package gentest.com.google.gson.stream.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.stream.*;
import com.google.gson.internal.JsonReaderInternalAccess;
import com.google.gson.internal.bind.JsonTreeReader;
import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.io.Reader;
 
public class JsonReaderTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                        public void testSetLenient_True() {
                                                                                                                                                                            // When
                                                                                                                                                                            jsonReader.setLenient(true);
                                                                                                                                                                            
                                                                                                                                                                            // Then
                                                                                                                                                                            assertTrue("Should be lenient after setting to true", 
                                                                                                                                                                                      jsonReader.isLenient());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testSetLenient_False() {
                                                                                                                                                                            // When
                                                                                                                                                                            jsonReader.setLenient(false);
                                                                                                                                                                            
                                                                                                                                                                            // Then
                                                                                                                                                                            assertFalse("Should not be lenient after setting to false", 
                                                                                                                                                                                       jsonReader.isLenient());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testSetLenient_ToggleBehavior() {
                                                                                                                                                                            // Initial state check (default might be false, but we'll test both ways)
                                                                                                                                                                            boolean initialState = jsonReader.isLenient();
                                                                                                                                                                            
                                                                                                                                                                            // First toggle
                                                                                                                                                                            jsonReader.setLenient(!initialState);
                                                                                                                                                                            assertEquals("First toggle should change the state", 
                                                                                                                                                                                        !initialState, jsonReader.isLenient());
                                                                                                                                                                            
                                                                                                                                                                            // Second toggle (back to original)
                                                                                                                                                                            jsonReader.setLenient(initialState);
                                                                                                                                                                            assertEquals("Second toggle should return to original state", 
                                                                                                                                                                                        initialState, jsonReader.isLenient());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testSetLenient_DoesNotAffectOtherOperations() {
                                                                                                                                                                            // Set up
                                                                                                                                                                            jsonReader.setLenient(true);
                                                                                                                                                                            
                                                                                                                                                                            // Perform some other operation (beginObject should work regardless of leniency)
                                                                                                                                                                            jsonReader.beginObject();
                                                                                                                                                                            
                                                                                                                                                                            // Change leniency
                                                                                                                                                                            jsonReader.setLenient(false);
                                                                                                                                                                            
                                                                                                                                                                            // Verify we can still perform operations
                                                                                                                                                                            jsonReader.endObject();
                                                                                                                                                                            
                                                                                                                                                                            // The test passes if no exceptions are thrown
                                                                                                                                                                            assertFalse("Lenient should be false after setting", 
                                                                                                                                                                                       jsonReader.isLenient());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testSetLenient_ConsecutiveCalls() {
                                                                                                                                                                            // Multiple true calls
                                                                                                                                                                            jsonReader.setLenient(true);
                                                                                                                                                                            jsonReader.setLenient(true);
                                                                                                                                                                            assertTrue("Consecutive true calls should keep lenient true", 
                                                                                                                                                                                      jsonReader.isLenient());
                                                                                                                                                                            
                                                                                                                                                                            // Multiple false calls
                                                                                                                                                                            jsonReader.setLenient(false);
                                                                                                                                                                            jsonReader.setLenient(false);
                                                                                                                                                                            assertFalse("Consecutive false calls should keep lenient false", 
                                                                                                                                                                                       jsonReader.isLenient());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testSetLenient_InMiddleOfReading() {
                                                                                                                                                                            // Set up a more complex JSON
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader("{\"key\": \"value\"}"));
                                                                                                                                                                            
                                                                                                                                                                            // Start reading
                                                                                                                                                                            jsonReader.beginObject();
                                                                                                                                                                            
                                                                                                                                                                            // Change leniency mid-read
                                                                                                                                                                            jsonReader.setLenient(true);
                                                                                                                                                                            assertTrue("Should be able to set lenient mid-read", 
                                                                                                                                                                                      jsonReader.isLenient());
                                                                                                                                                                            
                                                                                                                                                                            // Continue reading
                                                                                                                                                                            assertEquals("key", jsonReader.nextName());
                                                                                                                                                                            
                                                                                                                                                                            // Change leniency again
                                                                                                                                                                            jsonReader.setLenient(false);
                                                                                                                                                                            assertFalse("Should be able to change lenient multiple times mid-read", 
                                                                                                                                                                                       jsonReader.isLenient());
                                                                                                                                                                            
                                                                                                                                                                            // Finish reading
                                                                                                                                                                            assertEquals("value", jsonReader.nextString());
                                                                                                                                                                            jsonReader.endObject();
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testHasNext_WhenPeekedNone_AndDoPeekReturnsBeginObject() throws Exception {
                                                                                                                                                                            // Set peeked to PEEKED_NONE and mock doPeek to return BEGIN_OBJECT
                                                                                                                                                                            setPeekedField(jsonReader, JsonReader.PEEKED_NONE);
                                                                                                                                                                            JsonReader spyReader = spy(jsonReader);
                                                                                                                                                                            when(spyReader.doPeek()).thenReturn(JsonReader.PEEKED_BEGIN_OBJECT);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(spyReader.hasNext());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testHasNext_WhenPeekedNone_AndDoPeekReturnsEndObject() throws Exception {
                                                                                                                                                                            // Set peeked to PEEKED_NONE and mock doPeek to return END_OBJECT
                                                                                                                                                                            setPeekedField(jsonReader, JsonReader.PEEKED_NONE);
                                                                                                                                                                            JsonReader spyReader = spy(jsonReader);
                                                                                                                                                                            when(spyReader.doPeek()).thenReturn(JsonReader.PEEKED_END_OBJECT);
                                                                                                                                                                            
                                                                                                                                                                            assertFalse(spyReader.hasNext());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testHasNext_WhenPeekedNone_AndDoPeekReturnsBeginArray() throws Exception {
                                                                                                                                                                            // Set peeked to PEEKED_NONE and mock doPeek to return BEGIN_ARRAY
                                                                                                                                                                            setPeekedField(jsonReader, JsonReader.PEEKED_NONE);
                                                                                                                                                                            JsonReader spyReader = spy(jsonReader);
                                                                                                                                                                            when(spyReader.doPeek()).thenReturn(JsonReader.PEEKED_BEGIN_ARRAY);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(spyReader.hasNext());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testHasNext_WhenPeekedNone_AndDoPeekReturnsEndArray() throws Exception {
                                                                                                                                                                            // Set peeked to PEEKED_NONE and mock doPeek to return END_ARRAY
                                                                                                                                                                            setPeekedField(jsonReader, JsonReader.PEEKED_NONE);
                                                                                                                                                                            JsonReader spyReader = spy(jsonReader);
                                                                                                                                                                            when(spyReader.doPeek()).thenReturn(JsonReader.PEEKED_END_ARRAY);
                                                                                                                                                                            
                                                                                                                                                                            assertFalse(spyReader.hasNext());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testHasNext_WhenPeekedBeginObject() throws Exception {
                                                                                                                                                                            // Set peeked to BEGIN_OBJECT (shouldn't call doPeek)
                                                                                                                                                                            setPeekedField(jsonReader, JsonReader.PEEKED_BEGIN_OBJECT);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(jsonReader.hasNext());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testHasNext_WhenPeekedEndObject() throws Exception {
                                                                                                                                                                            // Set peeked to END_OBJECT (shouldn't call doPeek)
                                                                                                                                                                            setPeekedField(jsonReader, JsonReader.PEEKED_END_OBJECT);
                                                                                                                                                                            
                                                                                                                                                                            assertFalse(jsonReader.hasNext());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testHasNext_WhenPeekedBeginArray() throws Exception {
                                                                                                                                                                            // Set peeked to BEGIN_ARRAY (shouldn't call doPeek)
                                                                                                                                                                            setPeekedField(jsonReader, JsonReader.PEEKED_BEGIN_ARRAY);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(jsonReader.hasNext());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testHasNext_WhenPeekedEndArray() throws Exception {
                                                                                                                                                                            // Set peeked to END_ARRAY (shouldn't call doPeek)
                                                                                                                                                                            setPeekedField(jsonReader, JsonReader.PEEKED_END_ARRAY);
                                                                                                                                                                            
                                                                                                                                                                            assertFalse(jsonReader.hasNext());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testHasNext_WhenPeekedOtherValue() throws Exception {
                                                                                                                                                                            // Test with various other peeked values that should return true
                                                                                                                                                                            setPeekedField(jsonReader, JsonReader.PEEKED_TRUE);
                                                                                                                                                                            assertTrue(jsonReader.hasNext());
                                                                                                                                                                            
                                                                                                                                                                            setPeekedField(jsonReader, JsonReader.PEEKED_FALSE);
                                                                                                                                                                            assertTrue(jsonReader.hasNext());
                                                                                                                                                                            
                                                                                                                                                                            setPeekedField(jsonReader, JsonReader.PEEKED_NULL);
                                                                                                                                                                            assertTrue(jsonReader.hasNext());
                                                                                                                                                                            
                                                                                                                                                                            setPeekedField(jsonReader, JsonReader.PEEKED_STRING);
                                                                                                                                                                            assertTrue(jsonReader.hasNext());
                                                                                                                                                                            
                                                                                                                                                                            setPeekedField(jsonReader, JsonReader.PEEKED_NUMBER);
                                                                                                                                                                            assertTrue(jsonReader.hasNext());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPeek_WhenPeekedNone_CallsDoPeek() throws Exception {
                                                                                                                                                                            // Arrange
                                                                                                                                                                            JsonReader reader = spy(new JsonReader(new StringReader("{}")));
                                                                                                                                                                            when(reader.doPeek()).thenReturn(JsonReader.PEEKED_BEGIN_OBJECT);
                                                                                                                                                                            
                                                                                                                                                                            // Act
                                                                                                                                                                            JsonToken result = reader.peek();
                                                                                                                                                                            
                                                                                                                                                                            // Assert
                                                                                                                                                                            verify(reader).doPeek();
                                                                                                                                                                            assertEquals(JsonToken.BEGIN_OBJECT, result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPeek_WhenPeekedBeginObject_ReturnsBeginObject() throws Exception {
                                                                                                                                                                            // Arrange
                                                                                                                                                                            JsonReader reader = new JsonReader(new StringReader("{}"));
                                                                                                                                                                            reader.peeked = JsonReader.PEEKED_BEGIN_OBJECT;
                                                                                                                                                                            
                                                                                                                                                                            // Act & Assert
                                                                                                                                                                            assertEquals(JsonToken.BEGIN_OBJECT, reader.peek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPeek_WhenPeekedEndObject_ReturnsEndObject() throws Exception {
                                                                                                                                                                            // Arrange
                                                                                                                                                                            JsonReader reader = new JsonReader(new StringReader("{}"));
                                                                                                                                                                            reader.peeked = JsonReader.PEEKED_END_OBJECT;
                                                                                                                                                                            
                                                                                                                                                                            // Act & Assert
                                                                                                                                                                            assertEquals(JsonToken.END_OBJECT, reader.peek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPeek_WhenPeekedBeginArray_ReturnsBeginArray() throws Exception {
                                                                                                                                                                            // Arrange
                                                                                                                                                                            JsonReader reader = new JsonReader(new StringReader("[]"));
                                                                                                                                                                            reader.peeked = JsonReader.PEEKED_BEGIN_ARRAY;
                                                                                                                                                                            
                                                                                                                                                                            // Act & Assert
                                                                                                                                                                            assertEquals(JsonToken.BEGIN_ARRAY, reader.peek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPeek_WhenPeekedEndArray_ReturnsEndArray() throws Exception {
                                                                                                                                                                            // Arrange
                                                                                                                                                                            JsonReader reader = new JsonReader(new StringReader("[]"));
                                                                                                                                                                            reader.peeked = JsonReader.PEEKED_END_ARRAY;
                                                                                                                                                                            
                                                                                                                                                                            // Act & Assert
                                                                                                                                                                            assertEquals(JsonToken.END_ARRAY, reader.peek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPeek_WhenPeekedName_ReturnsName() throws Exception {
                                                                                                                                                                            // Test all name variants
                                                                                                                                                                            JsonReader reader = new JsonReader(new StringReader("{\"name\":\"value\"}"));
                                                                                                                                                                            
                                                                                                                                                                            reader.peeked = JsonReader.PEEKED_SINGLE_QUOTED_NAME;
                                                                                                                                                                            assertEquals(JsonToken.NAME, reader.peek());
                                                                                                                                                                            
                                                                                                                                                                            reader.peeked = JsonReader.PEEKED_DOUBLE_QUOTED_NAME;
                                                                                                                                                                            assertEquals(JsonToken.NAME, reader.peek());
                                                                                                                                                                            
                                                                                                                                                                            reader.peeked = JsonReader.PEEKED_UNQUOTED_NAME;
                                                                                                                                                                            assertEquals(JsonToken.NAME, reader.peek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPeek_WhenPeekedBoolean_ReturnsBoolean() throws Exception {
                                                                                                                                                                            // Test both boolean variants
                                                                                                                                                                            JsonReader reader = new JsonReader(new StringReader("true"));
                                                                                                                                                                            
                                                                                                                                                                            reader.peeked = JsonReader.PEEKED_TRUE;
                                                                                                                                                                            assertEquals(JsonToken.BOOLEAN, reader.peek());
                                                                                                                                                                            
                                                                                                                                                                            reader.peeked = JsonReader.PEEKED_FALSE;
                                                                                                                                                                            assertEquals(JsonToken.BOOLEAN, reader.peek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPeek_WhenPeekedNull_ReturnsNull() throws Exception {
                                                                                                                                                                            // Arrange
                                                                                                                                                                            JsonReader reader = new JsonReader(new StringReader("null"));
                                                                                                                                                                            reader.peeked = JsonReader.PEEKED_NULL;
                                                                                                                                                                            
                                                                                                                                                                            // Act & Assert
                                                                                                                                                                            assertEquals(JsonToken.NULL, reader.peek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPeek_WhenPeekedString_ReturnsString() throws Exception {
                                                                                                                                                                            // Test all string variants
                                                                                                                                                                            JsonReader reader = new JsonReader(new StringReader("\"string\""));
                                                                                                                                                                            
                                                                                                                                                                            reader.peeked = JsonReader.PEEKED_SINGLE_QUOTED;
                                                                                                                                                                            assertEquals(JsonToken.STRING, reader.peek());
                                                                                                                                                                            
                                                                                                                                                                            reader.peeked = JsonReader.PEEKED_DOUBLE_QUOTED;
                                                                                                                                                                            assertEquals(JsonToken.STRING, reader.peek());
                                                                                                                                                                            
                                                                                                                                                                            reader.peeked = JsonReader.PEEKED_UNQUOTED;
                                                                                                                                                                            assertEquals(JsonToken.STRING, reader.peek());
                                                                                                                                                                            
                                                                                                                                                                            reader.peeked = JsonReader.PEEKED_BUFFERED;
                                                                                                                                                                            assertEquals(JsonToken.STRING, reader.peek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPeek_WhenPeekedNumber_ReturnsNumber() throws Exception {
                                                                                                                                                                            // Test both number variants
                                                                                                                                                                            JsonReader reader = new JsonReader(new StringReader("123"));
                                                                                                                                                                            
                                                                                                                                                                            reader.peeked = JsonReader.PEEKED_LONG;
                                                                                                                                                                            assertEquals(JsonToken.NUMBER, reader.peek());
                                                                                                                                                                            
                                                                                                                                                                            reader.peeked = JsonReader.PEEKED_NUMBER;
                                                                                                                                                                            assertEquals(JsonToken.NUMBER, reader.peek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPeek_WhenPeekedEof_ReturnsEndDocument() throws Exception {
                                                                                                                                                                            // Arrange
                                                                                                                                                                            JsonReader reader = new JsonReader(new StringReader(""));
                                                                                                                                                                            reader.peeked = JsonReader.PEEKED_EOF;
                                                                                                                                                                            
                                                                                                                                                                            // Act & Assert
                                                                                                                                                                            assertEquals(JsonToken.END_DOCUMENT, reader.peek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPeek_WhenUnknownPeekedValue_ThrowsAssertionError() throws Exception {
                                                                                                                                                                            // Arrange
                                                                                                                                                                            JsonReader reader = new JsonReader(new StringReader(""));
                                                                                                                                                                            reader.peeked = -1; // Invalid peeked value
                                                                                                                                                                            
                                                                                                                                                                            // Expect exception
                                                                                                                                                                            thrown.expect(AssertionError.class);
                                                                                                                                                                            
                                                                                                                                                                            // Act
                                                                                                                                                                            reader.peek();
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testDoPeek_EmptyArray() throws Exception {
                                                                                                                                                                            String json = "[]";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            jsonReader.beginArray();
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(PEEKED_END_ARRAY, jsonReader.doPeek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testDoPeek_NonEmptyArrayWithComma() throws Exception {
                                                                                                                                                                            String json = "[1,2]";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            jsonReader.beginArray();
                                                                                                                                                                            jsonReader.nextInt(); // consume first element
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(PEEKED_NUMBER, jsonReader.doPeek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testDoPeek_NonEmptyArrayWithInvalidSeparator() throws Exception {
                                                                                                                                                                            String json = "[1;2]";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            jsonReader.beginArray();
                                                                                                                                                                            jsonReader.nextInt(); // consume first element
                                                                                                                                                                            
                                                                                                                                                                            expectedException.expect(IllegalStateException.class);
                                                                                                                                                                            expectedException.expectMessage("Unterminated array");
                                                                                                                                                                            jsonReader.doPeek();
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testDoPeek_EmptyObject() throws Exception {
                                                                                                                                                                            String json = "{}";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            jsonReader.beginObject();
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(PEEKED_END_OBJECT, jsonReader.doPeek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testDoPeek_NonEmptyObjectWithComma() throws Exception {
                                                                                                                                                                            String json = "{\"key1\":1,\"key2\":2}";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            jsonReader.beginObject();
                                                                                                                                                                            jsonReader.nextName(); // consume first name
                                                                                                                                                                            jsonReader.nextInt(); // consume first value
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(PEEKED_DOUBLE_QUOTED_NAME, jsonReader.doPeek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testDoPeek_NonEmptyObjectWithInvalidSeparator() throws Exception {
                                                                                                                                                                            String json = "{\"key1\":1;\"key2\":2}";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            jsonReader.beginObject();
                                                                                                                                                                            jsonReader.nextName(); // consume first name
                                                                                                                                                                            jsonReader.nextInt(); // consume first value
                                                                                                                                                                            
                                                                                                                                                                            expectedException.expect(IllegalStateException.class);
                                                                                                                                                                            expectedException.expectMessage("Unterminated object");
                                                                                                                                                                            jsonReader.doPeek();
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testDoPeek_EmptyDocument() throws Exception {
                                                                                                                                                                            String json = "";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(PEEKED_EOF, jsonReader.doPeek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testDoPeek_NonEmptyDocument() throws Exception {
                                                                                                                                                                            String json = "123";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(PEEKED_NUMBER, jsonReader.doPeek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testDoPeek_ClosedReader() throws Exception {
                                                                                                                                                                            String json = "{}";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            jsonReader.close();
                                                                                                                                                                            
                                                                                                                                                                            expectedException.expect(IllegalStateException.class);
                                                                                                                                                                            expectedException.expectMessage("JsonReader is closed");
                                                                                                                                                                            jsonReader.doPeek();
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testDoPeek_QuotedString() throws Exception {
                                                                                                                                                                            String json = "\"hello\"";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(PEEKED_DOUBLE_QUOTED, jsonReader.doPeek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testDoPeek_SingleQuotedStringInLenientMode() throws Exception {
                                                                                                                                                                            String json = "'hello'";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            jsonReader.setLenient(true);
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(PEEKED_SINGLE_QUOTED, jsonReader.doPeek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testDoPeek_BeginArray() throws Exception {
                                                                                                                                                                            String json = "[";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(PEEKED_BEGIN_ARRAY, jsonReader.doPeek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testDoPeek_BeginObject() throws Exception {
                                                                                                                                                                            String json = "{";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(PEEKED_BEGIN_OBJECT, jsonReader.doPeek());
                                                                                                                                                                        }
                                                                                                                                                                    
                                                                                                                                                                        @Test
                                                                                                                                                                        public void testDoPeek_UnquotedValueInLenientMode() throws Exception {
                                                                                                                                                                            String json = "hello";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            jsonReader.setLenient(true);
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(PEEKED_UNQUOTED, jsonReader.doPeek());
                                                                                                                                                                        }
                                                                                                                                                                    
                                                                                                                                                                        @Test
                                                                                                                                                                        public void testDoPeek_InvalidValue() throws Exception {
                                                                                                                                                                            String json = "@";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            jsonReader.setLenient(true);
                                                                                                                                                                            
                                                                                                                                                                            expectedException.expect(IllegalStateException.class);
                                                                                                                                                                            expectedException.expectMessage("Expected value");
                                                                                                                                                                            jsonReader.doPeek();
                                                                                                                                                                        }
                                                                                                                                                                    }

    @Test
            public void testPeekKeyword_NullLowercase() throws Exception {
                // Define test constants
                String input = "null";
                
                // Create JsonReader with test input
                
                // Set up reader state using reflection since buffer is likely private
{
}{
                    throw new RuntimeException("Failed to set up JsonReader state via reflection", e);
                }
                
                // Verify behavior
                int result = jsonReader.peekKeyword();
            }

    @Test
            public void testPeekKeyword_NullUppercase() throws Exception {
                // Create a JsonReader with a StringReader containing "NULL"
                java.io.Reader reader = new java.io.StringReader("NULL");
                
                // Use reflection to access the private peekKeyword method
                
                // Verify the result (assuming peekKeyword should return JsonToken.NULL for "NULL")
                // Note: peekKeyword actually returns an int that corresponds to JsonToken.NULL's ordinal
            }

    @Test
            public void testPeekKeyword_IncompleteKeyword() throws Exception {
                String input = "tru";
                
                // Use reflection to access private peekKeyword method
                // Verify initial state is PEEKED_NONE
            }

    @Test
            public void testPeekKeyword_InvalidKeyword() throws Exception {
                // Create test input with invalid keyword
                java.io.StringReader reader = new java.io.StringReader("invalid");
                
                // Use reflection to access private peekKeyword method
                // Verify that the result indicates an invalid keyword
                // (Assuming peekKeyword returns -1 or similar for invalid keywords)
            }

    @Test
        public void testPeekKeyword_KeywordFollowedByLiteral() throws Exception {
            // Create a JsonReader with a StringReader containing test data
            String testData = "trueX"; // "true" is keyword followed by literal 'X'
            
            // Get the private peekKeyword method via reflection
            // Verify the result (assuming PEEKED_TRUE is 5 based on common JsonReader implementations)
            // For Gson's JsonReader, PEEKED_TRUE is typically 5
        }

    @Test
        public void testPeekKeyword_KeywordAtBufferBoundary() throws Exception {
            String input = "true";
            
            // Access private buffer field using reflection
            // Call the peekKeyword method
            
            // Verify the result (assuming PEEKED_TRUE is a constant in JsonReader)
        }

    @Test
        public void testPeekKeyword_MixedCaseKeyword() throws Exception {
            // Define test input
            String input = "TrUe";
            
            // Create JsonReader instance
            
            // Set up reader state using reflection
{
}{
                throw new RuntimeException("Failed to set up JsonReader state via reflection", e);
            }
            
            // Create spy
            com.google.gson.stream.JsonReader spyReader = org.mockito.spy(jsonReader);
            
            // Get PEEKED_TRUE value via reflection
{
}{
                throw new RuntimeException("Failed to access PEEKED_TRUE constant", e);
            }
            
            // Verify behavior
            org.junit.Assert.assertEquals(PEEKED_TRUE, spyReader.peek());
        }

    @Test
        public void testPeekKeyword_TrueLowercase() throws Exception {
            String input = "true";
            
            // Use reflection to access private method
            // Verify results - assuming peekKeyword returns PEEKED_TRUE (1) for "true"
        }

    @Test
        public void testPeekKeyword_TrueUppercase() throws Exception {
            // Define test input
            String input = "TRUE";
            
            // Create JsonReader instance
            
            // Set up reader state using reflection since buffer, pos, and limit are private
            
        }

    @Test
    public void testPeekKeyword_FalseLowercase() throws Exception {
        // Create a JsonReader with a mock reader
        java.io.Reader mockReader = new java.io.StringReader("false");
        
        // Use reflection to access private peekKeyword method
        
        // Assert that peekKeyword returns 0 for "false"
    }

    @Test
    public void testPeekKeyword_FalseUppercase() throws Exception {
        String input = "FALSE";
        
        // Use reflection to access private peekKeyword method
        // Verify the result is not zero (assuming 0 means no keyword matched)
    }


}
