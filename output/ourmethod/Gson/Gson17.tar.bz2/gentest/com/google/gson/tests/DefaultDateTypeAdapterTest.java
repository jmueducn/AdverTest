package gentest.com.google.gson.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.*;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import com.google.gson.internal.bind.util.ISO8601Utils;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
 
public class DefaultDateTypeAdapterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                     public void testRead_SqlDateType() throws Exception {
                                                                                                                                                                                                         // Setup test data
                                                                                                                                                                                                         String testDateString = "2023-01-01";
                                                                                                                                                                                                         JsonReader in = mock(JsonReader.class);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Create adapter using reflection since DefaultDateTypeAdapter is not public
                                                                                                                                                                                                         Constructor<?> constructor = Class.forName("com.google.gson.DefaultDateTypeAdapter")
                                                                                                                                                                                                             .getDeclaredConstructor(Class.class);
                                                                                                                                                                                                         constructor.setAccessible(true);
                                                                                                                                                                                                         Object dateAdapter = constructor.newInstance(java.sql.Date.class);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Mock behavior
                                                                                                                                                                                                         when(in.peek()).thenReturn(JsonToken.STRING);
                                                                                                                                                                                                         when(in.nextString()).thenReturn(testDateString);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Call read method using reflection
                                                                                                                                                                                                         Method readMethod = dateAdapter.getClass().getDeclaredMethod("read", JsonReader.class);
                                                                                                                                                                                                         Date result = (Date) readMethod.invoke(dateAdapter, in);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Verify results
                                                                                                                                                                                                         assertNotNull(result);
                                                                                                                                                                                                         assertEquals(java.sql.Date.class, result.getClass());
                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                     public void testRead_InvalidDateFormat() throws Exception {
                                                                                                                                                                                                         // Create mock JsonReader
                                                                                                                                                                                                         JsonReader in = mock(JsonReader.class);
                                                                                                                                                                                                         when(in.peek()).thenReturn(JsonToken.STRING);
                                                                                                                                                                                                         when(in.nextString()).thenReturn("invalid-date-format");
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Create adapter instance using reflection since DefaultDateTypeAdapter is not public
                                                                                                                                                                                                         Constructor<?> constructor = Class.forName("com.google.gson.DefaultDateTypeAdapter")
                                                                                                                                                                                                             .getDeclaredConstructor(Class.class);
                                                                                                                                                                                                         constructor.setAccessible(true);
                                                                                                                                                                                                         Object dateAdapter = constructor.newInstance(Date.class);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // We expect this to throw an exception from deserializeToDate
                                                                                                                                                                                                         thrown.expect(RuntimeException.class);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Call read method using reflection
                                                                                                                                                                                                         Method readMethod = dateAdapter.getClass().getMethod("read", JsonReader.class);
                                                                                                                                                                                                         readMethod.invoke(dateAdapter, in);
                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                 public void testRead_DateType() throws Exception {
                                                                                                                                                                                                     // Create test date string
                                                                                                                                                                                                     String testDateString = "2023-01-01";
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Mock JsonReader
                                                                                                                                                                                                     JsonReader in = mock(JsonReader.class);
                                                                                                                                                                                                     when(in.peek()).thenReturn(JsonToken.STRING);
                                                                                                                                                                                                     when(in.nextString()).thenReturn(testDateString);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Get the DefaultDateTypeAdapter class using reflection
                                                                                                                                                                                                     Class<?> adapterClass = Class.forName("com.google.gson.DefaultDateTypeAdapter");
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Get the constructor that takes a Class parameter
                                                                                                                                                                                                     Constructor<?> constructor = adapterClass.getDeclaredConstructor(Class.class);
                                                                                                                                                                                                     constructor.setAccessible(true);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Create instance using reflection
                                                                                                                                                                                                     Object dateAdapter = constructor.newInstance(Date.class);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Get the read method
                                                                                                                                                                                                     Method readMethod = adapterClass.getDeclaredMethod("read", JsonReader.class);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Invoke the read method
                                                                                                                                                                                                     Date result = (Date) readMethod.invoke(dateAdapter, in);
                                                                                                                                                                                                     
                                                                                                                                                                                                     assertNotNull(result);
                                                                                                                                                                                                     assertEquals(Date.class, result.getClass());
                                                                                                                                                                                                 }

    @Test
                                                                                                                                 public void testRead_NullValue() throws Exception {
                                                                                                                                     // Create mock JsonReader
                                                                                                                                     JsonReader in = mock(JsonReader.class);
                                                                                                                                     
                                                                                                                                     // Get constructor via reflection
                                                                                                                                     Class<?> adapterClass = Class.forName("com.google.gson.DefaultDateTypeAdapter");
                                                                                                                                     Constructor<?> constructor = adapterClass.getConstructor(int.class, int.class);
                                                                                                                                     Object dateAdapter = constructor.newInstance(DateFormat.LONG, DateFormat.LONG);
                                                                                                                                     
                                                                                                                                     // Setup mock behavior
                                                                                                                                     when(in.peek()).thenReturn(JsonToken.NULL);
                                                                                                                                     
                                                                                                                                     // Execute test
                                                                                                                                     Method readMethod = adapterClass.getMethod("read", JsonReader.class);
                                                                                                                                     Date result = (Date) readMethod.invoke(dateAdapter, in);
                                                                                                                                     
                                                                                                                                     // Verify results
                                                                                                                                     assertNull(result);
                                                                                                                                     verify(in).nextNull();
                                                                                                                                 }

    @Test
                                                                                                                         public void testRead_TimestampType() throws Exception {
                                                                                                                             // Define test date string
                                                                                                                             String testDateString = "2023-01-01T12:00:00";
                                                                                                                             
                                                                                                                             // Create mock JsonReader
                                                                                                                             JsonReader in = mock(JsonReader.class);
                                                                                                                             
                                                                                                                             // Create date adapter for Timestamp type using public constructor
                                                                                                                             // Mock JsonReader behavior
                                                                                                                             when(in.peek()).thenReturn(JsonToken.STRING);
                                                                                                                             when(in.nextString()).thenReturn(testDateString);
                                                                                                                             
                                                                                                                             // Execute test
                                                                                                                             
                                                                                                                             // Verify results
                                                                                                                         }

    @Test
                                                                                                                         public void testRead_InvalidDateType() throws Exception {
                                                                                                                             // The constructor should prevent this, but we'll test the else branch
                                                                                                                             // by using reflection to bypass the constructor check
                                                                                                                             
                                                                                                                             ExpectedException thrown = ExpectedException.none();
                                                                                                                             thrown.expect(AssertionError.class);
                                                                                                                             
                                                                                                                             // Create test data
                                                                                                                             String testDateString = "2023-01-01";
                                                                                                                             JsonReader in = mock(JsonReader.class);
                                                                                                                             
                                                                                                                             // Create a mock Class object that's not one of the supported types
                                                                                                                             @SuppressWarnings("unchecked")
                                                                                                                             Class<Date> invalidType = (Class<Date>) mock(Class.class);
                                                                                                                             when(invalidType.getName()).thenReturn("InvalidDateType");
                                                                                                                             
                                                                                                                             // Create date adapter using public constructor
                                                                                                                             // Get the dateType field via reflection
                                                                                                                             
                                                                                                                             // Modify the dateType via reflection
                                                                                                                     {
                                                                                                                     }{
                                                                                                                                 fail("Failed to set dateType field via reflection");
                                                                                                                             }
                                                                                                                             
                                                                                                                             when(in.peek()).thenReturn(JsonToken.STRING);
                                                                                                                             when(in.nextString()).thenReturn(testDateString);
                                                                                                                             
                                                                                                                         }

    @Test
                                                                                                                         public void testRead_EmptyString() throws Exception {
                                                                                                                             // Create date adapter instance using public constructor
                                                                                                                             // Mock JsonReader
                                                                                                                             JsonReader in = mock(JsonReader.class);
                                                                                                                             when(in.peek()).thenReturn(JsonToken.STRING);
                                                                                                                             when(in.nextString()).thenReturn("");
                                                                                                                             
                                                                                                                             // Expect exception
                                                                                                                             ExpectedException thrown = ExpectedException.none();
                                                                                                                             thrown.expect(IllegalArgumentException.class);
                                                                                                                             
                                                                                                                         }

    @Test
                                                                                                public void testReadWithNullToken_ShouldReturnNull() throws IOException {
                                                                                                    // Arrange
                                                                                                    JsonReader mockReader = mock(JsonReader.class);
                                                                                                    when(mockReader.peek()).thenReturn(JsonToken.NULL);
                                                                                                    
                                                                                                    // Create adapter using reflection
                                                                                                    try {
                                                                                                        Constructor<?> constructor = Class.forName("com.google.gson.DefaultDateTypeAdapter")
                                                                                                            .getConstructor(int.class, int.class);
                                                                                                        Object adapter = constructor.newInstance(DateFormat.LONG, DateFormat.LONG);
                                                                                                        
                                                                                                        // Act
                                                                                                        Method readMethod = adapter.getClass().getMethod("read", JsonReader.class);
                                                                                                        Date result = (Date) readMethod.invoke(adapter, mockReader);
                                                                                                        
                                                                                                        // Assert
                                                                                                        assertNull("Expected null when reading NULL token", result);
                                                                                                        verify(mockReader).nextNull();
                                                                                                    } catch (Exception e) {
                                                                                                        fail("Test failed due to reflection error: " + e.getMessage());
                                                                                                    }
                                                                                                }

    @Test
                                                                                           public void testReadWithValidDateString_ShouldReturnCorrectDateType() throws Exception {
                                                                                               // Arrange
                                                                                               JsonReader in = mock(JsonReader.class);
                                                                                               when(in.peek()).thenReturn(JsonToken.STRING); // Not NULL
                                                                                               when(in.nextString()).thenReturn("2023-01-01");
                                                                                               
                                                                                               // Get constructor for Date adapter
                                                                                               Constructor<?> dateConstructor = Class.forName("com.google.gson.DefaultDateTypeAdapter")
                                                                                                       .getDeclaredConstructor(Class.class);
                                                                                               dateConstructor.setAccessible(true);
                                                                                               Object dateAdapter = dateConstructor.newInstance(Date.class);
                                                                                               
                                                                                               // Act
                                                                                               Method readMethod = dateAdapter.getClass().getDeclaredMethod("read", JsonReader.class);
                                                                                               Date result = (Date) readMethod.invoke(dateAdapter, in);
                                                                                               
                                                                                               // Assert
                                                                                               assertNotNull("Result should not be null for valid date string", result);
                                                                                               assertEquals("Should return Date type", Date.class, result.getClass());
                                                                                               
                                                                                               // Additional test for Timestamp type
                                                                                               Constructor<?> timestampConstructor = Class.forName("com.google.gson.DefaultDateTypeAdapter")
                                                                                                       .getDeclaredConstructor(Class.class);
                                                                                               timestampConstructor.setAccessible(true);
                                                                                               Object timestampAdapter = timestampConstructor.newInstance(Timestamp.class);
                                                                                               when(in.nextString()).thenReturn("2023-01-01"); // Reset mock
                                                                                               Timestamp timestampResult = (Timestamp) readMethod.invoke(timestampAdapter, in);
                                                                                               assertNotNull("Timestamp result should not be null", timestampResult);
                                                                                               assertEquals("Should return Timestamp type", Timestamp.class, timestampResult.getClass());
                                                                                               
                                                                                               // Additional test for sql.Date type
                                                                                               Constructor<?> sqlDateConstructor = Class.forName("com.google.gson.DefaultDateTypeAdapter")
                                                                                                       .getDeclaredConstructor(Class.class);
                                                                                               sqlDateConstructor.setAccessible(true);
                                                                                               Object sqlDateAdapter = sqlDateConstructor.newInstance(java.sql.Date.class);
                                                                                               when(in.nextString()).thenReturn("2023-01-01"); // Reset mock
                                                                                               java.sql.Date sqlDateResult = (java.sql.Date) readMethod.invoke(sqlDateAdapter, in);
                                                                                               assertNotNull("SQL Date result should not be null", sqlDateResult);
                                                                                               assertEquals("Should return java.sql.Date type", java.sql.Date.class, sqlDateResult.getClass());
                                                                                           }

    @Test
                                                                                  public void testReadWithDateTypeShouldReturnDateDirectly() throws Exception {
                                                                                      // Arrange
                                                                                      JsonReader in = mock(JsonReader.class);
                                                                                      when(in.peek()).thenReturn(JsonToken.STRING);
                                                                                      when(in.nextString()).thenReturn("2023-01-01");
                                                                                      
                                                                                      // Get the constructor using reflection
                                                                                      Class<?> adapterClass = Class.forName("com.google.gson.DefaultDateTypeAdapter");
                                                                                      Constructor<?> constructor = adapterClass.getConstructor(Class.class, int.class, int.class);
                                                                                      
                                                                                      // Create adapter instance
                                                                                      Object adapter = constructor.newInstance(Date.class, DateFormat.LONG, DateFormat.LONG);
                                                                                      
                                                                                      // Get the read method
                                                                                      Method readMethod = adapterClass.getMethod("read", JsonReader.class);
                                                                                      
                                                                                      // Act
                                                                                      Object result = readMethod.invoke(adapter, in);
                                                                                      
                                                                                      // Assert
                                                                                      assertNotNull(result);
                                                                                      assertEquals(Date.class, result.getClass());
                                                                                      assertFalse(result instanceof Timestamp);
                                                                                      assertFalse(result instanceof java.sql.Date);
                                                                                  }

    @Test
                                                                             public void testReadWithTimestampTypeShouldReturnTimestamp() throws Exception {
                                                                                 // Arrange
                                                                                 @SuppressWarnings("unchecked")
                                                                                 Class<? extends Date> timestampType = (Class<? extends Date>) Timestamp.class;
                                                                                 
                                                                                 // Use reflection to access the non-public constructor
                                                                                 Constructor<?> constructor = Class.forName("com.google.gson.DefaultDateTypeAdapter")
                                                                                     .getDeclaredConstructor(Class.class);
                                                                                 constructor.setAccessible(true);
                                                                                 Object adapter = constructor.newInstance(timestampType);
                                                                                 
                                                                                 JsonReader in = mock(JsonReader.class);
                                                                                 when(in.peek()).thenReturn(JsonToken.STRING);
                                                                                 when(in.nextString()).thenReturn("2023-01-01 12:00:00");
                                                                                 
                                                                                 // Act
                                                                                 Method readMethod = adapter.getClass().getMethod("read", JsonReader.class);
                                                                                 Object result = readMethod.invoke(adapter, in);
                                                                                 
                                                                                 // Assert
                                                                                 assertTrue("Should return Timestamp when dateType is Timestamp.class", 
                                                                                            result instanceof Timestamp);
                                                                                 assertEquals("Should preserve correct time value", 
                                                                                             new Date(123, 0, 1, 12, 0, 0).getTime(), 
                                                                                             ((Timestamp)result).getTime());
                                                                                 
                                                                                 // The mutant would fail both assertions:
                                                                                 // 1. It would return Date instead of Timestamp
                                                                                 // 2. Even if cast to Date, the value might differ due to different parsing
                                                                             }

    @Test
                                                                    public void testReadReturnsDateWhenDateTypeIsDate() throws Exception {
                                                                        // Setup
                                                                        JsonReader mockReader = mock(JsonReader.class);
                                                                        when(mockReader.peek()).thenReturn(JsonToken.STRING);
                                                                        when(mockReader.nextString()).thenReturn("2023-01-01");
                                                                        
                                                                        // Create adapter using reflection since DefaultDateTypeAdapter is not public
                                                                        Class<?> adapterClass = Class.forName("com.google.gson.DefaultDateTypeAdapter");
                                                                        Constructor<?> constructor = adapterClass.getDeclaredConstructor(Class.class, DateFormat.class, DateFormat.class);
                                                                        constructor.setAccessible(true);
                                                                        
                                                                        DateFormat format = DateFormat.getDateInstance(DateFormat.LONG);
                                                                        Object adapter = constructor.newInstance(Date.class, format, format);
                                                                        
                                                                        // Execute
                                                                        Method readMethod = adapterClass.getMethod("read", JsonReader.class);
                                                                        Date result = (Date) readMethod.invoke(adapter, mockReader);
                                                                        
                                                                        // Verify
                                                                        assertNotNull(result);
                                                                        // Should return plain Date, not Timestamp or sql.Date
                                                                        assertEquals(Date.class, result.getClass());
                                                                        
                                                                        // Verify interactions
                                                                        verify(mockReader).peek();
                                                                        verify(mockReader).nextString();
                                                                    }

    @Test
                                                               public void testReadWithSpecificDateShouldReturnParsedDateNotCurrentDate() throws Exception {
                                                                   // Arrange
                                                                   String testDateString = "2023-01-01";
                                                                   Date expectedDate = new SimpleDateFormat("yyyy-MM-dd").parse(testDateString);
                                                                   
                                                                   JsonReader mockReader = mock(JsonReader.class);
                                                                   when(mockReader.peek()).thenReturn(JsonToken.STRING);
                                                                   when(mockReader.nextString()).thenReturn(testDateString);
                                                                   
                                                                   // Create adapters using reflection
                                                                   Constructor<?> dateConstructor = Class.forName("com.google.gson.DefaultDateTypeAdapter")
                                                                           .getDeclaredConstructor(Class.class);
                                                                   dateConstructor.setAccessible(true);
                                                                   Object dateAdapter = dateConstructor.newInstance(Date.class);
                                                                   Method readMethod = dateAdapter.getClass().getMethod("read", JsonReader.class);
                                                                   
                                                                   // Act
                                                                   Date result = (Date) readMethod.invoke(dateAdapter, mockReader);
                                                                   
                                                                   // Assert
                                                                   assertEquals(expectedDate, result);
                                                                   
                                                                   // Additional test for Timestamp type
                                                                   Object timestampAdapter = dateConstructor.newInstance(Timestamp.class);
                                                                   Timestamp timestampResult = (Timestamp) readMethod.invoke(timestampAdapter, mockReader);
                                                                   assertEquals(new Timestamp(expectedDate.getTime()), timestampResult);
                                                                   
                                                                   // Additional test for sql.Date type
                                                                   Object sqlDateAdapter = dateConstructor.newInstance(java.sql.Date.class);
                                                                   java.sql.Date sqlDateResult = (java.sql.Date) readMethod.invoke(sqlDateAdapter, mockReader);
                                                                   assertEquals(new java.sql.Date(expectedDate.getTime()), sqlDateResult);
                                                                   
                                                                   // Verify interactions
                                                                   verify(mockReader, times(3)).peek();
                                                                   verify(mockReader, times(3)).nextString();
                                                               }

    @Test
                                                      public void testRead_ShouldConvertToTimestampWhenDateTypeIsTimestamp() throws Exception {
                                                          // Arrange
                                                          @SuppressWarnings("unchecked")
                                                          Class<? extends Date> timestampClass = (Class<? extends Date>) Timestamp.class;
                                                          JsonReader in = mock(JsonReader.class);
                                                          when(in.peek()).thenReturn(JsonToken.STRING);
                                                          when(in.nextString()).thenReturn("2023-01-01");
                                                          
                                                          // Use reflection to access the non-public constructor
                                                          Constructor<?> constructor = Class.forName("com.google.gson.DefaultDateTypeAdapter")
                                                              .getDeclaredConstructor(Class.class, DateFormat.class, DateFormat.class);
                                                          constructor.setAccessible(true);
                                                          
                                                          // Create adapter with Timestamp as dateType
                                                          Object adapter = constructor.newInstance(
                                                              timestampClass, 
                                                              DateFormat.getDateTimeInstance(DateFormat.DEFAULT, DateFormat.DEFAULT, Locale.US),
                                                              DateFormat.getDateTimeInstance(DateFormat.DEFAULT, DateFormat.DEFAULT)
                                                          );
                                                          
                                                          // Act
                                                          Method readMethod = adapter.getClass().getMethod("read", JsonReader.class);
                                                          Object result = readMethod.invoke(adapter, in);
                                                          
                                                          // Assert
                                                          assertTrue("Result should be Timestamp", result instanceof Timestamp);
                                                          assertEquals("Timestamp time should match", 
                                                              new Date(123, 0, 1).getTime(), 
                                                              ((Timestamp)result).getTime());
                                                      }

    @Test
                                          public void testRead_ShouldConvertToSqlDateWhenDateTypeIsSqlDate() throws Exception {
                                              // Arrange
                                              Class<java.sql.Date> sqlDateClass = java.sql.Date.class;
                                              JsonReader in = mock(JsonReader.class);
                                              when(in.peek()).thenReturn(JsonToken.STRING);
                                              when(in.nextString()).thenReturn("2023-01-01");
                                              
                                              // Get the constructor using reflection
                                              Class<?> adapterClass = Class.forName("com.google.gson.DefaultDateTypeAdapter");
                                              Constructor<?> constructor = adapterClass.getDeclaredConstructor(
                                                  Class.class, int.class, int.class
                                              );
                                              constructor.setAccessible(true);
                                              Object adapter = constructor.newInstance(
                                                  sqlDateClass, DateFormat.LONG, DateFormat.LONG
                                              );
                                              
                                              // Get the read method
                                              Method readMethod = adapterClass.getDeclaredMethod("read", JsonReader.class);
                                              
                                              // Act
                                              Object result = readMethod.invoke(adapter, in);
                                              
                                              // Assert
                                              assertTrue("Result should be java.sql.Date", result instanceof java.sql.Date);
                                              assertEquals("java.sql.Date time should match", 
                                                      new java.util.Date(123, 0, 1).getTime(), 
                                                      ((java.sql.Date)result).getTime());
                                          }

    @Test
                                     public void testReadReturnsDateWhenDateTypeIsDate1() throws Exception {
                                         // Setup
                                         JsonReader mockReader = mock(JsonReader.class);
                                         when(mockReader.peek()).thenReturn(JsonToken.STRING);
                                         String testDateStr = "2023-01-01";
                                         when(mockReader.nextString()).thenReturn(testDateStr);
                                         
                                         // Create adapter with Date.class type using reflection
                                         Class<?> adapterClass = Class.forName("com.google.gson.DefaultDateTypeAdapter");
                                         Constructor<?> constructor = adapterClass.getDeclaredConstructor(Class.class);
                                         constructor.setAccessible(true);
                                         Object adapter = constructor.newInstance(Date.class);
                                         
                                         // Get read method
                                         Method readMethod = adapterClass.getDeclaredMethod("read", JsonReader.class);
                                         readMethod.setAccessible(true);
                                         
                                         // Test
                                         Object result = readMethod.invoke(adapter, mockReader);
                                         
                                         // Verify
                                         assertNotNull(result);
                                         assertEquals(Date.class, result.getClass());
                                         assertFalse(result instanceof Timestamp);
                                         
                                         // Verify interactions
                                         verify(mockReader).peek();
                                         verify(mockReader).nextString();
                                     }

    @Test
                     public void testReadReturnsTimestampWhenDateTypeIsTimestamp() throws Exception {
                         // Setup
                         JsonReader mockReader = mock(JsonReader.class);
                         when(mockReader.peek()).thenReturn(JsonToken.STRING);
                         String testDateStr = "2023-01-01";
                         when(mockReader.nextString()).thenReturn(testDateStr);
                         
                         // Create adapter with Timestamp.class type using reflection
                         Class<?> adapterClass = Class.forName("com.google.gson.DefaultDateTypeAdapter");
                         Constructor<?> constructor = adapterClass.getConstructor(Class.class, int.class, int.class);
                         Object adapter = constructor.newInstance(Timestamp.class, DateFormat.LONG, DateFormat.LONG);
                         
                         // Test
                         Method readMethod = adapterClass.getMethod("read", JsonReader.class);
                         Object result = readMethod.invoke(adapter, mockReader);
                         
                         // Verify
                         assertNotNull(result);
                         assertEquals(Timestamp.class, result.getClass());
                         
                         // Verify interactions
                         verify(mockReader).peek();
                         verify(mockReader).nextString();
                     }

    @Test
    public void testReadWithUppercaseDateString() throws Exception {
        // Setup
        Class<Date> dateType = Date.class;
        DateFormat enUsFormat = new SimpleDateFormat("MMM dd, yyyy", Locale.US);
        DateFormat localFormat = new SimpleDateFormat("MMM dd, yyyy");
        
        // Use reflection to access the non-public constructor
        Constructor<?> constructor = Class.forName("com.google.gson.DefaultDateTypeAdapter")
                .getDeclaredConstructor(Class.class, DateFormat.class, DateFormat.class);
        constructor.setAccessible(true);
        Object adapter = constructor.newInstance(dateType, enUsFormat, localFormat);
        Method readMethod = adapter.getClass().getMethod("read", JsonReader.class);
        
        JsonReader in = mock(JsonReader.class);
        when(in.peek()).thenReturn(JsonToken.STRING);
        String testDateStr = "JAN 01, 2023";  // Uppercase month
        when(in.nextString()).thenReturn(testDateStr);
        
        // Expected date (Jan 1, 2023)
        SimpleDateFormat expectedFormat = new SimpleDateFormat("MMM dd, yyyy", Locale.US);
        Date expectedDate = expectedFormat.parse("Jan 01, 2023");
        
        // Test
        Date result = (Date) readMethod.invoke(adapter, in);
        
        // Verify
        assertEquals(expectedDate, result);
        verify(in).peek();
        verify(in).nextString();
    }


}
