package gentest.com.google.gson.internal.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.internal.*;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.GenericDeclaration;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
 
public class $Gson$TypesTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                        public void testGetSupertype_WithWildcardType_ResolvesUpperBound() throws Exception {
                                            // Setup
                                            WildcardType wildcardType = mock(WildcardType.class);
                                            Type upperBound = mock(Type.class);
                                            when(wildcardType.getUpperBounds()).thenReturn(new Type[]{upperBound});
                                            
                                            Class<?> contextRawType = Object.class;
                                            Class<?> supertype = Object.class;
                                            
                                            // Get private methods via reflection
                                            Method getGenericSupertype = $Gson$Types.class.getDeclaredMethod(
                                                "getGenericSupertype", Type.class, Class.class, Class.class);
                                            getGenericSupertype.setAccessible(true);
                                            
                                            Method getSupertype = $Gson$Types.class.getDeclaredMethod(
                                                "getSupertype", Type.class, Class.class, Class.class);
                                            getSupertype.setAccessible(true);
                                            
                                            Method resolve = $Gson$Types.class.getDeclaredMethod(
                                                "resolve", Type.class, Class.class, Type.class);
                                            resolve.setAccessible(true);
                                            
                                            // Mock the getGenericSupertype call
                                            Type resolvedType = mock(Type.class);
                                            when(getGenericSupertype.invoke(null, upperBound, contextRawType, supertype))
                                                .thenReturn(resolvedType);
                                            
                                            // Mock the resolve call
                                            Type expectedResult = mock(Type.class);
                                            when(resolve.invoke(null, upperBound, contextRawType, resolvedType))
                                                .thenReturn(expectedResult);
                                        
                                            // Test
                                            Type result = (Type) getSupertype.invoke(null, wildcardType, contextRawType, supertype);
                                            
                                            // Verify
                                            assertEquals(expectedResult, result);
                                            verify(wildcardType).getUpperBounds();
                                            verify(getGenericSupertype).invoke(null, upperBound, contextRawType, supertype);
                                            verify(resolve).invoke(null, upperBound, contextRawType, resolvedType);
                                        }

    @Test
                                        public void testGetSupertype_WithRegularType_ResolvesNormally() throws Exception {
                                            // Setup
                                            Type context = mock(Type.class);
                                            Class<?> contextRawType = Object.class;
                                            Class<?> supertype = Object.class;
                                            
                                            // Get the methods via reflection
                                            Method getGenericSupertypeMethod = $Gson$Types.class.getDeclaredMethod(
                                                "getGenericSupertype", Type.class, Class.class, Class.class);
                                            getGenericSupertypeMethod.setAccessible(true);
                                            
                                            Method getSupertypeMethod = $Gson$Types.class.getDeclaredMethod(
                                                "getSupertype", Type.class, Class.class, Class.class);
                                            getSupertypeMethod.setAccessible(true);
                                            
                                            Method resolveMethod = $Gson$Types.class.getDeclaredMethod(
                                                "resolve", Type.class, Class.class, Type.class);
                                            resolveMethod.setAccessible(true);
                                            
                                            // Mock the getGenericSupertype call
                                            Type genericSupertype = mock(Type.class);
                                            when(getGenericSupertypeMethod.invoke(null, context, contextRawType, supertype))
                                                .thenReturn(genericSupertype);
                                            
                                            // Mock the resolve call
                                            Type expectedResult = mock(Type.class);
                                            when(resolveMethod.invoke(null, context, contextRawType, genericSupertype))
                                                .thenReturn(expectedResult);
                                        
                                            // Test
                                            Type result = (Type) getSupertypeMethod.invoke(null, context, contextRawType, supertype);
                                            
                                            // Verify
                                            assertEquals(expectedResult, result);
                                            verify(getGenericSupertypeMethod).invoke(null, context, contextRawType, supertype);
                                            verify(resolveMethod).invoke(null, context, contextRawType, genericSupertype);
                                        }

    @Test
                                        public void testGetSupertype_WithIncompatibleTypes_ThrowsIllegalArgumentException() throws Exception {
                                            // Setup
                                            Type context = mock(Type.class);
                                            Class<?> contextRawType = String.class;
                                            Class<?> supertype = Integer.class; // String is not assignable to Integer
                                            
                                            // Get the private method via reflection
                                            Method getSupertypeMethod = $Gson$Types.class.getDeclaredMethod(
                                                "getSupertype", Type.class, Class.class, Class.class);
                                            getSupertypeMethod.setAccessible(true);
                                            
                                            // Expect exception
                                            thrown.expect(IllegalArgumentException.class);
                                            
                                            // Test
                                            getSupertypeMethod.invoke(null, context, contextRawType, supertype);
                                        }

    @Test
                                        public void testGetSupertype_WithNullContext_ThrowsNullPointerException() throws Exception {
                                            // Setup
                                            Class<?> contextRawType = Object.class;
                                            Class<?> supertype = Object.class;
                                            
                                            // Get the private method via reflection
                                            Class<?> typesClass = Class.forName("com.google.gson.internal.$Gson$Types");
                                            Method getSupertypeMethod = typesClass.getDeclaredMethod("getSupertype", 
                                                Type.class, Class.class, Class.class);
                                            getSupertypeMethod.setAccessible(true);
                                            
                                            // Expect exception
                                            thrown.expect(NullPointerException.class);
                                            
                                            // Test
                                            getSupertypeMethod.invoke(null, null, contextRawType, supertype);
                                        }

    @Test
                                        public void testGetSupertype_WithNullContextRawType_ThrowsNullPointerException() throws Exception {
                                            // Setup
                                            Type context = mock(Type.class);
                                            Class<?> supertype = Object.class;
                                            
                                            // Get the private method via reflection
                                            Class<?> typesClass = Class.forName("com.google.gson.internal.$Gson$Types");
                                            Method getSupertypeMethod = typesClass.getDeclaredMethod("getSupertype", Type.class, Class.class, Class.class);
                                            getSupertypeMethod.setAccessible(true);
                                            
                                            // Expect exception
                                            thrown.expect(NullPointerException.class);
                                            
                                            // Test
                                            getSupertypeMethod.invoke(null, context, null, supertype);
                                        }

    @Test
                                        public void testGetSupertype_WithNullSupertype_ThrowsNullPointerException() throws Exception {
                                            // Setup
                                            Type context = mock(Type.class);
                                            Class<?> contextRawType = Object.class;
                                            
                                            // Get the private method via reflection
                                            Method getSupertypeMethod = $Gson$Types.class.getDeclaredMethod(
                                                "getSupertype", Type.class, Class.class, Class.class);
                                            getSupertypeMethod.setAccessible(true);
                                            
                                            // Expect exception
                                            thrown.expect(NullPointerException.class);
                                            
                                            // Test
                                            getSupertypeMethod.invoke(null, context, contextRawType, null);
                                        }


}
