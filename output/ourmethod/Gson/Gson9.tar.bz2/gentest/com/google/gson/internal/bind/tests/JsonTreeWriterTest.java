package gentest.com.google.gson.internal.bind.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.internal.bind.*;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
 
public class JsonTreeWriterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                        public void testValue_AfterClose_ThrowsIllegalStateException() throws Exception {
                                                                                            // Arrange
                                                                                            JsonTreeWriter writer = new JsonTreeWriter();
                                                                                            writer.close();
                                                                                            
                                                                                            // Expect exception
                                                                                            thrown.expect(IllegalStateException.class);
                                                                                            
                                                                                            // Act
                                                                                            writer.value(true);
                                                                                        }

    @Test
                                                                                        public void testValue_AfterBeginObjectWithoutName_ThrowsIllegalStateException() {
                                                                                            // Arrange
                                                                                            JsonTreeWriter writer = new JsonTreeWriter();
                                                                                            
                                                                                            // Expect exception
                                                                                            thrown.expect(IllegalStateException.class);
                                                                                            
                                                                                            // Act
                                                                                        }

    @Test
                                                                                public void testValue_Boolean_True() throws Exception {
                                                                                    JsonTreeWriter writer = new JsonTreeWriter();
                                                                                    JsonWriter result = writer.value(true);
                                                                                    
                                                                                    // Verify method chaining
                                                                                    assertSame(writer, result);
                                                                                    
                                                                                    // Verify the stack contains the boolean value using reflection to access private peek()
                                                                                    Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                                                                                    peekMethod.setAccessible(true);
                                                                                    JsonElement topElement = (JsonElement) peekMethod.invoke(writer);
                                                                                    
                                                                                    assertTrue(topElement instanceof JsonPrimitive);
                                                                                    assertTrue(topElement.getAsBoolean());
                                                                                }

    @Test
                                                                                public void testValue_Boolean_False() {
                                                                                    JsonTreeWriter writer = new JsonTreeWriter();
                                                                                    
                                                                                    // Verify method chaining
                                                                                    
                                                                                    // Verify the stack contains the boolean value
                                                                                    // Need to use reflection to access private peek() method
                                                                                    try {
                                                                                        Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                                                                                        peekMethod.setAccessible(true);
                                                                                        JsonElement topElement = (JsonElement) peekMethod.invoke(writer);
                                                                                        
                                                                                        assertTrue(topElement instanceof JsonPrimitive);
                                                                                        assertFalse(topElement.getAsBoolean());
                                                                                    } catch (Exception e) {
                                                                                        fail("Failed to access private peek method: " + e.getMessage());
                                                                                    }
                                                                                }

    @Test
                                                                                public void testValue_Boolean_VerifyPutCalled() {
                                                                                    JsonTreeWriter writer = new JsonTreeWriter();
                                                                                    JsonTreeWriter spyWriter = spy(writer);
                                                                                    
                                                                                    Boolean testValue = true;
                                                                                    
                                                                                    // Verify the end result by checking the tree content
                                                                                    JsonElement result = spyWriter.get();
                                                                                    assertTrue(result instanceof JsonPrimitive);
                                                                                    assertEquals(testValue, ((JsonPrimitive)result).getAsBoolean());
                                                                                }

    @Test
                                                                                public void testValue_Boolean_WithPendingName() throws Exception {
                                                                                    JsonTreeWriter writer = new JsonTreeWriter();
                                                                                    writer.name("testName");
                                                                                    writer.value(true);
                                                                                    
                                                                                    // Use reflection to access private pendingName field
                                                                                    Field pendingNameField = JsonTreeWriter.class.getDeclaredField("pendingName");
                                                                                    pendingNameField.setAccessible(true);
                                                                                    Object pendingNameValue = pendingNameField.get(writer);
                                                                                    
                                                                                    // Verify the name was consumed
                                                                                    assertNull(pendingNameValue);
                                                                                    
                                                                                    // Use reflection to access private peek() method
                                                                                    Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                                                                                    peekMethod.setAccessible(true);
                                                                                    JsonElement topElement = (JsonElement) peekMethod.invoke(writer);
                                                                                    
                                                                                    // Verify the stack contains our value
                                                                                    assertTrue(topElement instanceof JsonPrimitive);
                                                                                    assertTrue(topElement.getAsBoolean());
                                                                                }

    @Test
                                                                                public void testValueBoolean_WhenClosed() {
                                                                                    JsonTreeWriter writer = new JsonTreeWriter();
                                                                                    ExpectedException thrown = ExpectedException.none();
                                                                                    
                                                                                    
                                                                                    thrown.expect(IllegalStateException.class);
                                                                                }

    @Test
                                                                                public void testValueBoolean_MultipleValues() {
                                                                                    JsonTreeWriter writer = new JsonTreeWriter();
                                                                                    
                                                                                    try {
                                                                                        // Use reflection to access private peek() method
                                                                                        Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                                                                                        peekMethod.setAccessible(true);
                                                                                        JsonArray array = (JsonArray) peekMethod.invoke(writer);
                                                                                        
                                                                                        // Use reflection to access private stack field
                                                                                        Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                                                                                        stackField.setAccessible(true);
                                                                                        List<?> stack = (List<?>) stackField.get(writer);
                                                                                        
                                                                                        assertEquals(1, stack.size()); // Only array should be on stack
                                                                                        assertEquals(2, array.size());
                                                                                        assertEquals(new JsonPrimitive(true), array.get(0));
                                                                                        assertEquals(new JsonPrimitive(false), array.get(1));
                                                                                    } catch (Exception e) {
                                                                                        fail("Reflection failed: " + e.getMessage());
                                                                                    }
                                                                                }

    @Test
                                                                                public void testValue_AfterBeginArray_PutsValueInArray() {
                                                                                    // Arrange
                                                                                    JsonTreeWriter writer = new JsonTreeWriter();
                                                                                    
                                                                                    // Act
                                                                                    
                                                                                    // Assert
                                                                                    // Verify the stack contains the array with our boolean value
                                                                                    try {
                                                                                        Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                                                                                        peekMethod.setAccessible(true);
                                                                                        JsonElement topElement = (JsonElement) peekMethod.invoke(writer);
                                                                                        assertTrue(topElement.toString().contains("true"));
                                                                                    } catch (Exception e) {
                                                                                        fail("Reflection failed: " + e.getMessage());
                                                                                    }
                                                                                }

    @Test
                                                                                public void testValueDouble_NaNValueInStrictMode() {
                                                                                    // Default is strict mode (not lenient)
                                                                                    ExpectedException thrown = ExpectedException.none();
                                                                                    thrown.expect(IllegalArgumentException.class);
                                                                                    thrown.expectMessage("JSON forbids NaN and infinities: NaN");
                                                                                    
                                                                                    JsonTreeWriter writer = new JsonTreeWriter();
                                                                                }

    @Test
                                                                                public void testValueDouble_PositiveInfinityInStrictMode() {
                                                                                    JsonTreeWriter writer = new JsonTreeWriter();
                                                                                    ExpectedException thrown = ExpectedException.none();
                                                                                    
                                                                                    thrown.expect(IllegalArgumentException.class);
                                                                                    thrown.expectMessage("JSON forbids NaN and infinities: Infinity");
                                                                                    
                                                                                }

    @Test
                                                                                public void testValueDouble_NegativeInfinityInStrictMode() {
                                                                                    JsonTreeWriter writer = new JsonTreeWriter();
                                                                                    ExpectedException thrown = ExpectedException.none();
                                                                                    
                                                                                    thrown.expect(IllegalArgumentException.class);
                                                                                    thrown.expectMessage("JSON forbids NaN and infinities: -Infinity");
                                                                                    
                                                                                }

    @Test
                                                                                public void testValueDouble_AfterName() {
                                                                                    JsonTreeWriter writer = new JsonTreeWriter();
                                                                                    
                                                                                    // Verify the value was properly associated with the name
                                                                                    // This would require additional verification of the complete JSON structure
                                                                                }

    @Test
                                                                                public void testValueBoolean_ThrowsWhenClosed() {
                                                                                    JsonTreeWriter writer = new JsonTreeWriter();
                                                                                    ExpectedException thrown = ExpectedException.none();
                                                                                    
                                                                                    
                                                                                    thrown.expect(IllegalStateException.class);
                                                                                }

    @Test
                                                                                public void testValueBoolean_ThrowsWhenNoPendingNameInObject() {
                                                                                    JsonTreeWriter writer = new JsonTreeWriter();
                                                                                    
                                                                                    thrown.expect(IllegalStateException.class);
                                                                                }

    @Test
                                                                            public void testValue_NullInput_ReturnsNullValue() {
                                                                                // Arrange
                                                                                JsonTreeWriter writer = new JsonTreeWriter();
                                                                                JsonTreeWriter spyWriter = spy(writer);
                                                                                
                                                                                // Act
                                                                                
                                                                                // Assert
                                                                            }

    @Test
                                                                            public void testValue_NotLenientWithNaN_ThrowsIllegalArgumentException() {
                                                                                // Arrange
                                                                                JsonTreeWriter writer = new JsonTreeWriter();
                                                                                Number nanValue = Double.NaN;
                                                                                
                                                                                // We need to define the expected exception rule
                                                                                ExpectedException thrown = ExpectedException.none();
                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                thrown.expectMessage("JSON forbids NaN and infinities: NaN");
                                                                                
                                                                                // Act & Assert
                                                                            }

    @Test
                                                                            public void testValue_NotLenientWithPositiveInfinity_ThrowsIllegalArgumentException() {
                                                                                // Arrange
                                                                                JsonTreeWriter writer = new JsonTreeWriter();
                                                                                Number infinityValue = Double.POSITIVE_INFINITY;
                                                                                ExpectedException thrown = ExpectedException.none();
                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                thrown.expectMessage("JSON forbids NaN and infinities: Infinity");
                                                                                
                                                                                // Act & Assert
                                                                            }

    @Test
                                                                            public void testValue_NotLenientWithNegativeInfinity_ThrowsIllegalArgumentException() {
                                                                                // Arrange
                                                                                JsonTreeWriter writer = new JsonTreeWriter();
                                                                                Number infinityValue = Double.NEGATIVE_INFINITY;
                                                                                ExpectedException thrown = ExpectedException.none();
                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                thrown.expectMessage("JSON forbids NaN and infinities: -Infinity");
                                                                                
                                                                                // Act & Assert
                                                                            }

    @Test
                                                                            public void testValue_LenientWithNaN_DoesNotThrow() {
                                                                                // Arrange
                                                                                JsonTreeWriter lenientWriter = new JsonTreeWriter();
                                                                                lenientWriter.setLenient(true);
                                                                                Number nanValue = Double.NaN;
                                                                                
                                                                                // Act
                                                                                
                                                                                // Assert
                                                                                try {
                                                                                    Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                                                                                    peekMethod.setAccessible(true);
                                                                                    JsonElement topElement = (JsonElement) peekMethod.invoke(lenientWriter);
                                                                                    assertTrue(topElement instanceof JsonPrimitive);
                                                                                    assertTrue(Double.isNaN(((JsonPrimitive)topElement).getAsDouble()));
                                                                                } catch (Exception e) {
                                                                                    fail("Reflection failed: " + e.getMessage());
                                                                                }
                                                                            }

    @Test
                                                                            public void testValue_LenientWithInfinity_DoesNotThrow() throws Exception {
                                                                                // Arrange
                                                                                JsonTreeWriter lenientWriter = new JsonTreeWriter();
                                                                                lenientWriter.setLenient(true);
                                                                                Number infinityValue = Double.POSITIVE_INFINITY;
                                                                                
                                                                                // Act
                                                                                JsonWriter result = lenientWriter.value(infinityValue);
                                                                                
                                                                                // Assert
                                                                                assertEquals(lenientWriter, result);
                                                                                
                                                                                // Use reflection to access private peek() method
                                                                                Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                                                                                peekMethod.setAccessible(true);
                                                                                JsonElement topElement = (JsonElement) peekMethod.invoke(lenientWriter);
                                                                                
                                                                                assertTrue(topElement instanceof JsonPrimitive);
                                                                                assertTrue(Double.isInfinite(((JsonPrimitive)topElement).getAsDouble()));
                                                                            }

    @Test
                                                                            public void testValue_Boolean_NullInput() {
                                                                                JsonTreeWriter writer = new JsonTreeWriter();
                                                                                JsonTreeWriter spyWriter = spy(writer);
                                                                                
                                                                                // Call method with null
                                                                                
                                                                                // Verify nullValue() was called
                                                                                // Verify method chaining
                                                                            }

    @Test
                                                                            public void testValueBoolean_TrueValue() throws Exception {
                                                                                JsonTreeWriter writer = new JsonTreeWriter();
                                                                                JsonWriter result = writer.value(true);
                                                                                
                                                                                assertSame(writer, result); // Should return this
                                                                                
                                                                                // Access private stack field via reflection
                                                                                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                                                                                stackField.setAccessible(true);
                                                                                List<?> stack = (List<?>) stackField.get(writer);
                                                                                assertEquals(1, stack.size());
                                                                                
                                                                                // Access private peek method via reflection
                                                                                Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                                                                                peekMethod.setAccessible(true);
                                                                                JsonElement actual = (JsonElement) peekMethod.invoke(writer);
                                                                                
                                                                                JsonPrimitive expected = new JsonPrimitive(true);
                                                                                assertEquals(expected, actual);
                                                                            }

    @Test
                                                                            public void testValueBoolean_FalseValue() throws Exception {
                                                                                JsonTreeWriter writer = new JsonTreeWriter();
                                                                                JsonWriter result = writer.value(false);
                                                                                
                                                                                assertSame(writer, result); // Should return this
                                                                                
                                                                                // Use reflection to access private methods/fields
                                                                                Class<?> writerClass = JsonTreeWriter.class;
                                                                                java.lang.reflect.Field stackField = writerClass.getDeclaredField("stack");
                                                                                stackField.setAccessible(true);
                                                                                java.util.List<?> stack = (java.util.List<?>) stackField.get(writer);
                                                                                assertEquals(1, stack.size());
                                                                                
                                                                                java.lang.reflect.Method peekMethod = writerClass.getDeclaredMethod("peek");
                                                                                peekMethod.setAccessible(true);
                                                                                JsonElement actual = (JsonElement) peekMethod.invoke(writer);
                                                                                
                                                                                JsonPrimitive expected = new JsonPrimitive(false);
                                                                                assertEquals(expected, actual);
                                                                            }

    @Test
                                                                            public void testValueBoolean_AfterBeginArray() throws Exception {
                                                                                JsonTreeWriter writer = new JsonTreeWriter();
                                                                                writer.beginArray();
                                                                                JsonWriter result = writer.value(true);
                                                                                
                                                                                assertSame(writer, result);
                                                                                
                                                                                // Access private stack field using reflection
                                                                                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                                                                                stackField.setAccessible(true);
                                                                                List<?> stack = (List<?>) stackField.get(writer);
                                                                                assertEquals(1, stack.size()); // Array should contain one element
                                                                                
                                                                                // Access private peek method using reflection
                                                                                Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                                                                                peekMethod.setAccessible(true);
                                                                                JsonArray array = (JsonArray) peekMethod.invoke(writer);
                                                                                assertEquals(1, array.size());
                                                                                assertEquals(new JsonPrimitive(true), array.get(0));
                                                                            }

    @Test
                                                                            public void testValueBoolean_WithoutContext() throws Exception {
                                                                                JsonTreeWriter writer = new JsonTreeWriter();
                                                                                JsonWriter result = writer.value(true);
                                                                                
                                                                                assertSame(writer, result);
                                                                                
                                                                                // Access private stack field via reflection
                                                                                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                                                                                stackField.setAccessible(true);
                                                                                List<?> stack = (List<?>) stackField.get(writer);
                                                                                assertEquals(1, stack.size());
                                                                                
                                                                                // Access private peek() method via reflection
                                                                                Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                                                                                peekMethod.setAccessible(true);
                                                                                JsonElement peekValue = (JsonElement) peekMethod.invoke(writer);
                                                                                assertEquals(new JsonPrimitive(true), peekValue);
                                                                                
                                                                                // Verify this becomes the final product
                                                                                assertEquals(new JsonPrimitive(true), writer.get());
                                                                            }

    @Test
                                                                            public void testValueDouble_ValidFiniteValue() throws Exception {
                                                                                JsonTreeWriter writer = new JsonTreeWriter();
                                                                                JsonWriter result = writer.value(3.14);
                                                                                
                                                                                assertSame(writer, result); // Should return this
                                                                                
                                                                                // Use reflection to access private peek() method
                                                                                Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                                                                                peekMethod.setAccessible(true);
                                                                                JsonElement element = (JsonElement) peekMethod.invoke(writer);
                                                                                
                                                                                assertTrue(element instanceof JsonPrimitive);
                                                                                assertEquals(3.14, element.getAsDouble(), 0.0001);
                                                                            }

    @Test
                                                                            public void testValueDouble_ZeroValue() throws Exception {
                                                                                JsonTreeWriter writer = new JsonTreeWriter();
                                                                                JsonWriter result = writer.value(0.0);
                                                                                
                                                                                assertSame(writer, result);
                                                                                
                                                                                // Use reflection to access private peek() method
                                                                                Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                                                                                peekMethod.setAccessible(true);
                                                                                JsonElement element = (JsonElement) peekMethod.invoke(writer);
                                                                                
                                                                                assertEquals(0.0, element.getAsDouble(), 0.0001);
                                                                            }

    @Test
                                                                            public void testValueDouble_NegativeValue() throws Exception {
                                                                                JsonTreeWriter writer = new JsonTreeWriter();
                                                                                JsonWriter result = writer.value(-123.456);
                                                                                
                                                                                assertSame(writer, result);
                                                                                
                                                                                // Use reflection to access private peek() method
                                                                                Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                                                                                peekMethod.setAccessible(true);
                                                                                JsonElement element = (JsonElement) peekMethod.invoke(writer);
                                                                                
                                                                                assertEquals(-123.456, element.getAsDouble(), 0.0001);
                                                                            }

    @Test
                                                                            public void testValueDouble_NaNValueInLenientMode() throws Exception {
                                                                                JsonTreeWriter writer = new JsonTreeWriter();
                                                                                writer.setLenient(true);
                                                                                JsonWriter result = writer.value(Double.NaN);
                                                                                
                                                                                assertSame(writer, result);
                                                                                
                                                                                // Use reflection to access private peek() method
                                                                                Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                                                                                peekMethod.setAccessible(true);
                                                                                JsonElement element = (JsonElement) peekMethod.invoke(writer);
                                                                                
                                                                                assertTrue(Double.isNaN(element.getAsDouble()));
                                                                            }

    @Test
                                                                            public void testValueDouble_InfinityValueInLenientMode() throws Exception {
                                                                                JsonTreeWriter writer = new JsonTreeWriter();
                                                                                writer.setLenient(true);
                                                                                JsonWriter result = writer.value(Double.POSITIVE_INFINITY);
                                                                                
                                                                                assertSame(writer, result);
                                                                                
                                                                                // Use reflection to access private peek() method
                                                                                Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                                                                                peekMethod.setAccessible(true);
                                                                                JsonElement element = (JsonElement) peekMethod.invoke(writer);
                                                                                
                                                                                assertTrue(Double.isInfinite(element.getAsDouble()));
                                                                            }

    @Test
                                                                            public void testValueDouble_MaxDoubleValue() throws Exception {
                                                                                JsonTreeWriter writer = new JsonTreeWriter();
                                                                                JsonWriter result = writer.value(Double.MAX_VALUE);
                                                                                
                                                                                assertSame(writer, result);
                                                                                
                                                                                // Access private peek() method using reflection
                                                                                Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                                                                                peekMethod.setAccessible(true);
                                                                                JsonElement element = (JsonElement) peekMethod.invoke(writer);
                                                                                
                                                                                assertEquals(Double.MAX_VALUE, element.getAsDouble(), 0.0);
                                                                            }

    @Test
                                                                            public void testValueDouble_MinDoubleValue() throws Exception {
                                                                                JsonTreeWriter writer = new JsonTreeWriter();
                                                                                JsonWriter result = writer.value(Double.MIN_VALUE);
                                                                                
                                                                                assertSame(writer, result);
                                                                                
                                                                                // Use reflection to access private peek() method
                                                                                Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                                                                                peekMethod.setAccessible(true);
                                                                                JsonElement element = (JsonElement) peekMethod.invoke(writer);
                                                                                
                                                                                assertEquals(Double.MIN_VALUE, element.getAsDouble(), 0.0);
                                                                            }

    @Test
                                                                            public void testValueBoolean_AddsTruePrimitive() {
                                                                                JsonTreeWriter writer = new JsonTreeWriter();
                                                                                
                                                                                
                                                                                // Access private stack field using reflection
                                                                                try {
                                                                                    Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                                                                                    stackField.setAccessible(true);
                                                                                    List<?> stack = (List<?>) stackField.get(writer);
                                                                                    
                                                                                    assertEquals(1, stack.size());
                                                                                    JsonPrimitive primitive = (JsonPrimitive) stack.get(0);
                                                                                    assertTrue(primitive.getAsBoolean());
                                                                                } catch (Exception e) {
                                                                                    fail("Reflection failed: " + e.getMessage());
                                                                                }
                                                                            }

    @Test
                                                                            public void testValueBoolean_AddsFalsePrimitive() throws Exception {
                                                                                JsonTreeWriter writer = new JsonTreeWriter();
                                                                                JsonTreeWriter result = (JsonTreeWriter) writer.value(false);
                                                                                
                                                                                assertSame(writer, result); // Should return this
                                                                                
                                                                                // Access private stack field via reflection
                                                                                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                                                                                stackField.setAccessible(true);
                                                                                @SuppressWarnings("unchecked")
                                                                                List<JsonElement> stack = (List<JsonElement>) stackField.get(writer);
                                                                                
                                                                                assertEquals(1, stack.size());
                                                                                JsonPrimitive primitive = (JsonPrimitive) stack.get(0);
                                                                                assertFalse(primitive.getAsBoolean());
                                                                            }

    @Test
                                                                            public void testValueBoolean_AddsToExistingStructure() throws Exception {
                                                                                JsonTreeWriter writer = new JsonTreeWriter();
                                                                                
                                                                                // Start an array
                                                                                writer.beginArray();
                                                                                JsonWriter result = writer.value(true);
                                                                                
                                                                                assertSame(writer, result);
                                                                                
                                                                                // Access private stack field via reflection
                                                                                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                                                                                stackField.setAccessible(true);
                                                                                List<?> stack = (List<?>) stackField.get(writer);
                                                                                assertEquals(1, stack.size()); // The array
                                                                                
                                                                                // Access private peek() method via reflection
                                                                                Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                                                                                peekMethod.setAccessible(true);
                                                                                JsonElement array = (JsonElement) peekMethod.invoke(writer);
                                                                                
                                                                                assertTrue(array.isJsonArray());
                                                                                assertEquals(1, array.getAsJsonArray().size());
                                                                                assertTrue(array.getAsJsonArray().get(0).getAsBoolean());
                                                                            }

    @Test
                                                                            public void testValueBoolean_AddsToObjectWithPendingName() {
                                                                                // Initialize JsonTreeWriter
                                                                                JsonTreeWriter writer = new JsonTreeWriter();
                                                                                
                                                                                // Start an object and set a name
                                                                                
                                                                                
                                                                                // Access stack using reflection since it's likely private
                                                                                try {
                                                                                    Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                                                                                    stackField.setAccessible(true);
                                                                                    List<?> stack = (List<?>) stackField.get(writer);
                                                                                    assertEquals(1, stack.size()); // The object
                                                                                    
                                                                                    // Access peek() method using reflection
                                                                                    Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                                                                                    peekMethod.setAccessible(true);
                                                                                    JsonElement object = (JsonElement) peekMethod.invoke(writer);
                                                                                    
                                                                                    assertTrue(object.isJsonObject());
                                                                                    assertTrue(object.getAsJsonObject().get("testFlag").getAsBoolean());
                                                                                    
                                                                                    // Access pendingName field using reflection
                                                                                    Field pendingNameField = JsonTreeWriter.class.getDeclaredField("pendingName");
                                                                                    pendingNameField.setAccessible(true);
                                                                                    assertNull(pendingNameField.get(writer)); // Should clear pending name
                                                                                } catch (Exception e) {
                                                                                    fail("Reflection failed: " + e.getMessage());
                                                                                }
                                                                            }

    @Test
                                                                        public void testValue_NullInput_ReturnsNullValue1() {
                                                                            // Arrange
                                                                            JsonTreeWriter writer = new JsonTreeWriter();
                                                                            JsonTreeWriter spyWriter = spy(writer);
                                                                            
                                                                            // Act
                                                                            
                                                                            // Assert
                                                                        }

    @Test
                                                                        public void testValueBoolean_ChainingMultipleValues() {
                                                                            JsonTreeWriter writer = new JsonTreeWriter();
                                                                            
                                                                            try {
                                                                                Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                                                                                peekMethod.setAccessible(true);
                                                                                JsonElement array = (JsonElement) peekMethod.invoke(writer);
                                                                                
                                                                                assertEquals(2, array.getAsJsonArray().size());
                                                                                assertTrue(array.getAsJsonArray().get(0).getAsBoolean());
                                                                                assertFalse(array.getAsJsonArray().get(1).getAsBoolean());
                                                                            } catch (Exception e) {
                                                                                fail("Failed to access private peek method: " + e.getMessage());
                                                                            }
                                                                        }

    @Test
                                                                        public void testValue_ValidNumber_PutsJsonPrimitive() {
                                                                            // Arrange
                                                                            JsonTreeWriter writer = new JsonTreeWriter();
                                                                            Number testNumber = 42;
                                                                            
                                                                            // Act
                                                                            
                                                                            // Assert
                                                                            // Verify the value was added to the stack
                                                                            try {
                                                                                java.lang.reflect.Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                                                                                stackField.setAccessible(true);
                                                                                java.util.List<JsonElement> stack = (java.util.List<JsonElement>) stackField.get(writer);
                                                                                JsonElement topElement = stack.get(stack.size() - 1);
                                                                                assertTrue(topElement instanceof JsonPrimitive);
                                                                                assertEquals(testNumber.intValue(), ((JsonPrimitive)topElement).getAsInt());
                                                                            } catch (Exception e) {
                                                                                fail("Reflection failed: " + e.getMessage());
                                                                            }
                                                                        }

    @Test
                                                                        public void testValue_Zero_PutsJsonPrimitive() throws Exception {
                                                                            // Arrange
                                                                            JsonTreeWriter writer = new JsonTreeWriter();
                                                                            Number zero = 0;
                                                                            
                                                                            // Act
                                                                            JsonWriter result = writer.value(zero);
                                                                            
                                                                            // Assert
                                                                            assertEquals(writer, result);
                                                                            
                                                                            // Use reflection to access private peek() method
                                                                            Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                                                                            peekMethod.setAccessible(true);
                                                                            JsonElement topElement = (JsonElement) peekMethod.invoke(writer);
                                                                            
                                                                            assertTrue(topElement instanceof JsonPrimitive);
                                                                            assertEquals(0, ((JsonPrimitive)topElement).getAsInt());
                                                                        }

    @Test
                                                                        public void testValue_LargeNumber_PutsJsonPrimitive() {
                                                                            // Arrange
                                                                            JsonTreeWriter writer = new JsonTreeWriter();
                                                                            Number largeNumber = Long.MAX_VALUE;
                                                                            
                                                                            // Act
                                                                            
                                                                            // Assert
                                                                            try {
                                                                                Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                                                                                peekMethod.setAccessible(true);
                                                                                JsonElement topElement = (JsonElement) peekMethod.invoke(writer);
                                                                                assertTrue(topElement instanceof JsonPrimitive);
                                                                                assertEquals(Long.MAX_VALUE, ((JsonPrimitive)topElement).getAsLong());
                                                                            } catch (Exception e) {
                                                                                fail("Reflection failed: " + e.getMessage());
                                                                            }
                                                                        }

    @Test
                                            public void testValueBoolean_AfterNameInObject() throws Exception {
                                                JsonTreeWriter writer = new JsonTreeWriter();
                                                writer.beginObject();
                                                writer.name("test");
                                                JsonWriter result = writer.value(false);
                                                
                                                assertSame(writer, result);
                                                
                                                // Access private stack field using reflection
                                                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                                                stackField.setAccessible(true);
                                                List<?> stack = (List<?>) stackField.get(writer);
                                                assertEquals(1, stack.size()); // Object should be on stack
                                                
                                                // Access private peek method using reflection
                                                Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                                                peekMethod.setAccessible(true);
                                                JsonElement element = (JsonElement) peekMethod.invoke(writer);
                                                JsonObject obj = (JsonObject) element;
                                                
                                                assertEquals(new JsonPrimitive(false), obj.get("test"));
                                            }

    @Test
    public void testValue_TrueBoolean_PutsJsonPrimitive() {
        // Arrange
        com.google.gson.internal.bind.JsonTreeWriter writer = new com.google.gson.internal.bind.JsonTreeWriter();
        org.mockito.ArgumentCaptor<com.google.gson.JsonElement> elementCaptor = 
            org.mockito.ArgumentCaptor.forClass(com.google.gson.JsonElement.class);
        
        // Act
        
        // Assert
        try {
            // Verify put was called with the captured element
            
            com.google.gson.JsonElement capturedElement = elementCaptor.getValue();
            org.junit.Assert.assertTrue(capturedElement instanceof com.google.gson.JsonPrimitive);
            org.junit.Assert.assertTrue(((com.google.gson.JsonPrimitive) capturedElement).getAsBoolean());
        } catch (Exception e) {
            org.junit.Assert.fail("Reflection failed: " + e.getMessage());
        }
    }

    @Test
    public void testValue_FalseBoolean_PutsJsonPrimitive() {
        // Arrange
        com.google.gson.internal.bind.JsonTreeWriter writer = new com.google.gson.internal.bind.JsonTreeWriter();
        
        // Act
        
        // Assert
        try {
            java.lang.reflect.Method putMethod = com.google.gson.internal.bind.JsonTreeWriter.class.getDeclaredMethod("put", com.google.gson.JsonElement.class);
            putMethod.setAccessible(true);
            
            // Verify value(false) was called
            // Capture the argument passed to put()
            org.mockito.ArgumentCaptor<com.google.gson.JsonElement> elementCaptor = org.mockito.ArgumentCaptor.forClass(com.google.gson.JsonElement.class);
            
            // Verify the captured element
            com.google.gson.JsonElement capturedElement = elementCaptor.getValue();
            org.junit.Assert.assertTrue(capturedElement instanceof com.google.gson.JsonPrimitive);
            org.junit.Assert.assertFalse(((com.google.gson.JsonPrimitive) capturedElement).getAsBoolean());
            
        } catch (Exception e) {
            org.junit.Assert.fail("Reflection failed: " + e.getMessage());
        }
    }


}
