package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.SeekableByteChannel;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.Calendar;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.zip.Deflater;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.utils.IOUtils;
 
public class ZipArchiveOutputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test(expected = NullPointerException.class)
                                                                                public void testWriteLocalFileHeaderWithNullEntry() throws Exception {
                                                                                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                    ZipArchiveOutputStream zos = new ZipArchiveOutputStream(bos);
                                                                                    
                                                                                    Method method = ZipArchiveOutputStream.class
                                                                                        .getDeclaredMethod("writeLocalFileHeader", ZipArchiveEntry.class);
                                                                                    method.setAccessible(true);
                                                                                    method.invoke(zos, (ZipArchiveEntry)null);
                                                                                }

    @Test(expected = NullPointerException.class)
                                                                                public void testWriteLocalFileHeaderWithNullEntry1() throws Exception {
                                                                                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                    ZipArchiveOutputStream zos = new ZipArchiveOutputStream(bos);
                                                                                    
                                                                                    Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                        "writeLocalFileHeader", 
                                                                                        ZipArchiveEntry.class, 
                                                                                        boolean.class
                                                                                    );
                                                                                    method.setAccessible(true);
                                                                                    method.invoke(zos, null, false);
                                                                                }

    @Test
                                                                                public void testVersionNeededToExtractWithZip() throws Exception {
                                                                                    ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new java.io.ByteArrayOutputStream());
                                                                                    Method versionNeededToExtractMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                        "versionNeededToExtract", int.class, boolean.class, boolean.class);
                                                                                    versionNeededToExtractMethod.setAccessible(true);
                                                                                    
                                                                                    final int STORED = 0;
                                                                                    final int ZIP64_MIN_VERSION = 45;
                                                                                    
                                                                                    int result = (int) versionNeededToExtractMethod.invoke(zos, 
                                                                                        STORED, true, false);
                                                                                    assertEquals(ZIP64_MIN_VERSION, result);
                                                                                }

    @Test
                                                                                public void testUsesDataDescriptor_WhenPhasedIsTrue_ReturnsFalse() throws Exception {
                                                                                    OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                    ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mockOutputStream);
                                                                                    Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                        "usesDataDescriptor", int.class, boolean.class);
                                                                                    method.setAccessible(true);
                                                                                    
                                                                                    boolean result = (boolean) method.invoke(zos, ZipArchiveOutputStream.DEFLATED, true);
                                                                                    assertFalse(result);
                                                                                }

    @Test
                                                                                public void testUsesDataDescriptor_WhenZipMethodIsNotDeflated_ReturnsFalse() throws Exception {
                                                                                    ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                                                    Method method = ZipArchiveOutputStream.class.getDeclaredMethod("usesDataDescriptor", Integer.TYPE, Boolean.TYPE);
                                                                                    method.setAccessible(true);
                                                                                    
                                                                                    boolean result = (boolean) method.invoke(zos, ZipArchiveOutputStream.STORED, false);
                                                                                    assertFalse(result);
                                                                                }

    @Test
                                                                                public void testUsesDataDescriptor_WhenChannelIsNotNull_ReturnsFalse() throws Exception {
                                                                                    SeekableByteChannel channel = mock(SeekableByteChannel.class);
                                                                                    ZipArchiveOutputStream zos = new ZipArchiveOutputStream(channel);
                                                                                    Method method = ZipArchiveOutputStream.class.getDeclaredMethod("usesDataDescriptor", int.class, boolean.class);
                                                                                    method.setAccessible(true);
                                                                                    
                                                                                    boolean result = (boolean) method.invoke(zos, ZipArchiveOutputStream.DEFLATED, false);
                                                                                    assertFalse(result);
                                                                                }

    @Test
                                                                                public void testUsesDataDescriptor_WhenConditionsMet_ReturnsTrue() throws Exception {
                                                                                    OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                    ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mockOutputStream);
                                                                                    Method method = ZipArchiveOutputStream.class.getDeclaredMethod("usesDataDescriptor", int.class, boolean.class);
                                                                                    method.setAccessible(true);
                                                                                    
                                                                                    boolean result = (boolean) method.invoke(zos, ZipArchiveOutputStream.DEFLATED, false);
                                                                                    assertTrue(result);
                                                                                }

    @Test
                                                                                public void testUsesDataDescriptor_WhenAllConditionsFalse_ReturnsFalse() throws Exception {
                                                                                    SeekableByteChannel channel = mock(SeekableByteChannel.class);
                                                                                    ZipArchiveOutputStream zos = new ZipArchiveOutputStream(channel);
                                                                                    Method method = ZipArchiveOutputStream.class.getDeclaredMethod("usesDataDescriptor", int.class, boolean.class);
                                                                                    method.setAccessible(true);
                                                                                    
                                                                                    boolean result = (boolean) method.invoke(zos, ZipArchiveOutputStream.STORED, true);
                                                                                    assertFalse(result);
                                                                                }

    @Test
                                                                            public void testVersionNeededToExtractMethodWithDeflated() throws Exception {
                                                                                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                                                Method versionNeededToExtractMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "versionNeededToExtract", int.class);
                                                                                versionNeededToExtractMethod.setAccessible(true);
                                                                                
                                                                                int result = (int) versionNeededToExtractMethod.invoke(zos, ZipMethod.DEFLATED.getCode());
                                                                                assertEquals(20, result); // ZipConstants.DEFLATE_MIN_VERSION is 20
                                                                            }

    @Test
                                                                            public void testWriteLocalFileHeaderWithUnicodeName() throws Exception {
                                                                                String unicodeName = "测试.txt"; // Chinese characters
                                                                                ZipArchiveEntry zipEntry = mock(ZipArchiveEntry.class);
                                                                                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(outputStream);
                                                                                
                                                                                when(zipEntry.getName()).thenReturn(unicodeName);
                                                                                when(zipEntry.getMethod()).thenReturn(ZipArchiveEntry.STORED);
                                                                                when(zipEntry.getTime()).thenReturn(System.currentTimeMillis());
                                                                                when(zipEntry.getSize()).thenReturn(75L);
                                                                                when(zipEntry.getCompressedSize()).thenReturn(75L);
                                                                                when(zipEntry.getCrc()).thenReturn(13579L);
                                                                                when(zipEntry.getLocalFileDataExtra()).thenReturn(new byte[0]);
                                                                                
                                                                                // Use reflection to access protected getAlignment method
                                                                                Method getAlignmentMethod = ZipArchiveEntry.class.getDeclaredMethod("getAlignment");
                                                                                getAlignmentMethod.setAccessible(true);
                                                                                when(getAlignmentMethod.invoke(zipEntry)).thenReturn(0);
                                                                                
                                                                                Method method = ZipArchiveOutputStream.class
                                                                                    .getDeclaredMethod("writeLocalFileHeader", ZipArchiveEntry.class);
                                                                                method.setAccessible(true);
                                                                                method.invoke(zos, zipEntry);
                                                                                
                                                                                byte[] output = outputStream.toByteArray();
                                                                                assertTrue(output.length > 0);
                                                                                
                                                                                // Verify filename length field
                                                                                int nameLength = (output[26] & 0xff) | ((output[27] & 0xff) << 8);
                                                                                assertTrue(nameLength > 0);
                                                                            }

    @Test
                                                                            public void testCreateLocalFileHeaderWithDeflatedMethod() throws Exception {
                                                                                ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream((java.io.OutputStream) null);
                                                                                
                                                                                Method createLocalFileHeaderMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "createLocalFileHeader", 
                                                                                    ZipArchiveEntry.class, 
                                                                                    ByteBuffer.class, 
                                                                                    boolean.class, 
                                                                                    boolean.class, 
                                                                                    long.class
                                                                                );
                                                                                createLocalFileHeaderMethod.setAccessible(true);
                                                                            
                                                                                // Use reflection to set alignment since it's protected
                                                                                Method setAlignmentMethod = ZipArchiveEntry.class.getDeclaredMethod("setAlignment", int.class);
                                                                                setAlignmentMethod.setAccessible(true);
                                                                                setAlignmentMethod.invoke(mockEntry, 0);
                                                                                
                                                                                when(mockEntry.getExtraField(ResourceAlignmentExtraField.ID)).thenReturn(null);
                                                                                when(mockEntry.getLocalFileDataExtra()).thenReturn(new byte[0]);
                                                                                when(mockEntry.getMethod()).thenReturn(ZipArchiveEntry.DEFLATED);
                                                                                when(mockEntry.getTime()).thenReturn(System.currentTimeMillis());
                                                                                when(mockEntry.getCrc()).thenReturn(12345L);
                                                                                when(mockEntry.getSize()).thenReturn(100L);
                                                                                when(mockEntry.getCompressedSize()).thenReturn(100L);
                                                                            
                                                                                ByteBuffer name = ByteBuffer.wrap("test.txt".getBytes());
                                                                                byte[] result = (byte[]) createLocalFileHeaderMethod.invoke(zos, 
                                                                                    mockEntry, name, true, false, 0L);
                                                                            
                                                                                assertNotNull(result);
                                                                                assertTrue(result.length > 0);
                                                                            }

    @Test
                                                                            public void testWriteDataDescriptorWithNullEntry() throws Exception {
                                                                                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                                                ZipArchiveEntry entry = null;
                                                                                
                                                                                Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "writeDataDescriptor", ZipArchiveEntry.class);
                                                                                method.setAccessible(true);
                                                                                method.invoke(zos, entry);
                                                                                
                                                                                assertEquals(0, baos.size());
                                                                            }

    @Test
                                                                            public void testVersionNeededToExtractWithDataDescriptor() throws Exception {
                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new java.io.ByteArrayOutputStream());
                                                                                Method versionNeededToExtractMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "versionNeededToExtract", int.class, boolean.class, boolean.class);
                                                                                versionNeededToExtractMethod.setAccessible(true);
                                                                                
                                                                                final int DATA_DESCRIPTOR_MIN_VERSION = 20;
                                                                                final int DEFLATED = 8; // Value from ZipConstants
                                                                                
                                                                                int result = (int) versionNeededToExtractMethod.invoke(zos, 
                                                                                    DEFLATED, false, true);
                                                                                assertEquals(DATA_DESCRIPTOR_MIN_VERSION, result);
                                                                            }

    @Test
                                                                            public void testVersionNeededToExtractWithDeflatedMethod() throws Exception {
                                                                                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                                                Method versionNeededToExtractMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "versionNeededToExtract", int.class, boolean.class, boolean.class);
                                                                                versionNeededToExtractMethod.setAccessible(true);
                                                                                
                                                                                int DEFLATE_MIN_VERSION = 20;
                                                                                int DEFLATED = 8;
                                                                                int result = (int) versionNeededToExtractMethod.invoke(zos, 
                                                                                    DEFLATED, false, false);
                                                                                assertEquals(DEFLATE_MIN_VERSION, result);
                                                                            }

    @Test
                                                                            public void testVersionNeededToExtractWithStoredMethod() throws Exception {
                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
                                                                                Method versionNeededToExtractMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "versionNeededToExtract", int.class, boolean.class, boolean.class);
                                                                                versionNeededToExtractMethod.setAccessible(true);
                                                                                
                                                                                final int INITIAL_VERSION = 10;
                                                                                final int STORED = 0;
                                                                                
                                                                                int result = (int) versionNeededToExtractMethod.invoke(zos, STORED, false, false);
                                                                                assertEquals(INITIAL_VERSION, result);
                                                                            }

    @Test
                                                                            public void testVersionNeededToExtractZip64TakesPrecedenceOverDataDescriptor() throws Exception {
                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
                                                                                Method versionNeededToExtractMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "versionNeededToExtract", int.class, boolean.class, boolean.class);
                                                                                versionNeededToExtractMethod.setAccessible(true);
                                                                                
                                                                                int DEFLATED = 8;
                                                                                int ZIP64_MIN_VERSION = 45;
                                                                                
                                                                                int result = (int) versionNeededToExtractMethod.invoke(zos, DEFLATED, true, true);
                                                                                assertEquals(ZIP64_MIN_VERSION, result);
                                                                            }

    @Test
                                                                            public void testVersionNeededToExtractDataDescriptorTakesPrecedenceOverMethod() throws Exception {
                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new java.io.ByteArrayOutputStream());
                                                                                Method versionNeededToExtractMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "versionNeededToExtract", int.class, boolean.class, boolean.class);
                                                                                versionNeededToExtractMethod.setAccessible(true);
                                                                                
                                                                                int DEFLATED = 8;
                                                                                int DATA_DESCRIPTOR_MIN_VERSION = 20;
                                                                                
                                                                                int result = (int) versionNeededToExtractMethod.invoke(zos, DEFLATED, false, true);
                                                                                assertEquals(DATA_DESCRIPTOR_MIN_VERSION, result);
                                                                            }

    @Test
                                                                    public void testVersionNeededToExtractMethodWithStored() throws Exception {
                                                                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                                        Method versionNeededToExtractMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                            "versionNeededToExtract", int.class);
                                                                        versionNeededToExtractMethod.setAccessible(true);
                                                                        
                                                                        int stored = 0; // STORED is 0 in ZipArchiveOutputStream
                                                                        int result = (int) versionNeededToExtractMethod.invoke(zos, stored);
                                                                        assertEquals(10, result); // INITIAL_VERSION is 10 in ZipConstants
                                                                    }

    @Test
                                                                    public void testVersionNeededToExtractMethodWithUnknownMethod() throws Exception {
                                                                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                                        Method versionNeededToExtractMethod = ZipArchiveOutputStream.class.getDeclaredMethod("versionNeededToExtract", int.class);
                                                                        versionNeededToExtractMethod.setAccessible(true);
                                                                        
                                                                        int result = (int) versionNeededToExtractMethod.invoke(zos, 999); // Unknown method
                                                                        assertEquals(10, result); // INITIAL_VERSION is 10
                                                                    }

    @Test
                                                                    public void testVersionNeededToExtractMethodWithZero() throws Exception {
                                                                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                                        Method versionNeededToExtractMethod = ZipArchiveOutputStream.class.getDeclaredMethod("versionNeededToExtract", int.class);
                                                                        versionNeededToExtractMethod.setAccessible(true);
                                                                        
                                                                        int result = (int) versionNeededToExtractMethod.invoke(zos, 0);
                                                                        assertEquals(10, result); // ZipConstants.INITIAL_VERSION is 10
                                                                    }

    @Test
                                                                    public void testVersionNeededToExtractMethodWithNegativeValue() throws Exception {
                                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
                                                                        Method versionNeededToExtractMethod = ZipArchiveOutputStream.class.getDeclaredMethod("versionNeededToExtract", int.class);
                                                                        versionNeededToExtractMethod.setAccessible(true);
                                                                        
                                                                        int result = (int) versionNeededToExtractMethod.invoke(zos, -1);
                                                                        assertEquals(10, result); // INITIAL_VERSION is 10
                                                                    }

    @Test
                                                                public void testWriteLocalFileHeaderWithUnicodeExtraFieldsNever() throws Exception {
                                                                    // Create mock StreamCompressor using reflection since it's not public
                                                                    Class<?> streamCompressorClass = Class.forName("org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream$StreamCompressor");
                                                                    Object streamCompressor = mock(streamCompressorClass);
                                                                    
                                                                    ZipEncoding zipEncoding = mock(ZipEncoding.class);
                                                                    
                                                                    // Create ZipArchiveOutputStream using reflection to access non-public constructor
                                                                    Constructor<?> constructor = ZipArchiveOutputStream.class.getDeclaredConstructor(streamCompressorClass, ZipEncoding.class);
                                                                    constructor.setAccessible(true);
                                                                    ZipArchiveOutputStream zos = (ZipArchiveOutputStream) constructor.newInstance(streamCompressor, zipEncoding);
                                                                    
                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                    entry.setMethod(ZipArchiveEntry.STORED);
                                                                    entry.setSize(100);
                                                                    entry.setCompressedSize(100);
                                                                    entry.setCrc(12345L);
                                                                    
                                                                    when(zipEncoding.canEncode("test.txt")).thenReturn(true);
                                                                    when(streamCompressorClass.getMethod("getTotalBytesWritten").invoke(streamCompressor)).thenReturn(0L);
                                                                    
                                                                    // Set createUnicodeExtraFields to NEVER
                                                                    Field unicodeField = ZipArchiveOutputStream.class.getDeclaredField("createUnicodeExtraFields");
                                                                    unicodeField.setAccessible(true);
                                                                    Class<?> unicodeExtraFieldPolicyClass = Class.forName("org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream$UnicodeExtraFieldPolicy");
                                                                    Object neverPolicy = Enum.valueOf((Class<Enum>) unicodeExtraFieldPolicyClass, "NEVER");
                                                                    unicodeField.set(zos, neverPolicy);
                                                                    
                                                                    Method writeLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod("writeLocalFileHeader", 
                                                                        ZipArchiveEntry.class, boolean.class);
                                                                    writeLocalFileHeader.setAccessible(true);
                                                                    writeLocalFileHeader.invoke(zos, entry, false);
                                                                    
                                                                    verify(streamCompressor, atLeastOnce()).getClass().getMethod("getTotalBytesWritten").invoke(streamCompressor);
                                                                    verify(streamCompressor, atLeastOnce()).getClass().getMethod("writeCounted", byte[].class).invoke(streamCompressor, any(byte[].class));
                                                                }

    @Test
                                                            public void testWriteLocalFileHeaderWithExtraData() throws Exception {
                                                                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(outputStream);
                                                                ZipArchiveEntry zipEntry = mock(ZipArchiveEntry.class);
                                                                
                                                                byte[] extraData = new byte[] {0x01, 0x02, 0x03, 0x04};
                                                                
                                                                when(zipEntry.getName()).thenReturn("extra.txt");
                                                                when(zipEntry.getMethod()).thenReturn(ZipArchiveEntry.STORED);
                                                                when(zipEntry.getTime()).thenReturn(System.currentTimeMillis());
                                                                when(zipEntry.getSize()).thenReturn(50L);
                                                                when(zipEntry.getCompressedSize()).thenReturn(50L);
                                                                when(zipEntry.getCrc()).thenReturn(98765L);
                                                                when(zipEntry.getLocalFileDataExtra()).thenReturn(extraData);
                                                                
                                                                // Use reflection to access protected getAlignment() method
                                                                java.lang.reflect.Method getAlignmentMethod = ZipArchiveEntry.class
                                                                    .getDeclaredMethod("getAlignment");
                                                                getAlignmentMethod.setAccessible(true);
                                                                when(getAlignmentMethod.invoke(zipEntry)).thenReturn(0);
                                                                
                                                                java.lang.reflect.Method method = ZipArchiveOutputStream.class
                                                                    .getDeclaredMethod("writeLocalFileHeader", ZipArchiveEntry.class);
                                                                method.setAccessible(true);
                                                                method.invoke(zos, zipEntry);
                                                                
                                                                byte[] output = outputStream.toByteArray();
                                                                assertTrue(output.length > 30 + "extra.txt".length() + extraData.length);
                                                                
                                                                // Verify extra data length field
                                                                int extraLength = (output[28] & 0xff) | ((output[29] & 0xff) << 8);
                                                                assertEquals(extraData.length, extraLength);
                                                            }

    @Test
                                                            public void testWriteDataDescriptorWithPhasedEntry() throws IOException {
                                                                // Setup test objects
                                                                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                                ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                            
                                                                // Create a mock entry that would normally write a descriptor but is phased
                                                                when(mockEntry.getMethod()).thenReturn(ZipArchiveEntry.DEFLATED);
                                                                when(mockEntry.getGeneralPurposeBit()).thenReturn(new GeneralPurposeBit());
                                                                when(mockEntry.getCrc()).thenReturn(0L);
                                                                when(mockEntry.getCompressedSize()).thenReturn(0L);
                                                                when(mockEntry.getSize()).thenReturn(0L);
                                                            
                                                                // Use reflection to test the private method
                                                                try {
                                                                    Method method = ZipArchiveOutputStream.class
                                                                        .getDeclaredMethod("writeDataDescriptor", ZipArchiveEntry.class, boolean.class);
                                                                    method.setAccessible(true);
                                                                    method.invoke(zos, mockEntry, true); // phased=true
                                                                } catch (Exception e) {
                                                                    fail("Reflection failed: " + e.getMessage());
                                                                }
                                                            
                                                                assertEquals(0, baos.size());
                                                            }

    @Test
                                                public void testWriteLocalFileHeader() throws Exception {
                                                    // Setup mocks and test objects
                                                    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                                                    ZipArchiveOutputStream zos = new ZipArchiveOutputStream(outputStream);
                                                    ZipArchiveEntry zipEntry = mock(ZipArchiveEntry.class);
                                                
                                                    // Setup mock behavior
                                                    when(zipEntry.getName()).thenReturn("test.txt");
                                                    when(zipEntry.getTime()).thenReturn(System.currentTimeMillis());
                                                    when(zipEntry.getSize()).thenReturn(100L);
                                                    when(zipEntry.getCompressedSize()).thenReturn(100L);
                                                    when(zipEntry.getCrc()).thenReturn(12345L);
                                                    when(zipEntry.getLocalFileDataExtra()).thenReturn(new byte[0]);
                                                    
                                                    // Use reflection to access protected getAlignment() method
                                                    Method getAlignmentMethod = ZipArchiveEntry.class.getDeclaredMethod("getAlignment");
                                                    getAlignmentMethod.setAccessible(true);
                                                    when(getAlignmentMethod.invoke(zipEntry)).thenReturn(0);
                                                    
                                                    // Invoke the method via reflection since it's protected
                                                    Method method = ZipArchiveOutputStream.class
                                                        .getDeclaredMethod("writeLocalFileHeader", ZipArchiveEntry.class);
                                                    method.setAccessible(true);
                                                    method.invoke(zos, zipEntry);
                                                    
                                                    // Verify the output contains the local file header signature
                                                    byte[] output = outputStream.toByteArray();
                                                    assertTrue(output.length > 0);
                                                    assertEquals(0x04034b50, 
                                                        (output[0] & 0xff) | ((output[1] & 0xff) << 8) | 
                                                        ((output[2] & 0xff) << 16) | ((output[3] & 0xff) << 24));
                                                }

    @Test
                                                public void testCreateLocalFileHeaderWithZip64Extra() throws Exception {
                                                    // Setup mock objects
                                                    ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                    ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
                                            
                                                    // Get private method via reflection
                                                    Method createLocalFileHeaderMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                        "createLocalFileHeader",
                                                        ZipArchiveEntry.class,
                                                        ByteBuffer.class,
                                                        boolean.class, 
                                                        boolean.class,
                                                        long.class
                                                    );
                                                    createLocalFileHeaderMethod.setAccessible(true);
                                                
                                                    // Create zip64 extra field
                                                    Zip64ExtendedInformationExtraField zip64Extra = new Zip64ExtendedInformationExtraField();
                                                    zip64Extra.setSize(new ZipEightByteInteger(100L));
                                                    zip64Extra.setCompressedSize(new ZipEightByteInteger(100L));
                                                    
                                                    // Mock entry behavior
                                                    when(mockEntry.getTime()).thenReturn(System.currentTimeMillis());
                                                    when(mockEntry.getCrc()).thenReturn(12345L);
                                                    when(mockEntry.getSize()).thenReturn(0xFFFFFFFFL + 1);
                                                    when(mockEntry.getCompressedSize()).thenReturn(0xFFFFFFFFL + 1);
                                                    when(mockEntry.getLocalFileDataExtra()).thenReturn(new byte[0]);
                                                    when(mockEntry.getExtraField(any(ZipShort.class)))
                                                        .thenReturn(zip64Extra);
                                                    
                                                    ByteBuffer name = ByteBuffer.wrap("test.txt".getBytes());
                                                    byte[] result = (byte[]) createLocalFileHeaderMethod.invoke(zos, 
                                                        mockEntry, name, true, false, 0L);
                                                    
                                                    assertNotNull(result);
                                                    assertTrue(result.length > 0);
                                                }

    @Test
                                                public void testWriteLocalFileHeaderWithDifferentCompressionMethods() throws Exception {
                                                    // Setup test objects
                                                    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                                                    ZipArchiveOutputStream zos = new ZipArchiveOutputStream(outputStream);
                                                    ZipArchiveEntry zipEntry = mock(ZipArchiveEntry.class);
                                                    
                                                    // Setup alignment field using reflection since it's protected
                                                    try {
                                                        Field alignmentField = ZipArchiveEntry.class.getDeclaredField("alignment");
                                                        alignmentField.setAccessible(true);
                                                        alignmentField.set(zipEntry, 0);
                                                    } catch (NoSuchFieldException e) {
                                                        // Ignore if field doesn't exist in this version
                                                    }
                                                    
                                                    // Test with DEFLATED method
                                                    when(zipEntry.getName()).thenReturn("deflated.txt");
                                                    when(zipEntry.getTime()).thenReturn(System.currentTimeMillis());
                                                    when(zipEntry.getSize()).thenReturn(200L);
                                                    when(zipEntry.getCompressedSize()).thenReturn(150L);
                                                    when(zipEntry.getCrc()).thenReturn(54321L);
                                                    when(zipEntry.getLocalFileDataExtra()).thenReturn(new byte[0]);
                                                    
                                                    Method method = ZipArchiveOutputStream.class
                                                        .getDeclaredMethod("writeLocalFileHeader", ZipArchiveEntry.class);
                                                    method.setAccessible(true);
                                                    method.invoke(zos, zipEntry);
                                                    
                                                    byte[] output = outputStream.toByteArray();
                                                    assertTrue(output.length > 0);
                                                    int methodByte = (output[8] & 0xff) | ((output[9] & 0xff) << 8);
                                                }

    @Test
                                                public void testWriteLocalFileHeaderWithUnicodeExtraFieldsAlways() throws Exception {
                                                    // Mock dependencies
                                                    ZipEncoding zipEncoding = mock(ZipEncoding.class);
                                                    StreamCompressor streamCompressor = mock(StreamCompressor.class);
                                                    
                                                    // Create test objects
                                                    ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                    Field compressorField = ZipArchiveOutputStream.class.getDeclaredField("compressor");
                                                    compressorField.setAccessible(true);
                                                    compressorField.set(zos, streamCompressor);
                                                    
                                                    Field encodingField = ZipArchiveOutputStream.class.getDeclaredField("zipEncoding");
                                                    encodingField.setAccessible(true);
                                                    encodingField.set(zos, zipEncoding);
                                                    
                                                    ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                    entry.setSize(100);
                                                    entry.setCompressedSize(100);
                                                    entry.setCrc(12345L);
                                                    
                                                    // Mock behavior
                                                    when(zipEncoding.canEncode("test.txt")).thenReturn(true);
                                                    when(streamCompressor.getTotalBytesWritten()).thenReturn(0L);
                                                    
                                                    // Set createUnicodeExtraFields to ALWAYS
                                                    Field field = ZipArchiveOutputStream.class.getDeclaredField("createUnicodeExtraFields");
                                                    field.setAccessible(true);
                                                    field.set(zos, ZipArchiveOutputStream.UnicodeExtraFieldPolicy.ALWAYS);
                                                    
                                                    // Invoke private method
                                                    Method method = ZipArchiveOutputStream.class.getDeclaredMethod("writeLocalFileHeader", 
                                                        ZipArchiveEntry.class, boolean.class);
                                                    method.setAccessible(true);
                                                    method.invoke(zos, entry, false);
                                                    
                                                    // Assert
                                                    assertNotNull(entry.getExtraField(UnicodePathExtraField.UPATH_ID));
                                                }

    @Test
                                                public void testWriteLocalFileHeaderWithNonEncodableName() throws Exception {
                                                    OutputStream out = mock(OutputStream.class);
                                                    ZipArchiveOutputStream zos = new ZipArchiveOutputStream(out);
                                                    ZipEncoding zipEncoding = mock(ZipEncoding.class);
                                                    
                                                    // Create mock StreamCompressor using reflection since it's not directly accessible
                                                    Class<?> streamCompressorClass = Class.forName("org.apache.commons.compress.archivers.zip.StreamCompressor");
                                                    Object streamCompressor = mock(streamCompressorClass);
                                                    
                                                    // Helper method to set private fields
                                                    Field zipEncodingField = ZipArchiveOutputStream.class.getDeclaredField("zipEncoding");
                                                    zipEncodingField.setAccessible(true);
                                                    zipEncodingField.set(zos, zipEncoding);
                                                    
                                                    Field streamCompressorField = ZipArchiveOutputStream.class.getDeclaredField("streamCompressor");
                                                    streamCompressorField.setAccessible(true);
                                                    streamCompressorField.set(zos, streamCompressor);
                                                    
                                                    Field charsetField = ZipArchiveOutputStream.class.getDeclaredField("charset");
                                                    charsetField.setAccessible(true);
                                                    
                                                    ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                    entry.setSize(100);
                                                    entry.setCompressedSize(100);
                                                    entry.setCrc(12345L);
                                                    
                                                    when(zipEncoding.canEncode("test.txt")).thenReturn(false);
                                                    when(zipEncoding.encode("test.txt")).thenReturn(ByteBuffer.wrap("test.txt".getBytes()));
                                                    
                                                    Method getTotalBytesWrittenMethod = streamCompressorClass.getDeclaredMethod("getTotalBytesWritten");
                                                    getTotalBytesWrittenMethod.setAccessible(true);
                                                    when(getTotalBytesWrittenMethod.invoke(streamCompressor)).thenReturn(0L);
                                                    
                                                    // Set fallbackToUTF8 to true
                                                    Field fallbackToUTF8Field = ZipArchiveOutputStream.class.getDeclaredField("fallbackToUTF8");
                                                    fallbackToUTF8Field.setAccessible(true);
                                                    fallbackToUTF8Field.set(zos, true);
                                                    
                                                    Method writeLocalFileHeaderMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                        "writeLocalFileHeader", ZipArchiveEntry.class, boolean.class);
                                                    writeLocalFileHeaderMethod.setAccessible(true);
                                                    writeLocalFileHeaderMethod.invoke(zos, entry, false);
                                                    
                                                    assertNotNull(entry.getExtraField(UnicodePathExtraField.UPATH_ID));
                                                }

    @Test
                                                public void testWriteLocalFileHeaderWithPhasedEntry() throws Exception {
                                                    // Create output stream with dummy output
                                                    OutputStream dummyOut = mock(OutputStream.class);
                                                    ZipArchiveOutputStream zos = new ZipArchiveOutputStream(dummyOut);
                                                    
                                                    ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                    entry.setSize(100);
                                                    entry.setCompressedSize(100);
                                                    entry.setCrc(12345L);
                                                    
                                                    ZipEncoding zipEncoding = mock(ZipEncoding.class);
                                                    Object streamCompressor = mock(zos.getClass().getDeclaredClasses()[0]);
                                                    
                                                    when(zipEncoding.canEncode("test.txt")).thenReturn(true);
                                                    when(streamCompressor.getClass().getMethod("getTotalBytesWritten").invoke(streamCompressor))
                                                        .thenReturn(0L);
                                                    
                                                    // Set mocks via reflection
                                                    Field zipEncodingField = ZipArchiveOutputStream.class.getDeclaredField("zipEncoding");
                                                    zipEncodingField.setAccessible(true);
                                                    zipEncodingField.set(zos, zipEncoding);
                                                    
                                                    Field streamCompressorField = ZipArchiveOutputStream.class.getDeclaredField("streamCompressor");
                                                    streamCompressorField.setAccessible(true);
                                                    streamCompressorField.set(zos, streamCompressor);
                                                    
                                                    Method writeLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                        "writeLocalFileHeader", ZipArchiveEntry.class, boolean.class);
                                                    writeLocalFileHeader.setAccessible(true);
                                                    writeLocalFileHeader.invoke(zos, entry, true);
                                                    
                                                    verify(streamCompressor, atLeastOnce()).getClass().getMethod("writeCounted", byte[].class)
                                                        .invoke(streamCompressor, any(byte[].class));
                                                }

    @Test
                                                public void testCreateLocalFileHeaderWithPhased() throws Exception {
                                                    ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                    ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new java.io.ByteArrayOutputStream());
                                                    
                                                    Method createLocalFileHeaderMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                        "createLocalFileHeader", 
                                                        ZipArchiveEntry.class, 
                                                        ByteBuffer.class,
                                                        boolean.class, 
                                                        boolean.class, 
                                                        long.class
                                                    );
                                                    createLocalFileHeaderMethod.setAccessible(true);
                                                
                                                    // Create a real ZipArchiveEntry to get alignment value
                                                    ZipArchiveEntry realEntry = new ZipArchiveEntry("test");
                                                    Method getAlignmentMethod = ZipArchiveEntry.class.getDeclaredMethod("getAlignment");
                                                    getAlignmentMethod.setAccessible(true);
                                                    int alignment = (int) getAlignmentMethod.invoke(realEntry);
                                                    
                                                    when(mockEntry.getExtraField(any(ZipShort.class))).thenReturn(null);
                                                    when(mockEntry.getLocalFileDataExtra()).thenReturn(new byte[0]);
                                                    when(mockEntry.getTime()).thenReturn(System.currentTimeMillis());
                                                    when(mockEntry.getCrc()).thenReturn(12345L);
                                                    when(mockEntry.getSize()).thenReturn(100L);
                                                    when(mockEntry.getCompressedSize()).thenReturn(100L);
                                                
                                                    ByteBuffer name = ByteBuffer.wrap("test.txt".getBytes());
                                                    byte[] result = (byte[]) createLocalFileHeaderMethod.invoke(zos, 
                                                        mockEntry, name, true, true, 0L);
                                                
                                                    assertNotNull(result);
                                                    assertTrue(result.length > 0);
                                                }

    @Test
                                                public void testWriteDataDescriptorWithDeflatedMethodWithZip() throws Exception {
                                                    // Setup mocks and test objects
                                                    ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                    ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                
                                                    // Mock behaviors
                                                    when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                    when(mockEntry.getCrc()).thenReturn(123456789L);
                                                    when(mockEntry.getCompressedSize()).thenReturn(5000000000L); // > 4GB
                                                    when(mockEntry.getSize()).thenReturn(6000000000L); // > 4GB
                                                
                                                    // Use reflection to access protected method
                                                    Method writeDataDescriptor = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                        "writeDataDescriptor", ZipArchiveEntry.class);
                                                    writeDataDescriptor.setAccessible(true);
                                                    writeDataDescriptor.invoke(zos, mockEntry);
                                                
                                                    // Verify results
                                                    byte[] result = baos.toByteArray();
                                                    assertEquals(28, result.length); // 4 (sig) + 4 (crc) + 8 (compressed) + 8 (size)
                                                
                                                    // Verify signature
                                                    assertEquals(0x50, result[0] & 0xff);
                                                    assertEquals(0x4b, result[1] & 0xff);
                                                    assertEquals(0x07, result[2] & 0xff);
                                                    assertEquals(0x08, result[3] & 0xff);
                                                
                                                    // Verify CRC
                                                    byte[] crcBytes = new byte[4];
                                                    System.arraycopy(result, 4, crcBytes, 0, 4);
                                                    assertEquals(123456789L, ZipLong.getValue(crcBytes));
                                                
                                                    // Verify compressed size (8 bytes)
                                                    byte[] compressedSizeBytes = new byte[8];
                                                    System.arraycopy(result, 8, compressedSizeBytes, 0, 8);
                                                    assertEquals(5000000000L, ZipEightByteInteger.getLongValue(compressedSizeBytes));
                                                
                                                    // Verify size (8 bytes)
                                                    byte[] sizeBytes = new byte[8];
                                                    System.arraycopy(result, 16, sizeBytes, 0, 8);
                                                    assertEquals(6000000000L, ZipEightByteInteger.getLongValue(sizeBytes));
                                                }

    @Test
                                                public void testWriteLocalFileHeaderWithDeflatedMethod() throws Exception {
                                                    OutputStream mockOutputStream = mock(OutputStream.class);
                                                    ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mockOutputStream);
                                                    ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                    entry.setSize(100);
                                                    entry.setCompressedSize(80);
                                                    entry.setCrc(12345L);
                                                    
                                                    // Create mocks
                                                    ZipEncoding zipEncoding = mock(ZipEncoding.class);
                                                    Object streamCompressor = mock(Class.forName("org.apache.commons.compress.archivers.zip.StreamCompressor"));
                                                    
                                                    // Set up mocks using reflection since they're private fields
                                                    Field zipEncodingField = ZipArchiveOutputStream.class.getDeclaredField("zipEncoding");
                                                    zipEncodingField.setAccessible(true);
                                                    zipEncodingField.set(zos, zipEncoding);
                                                    
                                                    Field streamCompressorField = ZipArchiveOutputStream.class.getDeclaredField("streamCompressor");
                                                    streamCompressorField.setAccessible(true);
                                                    streamCompressorField.set(zos, streamCompressor);
                                                    
                                                    when(zipEncoding.canEncode("test.txt")).thenReturn(true);
                                                    when(streamCompressor.getClass().getMethod("getTotalBytesWritten").invoke(streamCompressor)).thenReturn(0L);
                                                    
                                                    Method writeLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                        "writeLocalFileHeader", ZipArchiveEntry.class, boolean.class);
                                                    writeLocalFileHeader.setAccessible(true);
                                                    writeLocalFileHeader.invoke(zos, entry, false);
                                                    
                                                    verify(streamCompressor, atLeastOnce()).getClass().getMethod("writeCounted", byte[].class).invoke(any(byte[].class));
                                                }

    @Test
                                            public void testWriteDataDescriptorWithDeflatedMethodNoZip() throws IOException {
                                                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                
                                                when(mockEntry.getCrc()).thenReturn(123456789L);
                                                when(mockEntry.getCompressedSize()).thenReturn(1000L);
                                                when(mockEntry.getSize()).thenReturn(2000L);
                                                
                                                // Using reflection to access private method
                                                try {
                                                    java.lang.reflect.Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                        "writeDataDescriptor", ZipArchiveEntry.class);
                                                    method.setAccessible(true);
                                                    method.invoke(zos, mockEntry);
                                                } catch (Exception e) {
                                                    throw new RuntimeException(e);
                                                }
                                                
                                                byte[] result = baos.toByteArray();
                                                assertEquals(16, result.length); // 4 (sig) + 4 (crc) + 4 (compressed) + 4 (size)
                                            
                                                // Verify signature
                                                assertEquals(0x50, result[0] & 0xff);
                                                assertEquals(0x4b, result[1] & 0xff);
                                                assertEquals(0x07, result[2] & 0xff);
                                                assertEquals(0x08, result[3] & 0xff);
                                            
                                                // Verify CRC
                                                byte[] crcBytes = new byte[4];
                                                System.arraycopy(result, 4, crcBytes, 0, 4);
                                                assertEquals(123456789L, ZipLong.getValue(crcBytes));
                                            
                                                // Verify compressed size
                                                byte[] compressedSizeBytes = new byte[4];
                                                System.arraycopy(result, 8, compressedSizeBytes, 0, 4);
                                                assertEquals(1000L, ZipLong.getValue(compressedSizeBytes));
                                            
                                                // Verify size
                                                byte[] sizeBytes = new byte[4];
                                                System.arraycopy(result, 12, sizeBytes, 0, 4);
                                                assertEquals(2000L, ZipLong.getValue(sizeBytes));
                                            }

    @Test
                                    public void testCreateLocalFileHeaderWithNonEncodableName() throws Exception {
                                        // Setup mocks and test objects
                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new java.io.ByteArrayOutputStream());
                                        ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                        
                                        // Create a subclass to access protected method
                                        class TestZipArchiveEntry extends ZipArchiveEntry {
                                            public TestZipArchiveEntry(String name) {
                                                super(name);
                                            }
                                            @Override
                                            public int getAlignment() {
                                                return 0;
                                            }
                                        }
                                        ZipArchiveEntry testEntry = new TestZipArchiveEntry("test.txt");
                                        
                                        // Get private method via reflection
                                        Method createLocalFileHeaderMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                            "createLocalFileHeader",
                                            ZipArchiveEntry.class,
                                            ByteBuffer.class,
                                            boolean.class,
                                            boolean.class,
                                            long.class
                                        );
                                        createLocalFileHeaderMethod.setAccessible(true);
                                    
                                        // Mock behaviors
                                        when(mockEntry.getExtraField(any())).thenReturn(null);
                                        when(mockEntry.getLocalFileDataExtra()).thenReturn(new byte[0]);
                                        when(mockEntry.getTime()).thenReturn(System.currentTimeMillis());
                                        when(mockEntry.getCrc()).thenReturn(12345L);
                                        when(mockEntry.getSize()).thenReturn(100L);
                                        when(mockEntry.getCompressedSize()).thenReturn(100L);
                                    
                                        ByteBuffer name = ByteBuffer.wrap("test.txt".getBytes());
                                        byte[] result = (byte[]) createLocalFileHeaderMethod.invoke(
                                            zos, 
                                            testEntry, 
                                            name, 
                                            false, 
                                            false, 
                                            0L
                                        );
                                    
                                        // Assertions
                                        assertNotNull(result);
                                        assertTrue(result.length > 0);
                                    }

    @Test
                                    public void testWriteDataDescriptorWithStoredMethod() throws Exception {
                                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                        ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                        when(mockEntry.getMethod()).thenReturn(ZipArchiveEntry.STORED);
                                        
                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                        Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                                            "writeDataDescriptor", ZipArchiveEntry.class);
                                        method.setAccessible(true);
                                        method.invoke(zos, mockEntry);
                                        
                                        assertEquals(0, baos.size());
                                    }

    @Test
        public void testCreateLocalFileHeaderWithoutAlignment() throws Exception {
            // Create mock objects
            ZipArchiveOutputStream zos = mock(ZipArchiveOutputStream.class);
            ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
            
            // Create a subclass to access protected method
            class TestZipArchiveEntry extends ZipArchiveEntry {
                public TestZipArchiveEntry() {
                    super("test");
                }
                @Override
                public int getAlignment() {
                    return 0;
                }
            }
            TestZipArchiveEntry testEntry = new TestZipArchiveEntry();
            
            // Get private method via reflection
            Method createLocalFileHeaderMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                "createLocalFileHeader",
                ZipArchiveEntry.class,
                ByteBuffer.class, 
                boolean.class, 
                boolean.class, 
                long.class
            );
            createLocalFileHeaderMethod.setAccessible(true);
        
            // Setup mock behavior
            when(mockEntry.getExtraField(ResourceAlignmentExtraField.ID)).thenReturn(null);
            when(mockEntry.getLocalFileDataExtra()).thenReturn(new byte[0]);
            when(mockEntry.getTime()).thenReturn(System.currentTimeMillis());
            when(mockEntry.getCrc()).thenReturn(12345L);
            when(mockEntry.getSize()).thenReturn(100L);
            when(mockEntry.getCompressedSize()).thenReturn(100L);
        
            ByteBuffer name = ByteBuffer.wrap("test.txt".getBytes());
            byte[] result = (byte[]) createLocalFileHeaderMethod.invoke(zos, 
                testEntry, name, true, false, 0L);
        
            assertNotNull(result);
            assertTrue(result.length > 0);
            verify(mockEntry, never()).addExtraField(any(ResourceAlignmentExtraField.class));
        }

    @Test
        public void testCreateLocalFileHeaderWithAlignment() throws Exception {
            ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
            ResourceAlignmentExtraField mockAlignmentEx = mock(ResourceAlignmentExtraField.class);
            
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
            
            when(mockEntry.getExtraField(any(ZipShort.class))).thenReturn(mockAlignmentEx);
            when(mockAlignmentEx.getAlignment()).thenReturn((short)8);
            when(mockAlignmentEx.allowMethodChange()).thenReturn(true);
            when(mockEntry.getExtra()).thenReturn(new byte[0]);
            when(mockEntry.getTime()).thenReturn(System.currentTimeMillis());
            when(mockEntry.getCrc()).thenReturn(12345L);
            when(mockEntry.getSize()).thenReturn(100L);
            when(mockEntry.getCompressedSize()).thenReturn(100L);
            
            ByteBuffer name = ByteBuffer.wrap("test.txt".getBytes());
            Method createLocalFileHeaderMethod = ZipArchiveOutputStream.class
                    .getDeclaredMethod("createLocalFileHeader", 
                        ZipArchiveEntry.class, ByteBuffer.class, 
                        boolean.class, boolean.class, long.class);
            createLocalFileHeaderMethod.setAccessible(true);
            
            byte[] result = (byte[]) createLocalFileHeaderMethod.invoke(zos, 
                mockEntry, name, true, false, 0L);
        
            assertNotNull(result);
            assertTrue(result.length > 0);
            verify(mockEntry).removeExtraField(any(ZipShort.class));
            verify(mockEntry).addExtraField(any(ResourceAlignmentExtraField.class));
        }


}
