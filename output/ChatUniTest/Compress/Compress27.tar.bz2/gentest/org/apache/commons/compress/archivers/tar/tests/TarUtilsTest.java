package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                        public void testParseOctalWithValidInput() {
                                                                                            byte[] buffer = "   1234 \0".getBytes();
                                                                                            long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                                                            assertEquals(668, result); // 1234 in octal is 668 in decimal
                                                                                        }

    @Test
                                                                                        public void testParseOctalWithLeadingZero() {
                                                                                            byte[] buffer = "   0123 \0".getBytes();
                                                                                            long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                                                            assertEquals(83, result); // 0123 in octal is 83 in decimal
                                                                                        }

    @Test
                                                                                        public void testParseOctalWithLeadingSpaces() {
                                                                                            byte[] buffer = "     123 \0".getBytes();
                                                                                            long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                                                            assertEquals(83, result); // 123 in octal is 83 in decimal
                                                                                        }

    @Test
                                                                                        public void testParseOctalWithTrailingSpaces() {
                                                                                            byte[] buffer = "123     \0".getBytes();
                                                                                            long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                                                            assertEquals(83, result); // 123 in octal is 83 in decimal
                                                                                        }

    @Test
                                                                                        public void testParseOctalWithTrailingNuls() {
                                                                                            byte[] buffer = "123\0\0\0\0".getBytes();
                                                                                            long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                                                            assertEquals(83, result); // 123 in octal is 83 in decimal
                                                                                        }

    @Test
                                                                                        public void testParseOctalWithLeadingZeroByte() {
                                                                                            byte[] buffer = "\0123\0".getBytes();
                                                                                            long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                                                            assertEquals(0L, result);
                                                                                        }

    @Test
                                                                                        public void testParseOctalWithAllNuls() {
                                                                                            byte[] buffer = "\0\0\0\0".getBytes();
                                                                                            long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                                                            assertEquals(0L, result);
                                                                                        }

    @Test
                                                                                        public void testParseOctalWithMaxOctalValue() {
                                                                                            byte[] buffer = "17777777777 \0".getBytes();
                                                                                            long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                                                            assertEquals(2147483647L, result);
                                                                                        }

    @Test
                                                                                        public void testParseOctalWithOffset() {
                                                                                            byte[] buffer = "XX1234 \0".getBytes();
                                                                                            long result = TarUtils.parseOctal(buffer, 2, buffer.length - 2);
                                                                                            assertEquals(668, result); // 1234 in octal is 668 in decimal
                                                                                        }

    @Test
                                                                                        public void testParseOctalWithPartialBuffer() {
                                                                                            byte[] buffer = "12345678".getBytes();
                                                                                            long result = TarUtils.parseOctal(buffer, 0, 4); // Only parse "1234"
                                                                                            assertEquals(668, result); // 1234 in octal is 668 in decimal
                                                                                        }

    @Test
                                                                                        public void testParseOctalWithSingleDigit() {
                                                                                            byte[] buffer = "1 \0".getBytes();
                                                                                            long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                                                            assertEquals(1, result);
                                                                                        }

    @Test
                                                                                        public void testParseOctalWithMultipleSpaces() {
                                                                                            byte[] buffer = "   1   \0".getBytes();
                                                                                            long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                                                            assertEquals(1, result);
                                                                                        }

    @Test
                                                                                    public void testParseOctalThrowsForLengthLessThan() {
                                                                                        byte[] buffer = "1".getBytes();
                                                                                        try {
                                                                                            TarUtils.parseOctal(buffer, 0, 1);
                                                                                            fail("Expected IllegalArgumentException");
                                                                                        } catch (IllegalArgumentException e) {
                                                                                            assertEquals("Length 1 must be at least 2", e.getMessage());
                                                                                        }
                                                                                    }

    @Test
        public void testParseOctalThrowsForInvalidOctalDigit() {
            byte[] buffer = "128\0".getBytes();
        }


}
