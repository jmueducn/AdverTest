package gentest.org.apache.commons.compress.archivers.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.*;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.apache.commons.compress.archivers.ar.ArArchiveInputStream;
import org.apache.commons.compress.archivers.ar.ArArchiveOutputStream;
import org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream;
import org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream;
import org.apache.commons.compress.archivers.dump.DumpArchiveInputStream;
import org.apache.commons.compress.archivers.jar.JarArchiveInputStream;
import org.apache.commons.compress.archivers.jar.JarArchiveOutputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
 
public class ArchiveStreamFactoryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                public void testMatchesMethodForZip() throws Exception {
                    byte[] zipSignature = new byte[] {0x50, 0x4B, 0x03, 0x04};
                    Method matchesMethod = ZipArchiveInputStream.class.getDeclaredMethod("matches", byte[].class, int.class);
                    matchesMethod.setAccessible(true);
                    boolean result = (boolean) matchesMethod.invoke(null, zipSignature, zipSignature.length);
                    assertTrue(result);
                }

    @Test(expected = IllegalArgumentException.class)
            public void testCreateArchiveInputStreamWithNullArchiverName() throws ArchiveException {
                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                InputStream mockInputStream = mock(InputStream.class);
                factory.createArchiveInputStream(null, mockInputStream);
            }

    @Test(expected = IllegalArgumentException.class)
            public void testCreateArchiveInputStreamWithNullInputStream() throws ArchiveException {
                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                factory.createArchiveInputStream(ArchiveStreamFactory.AR, null);
            }

    @Test
            public void testCreateArArchiveInputStream() throws ArchiveException {
                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                InputStream mockInputStream = mock(InputStream.class);
                ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.AR, mockInputStream);
                assertTrue(result instanceof ArArchiveInputStream);
            }

    @Test
            public void testCreateJarArchiveInputStream() throws ArchiveException {
                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                InputStream mockInputStream = mock(InputStream.class);
                ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.JAR, mockInputStream);
                assertTrue(result instanceof JarArchiveInputStream);
            }

    @Test
            public void testCreateCpioArchiveInputStream() throws ArchiveException {
                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                InputStream mockInputStream = mock(InputStream.class);
                ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.CPIO, mockInputStream);
                assertTrue(result instanceof CpioArchiveInputStream);
            }

    @Test
            public void testCreateDumpArchiveInputStream() throws ArchiveException {
                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.DUMP, mockInputStream);
                assertTrue(result instanceof DumpArchiveInputStream);
            }

    @Test(expected = ArchiveException.class)
            public void testCreateArchiveInputStreamWithUnknownArchiver() throws ArchiveException {
                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                InputStream mockInputStream = mock(InputStream.class);
                factory.createArchiveInputStream("unknown", mockInputStream);
            }

    @Test
            public void testCreateArchiveInputStreamCaseInsensitive() throws ArchiveException {
                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                InputStream mockInputStream = mock(InputStream.class);
                
                ArchiveInputStream result = factory.createArchiveInputStream("Ar", mockInputStream);
                assertTrue(result instanceof ArArchiveInputStream);
                
                result = factory.createArchiveInputStream("zIp", mockInputStream);
                assertTrue(result instanceof ZipArchiveInputStream);
                
                result = factory.createArchiveInputStream("TAR", mockInputStream);
                assertTrue(result instanceof TarArchiveInputStream);
            }

    @Test(expected = IllegalArgumentException.class)
            public void testCreateArchiveInputStreamWithNullStream() throws Exception {
                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                factory.createArchiveInputStream(null);
            }

    @Test
            public void testCreateZipArchiveInputStream1() throws Exception {
                org.apache.commons.compress.archivers.ArchiveStreamFactory factory = 
                    new org.apache.commons.compress.archivers.ArchiveStreamFactory();
                byte[] zipSignature = new byte[] {0x50, 0x4B, 0x03, 0x04};
                InputStream in = new ByteArrayInputStream(zipSignature);
                ArchiveInputStream result = factory.createArchiveInputStream(in);
                assertTrue(result instanceof ZipArchiveInputStream);
            }

    @Test
            public void testCreateJarArchiveInputStream1() throws Exception {
                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                byte[] jarSignature = new byte[] {0x50, 0x4B, 0x03, 0x04, 0x14, 0x00, 0x08, 0x00, 0x08, 0x00, 0x00, 0x00};
                InputStream in = new ByteArrayInputStream(jarSignature);
                ArchiveInputStream result = factory.createArchiveInputStream(in);
                assertTrue(result instanceof JarArchiveInputStream);
            }

    @Test
            public void testCreateArArchiveInputStream1() throws Exception {
                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                byte[] arSignature = "!<arch>\n".getBytes();
                InputStream in = new ByteArrayInputStream(arSignature);
                ArchiveInputStream result = factory.createArchiveInputStream(in);
                assertTrue(result instanceof ArArchiveInputStream);
            }

    @Test
            public void testCreateCpioArchiveInputStream1() throws Exception {
                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                byte[] cpioSignature = new byte[] {0x30, 0x37, 0x30, 0x37, 0x30, 0x31};
                InputStream in = new ByteArrayInputStream(cpioSignature);
                ArchiveInputStream result = factory.createArchiveInputStream(in);
                assertTrue(result instanceof CpioArchiveInputStream);
            }

    @Test
            public void testCreateDumpArchiveInputStream1() throws Exception {
                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                byte[] dumpSignature = new byte[32];
                dumpSignature[0] = 0x43;
                dumpSignature[1] = 0x44;
                dumpSignature[2] = 0x30;
                dumpSignature[3] = 0x30;
                InputStream in = new ByteArrayInputStream(dumpSignature);
                ArchiveInputStream result = factory.createArchiveInputStream(in);
                assertTrue(result instanceof DumpArchiveInputStream);
            }

    @Test
            public void testCreateTarArchiveInputStream1() throws Exception {
                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                byte[] tarSignature = new byte[512];
                tarSignature[257] = 'u';
                tarSignature[258] = 's';
                tarSignature[259] = 't';
                tarSignature[260] = 'a';
                tarSignature[261] = 'r';
                InputStream in = new ByteArrayInputStream(tarSignature);
                ArchiveInputStream result = factory.createArchiveInputStream(in);
                assertTrue(result instanceof TarArchiveInputStream);
            }

    @Test(expected = ArchiveException.class)
            public void testCreateArchiveInputStreamWithUnknownFormat() throws Exception {
                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                byte[] unknownSignature = new byte[12];
                InputStream in = new ByteArrayInputStream(unknownSignature);
                factory.createArchiveInputStream(in);
            }

    @Test
            public void testCreateTarArchiveInputStreamWithExtendedDetection() throws Exception {
                byte[] tarHeader = new byte[512];
                // Create a valid tar header
                System.arraycopy("000644 \0".getBytes(), 0, tarHeader, 100, 8);
                System.arraycopy("000765 \0".getBytes(), 0, tarHeader, 108, 8);
                System.arraycopy("000024 \0".getBytes(), 0, tarHeader, 116, 8);
                System.arraycopy("14164217605 ".getBytes(), 0, tarHeader, 136, 12);
                System.arraycopy(" 0\0".getBytes(), 0, tarHeader, 148, 3);
                
                InputStream in = new ByteArrayInputStream(tarHeader);
                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                ArchiveInputStream result = factory.createArchiveInputStream(in);
                assertTrue(result instanceof TarArchiveInputStream);
            }

    @Test
        public void testCreateZipArchiveInputStream() throws ArchiveException {
            ArchiveStreamFactory factory = new ArchiveStreamFactory();
            InputStream mockInputStream = mock(InputStream.class);
            ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, mockInputStream);
            assertTrue(result instanceof ZipArchiveInputStream);
        }

    @Test
        public void testCreateTarArchiveInputStream() throws ArchiveException {
            ArchiveStreamFactory factory = new ArchiveStreamFactory();
            ByteArrayInputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
            ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, mockInputStream);
            assertTrue(result instanceof TarArchiveInputStream);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testCreateArchiveInputStreamWithNonMarkSupportedStream() throws Exception {
            ArchiveStreamFactory factory = new ArchiveStreamFactory();
            InputStream inputStream = mock(InputStream.class);
            when(inputStream.markSupported()).thenReturn(false);
            factory.createArchiveInputStream(inputStream);
        }

    @Test(expected = IOException.class)
        public void testCreateArchiveInputStreamWithIOException() throws Exception {
            ArchiveStreamFactory factory = new ArchiveStreamFactory();
            InputStream inputStream = mock(InputStream.class);
            
            when(inputStream.markSupported()).thenReturn(true);
            doThrow(new IOException()).when(inputStream).mark(anyInt());
            factory.createArchiveInputStream(inputStream);
        }


}
