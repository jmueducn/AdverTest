package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
import org.apache.commons.compress.utils.ArchiveUtils;
import org.apache.commons.compress.utils.CharsetNames;
import org.apache.commons.compress.utils.IOUtils;
 
public class TarArchiveInputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                    public void testParsePaxHeadersWithSingleHeader() throws Exception {
                                                        String input = "21 comment=Hello World\n";
                                                        InputStream inputStream = new ByteArrayInputStream(input.getBytes(CharsetNames.UTF_8));
                                                        
                                                        Method parsePaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                        parsePaxHeadersMethod.setAccessible(true);
                                                        TarArchiveInputStream tarInputStream = new TarArchiveInputStream(null);
                                                        Map<String, String> result = (Map<String, String>) parsePaxHeadersMethod.invoke(tarInputStream, inputStream);
                                                
                                                        assertEquals(1, result.size());
                                                        assertEquals("Hello World", result.get("comment"));
                                                    }

    @Test
                                                    public void testParsePaxHeadersWithIncompleteData() throws Exception {
                                                        String input = "100 comment=This is longer than specified length\n";
                                                        InputStream inputStream = new ByteArrayInputStream(input.getBytes(CharsetNames.UTF_8));
                                                        
                                                        TarArchiveInputStream tarInput = new TarArchiveInputStream(inputStream);
                                                        Method parsePaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                        parsePaxHeaders.setAccessible(true);
                                                        Map<String, String> result = (Map<String, String>) parsePaxHeaders.invoke(tarInput, inputStream);
                                                    }

    @Test
                                                    public void testParsePaxHeadersWithBlankLine() throws Exception {
                                                        String input = "\n21 comment=Hello World\n";
                                                        InputStream inputStream = new ByteArrayInputStream(input.getBytes(CharsetNames.UTF_8));
                                                        
                                                        TarArchiveInputStream tarInput = new TarArchiveInputStream(inputStream);
                                                        Method parsePaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                        parsePaxHeadersMethod.setAccessible(true);
                                                        Map<String, String> result = (Map<String, String>) parsePaxHeadersMethod.invoke(tarInput, inputStream);
                                                        
                                                        assertEquals(1, result.size());
                                                        assertEquals("Hello World", result.get("comment"));
                                                    }

    @Test
                                                    public void testParsePaxHeadersWithEmptyInput() throws Exception {
                                                        String input = "";
                                                        InputStream inputStream = new ByteArrayInputStream(input.getBytes(CharsetNames.UTF_8));
                                                        
                                                        Method parsePaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod(
                                                            "parsePaxHeaders", InputStream.class);
                                                        parsePaxHeadersMethod.setAccessible(true);
                                                        
                                                        TarArchiveInputStream tarInputStream = new TarArchiveInputStream(inputStream);
                                                        Map<String, String> result = (Map<String, String>) parsePaxHeadersMethod.invoke(
                                                            tarInputStream, inputStream);
                                                        
                                                        assertTrue(result.isEmpty());
                                                    }

    @Test
                                                    public void testParsePaxHeadersWithOnlyNewlines() throws Exception {
                                                        String input = "\n\n\n";
                                                        InputStream inputStream = new ByteArrayInputStream(input.getBytes(CharsetNames.UTF_8));
                                                        
                                                        Method parsePaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                        parsePaxHeadersMethod.setAccessible(true);
                                                        TarArchiveInputStream tarInputStream = new TarArchiveInputStream(null);
                                                        Map<String, String> result = (Map<String, String>) parsePaxHeadersMethod.invoke(tarInputStream, inputStream);
                                                        
                                                        assertTrue(result.isEmpty());
                                                    }

    @Test
                                                    public void testParsePaxHeadersWithMultibyteCharacters() throws Exception {
                                                        String input = "25 comment=こんにちは世界\n";
                                                        InputStream inputStream = new ByteArrayInputStream(input.getBytes(CharsetNames.UTF_8));
                                                        
                                                        Method parsePaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                        parsePaxHeadersMethod.setAccessible(true);
                                                        TarArchiveInputStream tarInputStream = new TarArchiveInputStream(null);
                                                        Map<String, String> result = (Map<String, String>) parsePaxHeadersMethod.invoke(tarInputStream, inputStream);
                                                
                                                        assertEquals(1, result.size());
                                                        assertEquals("こんにちは世界", result.get("comment"));
                                                    }

    @Test(expected = IOException.class)
                                                    public void testParsePaxHeadersWithIOError() throws Exception {
                                                        InputStream mockInputStream = mock(InputStream.class);
                                                        when(mockInputStream.read()).thenThrow(new IOException("Simulated IO error"));
                                                
                                                        // Using reflection to invoke private method
                                                        Method parsePaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod(
                                                            "parsePaxHeaders", InputStream.class, Map.class);
                                                        parsePaxHeadersMethod.setAccessible(true);
                                                        
                                                        parsePaxHeadersMethod.invoke(
                                                            new TarArchiveInputStream(new ByteArrayInputStream(new byte[0])),
                                                            mockInputStream,
                                                            mock(Map.class));
                                                    }

    @Test
            public void testParsePaxHeadersWithGlobalHeaders() throws Exception {
                Map<String, String> globalPaxHeaders = new HashMap<>();
                globalPaxHeaders.put("global", "value");
                
                String input = "21 comment=Hello World\n";
                InputStream inputStream = new ByteArrayInputStream(input.getBytes());
                
                Map<String, String> result = new HashMap<>(globalPaxHeaders);
                // Format is "length keyword=value\n";
                while(true){ // get length
                    int ch;
                    int len = 0;
                    int read = 0;
                    while((ch = inputStream.read()) != -1) {
                        read++;
                        if (ch == '\n') { // blank line in header
                            break;
                        } else if (ch == ' '){ // End of length string
                            // Get keyword
                            final ByteArrayOutputStream coll = new ByteArrayOutputStream();
                            String keyword = "";
                            while((ch = inputStream.read()) != -1) {
                                read++;
                                if (ch == '='){ // end of keyword
                                    keyword = new String(coll.toByteArray());
                                    // Get rest of entry
                                    final int restLen = len - read;
                                    if (restLen == 1) { // only NL
                                        result.remove(keyword);
                                    } else {
                                        final byte[] rest = new byte[restLen];
                                        final int got = IOUtils.readFully(inputStream, rest);
                                        if (got != restLen) {
                                            throw new IOException("Failed to read "
                                                                  + "Paxheader. Expected "
                                                                  + restLen
                                                                  + " bytes, read "
                                                                  + got);
                                        }
                                        // Drop trailing NL
                                        final String value = new String(rest, 0, restLen - 1);
                                        result.put(keyword, value);
                                    }
                                    break;
                                }
                                coll.write((byte) ch);
                            }
                            break; // Processed single header
                        }
                        len *= 10;
                        len += ch - '0';
                    }
                    if (ch == -1){ // EOF
                        break;
                    }
                }
            
                assertEquals(2, result.size());
                assertEquals("Hello World", result.get("comment"));
                assertEquals("value", result.get("global"));
            }

    @Test
        public void testParsePaxHeadersWithMultipleHeaders() throws Exception {
            String input = "21 comment=Hello World\n25 path=some/path/to/file\n";
            InputStream inputStream = new ByteArrayInputStream(input.getBytes());
            
            org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarInput = 
                new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream);
            Method method = org.apache.commons.compress.archivers.tar.TarArchiveInputStream.class.getDeclaredMethod(
                "parsePaxHeaders", InputStream.class);
            method.setAccessible(true);
            @SuppressWarnings("unchecked")
            Map<String, String> result = (Map<String, String>) method.invoke(tarInput, inputStream);
            
            assertEquals(2, result.size());
            assertEquals("Hello World", result.get("comment"));
            assertEquals("some/path/to/file", result.get("path"));
        }

    @Test
        public void testParsePaxHeadersWithHeaderRemoval() throws Exception {
            String input = "14 comment=\n";
            InputStream inputStream = new ByteArrayInputStream(input.getBytes());
            
            Map<String, String> initialHeaders = new HashMap<>();
            initialHeaders.put("comment", "to be removed");
            
            // Using reflection to access private method
            Method method = TarArchiveInputStream.class.getDeclaredMethod(
                "parsePaxHeaders", InputStream.class, Map.class);
            method.setAccessible(true);
            @SuppressWarnings("unchecked")
            Map<String, String> result = (Map<String, String>) method.invoke(
                new TarArchiveInputStream(null), inputStream, initialHeaders);
            
            assertEquals(0, result.size());
            assertFalse(result.containsKey("comment"));
        }


}
