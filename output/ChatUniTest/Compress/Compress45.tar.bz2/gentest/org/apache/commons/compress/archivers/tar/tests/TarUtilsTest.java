package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                public void testFormatLongOctalOrBinaryBytes_PositiveOctal() {
                                                    byte[] buf = new byte[8];
                                                    int offset = 0;
                                                    int length = 8;
                                                    long value = 1234567L;
                                                    
                                                    int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                    
                                                    assertEquals(offset + length, result);
                                                    assertEquals(' ', buf[offset + length - 1]);
                                                }

    @Test
                                                public void testFormatLongOctalOrBinaryBytes_NegativeOctal() {
                                                    byte[] buf = new byte[8];
                                                    int offset = 0;
                                                    int length = 8;
                                                    long value = -1234567L;
                                                    
                                                    int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                    
                                                    assertEquals(offset + length, result);
                                                    assertEquals((byte) 0xff, buf[offset]);
                                                }

    @Test
                                                public void testFormatLongOctalOrBinaryBytes_NegativeBinaryShort() {
                                                    byte[] buf = new byte[8];
                                                    int offset = 0;
                                                    int length = 8;
                                                    long value = -123456789L;
                                                    
                                                    int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                    
                                                    assertEquals(offset + length, result);
                                                    assertEquals((byte) 0xff, buf[offset]);
                                                }

    @Test
                                                public void testFormatLongOctalOrBinaryBytes_NegativeBinaryLong() {
                                                    byte[] buf = new byte[12];
                                                    int offset = 0;
                                                    int length = 12;
                                                    long value = Long.MIN_VALUE;
                                                    
                                                    int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                    
                                                    assertEquals(offset + length, result);
                                                    assertEquals((byte) 0xff, buf[offset]);
                                                }

    @Test(expected = IllegalArgumentException.class)
                                                public void testFormatLongBinary_ValueTooLarge() throws Exception {
                                                    byte[] buf = new byte[8];
                                                    int offset = 0;
                                                    int length = 8;
                                                    long value = 1L << (7 * 8);
                                                    
                                                    Method method = TarUtils.class.getDeclaredMethod("formatLongBinary", 
                                                        long.class, byte[].class, int.class, int.class, boolean.class);
                                                    method.setAccessible(true);
                                                    method.invoke(null, value, buf, offset, length, false);
                                                }

    @Test(expected = IllegalArgumentException.class)
                                                public void testFormatBigIntegerBinary_ValueTooLarge() throws Exception {
                                                    byte[] buf = new byte[12];
                                                    int offset = 0;
                                                    int length = 12;
                                                    long value = Long.MAX_VALUE;
                                                    
                                                    Method method = TarUtils.class.getDeclaredMethod("formatBigIntegerBinary", 
                                                        long.class, byte[].class, int.class, int.class, boolean.class);
                                                    method.setAccessible(true);
                                                    method.invoke(null, value, buf, offset, length, false);
                                                }

    @Test
                                                public void testFormatLongBinary_PositiveValue() throws Exception {
                                                    byte[] buf = new byte[8];
                                                    int offset = 0;
                                                    int length = 8;
                                                    long value = 0x123456789ABCDEFL;
                                                    
                                                    Method method = TarUtils.class.getDeclaredMethod("formatLongBinary", 
                                                        long.class, byte[].class, int.class, int.class, boolean.class);
                                                    method.setAccessible(true);
                                                    method.invoke(null, value, buf, offset, length, false);
                                                    
                                                    assertEquals((byte) 0x12, buf[offset]);
                                                    assertEquals((byte) 0x34, buf[offset + 1]);
                                                    assertEquals((byte) 0x56, buf[offset + 2]);
                                                    assertEquals((byte) 0x78, buf[offset + 3]);
                                                    assertEquals((byte) 0x9A, buf[offset + 4]);
                                                    assertEquals((byte) 0xBC, buf[offset + 5]);
                                                    assertEquals((byte) 0xDE, buf[offset + 6]);
                                                    assertEquals((byte) 0xEF, buf[offset + 7]);
                                                }

    @Test
                                                public void testFormatBigIntegerBinary_NegativeValue() throws Exception {
                                                    byte[] buf = new byte[12];
                                                    int offset = 0;
                                                    int length = 12;
                                                    long value = -1234567890123456789L;
                                                    
                                                    Method method = TarUtils.class.getDeclaredMethod("formatBigIntegerBinary", 
                                                        long.class, byte[].class, int.class, int.class, boolean.class);
                                                    method.setAccessible(true);
                                                    method.invoke(null, value, buf, offset, length, true);
                                                    
                                                    assertEquals((byte) 0xff, buf[offset + 1]);
                                                    assertEquals((byte) 0xff, buf[offset + 2]);
                                                    assertEquals((byte) 0xff, buf[offset + 3]);
                                                }

    @Test
                                            public void testFormatLongOctalOrBinaryBytes_PositiveBinaryShort() {
                                                byte[] buf = new byte[8];
                                                int offset = 0;
                                                int length = 8;
                                                long value = 07777777L + 1; // MAXID + 1
                                                
                                                int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                
                                                assertEquals(offset + length, result);
                                                assertEquals((byte) 0x80, buf[offset]);
                                            }

    @Test
                                            public void testFormatLongOctalOrBinaryBytes_PositiveBinaryLong() {
                                                byte[] buf = new byte[12];
                                                int offset = 0;
                                                int length = 12;
                                                long value = TarConstants.MAXSIZE + 1;
                                                
                                                int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                
                                                assertEquals(offset + length, result);
                                                assertEquals((byte) 0x80, buf[offset]);
                                            }

    @Test
                                            public void testFormatLongOctalOrBinaryBytes_UIDLengthPositive() {
                                                int UIDLEN = TarConstants.UIDLEN;
                                                long MAXID = TarConstants.MAXID;
                                                byte[] buf = new byte[UIDLEN];
                                                int offset = 0;
                                                int length = UIDLEN;
                                                long value = MAXID;
                                                
                                                int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                
                                                assertEquals(offset + length, result);
                                                assertEquals(' ', buf[offset + length - 1]);
                                            }

    @Test
                                            public void testFormatLongOctalOrBinaryBytes_UIDLengthNegative() {
                                                final int UIDLEN = 8; // Defining the constant that was missing
                                                byte[] buf = new byte[UIDLEN];
                                                int offset = 0;
                                                int length = UIDLEN;
                                                long value = -1L;
                                                
                                                int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                
                                                assertEquals(offset + length, result);
                                                assertEquals((byte) 0xff, buf[offset]);
                                            }


}
