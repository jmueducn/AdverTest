package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
 
public class TarUtilsTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testParseOctalWithValidInput() {
            byte[] buffer = {' ', '1', '2', '3', ' ', 0};
            long result = TarUtils.parseOctal(buffer, 0, 6);
            assertEquals(83L, result);
        }

    @Test
        public void testParseOctalWithLeadingSpaces() {
            byte[] buffer = {' ', ' ', '7', ' ', 0};
            long result = TarUtils.parseOctal(buffer, 0, 5);
            assertEquals(7L, result);
        }

    @Test
        public void testParseOctalWithSingleTrailingSpace() {
            byte[] buffer = {'1', '2', ' ', 0};
            long result = TarUtils.parseOctal(buffer, 0, 4);
            assertEquals(10L, result);
        }

    @Test
        public void testParseOctalWithDoubleTrailingSpace() {
            byte[] buffer = {'1', '2', ' ', ' ', 0};
            long result = TarUtils.parseOctal(buffer, 0, 5);
            assertEquals(10L, result);
        }

    @Test
        public void testParseOctalWithSingleTrailingNUL() {
            byte[] buffer = {'1', '2', 0};
            long result = TarUtils.parseOctal(buffer, 0, 3);
            assertEquals(10L, result);
        }

    @Test
        public void testParseOctalWithDoubleTrailingNUL() {
            byte[] buffer = {'1', '2', 0, 0};
            long result = TarUtils.parseOctal(buffer, 0, 4);
            assertEquals(10L, result);
        }

    @Test
        public void testParseOctalWithAllNULs() {
            byte[] buffer = {0, 0, 0, 0};
            long result = TarUtils.parseOctal(buffer, 0, 4);
            assertEquals(0L, result);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testParseOctalWithInvalidLength() {
            byte[] buffer = {'1'};
            TarUtils.parseOctal(buffer, 0, 1);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testParseOctalWithInvalidTrailer() {
            byte[] buffer = {'1', '2', '3'};
            TarUtils.parseOctal(buffer, 0, 3);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testParseOctalWithInvalidOctalDigit() {
            byte[] buffer = {'1', '8', ' ', 0};
            TarUtils.parseOctal(buffer, 0, 4);
        }

    @Test
        public void testParseOctalWithMaximumValue() {
            byte[] buffer = {'7', '7', '7', '7', '7', '7', '7', '7', ' ', 0};
            long result = TarUtils.parseOctal(buffer, 0, 10);
            assertEquals(2097151L, result);
        }

    @Test
        public void testParseOctalWithMinimumValue() {
            byte[] buffer = {'0', '0', ' ', 0};
            long result = TarUtils.parseOctal(buffer, 0, 4);
            assertEquals(0L, result);
        }

    @Test
        public void testExceptionMessage() throws Exception {
            byte[] buffer = {'a', 'b', 'c'};
            Method method = TarUtils.class.getDeclaredMethod("exceptionMessage", 
                byte[].class, int.class, int.class, int.class, byte.class);
            method.setAccessible(true);
            
            String message = (String) method.invoke(null, buffer, 0, 3, 1, (byte)'x');
            assertEquals("Invalid byte 120 at offset 1 in 'abc' len=3", message);
        }

    @Test
        public void testParseOctalWithMixedTrailingChars() {
            byte[] buffer = {'1', '2', ' ', 0, ' '};
            long result = TarUtils.parseOctal(buffer, 0, 5);
            assertEquals(10L, result);
        }

    @Test
        public void testParseOctalWithOffset() {
            byte[] buffer = {0, '1', '2', '3', ' ', 0};
            long result = TarUtils.parseOctal(buffer, 1, 5);
            assertEquals(83L, result);
        }

}
