package gentest.org.apache.commons.compress.utils.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.utils.*;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import org.apache.commons.compress.archivers.ArchiveEntry;
 
public class ArchiveUtilsTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testSanitizeShortString() {
            String input = "test";
            String result = ArchiveUtils.sanitize(input);
            assertEquals("test", result);
        }

    @Test
        public void testSanitizeLongString() throws Exception {
            // Create a string longer than MAX_SANITIZED_NAME_LENGTH
            char[] longChars = new char[300];
            Arrays.fill(longChars, 'a');
            String longString = new String(longChars);
            
            String result = ArchiveUtils.sanitize(longString);
            
            // Get MAX_SANITIZED_NAME_LENGTH via reflection
            Field field = ArchiveUtils.class.getDeclaredField("MAX_SANITIZED_NAME_LENGTH");
            field.setAccessible(true);
            int maxLength = field.getInt(null);
            
            assertEquals(maxLength, result.length());
            assertTrue(result.endsWith("..."));
        }

    @Test
        public void testSanitizeWithControlCharacters() {
            String input = "test\u0001\u0002test";
            String result = ArchiveUtils.sanitize(input);
            assertEquals("test??test", result);
        }

    @Test
        public void testSanitizeWithSpecialUnicodeBlock() {
            String input = "test\uFFF0test"; // SPECIALS block
            String result = ArchiveUtils.sanitize(input);
            assertEquals("test?test", result);
        }

    @Test
        public void testSanitizeWithNonSpecialUnicodeBlock() {
            String input = "test\u00A0test"; // NO-BREAK SPACE
            String result = ArchiveUtils.sanitize(input);
            assertEquals("test\u00A0test", result);
        }

    @Test
        public void testSanitizeEmptyString() {
            String input = "";
            String result = ArchiveUtils.sanitize(input);
            assertEquals("", result);
        }

    @Test
        public void testSanitizeNullString() {
            String input = null;
            try {
                ArchiveUtils.sanitize(input);
                fail("Expected NullPointerException");
            } catch (NullPointerException e) {
                // expected
            }
        }

    @Test
        public void testSanitizeExactlyMaxLength() throws Exception {
            // Get MAX_SANITIZED_NAME_LENGTH via reflection
            Field field = ArchiveUtils.class.getDeclaredField("MAX_SANITIZED_NAME_LENGTH");
            field.setAccessible(true);
            int maxLength = field.getInt(null);
            
            char[] exactChars = new char[maxLength];
            Arrays.fill(exactChars, 'a');
            String exactString = new String(exactChars);
            
            String result = ArchiveUtils.sanitize(exactString);
            assertEquals(maxLength, result.length());
            assertFalse(result.contains("..."));
        }

    @Test
        public void testSanitizeOneOverMaxLength() throws Exception {
            // Get MAX_SANITIZED_NAME_LENGTH via reflection
            Field field = ArchiveUtils.class.getDeclaredField("MAX_SANITIZED_NAME_LENGTH");
            field.setAccessible(true);
            int maxLength = field.getInt(null);
            
            char[] chars = new char[maxLength + 1];
            Arrays.fill(chars, 'a');
            String input = new String(chars);
            
            String result = ArchiveUtils.sanitize(input);
            assertEquals(maxLength, result.length());
            assertTrue(result.endsWith("..."));
        }

}
