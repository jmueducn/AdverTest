package gentest.org.apache.commons.compress.archivers.cpio.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.cpio.*;
import java.io.File;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.utils.ArchiveUtils;
 
public class CpioArchiveOutputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                    public void testEnsureOpenExceptionMessage() throws Exception {
                        OutputStream out = new OutputStream() {
                            @Override
                            public void write(int b) throws IOException {
                                // Do nothing
                            }
                        };
                        CpioArchiveOutputStream cpioStream = new CpioArchiveOutputStream(out);
                        
                        Method ensureOpenMethod = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                        ensureOpenMethod.setAccessible(true);
                        
                        try {
                            // Close the stream
                            cpioStream.close();
                            
                            // Invoke ensureOpen which should throw IOException
                            ensureOpenMethod.invoke(cpioStream);
                            fail("Expected IOException to be thrown");
                        } catch (Exception e) {
                            Throwable cause = e.getCause();
                            assertTrue(cause instanceof IOException);
                            assertEquals("Stream closed", cause.getMessage());
                        }
                    }

    @Test
                    public void testCloseWhenNotClosed() throws Exception {
                        // Create mock output stream
                        OutputStream mockOutputStream = mock(OutputStream.class);
                        
                        // Create CpioArchiveOutputStream instance
                        CpioArchiveOutputStream cpioStream = new CpioArchiveOutputStream(mockOutputStream);
                        
                        // Set closed field to false using reflection
                        Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                        closedField.setAccessible(true);
                        closedField.set(cpioStream, false);
                
                        cpioStream.close();
                
                        verify(mockOutputStream).close();
                        assert((boolean) closedField.get(cpioStream));
                    }

    @Test
                    public void testCloseWhenAlreadyClosed() throws Exception {
                        OutputStream mockOutputStream = mock(OutputStream.class);
                        CpioArchiveOutputStream cpioStream = new CpioArchiveOutputStream(mockOutputStream);
                        
                        // Set closed field to true using reflection
                        Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                        closedField.setAccessible(true);
                        closedField.set(cpioStream, true);
                
                        cpioStream.close();
                
                        verify(mockOutputStream, never()).close();
                        assert((boolean) closedField.get(cpioStream));
                    }

    @Test
                    public void testCloseThrowsIOException() throws Exception {
                        OutputStream mockOutputStream = mock(OutputStream.class);
                        CpioArchiveOutputStream cpioStream = new CpioArchiveOutputStream(mockOutputStream);
                        
                        doThrow(new IOException("Test exception")).when(mockOutputStream).close();
                        
                        Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                        closedField.setAccessible(true);
                        closedField.set(cpioStream, false);
                    
                        try {
                            cpioStream.close();
                        } catch (IOException e) {
                            // Expected
                        }
                    
                        verify(mockOutputStream).close();
                        assert((boolean) closedField.get(cpioStream));
                    }

    @Test
            public void testEnsureOpenWhenStreamIsClosed1() throws Exception {
                // Create test objects
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                CpioArchiveOutputStream cpioStream = new CpioArchiveOutputStream(out);
                
                // Get private method via reflection
                Method ensureOpenMethod = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                ensureOpenMethod.setAccessible(true);
                
                // Close the stream
                cpioStream.close();
                
                // Get private closed field via reflection and verify the stream is closed
                Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                closedField.setAccessible(true);
                assertTrue(closedField.getBoolean(cpioStream));
                
                // Invoke ensureOpen which should throw IOException
                try {
                    ensureOpenMethod.invoke(cpioStream);
                    fail("Expected IOException to be thrown");
                } catch (Exception e) {
                    assertTrue(e.getCause() instanceof IOException);
                    assertEquals("Stream closed", e.getCause().getMessage());
                }
            }

    @Test
        public void testEnsureOpenWhenStreamIsClosed() throws Exception {
            // Create test objects
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            CpioArchiveOutputStream cpioStream = new CpioArchiveOutputStream(out);
            
            // Get private method via reflection
            Method ensureOpenMethod = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
            ensureOpenMethod.setAccessible(true);
            
            // Close the stream
            cpioStream.close();
            
            // Verify the stream is closed using reflection
            Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
            closedField.setAccessible(true);
            boolean closed = (boolean) closedField.get(cpioStream);
            assertTrue(closed);
            
            // Invoke ensureOpen which should throw IOException
            try {
                ensureOpenMethod.invoke(cpioStream);
                fail("Expected IOException to be thrown");
            } catch (Exception e) {
                assertTrue(e.getCause() instanceof IOException);
                assertEquals("Stream closed", e.getCause().getMessage());
            }
        }


}
