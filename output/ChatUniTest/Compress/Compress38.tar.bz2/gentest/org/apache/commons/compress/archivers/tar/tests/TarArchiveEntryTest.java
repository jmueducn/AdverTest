package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.utils.ArchiveUtils;
 
public class TarArchiveEntryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                public void testIsDirectoryWhenNameEndsWithSlash() {
                                                    TarArchiveEntry entry = new TarArchiveEntry("testDir/");
                                                    assertTrue(entry.isDirectory());
                                                }

    @Test
                                                public void testIsDirectoryWhenNotDirectory() {
                                                    TarArchiveEntry entry = new TarArchiveEntry("testFile");
                                                    assertFalse(entry.isDirectory());
                                                }

    @Test
                                            public void testIsDirectoryWhenFileIsDirectory() {
                                                File mockFile = mock(File.class);
                                                when(mockFile.isDirectory()).thenReturn(true);
                                                TarArchiveEntry entry = new TarArchiveEntry(mockFile, "testDir");
                                                assertTrue(entry.isDirectory());
                                            }

    @Test
                                            public void testIsDirectoryWhenFileIsNotDirectory() {
                                                File mockFile = mock(File.class);
                                                when(mockFile.isDirectory()).thenReturn(false);
                                                TarArchiveEntry entry = new TarArchiveEntry(mockFile, "testFile");
                                                assertFalse(entry.isDirectory());
                                            }

    @Test
        public void testIsDirectoryWhenLinkFlagIsDir() {
            byte LF_DIR = 0x35; // ASCII value for '5' which represents directory in tar format
            TarArchiveEntry entry = new TarArchiveEntry("testDir");
            assertTrue(entry.isDirectory());
        }

    @Test
        public void testIsDirectoryWhenNameEndsWithSlashButIsPaxHeader() {
            byte LF_PAX_EXTENDED_HEADER_LC = (byte) 'x';
            TarArchiveEntry entry = new TarArchiveEntry("testDir/");
            assertFalse(entry.isDirectory());
        }

    @Test
        public void testIsDirectoryWhenNameEndsWithSlashButIsGlobalPaxHeader() {
            TarArchiveEntry entry = new TarArchiveEntry("testDir/");
            byte LF_PAX_GLOBAL_EXTENDED_HEADER = (byte) 'g';
            assertFalse(entry.isDirectory());
        }

    @Test
        public void testIsDirectoryWhenFileIsNullAndNameDoesNotEndWithSlash() {
            byte LF_NORMAL = (byte) '0';
            TarArchiveEntry entry = new TarArchiveEntry("testFile");
            assertFalse(entry.isDirectory());
        }

    @Test
        public void testIsDirectoryWhenFileIsNullAndLinkFlagNotDir() {
            byte LF_NORMAL = (byte) '0';
            TarArchiveEntry entry = new TarArchiveEntry("testFile");
            assertFalse(entry.isDirectory());
        }


}
