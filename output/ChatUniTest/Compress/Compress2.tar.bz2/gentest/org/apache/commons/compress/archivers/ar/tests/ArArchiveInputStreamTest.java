package gentest.org.apache.commons.compress.archivers.ar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.ar.*;
import java.io.IOException;
import java.io.InputStream;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveInputStream;
 
public class ArArchiveInputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                public void testReadByteArrayWithRealStream() throws IOException {
                                                    byte[] inputData = "test data".getBytes();
                                                    InputStream realInputStream = new ByteArrayInputStream(inputData);
                                                    ArArchiveInputStream realArInputStream = new ArArchiveInputStream(realInputStream);
                                                    
                                                    byte[] buffer = new byte[inputData.length];
                                                    int result = realArInputStream.read(buffer);
                                                    
                                                    assertEquals(inputData.length, result);
                                                    assertArrayEquals(inputData, buffer);
                                                }

    @Test
                                        public void testGetNextArEntryWithNullCurrentEntry() throws Exception {
                                            // Setup
                                            InputStream mockInputStream = mock(InputStream.class);
                                            ArArchiveInputStream arInputStream = new ArArchiveInputStream(mockInputStream);
                                            
                                            // Set currentEntry to null through reflection
                                            java.lang.reflect.Field currentEntryField = ArArchiveInputStream.class.getDeclaredField("currentEntry");
                                            currentEntryField.setAccessible(true);
                                            currentEntryField.set(arInputStream, null);
                                            
                                            // Set offset to 0 through reflection
                                            java.lang.reflect.Field offsetField = ArArchiveInputStream.class.getDeclaredField("offset");
                                            offsetField.setAccessible(true);
                                            offsetField.set(arInputStream, 0L);
                                            
                                            // Mock behavior
                                            when(mockInputStream.available()).thenReturn(0);
                                            
                                            // Test
                                            assertNull(arInputStream.getNextArEntry());
                                        }

    @Test
                                        public void testGetNextArEntryWithCurrentEntryAndEOF() throws Exception {
                                            // Create test objects
                                            InputStream mockInputStream = mock(InputStream.class);
                                            ArArchiveInputStream arInputStream = new ArArchiveInputStream(mockInputStream);
                                            
                                            // Set up test data
                                            ArArchiveEntry entry = new ArArchiveEntry("test", 10);
                                            
                                            // Set private fields using reflection
                                            Field currentEntryField = ArArchiveInputStream.class.getDeclaredField("currentEntry");
                                            currentEntryField.setAccessible(true);
                                            currentEntryField.set(arInputStream, entry);
                                            
                                            Field entryOffsetField = ArArchiveInputStream.class.getDeclaredField("entryOffset");
                                            entryOffsetField.setAccessible(true);
                                            entryOffsetField.set(arInputStream, 0L);
                                            
                                            Field offsetField = ArArchiveInputStream.class.getDeclaredField("offset");
                                            offsetField.setAccessible(true);
                                            offsetField.set(arInputStream, 5L);
                                            
                                            // Mock behavior
                                            when(mockInputStream.read()).thenReturn(-1);
                                            
                                            // Test and verify
                                            assertNull(arInputStream.getNextArEntry());
                                        }

    @Test
                                        public void testGetNextArEntryWithInvalidHeader() throws Exception {
                                            byte[] invalidHeader = "invalid".getBytes();
                                            InputStream is = new ByteArrayInputStream(invalidHeader);
                                            ArArchiveInputStream arInputStream = new ArArchiveInputStream(is);
                                    
                                            try {
                                                arInputStream.getNextArEntry();
                                                fail("Expected IOException");
                                            } catch (IOException e) {
                                                assertTrue(e.getMessage().contains("failed to read header"));
                                            }
                                        }

    @Test
                                        public void testGetNextArEntryWithValidHeaderButOddOffset() throws Exception {
                                            byte[] header = ArArchiveEntry.HEADER.getBytes();
                                            byte[] oddByte = new byte[]{0};
                                            byte[] combined = new byte[header.length + oddByte.length];
                                            System.arraycopy(header, 0, combined, 0, header.length);
                                            System.arraycopy(oddByte, 0, combined, header.length, oddByte.length);
                                    
                                            InputStream is = new ByteArrayInputStream(combined);
                                            ArArchiveInputStream arInputStream = new ArArchiveInputStream(is);
                                            
                                            assertNull(arInputStream.getNextArEntry());
                                        }

    @Test
                                        public void testGetNextArEntryWhenInputStreamEmpty() throws Exception {
                                            InputStream mockInputStream = mock(InputStream.class);
                                            ArArchiveInputStream arInputStream = new ArArchiveInputStream(mockInputStream);
                                            
                                            when(mockInputStream.available()).thenReturn(0);
                                            assertNull(arInputStream.getNextArEntry());
                                        }

    @Test
                                        public void testGetNextArEntryWithOddOffsetAndEOF() throws Exception {
                                            // Create mock input stream
                                            InputStream mockInputStream = mock(InputStream.class);
                                            
                                            // Create test instance
                                            ArArchiveInputStream arInputStream = new ArArchiveInputStream(mockInputStream);
                                            
                                            // Set private field using reflection
                                            java.lang.reflect.Field offsetField = ArArchiveInputStream.class.getDeclaredField("offset");
                                            offsetField.setAccessible(true);
                                            offsetField.set(arInputStream, 1L);
                                            
                                            // Mock behavior
                                            when(mockInputStream.read()).thenReturn(-1);
                                            
                                            // Test and assert
                                            assertNull(arInputStream.getNextArEntry());
                                        }

    @Test
                                        public void testCloseWhenNotClosed() throws Exception {
                                            // Create mock input stream
                                            InputStream mockInputStream = mock(InputStream.class);
                                            
                                            // Create ArArchiveInputStream instance
                                            ArArchiveInputStream arArchiveInputStream = new ArArchiveInputStream(mockInputStream);
                                            
                                            // Set up closed state to false
                                            Field closedField = ArArchiveInputStream.class.getDeclaredField("closed");
                                            closedField.setAccessible(true);
                                            closedField.set(arArchiveInputStream, false);
                                            
                                            // Set currentEntry to non-null
                                            Field currentEntryField = ArArchiveInputStream.class.getDeclaredField("currentEntry");
                                            currentEntryField.setAccessible(true);
                                            currentEntryField.set(arArchiveInputStream, new ArArchiveEntry("test", 100));
                                            
                                            // Call close
                                            arArchiveInputStream.close();
                                            
                                            // Verify input stream was closed
                                            verify(mockInputStream).close();
                                            
                                            // Verify closed flag is true
                                            assertTrue((boolean) closedField.get(arArchiveInputStream));
                                            
                                            // Verify currentEntry is null
                                            assertNull(currentEntryField.get(arArchiveInputStream));
                                        }

    @Test
                                        public void testCloseWhenAlreadyClosed() throws Exception {
                                            // Create mock input stream
                                            InputStream mockInputStream = mock(InputStream.class);
                                            
                                            // Create ArArchiveInputStream instance
                                            ArArchiveInputStream arArchiveInputStream = new ArArchiveInputStream(mockInputStream);
                                            
                                            // Set up closed state to true
                                            Field closedField = ArArchiveInputStream.class.getDeclaredField("closed");
                                            closedField.setAccessible(true);
                                            closedField.set(arArchiveInputStream, true);
                                    
                                            // Set currentEntry to non-null
                                            Field currentEntryField = ArArchiveInputStream.class.getDeclaredField("currentEntry");
                                            currentEntryField.setAccessible(true);
                                            currentEntryField.set(arArchiveInputStream, new ArArchiveEntry("test", 100));
                                    
                                            // Call close
                                            arArchiveInputStream.close();
                                    
                                            // Verify input stream was NOT closed
                                            verify(mockInputStream, never()).close();
                                    
                                            // Verify closed flag remains true
                                            assertTrue((boolean) closedField.get(arArchiveInputStream));
                                    
                                            // Verify currentEntry is null
                                            assertNull(currentEntryField.get(arArchiveInputStream));
                                        }

    @Test
                                        public void testCloseWithIOException() throws Exception {
                                            // Create mock input stream
                                            InputStream mockInputStream = mock(InputStream.class);
                                            
                                            // Create instance of ArArchiveInputStream
                                            ArArchiveInputStream arArchiveInputStream = new ArArchiveInputStream(mockInputStream);
                                            
                                            // Set up closed state to false
                                            Field closedField = ArArchiveInputStream.class.getDeclaredField("closed");
                                            closedField.setAccessible(true);
                                            closedField.set(arArchiveInputStream, false);
                                    
                                            // Make input stream throw IOException
                                            doThrow(new IOException()).when(mockInputStream).close();
                                    
                                            // Call close and expect IOException
                                            try {
                                                arArchiveInputStream.close();
                                                fail("Expected IOException");
                                            } catch (IOException e) {
                                                // expected
                                            }
                                    
                                            // Verify closed flag is still true despite the exception
                                            assertTrue((boolean) closedField.get(arArchiveInputStream));
                                    
                                            // Verify currentEntry is null
                                            Field currentEntryField = ArArchiveInputStream.class.getDeclaredField("currentEntry");
                                            currentEntryField.setAccessible(true);
                                            assertNull(currentEntryField.get(arArchiveInputStream));
                                        }

    @Test
                                        public void testCloseWithNullCurrentEntry() throws Exception {
                                            // Create mock input stream
                                            InputStream mockInputStream = mock(InputStream.class);
                                            
                                            // Create instance of ArArchiveInputStream
                                            ArArchiveInputStream arArchiveInputStream = new ArArchiveInputStream(mockInputStream);
                                            
                                            // Set up closed state to false
                                            Field closedField = ArArchiveInputStream.class.getDeclaredField("closed");
                                            closedField.setAccessible(true);
                                            closedField.set(arArchiveInputStream, false);
                                    
                                            // Ensure currentEntry is null
                                            Field currentEntryField = ArArchiveInputStream.class.getDeclaredField("currentEntry");
                                            currentEntryField.setAccessible(true);
                                            currentEntryField.set(arArchiveInputStream, null);
                                    
                                            // Call close
                                            arArchiveInputStream.close();
                                    
                                            // Verify input stream was closed
                                            verify(mockInputStream).close();
                                    
                                            // Verify closed flag is true
                                            assertTrue((boolean) closedField.get(arArchiveInputStream));
                                    
                                            // Verify currentEntry remains null
                                            assertNull(currentEntryField.get(arArchiveInputStream));
                                        }

    @Test
                                        public void testReadReturnsMinusOneWhenEOF() throws IOException {
                                            InputStream mockInputStream = mock(InputStream.class);
                                            ArArchiveInputStream arInputStream = new ArArchiveInputStream(mockInputStream);
                                            
                                            when(mockInputStream.read(any(byte[].class), eq(0), eq(1)))
                                                .thenReturn(-1);
                                            
                                            int result = arInputStream.read();
                                            assertEquals(-1, result);
                                        }

    @Test
                                        public void testReadWithCurrentEntryBoundary() throws IOException {
                                            ArArchiveEntry entry = new ArArchiveEntry("test", 1);
                                            ArArchiveInputStream arInputStream = new ArArchiveInputStream(new ByteArrayInputStream(new byte[]{0x12}));
                                            
                                            // Use reflection to set private fields
                                            try {
                                                java.lang.reflect.Field currentEntryField = ArArchiveInputStream.class
                                                    .getDeclaredField("currentEntry");
                                                currentEntryField.setAccessible(true);
                                                currentEntryField.set(arInputStream, entry);
                                        
                                                java.lang.reflect.Field entryOffsetField = ArArchiveInputStream.class
                                                    .getDeclaredField("entryOffset");
                                                entryOffsetField.setAccessible(true);
                                                entryOffsetField.set(arInputStream, 0L);
                                            } catch (Exception e) {
                                                fail("Reflection failed: " + e.getMessage());
                                            }
                                        
                                            int result = arInputStream.read();
                                            assertEquals(0x12, result);
                                            
                                            // Should return -1 when trying to read beyond entry boundary
                                            result = arInputStream.read();
                                            assertEquals(-1, result);
                                        }

    @Test
                                        public void testReadWithZeroLengthEntry() throws IOException {
                                            ArArchiveInputStream arInputStream = null;
                                            try {
                                                ArArchiveEntry entry = new ArArchiveEntry("test", 0);
                                                arInputStream = new ArArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                
                                                try {
                                                    java.lang.reflect.Field currentEntryField = ArArchiveInputStream.class
                                                        .getDeclaredField("currentEntry");
                                                    currentEntryField.setAccessible(true);
                                                    currentEntryField.set(arInputStream, entry);
                                        
                                                    java.lang.reflect.Field entryOffsetField = ArArchiveInputStream.class
                                                        .getDeclaredField("entryOffset");
                                                    entryOffsetField.setAccessible(true);
                                                    entryOffsetField.set(arInputStream, 0L);
                                                } catch (Exception e) {
                                                    org.junit.Assert.fail("Reflection failed: " + e.getMessage());
                                                }
                                        
                                                int result = arInputStream.read();
                                                org.junit.Assert.assertEquals(-1, result);
                                            } finally {
                                                if (arInputStream != null) {
                                                    arInputStream.close();
                                                }
                                            }
                                        }

    @Test
                                        public void testReadByteArray() throws IOException {
                                            InputStream mockInputStream = mock(InputStream.class);
                                            ArArchiveInputStream arInputStream = new ArArchiveInputStream(mockInputStream);
                                            byte[] testData = new byte[10];
                                            
                                            when(mockInputStream.read(testData, 0, 10)).thenReturn(10);
                                            
                                            int result = arInputStream.read(testData);
                                            
                                            assertEquals(10, result);
                                            verify(mockInputStream).read(testData, 0, 10);
                                        }

    @Test
                                        public void testReadByteArrayWithEmptyArray() throws IOException {
                                            byte[] emptyArray = new byte[0];
                                            java.io.InputStream mockInputStream = mock(java.io.InputStream.class);
                                            ArArchiveInputStream arInputStream = new ArArchiveInputStream(mockInputStream);
                                            
                                            int result = arInputStream.read(emptyArray);
                                            
                                            assertEquals(0, result);
                                            verify(mockInputStream, never()).read(any(), anyInt(), anyInt());
                                        }

    @Test
                                        public void testReadByteArrayWithCurrentEntry() throws IOException {
                                            // Create mock objects
                                            InputStream mockInputStream = mock(InputStream.class);
                                            ArArchiveInputStream arInputStream = new ArArchiveInputStream(mockInputStream);
                                            
                                            byte[] testData = new byte[10];
                                            ArArchiveEntry entry = new ArArchiveEntry("test", 5);
                                            
                                            // Use reflection to set private fields
                                            try {
                                                java.lang.reflect.Field currentEntryField = ArArchiveInputStream.class.getDeclaredField("currentEntry");
                                                currentEntryField.setAccessible(true);
                                                currentEntryField.set(arInputStream, entry);
                                                
                                                java.lang.reflect.Field entryOffsetField = ArArchiveInputStream.class.getDeclaredField("entryOffset");
                                                entryOffsetField.setAccessible(true);
                                                entryOffsetField.set(arInputStream, 0L);
                                                
                                                java.lang.reflect.Field offsetField = ArArchiveInputStream.class.getDeclaredField("offset");
                                                offsetField.setAccessible(true);
                                                offsetField.set(arInputStream, 0L);
                                            } catch (Exception e) {
                                                fail("Failed to set private fields via reflection");
                                            }
                                            
                                            when(mockInputStream.read(testData, 0, 5)).thenReturn(5);
                                            
                                            int result = arInputStream.read(testData);
                                            
                                            assertEquals(5, result);
                                            verify(mockInputStream).read(testData, 0, 5);
                                        }

    @Test
                                        public void testReadByteArrayWithCurrentEntryAtEnd() throws IOException {
                                            // Create mock objects
                                            InputStream mockInputStream = mock(InputStream.class);
                                            ArArchiveInputStream arInputStream = new ArArchiveInputStream(mockInputStream);
                                            
                                            byte[] testData = new byte[10];
                                            ArArchiveEntry entry = new ArArchiveEntry("test", 5);
                                            
                                            // Use reflection to set private fields
                                            try {
                                                java.lang.reflect.Field currentEntryField = ArArchiveInputStream.class.getDeclaredField("currentEntry");
                                                currentEntryField.setAccessible(true);
                                                currentEntryField.set(arInputStream, entry);
                                                
                                                java.lang.reflect.Field entryOffsetField = ArArchiveInputStream.class.getDeclaredField("entryOffset");
                                                entryOffsetField.setAccessible(true);
                                                entryOffsetField.set(arInputStream, 0L);
                                                
                                                java.lang.reflect.Field offsetField = ArArchiveInputStream.class.getDeclaredField("offset");
                                                offsetField.setAccessible(true);
                                                offsetField.set(arInputStream, 5L);
                                            } catch (Exception e) {
                                                fail("Failed to set private fields via reflection");
                                            }
                                            
                                            int result = arInputStream.read(testData);
                                            
                                            assertEquals(-1, result);
                                            verify(mockInputStream, never()).read(any(), anyInt(), anyInt());
                                        }

    @Test(expected = IOException.class)
                                        public void testReadByteArrayThrowsIOException() throws IOException {
                                            InputStream mockInputStream = mock(InputStream.class);
                                            ArArchiveInputStream arInputStream = new ArArchiveInputStream(mockInputStream);
                                            byte[] testData = new byte[10];
                                            
                                            when(mockInputStream.read(testData, 0, 10)).thenThrow(new IOException());
                                            
                                            arInputStream.read(testData);
                                        }

    @Test
                                        public void testReadWithCurrentEntryAtBoundary() throws Exception {
                                            // Setup mocks
                                            ArArchiveEntry mockEntry = mock(ArArchiveEntry.class);
                                            InputStream mockInputStream = mock(InputStream.class);
                                            
                                            // Create test instance - you may need to adjust this based on actual constructor
                                            ArArchiveInputStream arArchiveInputStream = new ArArchiveInputStream(mockInputStream);
                                            
                                            // Use reflection to set private fields
                                            java.lang.reflect.Field currentEntryField = ArArchiveInputStream.class.getDeclaredField("currentEntry");
                                            currentEntryField.setAccessible(true);
                                            currentEntryField.set(arArchiveInputStream, mockEntry);
                                            
                                            java.lang.reflect.Field entryOffsetField = ArArchiveInputStream.class.getDeclaredField("entryOffset");
                                            entryOffsetField.setAccessible(true);
                                            entryOffsetField.set(arArchiveInputStream, 0L);
                                            
                                            java.lang.reflect.Field offsetField = ArArchiveInputStream.class.getDeclaredField("offset");
                                            offsetField.setAccessible(true);
                                            offsetField.set(arArchiveInputStream, 15L);
                                            
                                            // Configure mocks
                                            when(mockEntry.getLength()).thenReturn(20L);
                                            when(mockInputStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(5);
                                            
                                            // Test
                                            byte[] buffer = new byte[10];
                                            int result = arArchiveInputStream.read(buffer, 0, 10);
                                            
                                            // Verify
                                            assertEquals(5, result);
                                            verify(mockInputStream).read(buffer, 0, 5);
                                        }

    @Test
                                        public void testReadWithCurrentEntryBeyondBounds() throws Exception {
                                            // Setup mocks
                                            InputStream mockInputStream = mock(InputStream.class);
                                            ArArchiveEntry mockEntry = mock(ArArchiveEntry.class);
                                            ArArchiveInputStream arArchiveInputStream = new ArArchiveInputStream(mockInputStream);
                                            
                                            // Use reflection to set private fields
                                            Field currentEntryField = ArArchiveInputStream.class.getDeclaredField("currentEntry");
                                            currentEntryField.setAccessible(true);
                                            currentEntryField.set(arArchiveInputStream, mockEntry);
                                            
                                            Field entryOffsetField = ArArchiveInputStream.class.getDeclaredField("entryOffset");
                                            entryOffsetField.setAccessible(true);
                                            entryOffsetField.set(arArchiveInputStream, 0L);
                                            
                                            Field offsetField = ArArchiveInputStream.class.getDeclaredField("offset");
                                            offsetField.setAccessible(true);
                                            offsetField.set(arArchiveInputStream, 20L);
                                            
                                            byte[] buffer = new byte[10];
                                            when(mockEntry.getLength()).thenReturn(20L);
                                            
                                            int result = arArchiveInputStream.read(buffer, 0, 10);
                                            
                                            assertEquals(-1, result);
                                            verify(mockInputStream, never()).read(any(), anyInt(), anyInt());
                                        }

    @Test
                                        public void testReadWithCurrentEntryAndZeroLength() throws Exception {
                                            // Setup mocks
                                            InputStream mockInputStream = mock(InputStream.class);
                                            ArArchiveEntry mockEntry = mock(ArArchiveEntry.class);
                                            ArArchiveInputStream arArchiveInputStream = new ArArchiveInputStream(mockInputStream);
                                            
                                            // Use reflection to set private fields
                                            java.lang.reflect.Field currentEntryField = ArArchiveInputStream.class.getDeclaredField("currentEntry");
                                            currentEntryField.setAccessible(true);
                                            currentEntryField.set(arArchiveInputStream, mockEntry);
                                            
                                            java.lang.reflect.Field entryOffsetField = ArArchiveInputStream.class.getDeclaredField("entryOffset");
                                            entryOffsetField.setAccessible(true);
                                            entryOffsetField.set(arArchiveInputStream, 0L);
                                            
                                            java.lang.reflect.Field offsetField = ArArchiveInputStream.class.getDeclaredField("offset");
                                            offsetField.setAccessible(true);
                                            offsetField.set(arArchiveInputStream, 5L);
                                    
                                            // Test
                                            byte[] buffer = new byte[10];
                                            when(mockEntry.getLength()).thenReturn(20L);
                                            
                                            int result = arArchiveInputStream.read(buffer, 0, 0);
                                            
                                            assertEquals(-1, result);
                                            verify(mockInputStream, never()).read(any(), anyInt(), anyInt());
                                        }

    @Test
                                    public void testReadWithCurrentEntryWithinBounds() throws Exception {
                                        // Create mocks
                                        ArArchiveEntry mockEntry = mock(ArArchiveEntry.class);
                                        InputStream mockInputStream = mock(InputStream.class);
                                        
                                        // Create instance and inject mocks using reflection
                                        ArArchiveInputStream arArchiveInputStream = new ArArchiveInputStream(mockInputStream);
                                        
                                        // Set private fields using reflection
                                        Field currentEntryField = ArArchiveInputStream.class.getDeclaredField("currentEntry");
                                        currentEntryField.setAccessible(true);
                                        currentEntryField.set(arArchiveInputStream, mockEntry);
                                        
                                        Field entryOffsetField = ArArchiveInputStream.class.getDeclaredField("entryOffset");
                                        entryOffsetField.setAccessible(true);
                                        entryOffsetField.set(arArchiveInputStream, 0L);
                                        
                                        Field offsetField = ArArchiveInputStream.class.getDeclaredField("offset");
                                        offsetField.setAccessible(true);
                                        offsetField.set(arArchiveInputStream, 5L);
                                        
                                        // Configure mocks
                                        when(mockEntry.getLength()).thenReturn(20L);
                                        when(mockInputStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(5);
                                        
                                        // Test
                                        byte[] buffer = new byte[10];
                                        int result = arArchiveInputStream.read(buffer, 0, 10);
                                        
                                        // Verify
                                        assertEquals(5, result);
                                        verify(mockInputStream).read(buffer, 0, 5);
                                    }

    @Test
                            public void testGetNextArEntryWithValidData() throws Exception {
                                String entryName = "test.txt";
                                String entryLength = "100";
                                byte[] header = ArArchiveEntry.HEADER.getBytes();
                                byte[] name = String.format("%-16s", entryName).getBytes();
                                byte[] length = String.format("%-10s", entryLength).getBytes();
                                byte[] trailer = ArArchiveEntry.TRAILER.getBytes();
                                
                                byte[] testData = new byte[header.length + name.length + length.length + trailer.length];
                                System.arraycopy(header, 0, testData, 0, header.length);
                                System.arraycopy(name, 0, testData, header.length, name.length);
                                System.arraycopy(length, 0, testData, header.length + name.length, length.length);
                                System.arraycopy(trailer, 0, testData, header.length + name.length + length.length, trailer.length);
                                
                                InputStream is = new ByteArrayInputStream(testData);
                                ArArchiveInputStream arInputStream = new ArArchiveInputStream(is);
                                
                                ArArchiveEntry entry = arInputStream.getNextArEntry();
                                assertNotNull(entry);
                                assertEquals(entryName, entry.getName());
                                assertEquals(Long.parseLong(entryLength), entry.getLength());
                            }

    @Test
                            public void testGetNextArEntryWithInvalidEntryHeader() throws Exception {
                                byte[] header = "!<arch>\n".getBytes(); // Using the actual header value
                                byte[] invalidTrailer = "invalid".getBytes();
                                byte[] testData = new byte[header.length + invalidTrailer.length];
                                System.arraycopy(header, 0, testData, 0, header.length);
                                System.arraycopy(invalidTrailer, 0, testData, header.length, invalidTrailer.length);
                                
                                InputStream is = new ByteArrayInputStream(testData);
                                ArArchiveInputStream arInputStream = new ArArchiveInputStream(is);
                                
                                try {
                                    arInputStream.getNextArEntry();
                                    fail("Expected IOException");
                                } catch (IOException e) {
                                    assertTrue(e.getMessage().contains("failed to read entry header"));
                                }
                            }

    @Test
                            public void testReadWithNegativeReturnValue() throws IOException {
                                // Setup mocks and test objects
                                java.io.InputStream mockInputStream = mock(java.io.InputStream.class);
                                ArArchiveEntry mockEntry = mock(ArArchiveEntry.class);
                                
                                // Create test instance
                                ArArchiveInputStream arArchiveInputStream = new ArArchiveInputStream(mockInputStream);
                                
                                // Set up test data
                                byte[] buffer = new byte[10];
                                when(mockEntry.getLength()).thenReturn(20L);
                                
                                // Use reflection to set private field
                                try {
                                    java.lang.reflect.Field entryField = ArArchiveInputStream.class.getDeclaredField("currentEntry");
                                    entryField.setAccessible(true);
                                    entryField.set(arArchiveInputStream, mockEntry);
                                    
                                    java.lang.reflect.Field offsetField = ArArchiveInputStream.class.getDeclaredField("offset");
                                    offsetField.setAccessible(true);
                                    offsetField.set(arArchiveInputStream, 0L);
                                    
                                    java.lang.reflect.Field entryOffsetField = ArArchiveInputStream.class.getDeclaredField("entryOffset");
                                    entryOffsetField.setAccessible(true);
                                    entryOffsetField.set(arArchiveInputStream, 0L);
                                } catch (Exception e) {
                                    fail("Failed to set private fields via reflection");
                                }
                                
                                // Mock behavior
                                when(mockInputStream.read(buffer, 0, 10)).thenReturn(-1);
                                
                                // Execute test
                                int result = arArchiveInputStream.read(buffer, 0, 10);
                                
                                // Verify results
                                assertEquals(-1, result);
                                
                                // Verify bytes read (using reflection to get private field)
                                try {
                                    java.lang.reflect.Field bytesReadField = ArArchiveInputStream.class.getDeclaredField("bytesRead");
                                    bytesReadField.setAccessible(true);
                                    long bytesRead = (long) bytesReadField.get(arArchiveInputStream);
                                    assertEquals(0, bytesRead);
                                } catch (Exception e) {
                                    fail("Failed to get bytesRead via reflection");
                                }
                            }

    @Test
                            public void testReadWithZeroReturnValue() throws IOException {
                                // Setup mocks and test objects
                                InputStream mockInputStream = mock(InputStream.class);
                                ArArchiveEntry mockEntry = mock(ArArchiveEntry.class);
                                
                                // Create test instance
                                ArArchiveInputStream arArchiveInputStream = new ArArchiveInputStream(mockInputStream);
                                
                                // Set up test data
                                byte[] buffer = new byte[10];
                                when(mockEntry.getLength()).thenReturn(20L);
                                when(mockInputStream.read(buffer, 0, 10)).thenReturn(0);
                                
                                // Use reflection to set private field
                                try {
                                    java.lang.reflect.Field entryField = ArArchiveInputStream.class.getDeclaredField("currentEntry");
                                    entryField.setAccessible(true);
                                    entryField.set(arArchiveInputStream, mockEntry);
                                    
                                    java.lang.reflect.Field offsetField = ArArchiveInputStream.class.getDeclaredField("offset");
                                    offsetField.setAccessible(true);
                                    offsetField.set(arArchiveInputStream, 0L);
                                    
                                    java.lang.reflect.Field entryOffsetField = ArArchiveInputStream.class.getDeclaredField("entryOffset");
                                    entryOffsetField.setAccessible(true);
                                    entryOffsetField.set(arArchiveInputStream, 0L);
                                } catch (Exception e) {
                                    fail("Failed to set private fields via reflection");
                                }
                                
                                // Execute test
                                int result = arArchiveInputStream.read(buffer, 0, 10);
                                
                                // Verify results
                                assertEquals(0, result);
                                
                                // Verify bytes read
                                try {
                                    java.lang.reflect.Field bytesReadField = ArArchiveInputStream.class.getDeclaredField("offset");
                                    bytesReadField.setAccessible(true);
                                    assertEquals(0L, bytesReadField.get(arArchiveInputStream));
                                } catch (Exception e) {
                                    fail("Failed to get private field via reflection");
                                }
                            }

    @Test
                            public void testReadWithNoCurrentEntry() throws IOException, NoSuchFieldException, IllegalAccessException {
                                // Setup
                                InputStream mockInputStream = mock(InputStream.class);
                                ArArchiveInputStream arArchiveInputStream = new ArArchiveInputStream(mockInputStream);
                                
                                // Use reflection to set private currentEntry field to null
                                Field currentEntryField = ArArchiveInputStream.class.getDeclaredField("currentEntry");
                                currentEntryField.setAccessible(true);
                                currentEntryField.set(arArchiveInputStream, null);
                                
                                byte[] buffer = new byte[10];
                                when(mockInputStream.read(buffer, 0, 10)).thenReturn(5);
                                
                                // Test
                                int result = arArchiveInputStream.read(buffer, 0, 10);
                                
                                // Verify
                                assertEquals(5, result);
                                verify(mockInputStream).read(buffer, 0, 10);
                            }

    @Test(expected = IOException.class)
            public void testReadThrowsIOException1() throws IOException {
                InputStream mockInputStream = mock(InputStream.class);
                ArArchiveInputStream arInputStream = new ArArchiveInputStream(mockInputStream);
                
                when(mockInputStream.read(any(byte[].class), eq(0), eq(1)))
                    .thenThrow(new IOException("Test exception"));
                
                arInputStream.read();
            }

    @Test(expected = IOException.class)
        public void testReadThrowsIOException() throws IOException {
            InputStream mockInputStream = mock(InputStream.class);
            ArArchiveInputStream arInputStream = new ArArchiveInputStream(mockInputStream);
            
            when(mockInputStream.read(any(byte[].class), anyInt(), anyInt()))
                .thenThrow(new IOException("Test exception"));
            
            arInputStream.read();
        }

    @Test
        public void testReadReturnsByteWhenDataAvailable() throws IOException {
            InputStream mockInputStream = mock(InputStream.class);
            ArArchiveInputStream arInputStream = new ArArchiveInputStream(mockInputStream);
            
            final byte testByte = (byte) 0xAB;
            when(mockInputStream.read(any(byte[].class), eq(0), eq(1)))
                .thenAnswer(invocation -> {
                    byte[] buf = (byte[]) invocation.getArguments()[0];
                    buf[0] = testByte;
                    return 1;
                });
            
            int result = arInputStream.read();
            assertEquals(0xAB, result);
        }


}
