package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                public void testVerifyCheckSumWithEmptyHeader() {
                                                    byte[] header = new byte[0];
                                                    assertFalse(TarUtils.verifyCheckSum(header));
                                                }

    @Test
                                                public void testVerifyCheckSumWithNullHeader() {
                                                    assertFalse(TarUtils.verifyCheckSum(null));
                                                }

    @Test
                                                public void testVerifyCheckSumWithAllZeroHeader() {
                                                    byte[] header = new byte[512];
                                                    // Checksum field will be parsed as 0
                                                    assertTrue(TarUtils.verifyCheckSum(header));
                                                }

    @Test
                                            public void testVerifyCheckSumWithValidUnsignedSum() {
                                                // Define constants that were missing
                                                final int CHKSUM_OFFSET = 148;
                                                final int CHKSUMLEN = 8;
                                                
                                                byte[] header = new byte[512];
                                                // Set up a header with checksum field (8 bytes) at CHKSUM_OFFSET
                                                long expectedSum = 12345L;
                                                TarUtils.formatOctalBytes(expectedSum, header, CHKSUM_OFFSET, CHKSUMLEN);
                                                
                                                // Calculate unsigned sum (treating bytes as unsigned)
                                                long unsignedSum = 0;
                                                for (int i = 0; i < header.length; i++) {
                                                    byte b = header[i];
                                                    if (CHKSUM_OFFSET <= i && i < CHKSUM_OFFSET + CHKSUMLEN) {
                                                        b = ' ';
                                                    }
                                                    unsignedSum += 0xff & b;
                                                }
                                                
                                                // Modify header to have the correct checksum
                                                TarUtils.formatOctalBytes(unsignedSum, header, CHKSUM_OFFSET, CHKSUMLEN);
                                                
                                                assertTrue(TarUtils.verifyCheckSum(header));
                                            }

    @Test
                                            public void testVerifyCheckSumWithValidSignedSum() {
                                                // Define constants that were missing
                                                final int CHKSUM_OFFSET = 148;
                                                final int CHKSUMLEN = 8;
                                                
                                                byte[] header = new byte[512];
                                                // Set up a header with checksum field (8 bytes) at CHKSUM_OFFSET
                                                long expectedSum = -12345L; // Negative to test signed case
                                                TarUtils.formatOctalBytes(Math.abs(expectedSum), header, CHKSUM_OFFSET, CHKSUMLEN);
                                                
                                                // Calculate signed sum (treating bytes as signed)
                                                long signedSum = 0;
                                                for (int i = 0; i < header.length; i++) {
                                                    byte b = header[i];
                                                    if (CHKSUM_OFFSET <= i && i < CHKSUM_OFFSET + CHKSUMLEN) {
                                                        b = ' ';
                                                    }
                                                    signedSum += b;
                                                }
                                                
                                                // Modify header to have the correct checksum
                                                TarUtils.formatOctalBytes(signedSum, header, CHKSUM_OFFSET, CHKSUMLEN);
                                                
                                                assertTrue(TarUtils.verifyCheckSum(header));
                                            }

    @Test
                                            public void testVerifyCheckSumWithInvalidSum() {
                                                // Define constants that were missing
                                                final int CHKSUM_OFFSET = 148;
                                                final int CHKSUMLEN = 8;
                                                
                                                byte[] header = new byte[512];
                                                // Set checksum to a value that won't match either signed or unsigned sum
                                                TarUtils.formatOctalBytes(999999L, header, CHKSUM_OFFSET, CHKSUMLEN);
                                                
                                                assertFalse(TarUtils.verifyCheckSum(header));
                                            }

    @Test
                                            public void testVerifyCheckSumWithOnlyChecksumField() {
                                                final int CHKSUMLEN = 8;
                                                final int CHKSUM_OFFSET = 0;
                                                
                                                byte[] header = new byte[CHKSUMLEN];
                                                long expectedSum = 12345L;
                                                org.apache.commons.compress.archivers.tar.TarUtils.formatOctalBytes(expectedSum, header, 0, CHKSUMLEN);
                                                
                                                // Calculate unsigned sum (all bytes are checksum field, so they'll be treated as spaces)
                                                long unsignedSum = 0;
                                                for (int i = 0; i < header.length; i++) {
                                                    unsignedSum += 0xff & ' ';
                                                }
                                                
                                                // Modify header to have the correct checksum
                                                org.apache.commons.compress.archivers.tar.TarUtils.formatOctalBytes(unsignedSum, header, 0, CHKSUMLEN);
                                                
                                                assertTrue(org.apache.commons.compress.archivers.tar.TarUtils.verifyCheckSum(header));
                                            }

    @Test
                                            public void testVerifyCheckSumWithNegativeSignedSumMatch() {
                                                final int CHKSUM_OFFSET = 148;
                                                final int CHKSUMLEN = 8;
                                                
                                                byte[] header = new byte[512];
                                                // Fill header with negative bytes to get negative signed sum
                                                for (int i = 0; i < header.length; i++) {
                                                    if (CHKSUM_OFFSET <= i && i < CHKSUM_OFFSET + CHKSUMLEN) {
                                                        header[i] = ' ';
                                                    } else {
                                                        header[i] = (byte) 0xFF; // -1 when treated as signed
                                                    }
                                                }
                                                
                                                // Calculate signed sum
                                                long signedSum = 0;
                                                for (int i = 0; i < header.length; i++) {
                                                    byte b = header[i];
                                                    if (CHKSUM_OFFSET <= i && i < CHKSUM_OFFSET + CHKSUMLEN) {
                                                        b = ' ';
                                                    }
                                                    signedSum += b;
                                                }
                                                
                                                // Set checksum to match signed sum
                                                TarUtils.formatOctalBytes(signedSum, header, CHKSUM_OFFSET, CHKSUMLEN);
                                                
                                                assertTrue(TarUtils.verifyCheckSum(header));
                                            }


}
