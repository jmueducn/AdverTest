package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                public void testParseOctalWithValidInput() {
                                                    byte[] buffer = {' ', ' ', '1', '2', '3', ' ', 0};
                                                    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                    assertEquals(83L, result); // 1*64 + 2*8 + 3 = 83
                                                }

    @Test
                                                public void testParseOctalWithLeadingZero() {
                                                    byte[] buffer = {0, '1', '2', '3', ' ', 0};
                                                    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                    assertEquals(0L, result);
                                                }

    @Test
                                                public void testParseOctalWithOnlySpaces() {
                                                    byte[] buffer = {' ', ' ', ' ', ' ', 0};
                                                    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                    assertEquals(0L, result);
                                                }

    @Test(expected = IllegalArgumentException.class)
                                                public void testParseOctalWithInvalidTrailer() {
                                                    byte[] buffer = {'1', '2', '3', '4'}; // No trailing space or NUL
                                                    TarUtils.parseOctal(buffer, 0, buffer.length);
                                                }

    @Test(expected = IllegalArgumentException.class)
                                                public void testParseOctalWithInvalidDigit() {
                                                    byte[] buffer = {'1', '2', '8', ' ', 0}; // '8' is invalid in octal
                                                    TarUtils.parseOctal(buffer, 0, buffer.length);
                                                }

    @Test(expected = IllegalArgumentException.class)
                                                public void testParseOctalWithLengthLessThan() {
                                                    byte[] buffer = {'1', 0};
                                                    TarUtils.parseOctal(buffer, 0, 1); // length=1
                                                }

    @Test
                                                public void testParseOctalWithMultipleTrailingSpaces() {
                                                    byte[] buffer = {'1', '2', ' ', ' ', 0};
                                                    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                    assertEquals(10L, result); // 1*8 + 2 = 10
                                                }

    @Test
                                                public void testParseOctalWithTrailingNUL() {
                                                    byte[] buffer = {'1', '2', '3', 0};
                                                    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                    assertEquals(83L, result);
                                                }

    @Test
                                                public void testParseOctalWithMultipleLeadingSpaces() {
                                                    byte[] buffer = {' ', ' ', ' ', '1', '2', ' ', 0};
                                                    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                    assertEquals(10L, result);
                                                }

    @Test
                                                public void testParseOctalWithMaxOctalValue() {
                                                    byte[] buffer = {'7', '7', '7', ' ', 0};
                                                    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                    assertEquals(511L, result); // 7*64 + 7*8 + 7 = 511
                                                }

    @Test
                                                public void testParseOctalWithSingleDigit() {
                                                    byte[] buffer = {'5', ' ', 0};
                                                    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                    assertEquals(5L, result);
                                                }

    @Test
                                                public void testParseOctalWithOffset() {
                                                    byte[] buffer = {'x', 'x', '1', '2', '3', ' ', 0};
                                                    long result = TarUtils.parseOctal(buffer, 2, 4);
                                                    assertEquals(83L, result);
                                                }

    @Test(expected = IllegalArgumentException.class)
                                                public void testParseOctalWithInvalidCharacter() {
                                                    byte[] buffer = {'1', 'a', '3', ' ', 0};
                                                    TarUtils.parseOctal(buffer, 0, buffer.length);
                                                }

    @Test
                                                public void testParseOctalWithAllNULs() {
                                                    byte[] buffer = {0, 0, 0, 0, 0};
                                                    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                    assertEquals(0L, result);
                                                }

    @Test
                                                public void testParseOctalWithTrailingSpaceAndNUL() {
                                                    byte[] buffer = {'1', '2', ' ', 0, 0};
                                                    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                    assertEquals(10L, result);
                                                }

    @Test
                                                public void testExceptionMessage() throws Exception {
                                                    byte[] buffer = {'1', 'a', '3', 'x'};
                                                    Method method = TarUtils.class.getDeclaredMethod("exceptionMessage", 
                                                        byte[].class, int.class, int.class, int.class, byte.class);
                                                    method.setAccessible(true);
                                                    
                                                    String message = (String) method.invoke(null, 
                                                        buffer, 0, buffer.length, 1, (byte)'a');
                                                    assertTrue(message.contains("Invalid byte"));
                                                    assertTrue(message.contains("at offset 1"));
                                                }


}
