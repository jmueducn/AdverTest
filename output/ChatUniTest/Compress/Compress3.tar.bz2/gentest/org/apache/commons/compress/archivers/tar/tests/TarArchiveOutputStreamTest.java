package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
 
public class TarArchiveOutputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                    public void testFinishWithUnclosedEntry() throws Exception {
                                        OutputStream mockOutputStream = mock(OutputStream.class);
                                        TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOutputStream);
                                        
                                        Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                        haveUnclosedEntryField.setAccessible(true);
                                        haveUnclosedEntryField.set(tarOut, true);
                                
                                        try {
                                            tarOut.finish();
                                            fail("Expected IOException");
                                        } catch (IOException e) {
                                            assertEquals("This archives contains unclosed entries.", e.getMessage());
                                        }
                                    }

    @Test
                                    public void testWriteEOFRecord() throws Exception {
                                        OutputStream mockOutputStream = mock(OutputStream.class);
                                        TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOutputStream);
                                        
                                        // Get the private writeEOFRecord method
                                        Method writeEOFRecord = TarArchiveOutputStream.class.getDeclaredMethod("writeEOFRecord");
                                        writeEOFRecord.setAccessible(true);
                                        
                                        // Get the recordBuf field
                                        Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                        recordBufField.setAccessible(true);
                                        byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                        
                                        // Initialize with non-zero values
                                        for (int i = 0; i < recordBuf.length; i++) {
                                            recordBuf[i] = 1;
                                        }
                                        
                                        // Invoke the method
                                        writeEOFRecord.invoke(tarOut);
                                        
                                        // Verify all bytes are zero
                                        for (byte b : recordBuf) {
                                            assertEquals(0, b);
                                        }
                                        
                                        // Verify buffer.writeRecord was called
                                        Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                        bufferField.setAccessible(true);
                                        Object buffer = bufferField.get(tarOut);
                                        Method writeRecord = buffer.getClass().getDeclaredMethod("writeRecord", byte[].class);
                                        writeRecord.setAccessible(true);
                                        
                                        // Mock the buffer's writeRecord method
                                        Object mockBuffer = mock(buffer.getClass());
                                        bufferField.set(tarOut, mockBuffer);
                                        when(mockBuffer.getClass().getDeclaredMethod("writeRecord", byte[].class).invoke(mockBuffer, recordBuf))
                                            .thenReturn(null);
                                        
                                        writeEOFRecord.invoke(tarOut);
                                        verify(mockBuffer.getClass().getDeclaredMethod("writeRecord", byte[].class), times(1))
                                            .invoke(mockBuffer, recordBuf);
                                    }

    @Test
                                    public void testPutArchiveEntryWithLongNameInErrorMode() throws Exception {
                                        TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(null);
                                        TarArchiveEntry longNameEntry = new TarArchiveEntry("this_is_a_very_long_file_name_that_exceeds_the_tar_name_limit_of_100_characters_which_should_trigger_an_exception_in_error_mode");
                                        
                                        thrown.expect(RuntimeException.class);
                                        thrown.expectMessage("file name 'this_is_a_very_long_file_name_that_exceeds_the_tar_name_limit_of_100_characters_which_should_trigger_an_exception_in_error_mode' is too long ( > " + TarConstants.NAMELEN + " bytes)");
                                        
                                        tarOutputStream.setLongFileMode(TarArchiveOutputStream.LONGFILE_ERROR);
                                        tarOutputStream.putArchiveEntry(longNameEntry);
                                    }

    @Test
                                    public void testPutArchiveEntryWithLongNameInGnuModeWritesCorrectData() throws Exception {
                                        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                                        TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(outputStream);
                                        
                                        tarOutputStream.setLongFileMode(TarArchiveOutputStream.LONGFILE_GNU);
                                        
                                        // Create a real entry with a long name
                                        TarArchiveEntry realLongEntry = new TarArchiveEntry("this_is_a_very_long_file_name_that_exceeds_the_tar_name_limit_of_100_characters.txt");
                                        
                                        // Use reflection to get private write method
                                        Method writeMethod = TarArchiveOutputStream.class.getDeclaredMethod("write", int.class);
                                        writeMethod.setAccessible(true);
                                        
                                        // Replace buffer with real output stream to verify writes
                                        Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                        bufferField.setAccessible(true);
                                        
                                        Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                        recordBufField.setAccessible(true);
                                        byte[] recordBuf = (byte[]) recordBufField.get(tarOutputStream);
                                        
                                        Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                        currBytesField.setAccessible(true);
                                        
                                        Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                        currSizeField.setAccessible(true);
                                        
                                        Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                        currNameField.setAccessible(true);
                                        
                                        Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                        haveUnclosedEntryField.setAccessible(true);
                                        
                                        tarOutputStream.putArchiveEntry(realLongEntry);
                                        
                                        byte[] output = outputStream.toByteArray();
                                        assertTrue(output.length > 0);
                                        assertTrue(new String(output).contains("this_is_a_very_long_file_name"));
                                    }

    @Test(expected = ClassCastException.class)
                                public void testPutArchiveEntryWithNonTarEntry() throws Exception {
                                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                                    TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(byteArrayOutputStream);
                                    ArchiveEntry nonTarEntry = mock(ArchiveEntry.class);
                                    tarOutputStream.putArchiveEntry(nonTarEntry);
                                }

    @Test
                                public void testPutArchiveEntryWithLongNameInGnuMode() throws Exception {
                                    // Setup mocks and test objects
                                    ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                                    TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(buffer);
                                    TarArchiveEntry longNameEntry = mock(TarArchiveEntry.class);
                                    
                                    // Configure mocks
                                    when(longNameEntry.getName()).thenReturn(new String(new char[TarConstants.NAMELEN + 1]).replace('\0', 'a'));
                                    when(longNameEntry.isDirectory()).thenReturn(false);
                                    when(longNameEntry.getSize()).thenReturn(0L);
                                    
                                    // Set long file mode
                                    tarOutputStream.setLongFileMode(TarArchiveOutputStream.LONGFILE_GNU);
                                    
                                    // Test the method
                                    tarOutputStream.putArchiveEntry(longNameEntry);
                                    
                                    // Verify interactions
                                    verify(longNameEntry, times(2)).writeEntryHeader(any(byte[].class));
                                    
                                    // Use reflection to verify internal state
                                    Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                    currBytesField.setAccessible(true);
                                    assertEquals(0L, currBytesField.get(tarOutputStream));
                                }

    @Test
                                public void testCloseArchiveEntryWithIncompleteData() throws Exception {
                                    // Create test objects
                                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                                    TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(byteArrayOutputStream);
                                    
                                    // Create test entry
                                    TarArchiveEntry entry = new TarArchiveEntry("testEntry");
                                    tarOutputStream.putArchiveEntry(entry);
                                    
                                    // Set up test data using reflection
                                    Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                    assemLenField.setAccessible(true);
                                    assemLenField.set(tarOutputStream, 0);
                                    
                                    Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                    currBytesField.setAccessible(true);
                                    currBytesField.set(tarOutputStream, 50L);
                                    
                                    Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                    currSizeField.setAccessible(true);
                                    currSizeField.set(tarOutputStream, 100L);
                                    
                                    Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                    currNameField.setAccessible(true);
                                    currNameField.set(tarOutputStream, "testEntry");
                                    
                                    Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                    haveUnclosedEntryField.setAccessible(true);
                                    haveUnclosedEntryField.set(tarOutputStream, true);
                                
                                    // Execute
                                    tarOutputStream.closeArchiveEntry();
                                }

    @Test
                                public void testCloseArchiveEntryWithExactBytes() throws Exception {
                                    // Create mock objects and test instance
                                    byte[] assemBuf = new byte[512];
                                    ByteArrayOutputStream mockBuffer = mock(ByteArrayOutputStream.class);
                                    TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(null);
                                    
                                    // Set up test data using reflection
                                    Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                    assemBufField.setAccessible(true);
                                    assemBufField.set(tarOutputStream, assemBuf);
                                    
                                    Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                    bufferField.setAccessible(true);
                                    bufferField.set(tarOutputStream, mockBuffer);
                                    
                                    Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                    assemLenField.setAccessible(true);
                                    assemLenField.set(tarOutputStream, 0);
                                    
                                    Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                    currBytesField.setAccessible(true);
                                    currBytesField.set(tarOutputStream, 100L);
                                    
                                    Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                    currSizeField.setAccessible(true);
                                    currSizeField.set(tarOutputStream, 100L);
                                    
                                    Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                    haveUnclosedEntryField.setAccessible(true);
                                    haveUnclosedEntryField.set(tarOutputStream, true);
                                
                                    // Execute
                                    tarOutputStream.closeArchiveEntry();
                                
                                    // Verify
                                    verify(mockBuffer, never()).write(assemBuf);
                                    assertFalse(haveUnclosedEntryField.getBoolean(tarOutputStream));
                                }

    @Test
                            public void testCloseArchiveEntryWithoutAssembledData() throws Exception {
                                // Create mock objects
                                ByteArrayOutputStream mockByteArrayOutputStream = mock(ByteArrayOutputStream.class);
                                byte[] assemBuf = new byte[512];
                                
                                // Create real output stream with mock buffer
                                TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(null);
                                Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                bufferField.setAccessible(true);
                                bufferField.set(tarOutputStream, mockByteArrayOutputStream);
                                
                                Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                assemBufField.setAccessible(true);
                                assemBufField.set(tarOutputStream, assemBuf);
                            
                                // Set up test data
                                Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                assemLenField.setAccessible(true);
                                assemLenField.set(tarOutputStream, 0);
                                
                                Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                currBytesField.setAccessible(true);
                                currBytesField.set(tarOutputStream, 100L);
                                
                                Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                currSizeField.setAccessible(true);
                                currSizeField.set(tarOutputStream, 100L);
                                
                                Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                haveUnclosedEntryField.setAccessible(true);
                                haveUnclosedEntryField.set(tarOutputStream, true);
                            
                                // Execute
                                tarOutputStream.closeArchiveEntry();
                            
                                // Verify
                                verify(mockByteArrayOutputStream, never()).write(assemBuf, 0, 512);
                                assertFalse(haveUnclosedEntryField.getBoolean(tarOutputStream));
                            }

    @Test
                    public void testCloseArchiveEntryWithAssembledData() throws Exception {
                        // Create mock objects and test data
                        byte[] assemBuf = new byte[512];
                        ByteArrayOutputStream mockBuffer = mock(ByteArrayOutputStream.class);
                        TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(null);
                        
                        // Set up reflection fields
                        Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                        assemBufField.setAccessible(true);
                        assemBufField.set(tarOutputStream, assemBuf);
                        
                        Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                        bufferField.setAccessible(true);
                        bufferField.set(tarOutputStream, mockBuffer);
                        
                        Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                        assemLenField.setAccessible(true);
                        assemLenField.set(tarOutputStream, 10);
                        
                        Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                        currBytesField.setAccessible(true);
                        currBytesField.set(tarOutputStream, 100L);
                        
                        Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                        currSizeField.setAccessible(true);
                        currSizeField.set(tarOutputStream, 100L);
                        
                        Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                        currNameField.setAccessible(true);
                        currNameField.set(tarOutputStream, "testEntry");
                        
                        Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                        haveUnclosedEntryField.setAccessible(true);
                        haveUnclosedEntryField.set(tarOutputStream, true);
                    
                        // Execute
                        tarOutputStream.closeArchiveEntry();
                    
                        // Verify
                        verify(mockBuffer).write(assemBuf, 0, 10);
                        assert(assemLenField.getInt(tarOutputStream) == 0);
                        assert(!haveUnclosedEntryField.getBoolean(tarOutputStream));
                        
                        // Verify zeros were written to remaining buffer
                        for (int i = 10; i < assemBuf.length; i++) {
                            assert(assemBuf[i] == 0);
                        }
                    }

    @Test
                public void testFinishSuccessfully() throws Exception {
                    // Setup mock objects
                    ByteArrayOutputStream mockOutputStream = new ByteArrayOutputStream();
                    TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOutputStream);
                    
                    // Set private field using reflection
                    Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                    haveUnclosedEntryField.setAccessible(true);
                    haveUnclosedEntryField.set(tarOut, false);
                
                    // Create spy to verify method calls
                    TarArchiveOutputStream spyTarOut = spy(tarOut);
                    
                    // Use reflection to access the private method
                    Method writeEOFRecord = TarArchiveOutputStream.class.getDeclaredMethod("writeEOFRecord");
                    writeEOFRecord.setAccessible(true);
                    
                    // Mock the private method call
                    doNothing().when(writeEOFRecord).invoke(spyTarOut);
                
                    // Invoke finish method
                    spyTarOut.finish();
                
                    // Verify writeEOFRecord was called twice through reflection
                    verify(writeEOFRecord, times(2)).invoke(spyTarOut);
                }

    @Test
            public void testPutArchiveEntryWithShortName() throws Exception {
                // Setup mocks
                TarArchiveOutputStream tarOutputStream = mock(TarArchiveOutputStream.class);
                TarArchiveEntry shortNameEntry = mock(TarArchiveEntry.class);
                when(shortNameEntry.getName()).thenReturn("short.txt");
                when(shortNameEntry.isDirectory()).thenReturn(false);
                when(shortNameEntry.getSize()).thenReturn(100L);
                
                // Create buffer implementation class inside method
                class BufferImpl {
                    public void writeRecord(byte[] data) {}
                }
                Object buffer = new BufferImpl();
                
                // Use reflection to set private fields
                Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                bufferField.setAccessible(true);
                bufferField.set(tarOutputStream, buffer);
        
                Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                recordBufField.setAccessible(true);
                byte[] recordBuf = new byte[512];
                recordBufField.set(tarOutputStream, recordBuf);
        
                // Call the method under test
                Method putArchiveEntryMethod = TarArchiveOutputStream.class.getDeclaredMethod("putArchiveEntry", TarArchiveEntry.class);
                putArchiveEntryMethod.setAccessible(true);
                putArchiveEntryMethod.invoke(tarOutputStream, shortNameEntry);
        
                // Verify interactions
                verify(shortNameEntry).writeEntryHeader(any(byte[].class));
                
                // Verify field values
                Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                currBytesField.setAccessible(true);
                assertEquals(0L, currBytesField.get(tarOutputStream));
        
                Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                currSizeField.setAccessible(true);
                assertEquals(100L, currSizeField.get(tarOutputStream));
        
                Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                currNameField.setAccessible(true);
                assertEquals("short.txt", currNameField.get(tarOutputStream));
        
                Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                haveUnclosedEntryField.setAccessible(true);
                assertTrue((boolean) haveUnclosedEntryField.get(tarOutputStream));
            }

    @Test
            public void testPutArchiveEntryWithLongNameInTruncateMode() throws Exception {
                // Create mocks
                TarArchiveOutputStream tarOutputStream = spy(new TarArchiveOutputStream(null));
                TarArchiveEntry longNameEntry = mock(TarArchiveEntry.class);
                byte[] recordBuf = new byte[512];
                
                // Setup mocks
                when(longNameEntry.getName()).thenReturn(new String(new char[TarConstants.NAMELEN + 1]).replace('\0', 'a'));
                when(longNameEntry.isDirectory()).thenReturn(false);
                when(longNameEntry.getSize()).thenReturn(0L);
                
                // Use reflection to set private fields
                Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                bufferField.setAccessible(true);
                bufferField.set(tarOutputStream, new Object()); // Simplified buffer object
                
                Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                recordBufField.setAccessible(true);
                recordBufField.set(tarOutputStream, recordBuf);
            
                // Test
                tarOutputStream.setLongFileMode(TarArchiveOutputStream.LONGFILE_TRUNCATE);
                tarOutputStream.putArchiveEntry(longNameEntry);
                
                // Verify
                verify(longNameEntry).writeEntryHeader(any(byte[].class));
            }

    @Test
        public void testPutArchiveEntryWithDirectory() throws Exception {
            // Create mocks and test objects
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(byteArrayOutputStream);
            
            // Mock the entry and buffer
            TarArchiveEntry directoryEntry = mock(TarArchiveEntry.class);
            when(directoryEntry.isDirectory()).thenReturn(true);
            when(directoryEntry.getName()).thenReturn("testdir/");
            
            // Create mock buffer class since we can't mock the actual buffer class directly
            class MockBuffer {
                public void writeRecord(byte[] record) {}
            }
            
            // Use reflection to set the buffer field
            Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
            bufferField.setAccessible(true);
            MockBuffer buffer = mock(MockBuffer.class);
            bufferField.set(tarOutputStream, buffer);
            
            // Use reflection to set the recordBuf field
            Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
            recordBufField.setAccessible(true);
            byte[] recordBuf = new byte[512]; // Replaced TarConstants.DEFAULT_RCDSIZE with actual value
            recordBufField.set(tarOutputStream, recordBuf);
            
            // Execute the test
            tarOutputStream.putArchiveEntry(directoryEntry);
            
            // Verify interactions
            verify(directoryEntry).writeEntryHeader(any(byte[].class));
            verify(buffer).writeRecord(any(byte[].class));
            
            // Verify field values
            Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
            currSizeField.setAccessible(true);
            assertEquals(0L, currSizeField.get(tarOutputStream));
        }


}
