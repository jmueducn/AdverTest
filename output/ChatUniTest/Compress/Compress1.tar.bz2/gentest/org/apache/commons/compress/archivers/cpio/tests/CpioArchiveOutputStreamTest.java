package gentest.org.apache.commons.compress.archivers.cpio.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.cpio.*;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
 
public class CpioArchiveOutputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
        public void testCloseWhenNotClosed() throws IOException {
            // Set up
            OutputStream mockOutputStream = mock(OutputStream.class);
            CpioArchiveOutputStream cpioStream = new CpioArchiveOutputStream(mockOutputStream);
            
            // Use reflection to access the closed field since it's private
            try {
                java.lang.reflect.Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                closedField.setAccessible(true);
                closedField.set(cpioStream, false);
            } catch (Exception e) {
                fail("Failed to set closed field via reflection");
            }
    
            // Execute
            cpioStream.close();
    
            // Verify
            try {
                java.lang.reflect.Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                closedField.setAccessible(true);
                assertTrue((boolean) closedField.get(cpioStream));
            } catch (Exception e) {
                fail("Failed to get closed field via reflection");
            }
            verify(mockOutputStream).close();
        }

    @Test
        public void testCloseWhenAlreadyClosed() throws IOException {
            // Set up
            OutputStream mockOutputStream = mock(OutputStream.class);
            CpioArchiveOutputStream cpioStream = new CpioArchiveOutputStream(mockOutputStream);
            
            // Use reflection to set the closed field since it's private
            try {
                java.lang.reflect.Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                closedField.setAccessible(true);
                closedField.setBoolean(cpioStream, true);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
    
            // Execute
            cpioStream.close();
    
            // Verify
            try {
                java.lang.reflect.Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                closedField.setAccessible(true);
                assertTrue(closedField.getBoolean(cpioStream));
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            verify(mockOutputStream, never()).close();
        }

    @Test
        public void testCloseCallsFinish() throws IOException {
            // Set up
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            CpioArchiveOutputStream cpioStream = new CpioArchiveOutputStream(byteArrayOutputStream);
            CpioArchiveOutputStream spyStream = spy(cpioStream);
            doNothing().when(spyStream).finish();
    
            // Execute
            spyStream.close();
    
            // Verify
            verify(spyStream).finish();
        }

    @Test
        public void testCloseSetsClosedFlag() throws IOException {
            // Set up
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            CpioArchiveOutputStream cpioStream = new CpioArchiveOutputStream(out);
            
            // Use reflection to access private field
            try {
                java.lang.reflect.Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                closedField.setAccessible(true);
                boolean initialClosed = (boolean) closedField.get(cpioStream);
                assertFalse(initialClosed);
    
                // Execute
                cpioStream.close();
    
                // Verify
                boolean finalClosed = (boolean) closedField.get(cpioStream);
                assertTrue(finalClosed);
            } catch (Exception e) {
                fail("Reflection failed: " + e.getMessage());
            }
        }

    @Test
        public void testClosePropagatesIOExceptionFromFinish() throws IOException {
            // Set up
            CpioArchiveOutputStream cpioStream = new CpioArchiveOutputStream(null);
            CpioArchiveOutputStream spyStream = spy(cpioStream);
            doThrow(new IOException("Test exception")).when(spyStream).finish();
    
            // Execute & Verify
            try {
                spyStream.close();
                fail("Expected IOException");
            } catch (IOException e) {
                assertEquals("Test exception", e.getMessage());
            }
        }

    @Test
        public void testClosePropagatesIOExceptionFromSuperClose() throws IOException {
            // Set up
            OutputStream mockOutputStream = mock(OutputStream.class);
            CpioArchiveOutputStream cpioStream = new CpioArchiveOutputStream(mockOutputStream);
            doThrow(new IOException("Test exception")).when(mockOutputStream).close();
    
            // Execute & Verify
            try {
                cpioStream.close();
                fail("Expected IOException");
            } catch (IOException e) {
                assertEquals("Test exception", e.getMessage());
            }
        }


}
