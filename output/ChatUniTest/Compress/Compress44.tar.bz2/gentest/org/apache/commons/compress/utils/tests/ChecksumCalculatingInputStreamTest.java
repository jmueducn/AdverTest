package gentest.org.apache.commons.compress.utils.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.utils.*;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.Checksum;
 
public class ChecksumCalculatingInputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
        public void testConstructorWithValidParameters() {
            Checksum mockChecksum = mock(Checksum.class);
            InputStream mockInputStream = mock(InputStream.class);
            
            ChecksumCalculatingInputStream stream = 
                new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
            
            assertNotNull(stream);
            // Verify fields are set correctly through reflection
            try {
                java.lang.reflect.Field checksumField = 
                    ChecksumCalculatingInputStream.class.getDeclaredField("checksum");
                checksumField.setAccessible(true);
                assertEquals(mockChecksum, checksumField.get(stream));
                
                java.lang.reflect.Field inField = 
                    ChecksumCalculatingInputStream.class.getDeclaredField("in");
                inField.setAccessible(true);
                assertEquals(mockInputStream, inField.get(stream));
            } catch (Exception e) {
                fail("Reflection failed: " + e.getMessage());
            }
        }

    @Test
        public void testConstructorWithNullInputStream() {
            Checksum mockChecksum = mock(Checksum.class);
            thrown.expect(NullPointerException.class);
            thrown.expectMessage("Parameter in must not be null");
            new ChecksumCalculatingInputStream(mockChecksum, null);
        }

    @Test
        public void testConstructorWithNullChecksum() {
            InputStream mockInputStream = mock(InputStream.class);
            thrown.expect(NullPointerException.class);
            thrown.expectMessage("Parameter checksum must not be null");
            new ChecksumCalculatingInputStream(null, mockInputStream);
        }

    @Test
        public void testConstructorExceptionMessageForNullChecksum() {
            InputStream mockInputStream = mock(InputStream.class);
            try {
                new ChecksumCalculatingInputStream(null, mockInputStream);
                fail("Expected NullPointerException");
            } catch (NullPointerException e) {
                assertEquals("Parameter checksum must not be null", e.getMessage());
            }
        }

    @Test
        public void testConstructorExceptionMessageForNullInputStream() {
            Checksum mockChecksum = mock(Checksum.class);
            try {
                new ChecksumCalculatingInputStream(mockChecksum, null);
                fail("Expected NullPointerException");
            } catch (NullPointerException e) {
                assertEquals("Parameter in must not be null", e.getMessage());
            }
        }


}
