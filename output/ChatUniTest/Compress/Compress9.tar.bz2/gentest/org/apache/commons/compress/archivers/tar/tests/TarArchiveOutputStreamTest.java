package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.utils.ArchiveUtils;
import org.apache.commons.compress.utils.CountingOutputStream;
 
public class TarArchiveOutputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                            public void testGetCountReturnsZeroWhenNoBytesWritten() throws Exception {
                                OutputStream mockOutputStream = mock(OutputStream.class);
                                TarArchiveOutputStream tarArchiveOutputStream = new TarArchiveOutputStream(mockOutputStream);
                                
                                // Use reflection to access private getBytesWritten() method
                                java.lang.reflect.Method getBytesWrittenMethod = 
                                    TarArchiveOutputStream.class.getDeclaredMethod("getBytesWritten");
                                getBytesWrittenMethod.setAccessible(true);
                                
                                // Mock the return value
                                when(getBytesWrittenMethod.invoke(tarArchiveOutputStream)).thenReturn(0L);
                                
                                assertEquals(0, tarArchiveOutputStream.getCount());
                            }

    @Test
                            public void testGetCountReturnsPositiveValueWhenBytesWritten() throws Exception {
                                OutputStream mockOutputStream = mock(OutputStream.class);
                                TarArchiveOutputStream tarArchiveOutputStream = new TarArchiveOutputStream(mockOutputStream);
                                
                                // Use reflection to set the countingOutputStream field since it's private
                                java.lang.reflect.Field field = TarArchiveOutputStream.class.getDeclaredField("countingOutputStream");
                                field.setAccessible(true);
                                org.apache.commons.compress.utils.CountingOutputStream countingOutputStream = 
                                    mock(org.apache.commons.compress.utils.CountingOutputStream.class);
                                field.set(tarArchiveOutputStream, countingOutputStream);
                                
                                when(countingOutputStream.getBytesWritten()).thenReturn(12345L);
                                assertEquals(12345, tarArchiveOutputStream.getCount());
                            }

    @Test
                            public void testGetCountReturnsMaxIntWhenBytesWrittenExceedsMaxInt() throws Exception {
                                CountingOutputStream countingOutputStream = mock(CountingOutputStream.class);
                                OutputStream outputStream = mock(OutputStream.class);
                                TarArchiveOutputStream tarArchiveOutputStream = new TarArchiveOutputStream(outputStream);
                                
                                // Use reflection to set the private countingOutputStream field
                                java.lang.reflect.Field field = TarArchiveOutputStream.class.getDeclaredField("countingOutputStream");
                                field.setAccessible(true);
                                field.set(tarArchiveOutputStream, countingOutputStream);
                        
                                when(countingOutputStream.getBytesWritten()).thenReturn((long)Integer.MAX_VALUE + 1L);
                                assertEquals(Integer.MAX_VALUE, tarArchiveOutputStream.getCount());
                            }

    @Test
                            public void testGetCountReturnsMinIntWhenBytesWrittenExceedsMinInt() throws Exception {
                                OutputStream outputStream = mock(OutputStream.class);
                                TarArchiveOutputStream tarArchiveOutputStream = new TarArchiveOutputStream(outputStream);
                                
                                // Use reflection to mock the countingOutputStream field
                                java.lang.reflect.Field field = TarArchiveOutputStream.class.getDeclaredField("countingOutputStream");
                                field.setAccessible(true);
                                org.apache.commons.compress.utils.CountingOutputStream countingOutputStream = 
                                    mock(org.apache.commons.compress.utils.CountingOutputStream.class);
                                field.set(tarArchiveOutputStream, countingOutputStream);
                                
                                when(countingOutputStream.getBytesWritten()).thenReturn((long)Integer.MIN_VALUE - 1L);
                                assertEquals(Integer.MIN_VALUE, tarArchiveOutputStream.getCount());
                            }

    @Test
                            public void testGetBytesWrittenReturnsZeroWhenNoBytesWritten() throws Exception {
                                CountingOutputStream countingOutputStream = mock(CountingOutputStream.class);
                                TarArchiveOutputStream tarArchiveOutputStream = new TarArchiveOutputStream(countingOutputStream);
                                
                                when(countingOutputStream.getBytesWritten()).thenReturn(0L);
                                assertEquals(0L, tarArchiveOutputStream.getBytesWritten());
                            }

    @Test
                            public void testGetBytesWrittenReturnsCorrectValueWhenBytesWritten() throws Exception {
                                long expectedBytes = 1024L;
                                CountingOutputStream countingOutputStream = mock(CountingOutputStream.class);
                                when(countingOutputStream.getBytesWritten()).thenReturn(expectedBytes);
                                
                                TarArchiveOutputStream tarArchiveOutputStream = new TarArchiveOutputStream(countingOutputStream);
                                assertEquals(expectedBytes, tarArchiveOutputStream.getBytesWritten());
                            }

    @Test
                            public void testWriteExceedsEntrySize() throws IOException {
                                // Create a mock or real output stream (depending on your needs)
                                // In this case, we'll create a real one since we need to test the actual behavior
                                java.io.ByteArrayOutputStream byteArrayOutputStream = new java.io.ByteArrayOutputStream();
                                TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(byteArrayOutputStream);
                                
                                // Set up a dummy entry with size 1024
                                org.apache.commons.compress.archivers.tar.TarArchiveEntry entry = 
                                    new org.apache.commons.compress.archivers.tar.TarArchiveEntry("test");
                                entry.setSize(1024);
                                tarOutputStream.putArchiveEntry(entry);
                                
                                byte[] data = new byte[1025];
                                try {
                                    tarOutputStream.write(data, 0, 1025);
                                    fail("Expected IOException");
                                } catch (IOException e) {
                                    assertTrue(e.getMessage().contains("exceeds size in header"));
                                } finally {
                                    tarOutputStream.close();
                                }
                            }

    @Test
                        public void testGetBytesWrittenReturnsMaxLongValue() throws Exception {
                            CountingOutputStream countingOutputStream = mock(CountingOutputStream.class);
                            OutputStream outputStream = mock(OutputStream.class);
                            TarArchiveOutputStream tarArchiveOutputStream = new TarArchiveOutputStream(outputStream);
                            
                            // Use reflection to set the private 'out' field
                            java.lang.reflect.Field outField = TarArchiveOutputStream.class.getDeclaredField("out");
                            outField.setAccessible(true);
                            outField.set(tarArchiveOutputStream, countingOutputStream);
                    
                            when(countingOutputStream.getBytesWritten()).thenReturn(Long.MAX_VALUE);
                            assertEquals(Long.MAX_VALUE, tarArchiveOutputStream.getBytesWritten());
                        }

    @Test
                        public void testGetBytesWrittenReturnsNegativeValue() throws Exception {
                            // Setup
                            OutputStream mockOutputStream = mock(OutputStream.class);
                            CountingOutputStream countingOutputStream = mock(CountingOutputStream.class);
                            when(countingOutputStream.getBytesWritten()).thenReturn(-1L);
                            
                            TarArchiveOutputStream tarArchiveOutputStream = new TarArchiveOutputStream(mockOutputStream);
                            // Use reflection to set the private 'out' field
                            java.lang.reflect.Field outField = TarArchiveOutputStream.class.getDeclaredField("out");
                            outField.setAccessible(true);
                            outField.set(tarArchiveOutputStream, countingOutputStream);
                            
                            // Test
                            assertEquals(-1L, tarArchiveOutputStream.getBytesWritten());
                        }

    @Test
                        public void testWriteWithPartialRecord() throws IOException, NoSuchFieldException, IllegalAccessException {
                            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                            TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(byteArrayOutputStream);
                            
                            byte[] data = new byte[100];
                            tarOutputStream.write(data, 0, 100);
                            
                            Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                            assemLenField.setAccessible(true);
                            int assemLen = (int) assemLenField.get(tarOutputStream);
                            
                            Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                            currBytesField.setAccessible(true);
                            long currBytes = (long) currBytesField.get(tarOutputStream);
                            
                            assertEquals(100, assemLen);
                            assertEquals(0, currBytes);
                        }

    @Test
                        public void testWriteWithAssemBufferAndCompleteRecord() throws Exception {
                            // Setup mock and test objects
                            ByteArrayOutputStream mockBuffer = mock(ByteArrayOutputStream.class);
                            int recordSize = 512;
                            byte[] recordBuf = new byte[recordSize];
                            
                            // Create real TarOutputStream with mock buffer
                            TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(mockBuffer);
                            
                            // Set private fields using reflection
                            Field recordSizeField = TarArchiveOutputStream.class.getDeclaredField("recordSize");
                            recordSizeField.setAccessible(true);
                            recordSizeField.set(tarOutputStream, recordSize);
                            
                            Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                            recordBufField.setAccessible(true);
                            recordBufField.set(tarOutputStream, recordBuf);
                            
                            Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                            assemLenField.setAccessible(true);
                            
                            Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                            currBytesField.setAccessible(true);
                    
                            // First write partial data to fill assembly buffer
                            int partialSize = recordSize - 100;
                            byte[] partialData = new byte[partialSize];
                            tarOutputStream.write(partialData, 0, partialSize);
                            
                            assertEquals(partialSize, assemLenField.getInt(tarOutputStream));
                            
                            // Now write enough data to complete the record
                            byte[] completeData = new byte[200];
                            tarOutputStream.write(completeData, 0, 200);
                            
                            verify(mockBuffer).write(recordBuf, 0, recordSize);
                            assertEquals(recordSize, currBytesField.getInt(tarOutputStream));
                            assertEquals(100, assemLenField.getInt(tarOutputStream));
                        }

    @Test
                        public void testWriteWithAssemBufferAndNotEnoughForCompleteRecord() throws Exception {
                            // Create test objects
                            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                            TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(byteArrayOutputStream);
                            
                            // Initialize necessary fields using reflection
                            Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                            assemBufField.setAccessible(true);
                            byte[] assemBuf = (byte[]) assemBufField.get(tarOutputStream);
                            
                            Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                            recordBufField.setAccessible(true);
                            byte[] recordBuf = (byte[]) recordBufField.get(tarOutputStream);
                        
                            // First write partial data to fill assembly buffer
                            int partialSize = 100;
                            byte[] partialData = new byte[partialSize];
                            tarOutputStream.write(partialData, 0, partialSize);
                        
                            // Write more data but not enough to complete record
                            byte[] moreData = new byte[200];
                            tarOutputStream.write(moreData, 0, 200);
                            
                            // Helper method to get field value
                            Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                            assemLenField.setAccessible(true);
                            int assemLen = (int) assemLenField.get(tarOutputStream);
                            
                            Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                            currBytesField.setAccessible(true);
                            int currBytes = (int) currBytesField.get(tarOutputStream);
                            
                            assertEquals(300, assemLen);
                            assertEquals(0, currBytes);
                        }

    @Test
                    public void testWriteMultipleFullRecords() throws IOException {
                        // Define required variables
                        int recordSize = 512;
                        OutputStream mockOutputStream = mock(OutputStream.class);
                        TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(mockOutputStream);
                        
                        // Set up private fields using reflection
                        try {
                            java.lang.reflect.Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                            currBytesField.setAccessible(true);
                            currBytesField.set(tarOutputStream, 0);
                            
                            java.lang.reflect.Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                            recordBufField.setAccessible(true);
                            recordBufField.set(tarOutputStream, new byte[recordSize]);
                            
                            // Mock the buffer internally used by TarArchiveOutputStream
                            java.lang.reflect.Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                            bufferField.setAccessible(true);
                            Object mockBuffer = mock(bufferField.getType());
                            bufferField.set(tarOutputStream, mockBuffer);
                            
                            // Mock the writeRecord method
                            when(mockBuffer.getClass().getMethod("writeRecord", byte[].class, int.class).invoke(
                                mockBuffer, any(byte[].class), anyInt())).thenReturn(null);
                        } catch (Exception e) {
                            fail("Reflection setup failed: " + e.getMessage());
                        }
                
                        byte[] data = new byte[recordSize * 3];
                        tarOutputStream.write(data, 0, recordSize * 3);
                        
                        // Verify the internal buffer calls
                        try {
                            java.lang.reflect.Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                            bufferField.setAccessible(true);
                            Object mockBuffer = bufferField.get(tarOutputStream);
                            verify(mockBuffer, times(3)).getClass().getMethod("writeRecord", byte[].class, int.class).invoke(
                                mockBuffer, any(byte[].class), anyInt());
                        } catch (Exception e) {
                            fail("Reflection verification failed: " + e.getMessage());
                        }
                        
                        // Verify currBytes using reflection
                        try {
                            java.lang.reflect.Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                            currBytesField.setAccessible(true);
                            assertEquals(recordSize * 3, currBytesField.get(tarOutputStream));
                        } catch (Exception e) {
                            fail("Reflection verification failed: " + e.getMessage());
                        }
                    }

    @Test
            public void testWriteWithOffset() throws Exception {
                // Define required variables
                int recordSize = 512;
                byte[] data = new byte[recordSize + 100];
                Object mockBuffer = mock(Object.class); // Using Object since TarBuffer is not accessible
                
                // Create instance and set private fields using reflection
                TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(null);
                
                // Helper method to set field values
                Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                bufferField.setAccessible(true);
                bufferField.set(tarOutputStream, mockBuffer);
                
                Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                recordBufField.setAccessible(true);
                recordBufField.set(tarOutputStream, new byte[recordSize]);
                
                Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                assemBufField.setAccessible(true);
                assemBufField.set(tarOutputStream, new byte[recordSize]);
                
                Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                currBytesField.setAccessible(true);
                currBytesField.set(tarOutputStream, 0);
                
                Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                currSizeField.setAccessible(true);
                currSizeField.set(tarOutputStream, recordSize * 2); // Set larger than recordSize to avoid exception
                
                // Mock the writeRecord method
                Method writeRecordMethod = mockBuffer.getClass().getMethod("writeRecord", byte[].class, int.class);
                when(writeRecordMethod.invoke(mockBuffer, any(byte[].class), anyInt())).thenReturn(null);
                
                tarOutputStream.write(data, 100, recordSize);
                
                verify(writeRecordMethod, times(1)).invoke(mockBuffer, any(byte[].class), anyInt());
                
                assertEquals(recordSize, currBytesField.get(tarOutputStream));
            }

    @Test
        public void testWriteWithEmptyAssemBufferAndFullRecord() throws IOException, NoSuchFieldException, IllegalAccessException {
            // Setup test variables
            int recordSize = 512;
            byte[] data = new byte[recordSize];
            
            // Create mock OutputStream and inject it
            OutputStream mockOutputStream = mock(OutputStream.class);
            Object mockBuffer = mock(Object.class); // Using Object instead of TarBuffer
            
            // Create test instance
            TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(mockOutputStream);
            
            // Inject mock buffer using reflection
            Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
            bufferField.setAccessible(true);
            bufferField.set(tarOutputStream, mockBuffer);
            
            // Set recordBuf field
            Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
            recordBufField.setAccessible(true);
            recordBufField.set(tarOutputStream, new byte[recordSize]);
            
            // Set currBytes field to 0
            Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
            currBytesField.setAccessible(true);
            currBytesField.set(tarOutputStream, 0);
            
            try {
                // Mock the writeRecord method using reflection
                Class<?> tarBufferClass = Class.forName("org.apache.commons.compress.archivers.tar.TarBuffer");
                Method writeRecordMethod = tarBufferClass.getDeclaredMethod("writeRecord", byte[].class, int.class);
                writeRecordMethod.setAccessible(true);
                
                // Execute test
                tarOutputStream.write(data, 0, recordSize);
                
                // Verify
                verify(mockOutputStream, atLeastOnce()).write(any(byte[].class), anyInt(), anyInt());
                assertEquals(recordSize, currBytesField.get(tarOutputStream));
            } catch (ClassNotFoundException | NoSuchMethodException e) {
                fail("Reflection failed: " + e.getMessage());
            }
        }


}
