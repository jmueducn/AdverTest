package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
 
public class TarUtilsTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testParseNameWithNormalInput() {
            byte[] buffer = {'f', 'i', 'l', 'e', '.', 't', 'x', 't'};
            String result = TarUtils.parseName(buffer, 0, buffer.length);
            assertEquals("file.txt", result);
        }

    @Test
        public void testParseNameWithNullTerminatedInput() {
            byte[] buffer = {'d', 'i', 'r', 0, 'x', 'y', 'z'};
            String result = TarUtils.parseName(buffer, 0, buffer.length);
            assertEquals("dir", result);
        }

    @Test
        public void testParseNameWithOffset() {
            byte[] buffer = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};
            String result = TarUtils.parseName(buffer, 2, 3);
            assertEquals("cde", result);
        }

    @Test
        public void testParseNameWithNegativeBytes() {
            byte[] buffer = {(byte) 0xFF, (byte) 0x80, 'a', 'b'};
            String result = TarUtils.parseName(buffer, 0, buffer.length);
            assertEquals("\u00FF\u0080ab", result);
        }

    @Test
        public void testParseNameWithZeroLength() {
            byte[] buffer = {'a', 'b', 'c'};
            String result = TarUtils.parseName(buffer, 0, 0);
            assertEquals("", result);
        }

    @Test
        public void testParseNameWithEmptyBuffer() {
            byte[] buffer = {};
            String result = TarUtils.parseName(buffer, 0, 0);
            assertEquals("", result);
        }

    @Test
        public void testParseNameWithOnlyNullByte() {
            byte[] buffer = {0};
            String result = TarUtils.parseName(buffer, 0, 1);
            assertEquals("", result);
        }

    @Test
        public void testParseNameWithLengthLargerThanBuffer() {
            byte[] buffer = {'a', 'b', 'c'};
            String result = TarUtils.parseName(buffer, 0, 5);
            assertEquals("abc", result);
        }

    @Test
        public void testParseNameWithOffsetAndNullTermination() {
            byte[] buffer = {'x', 'y', 'z', 0, 'a', 'b', 'c'};
            String result = TarUtils.parseName(buffer, 1, 5);
            assertEquals("yz", result);
        }

}
