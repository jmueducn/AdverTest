package gentest.org.apache.commons.compress.utils.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.utils.*;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
 
public class IOUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
        public void testSkip_SuccessfulSkip() throws IOException {
            InputStream inputStream = mock(InputStream.class);
            when(inputStream.skip(anyLong())).thenReturn(10L, 5L);
            long result = IOUtils.skip(inputStream, 15);
            assertEquals(15, result);
            verify(inputStream, times(2)).skip(anyLong());
        }

    @Test
        public void testSkip_PartialSkipThenRead() throws IOException {
            InputStream inputStream = mock(InputStream.class);
            when(inputStream.skip(anyLong())).thenReturn(10L, 0L);
            when(inputStream.read(any(byte[].class), anyInt(), anyInt()))
                .thenReturn(5, 0);
            long result = IOUtils.skip(inputStream, 20);
            assertEquals(15, result);
            verify(inputStream, times(2)).skip(anyLong());
            verify(inputStream, atLeastOnce()).read(any(byte[].class), anyInt(), anyInt());
        }

    @Test
        public void testSkip_ZeroBytesRequested() throws IOException {
            InputStream inputStream = mock(InputStream.class);
            long result = IOUtils.skip(inputStream, 0);
            assertEquals(0, result);
            verify(inputStream, never()).skip(anyLong());
        }

    @Test
        public void testSkip_AllThroughRead() throws IOException {
            InputStream inputStream = mock(InputStream.class);
            when(inputStream.skip(anyLong())).thenReturn(0L);
            when(inputStream.read(any(byte[].class), anyInt(), anyInt()))
                .thenReturn(4096, 4096, 100, -1);
            long result = IOUtils.skip(inputStream, 10000);
            assertEquals(8192, result);
        }

    @Test
        public void testSkip_EndOfStreamDuringRead() throws IOException {
            InputStream inputStream = mock(InputStream.class);
            when(inputStream.skip(anyLong())).thenReturn(5L, 0L);
            when(inputStream.read(any(byte[].class), anyInt(), anyInt()))
                .thenReturn(3, -1);
            long result = IOUtils.skip(inputStream, 20);
            assertEquals(8, result);
        }

    @Test(expected = IOException.class)
        public void testSkip_IOExceptionDuringSkip() throws IOException {
            InputStream inputStream = mock(InputStream.class);
            when(inputStream.skip(anyLong())).thenThrow(new IOException());
            IOUtils.skip(inputStream, 10);
        }

    @Test(expected = IOException.class)
        public void testSkip_IOExceptionDuringRead() throws IOException {
            InputStream inputStream = mock(InputStream.class);
            when(inputStream.skip(anyLong())).thenReturn(0L);
            when(inputStream.read(any(byte[].class), anyInt(), anyInt()))
                .thenThrow(new IOException());
            IOUtils.skip(inputStream, 10);
        }

    @Test
        public void testSkip_LargeSkip() throws IOException {
            InputStream inputStream = mock(InputStream.class);
            when(inputStream.skip(anyLong())).thenReturn(Integer.MAX_VALUE * 2L, 100L, 0L);
            when(inputStream.read(any(byte[].class), anyInt(), anyInt()))
                .thenReturn(4096, 4096, -1);
            long result = IOUtils.skip(inputStream, Integer.MAX_VALUE * 2L + 5000L);
            assertEquals(Integer.MAX_VALUE * 2L + 8192L, result);
        }


}
