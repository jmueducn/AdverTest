package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
 
public class ZipArchiveEntryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                    public void testSetNameWithRawName() throws Exception {
                        ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Changed to use available constructor
                        String name = "test.txt";
                        byte[] rawName = new byte[] {116, 101, 115, 116, 46, 116, 120, 116}; // "test.txt" in bytes
                        
                        // Use reflection to access protected method
                        Method method = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                        method.setAccessible(true);
                        method.invoke(entry, name, rawName);
                        
                        assertEquals("Name should be set correctly", name, entry.getName());
                        assertArrayEquals("Raw name should be set correctly", rawName, entry.getRawName());
                    }

    @Test
                    public void testSetNameWithNullRawName() throws Exception {
                        ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Changed to use available constructor
                        String name = "test.txt";
                        
                        // Use reflection to access protected method
                        Method method = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                        method.setAccessible(true);
                        method.invoke(entry, name, null);
                        
                        assertEquals("Name should be set correctly", name, entry.getName());
                        assertNull("Raw name should be null", entry.getRawName());
                    }

    @Test
                    public void testSetNameWithEmptyRawName() throws Exception {
                        ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Changed to use available constructor
                        String name = "test.txt";
                        byte[] rawName = new byte[0];
                        
                        // Use reflection to access protected method
                        Method method = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                        method.setAccessible(true);
                        method.invoke(entry, name, rawName);
                        
                        assertEquals("Name should be set correctly", name, entry.getName());
                        assertArrayEquals("Raw name should be empty array", rawName, entry.getRawName());
                    }

    @Test
                    public void testSetNameWithNullName() throws Exception {
                        ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Using available constructor
                        byte[] rawName = new byte[] {116, 101, 115, 116, 46, 116, 120, 116}; // "test.txt" in bytes
                        
                        // Use reflection to access protected method
                        Method method = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                        method.setAccessible(true);
                        method.invoke(entry, null, rawName);
                        
                        assertNull("Name should be null", entry.getName());
                        assertArrayEquals("Raw name should be set correctly", rawName, entry.getRawName());
                    }

    @Test
                    public void testSetNameWithBothNull() throws Exception {
                        ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Changed to use available constructor
                        
                        // Use reflection to access protected method
                        Method method = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                        method.setAccessible(true);
                        method.invoke(entry, null, null);
                        
                        assertNull("Name should be null", entry.getName());
                        assertNull("Raw name should be null", entry.getRawName());
                    }

    @Test
                public void testSetNameWithNull() throws Exception {
                    ZipArchiveEntry entry = new ZipArchiveEntry("test");
                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                    setNameMethod.setAccessible(true);
                    setNameMethod.invoke(entry, (String)null);
                    assertNull(entry.getName());
                }

    @Test
                public void testSetNameWithNormalString() throws Exception {
                    ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                    setNameMethod.setAccessible(true);
                    
                    setNameMethod.invoke(entry, "test.txt");
                    assertEquals("test.txt", entry.getName());
                }

    @Test
                public void testSetNameWithBackslashesOnFATPlatform() throws Exception {
                    ZipArchiveEntry entry = new ZipArchiveEntry("test");
                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                    setNameMethod.setAccessible(true);
                    
                    Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                    setPlatformMethod.setAccessible(true);
                    setPlatformMethod.invoke(entry, 0); // 0 represents PLATFORM_FAT
                    
                    setNameMethod.invoke(entry, "folder\\file.txt");
                    assertEquals("folder/file.txt", entry.getName());
                }

    @Test
                public void testSetNameWithBackslashesOnUnixPlatform() throws Exception {
                    ZipArchiveEntry entry = new ZipArchiveEntry("test");
                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                    setNameMethod.setAccessible(true);
                    
                    // Set platform to UNIX using reflection since PLATFORM_UNIX might not be accessible
                    Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                    setPlatformMethod.setAccessible(true);
                    setPlatformMethod.invoke(entry, 3); // 3 represents UNIX platform
                    
                    setNameMethod.invoke(entry, "folder\\file.txt");
                    assertEquals("folder\\file.txt", entry.getName());
                }

    @Test
                public void testSetNameWithForwardSlashOnFATPlatform() throws Exception {
                    ZipArchiveEntry entry = new ZipArchiveEntry("test");
                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                    setNameMethod.setAccessible(true);
                    
                    // Set platform to FAT using reflection since PLATFORM_FAT might be private
                    Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                    setPlatformMethod.setAccessible(true);
                    setPlatformMethod.invoke(entry, 0); // 0 is typically the value for PLATFORM_FAT
                    
                    setNameMethod.invoke(entry, "folder/file.txt");
                    assertEquals("folder/file.txt", entry.getName());
                }

    @Test
                public void testSetNameWithMixedSlashesOnFATPlatform() throws Exception {
                    ZipArchiveEntry entry = new ZipArchiveEntry("test");
                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                    setNameMethod.setAccessible(true);
                    
                    Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                    setPlatformMethod.setAccessible(true);
                    setPlatformMethod.invoke(entry, 0); // 0 represents PLATFORM_FAT
                    
                    setNameMethod.invoke(entry, "folder\\subfolder/file.txt");
                    assertEquals("folder/subfolder/file.txt", entry.getName());
                }

    @Test
                public void testSetNameWithMultipleBackslashesOnFATPlatform() throws Exception {
                    ZipArchiveEntry entry = new ZipArchiveEntry("test");
                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                    setNameMethod.setAccessible(true);
                    
                    Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                    setPlatformMethod.setAccessible(true);
                    setPlatformMethod.invoke(entry, 0); // PLATFORM_FAT is 0
                    
                    setNameMethod.invoke(entry, "folder\\\\file.txt");
                    assertEquals("folder//file.txt", entry.getName());
                }

    @Test
                public void testSetNameWithUnicodeCharacters() throws Exception {
                    ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                    setNameMethod.setAccessible(true);
                    
                    setNameMethod.invoke(entry, "测试文件.txt");
                    assertEquals("测试文件.txt", entry.getName());
                }

    @Test
                public void testSetNameWithSpaces() throws Exception {
                    ZipArchiveEntry entry = new ZipArchiveEntry("test");
                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                    setNameMethod.setAccessible(true);
                    setNameMethod.invoke(entry, "file with spaces.txt");
                    assertEquals("file with spaces.txt", entry.getName());
                }

    @Test
                public void testSetNameWithSpecialCharacters() throws Exception {
                    ZipArchiveEntry entry = new ZipArchiveEntry("test");
                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                    setNameMethod.setAccessible(true);
                    
                    setNameMethod.invoke(entry, "file$#@!.txt");
                    assertEquals("file$#@!.txt", entry.getName());
                }

    @Test
            public void testSetNameWithEmptyString() throws Exception {
                ZipArchiveEntry entry = new ZipArchiveEntry("test");
                Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                setNameMethod.setAccessible(true);
                setNameMethod.invoke(entry, "");
                assertEquals("", entry.getName());
            }

    @Test
        public void testSetNameWithSpecialCharacters1() throws Exception {
            ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
            String name = "test-äöüß.txt";
            byte[] rawName = name.getBytes("UTF-8");  // Changed from StandardCharsets.UTF_8 to "UTF-8"
            
            // Use reflection to access protected method
            Method method = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
            method.setAccessible(true);
            method.invoke(entry, name, rawName);
            
            assertEquals("Name with special characters should be set correctly", name, entry.getName());
            assertArrayEquals("Raw name with special characters should be set correctly", 
                             rawName, entry.getRawName());
        }


}
