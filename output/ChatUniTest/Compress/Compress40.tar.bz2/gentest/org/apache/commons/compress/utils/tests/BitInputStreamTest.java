package gentest.org.apache.commons.compress.utils.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.utils.*;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteOrder;
 
public class BitInputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test(expected = IllegalArgumentException.class)
        public void testReadBitsNegativeCount() throws IOException {
            InputStream mockInputStream = mock(InputStream.class);
            BitInputStream bitInputStream = new BitInputStream(mockInputStream, ByteOrder.BIG_ENDIAN);
            bitInputStream.readBits(-1);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testReadBitsCountGreaterThanMaximum() throws IOException {
            byte[] data = new byte[]{0x01, 0x02, 0x03};
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(data);
            BitInputStream bitInputStreamBigEndian = new BitInputStream(byteArrayInputStream, ByteOrder.BIG_ENDIAN);
            bitInputStreamBigEndian.readBits(64);
        }

    @Test
        public void testReadBitsEndOfStream() throws IOException {
            InputStream mockInputStream = mock(InputStream.class);
            BitInputStream bitInputStreamBigEndian = new BitInputStream(mockInputStream, ByteOrder.BIG_ENDIAN);
            when(mockInputStream.read()).thenReturn(-1);
            assertEquals(-1, bitInputStreamBigEndian.readBits(1));
        }

    @Test
        public void testReadBitsSingleByteBigEndian() throws Exception {
            InputStream mockInputStream = mock(InputStream.class);
            BitInputStream bitInputStreamBigEndian = new BitInputStream(mockInputStream, ByteOrder.BIG_ENDIAN);
            
            when(mockInputStream.read()).thenReturn(0b10101010);
            assertEquals(0b10101010, bitInputStreamBigEndian.readBits(8));
        }

    @Test
        public void testReadBitsSingleByteLittleEndian() throws IOException {
            InputStream mockInputStream = mock(InputStream.class);
            BitInputStream bitInputStreamLittleEndian = new BitInputStream(mockInputStream, ByteOrder.LITTLE_ENDIAN);
            
            when(mockInputStream.read()).thenReturn(0b10101010);
            assertEquals(0b10101010, bitInputStreamLittleEndian.readBits(8));
        }

    @Test
        public void testReadBitsMultipleBytesBigEndian() throws Exception {
            InputStream mockInputStream = mock(InputStream.class);
            BitInputStream bitInputStreamBigEndian = new BitInputStream(mockInputStream, ByteOrder.BIG_ENDIAN);
            
            when(mockInputStream.read())
                .thenReturn(0b10101010)
                .thenReturn(0b11001100);
            assertEquals(0b1010101011001100L, bitInputStreamBigEndian.readBits(16));
        }

    @Test
        public void testReadBitsMultipleBytesLittleEndian() throws IOException {
            InputStream mockInputStream = mock(InputStream.class);
            BitInputStream bitInputStreamLittleEndian = new BitInputStream(mockInputStream, ByteOrder.LITTLE_ENDIAN);
            
            when(mockInputStream.read())
                .thenReturn(0b10101010)
                .thenReturn(0b11001100);
            assertEquals(0b1100110010101010, bitInputStreamLittleEndian.readBits(16));
        }

    @Test
        public void testReadBitsPartialBigEndian() throws Exception {
            InputStream mockInputStream = mock(InputStream.class);
            BitInputStream bitInputStreamBigEndian = new BitInputStream(mockInputStream, ByteOrder.BIG_ENDIAN);
            
            when(mockInputStream.read()).thenReturn(0b10101010);
            assertEquals(0b1010, bitInputStreamBigEndian.readBits(4));
            assertEquals(0b1010, bitInputStreamBigEndian.readBits(4));
        }

    @Test
        public void testReadBitsPartialLittleEndian() throws Exception {
            InputStream mockInputStream = mock(InputStream.class);
            BitInputStream bitInputStreamLittleEndian = new BitInputStream(mockInputStream, ByteOrder.LITTLE_ENDIAN);
            
            when(mockInputStream.read()).thenReturn(0b10101010);
            assertEquals(0b1010, bitInputStreamLittleEndian.readBits(4));
            assertEquals(0b1010, bitInputStreamLittleEndian.readBits(4));
        }

    @Test
        public void testReadBitsWithOverflowBigEndian() throws IOException {
            InputStream mockInputStream = mock(InputStream.class);
            BitInputStream bitInputStreamBigEndian = new BitInputStream(mockInputStream, ByteOrder.BIG_ENDIAN);
            
            // Fill cache with 56 bits (7 bytes)
            when(mockInputStream.read())
                .thenReturn(0xFF)
                .thenReturn(0xFF)
                .thenReturn(0xFF)
                .thenReturn(0xFF)
                .thenReturn(0xFF)
                .thenReturn(0xFF)
                .thenReturn(0xFF)
                .thenReturn(0b10101010); // 8th byte for overflow
        
            // Request 57 bits (which requires overflow handling)
            assertEquals(0x7FFFFFFFFFFFFFFFL, bitInputStreamBigEndian.readBits(57));
        }

    @Test
        public void testReadBitsWithOverflowLittleEndian() throws IOException {
            InputStream mockInputStream = mock(InputStream.class);
            BitInputStream bitInputStreamLittleEndian = new BitInputStream(mockInputStream, ByteOrder.LITTLE_ENDIAN);
            
            // Fill cache with 56 bits (7 bytes)
            when(mockInputStream.read())
                .thenReturn(0xFF)
                .thenReturn(0xFF)
                .thenReturn(0xFF)
                .thenReturn(0xFF)
                .thenReturn(0xFF)
                .thenReturn(0xFF)
                .thenReturn(0xFF)
                .thenReturn(0b10101010); // 8th byte for overflow
        
            // Request 57 bits (which requires overflow handling)
            assertEquals(0xFFFFFFFFFFFFFFFEL, bitInputStreamLittleEndian.readBits(57));
        }

    @Test
        public void testReadBitsMixedCallsBigEndian() throws IOException {
            InputStream mockInputStream = mock(InputStream.class);
            BitInputStream bitInputStreamBigEndian = new BitInputStream(mockInputStream, ByteOrder.BIG_ENDIAN);
            
            when(mockInputStream.read())
                .thenReturn(0b10101010)
                .thenReturn(0b11001100)
                .thenReturn(0b11110000);
        
            assertEquals(0b101010, bitInputStreamBigEndian.readBits(6));
            assertEquals(0b1011001100, bitInputStreamBigEndian.readBits(10));
            assertEquals(0b11110000, bitInputStreamBigEndian.readBits(8));
        }

    @Test
        public void testReadBitsMixedCallsLittleEndian() throws IOException {
            InputStream mockInputStream = mock(InputStream.class);
            when(mockInputStream.read())
                .thenReturn(0b10101010)
                .thenReturn(0b11001100)
                .thenReturn(0b11110000);
            
            BitInputStream bitInputStreamLittleEndian = new BitInputStream(mockInputStream, ByteOrder.LITTLE_ENDIAN);
            
            assertEquals(0b101010, bitInputStreamLittleEndian.readBits(6));
            assertEquals(0b1100110010, bitInputStreamLittleEndian.readBits(10));
            assertEquals(0b11110000, bitInputStreamLittleEndian.readBits(8));
        }

    @Test
        public void testReadBitsEndOfStreamDuringRead() throws IOException {
            InputStream mockInputStream = mock(InputStream.class);
            BitInputStream bitInputStreamBigEndian = new BitInputStream(mockInputStream, ByteOrder.BIG_ENDIAN);
            
            when(mockInputStream.read())
                .thenReturn(0b10101010)
                .thenReturn(-1);
        
            assertEquals(0b10101010, bitInputStreamBigEndian.readBits(8));
            assertEquals(-1, bitInputStreamBigEndian.readBits(8));
        }


}
