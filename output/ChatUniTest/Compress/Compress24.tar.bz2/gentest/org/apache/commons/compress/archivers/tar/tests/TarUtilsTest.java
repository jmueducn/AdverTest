package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                public void testParseOctalWithValidInput() {
                                                    byte[] buffer = " 1234 \0".getBytes();
                                                    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                    assertEquals(668, result);
                                                }

    @Test
                                                public void testParseOctalWithLeadingZero() {
                                                    byte[] buffer = "01234".getBytes();
                                                    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                    assertEquals(0L, result);
                                                }

    @Test
                                                public void testParseOctalWithLeadingSpaces() {
                                                    byte[] buffer = "   1234 ".getBytes();
                                                    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                    assertEquals(668, result);
                                                }

    @Test
                                                public void testParseOctalWithTrailingSpaces() {
                                                    byte[] buffer = "1234   ".getBytes();
                                                    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                    assertEquals(668, result);
                                                }

    @Test
                                                public void testParseOctalWithTrailingNULs() {
                                                    byte[] buffer = "1234\0\0\0".getBytes();
                                                    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                    assertEquals(668, result);
                                                }

    @Test
                                                public void testParseOctalWithSingleDigit() {
                                                    byte[] buffer = " 5 \0".getBytes();
                                                    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                    assertEquals(5, result);
                                                }

    @Test(expected = IllegalArgumentException.class)
                                                public void testParseOctalWithInvalidCharacter() {
                                                    byte[] buffer = "12a4".getBytes();
                                                    TarUtils.parseOctal(buffer, 0, buffer.length);
                                                }

    @Test(expected = IllegalArgumentException.class)
                                                public void testParseOctalWithLengthLessThan() {
                                                    byte[] buffer = "1".getBytes();
                                                    TarUtils.parseOctal(buffer, 0, buffer.length);
                                                }

    @Test(expected = IllegalArgumentException.class)
                                                public void testParseOctalWithAllSpaces() {
                                                    byte[] buffer = "    ".getBytes();
                                                    TarUtils.parseOctal(buffer, 0, buffer.length);
                                                }

    @Test(expected = IllegalArgumentException.class)
                                                public void testParseOctalWithAllNULs() {
                                                    byte[] buffer = new byte[] {0, 0, 0, 0};
                                                    TarUtils.parseOctal(buffer, 0, buffer.length);
                                                }

    @Test
                                                public void testParseOctalWithMaxOctalValue() {
                                                    byte[] buffer = "7777777777777777777".getBytes();
                                                    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                    assertEquals(Long.MAX_VALUE, result);
                                                }

    @Test
                                                public void testExceptionMessage() throws Exception {
                                                    byte[] buffer = "12a4".getBytes();
                                                    Method exceptionMessage = TarUtils.class.getDeclaredMethod(
                                                        "exceptionMessage", byte[].class, int.class, int.class, int.class, byte.class);
                                                    exceptionMessage.setAccessible(true);
                                                    
                                                    String message = (String) exceptionMessage.invoke(null, 
                                                        buffer, 0, buffer.length, 2, (byte)'a');
                                                    
                                                    assertTrue(message.contains("Invalid byte"));
                                                    assertTrue(message.contains("at offset 2"));
                                                }


}
