package gentest.org.apache.commons.compress.archivers.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.*;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.apache.commons.compress.archivers.ar.ArArchiveInputStream;
import org.apache.commons.compress.archivers.ar.ArArchiveOutputStream;
import org.apache.commons.compress.archivers.arj.ArjArchiveInputStream;
import org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream;
import org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream;
import org.apache.commons.compress.archivers.dump.DumpArchiveInputStream;
import org.apache.commons.compress.archivers.jar.JarArchiveInputStream;
import org.apache.commons.compress.archivers.jar.JarArchiveOutputStream;
import org.apache.commons.compress.archivers.sevenz.SevenZFile;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import org.apache.commons.compress.utils.IOUtils;
 
public class ArchiveStreamFactoryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                    public void testGetEntryEncodingWhenDefaultConstructorUsed() {
                        ArchiveStreamFactory factory = new ArchiveStreamFactory();
                        assertNull(factory.getEntryEncoding());
                    }

    @Test
                    public void testGetEntryEncodingWhenEncodingConstructorUsed() {
                        String encoding = "UTF-8";
                        ArchiveStreamFactory factory = new ArchiveStreamFactory(encoding);
                        assertEquals(encoding, factory.getEntryEncoding());
                    }

    @Test
                    public void testGetEntryEncodingAfterSetEntryEncoding() throws Exception {
                        ArchiveStreamFactory factory = new ArchiveStreamFactory();
                        
                        // Use reflection to set the private field since setEntryEncoding is deprecated
                        Field entryEncodingField = ArchiveStreamFactory.class.getDeclaredField("entryEncoding");
                        entryEncodingField.setAccessible(true);
                        entryEncodingField.set(factory, "UTF-16");
                        
                        assertEquals("UTF-16", factory.getEntryEncoding());
                    }

    @Test
                    public void testGetEntryEncodingWhenNullEncodingConstructorUsed() {
                        ArchiveStreamFactory factory = new ArchiveStreamFactory(null);
                        assertNull(factory.getEntryEncoding());
                    }

    @Test
                    public void testGetEntryEncodingAfterDeprecatedSetMethod() throws Exception {
                        ArchiveStreamFactory factory = new ArchiveStreamFactory();
                        
                        // This will work because we didn't use the encoding constructor
                        factory.setEntryEncoding("ISO-8859-1");
                        assertEquals("ISO-8859-1", factory.getEntryEncoding());
                    }

    @Test(expected = IllegalArgumentException.class)
                public void testCreateArchiveInputStreamWithNullArchiverName() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                    factory.createArchiveInputStream(null, inputStream);
                }

    @Test(expected = IllegalArgumentException.class)
                public void testCreateArchiveInputStreamWithNullInputStream() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, null);
                }

    @Test
                public void testCreateArArchiveInputStream() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                    ArchiveInputStream ais = factory.createArchiveInputStream(ArchiveStreamFactory.AR, inputStream);
                    assertTrue(ais instanceof ArArchiveInputStream);
                }

    @Test
                public void testCreateArjArchiveInputStream() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                    ArchiveInputStream ais = factory.createArchiveInputStream(ArchiveStreamFactory.ARJ, inputStream);
                    assertTrue(ais instanceof ArjArchiveInputStream);
                }

    @Test
                public void testCreateArjArchiveInputStreamWithEncoding() throws Exception {
                    ArchiveStreamFactory factoryWithEncoding = new ArchiveStreamFactory("UTF-8");
                    ByteArrayInputStream inputStream = new ByteArrayInputStream(new byte[0]);
                    ArchiveInputStream ais = factoryWithEncoding.createArchiveInputStream(ArchiveStreamFactory.ARJ, inputStream);
                    assertTrue(ais instanceof ArjArchiveInputStream);
                }

    @Test
                public void testCreateZipArchiveInputStream() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    ByteArrayInputStream inputStream = new ByteArrayInputStream(new byte[0]);
                    ArchiveInputStream ais = factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, inputStream);
                    assertTrue(ais instanceof ZipArchiveInputStream);
                }

    @Test
                public void testCreateZipArchiveInputStreamWithEncoding() throws Exception {
                    ArchiveStreamFactory factoryWithEncoding = new ArchiveStreamFactory("UTF-8");
                    ByteArrayInputStream inputStream = new ByteArrayInputStream(new byte[0]);
                    ArchiveInputStream ais = factoryWithEncoding.createArchiveInputStream(ArchiveStreamFactory.ZIP, inputStream);
                    assertTrue(ais instanceof ZipArchiveInputStream);
                }

    @Test
                public void testCreateTarArchiveInputStream() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    ByteArrayInputStream inputStream = new ByteArrayInputStream(new byte[0]);
                    ArchiveInputStream ais = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, inputStream);
                    assertTrue(ais instanceof TarArchiveInputStream);
                }

    @Test
                public void testCreateTarArchiveInputStreamWithEncoding() throws Exception {
                    ArchiveStreamFactory factoryWithEncoding = new ArchiveStreamFactory("UTF-8");
                    ByteArrayInputStream inputStream = new ByteArrayInputStream(new byte[0]);
                    ArchiveInputStream ais = factoryWithEncoding.createArchiveInputStream(ArchiveStreamFactory.TAR, inputStream);
                    assertTrue(ais instanceof TarArchiveInputStream);
                }

    @Test
                public void testCreateJarArchiveInputStream() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    ByteArrayInputStream inputStream = new ByteArrayInputStream(new byte[0]);
                    ArchiveInputStream ais = factory.createArchiveInputStream(ArchiveStreamFactory.JAR, inputStream);
                    assertTrue(ais instanceof JarArchiveInputStream);
                }

    @Test
                public void testCreateJarArchiveInputStreamWithEncoding() throws Exception {
                    ArchiveStreamFactory factoryWithEncoding = new ArchiveStreamFactory("UTF-8");
                    ByteArrayInputStream inputStream = new ByteArrayInputStream(new byte[0]);
                    ArchiveInputStream ais = factoryWithEncoding.createArchiveInputStream(ArchiveStreamFactory.JAR, inputStream);
                    assertTrue(ais instanceof JarArchiveInputStream);
                }

    @Test
                public void testCreateCpioArchiveInputStream() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    ByteArrayInputStream inputStream = new ByteArrayInputStream(new byte[0]);
                    ArchiveInputStream ais = factory.createArchiveInputStream(ArchiveStreamFactory.CPIO, inputStream);
                    assertTrue(ais instanceof CpioArchiveInputStream);
                }

    @Test
                public void testCreateCpioArchiveInputStreamWithEncoding() throws Exception {
                    ArchiveStreamFactory factoryWithEncoding = new ArchiveStreamFactory("UTF-8");
                    ByteArrayInputStream inputStream = new ByteArrayInputStream(new byte[0]);
                    ArchiveInputStream ais = factoryWithEncoding.createArchiveInputStream(ArchiveStreamFactory.CPIO, inputStream);
                    assertTrue(ais instanceof CpioArchiveInputStream);
                }

    @Test
                public void testCreateDumpArchiveInputStream() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                    ArchiveInputStream ais = factory.createArchiveInputStream(ArchiveStreamFactory.DUMP, inputStream);
                    assertTrue(ais instanceof DumpArchiveInputStream);
                }

    @Test
                public void testCreateDumpArchiveInputStreamWithEncoding() throws Exception {
                    ArchiveStreamFactory factoryWithEncoding = new ArchiveStreamFactory("UTF-8");
                    ByteArrayInputStream inputStream = new ByteArrayInputStream(new byte[0]);
                    
                    ArchiveInputStream ais = factoryWithEncoding.createArchiveInputStream(ArchiveStreamFactory.DUMP, inputStream);
                    assertTrue(ais instanceof DumpArchiveInputStream);
                }

    @Test(expected = StreamingNotSupportedException.class)
                public void testCreateSevenZArchiveInputStream() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                    factory.createArchiveInputStream(ArchiveStreamFactory.SEVEN_Z, inputStream);
                }

    @Test(expected = ArchiveException.class)
                public void testCreateUnknownArchiveInputStream() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                    factory.createArchiveInputStream("unknown", inputStream);
                }

    @Test
                public void testCreateArchiveInputStreamCaseInsensitive() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                    ArchiveInputStream ais = factory.createArchiveInputStream("ZiP", inputStream);
                    assertTrue(ais instanceof ZipArchiveInputStream);
                }

    @Test
                public void testCreateArchiveInputStreamWithEmptyStream() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    InputStream emptyStream = new ByteArrayInputStream(new byte[0]);
                    ArchiveInputStream ais = factory.createArchiveInputStream(ArchiveStreamFactory.AR, emptyStream);
                    assertTrue(ais instanceof ArArchiveInputStream);
                }

    @Test
                public void testCreateArchiveOutputStreamWithNullArchiverName() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    OutputStream mockOutputStream = mock(OutputStream.class);
                    
                    thrown.expect(IllegalArgumentException.class);
                    thrown.expectMessage("Archivername must not be null.");
                    factory.createArchiveOutputStream(null, mockOutputStream);
                }

    @Test(expected = IllegalArgumentException.class)
                public void testCreateArchiveOutputStreamWithNullOutputStream() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    factory.createArchiveOutputStream(ArchiveStreamFactory.ZIP, null);
                }

    @Test
                public void testCreateArArchiveOutputStream() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    java.io.OutputStream mockOutputStream = mock(java.io.OutputStream.class);
                    
                    ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.AR, mockOutputStream);
                    assertTrue(result instanceof ArArchiveOutputStream);
                }

    @Test
                public void testCreateZipArchiveOutputStream() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    ByteArrayOutputStream mockOutputStream = new ByteArrayOutputStream();
                    ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.ZIP, mockOutputStream);
                    assertTrue(result instanceof ZipArchiveOutputStream);
                }

    @Test
                public void testCreateZipArchiveOutputStreamWithEncoding() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    OutputStream mockOutputStream = mock(OutputStream.class);
                    
                    // Use reflection to set the entry encoding
                    factory.getClass()
                           .getMethod("setEntryEncoding", String.class)
                           .invoke(factory, "UTF-8");
                    
                    ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.ZIP, mockOutputStream);
                    assertTrue(result instanceof ZipArchiveOutputStream);
                }

    @Test
                public void testCreateTarArchiveOutputStream() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    ByteArrayOutputStream mockOutputStream = new ByteArrayOutputStream();
                    ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.TAR, mockOutputStream);
                    assertTrue(result instanceof TarArchiveOutputStream);
                }

    @Test
                public void testCreateTarArchiveOutputStreamWithEncoding() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    ByteArrayOutputStream mockOutputStream = new ByteArrayOutputStream();
                    
                    // Use reflection to set entry encoding
                    factory.getClass().getMethod("setEntryEncoding", String.class).invoke(factory, "UTF-8");
                    
                    ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.TAR, mockOutputStream);
                    assertTrue(result instanceof TarArchiveOutputStream);
                }

    @Test
                public void testCreateJarArchiveOutputStream() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    OutputStream mockOutputStream = mock(OutputStream.class);
                    ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.JAR, mockOutputStream);
                    assertTrue(result instanceof JarArchiveOutputStream);
                }

    @Test
                public void testCreateJarArchiveOutputStreamWithEncoding() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    ByteArrayOutputStream mockOutputStream = new ByteArrayOutputStream();
                    
                    // Set entry encoding using reflection since it's likely a private field
                    java.lang.reflect.Field field = ArchiveStreamFactory.class.getDeclaredField("entryEncoding");
                    field.setAccessible(true);
                    field.set(factory, "UTF-8");
                    
                    ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.JAR, mockOutputStream);
                    assertTrue(result instanceof JarArchiveOutputStream);
                }

    @Test
                public void testCreateCpioArchiveOutputStream() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    OutputStream mockOutputStream = mock(OutputStream.class);
                    ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.CPIO, mockOutputStream);
                    assertTrue(result instanceof CpioArchiveOutputStream);
                }

    @Test
                public void testCreateCpioArchiveOutputStreamWithEncoding() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    OutputStream mockOutputStream = mock(OutputStream.class);
                    
                    // Set entry encoding using reflection since it's likely a private field
                    java.lang.reflect.Field field = ArchiveStreamFactory.class.getDeclaredField("entryEncoding");
                    field.setAccessible(true);
                    field.set(factory, "UTF-8");
                    
                    ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.CPIO, mockOutputStream);
                    assertTrue(result instanceof CpioArchiveOutputStream);
                }

    @Test(expected = ArchiveException.class)
                public void testCreateSevenZArchiveOutputStream() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    OutputStream mockOutputStream = new OutputStream() {
                        @Override
                        public void write(int b) {
                            // Empty implementation for mock
                        }
                    };
                    factory.createArchiveOutputStream(ArchiveStreamFactory.SEVEN_Z, mockOutputStream);
                    fail("Expected ArchiveException to be thrown");
                }

    @Test(expected = ArchiveException.class)
                public void testCreateUnknownArchiveOutputStream() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    OutputStream mockOutputStream = mock(OutputStream.class);
                    factory.createArchiveOutputStream("unknown", mockOutputStream);
                }

    @Test(expected = IllegalArgumentException.class)
                public void testCreateArchiveInputStreamWithNullStream() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    factory.createArchiveInputStream(null);
                }

    @Test(expected = IllegalArgumentException.class)
                public void testCreateArchiveInputStreamWithNonMarkSupportedStream() throws Exception {
                    InputStream inputStream = mock(InputStream.class);
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    when(inputStream.markSupported()).thenReturn(false);
                    factory.createArchiveInputStream(inputStream);
                }

    @Test
                public void testCreateZipArchiveInputStream1() throws Exception {
                    byte[] zipSignature = new byte[] {0x50, 0x4B, 0x03, 0x04};
                    InputStream in = new ByteArrayInputStream(zipSignature);
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    ArchiveInputStream ais = factory.createArchiveInputStream(in);
                    assertTrue(ais instanceof ZipArchiveInputStream);
                }

    @Test
                public void testCreateZipArchiveInputStreamWithEncoding1() throws Exception {
                    byte[] zipSignature = new byte[] {0x50, 0x4B, 0x03, 0x04};
                    InputStream in = new ByteArrayInputStream(zipSignature);
                    ArchiveStreamFactory factoryWithEncoding = new ArchiveStreamFactory("UTF-8");
                    ArchiveInputStream ais = factoryWithEncoding.createArchiveInputStream(in);
                    assertTrue(ais instanceof ZipArchiveInputStream);
                }

    @Test
                public void testCreateJarArchiveInputStream1() throws Exception {
                    byte[] jarSignature = new byte[] {0x50, 0x4B, 0x03, 0x04};
                    InputStream in = new ByteArrayInputStream(jarSignature);
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    ArchiveInputStream ais = factory.createArchiveInputStream(in);
                    assertTrue(ais instanceof JarArchiveInputStream);
                }

    @Test
                public void testCreateJarArchiveInputStreamWithEncoding1() throws Exception {
                    ArchiveStreamFactory factoryWithEncoding = new ArchiveStreamFactory("UTF-8");
                    byte[] jarSignature = new byte[] {0x50, 0x4B, 0x03, 0x04};
                    InputStream in = new ByteArrayInputStream(jarSignature);
                    ArchiveInputStream ais = factoryWithEncoding.createArchiveInputStream(in);
                    assertTrue(ais instanceof JarArchiveInputStream);
                }

    @Test
                public void testCreateArArchiveInputStream1() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    byte[] arSignature = new byte[] {0x21, 0x3C, 0x61, 0x72, 0x63, 0x68, 0x3E};
                    InputStream in = new ByteArrayInputStream(arSignature);
                    ArchiveInputStream ais = factory.createArchiveInputStream(in);
                    assertTrue(ais instanceof ArArchiveInputStream);
                }

    @Test
                public void testCreateCpioArchiveInputStream1() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    byte[] cpioSignature = new byte[] {0x30, 0x37, 0x30, 0x37, 0x30, 0x31};
                    InputStream in = new ByteArrayInputStream(cpioSignature);
                    ArchiveInputStream ais = factory.createArchiveInputStream(in);
                    assertTrue(ais instanceof CpioArchiveInputStream);
                }

    @Test
                public void testCreateCpioArchiveInputStreamWithEncoding1() throws Exception {
                    byte[] cpioSignature = new byte[] {0x30, 0x37, 0x30, 0x37, 0x30, 0x31};
                    InputStream in = new ByteArrayInputStream(cpioSignature);
                    ArchiveStreamFactory factoryWithEncoding = new ArchiveStreamFactory("UTF-8");
                    ArchiveInputStream ais = factoryWithEncoding.createArchiveInputStream(in);
                    assertTrue(ais instanceof CpioArchiveInputStream);
                }

    @Test
                public void testCreateArjArchiveInputStream1() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    byte[] arjSignature = new byte[] {(byte)0x60, (byte)0xEA};
                    InputStream in = new ByteArrayInputStream(arjSignature);
                    ArchiveInputStream ais = factory.createArchiveInputStream(in);
                    assertTrue(ais instanceof ArjArchiveInputStream);
                }

    @Test
                public void testCreateArjArchiveInputStreamWithEncoding1() throws Exception {
                    ArchiveStreamFactory factoryWithEncoding = new ArchiveStreamFactory("UTF-8");
                    byte[] arjSignature = new byte[] {(byte)0x60, (byte)0xEA};
                    InputStream in = new ByteArrayInputStream(arjSignature);
                    ArchiveInputStream ais = factoryWithEncoding.createArchiveInputStream(in);
                    assertTrue(ais instanceof ArjArchiveInputStream);
                }

    @Test(expected = org.apache.commons.compress.archivers.StreamingNotSupportedException.class)
                public void testCreateSevenZArchiveInputStream1() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    byte[] sevenZSignature = new byte[] {'7', 'z', (byte)0xBC, (byte)0xAF, 0x27, 0x1C};
                    InputStream in = new ByteArrayInputStream(sevenZSignature);
                    factory.createArchiveInputStream(in);
                }

    @Test
                public void testCreateDumpArchiveInputStream1() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    byte[] dumpSignature = new byte[] {0x43, 0x44, 0x30, 0x30, 0x31};
                    InputStream in = new ByteArrayInputStream(dumpSignature);
                    ArchiveInputStream ais = factory.createArchiveInputStream(in);
                    assertTrue(ais instanceof DumpArchiveInputStream);
                }

    @Test
                public void testCreateDumpArchiveInputStreamWithEncoding1() throws Exception {
                    ArchiveStreamFactory factoryWithEncoding = new ArchiveStreamFactory("UTF-8");
                    byte[] dumpSignature = new byte[] {0x43, 0x44, 0x30, 0x30, 0x31};
                    InputStream in = new ByteArrayInputStream(dumpSignature);
                    ArchiveInputStream ais = factoryWithEncoding.createArchiveInputStream(in);
                    assertTrue(ais instanceof DumpArchiveInputStream);
                }

    @Test
                public void testCreateTarArchiveInputStream1() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    byte[] tarSignature = new byte[512];
                    tarSignature[257] = 'u';
                    tarSignature[258] = 's';
                    tarSignature[259] = 't';
                    tarSignature[260] = 'a';
                    tarSignature[261] = 'r';
                    InputStream in = new ByteArrayInputStream(tarSignature);
                    ArchiveInputStream ais = factory.createArchiveInputStream(in);
                    assertTrue(ais instanceof TarArchiveInputStream);
                }

    @Test
                public void testCreateTarArchiveInputStreamWithEncoding1() throws Exception {
                    ArchiveStreamFactory factoryWithEncoding = new ArchiveStreamFactory("UTF-8");
                    byte[] tarSignature = new byte[512];
                    tarSignature[257] = 'u';
                    tarSignature[258] = 's';
                    tarSignature[259] = 't';
                    tarSignature[260] = 'a';
                    tarSignature[261] = 'r';
                    InputStream in = new ByteArrayInputStream(tarSignature);
                    ArchiveInputStream ais = factoryWithEncoding.createArchiveInputStream(in);
                    assertTrue(ais instanceof TarArchiveInputStream);
                }

    @Test(expected = ArchiveException.class)
                public void testCreateArchiveInputStreamWithUnknownSignature() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    byte[] unknownSignature = new byte[] {0x00, 0x01, 0x02, 0x03};
                    InputStream in = new ByteArrayInputStream(unknownSignature);
                    factory.createArchiveInputStream(in);
                }

    @Test
                public void testMatchesMethodForTar() throws Exception {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    byte[] tarHeader = new byte[512];
                    tarHeader[257] = 'u';
                    tarHeader[258] = 's';
                    tarHeader[259] = 't';
                    tarHeader[260] = 'a';
                    tarHeader[261] = 'r';
                    
                    Method matchesMethod = ArchiveStreamFactory.class.getDeclaredMethod("matches", byte[].class, int.class);
                    matchesMethod.setAccessible(true);
                    
                    boolean result = (boolean) matchesMethod.invoke(factory, tarHeader, 512);
                    assertTrue(result);
                }

    @Test(expected = IOException.class)
        public void testCreateArchiveInputStreamWithIOException() throws Exception {
            InputStream inputStream = mock(InputStream.class);
            ArchiveStreamFactory factory = new ArchiveStreamFactory();
            
            when(inputStream.markSupported()).thenReturn(true);
            doThrow(new IOException()).when(inputStream).mark(anyInt());
            factory.createArchiveInputStream(inputStream);
        }


}
