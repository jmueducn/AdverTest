package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.Serializable;
import java.util.Date;
import java.util.zip.ZipException;
 
public class X5455_ExtendedTimestampTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testUnixTimeToZipLongWithValidValue() throws Exception {
            Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
            method.setAccessible(true);
            
            long testValue = 1234567890L;
            ZipLong result = (ZipLong) method.invoke(null, testValue);
            assertEquals(testValue, result.getValue());
        }

    @Test
        public void testUnixTimeToZipLongWithMinIntegerValue() throws Exception {
            Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
            method.setAccessible(true);
            
            long testValue = Integer.MIN_VALUE;
            ZipLong result = (ZipLong) method.invoke(null, testValue);
            assertEquals(testValue, result.getValue());
        }

    @Test
        public void testUnixTimeToZipLongWithMaxIntegerValue() throws Exception {
            Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
            method.setAccessible(true);
            
            long testValue = Integer.MAX_VALUE;
            ZipLong result = (ZipLong) method.invoke(null, testValue);
            assertEquals(testValue, result.getValue());
        }

    @Test(expected = IllegalArgumentException.class)
        public void testUnixTimeToZipLongWithValueBelowMinInteger() throws Exception {
            Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
            method.setAccessible(true);
            
            long testValue = Integer.MIN_VALUE - 1L;
            method.invoke(null, testValue);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testUnixTimeToZipLongWithValueAboveMaxInteger() throws Exception {
            Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
            method.setAccessible(true);
            
            long testValue = Integer.MAX_VALUE + 1L;
            method.invoke(null, testValue);
        }

    @Test
        public void testUnixTimeToZipLongWithZeroValue() throws Exception {
            Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
            method.setAccessible(true);
            
            long testValue = 0L;
            ZipLong result = (ZipLong) method.invoke(null, testValue);
            assertEquals(testValue, result.getValue());
        }

    @Test
        public void testUnixTimeToZipLongWithNegativeValueWithinRange() throws Exception {
            Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
            method.setAccessible(true);
            
            long testValue = -1234567890L;
            ZipLong result = (ZipLong) method.invoke(null, testValue);
            assertEquals(testValue, result.getValue());
        }

}
