package gentest.org.apache.commons.compress.compressors.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.compressors.*;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorOutputStream;
import org.apache.commons.compress.compressors.deflate.DeflateCompressorInputStream;
import org.apache.commons.compress.compressors.deflate.DeflateCompressorOutputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream;
import org.apache.commons.compress.compressors.lzma.LZMACompressorInputStream;
import org.apache.commons.compress.compressors.lzma.LZMAUtils;
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream;
import org.apache.commons.compress.compressors.xz.XZCompressorOutputStream;
import org.apache.commons.compress.compressors.xz.XZUtils;
import org.apache.commons.compress.compressors.pack200.Pack200CompressorInputStream;
import org.apache.commons.compress.compressors.pack200.Pack200CompressorOutputStream;
import org.apache.commons.compress.compressors.snappy.FramedSnappyCompressorInputStream;
import org.apache.commons.compress.compressors.snappy.SnappyCompressorInputStream;
import org.apache.commons.compress.compressors.z.ZCompressorInputStream;
import org.apache.commons.compress.utils.IOUtils;
 
public class CompressorStreamFactoryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test(expected = IllegalArgumentException.class)
                                            public void testCreateCompressorInputStreamWithNullStream() throws CompressorException {
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                factory.createCompressorInputStream(null);
                                            }

    @Test(expected = IllegalArgumentException.class)
                                            public void testCreateCompressorInputStreamWithNonMarkSupportedStream() throws CompressorException {
                                                InputStream inputStream = mock(InputStream.class);
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                when(inputStream.markSupported()).thenReturn(false);
                                                factory.createCompressorInputStream(inputStream);
                                            }

    @Test(expected = CompressorException.class)
                                            public void testCreateCompressorInputStreamWithIOException() throws Exception {
                                                InputStream inputStream = mock(InputStream.class);
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                
                                                when(inputStream.markSupported()).thenReturn(true);
                                                when(IOUtils.readFully(any(InputStream.class), any(byte[].class))).thenThrow(new IOException());
                                                factory.createCompressorInputStream(inputStream);
                                            }

    @Test
                                            public void testCreateBZip2CompressorInputStream() throws Exception {
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                InputStream inputStream = mock(InputStream.class);
                                                
                                                when(inputStream.markSupported()).thenReturn(true);
                                                byte[] signature = new byte[12];
                                                when(IOUtils.readFully(any(InputStream.class), any(byte[].class))).thenReturn(12);
                                                when(BZip2CompressorInputStream.matches(signature, 12)).thenReturn(true);
                                                
                                                factory.createCompressorInputStream(inputStream);
                                                verify(inputStream).mark(12);
                                                verify(inputStream).reset();
                                            }

    @Test
                                            public void testCreateGzipCompressorInputStream() throws Exception {
                                                // Setup
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                InputStream inputStream = mock(InputStream.class);
                                                
                                                // Mock behavior
                                                when(inputStream.markSupported()).thenReturn(true);
                                                byte[] signature = new byte[12];
                                                when(IOUtils.readFully(any(InputStream.class), any(byte[].class))).thenReturn(12);
                                                when(GzipCompressorInputStream.matches(signature, 12)).thenReturn(true);
                                                
                                                // Test
                                                factory.createCompressorInputStream(inputStream);
                                                
                                                // Verify
                                                verify(inputStream).mark(12);
                                                verify(inputStream).reset();
                                            }

    @Test
                                            public void testCreatePack200CompressorInputStream() throws Exception {
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                InputStream inputStream = mock(InputStream.class);
                                                
                                                when(inputStream.markSupported()).thenReturn(true);
                                                byte[] signature = new byte[12];
                                                when(IOUtils.readFully(any(InputStream.class), any(byte[].class))).thenReturn(12);
                                                when(Pack200CompressorInputStream.matches(signature, 12)).thenReturn(true);
                                                
                                                factory.createCompressorInputStream(inputStream);
                                                verify(inputStream).mark(12);
                                                verify(inputStream).reset();
                                            }

    @Test
                                            public void testCreateFramedSnappyCompressorInputStream() throws Exception {
                                                InputStream inputStream = mock(InputStream.class);
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                
                                                when(inputStream.markSupported()).thenReturn(true);
                                                byte[] signature = new byte[12];
                                                when(IOUtils.readFully(any(InputStream.class), any(byte[].class))).thenReturn(12);
                                                when(FramedSnappyCompressorInputStream.matches(signature, 12)).thenReturn(true);
                                                
                                                factory.createCompressorInputStream(inputStream);
                                                verify(inputStream).mark(12);
                                                verify(inputStream).reset();
                                            }

    @Test
                                            public void testCreateZCompressorInputStream() throws Exception {
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                InputStream inputStream = mock(InputStream.class);
                                                
                                                when(inputStream.markSupported()).thenReturn(true);
                                                byte[] signature = new byte[12];
                                                when(IOUtils.readFully(any(InputStream.class), any(byte[].class))).thenReturn(12);
                                                when(ZCompressorInputStream.matches(signature, 12)).thenReturn(true);
                                                
                                                factory.createCompressorInputStream(inputStream);
                                                verify(inputStream).mark(12);
                                                verify(inputStream).reset();
                                            }

    @Test
                                            public void testCreateDeflateCompressorInputStream() throws Exception {
                                                InputStream inputStream = mock(InputStream.class);
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                
                                                when(inputStream.markSupported()).thenReturn(true);
                                                byte[] signature = new byte[12];
                                                when(IOUtils.readFully(any(InputStream.class), any(byte[].class))).thenReturn(12);
                                                when(DeflateCompressorInputStream.matches(signature, 12)).thenReturn(true);
                                                
                                                factory.createCompressorInputStream(inputStream);
                                                verify(inputStream).mark(12);
                                                verify(inputStream).reset();
                                            }

    @Test
                                            public void testCreateXZCompressorInputStream() throws Exception {
                                                InputStream inputStream = mock(InputStream.class);
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                
                                                when(inputStream.markSupported()).thenReturn(true);
                                                byte[] signature = new byte[12];
                                                when(IOUtils.readFully(any(InputStream.class), any(byte[].class))).thenReturn(12);
                                                when(XZUtils.matches(signature, 12)).thenReturn(true);
                                                when(XZUtils.isXZCompressionAvailable()).thenReturn(true);
                                                
                                                factory.createCompressorInputStream(inputStream);
                                                verify(inputStream).mark(12);
                                                verify(inputStream).reset();
                                            }

    @Test
                                            public void testCreateLZMACompressorInputStream() throws Exception {
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                InputStream inputStream = mock(InputStream.class);
                                                
                                                when(inputStream.markSupported()).thenReturn(true);
                                                byte[] signature = new byte[12];
                                                when(IOUtils.readFully(any(InputStream.class), any(byte[].class))).thenReturn(12);
                                                when(LZMAUtils.matches(signature, 12)).thenReturn(true);
                                                when(LZMAUtils.isLZMACompressionAvailable()).thenReturn(true);
                                                
                                                factory.createCompressorInputStream(inputStream);
                                                verify(inputStream).mark(12);
                                                verify(inputStream).reset();
                                            }

                                            public void testCreateCompressorInputStreamWithNoMatchingSignature() throws Exception {
                                                InputStream inputStream = mock(InputStream.class);
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                
                                                when(inputStream.markSupported()).thenReturn(true);
                                                byte[] signature = new byte[12];
                                                when(IOUtils.readFully(any(InputStream.class), any(byte[].class))).thenReturn(12);
                                                
                                                factory.createCompressorInputStream(inputStream);
                                            }

    @Test
                                            public void testCreateCompressorInputStreamWithDecompressConcatenated() throws Exception {
                                                CompressorStreamFactory factory = new CompressorStreamFactory(true);
                                                Field field = CompressorStreamFactory.class.getDeclaredField("decompressConcatenated");
                                                field.setAccessible(true);
                                                assertTrue(field.getBoolean(factory));
                                            }

    @Test(expected = IllegalArgumentException.class)
                                            public void testCreateCompressorInputStreamWithNullName() throws Exception {
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                                                factory.createCompressorInputStream(null, inputStream);
                                            }

    @Test(expected = IllegalArgumentException.class)
                                            public void testCreateCompressorInputStreamWithNullStream1() throws Exception {
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                factory.createCompressorInputStream(CompressorStreamFactory.GZIP, null);
                                            }

    @Test(expected = IllegalArgumentException.class)
                                            public void testCreateCompressorInputStreamWithBothNull() throws Exception {
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                factory.createCompressorInputStream(null, null);
                                            }

    @Test
                                            public void testCreateGzipCompressorInputStream1() throws Exception {
                                                InputStream inputStream = mock(InputStream.class);
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                
                                                when(inputStream.read(any(byte[].class))).thenReturn(-1);
                                                assertTrue(factory.createCompressorInputStream(CompressorStreamFactory.GZIP, inputStream)
                                                    instanceof GzipCompressorInputStream);
                                            }

    @Test
                                            public void testCreateBzip2CompressorInputStream() throws Exception {
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                InputStream inputStream = mock(InputStream.class);
                                                when(inputStream.read(any(byte[].class))).thenReturn(-1);
                                                assertTrue(factory.createCompressorInputStream(CompressorStreamFactory.BZIP2, inputStream) 
                                                    instanceof BZip2CompressorInputStream);
                                            }

    @Test
                                            public void testCreateXzCompressorInputStream() throws Exception {
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                InputStream inputStream = mock(InputStream.class);
                                                when(inputStream.read(any(byte[].class))).thenReturn(-1);
                                                assertTrue(factory.createCompressorInputStream(CompressorStreamFactory.XZ, inputStream)
                                                    instanceof XZCompressorInputStream);
                                            }

    @Test
                                            public void testCreateLzmaCompressorInputStream() throws Exception {
                                                InputStream inputStream = mock(InputStream.class);
                                                when(inputStream.read(any(byte[].class))).thenReturn(-1);
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                assertTrue(factory.createCompressorInputStream(CompressorStreamFactory.LZMA, inputStream)
                                                    instanceof LZMACompressorInputStream);
                                            }

    @Test
                                            public void testCreatePack200CompressorInputStream1() throws Exception {
                                                InputStream inputStream = mock(InputStream.class);
                                                when(inputStream.read(any(byte[].class))).thenReturn(-1);
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                assertTrue(factory.createCompressorInputStream(CompressorStreamFactory.PACK200, inputStream) 
                                                    instanceof Pack200CompressorInputStream);
                                            }

    @Test
                                            public void testCreateSnappyRawCompressorInputStream() throws Exception {
                                                InputStream inputStream = mock(InputStream.class);
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                
                                                when(inputStream.read(any(byte[].class))).thenReturn(-1);
                                                assertTrue(factory.createCompressorInputStream(CompressorStreamFactory.SNAPPY_RAW, inputStream)
                                                    instanceof SnappyCompressorInputStream);
                                            }

    @Test
                                            public void testCreateSnappyFramedCompressorInputStream() throws Exception {
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                InputStream inputStream = mock(InputStream.class);
                                                when(inputStream.read(any(byte[].class))).thenReturn(-1);
                                                assertTrue(factory.createCompressorInputStream(CompressorStreamFactory.SNAPPY_FRAMED, inputStream)
                                                    instanceof FramedSnappyCompressorInputStream);
                                            }

    @Test
                                            public void testCreateZCompressorInputStream1() throws Exception {
                                                InputStream inputStream = mock(InputStream.class);
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                
                                                when(inputStream.read(any(byte[].class))).thenReturn(-1);
                                                assertTrue(factory.createCompressorInputStream(CompressorStreamFactory.Z, inputStream)
                                                    instanceof ZCompressorInputStream);
                                            }

    @Test
                                            public void testCreateDeflateCompressorInputStream1() throws Exception {
                                                InputStream inputStream = mock(InputStream.class);
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                
                                                when(inputStream.read(any(byte[].class))).thenReturn(-1);
                                                assertTrue(factory.createCompressorInputStream(CompressorStreamFactory.DEFLATE, inputStream)
                                                    instanceof DeflateCompressorInputStream);
                                            }

    @Test(expected = CompressorException.class)
                                            public void testCreateCompressorInputStreamWithUnknownName() throws Exception {
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                                                factory.createCompressorInputStream("unknown", inputStream);
                                            }

    @Test(expected = CompressorException.class)
                                            public void testCreateCompressorInputStreamWithIOException1() throws Exception {
                                                InputStream inputStream = mock(InputStream.class);
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                
                                                when(inputStream.read(any(byte[].class))).thenThrow(new IOException());
                                                factory.createCompressorInputStream(CompressorStreamFactory.GZIP, inputStream);
                                            }

    @Test
                                            public void testCreateCompressorInputStreamCaseInsensitive() throws Exception {
                                                CompressorStreamFactory factory = new CompressorStreamFactory();
                                                InputStream inputStream = mock(InputStream.class);
                                                
                                                when(inputStream.read(any(byte[].class))).thenReturn(-1);
                                                assertTrue(factory.createCompressorInputStream("Gz", inputStream) 
                                                    instanceof GzipCompressorInputStream);
                                                assertTrue(factory.createCompressorInputStream("BZIP2", inputStream) 
                                                    instanceof BZip2CompressorInputStream);
                                                assertTrue(factory.createCompressorInputStream("xz", inputStream) 
                                                    instanceof XZCompressorInputStream);
                                            }


}
