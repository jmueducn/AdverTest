package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
 
public class ZipArchiveEntryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
            public void testEqualsSameObject() {
                ZipArchiveEntry entry = new ZipArchiveEntry("test");
                assertTrue(entry.equals(entry));
            }

    @Test
            public void testEqualsNull() {
                ZipArchiveEntry entry = new ZipArchiveEntry("test");
                assertFalse(entry.equals(null));
            }

    @Test
            public void testEqualsDifferentClass() {
                ZipArchiveEntry entry = new ZipArchiveEntry("test");
                assertFalse(entry.equals("string"));
            }

    @Test
            public void testEqualsDifferentName() {
                ZipArchiveEntry entry1 = new ZipArchiveEntry("test1");
                ZipArchiveEntry entry2 = new ZipArchiveEntry("test2");
                assertFalse(entry1.equals(entry2));
            }

    @Test
            public void testEqualsDifferentTime() {
                ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                entry1.setTime(1000);
                entry2.setTime(2000);
                assertFalse(entry1.equals(entry2));
            }

    @Test
            public void testEqualsDifferentComment() {
                ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                entry1.setComment("comment1");
                entry2.setComment("comment2");
                assertFalse(entry1.equals(entry2));
            }

    @Test
            public void testEqualsNullComment() {
                ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                entry1.setComment(null);
                entry2.setComment("comment");
                assertFalse(entry1.equals(entry2));
            }

    @Test
            public void testEqualsBothNullComment() {
                ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                entry1.setComment(null);
                entry2.setComment(null);
                assertTrue(entry1.equals(entry2));
            }

    @Test
            public void testEqualsDifferentInternalAttributes() {
                ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                entry1.setInternalAttributes(1);
                entry2.setInternalAttributes(2);
                assertFalse(entry1.equals(entry2));
            }

    @Test
            public void testEqualsDifferentExternalAttributes() {
                ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                entry1.setExternalAttributes(1);
                entry2.setExternalAttributes(2);
                assertFalse(entry1.equals(entry2));
            }

    @Test
            public void testEqualsDifferentMethod() {
                ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                entry1.setMethod(1);
                entry2.setMethod(2);
                assertFalse(entry1.equals(entry2));
            }

    @Test
            public void testEqualsDifferentSize() {
                ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                entry1.setSize(100);
                entry2.setSize(200);
                assertFalse(entry1.equals(entry2));
            }

    @Test
            public void testEqualsDifferentCrc() {
                ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                entry1.setCrc(100);
                entry2.setCrc(200);
                assertFalse(entry1.equals(entry2));
            }

    @Test
            public void testEqualsDifferentCompressedSize() {
                ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                entry1.setCompressedSize(100);
                entry2.setCompressedSize(200);
                assertFalse(entry1.equals(entry2));
            }

    @Test
            public void testEqualsDifferentCentralDirectoryExtra() {
                ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                entry1.setCentralDirectoryExtra(new byte[]{1, 2, 3});
                entry2.setCentralDirectoryExtra(new byte[]{4, 5, 6});
                assertFalse(entry1.equals(entry2));
            }

    @Test
            public void testEqualsDifferentLocalFileDataExtra() {
                ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                entry1.setExtra(new byte[]{1, 2, 3});
                entry2.setExtra(new byte[]{4, 5, 6});
                assertFalse(entry1.equals(entry2));
            }

    @Test
            public void testEqualsDifferentGeneralPurposeBit() {
                ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                GeneralPurposeBit gpb1 = new GeneralPurposeBit();
                GeneralPurposeBit gpb2 = new GeneralPurposeBit();
                gpb1.useDataDescriptor(true);
                entry1.setGeneralPurposeBit(gpb1);
                entry2.setGeneralPurposeBit(gpb2);
                assertFalse(entry1.equals(entry2));
            }

    @Test
        public void testEqualsNullName() {
            ZipArchiveEntry entry1 = new ZipArchiveEntry((String) null);
            ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
            assertFalse(entry1.equals(entry2));
        }

    @Test
        public void testEqualsBothNullName() {
            ZipArchiveEntry entry1 = new ZipArchiveEntry((String) null);
            ZipArchiveEntry entry2 = new ZipArchiveEntry((String) null);
            assertTrue(entry1.equals(entry2));
        }

    @Test
        public void testEqualsDifferentPlatform() throws Exception {
            ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
            ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
            
            Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
            setPlatformMethod.setAccessible(true);
            setPlatformMethod.invoke(entry1, 0); // PLATFORM_FAT is 0
            setPlatformMethod.invoke(entry2, 3); // PLATFORM_UNIX is 3
            
            assertFalse(entry1.equals(entry2));
        }

    @Test
        public void testEqualsAllFieldsSame() {
            ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
            ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
            entry1.setTime(1000);
            entry2.setTime(1000);
            entry1.setComment("comment");
            entry2.setComment("comment");
            entry1.setInternalAttributes(1);
            entry2.setInternalAttributes(1);
            
            // Using reflection to set protected platform field
            try {
                java.lang.reflect.Field platformField = ZipArchiveEntry.class.getDeclaredField("platform");
                platformField.setAccessible(true);
                platformField.set(entry1, 0); // PLATFORM_FAT is 0
                platformField.set(entry2, 0);
            } catch (Exception e) {
                fail("Failed to set platform field via reflection");
            }
            
            entry1.setExternalAttributes(1);
            entry2.setExternalAttributes(1);
            entry1.setMethod(1);
            entry2.setMethod(1);
            entry1.setSize(100);
            entry2.setSize(100);
            entry1.setCrc(100);
            entry2.setCrc(100);
            entry1.setCompressedSize(100);
            entry2.setCompressedSize(100);
            entry1.setCentralDirectoryExtra(new byte[]{1, 2, 3});
            entry2.setCentralDirectoryExtra(new byte[]{1, 2, 3});
            entry1.setExtra(new byte[]{1, 2, 3});
            entry2.setExtra(new byte[]{1, 2, 3});
            GeneralPurposeBit gpb = new GeneralPurposeBit();
            entry1.setGeneralPurposeBit(gpb);
            entry2.setGeneralPurposeBit(gpb);
            assertTrue(entry1.equals(entry2));
        }


}
