package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                public void testParseOctalWithValidInput() {
                                                    byte[] buffer = {' ', ' ', '1', '2', '3', ' ', ' '};
                                                    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                    assertEquals(83L, result); // 1*64 + 2*8 + 3 = 83
                                                }

    @Test
                                                public void testParseOctalWithLeadingZero() {
                                                    byte[] buffer = {'0', '1', '2', '3', ' '};
                                                    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                    assertEquals(0L, result);
                                                }

    @Test
                                                public void testParseOctalWithLeadingSpaces() {
                                                    byte[] buffer = {' ', ' ', '7', '5', ' ', ' '};
                                                    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                    assertEquals(61L, result); // 7*8 + 5 = 61
                                                }

    @Test
                                                public void testParseOctalWithTrailingSpacesAndNulls() {
                                                    byte[] buffer = {'1', '2', '3', ' ', 0, ' '};
                                                    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                    assertEquals(83L, result); // 1*64 + 2*8 + 3 = 83
                                                }

    @Test(expected = IllegalArgumentException.class)
                                                public void testParseOctalWithInvalidDigit() {
                                                    byte[] buffer = {'1', '2', '9', ' '};
                                                    TarUtils.parseOctal(buffer, 0, buffer.length);
                                                }

    @Test(expected = IllegalArgumentException.class)
                                                public void testParseOctalWithLengthLessThan() {
                                                    byte[] buffer = {'1'};
                                                    TarUtils.parseOctal(buffer, 0, buffer.length);
                                                }

    @Test
                                                public void testParseOctalWithAllNulls() {
                                                    byte[] buffer = {0, 0, 0, 0};
                                                    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                    assertEquals(0L, result);
                                                }

    @Test
                                                public void testParseOctalWithMaxOctalValue() {
                                                    byte[] buffer = {'1', '7', '7', '7', '7', '7', '7', '7', '7', ' '};
                                                    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                    assertEquals(2147483647L, result);
                                                }

    @Test
                                                public void testParseOctalWithSingleDigit() {
                                                    byte[] buffer = {' ', '5', ' '};
                                                    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                    assertEquals(5L, result);
                                                }

    @Test
                                                public void testParseOctalWithMultipleSpaces() {
                                                    byte[] buffer = {' ', ' ', ' ', '3', ' ', ' ', ' '};
                                                    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                    assertEquals(3L, result);
                                                }

    @Test
                                                public void testExceptionMessage() throws Exception {
                                                    byte[] buffer = {'a', 'b', 'c'};
                                                    Method method = TarUtils.class.getDeclaredMethod("exceptionMessage", 
                                                        byte[].class, int.class, int.class, int.class, byte.class);
                                                    method.setAccessible(true);
                                                    
                                                    String message = (String) method.invoke(null, buffer, 0, buffer.length, 1, (byte)'x');
                                                    assertTrue(message.contains("Invalid byte"));
                                                    assertTrue(message.contains("offset 1"));
                                                }


}
