package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringWriter;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
import org.apache.commons.compress.utils.CharsetNames;
import org.apache.commons.compress.utils.CountingOutputStream;
 
public class TarArchiveOutputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test(expected = IOException.class)
                                                                                        public void testWritePaxHeadersThrowsIOException() throws Exception {
                                                                                            Map<String, String> headers = new HashMap<>();
                                                                                            headers.put("key", "value");
                                                                                    
                                                                                            OutputStream failingOutputStream = mock(OutputStream.class);
                                                                                            doThrow(new IOException()).when(failingOutputStream).write(any(byte[].class), anyInt(), anyInt());
                                                                                            
                                                                                            TarArchiveOutputStream failingTarStream = new TarArchiveOutputStream(failingOutputStream);
                                                                                            
                                                                                            Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                "writePaxHeaders", String.class, Map.class);
                                                                                            writePaxHeaders.setAccessible(true);
                                                                                            writePaxHeaders.invoke(failingTarStream, "test.txt", headers);
                                                                                        }

    @Test
                                                                                    public void testWritePaxHeadersWithNormalEntryName() throws Exception {
                                                                                        OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                        TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(mockOutputStream);
                                                                                        
                                                                                        Map<String, String> headers = new HashMap<>();
                                                                                        headers.put("key1", "value1");
                                                                                        headers.put("key2", "value2");
                                                                                
                                                                                        Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                            "writePaxHeaders", String.class, Map.class);
                                                                                        writePaxHeaders.setAccessible(true);
                                                                                        writePaxHeaders.invoke(tarOutputStream, "test.txt", headers);
                                                                                
                                                                                        verify(mockOutputStream, atLeastOnce()).write(any(byte[].class), anyInt(), anyInt());
                                                                                    }

    @Test
                                                                                    public void testWritePaxHeadersWithEntryNameEndingWithSlash() throws Exception {
                                                                                        OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                        TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(mockOutputStream);
                                                                                        
                                                                                        Map<String, String> headers = new HashMap<>();
                                                                                        headers.put("key", "value");
                                                                                        
                                                                                        Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                            "writePaxHeaders", String.class, Map.class);
                                                                                        writePaxHeaders.setAccessible(true);
                                                                                        writePaxHeaders.invoke(tarOutputStream, "test/", headers);
                                                                                        
                                                                                        verify(mockOutputStream, atLeastOnce()).write(any(byte[].class), anyInt(), anyInt());
                                                                                    }

    @Test
                                                                                    public void testWritePaxHeadersWithEmptyHeaders() throws Exception {
                                                                                        OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                        TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(mockOutputStream);
                                                                                        Map<String, String> headers = new HashMap<>();
                                                                                
                                                                                        Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                            "writePaxHeaders", String.class, Map.class);
                                                                                        writePaxHeaders.setAccessible(true);
                                                                                        writePaxHeaders.invoke(tarOutputStream, "test.txt", headers);
                                                                                
                                                                                        verify(mockOutputStream, atLeastOnce()).write(any(byte[].class), anyInt(), anyInt());
                                                                                    }

    @Test
                                                                                    public void testWritePaxHeadersWithNonAsciiCharacters() throws Exception {
                                                                                        OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                        TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(mockOutputStream);
                                                                                        
                                                                                        Map<String, String> headers = new HashMap<>();
                                                                                        headers.put("key", "välue");
                                                                                
                                                                                        Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                            "writePaxHeaders", String.class, Map.class);
                                                                                        writePaxHeaders.setAccessible(true);
                                                                                        writePaxHeaders.invoke(tarOutputStream, "tést.txt", headers);
                                                                                
                                                                                        verify(mockOutputStream, atLeastOnce()).write(any(byte[].class), anyInt(), anyInt());
                                                                                    }

    @Test
                                                                                    public void testWritePaxHeadersWithSpecialCharacters() throws Exception {
                                                                                        OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                        TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(mockOutputStream);
                                                                                        
                                                                                        Map<String, String> headers = new HashMap<>();
                                                                                        headers.put("special", "value with spaces");
                                                                                        headers.put("another", "value=with=equals");
                                                                                
                                                                                        Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                            "writePaxHeaders", String.class, Map.class);
                                                                                        writePaxHeaders.setAccessible(true);
                                                                                        writePaxHeaders.invoke(tarOutputStream, "special!.txt", headers);
                                                                                
                                                                                        verify(mockOutputStream, atLeastOnce()).write(any(byte[].class), anyInt(), anyInt());
                                                                                    }

    @Test
                                                                                    public void testWritePaxHeadersWithMultipleHeaders() throws Exception {
                                                                                        OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                        TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(mockOutputStream);
                                                                                        
                                                                                        Map<String, String> headers = new HashMap<>();
                                                                                        for (int i = 0; i < 10; i++) {
                                                                                            headers.put("key" + i, "value" + i);
                                                                                        }
                                                                                
                                                                                        Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                            "writePaxHeaders", String.class, Map.class);
                                                                                        writePaxHeaders.setAccessible(true);
                                                                                        writePaxHeaders.invoke(tarOutputStream, "multi.txt", headers);
                                                                                
                                                                                        verify(mockOutputStream, atLeastOnce()).write(any(byte[].class), anyInt(), anyInt());
                                                                                    }

    @Test
                                                                                    public void testWritePaxHeadersWithVeryLongHeaderValue() throws Exception {
                                                                                        OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                        TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(mockOutputStream);
                                                                                        
                                                                                        Map<String, String> headers = new HashMap<>();
                                                                                        StringBuilder longValue = new StringBuilder();
                                                                                        for (int i = 0; i < 1000; i++) {
                                                                                            longValue.append("x");
                                                                                        }
                                                                                        headers.put("long", longValue.toString());
                                                                                
                                                                                        Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                            "writePaxHeaders", String.class, Map.class);
                                                                                        writePaxHeaders.setAccessible(true);
                                                                                        writePaxHeaders.invoke(tarOutputStream, "longvalue.txt", headers);
                                                                                
                                                                                        verify(mockOutputStream, atLeastOnce()).write(any(byte[].class), anyInt(), anyInt());
                                                                                    }

    @Test
        public void testWritePaxHeadersWithLongEntryName() throws Exception {
            OutputStream mockOutputStream = mock(OutputStream.class);
            TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(mockOutputStream);
            
            Map<String, String> headers = new HashMap<>();
            headers.put("key", "value");
        
            StringBuilder longName = new StringBuilder();
            for (int i = 0; i < TarConstants.NAMELEN + 10; i++) {
                longName.append("a");
            }
        
            Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                "writePaxHeaders", String.class, Map.class);
            writePaxHeaders.setAccessible(true);
            writePaxHeaders.invoke(tarOutputStream, longName.toString(), headers);
        
        }


}
