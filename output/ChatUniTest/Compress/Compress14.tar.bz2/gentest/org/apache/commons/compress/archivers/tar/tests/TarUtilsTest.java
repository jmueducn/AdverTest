package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
            public void testParseOctalWithValidInput() {
                byte[] buffer = "12345 \0".getBytes();
                long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                assertEquals(5349L, result);
            }

    @Test
            public void testParseOctalWithLeadingZero() {
                byte[] buffer = "012345 \0".getBytes();
                long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                assertEquals(0L, result);
            }

    @Test
            public void testParseOctalWithLeadingSpaces() {
                byte[] buffer = "   12345 \0".getBytes();
                long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                assertEquals(5349L, result);
            }

    @Test
            public void testParseOctalWithSingleTrailingSpace() {
                byte[] buffer = "12345 ".getBytes();
                long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                assertEquals(5349L, result);
            }

    @Test
            public void testParseOctalWithDoubleTrailingSpace() {
                byte[] buffer = "12345  ".getBytes();
                long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                assertEquals(5349L, result);
            }

    @Test
            public void testParseOctalWithSingleTrailingNull() {
                byte[] buffer = "12345\0".getBytes();
                long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                assertEquals(5349L, result);
            }

    @Test
            public void testParseOctalWithDoubleTrailingNull() {
                byte[] buffer = "12345\0\0".getBytes();
                long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                assertEquals(5349L, result);
            }

    @Test
            public void testParseOctalWithSpaceAndNullTrailer() {
                byte[] buffer = "12345 \0".getBytes();
                long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                assertEquals(5349L, result);
            }

    @Test
            public void testParseOctalWithMaxOctalValue() {
                byte[] buffer = "7777777777 \0".getBytes();
                long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                assertEquals(1073741823L, result);
            }

    @Test
            public void testParseOctalWithOffset() {
                byte[] buffer = "XX12345 \0".getBytes();
                long result = TarUtils.parseOctal(buffer, 2, buffer.length - 2);
                assertEquals(5349L, result);
            }

    @Test
            public void testParseOctalWithAllZeros() {
                byte[] buffer = "00000 \0".getBytes();
                long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                assertEquals(0L, result);
            }

    @Test
            public void testParseOctalWithSingleZero() {
                byte[] buffer = "0 \0".getBytes();
                long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                assertEquals(0L, result);
            }

    @Test
        public void testParseOctalThrowsForLengthLessThan() {
            byte[] buffer = "1".getBytes();
            try {
                TarUtils.parseOctal(buffer, 0, buffer.length);
                fail("Expected IllegalArgumentException");
            } catch (IllegalArgumentException e) {
                assertEquals("Length 1 must be at least 2", e.getMessage());
            }
        }

    @Test
        public void testParseOctalThrowsForInvalidTrailer() {
            byte[] buffer = "12345X".getBytes();
            try {
                TarUtils.parseOctal(buffer, 0, buffer.length);
                fail("Expected IllegalArgumentException");
            } catch (IllegalArgumentException e) {
                // expected
            }
        }

    @Test
        public void testParseOctalThrowsForInvalidDigit() {
            byte[] buffer = "123X5 \0".getBytes();
            try {
                TarUtils.parseOctal(buffer, 0, buffer.length);
                fail("Expected IllegalArgumentException");
            } catch (IllegalArgumentException e) {
                // expected
            }
        }


}
