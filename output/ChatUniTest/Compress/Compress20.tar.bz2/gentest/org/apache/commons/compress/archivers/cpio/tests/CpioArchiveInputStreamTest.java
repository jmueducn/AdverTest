package gentest.org.apache.commons.compress.archivers.cpio.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.cpio.*;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.utils.ArchiveUtils;
 
public class CpioArchiveInputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                    public void testReadOldAsciiEntry() throws Exception {
                                                                                                                                                                        // Setup test data
                                                                                                                                                                        String testData = "000123"  // device
                                                                                                                                                                                + "000456"  // inode
                                                                                                                                                                                + "100644"  // mode (regular file)
                                                                                                                                                                                + "000500"  // uid
                                                                                                                                                                                + "000600"  // gid
                                                                                                                                                                                + "000001"  // number of links
                                                                                                                                                                                + "000000"  // remote device
                                                                                                                                                                                + "01234567890"  // time
                                                                                                                                                                                + "000005"  // name size
                                                                                                                                                                                + "00000000012"  // size
                                                                                                                                                                                + "test\0";  // name + null terminator
                                                                                                                                                                
                                                                                                                                                                        InputStream inputStream = new ByteArrayInputStream(testData.getBytes());
                                                                                                                                                                        CpioArchiveInputStream cpioIn = new CpioArchiveInputStream(inputStream);
                                                                                                                                                                
                                                                                                                                                                        Method method = CpioArchiveInputStream.class.getDeclaredMethod("readOldAsciiEntry");
                                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                                        CpioArchiveEntry entry = (CpioArchiveEntry) method.invoke(cpioIn);
                                                                                                                                                                
                                                                                                                                                                        assertNotNull(entry);
                                                                                                                                                                        assertEquals(83L, entry.getDevice());  // 123 octal = 83 decimal
                                                                                                                                                                        assertEquals(302L, entry.getInode());  // 456 octal = 302 decimal
                                                                                                                                                                        assertEquals(33188L, entry.getMode());  // 100644 octal = 33188 decimal
                                                                                                                                                                        assertEquals(320L, entry.getUID());  // 500 octal = 320 decimal
                                                                                                                                                                        assertEquals(384L, entry.getGID());  // 600 octal = 384 decimal
                                                                                                                                                                        assertEquals(1L, entry.getNumberOfLinks());
                                                                                                                                                                        assertEquals(0L, entry.getRemoteDevice());
                                                                                                                                                                        assertEquals(5349888L, entry.getTime());  // 1234567890 octal = 5349888 decimal
                                                                                                                                                                        assertEquals(10L, entry.getSize());  // 12 octal = 10 decimal
                                                                                                                                                                        assertEquals("test", entry.getName());
                                                                                                                                                                    }

    @Test(expected = IOException.class)
                                                                                                                                                                    public void testReadOldAsciiEntryWithInvalidMode() throws Exception {
                                                                                                                                                                        // Setup test data with mode 0 but not trailer
                                                                                                                                                                        String testData = "000000"  // device
                                                                                                                                                                                + "000000"  // inode
                                                                                                                                                                                + "000000"  // mode
                                                                                                                                                                                + "000000"  // uid
                                                                                                                                                                                + "000000"  // gid
                                                                                                                                                                                + "000000"  // number of links
                                                                                                                                                                                + "000000"  // remote device
                                                                                                                                                                                + "00000000000"  // time
                                                                                                                                                                                + "000005"  // name size
                                                                                                                                                                                + "00000000000"  // size
                                                                                                                                                                                + "test\0";  // name + null terminator
                                                                                                                                                                
                                                                                                                                                                        InputStream inputStream = new ByteArrayInputStream(testData.getBytes());
                                                                                                                                                                        CpioArchiveInputStream cpioIn = new CpioArchiveInputStream(inputStream);
                                                                                                                                                                
                                                                                                                                                                        Method method = CpioArchiveInputStream.class.getDeclaredMethod("readOldAsciiEntry");
                                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                                        method.invoke(cpioIn);  // Should throw IOException
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testReadOldAsciiEntryWithSymbolicLink() throws Exception {
                                                                                                                                                                        // Setup test data for symbolic link
                                                                                                                                                                        String testData = "000123"  // device
                                                                                                                                                                                + "000456"  // inode
                                                                                                                                                                                + "120777"  // mode (symbolic link)
                                                                                                                                                                                + "000500"  // uid
                                                                                                                                                                                + "000600"  // gid
                                                                                                                                                                                + "000001"  // number of links
                                                                                                                                                                                + "000000"  // remote device
                                                                                                                                                                                + "01234567890"  // time
                                                                                                                                                                                + "000008"  // name size
                                                                                                                                                                                + "00000000005"  // size
                                                                                                                                                                                + "link\0\0\0\0"  // name + null terminator + padding
                                                                                                                                                                                + "target";  // link target (not read by this method)
                                                                                                                                                                    
                                                                                                                                                                        InputStream inputStream = new ByteArrayInputStream(testData.getBytes());
                                                                                                                                                                        CpioArchiveInputStream cpioIn = new CpioArchiveInputStream(inputStream);
                                                                                                                                                                    
                                                                                                                                                                        Method method = CpioArchiveInputStream.class.getDeclaredMethod("readOldAsciiEntry");
                                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                                        CpioArchiveEntry entry = (CpioArchiveEntry) method.invoke(cpioIn);
                                                                                                                                                                    
                                                                                                                                                                        assertNotNull(entry);
                                                                                                                                                                        assertEquals(41471L, entry.getMode());  // 120777 octal = 41471 decimal
                                                                                                                                                                        assertEquals("link", entry.getName());
                                                                                                                                                                        assertTrue(entry.isSymbolicLink());
                                                                                                                                                                    }

    @Test(expected = IOException.class)
                                                                                                                                                            public void testReadNewEntryWithInvalidData() throws Exception {
                                                                                                                                                                InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                CpioArchiveInputStream inputStream = new CpioArchiveInputStream(mockInputStream);
                                                                                                                                                                
                                                                                                                                                                Method readNewEntryMethod = CpioArchiveInputStream.class.getDeclaredMethod("readNewEntry", boolean.class);
                                                                                                                                                                readNewEntryMethod.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                                when(mockInputStream.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                                    .thenThrow(new IOException("Test IO Exception"));
                                                                                                                                                            
                                                                                                                                                                readNewEntryMethod.invoke(inputStream, false);
                                                                                                                                                            }

    @Test
                                                                                                                                                        public void testReadOldAsciiEntryWithTrailer() throws Exception {
                                                                                                                                                            // Setup test data for trailer entry
                                                                                                                                                            String testData = "000000"  // device
                                                                                                                                                                    + "000000"  // inode
                                                                                                                                                                    + "000000"  // mode
                                                                                                                                                                    + "000000"  // uid
                                                                                                                                                                    + "000000"  // gid
                                                                                                                                                                    + "000000"  // number of links
                                                                                                                                                                    + "000000"  // remote device
                                                                                                                                                                    + "00000000000"  // time
                                                                                                                                                                    + "000013"  // name size
                                                                                                                                                                    + "00000000000"  // size
                                                                                                                                                                    + "TRAILER!!!\0";  // name + null terminator
                                                                                                                                                            
                                                                                                                                                            InputStream inputStream = new ByteArrayInputStream(testData.getBytes());
                                                                                                                                                            CpioArchiveInputStream cpioIn = new CpioArchiveInputStream(inputStream);
                                                                                                                                                            
                                                                                                                                                            Method method = CpioArchiveInputStream.class.getDeclaredMethod("readOldAsciiEntry");
                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                            CpioArchiveEntry entry = (CpioArchiveEntry) method.invoke(cpioIn);
                                                                                                                                                            
                                                                                                                                                            assertNotNull(entry);
                                                                                                                                                            assertEquals(CpioConstants.CPIO_TRAILER, entry.getName());
                                                                                                                                                            assertEquals(0L, entry.getMode());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testReadOldAsciiEntryWithDirectory() throws Exception {
                                                                                                                                                            // Setup test data for directory entry
                                                                                                                                                            String testData = "000123"  // device
                                                                                                                                                                    + "000456"  // inode
                                                                                                                                                                    + "040755"  // mode (directory)
                                                                                                                                                                    + "000500"  // uid
                                                                                                                                                                    + "000600"  // gid
                                                                                                                                                                    + "000001"  // number of links
                                                                                                                                                                    + "000000"  // remote device
                                                                                                                                                                    + "01234567890"  // time
                                                                                                                                                                    + "000006"  // name size
                                                                                                                                                                    + "00000000000"  // size
                                                                                                                                                                    + "dir\0\0\0";  // name + null terminator + padding
                                                                                                                                                            
                                                                                                                                                            InputStream inputStream = new ByteArrayInputStream(testData.getBytes());
                                                                                                                                                            CpioArchiveInputStream cpioIn = new CpioArchiveInputStream(inputStream);
                                                                                                                                                            
                                                                                                                                                            Method method = CpioArchiveInputStream.class.getDeclaredMethod("readOldAsciiEntry");
                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                            CpioArchiveEntry entry = (CpioArchiveEntry) method.invoke(cpioIn);
                                                                                                                                                            
                                                                                                                                                            assertNotNull(entry);
                                                                                                                                                            assertEquals(16877L, entry.getMode());  // 040755 octal = 16877 decimal
                                                                                                                                                            assertEquals("dir", entry.getName());
                                                                                                                                                            assertTrue(entry.isDirectory());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testReadNewEntryWithoutCrc() throws Exception {
                                                                                                                                                            // Create mock InputStream
                                                                                                                                                            InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                            
                                                                                                                                                            // Get private method via reflection
                                                                                                                                                            Method readNewEntryMethod = CpioArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                "readNewEntry", boolean.class);
                                                                                                                                                            readNewEntryMethod.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            // Create test instance
                                                                                                                                                            CpioArchiveInputStream inputStream = new CpioArchiveInputStream(mockInputStream);
                                                                                                                                                            
                                                                                                                                                            // Setup mock data for non-CRC format
                                                                                                                                                            String mockData = "00000001" + // inode
                                                                                                                                                                             "000081A4" + // mode (regular file)
                                                                                                                                                                             "00000002" + // uid
                                                                                                                                                                             "00000003" + // gid
                                                                                                                                                                             "00000001" + // nlink
                                                                                                                                                                             "00000004" + // mtime
                                                                                                                                                                             "00000005" + // filesize
                                                                                                                                                                             "00000006" + // devmajor
                                                                                                                                                                             "00000007" + // devminor
                                                                                                                                                                             "00000008" + // rdevmajor
                                                                                                                                                                             "00000009" + // rdevminor
                                                                                                                                                                             "0000000A" + // namesize
                                                                                                                                                                             "00000000" + // chksum (0 for non-CRC)
                                                                                                                                                                             "testfile\0"; // name + null terminator
                                                                                                                                                        
                                                                                                                                                            when(mockInputStream.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                                .thenAnswer(invocation -> {
                                                                                                                                                                    Object[] args = invocation.getArguments();
                                                                                                                                                                    byte[] buf = (byte[]) args[0];
                                                                                                                                                                    int off = (int) args[1];
                                                                                                                                                                    int len = (int) args[2];
                                                                                                                                                                    byte[] data = mockData.getBytes();
                                                                                                                                                                    System.arraycopy(data, 0, buf, off, len);
                                                                                                                                                                    return len;
                                                                                                                                                                });
                                                                                                                                                        
                                                                                                                                                            CpioArchiveEntry entry = (CpioArchiveEntry) readNewEntryMethod.invoke(inputStream, false);
                                                                                                                                                        
                                                                                                                                                            assertEquals(CpioConstants.FORMAT_NEW, entry.getFormat());
                                                                                                                                                            assertEquals(0, entry.getChksum()); // Should be 0 for non-CRC format
                                                                                                                                                        }

    @Test
                                                                                                                public void testReadOldBinaryEntryNormalFile() throws Exception {
                                                                                                                    Method readOldBinaryEntryMethod = CpioArchiveInputStream.class.getDeclaredMethod(
                                                                                                                        "readOldBinaryEntry", boolean.class);
                                                                                                                    readOldBinaryEntryMethod.setAccessible(true);
                                                                                                                    
                                                                                                                    byte[] buf = new byte[29]; // Buffer size needs to accommodate all copied data
                                                                                                                    InputStream mockInputStream = mock(InputStream.class);
                                                                                                                    when(mockInputStream.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                        .thenAnswer(invocation -> {
                                                                                                                            Object[] args = invocation.getArguments();
                                                                                                                            byte[] buffer = (byte[]) args[0];
                                                                                                                            System.arraycopy(new byte[]{(byte)0x01, (byte)0x00}, 0, buffer, 0, 2); // device
                                                                                                                            System.arraycopy(new byte[]{(byte)0x02, (byte)0x00}, 0, buffer, 2, 2); // inode
                                                                                                                            System.arraycopy(new byte[]{(byte)0x81, (byte)0xA4}, 0, buffer, 4, 2); // mode (regular file)
                                                                                                                            System.arraycopy(new byte[]{(byte)0x03, (byte)0x00}, 0, buffer, 6, 2); // uid
                                                                                                                            System.arraycopy(new byte[]{(byte)0x04, (byte)0x00}, 0, buffer, 8, 2); // gid
                                                                                                                            System.arraycopy(new byte[]{(byte)0x01, (byte)0x00}, 0, buffer, 10, 2); // nlink
                                                                                                                            System.arraycopy(new byte[]{(byte)0x05, (byte)0x00}, 0, buffer, 12, 2); // rdev
                                                                                                                            System.arraycopy(new byte[]{(byte)0x00, (byte)0x00, (byte)0x00, (byte)0x10}, 0, buffer, 14, 4); // time
                                                                                                                            System.arraycopy(new byte[]{(byte)0x06, (byte)0x00}, 0, buffer, 18, 2); // namesize
                                                                                                                            System.arraycopy(new byte[]{(byte)0x00, (byte)0x00, (byte)0x00, (byte)0x20}, 0, buffer, 20, 4); // size
                                                                                                                            System.arraycopy("test\0".getBytes(), 0, buffer, 24, 5); // name
                                                                                                                            return 29; // total bytes read
                                                                                                                        });
                                                                                                                    
                                                                                                                    CpioArchiveInputStream stream = new CpioArchiveInputStream(mockInputStream);
                                                                                                                    CpioArchiveEntry entry = (CpioArchiveEntry) readOldBinaryEntryMethod.invoke(stream, false);
                                                                                                                    
                                                                                                                    assertEquals(1, entry.getDevice());
                                                                                                                    assertEquals(2, entry.getInode());
                                                                                                                    assertEquals(0100644, entry.getMode());
                                                                                                                    assertEquals(3, entry.getUID());
                                                                                                                    assertEquals(4, entry.getGID());
                                                                                                                    assertEquals(1, entry.getNumberOfLinks());
                                                                                                                    assertEquals(5, entry.getRemoteDevice());
                                                                                                                    assertEquals(16, entry.getTime());
                                                                                                                    assertEquals(32, entry.getSize());
                                                                                                                    assertEquals("test", entry.getName());
                                                                                                                }

    @Test(expected = IOException.class)
                                                                                    public void testReadNewEntryWithInvalidMode() throws Exception {
                                                                                        // Create mock input stream data
                                                                                        String mockData = "070701" + // magic
                                                                                                         "00000001" + // inode
                                                                                                         "00000002" + // mode (invalid)
                                                                                                         "00000003" + // uid
                                                                                                         "00000004" + // gid
                                                                                                         "00000005" + // nlink
                                                                                                         "00000006" + // mtime
                                                                                                         "00000007" + // filesize
                                                                                                         "00000008" + // rdevmajor
                                                                                                         "00000009" + // rdevminor
                                                                                                         "0000000A" + // namesize
                                                                                                         "00000000" + // chksum
                                                                                                         "invalid\0"; // name (not trailer)
                                                                                
                                                                                        InputStream mockInputStream = new ByteArrayInputStream(mockData.getBytes());
                                                                                        CpioArchiveInputStream inputStream = new CpioArchiveInputStream(mockInputStream);
                                                                                
                                                                                        // Get private method via reflection
                                                                                        Method readNewEntryMethod = CpioArchiveInputStream.class.getDeclaredMethod("readNewEntry", boolean.class);
                                                                                        readNewEntryMethod.setAccessible(true);
                                                                                        
                                                                                        // Invoke the method which should throw IOException
                                                                                        readNewEntryMethod.invoke(inputStream, false);
                                                                                    }

    @Test
                                                                                    public void testReadNewEntryWithSpecialFile() throws Exception {
                                                                                        // Create mock InputStream
                                                                                        InputStream mockInputStream = mock(InputStream.class);
                                                                                        
                                                                                        // Get private method via reflection
                                                                                        Method readNewEntryMethod = CpioArchiveInputStream.class.getDeclaredMethod("readNewEntry");
                                                                                        readNewEntryMethod.setAccessible(true);
                                                                                        
                                                                                        // Setup mock data for special file (directory)
                                                                                        String mockData = "00000001" + // inode
                                                                                                         "000041ED" + // mode (directory)
                                                                                                         "00000002" + // uid
                                                                                                         "00000003" + // gid
                                                                                                         "00000001" + // nlink
                                                                                                         "00000004" + // mtime
                                                                                                         "00000005" + // filesize
                                                                                                         "00000006" + // devmajor
                                                                                                         "00000007" + // devminor
                                                                                                         "00000008" + // rdevmajor
                                                                                                         "00000009" + // rdevminor
                                                                                                         "0000000A" + // namesize
                                                                                                         "00000000" + // chksum
                                                                                                         "directory\0"; // name
                                                                                        
                                                                                        // Setup mock behavior
                                                                                        when(mockInputStream.read(any(byte[].class), anyInt(), anyInt())).thenAnswer(invocation -> {
                                                                                            byte[] buffer = (byte[]) invocation.getArguments()[0];
                                                                                            int offset = (int) invocation.getArguments()[1];
                                                                                            int len = (int) invocation.getArguments()[2];
                                                                                            
                                                                                            byte[] dataBytes = mockData.getBytes();
                                                                                            System.arraycopy(dataBytes, 0, buffer, offset, Math.min(len, dataBytes.length));
                                                                                            return Math.min(len, dataBytes.length);
                                                                                        });
                                                                                        
                                                                                        // Create test instance and invoke method
                                                                                        CpioArchiveInputStream testInstance = new CpioArchiveInputStream(mockInputStream);
                                                                                        readNewEntryMethod.invoke(testInstance);
                                                                                    }

    @Test
                                                                                    public void testReadOldBinaryEntryTrailer() throws Exception {
                                                                                        byte[] buf = new byte[26];
                                                                                        System.arraycopy(new byte[]{0x01, 0x00}, 0, buf, 0, 2); // device
                                                                                        System.arraycopy(new byte[]{0x02, 0x00}, 0, buf, 2, 2); // inode
                                                                                        System.arraycopy(new byte[]{0x00, 0x00}, 0, buf, 4, 2); // mode (0 for trailer)
                                                                                        System.arraycopy(new byte[]{0x03, 0x00}, 0, buf, 6, 2); // uid
                                                                                        System.arraycopy(new byte[]{0x04, 0x00}, 0, buf, 8, 2); // gid
                                                                                        System.arraycopy(new byte[]{0x01, 0x00}, 0, buf, 10, 2); // nlink
                                                                                        System.arraycopy(new byte[]{0x05, 0x00}, 0, buf, 12, 2); // rdev
                                                                                        System.arraycopy(new byte[]{0x00, 0x00, 0x00, 0x10}, 0, buf, 14, 4); // time
                                                                                        System.arraycopy(new byte[]{0x0B, 0x00}, 0, buf, 18, 2); // namesize
                                                                                        System.arraycopy(new byte[]{0x00, 0x00, 0x00, 0x20}, 0, buf, 20, 4); // size
                                                                                
                                                                                        InputStream mockInputStream = new ByteArrayInputStream(buf);
                                                                                        CpioArchiveInputStream stream = new CpioArchiveInputStream(mockInputStream);
                                                                                    }

    @Test
                                                                                    public void testReadOldBinaryEntryWithSwapHalfWord() throws Exception {
                                                                                        byte[] testData = new byte[29];
                                                                                        System.arraycopy(new byte[]{(byte)0x00, (byte)0x01}, 0, testData, 0, 2); // device (swapped)
                                                                                        System.arraycopy(new byte[]{(byte)0x00, (byte)0x02}, 0, testData, 2, 2); // inode (swapped)
                                                                                        System.arraycopy(new byte[]{(byte)0xA4, (byte)0x81}, 0, testData, 4, 2); // mode (swapped)
                                                                                        System.arraycopy(new byte[]{(byte)0x00, (byte)0x03}, 0, testData, 6, 2); // uid (swapped)
                                                                                        System.arraycopy(new byte[]{(byte)0x00, (byte)0x04}, 0, testData, 8, 2); // gid (swapped)
                                                                                        System.arraycopy(new byte[]{(byte)0x00, (byte)0x01}, 0, testData, 10, 2); // nlink (swapped)
                                                                                        System.arraycopy(new byte[]{(byte)0x00, (byte)0x05}, 0, testData, 12, 2); // rdev (swapped)
                                                                                        System.arraycopy(new byte[]{(byte)0x10, (byte)0x00, (byte)0x00, (byte)0x00}, 0, testData, 14, 4); // time (swapped)
                                                                                        System.arraycopy(new byte[]{(byte)0x00, (byte)0x06}, 0, testData, 18, 2); // namesize (swapped)
                                                                                        System.arraycopy(new byte[]{(byte)0x20, (byte)0x00, (byte)0x00, (byte)0x00}, 0, testData, 20, 4); // size (swapped)
                                                                                        System.arraycopy("test\0".getBytes(), 0, testData, 24, 5); // name
                                                                                
                                                                                        ByteArrayInputStream in = new ByteArrayInputStream(testData);
                                                                                        CpioArchiveInputStream cais = new CpioArchiveInputStream(in);
                                                                                        CpioArchiveEntry entry = cais.getNextCPIOEntry();
                                                                                        
                                                                                        assertEquals(4, entry.getGID());
                                                                                    }

    @Test(expected = IOException.class)
                                                                                    public void testReadOldBinaryEntryInvalidModeZero() throws Exception {
                                                                                        byte[] buf = new byte[2];
                                                                                        System.arraycopy(new byte[]{0x02, 0x00}, 0, buf, 0, 2); // inode
                                                                                        
                                                                                        ByteArrayInputStream in = new ByteArrayInputStream(buf);
                                                                                        CpioArchiveInputStream cais = new CpioArchiveInputStream(in);
                                                                                        
                                                                                        Method method = CpioArchiveInputStream.class.getDeclaredMethod("readOldBinaryEntry", boolean.class);
                                                                                        method.setAccessible(true);
                                                                                        method.invoke(cais, false);
                                                                                    }

    @Test
                                                                        public void testReadOldBinaryEntrySkipsHeaderPadding() throws Exception {
                                                                            byte[] buf = new byte[26]; // CPIO_OLD_BIN_HEADER_SIZE
                                                                            System.arraycopy(new byte[]{'0', '7', '0', '7', '0', '1'}, 0, buf, 0, 6); // magic
                                                                            System.arraycopy(new byte[]{0x02, 0x00}, 0, buf, 2, 2); // inode
                                                                            System.arraycopy(new byte[]{0x00, 0x00, 0x00, 0x00}, 0, buf, 22, 4); // namesize
                                                                            
                                                                            ByteArrayInputStream in = new ByteArrayInputStream(buf);
                                                                            CpioArchiveInputStream cis = new CpioArchiveInputStream(in);
                                                                            
                                                                            try {
                                                                                Method method = CpioArchiveInputStream.class.getDeclaredMethod("readOldBinaryEntry", boolean.class);
                                                                                method.setAccessible(true);
                                                                                method.invoke(cis, false);
                                                                                // Test passes if no exception is thrown
                                                                            } finally {
                                                                                cis.close();
                                                                            }
                                                                        }

    @Test
                                                public void testReadNewEntryWithCrc() throws Exception {
                                                    // Setup mock objects
                                                    String mockData = "070701" + // magic
                                                                     "00000001" + // inode
                                                                     "00000002" + // mode
                                                                     "00000003" + // uid
                                                                     "00000004" + // gid
                                                                     "00000005" + // filesize
                                                                     "00000006" + // devmajor
                                                                     "00000007" + // devminor
                                                                     "00000008" + // rdevmajor
                                                                     "00000009" + // rdevminor
                                                                     "0000000A" + // namesize
                                                                     "0000000B" + // chksum
                                                                     "testfile\0"; // name + null terminator
                                                    
                                                    InputStream mockInputStream = new ByteArrayInputStream(mockData.getBytes());
                                                    CpioArchiveInputStream inputStream = new CpioArchiveInputStream(mockInputStream);
                                                    
                                                    // Invoke readNewEntry
                                                }

    @Test
        public void testReadNewEntryWithTrailer() throws Exception {
            // Setup reflection to access private method
            Method readNewEntryMethod = CpioArchiveInputStream.class.getDeclaredMethod("readNewEntry", boolean.class);
            readNewEntryMethod.setAccessible(true);
            
            // Create mock input stream
            InputStream mockInputStream = mock(InputStream.class);
            CpioArchiveInputStream inputStream = new CpioArchiveInputStream(mockInputStream);
            
            // Setup mock data for trailer entry (mode 0)
            final String mockData = "00000001" + // inode
                                 "00000000" + // mode (0 for trailer)
                                 "00000002" + // uid
                                 "00000003" + // gid
                                 "00000001" + // nlink
                                 "00000004" + // mtime
                                 "00000005" + // filesize
                                 "00000006" + // devmajor
                                 "00000007" + // devminor
                                 "00000008" + // rdevmajor
                                 "00000009" + // rdevminor
                                 "0000000B" + // namesize (11 for "TRAILER!!!\0")
                                 "00000000" + // chksum
                                 "TRAILER!!!\0"; // trailer name
            
{
                @Override
{
                    int len = (Integer) invocation.getArguments()[2];
                    byte[] data = mockData.getBytes();
                    System.arraycopy(data, 0, buf, off, Math.min(len, data.length));
                    return Math.min(len, data.length);
                }
}
            
            CpioArchiveEntry entry = (CpioArchiveEntry) readNewEntryMethod.invoke(inputStream, false);
        }


}
