package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.File;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
 
public class ZipArchiveEntryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                public void testEqualsSameObject() {
                    ZipArchiveEntry entry = new ZipArchiveEntry("test");
                    assertTrue(entry.equals(entry));
                }

    @Test
                public void testEqualsNull() {
                    ZipArchiveEntry entry = new ZipArchiveEntry("test");
                    assertFalse(entry.equals(null));
                }

    @Test
                public void testEqualsDifferentClass() {
                    ZipArchiveEntry entry = new ZipArchiveEntry("test");
                    assertFalse(entry.equals(new Object()));
                }

    @Test
                public void testEqualsDifferentNames() {
                    ZipArchiveEntry entry1 = new ZipArchiveEntry("test1");
                    ZipArchiveEntry entry2 = new ZipArchiveEntry("test2");
                    assertFalse(entry1.equals(entry2));
                }

    @Test
                public void testEqualsSameNames() {
                    ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                    ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                    assertTrue(entry1.equals(entry2));
                }

    @Test
                public void testEqualsSameNamesDifferentCase() {
                    ZipArchiveEntry entry1 = new ZipArchiveEntry("TEST");
                    ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                    assertFalse(entry1.equals(entry2));
                }

    @Test
            public void testEqualsBothNamesNull() throws Exception {
                ZipArchiveEntry entry1 = new ZipArchiveEntry("");
                Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                setNameMethod.setAccessible(true);
                setNameMethod.invoke(entry1, (String)null);
                
                ZipArchiveEntry entry2 = new ZipArchiveEntry("");
                setNameMethod.invoke(entry2, (String)null);
                
                assertTrue(entry1.equals(entry2));
            }

    @Test
            public void testEqualsFirstNotNullSecondNull() {
                ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                ZipArchiveEntry entry2 = new ZipArchiveEntry("");
                try {
                    java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                    nameField.setAccessible(true);
                    nameField.set(entry2, null);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
                assertFalse(entry1.equals(entry2));
            }

    @Test
        public void testEqualsFirstNullSecondNotNull() {
            ZipArchiveEntry entry1 = new ZipArchiveEntry("") {
                @Override
                protected void setName(String name) {
                    try {
                        java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                        nameField.setAccessible(true);
                        nameField.set(this, name);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            };
            
            try {
                java.lang.reflect.Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                setNameMethod.setAccessible(true);
                setNameMethod.invoke(entry1, (String)null);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            
            ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
            assertFalse(entry1.equals(entry2));
        }


}
