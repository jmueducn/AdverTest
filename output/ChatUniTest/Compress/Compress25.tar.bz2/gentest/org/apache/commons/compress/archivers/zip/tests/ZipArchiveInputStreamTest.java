package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;
import java.nio.ByteBuffer;
import java.util.zip.CRC32;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.utils.IOUtils;
 
public class ZipArchiveInputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                    public void testGetNextZipEntryWhenClosed() throws IOException {
                                                                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                        zais.close();
                                                                                        assertNull(zais.getNextZipEntry());
                                                                                    }

    @Test
                                                                                    public void testGetNextZipEntryWhenHitCentralDirectory() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                        Field hitCentralDirectoryField = ZipArchiveInputStream.class.getDeclaredField("hitCentralDirectory");
                                                                                        hitCentralDirectoryField.setAccessible(true);
                                                                                        hitCentralDirectoryField.set(zais, true);
                                                                                        assertNull(zais.getNextZipEntry());
                                                                                    }

    @Test
                                                                                    public void testGetNextZipEntryWithEOF() throws IOException {
                                                                                        InputStream mockInputStream = mock(InputStream.class);
                                                                                        when(mockInputStream.read(any(byte[].class))).thenReturn(-1);
                                                                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                        assertNull(zais.getNextZipEntry());
                                                                                    }

    @Test
                                                                                    public void testGetNextZipEntryWithCentralDirectorySignature() throws IOException {
                                                                                        byte[] cfhSig = new byte[] {0x50, 0x4b, 0x01, 0x02}; // CFH signature
                                                                                        byte[] testData = new byte[4];
                                                                                        System.arraycopy(cfhSig, 0, testData, 0, 4);
                                                                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(testData));
                                                                                        assertNull(zais.getNextZipEntry());
                                                                                        
                                                                                        // Using reflection to access private field
                                                                                    }

    @Test
                                                                                    public void testGetNextZipEntryWithAedSignature() throws IOException {
                                                                                        byte[] aedSig = new byte[] {0x50, 0x4b, 0x06, 0x07}; // AED_SIG
                                                                                        byte[] testData = new byte[4];
                                                                                        System.arraycopy(aedSig, 0, testData, 0, 4);
                                                                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(testData));
                                                                                        assertNull(zais.getNextZipEntry());
                                                                                        
                                                                                        // Using reflection to access private field
                                                                                        try {
                                                                                            java.lang.reflect.Field field = ZipArchiveInputStream.class.getDeclaredField("hitCentralDirectory");
                                                                                            field.setAccessible(true);
                                                                                            boolean hitCentralDirectory = field.getBoolean(zais);
                                                                                            assertTrue(hitCentralDirectory);
                                                                                        } catch (Exception e) {
                                                                                            fail("Failed to access private field: " + e.getMessage());
                                                                                        }
                                                                                    }

    @Test
                                                                                    public void testGetNextZipEntryWithInvalidSignature() throws IOException {
                                                                                        byte[] testData = new byte[100]; // Create test data array
                                                                                        byte[] invalidSig = {1, 2, 3, 4};
                                                                                        System.arraycopy(invalidSig, 0, testData, 0, 4);
                                                                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(testData));
                                                                                        assertNull(zais.getNextZipEntry());
                                                                                    }

    @Test(expected = IOException.class)
                                                                                    public void testGetNextZipEntryWithIncompleteData() throws IOException {
                                                                                        // Provide incomplete data (less than LFH_LEN)
                                                                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[10]));
                                                                                        zais.getNextZipEntry();
                                                                                    }

    @Test
                                                                            public void testGetNextZipEntryWithUnshrinkingMethod() throws Exception {
                                                                                byte[] testData = new byte[30];
                                                                                // Set LFH signature
                                                                                System.arraycopy(new ZipLong(0x04034b50L).getBytes(), 0, testData, 0, 4);
                                                                                // Set version made by
                                                                                new ZipShort((short)0).getBytes();
                                                                                System.arraycopy(new ZipShort((short)0).getBytes(), 0, testData, 4, 2);
                                                                                // Set general purpose bit flag
                                                                                System.arraycopy(new ZipShort((short)0).getBytes(), 0, testData, 6, 2);
                                                                                // Set compression method to UNSHRINKING
                                                                                System.arraycopy(new ZipShort(ZipMethod.UNSHRINKING.getCode()).getBytes(), 0, testData, 8, 2);
                                                                                // Set last mod time
                                                                                System.arraycopy(new ZipLong(0L).getBytes(), 0, testData, 10, 4);
                                                                                // Set CRC
                                                                                System.arraycopy(new ZipLong(0L).getBytes(), 0, testData, 14, 4);
                                                                                // Set compressed size
                                                                                System.arraycopy(new ZipLong(100L).getBytes(), 0, testData, 18, 4);
                                                                                // Set uncompressed size
                                                                                System.arraycopy(new ZipLong(200L).getBytes(), 0, testData, 22, 4);
                                                                                // Set filename length
                                                                                System.arraycopy(new ZipShort((short)5).getBytes(), 0, testData, 26, 2);
                                                                                // Set extra field length
                                                                                System.arraycopy(new ZipShort((short)0).getBytes(), 0, testData, 28, 2);
                                                                        
                                                                                byte[] fullData = new byte[testData.length + 5];
                                                                                System.arraycopy(testData, 0, fullData, 0, testData.length);
                                                                                System.arraycopy("test4".getBytes(), 0, fullData, testData.length, 5);
                                                                        
                                                                                ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(fullData));
                                                                                ZipArchiveEntry entry = zais.getNextZipEntry();
                                                                                assertNotNull(entry);
                                                                        
                                                                                Field currentField = zais.getClass().getDeclaredField("current");
                                                                                currentField.setAccessible(true);
                                                                                Object current = currentField.get(zais);
                                                                                Field inField = current.getClass().getDeclaredField("in");
                                                                                inField.setAccessible(true);
                                                                                InputStream in = (InputStream) inField.get(current);
                                                                                assertNotNull(in);
                                                                            }

    @Test
                                                                        public void testGetNextZipEntryWithUnicodeExtraFields() throws IOException {
                                                                            // Create test data with local file header signature
                                                                            byte[] testData = new byte[30];
                                                                            System.arraycopy(new byte[] { 0x50, 0x4b, 0x03, 0x04 }, 0, testData, 0, 4); // LFH signature
                                                                            
                                                                            // Define ZipShort constants locally
                                                                            final int GENERAL_PURPOSE_BIT_FLAG_OFFSET = 6;
                                                                            final int FILENAME_LENGTH_OFFSET = 26;
                                                                            final int EXTRA_FIELD_LENGTH_OFFSET = 28;
                                                                            
                                                                            // Use ZipShort to write values
                                                                            System.arraycopy(new byte[] { 0x00, 0x00 }, 0, testData, GENERAL_PURPOSE_BIT_FLAG_OFFSET, 2); // general purpose bit flag
                                                                            System.arraycopy(new byte[] { 0x05, 0x00 }, 0, testData, FILENAME_LENGTH_OFFSET, 2); // filename length
                                                                            System.arraycopy(new byte[] { 0x0A, 0x00 }, 0, testData, EXTRA_FIELD_LENGTH_OFFSET, 2); // extra field length
                                                                            
                                                                            // Append filename "test3" and extra field
                                                                            byte[] fullData = new byte[testData.length + 5 + 10];
                                                                            System.arraycopy(testData, 0, fullData, 0, testData.length);
                                                                            System.arraycopy("test3".getBytes(), 0, fullData, testData.length, 5);
                                                                            // Add some extra field data
                                                                            System.arraycopy(new byte[10], 0, fullData, testData.length + 5, 10);
                                                                        
                                                                            ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(fullData), "UTF-8", true);
                                                                            ZipArchiveEntry entry = zais.getNextZipEntry();
                                                                            assertNotNull(entry);
                                                                            assertEquals("test3", entry.getName());
                                                                        }

    @Test
                                                public void testGetNextZipEntryWithDataDescriptor() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                    // Create test data with local file header signature
                                                    byte[] testData = new byte[30];
                                                    System.arraycopy(new byte[] {0x50, 0x4b, 0x03, 0x04}, 0, testData, 0, 4); // LFH signature
                                                    
                                                    // Set general purpose bit flag to indicate data descriptor
                                                    // Skip crc, compressed size and size fields
                                                
                                                    // Append filename "test2"
                                                    byte[] fullData = new byte[testData.length + 5];
                                                    System.arraycopy(testData, 0, fullData, 0, testData.length);
                                                    System.arraycopy("test2".getBytes(), 0, fullData, testData.length, 5);
                                                
                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(fullData));
                                                    ZipArchiveEntry entry = zais.getNextZipEntry();
                                                    assertNotNull(entry);
                                                
                                                    // Use reflection to check private field
                                                    Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                    currentField.setAccessible(true);
                                                    Object current = currentField.get(zais);
                                                    Field hasDataDescriptorField = current.getClass().getDeclaredField("hasDataDescriptor");
                                                    hasDataDescriptorField.setAccessible(true);
                                                    boolean hasDataDescriptor = hasDataDescriptorField.getBoolean(current);
                                                    assertTrue(hasDataDescriptor);
                                                }

    @Test
                                            public void testGetNextZipEntrySuccess() throws IOException {
                                                // Define test data buffer
                                                byte[] testData = new byte[30]; // Local file header is 30 bytes
                                                
                                                // Define dosTime value
                                                long dosTime = 1234567890L;
                                                
                                                // Set up valid LFH data
                                                int LFH_SIG = 0x04034b50; // Local file header signature
                                                System.arraycopy(new byte[] {
                                                    (byte)(LFH_SIG & 0xff),
                                                    (byte)((LFH_SIG >> 8) & 0xff),
                                                    (byte)((LFH_SIG >> 16) & 0xff),
                                                    (byte)((LFH_SIG >> 24) & 0xff)
                                                }, 0, testData, 0, 4);
                                                
                                                // version needed to extract
                                                System.arraycopy(new byte[] {20, 0}, 0, testData, 4, 2);
                                                
                                                // general purpose bit flag
                                                System.arraycopy(new byte[] {0, 0}, 0, testData, 6, 2);
                                                
                                                // method (STORED)
                                                System.arraycopy(new byte[] {0, 0}, 0, testData, 8, 2);
                                                
                                                // time
                                                System.arraycopy(new byte[] {
                                                    (byte)(dosTime & 0xff),
                                                    (byte)((dosTime >> 8) & 0xff),
                                                    (byte)((dosTime >> 16) & 0xff),
                                                    (byte)((dosTime >> 24) & 0xff)
                                                }, 0, testData, 10, 4);
                                                
                                                // crc
                                                System.arraycopy(new byte[] {
                                                    (byte)(1234L & 0xff),
                                                    (byte)((1234L >> 8) & 0xff),
                                                    (byte)((1234L >> 16) & 0xff),
                                                    (byte)((1234L >> 24) & 0xff)
                                                }, 0, testData, 14, 4);
                                                
                                                // compressed size
                                                System.arraycopy(new byte[] {
                                                    (byte)(100L & 0xff),
                                                    (byte)((100L >> 8) & 0xff),
                                                    (byte)((100L >> 16) & 0xff),
                                                    (byte)((100L >> 24) & 0xff)
                                                }, 0, testData, 18, 4);
                                                
                                                // size
                                                System.arraycopy(new byte[] {
                                                    (byte)(100L & 0xff),
                                                    (byte)((100L >> 8) & 0xff),
                                                    (byte)((100L >> 16) & 0xff),
                                                    (byte)((100L >> 24) & 0xff)
                                                }, 0, testData, 22, 4);
                                                
                                                // filename length
                                                System.arraycopy(new byte[] {5, 0}, 0, testData, 26, 2);
                                                
                                                // extra field length
                                                System.arraycopy(new byte[] {0, 0}, 0, testData, 28, 2);
                                            
                                                // Append filename "test1"
                                                byte[] fullData = new byte[testData.length + 5];
                                                System.arraycopy(testData, 0, fullData, 0, testData.length);
                                                System.arraycopy("test1".getBytes(), 0, fullData, testData.length, 5);
                                            
                                                ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(fullData));
                                                ZipArchiveEntry entry = zais.getNextZipEntry();
                                                assertNotNull(entry);
                                                assertEquals("test1", entry.getName());
                                                assertEquals(100L, entry.getSize());
                                                assertEquals(100L, entry.getCompressedSize());
                                                assertEquals(1234L, entry.getCrc());
                                                assertEquals(ZipEntry.STORED, entry.getMethod());
                                            }


}
