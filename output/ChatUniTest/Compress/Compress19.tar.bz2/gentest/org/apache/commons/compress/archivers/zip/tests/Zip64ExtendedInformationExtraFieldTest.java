package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.util.zip.ZipException;
 
public class Zip64ExtendedInformationExtraFieldTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                            public void testReparseCentralDirectoryDataWithNullData() throws Exception {
                                                Zip64ExtendedInformationExtraField field = new Zip64ExtendedInformationExtraField();
                                                
                                                // Use reflection to set rawCentralDirectoryData to null
                                                java.lang.reflect.Field rawDataField = Zip64ExtendedInformationExtraField.class
                                                    .getDeclaredField("rawCentralDirectoryData");
                                                rawDataField.setAccessible(true);
                                                rawDataField.set(field, null);
                                        
                                                field.reparseCentralDirectoryData(true, true, true, true);
                                                assertNull(field.getSize());
                                                assertNull(field.getCompressedSize());
                                                assertNull(field.getRelativeHeaderOffset());
                                                assertNull(field.getDiskStartNumber());
                                            }

    @Test
                                            public void testReparseCentralDirectoryDataWithAllFields() throws Exception {
                                                final int DWORD = 8;
                                                final int WORD = 4;
                                                
                                                Zip64ExtendedInformationExtraField field = new Zip64ExtendedInformationExtraField();
                                                Field rawCentralDirectoryDataField = Zip64ExtendedInformationExtraField.class
                                                    .getDeclaredField("rawCentralDirectoryData");
                                                rawCentralDirectoryDataField.setAccessible(true);
                                                
                                                byte[] data = new byte[3 * DWORD + WORD];
                                                rawCentralDirectoryDataField.set(field, data);
                                                
                                                field.reparseCentralDirectoryData(true, true, true, true);
                                                
                                                assertNotNull(field.getSize());
                                                assertNotNull(field.getCompressedSize());
                                                assertNotNull(field.getRelativeHeaderOffset());
                                                assertNotNull(field.getDiskStartNumber());
                                            }

    @Test
                                            public void testReparseCentralDirectoryDataWithOnlyUncompressedSize() throws Exception {
                                                final int DWORD = 8;
                                                final int WORD = 4;
                                                
                                                Zip64ExtendedInformationExtraField field = new Zip64ExtendedInformationExtraField();
                                                
                                                Field rawCentralDirectoryDataField = Zip64ExtendedInformationExtraField.class
                                                    .getDeclaredField("rawCentralDirectoryData");
                                                rawCentralDirectoryDataField.setAccessible(true);
                                                
                                                byte[] data = new byte[DWORD];
                                                rawCentralDirectoryDataField.set(field, data);
                                                
                                                field.reparseCentralDirectoryData(true, false, false, false);
                                                
                                                assertNotNull(field.getSize());
                                                assertNull(field.getCompressedSize());
                                                assertNull(field.getRelativeHeaderOffset());
                                                assertNull(field.getDiskStartNumber());
                                            }

    @Test
                                            public void testReparseCentralDirectoryDataWithOnlyCompressedSize() throws Exception {
                                                final int DWORD = 8;
                                                final int WORD = 4;
                                                
                                                Zip64ExtendedInformationExtraField field = new Zip64ExtendedInformationExtraField();
                                                Field rawCentralDirectoryDataField = Zip64ExtendedInformationExtraField.class
                                                    .getDeclaredField("rawCentralDirectoryData");
                                                rawCentralDirectoryDataField.setAccessible(true);
                                                
                                                byte[] data = new byte[DWORD];
                                                rawCentralDirectoryDataField.set(field, data);
                                                
                                                field.reparseCentralDirectoryData(false, true, false, false);
                                                
                                                assertNull(field.getSize());
                                                assertNotNull(field.getCompressedSize());
                                                assertNull(field.getRelativeHeaderOffset());
                                                assertNull(field.getDiskStartNumber());
                                            }

    @Test
                                            public void testReparseCentralDirectoryDataWithOnlyRelativeHeaderOffset() throws Exception {
                                                final int DWORD = 8;
                                                final int WORD = 4;
                                                
                                                Zip64ExtendedInformationExtraField field = new Zip64ExtendedInformationExtraField();
                                                Field rawCentralDirectoryDataField = Zip64ExtendedInformationExtraField.class
                                                    .getDeclaredField("rawCentralDirectoryData");
                                                rawCentralDirectoryDataField.setAccessible(true);
                                                
                                                byte[] data = new byte[DWORD];
                                                rawCentralDirectoryDataField.set(field, data);
                                                
                                                field.reparseCentralDirectoryData(false, false, true, false);
                                                
                                                assertNull(field.getSize());
                                                assertNull(field.getCompressedSize());
                                                assertNotNull(field.getRelativeHeaderOffset());
                                                assertNull(field.getDiskStartNumber());
                                            }

    @Test
                                            public void testReparseCentralDirectoryDataWithOnlyDiskStart() throws Exception {
                                                final int WORD = 4;
                                                final int DWORD = 8;
                                                
                                                Zip64ExtendedInformationExtraField field = new Zip64ExtendedInformationExtraField();
                                                Field rawCentralDirectoryDataField = Zip64ExtendedInformationExtraField.class
                                                    .getDeclaredField("rawCentralDirectoryData");
                                                rawCentralDirectoryDataField.setAccessible(true);
                                                
                                                byte[] data = new byte[WORD];
                                                rawCentralDirectoryDataField.set(field, data);
                                                
                                                field.reparseCentralDirectoryData(false, false, false, true);
                                                
                                                assertNull(field.getSize());
                                                assertNull(field.getCompressedSize());
                                                assertNull(field.getRelativeHeaderOffset());
                                                assertNotNull(field.getDiskStartNumber());
                                            }

    @Test
                                            public void testReparseCentralDirectoryDataWithInsufficientData() throws Exception {
                                                final int DWORD = 8;
                                                final int WORD = 4;
                                                
                                                Zip64ExtendedInformationExtraField field = new Zip64ExtendedInformationExtraField();
                                                Field rawCentralDirectoryDataField = Zip64ExtendedInformationExtraField.class
                                                    .getDeclaredField("rawCentralDirectoryData");
                                                rawCentralDirectoryDataField.setAccessible(true);
                                                
                                                byte[] data = new byte[DWORD - 1];
                                                rawCentralDirectoryDataField.set(field, data);
                                                
                                                try {
                                                    field.reparseCentralDirectoryData(true, false, false, false);
                                                    fail("Expected ZipException");
                                                } catch (ZipException e) {
                                                    assertEquals("central directory zip64 extended information extra field's length doesn't match central directory data.  Expected length 8 but is 7", 
                                                                 e.getMessage());
                                                }
                                            }

    @Test
                                            public void testReparseCentralDirectoryDataWithMultipleCombinations() throws Exception {
                                                final int DWORD = 8;
                                                final int WORD = 4;
                                                
                                                Zip64ExtendedInformationExtraField field = new Zip64ExtendedInformationExtraField();
                                                Field rawCentralDirectoryDataField = Zip64ExtendedInformationExtraField.class
                                                    .getDeclaredField("rawCentralDirectoryData");
                                                rawCentralDirectoryDataField.setAccessible(true);
                                        
                                                // Test combination of uncompressed size and disk start
                                                byte[] data1 = new byte[DWORD + WORD];
                                                rawCentralDirectoryDataField.set(field, data1);
                                                field.reparseCentralDirectoryData(true, false, false, true);
                                                assertNotNull(field.getSize());
                                                assertNull(field.getCompressedSize());
                                                assertNull(field.getRelativeHeaderOffset());
                                                assertNotNull(field.getDiskStartNumber());
                                        
                                                // Test combination of compressed size and relative header offset
                                                byte[] data2 = new byte[2 * DWORD];
                                                rawCentralDirectoryDataField.set(field, data2);
                                                field.reparseCentralDirectoryData(false, true, true, false);
                                                assertNull(field.getSize());
                                                assertNotNull(field.getCompressedSize());
                                                assertNotNull(field.getRelativeHeaderOffset());
                                                assertNull(field.getDiskStartNumber());
                                            }

    @Test
                                            public void testReparseCentralDirectoryDataWithExactLength() throws Exception {
                                                final int DWORD = 8;
                                                final int WORD = 4;
                                                
                                                Zip64ExtendedInformationExtraField field = new Zip64ExtendedInformationExtraField();
                                                Field rawCentralDirectoryDataField = Zip64ExtendedInformationExtraField.class
                                                    .getDeclaredField("rawCentralDirectoryData");
                                                rawCentralDirectoryDataField.setAccessible(true);
                                                
                                                byte[] data = new byte[2 * DWORD + WORD];
                                                rawCentralDirectoryDataField.set(field, data);
                                                
                                                field.reparseCentralDirectoryData(true, true, false, true);
                                                
                                                assertNotNull(field.getSize());
                                                assertNotNull(field.getCompressedSize());
                                                assertNull(field.getRelativeHeaderOffset());
                                                assertNotNull(field.getDiskStartNumber());
                                            }


}
