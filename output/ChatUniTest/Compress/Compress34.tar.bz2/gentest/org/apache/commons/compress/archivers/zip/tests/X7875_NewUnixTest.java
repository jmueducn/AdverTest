package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.Serializable;
import java.math.BigInteger;
import java.util.zip.ZipException;
 
public class X7875_NewUnixTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                            public void testGetCentralDirectoryLength() {
                                                X7875_NewUnix newUnix = new X7875_NewUnix();
                                                ZipShort result = newUnix.getCentralDirectoryLength();
                                                assertEquals(new ZipShort(0), result);
                                            }

    @Test
                                            public void testGetCentralDirectoryLengthAfterModification() {
                                                X7875_NewUnix newUnix = new X7875_NewUnix();
                                                newUnix.setUID(1000L);
                                                newUnix.setGID(1000L);
                                                ZipShort result = newUnix.getCentralDirectoryLength();
                                                assertEquals(new ZipShort(0), result);
                                            }

    @Test
                                            public void testGetCentralDirectoryLengthWithDifferentUIDGID() {
                                                X7875_NewUnix newUnix = new X7875_NewUnix();
                                                newUnix.setUID(12345L);
                                                newUnix.setGID(67890L);
                                                ZipShort result = newUnix.getCentralDirectoryLength();
                                                assertEquals(new ZipShort(0), result);
                                            }

    @Test
                                            public void testGetCentralDirectoryLengthAfterClone() throws CloneNotSupportedException {
                                                X7875_NewUnix original = new X7875_NewUnix();
                                                original.setUID(1000L);
                                                original.setGID(1000L);
                                                X7875_NewUnix cloned = (X7875_NewUnix) original.clone();
                                                ZipShort result = cloned.getCentralDirectoryLength();
                                                assertEquals(new ZipShort(0), result);
                                            }


}
