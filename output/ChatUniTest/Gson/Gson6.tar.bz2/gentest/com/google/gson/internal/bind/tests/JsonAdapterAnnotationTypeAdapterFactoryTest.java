package gentest.com.google.gson.internal.bind.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.internal.bind.*;
import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.internal.ConstructorConstructor;
import com.google.gson.reflect.TypeToken;
 
public class JsonAdapterAnnotationTypeAdapterFactoryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                    public void testGetTypeAdapter_TypeAdapter() throws Exception {
                                                                        // Setup mocks
                                                                        ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                        Gson gson = mock(Gson.class);
                                                                        TypeToken<?> fieldType = mock(TypeToken.class);
                                                                        JsonAdapter annotation = mock(JsonAdapter.class);
                                                                        
                                                                        // Create mock TypeAdapter
                                                                        @SuppressWarnings("rawtypes")
                                                                        TypeAdapter typeAdapter = mock(TypeAdapter.class);
                                                                        
                                                                        // Test logic
                                                                        Class<?> typeAdapterClass = TypeAdapter.class;
                                                                        when(annotation.value()).thenReturn((Class)typeAdapterClass);
                                                                        when(constructorConstructor.get(any(TypeToken.class))).thenReturn(typeAdapter);
                                                                        when(typeAdapter.nullSafe()).thenReturn(typeAdapter);
                                                                        
                                                                        // Invoke the method under test
                                                                        Method getTypeAdapterMethod = JsonAdapterAnnotationTypeAdapterFactory.class.getDeclaredMethod(
                                                                            "getTypeAdapter", ConstructorConstructor.class, Gson.class, TypeToken.class, JsonAdapter.class);
                                                                        getTypeAdapterMethod.setAccessible(true);
                                                                        JsonAdapterAnnotationTypeAdapterFactory factory = new JsonAdapterAnnotationTypeAdapterFactory(constructorConstructor);
                                                                        TypeAdapter<?> result = (TypeAdapter<?>) getTypeAdapterMethod.invoke(
                                                                            factory, constructorConstructor, gson, fieldType, annotation);
                                                                    
                                                                        assertNotNull(result);
                                                                        verify(constructorConstructor).get(TypeToken.get(typeAdapterClass));
                                                                        verify(typeAdapter).nullSafe();
                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                    public void testGetTypeAdapter_InvalidClass() throws Exception {
                                                                        // Setup mocks
                                                                        ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                        Gson gson = mock(Gson.class);
                                                                        TypeToken<?> fieldType = mock(TypeToken.class);
                                                                        JsonAdapter annotation = mock(JsonAdapter.class);
                                                                        
                                                                        // Define test data
                                                                        Class<?> invalidClass = String.class;
                                                                        when(annotation.value()).thenReturn((Class) invalidClass);
                                                                        
                                                                        // Invoke private method using reflection
                                                                        JsonAdapterAnnotationTypeAdapterFactory factory = new JsonAdapterAnnotationTypeAdapterFactory(constructorConstructor);
                                                                        Method method = JsonAdapterAnnotationTypeAdapterFactory.class.getDeclaredMethod(
                                                                            "getTypeAdapter", ConstructorConstructor.class, Gson.class, TypeToken.class, JsonAdapter.class);
                                                                        method.setAccessible(true);
                                                                        method.invoke(factory, constructorConstructor, gson, fieldType, annotation);
                                                                    }

    @Test
                                            public void testGetTypeAdapter_NullSafeNotCalledWhenAdapterIsNull() throws Exception {
                                                // Setup mocks
                                                JsonAdapter annotation = mock(JsonAdapter.class);
                                                ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                Gson gson = mock(Gson.class);
                                                TypeToken fieldType = mock(TypeToken.class);
                                                
                                                @SuppressWarnings("unchecked")
                                                TypeAdapterFactory typeAdapterFactory = mock(TypeAdapterFactory.class);
                                                
                                                Object typeAdapterFactoryConstructor = mock(Object.class);
                                                
                                                when(annotation.value()).thenReturn((Class)TypeAdapterFactory.class);
                                                when(constructorConstructor.get(any(TypeToken.class))).thenReturn(typeAdapterFactoryConstructor);
                                                when(typeAdapterFactoryConstructor.getClass().getMethod("construct").invoke(typeAdapterFactoryConstructor)).thenReturn(typeAdapterFactory);
                                                when(typeAdapterFactory.create(gson, fieldType)).thenReturn(null);
                                            
                                                // Create instance of class under test
                                                Object factory = Class.forName("com.google.gson.internal.bind.JsonAdapterAnnotationTypeAdapterFactory")
                                                    .getConstructor(ConstructorConstructor.class)
                                                    .newInstance(constructorConstructor);
                                                
                                                // Get method via reflection
                                                Method getTypeAdapterMethod = factory.getClass().getDeclaredMethod(
                                                    "getTypeAdapter", Gson.class, TypeToken.class, JsonAdapter.class);
                                                getTypeAdapterMethod.setAccessible(true);
                                                
                                                // Invoke method under test
                                                TypeAdapter<?> result = (TypeAdapter<?>) getTypeAdapterMethod.invoke(
                                                    factory, gson, fieldType, annotation);
                                            
                                                assertNull(result);
                                            }

    @Test
        public void testGetTypeAdapter_TypeAdapterFactory() throws Exception {
            // Setup mocks
            ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
            Gson gson = mock(Gson.class);
            Type fieldType = mock(Type.class);
            JsonAdapter annotation = mock(JsonAdapter.class);
            
            @SuppressWarnings("unchecked")
            
            TypeAdapterFactory typeAdapterFactory = mock(TypeAdapterFactory.class);
            @SuppressWarnings("rawtypes")
            TypeAdapter typeAdapter = mock(TypeAdapter.class);
            
            // Test logic
            Class<?> typeAdapterFactoryClass = TypeAdapterFactory.class;
            
            @SuppressWarnings("unchecked")
            TypeAdapter<String> mockAdapter = mock(TypeAdapter.class);
            when(typeAdapterFactory.create(eq(gson), any(TypeToken.class))).thenReturn(mockAdapter);
            when(mockAdapter.nullSafe()).thenReturn(mockAdapter);
        
            // Invoke method under test using reflection
            Class<?> factoryClass = Class.forName("com.google.gson.internal.bind.JsonAdapterAnnotationTypeAdapterFactory");
            Object factory = factoryClass.getConstructor(ConstructorConstructor.class).newInstance(constructorConstructor);
            Method getTypeAdapterMethod = factoryClass.getDeclaredMethod("getTypeAdapter", Gson.class, Type.class, JsonAdapter.class);
            getTypeAdapterMethod.setAccessible(true);
            TypeAdapter<?> result = (TypeAdapter<?>) getTypeAdapterMethod.invoke(factory, gson, fieldType, annotation);
        
            // Verify
            assertNotNull(result);
            verify(constructorConstructor).get(TypeToken.get(typeAdapterFactoryClass));
            verify(typeAdapterFactory).create(eq(gson), any(TypeToken.class));
            verify(mockAdapter).nullSafe();
        }

    @Test
        public void testGetTypeAdapter_NullSafeWhenAdapterNotNull() throws Exception {
            // Setup mocks
            ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
            Gson gson = mock(Gson.class);
            TypeToken<?> fieldType = mock(TypeToken.class);
            JsonAdapter annotation = mock(JsonAdapter.class);
            
            @SuppressWarnings("unchecked")
            TypeAdapter<Object> typeAdapter = mock(TypeAdapter.class);
            
            // Fix: Use raw type for ObjectConstructor
            Object typeAdapterConstructor = mock(Object.class);
            
            @SuppressWarnings("unchecked")
            Class<TypeAdapter<Object>> typeAdapterClass = (Class<TypeAdapter<Object>>) (Class<?>) TypeAdapter.class;
            
            when(constructorConstructor.get(any(TypeToken.class))).thenReturn(typeAdapterConstructor);
            when(typeAdapter.nullSafe()).thenReturn(typeAdapter);
        
            // Invoke private method using reflection
            Class<?> factoryClass = Class.forName("com.google.gson.internal.bind.JsonAdapterAnnotationTypeAdapterFactory");
            Constructor<?> constructor = factoryClass.getDeclaredConstructor(ConstructorConstructor.class);
            constructor.setAccessible(true);
            Object factory = constructor.newInstance(constructorConstructor);
            
            Method method = factoryClass.getDeclaredMethod("getTypeAdapter", Gson.class, TypeToken.class, JsonAdapter.class);
            method.setAccessible(true);
            
            @SuppressWarnings("unchecked")
            TypeAdapter<Object> result = (TypeAdapter<Object>) method.invoke(factory, gson, fieldType, annotation);
        
            verify(typeAdapter).nullSafe();
            assertNotNull(result);
        }


}
