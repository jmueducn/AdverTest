package gentest.com.google.gson.internal.bind.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.internal.bind.*;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
 
public class JsonTreeWriterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test(expected = IllegalStateException.class)
                                public void testValueBooleanWithInvalidStackState() throws Exception {
                                    JsonTreeWriter writer = new JsonTreeWriter();
                                    writer.beginObject();
                                    writer.value(true);
                                }

    @Test(expected = IllegalStateException.class)
                                public void testValueBooleanAfterClose() throws IOException {
                                    JsonTreeWriter writer = new JsonTreeWriter();
                                    writer.close();
                                    writer.value(false);
                                }

    @Test(expected = IllegalStateException.class)
                                public void testValueWithBooleanInInvalidState() throws Exception {
                                    JsonTreeWriter jsonTreeWriter = new JsonTreeWriter();
                                    jsonTreeWriter.beginObject();
                                    // Don't set name before setting value
                                    jsonTreeWriter.value(true);
                                }

    @Test(expected = IllegalArgumentException.class)
                                public void testValueDoubleWithNaNWhenNotLenient() throws IOException {
                                    JsonTreeWriter writer = new JsonTreeWriter();
                                    writer.setLenient(false);
                                    writer.value(Double.NaN);
                                }

    @Test(expected = IllegalArgumentException.class)
                                public void testValueDoubleWithPositiveInfinityWhenNotLenient() throws IOException {
                                    JsonTreeWriter writer = new JsonTreeWriter();
                                    writer.setLenient(false);
                                    writer.value(Double.POSITIVE_INFINITY);
                                }

    @Test(expected = IllegalArgumentException.class)
                                public void testValueDoubleWithNegativeInfinityWhenNotLenient() throws IOException {
                                    JsonTreeWriter writer = new JsonTreeWriter();
                                    writer.setLenient(false);
                                    writer.value(Double.NEGATIVE_INFINITY);
                                }

    @Test
                                public void testValueDoubleAddsToArrayWhenStackNotEmpty() throws IOException {
                                    JsonTreeWriter writer = new JsonTreeWriter();
                                    writer.beginArray();
                                    writer.value(1.1);
                                    writer.value(2.2);
                                    writer.endArray();
                                    
                                    JsonElement product = writer.get();
                                    assertTrue(product.isJsonArray());
                                }

    @Test(expected = IllegalArgumentException.class)
                                public void testValueWithNaNWhenNotLenient() throws IOException {
                                    JsonTreeWriter writer = new JsonTreeWriter();
                                    // Make writer not lenient
                                    writer.setLenient(false);
                                    
                                    writer.value(Double.NaN);
                                }

    @Test(expected = IllegalArgumentException.class)
                            public void testValueWithInfiniteWhenNotLenient() throws IOException {
                                JsonTreeWriter writer = new JsonTreeWriter();
                                // Make writer not lenient
                                writer.setLenient(false);
                                writer.value(Double.POSITIVE_INFINITY);
                            }

    @Test
                            public void testValueWithNonNullString() throws Exception {
                                JsonTreeWriter writer = new JsonTreeWriter();
                                String testValue = "test";
                                JsonWriter result = writer.value(testValue);
                                
                                // Verify put was called with JsonPrimitive containing the test value
                                Field productField = JsonTreeWriter.class.getDeclaredField("product");
                                productField.setAccessible(true);
                                JsonElement product = (JsonElement) productField.get(writer);
                                
                                assertTrue(product instanceof JsonPrimitive);
                                assertEquals(testValue, ((JsonPrimitive) product).getAsString());
                                assertSame(writer, result);
                            }

    @Test
                            public void testValueWithEmptyString() throws Exception {
                                JsonTreeWriter writer = new JsonTreeWriter();
                                String testValue = "";
                                JsonTreeWriter result = (JsonTreeWriter) writer.value(testValue);
                                
                                Field productField = JsonTreeWriter.class.getDeclaredField("product");
                                productField.setAccessible(true);
                                JsonElement product = (JsonElement) productField.get(writer);
                                
                                assertTrue(product instanceof JsonPrimitive);
                                assertEquals(testValue, ((JsonPrimitive) product).getAsString());
                                assertSame(writer, result);
                            }

    @Test
                            public void testValueWhenStackNotEmpty() throws Exception {
                                // Create new writer instance
                                JsonTreeWriter writer = new JsonTreeWriter();
                                
                                // Setup stack with an array
                                writer.beginArray();
                                String testValue = "test";
                                JsonTreeWriter result = (JsonTreeWriter) writer.value(testValue);
                                
                                // Verify the value was added to the array
                                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                                stackField.setAccessible(true);
                                List<JsonElement> stack = (List<JsonElement>) stackField.get(writer);
                                JsonElement arrayElement = stack.get(0);
                                
                                assertTrue(arrayElement instanceof com.google.gson.JsonArray);
                                com.google.gson.JsonArray array = (com.google.gson.JsonArray) arrayElement;
                                assertEquals(1, array.size());
                                assertEquals(testValue, array.get(0).getAsString());
                                assertSame(writer, result);
                            }

    @Test
                            public void testValueBooleanWithEmptyStack() throws Exception {
                                JsonTreeWriter writer = new JsonTreeWriter();
                                JsonTreeWriter result = (JsonTreeWriter) writer.value(true);
                                assertEquals(writer, result);
                                
                                Field productField = JsonTreeWriter.class.getDeclaredField("product");
                                productField.setAccessible(true);
                                JsonElement product = (JsonElement) productField.get(writer);
                                
                                assertTrue(product instanceof JsonPrimitive);
                                assertEquals(true, ((JsonPrimitive) product).getAsBoolean());
                            }

    @Test
                            public void testValueBooleanWithPendingName() throws Exception {
                                JsonTreeWriter writer = new JsonTreeWriter();
                                writer.beginObject();
                                writer.name("test");
                                
                                JsonTreeWriter result = (JsonTreeWriter) writer.value(true);
                                assertEquals(writer, result);
                                
                                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                                stackField.setAccessible(true);
                                @SuppressWarnings("unchecked")
                                List<JsonElement> stack = (List<JsonElement>) stackField.get(writer);
                                
                                JsonElement topElement = stack.get(stack.size() - 1);
                                assertTrue(topElement instanceof JsonObject);
                                
                                JsonObject object = (JsonObject) topElement;
                                assertTrue(object.has("test"));
                                assertTrue(object.get("test") instanceof JsonPrimitive);
                                assertEquals(true, object.get("test").getAsBoolean());
                                
                                Field pendingNameField = JsonTreeWriter.class.getDeclaredField("pendingName");
                                pendingNameField.setAccessible(true);
                                assertNull(pendingNameField.get(writer));
                            }

    @Test
                            public void testValueWithTrueBoolean() throws Exception {
                                JsonTreeWriter jsonTreeWriter = new JsonTreeWriter();
                                JsonTreeWriter result = (JsonTreeWriter) jsonTreeWriter.value(true);
                                
                                assertEquals(jsonTreeWriter, result);
                                
                                Field productField = JsonTreeWriter.class.getDeclaredField("product");
                                productField.setAccessible(true);
                                JsonElement product = (JsonElement) productField.get(jsonTreeWriter);
                                
                                assertTrue(product instanceof JsonPrimitive);
                                assertEquals(true, ((JsonPrimitive) product).getAsBoolean());
                            }

    @Test
                            public void testValueWithFalseBoolean() throws Exception {
                                JsonTreeWriter jsonTreeWriter = new JsonTreeWriter();
                                JsonTreeWriter result = (JsonTreeWriter) jsonTreeWriter.value(false);
                                
                                assertEquals(jsonTreeWriter, result);
                        
                                Field productField = JsonTreeWriter.class.getDeclaredField("product");
                                productField.setAccessible(true);
                                JsonElement product = (JsonElement) productField.get(jsonTreeWriter);
                                
                                assertTrue(product instanceof JsonPrimitive);
                                assertEquals(false, ((JsonPrimitive) product).getAsBoolean());
                            }

    @Test
                            public void testValueWithBooleanInArray() throws Exception {
                                JsonTreeWriter jsonTreeWriter = new JsonTreeWriter();
                                jsonTreeWriter.beginArray();
                                JsonTreeWriter result = (JsonTreeWriter) jsonTreeWriter.value(true);
                                
                                assertEquals(jsonTreeWriter, result);
                                
                                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                                stackField.setAccessible(true);
                                List<JsonElement> stack = (List<JsonElement>) stackField.get(jsonTreeWriter);
                                
                                JsonElement arrayElement = stack.get(0);
                                assertTrue(arrayElement instanceof com.google.gson.JsonArray);
                                
                                com.google.gson.JsonArray array = (com.google.gson.JsonArray) arrayElement;
                                assertEquals(1, array.size());
                                assertTrue(array.get(0).getAsBoolean());
                            }

    @Test
                            public void testValueDoubleWithValidNumber() throws Exception {
                                JsonTreeWriter writer = new JsonTreeWriter();
                                JsonTreeWriter result = (JsonTreeWriter) writer.value(123.45);
                                assertSame(writer, result);
                                
                                JsonElement product = writer.get();
                                assertTrue(product instanceof JsonPrimitive);
                                assertEquals(123.45, ((JsonPrimitive) product).getAsDouble(), 0.001);
                            }

    @Test
                            public void testValueDoubleWithNaNWhenLenient() throws IOException {
                                JsonTreeWriter writer = new JsonTreeWriter();
                                writer.setLenient(true);
                                JsonTreeWriter result = (JsonTreeWriter) writer.value(Double.NaN);
                                assertSame(writer, result);
                                
                                JsonElement product = writer.get();
                                assertTrue(product instanceof JsonPrimitive);
                                assertTrue(Double.isNaN(((JsonPrimitive) product).getAsDouble()));
                            }

    @Test
                            public void testValueDoubleWithInfinityWhenLenient() throws IOException {
                                JsonTreeWriter writer = new JsonTreeWriter();
                                writer.setLenient(true);
                                JsonTreeWriter result = (JsonTreeWriter) writer.value(Double.POSITIVE_INFINITY);
                                assertSame(writer, result);
                                
                                JsonElement product = writer.get();
                                assertTrue(product instanceof JsonPrimitive);
                                assertEquals(Double.POSITIVE_INFINITY, ((JsonPrimitive) product).getAsDouble(), 0.001);
                            }

    @Test
                            public void testValueLong() throws IOException {
                                JsonTreeWriter jsonTreeWriter = new JsonTreeWriter();
                                JsonTreeWriter result = (JsonTreeWriter) jsonTreeWriter.value(123L);
                                assertSame(jsonTreeWriter, result);
                        
                                JsonElement product = jsonTreeWriter.get();
                                assertTrue(product instanceof JsonPrimitive);
                                assertEquals(123L, ((JsonPrimitive) product).getAsLong());
                            }

    @Test
                            public void testValueLongWithStack() throws IOException, NoSuchFieldException, IllegalAccessException {
                                JsonTreeWriter jsonTreeWriter = new JsonTreeWriter();
                                jsonTreeWriter.beginArray();
                                JsonTreeWriter result = (JsonTreeWriter) jsonTreeWriter.value(456L);
                                assertSame(jsonTreeWriter, result);
                        
                                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                                stackField.setAccessible(true);
                                List<JsonElement> stack = (List<JsonElement>) stackField.get(jsonTreeWriter);
                                
                                assertEquals(1, stack.size());
                                JsonElement arrayElement = stack.get(0);
                                assertTrue(arrayElement instanceof JsonArray);
                                
                                JsonArray array = (JsonArray) arrayElement;
                                assertEquals(1, array.size());
                                assertEquals(456L, array.get(0).getAsLong());
                            }

    @Test
                            public void testValueWithNullNumber() throws IOException, NoSuchFieldException, IllegalAccessException {
                                JsonTreeWriter writer = new JsonTreeWriter();
                                JsonTreeWriter result = (JsonTreeWriter) writer.value((Number) null);
                                assertEquals(writer, result);
                                
                                // Verify nullValue() was called
                                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                                stackField.setAccessible(true);
                                JsonElement product = (JsonElement) stackField.get(writer);
                                assertEquals(JsonNull.INSTANCE, product);
                            }

    @Test
                            public void testValueWithValidNumber() throws IOException {
                                JsonTreeWriter writer = new JsonTreeWriter();
                                Number number = 42;
                                JsonTreeWriter result = (JsonTreeWriter) writer.value(number);
                                assertEquals(writer, result);
                                
                                JsonElement product = writer.get();
                                assertTrue(product instanceof JsonPrimitive);
                                assertEquals(number, ((JsonPrimitive) product).getAsNumber());
                            }

    @Test
                        public void testValueWithInfiniteWhenLenient() throws IOException {
                            JsonTreeWriter writer = new JsonTreeWriter();
                            
                            // Make writer lenient
                            writer.setLenient(true);
                            
                            JsonWriter result = writer.value(Double.POSITIVE_INFINITY);
                            assertEquals(writer, result);
                            
                            JsonElement product = writer.get();
                            assertTrue(product instanceof JsonPrimitive);
                            assertTrue(Double.isInfinite(((JsonPrimitive) product).getAsDouble()));
                        }

    @Test
                        public void testValueWithNumberInStack() throws IOException, NoSuchFieldException, IllegalAccessException {
                            // Setup writer and stack
                            JsonTreeWriter writer = new JsonTreeWriter();
                            
                            // Setup stack with JsonArray
                            writer.beginArray();
                            Number number = 123;
                            
                            JsonTreeWriter result = (JsonTreeWriter) writer.value(number);
                            assertEquals(writer, result);
                            
                            // Verify value was added to array in stack
                            Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                            stackField.setAccessible(true);
                            List<JsonElement> stack = (List<JsonElement>) stackField.get(writer);
                            
                            assertFalse(stack.isEmpty());
                            JsonElement arrayElement = stack.get(0);
                            assertTrue(arrayElement instanceof JsonArray);
                            JsonArray array = (JsonArray) arrayElement;
                            assertEquals(1, array.size());
                            assertEquals(number, array.get(0).getAsNumber());
                        }

    @Test
                        public void testValueWithPendingName() throws Exception {
                            JsonTreeWriter writer = new JsonTreeWriter();
                            
                            // Setup pending name
                            writer.beginObject();
                            writer.name("test");
                            Number number = 456;
                            
                            JsonTreeWriter result = (JsonTreeWriter) writer.value(number);
                            assertEquals(writer, result);
                            
                            // Verify value was added to object with pending name
                            List<JsonElement> stack = (List<JsonElement>) writer.getClass()
                                .getDeclaredField("stack")
                                .get(writer);
                            assertFalse(stack.isEmpty());
                            JsonElement objectElement = stack.get(0);
                            assertTrue(objectElement instanceof JsonObject);
                            JsonObject object = (JsonObject) objectElement;
                            assertEquals(number, object.get("test").getAsNumber());
                        }

    @Test
                        public void testValueWithPendingName1() throws Exception {
                            // Create new writer and setup pending name scenario
                            JsonTreeWriter writer = new JsonTreeWriter();
                            writer.beginObject();
                            writer.name("testName");
                            String testValue = "testValue";
                            JsonTreeWriter result = (JsonTreeWriter) writer.value(testValue);
                            
                            // Verify the value was added to the object with the pending name
                            Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                            stackField.setAccessible(true);
                            List<JsonElement> stack = (List<JsonElement>) stackField.get(writer);
                            JsonElement objectElement = stack.get(0);
                            
                            assertTrue(objectElement instanceof JsonObject);
                            JsonObject object = (JsonObject) objectElement;
                            assertEquals(testValue, object.get("testName").getAsString());
                            assertSame(writer, result);
                        }

    @Test
                        public void testValueBooleanWithJsonArrayInStack() throws Exception {
                            JsonTreeWriter writer = new JsonTreeWriter();
                            writer.beginArray();
                            
                            JsonTreeWriter result = (JsonTreeWriter) writer.value(false);
                            assertEquals(writer, result);
                            
                            Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                            stackField.setAccessible(true);
                            @SuppressWarnings("unchecked")
                            List<JsonElement> stack = (List<JsonElement>) stackField.get(writer);
                            
                            JsonElement topElement = stack.get(stack.size() - 1);
                            assertTrue(topElement instanceof JsonArray);
                            
                            JsonArray array = (JsonArray) topElement;
                            assertEquals(1, array.size());
                            assertTrue(array.get(0) instanceof JsonPrimitive);
                            assertEquals(false, array.get(0).getAsBoolean());
                        }

    @Test
                        public void testValueLongWithPendingName() throws IOException, NoSuchFieldException, IllegalAccessException {
                            JsonTreeWriter jsonTreeWriter = new JsonTreeWriter();
                            
                            jsonTreeWriter.beginObject();
                            
                            // Set pending name using reflection
                            Field pendingNameField = JsonTreeWriter.class.getDeclaredField("pendingName");
                            pendingNameField.setAccessible(true);
                            pendingNameField.set(jsonTreeWriter, "testName");
                            
                            JsonWriter result = jsonTreeWriter.value(789L);
                            assertSame(jsonTreeWriter, result);
                        
                            // Get stack using reflection
                            Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                            stackField.setAccessible(true);
                            List<JsonElement> stack = (List<JsonElement>) stackField.get(jsonTreeWriter);
                            
                            assertEquals(1, stack.size());
                            JsonElement objectElement = stack.get(0);
                            assertTrue(objectElement instanceof JsonObject);
                            
                            JsonObject object = (JsonObject) objectElement;
                            assertEquals(1, object.entrySet().size());
                            assertEquals(789L, object.get("testName").getAsLong());
                            
                            // Verify pending name is cleared
                            assertNull(pendingNameField.get(jsonTreeWriter));
                        }

    @Test
                    public void testValueWithNaNWhenLenient() throws IOException {
                        JsonTreeWriter writer = new JsonTreeWriter();
                        
                        // Make writer lenient
                        writer.setLenient(true);
                        
                        JsonTreeWriter result = (JsonTreeWriter) writer.value(Double.NaN);
                        assertEquals(writer, result);
                        
                        JsonElement product = writer.get();
                        assertTrue(product instanceof JsonPrimitive);
                        assertTrue(Double.isNaN(((JsonPrimitive) product).getAsDouble()));
                    }

    @Test
                    public void testValueWithNullBoolean() throws Exception {
                        JsonTreeWriter jsonTreeWriter = new JsonTreeWriter();
                        JsonTreeWriter result = (JsonTreeWriter) jsonTreeWriter.value((Boolean) null);
                        
                        assertEquals(jsonTreeWriter, result);
                        
                        Field productField = JsonTreeWriter.class.getDeclaredField("product");
                        productField.setAccessible(true);
                        JsonElement product = (JsonElement) productField.get(jsonTreeWriter);
                        
                        assertEquals(JsonNull.INSTANCE, product);
                    }

    @Test
            public void testValueWithBooleanInObject() throws Exception {
                JsonTreeWriter jsonTreeWriter = new JsonTreeWriter();
                
                jsonTreeWriter.beginObject();
                jsonTreeWriter.name("test");
                JsonTreeWriter result = (JsonTreeWriter) jsonTreeWriter.value(true);
                
                assertEquals(jsonTreeWriter, result);
                
                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                stackField.setAccessible(true);
                List<JsonElement> stack = (List<JsonElement>) stackField.get(jsonTreeWriter);
                
                JsonElement objectElement = stack.get(0);
                assertTrue(objectElement instanceof JsonObject);
                
                JsonObject jsonObject = (JsonObject) objectElement;
                assertEquals(1, jsonObject.entrySet().size());
                assertTrue(jsonObject.get("test").getAsBoolean());
            }

    @Test
        public void testValueWithNull() throws Exception {
            JsonTreeWriter writer = new JsonTreeWriter();
            JsonWriter result = writer.value((String) null);
    
            // Verify nullValue() was called by checking the product is JsonNull
            Field productField = JsonTreeWriter.class.getDeclaredField("product");
            productField.setAccessible(true);
            JsonElement product = (JsonElement) productField.get(writer);
            
            assertEquals(JsonNull.INSTANCE, product);
            assertSame(writer, result);
        }


}
