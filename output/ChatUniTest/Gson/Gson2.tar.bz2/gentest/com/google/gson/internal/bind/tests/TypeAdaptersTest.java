package gentest.com.google.gson.internal.bind.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.internal.bind.*;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSyntaxException;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.annotations.SerializedName;
import com.google.gson.internal.LazilyParsedNumber;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.Timestamp;
import java.util.BitSet;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.UUID;
 
public class TypeAdaptersTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                        public void testFactoryToString() {
                                                                                                                                                                            TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(
                                                                                                                                                                                Number.class, mock(TypeAdapter.class));
                                                                                                                                                                            
                                                                                                                                                                            String toString = factory.toString();
                                                                                                                                                                            assertTrue(toString.startsWith("Factory[typeHierarchy=java.lang.Number,adapter="));
                                                                                                                                                                        }

    @Test(expected = IOException.class)
                                                                                                                                                                    public void testRead_IOException() throws IOException {
                                                                                                                                                                        JsonReader mockReader = mock(JsonReader.class);
                                                                                                                                                                        Map<String, Object> nameToConstant = new HashMap<>();
                                                                                                                                                                        TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
                                                                                                                                                                            @Override
                                                                                                                                                                            public void write(com.google.gson.stream.JsonWriter out, Object value) {
                                                                                                                                                                            }
                                                                                                                                                                
                                                                                                                                                                            @Override
                                                                                                                                                                            public Object read(JsonReader in) throws IOException {
                                                                                                                                                                                if (in.peek() == JsonToken.NULL) {
                                                                                                                                                                                    in.nextNull();
                                                                                                                                                                                    return null;
                                                                                                                                                                                }
                                                                                                                                                                                return nameToConstant.get(in.nextString());
                                                                                                                                                                            }
                                                                                                                                                                        };
                                                                                                                                                                
                                                                                                                                                                        when(mockReader.peek()).thenReturn(JsonToken.STRING);
                                                                                                                                                                        when(mockReader.nextString()).thenThrow(new IOException());
                                                                                                                                                                        
                                                                                                                                                                        adapter.read(mockReader);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                public void testNewTypeHierarchyFactoryWithMatchingType() {
                                                                                                                                                                    // Create mock objects
                                                                                                                                                                    TypeAdapter<String> mockStringAdapter = mock(TypeAdapter.class);
                                                                                                                                                                    Gson mockGson = mock(Gson.class);
                                                                                                                                                                    
                                                                                                                                                                    // Create factory instance
                                                                                                                                                                    TypeAdapterFactory factory = new TypeAdapterFactory() {
                                                                                                                                                                        @Override
                                                                                                                                                                        public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> type) {
                                                                                                                                                                            if (CharSequence.class.isAssignableFrom(type.getRawType())) {
                                                                                                                                                                                @SuppressWarnings("unchecked")
                                                                                                                                                                                TypeAdapter<T> result = (TypeAdapter<T>) mockStringAdapter;
                                                                                                                                                                                return result;
                                                                                                                                                                            }
                                                                                                                                                                            return null;
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        @Override
                                                                                                                                                                        public String toString() {
                                                                                                                                                                            return "Factory[typeHierarchy=java.lang.CharSequence,adapter=" + mockStringAdapter + "]";
                                                                                                                                                                        }
                                                                                                                                                                    };
                                                                                                                                                                    
                                                                                                                                                                    TypeToken<String> stringTypeToken = TypeToken.get(String.class);
                                                                                                                                                                    TypeAdapter<String> adapter = factory.create(mockGson, stringTypeToken);
                                                                                                                                                                    
                                                                                                                                                                    assertNotNull(adapter);
                                                                                                                                                                    assertEquals("Factory[typeHierarchy=java.lang.CharSequence,adapter=" + mockStringAdapter + "]", 
                                                                                                                                                                        factory.toString());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testNewTypeHierarchyFactoryWithNonMatchingType() {
                                                                                                                                                                    // Create mock objects
                                                                                                                                                                    TypeAdapter<String> mockStringAdapter = mock(TypeAdapter.class);
                                                                                                                                                                    Gson mockGson = mock(Gson.class);
                                                                                                                                                                    
                                                                                                                                                                    TypeAdapterFactory factory = new TypeAdapterFactory() {
                                                                                                                                                                        @Override
                                                                                                                                                                        public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> type) {
                                                                                                                                                                            if (!CharSequence.class.isAssignableFrom(type.getRawType())) {
                                                                                                                                                                                return null;
                                                                                                                                                                            }
                                                                                                                                                                            @SuppressWarnings("unchecked")
                                                                                                                                                                            TypeAdapter<T> result = (TypeAdapter<T>) mockStringAdapter;
                                                                                                                                                                            return result;
                                                                                                                                                                        }
                                                                                                                                                                    };
                                                                                                                                                                    
                                                                                                                                                                    TypeToken<Integer> integerTypeToken = TypeToken.get(Integer.class);
                                                                                                                                                                    TypeAdapter<Integer> adapter = factory.create(mockGson, integerTypeToken);
                                                                                                                                                                    
                                                                                                                                                                    assertNull(adapter);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testCreatedAdapterWrite() throws IOException {
                                                                                                                                                                    @SuppressWarnings("unchecked")
                                                                                                                                                                    TypeAdapter<String> mockStringAdapter = mock(TypeAdapter.class);
                                                                                                                                                                    Gson mockGson = mock(Gson.class);
                                                                                                                                                                    JsonWriter mockJsonWriter = mock(JsonWriter.class);
                                                                                                                                                                    
                                                                                                                                                                    when(mockGson.getAdapter(TypeToken.get(String.class))).thenReturn(mockStringAdapter);
                                                                                                                                                                    
                                                                                                                                                                    TypeAdapterFactory factory = new TypeAdapterFactory() {
                                                                                                                                                                        @Override
                                                                                                                                                                        public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> type) {
                                                                                                                                                                            if (CharSequence.class.isAssignableFrom(type.getRawType())) {
                                                                                                                                                                                return (TypeAdapter<T>) mockStringAdapter;
                                                                                                                                                                            }
                                                                                                                                                                            return null;
                                                                                                                                                                        }
                                                                                                                                                                    };
                                                                                                                                                                    
                                                                                                                                                                    TypeAdapter<String> adapter = factory.create(mockGson, TypeToken.get(String.class));
                                                                                                                                                                    
                                                                                                                                                                    String value = "test";
                                                                                                                                                                    adapter.write(mockJsonWriter, value);
                                                                                                                                                                    
                                                                                                                                                                    verify(mockStringAdapter).write(mockJsonWriter, value);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testCreatedAdapterReadWithValidType() throws IOException {
                                                                                                                                                                    // Create mocks
                                                                                                                                                                    TypeAdapter<String> mockStringAdapter = mock(TypeAdapter.class);
                                                                                                                                                                    Gson mockGson = mock(Gson.class);
                                                                                                                                                                    JsonReader mockJsonReader = mock(JsonReader.class);
                                                                                                                                                                    
                                                                                                                                                                    // Create factory using TypeAdapters
                                                                                                                                                                    TypeAdapterFactory factory = new TypeAdapterFactory() {
                                                                                                                                                                        @Override
                                                                                                                                                                        public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> type) {
                                                                                                                                                                            if (CharSequence.class.isAssignableFrom(type.getRawType())) {
                                                                                                                                                                                return (TypeAdapter<T>) mockStringAdapter;
                                                                                                                                                                            }
                                                                                                                                                                            return null;
                                                                                                                                                                        }
                                                                                                                                                                    };
                                                                                                                                                                    
                                                                                                                                                                    TypeAdapter<String> adapter = factory.create(mockGson, TypeToken.get(String.class));
                                                                                                                                                                    
                                                                                                                                                                    when(mockStringAdapter.read(mockJsonReader)).thenReturn("test");
                                                                                                                                                                    
                                                                                                                                                                    String result = adapter.read(mockJsonReader);
                                                                                                                                                                    
                                                                                                                                                                    assertEquals("test", result);
                                                                                                                                                                    verify(mockStringAdapter).read(mockJsonReader);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testCreatedAdapterReadWithNull() throws IOException {
                                                                                                                                                                    // Create mock objects
                                                                                                                                                                    TypeAdapter<String> mockStringAdapter = mock(TypeAdapter.class);
                                                                                                                                                                    Gson mockGson = mock(Gson.class);
                                                                                                                                                                    JsonReader mockJsonReader = mock(JsonReader.class);
                                                                                                                                                            
                                                                                                                                                                    // Create test factory implementation
                                                                                                                                                                    TypeAdapterFactory factory = new TypeAdapterFactory() {
                                                                                                                                                                        @Override
                                                                                                                                                                        public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> type) {
                                                                                                                                                                            if (CharSequence.class.isAssignableFrom(type.getRawType())) {
                                                                                                                                                                                return (TypeAdapter<T>) mockStringAdapter;
                                                                                                                                                                            }
                                                                                                                                                                            return null;
                                                                                                                                                                        }
                                                                                                                                                                    };
                                                                                                                                                            
                                                                                                                                                                    TypeAdapter<String> adapter = factory.create(mockGson, TypeToken.get(String.class));
                                                                                                                                                                        
                                                                                                                                                                    when(mockStringAdapter.read(mockJsonReader)).thenReturn(null);
                                                                                                                                                                        
                                                                                                                                                                    assertNull(adapter.read(mockJsonReader));
                                                                                                                                                                }

    @Test
                                                                                                                                                    public void testWriteNullValue() throws Exception {
                                                                                                                                                        // Get the private constructor via reflection
                                                                                                                                                        Class<?> clazz = Class.forName("com.google.gson.internal.bind.TypeAdapters");
                                                                                                                                                        Method getInstanceMethod = clazz.getDeclaredMethod("getInstance");
                                                                                                                                                        getInstanceMethod.setAccessible(true);
                                                                                                                                                        Object adapter = getInstanceMethod.invoke(null);
                                                                                                                                                
                                                                                                                                                        JsonWriter mockWriter = mock(JsonWriter.class);
                                                                                                                                                        
                                                                                                                                                        // Get the write method via reflection
                                                                                                                                                        Method writeMethod = clazz.getDeclaredMethod("write", JsonWriter.class, Object.class);
                                                                                                                                                        writeMethod.setAccessible(true);
                                                                                                                                                        writeMethod.invoke(adapter, mockWriter, null);
                                                                                                                                                        
                                                                                                                                                        verify(mockWriter).value((String)null);
                                                                                                                                                    }

    @Test
                                                                        public void testCreatedAdapterReadWithInvalidType() throws IOException {
                                                                            // Create mock objects
                                                                            TypeAdapter<String> mockStringAdapter = mock(TypeAdapter.class);
                                                                            Gson mockGson = mock(Gson.class);
                                                                            JsonReader mockJsonReader = mock(JsonReader.class);
                                                                            
                                                                            // Create the adapter using TypeAdapters
                                                                            TypeAdapter<String> adapter = TypeAdapters.newTypeHierarchyFactory(String.class, mockStringAdapter)
                                                                                .create(mockGson, null);
                                                                            
                                                                            // Setup mock behavior
                                                                            when(mockStringAdapter.read(mockJsonReader)).thenReturn("test");
                                                                            
                                                                            // Execute test
                                                                            adapter.read(mockJsonReader);
                                                                        }

    @Test(expected = NullPointerException.class)
                                            public void testWriteWithNullWriter() throws IOException {
                                                // Create instance using reflection since constructor is private
                                                com.google.gson.internal.bind.TypeAdapters typeAdapters;
                                                try {
                                                    java.lang.reflect.Constructor<com.google.gson.internal.bind.TypeAdapters> constructor = 
                                                        com.google.gson.internal.bind.TypeAdapters.class.getDeclaredConstructor();
                                                    constructor.setAccessible(true);
                                                    typeAdapters = constructor.newInstance();
                                                } catch (Exception e) {
                                                    throw new RuntimeException("Failed to create TypeAdapters instance", e);
                                                }
                                                
                                                // Get the write method using reflection
                                                Method method;
                                                try {
                                                    method = com.google.gson.internal.bind.TypeAdapters.class.getDeclaredMethod(
                                                        "write", JsonWriter.class, Object.class);
                                                } catch (Exception e) {
                                                    throw new RuntimeException("Failed to get write method", e);
                                                }
                                                
                                                JsonWriter writer = null;
                                                Object value = new Object();
                                                
                                                // Using reflection to test private write method
                                                try {
                                                    method.setAccessible(true);
                                                    method.invoke(typeAdapters, writer, value);
                                                } catch (Exception e) {
                                                    if (e.getCause() instanceof NullPointerException) {
                                                        throw (NullPointerException) e.getCause();
                                                    }
                                                    throw new RuntimeException(e);
                                                }
                                            }

    @Test
            public void testWriteWithUnknownEnumValue() throws Exception {
                // Setup
                
                // Create an instance of EnumTypeAdapter for TestEnum
                Class<?> enumTypeAdapterClass = Class.forName("com.google.gson.internal.bind.TypeAdapters$EnumTypeAdapter");
                Constructor<?> constructor = enumTypeAdapterClass.getDeclaredConstructor(Class.class);
                constructor.setAccessible(true);
                
                // Get the write method
                Method writeMethod = enumTypeAdapterClass.getDeclaredMethod("write", JsonWriter.class, Object.class);
                writeMethod.setAccessible(true);
                
                // Create an enum value that's not in TestEnum (using null to simulate unknown value)
                writeMethod.invoke(enumTypeAdapter, jsonWriter, null);
                
                // Verify the output
                jsonWriter.flush();
                assertEquals("null", stringWriter.toString());
            }

    @Test
            public void testWriteNonNullValue() throws IOException {
                // Setup mock writer
                JsonWriter mockWriter = mock(JsonWriter.class);
                
                // Create test enum value
                // Create adapter
{
                    @Override
                    public void write(JsonWriter out, TestEnum value) throws IOException {
                        out.value(value.name());
                    }
                    
                    @Override
{
                    }
                };
                
                // Test write operation
            }

    @Test
            public void testRead_UnknownEnumValue() throws IOException {
                
{
                    @Override
                    public void write(com.google.gson.stream.JsonWriter out, TestEnum value) throws IOException {
                        throw new UnsupportedOperationException();
                    }
                
                    @Override
{
{
                            in.nextNull();
                        }
                        return nameToConstant.get(in.nextString());
                    }
                };
            
            }

    @Test
            public void testWriteDifferentNonNullValue() throws Exception {
                
                // Create StringWriter and JsonWriter for testing
                
                // Use reflection to access private EnumTypeAdapter
                Class<?> enumTypeAdapterClass = Class.forName("com.google.gson.internal.bind.TypeAdapters$EnumTypeAdapter");
                
                // Create instance of EnumTypeAdapter
            }

    @Test
            public void testRead_NullValue() throws IOException {
{
                    @Override
                    public void write(com.google.gson.stream.JsonWriter out, TestEnum value) throws IOException {
                    }
                
                    @Override
{
{
                            in.nextNull();
                        }
                    }
}
                
            }

    @Test
        public void testRead_ValidEnumValue() throws IOException {
{
                @Override
                public void write(JsonWriter out, TestEnum value) throws IOException {
                    throw new UnsupportedOperationException();
                }
    
                @Override
{
                    if (in.peek() == com.google.gson.stream.JsonToken.NULL) {
                        in.nextNull();
                    }
                    String value = in.nextString();
                }
            };
    
            // Test with VALUE1
    
            // Test with VALUE2
    
            // Test with null
        }


}
