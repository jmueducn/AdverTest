package gentest.com.google.gson.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.*;
import java.lang.reflect.Field;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
 
public class TypeInfoFactoryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                public void testExtractTypeForHierarchyWithUnsupportedParentType() throws Exception {
                    // Create a custom GenericArrayType implementation since we can't access the original one
                    class GenericArrayTypeImpl implements GenericArrayType {
                        private final Type componentType;
            
                        GenericArrayTypeImpl(Type componentType) {
                            this.componentType = componentType;
                        }
            
                        @Override
                        public Type getGenericComponentType() {
                            return componentType;
                        }
                    }
            
                    // Get the method via reflection
                    Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                    Method method = typeInfoFactoryClass.getDeclaredMethod(
                        "extractTypeForHierarchy", Type.class, TypeVariable.class);
                    method.setAccessible(true);
            
                    class Parent<T> {}
                    TypeVariable<?> typeVar = Parent.class.getTypeParameters()[0];
            
                    // Using GenericArrayType as unsupported type
                    GenericArrayType unsupportedType = new GenericArrayTypeImpl(String.class);
                    Type result = (Type) method.invoke(null, unsupportedType, typeVar);
            
                    assertNull(result);
                }

    @Test
                public void testExtractTypeForHierarchyWithNullSuperClass() throws Exception {
                    // Create a local version of TypeInfoFactory since the original is not public
                    class LocalTypeInfoFactory {
                        private Type extractTypeForHierarchy(Type parentType, TypeVariable<?> typeToEvaluate) {
                            Class<?> rawParentType = null;
                            if (parentType instanceof Class<?>) {
                                rawParentType = (Class<?>) parentType;
                            } else if (parentType instanceof ParameterizedType) {
                                ParameterizedType parentTypeAsPT = (ParameterizedType) parentType;
                                rawParentType = (Class<?>) parentTypeAsPT.getRawType();
                            } else {
                                return null;
                            }
            
                            Type superClass = rawParentType.getGenericSuperclass();
                            if (superClass instanceof ParameterizedType
                                && ((ParameterizedType) superClass).getRawType() == typeToEvaluate.getGenericDeclaration()) {
                                TypeVariable<?>[] classTypeVariables =
                                    ((Class<?>) ((ParameterizedType) superClass).getRawType()).getTypeParameters();
                                int indexOfActualTypeArgument = -1;
                                for (int i = 0; i < classTypeVariables.length; i++) {
                                    if (classTypeVariables[i].equals(typeToEvaluate)) {
                                        indexOfActualTypeArgument = i;
                                        break;
                                    }
                                }
            
                                Type[] actualTypeArguments = null;
                                if (parentType instanceof Class<?>) {
                                    actualTypeArguments = ((ParameterizedType) superClass).getActualTypeArguments();
                                } else if (parentType instanceof ParameterizedType) {
                                    actualTypeArguments = ((ParameterizedType) parentType).getActualTypeArguments();
                                } else {
                                    return null;
                                }
            
                                return actualTypeArguments[indexOfActualTypeArgument];
                            }
            
                            Type searchedType = null;
                            if (superClass != null) {
                                searchedType = extractTypeForHierarchy(superClass, typeToEvaluate);
                            }
                            return searchedType;
                        }
                    }
            
                    class Parent<T> {}
                    class Child extends Parent<String> {}
            
                    TypeVariable<?> typeVar = String.class.getTypeParameters().length > 0 ? 
                        String.class.getTypeParameters()[0] : null;
                    Type result = new LocalTypeInfoFactory().extractTypeForHierarchy(Child.class, typeVar);
            
                    assertNull(result);
                }

    @Test
                public void testExtractTypeForHierarchyWithNonMatchingDeclaration() throws Exception {
                    // Get the TypeInfoFactory class using reflection since it's not public
                    Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                    Method method = typeInfoFactoryClass.getDeclaredMethod(
                        "extractTypeForHierarchy", Type.class, TypeVariable.class);
                    method.setAccessible(true);
            
                    class Parent<T> {}
                    class Child extends Parent<String> {}
            
                    // Using a type variable from a different class
                    TypeVariable<?> typeVar = Object.class.getTypeParameters().length > 0 ? 
                        Object.class.getTypeParameters()[0] : null;
                    Type result = (Type) method.invoke(null, Child.class, typeVar);
            
                    assertNull(result);
                }

    @Test
            public void testExtractTypeForHierarchyWithClassParentType() throws Exception {
                // Use reflection to access the private method
                Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                Method method = typeInfoFactoryClass.getDeclaredMethod(
                    "extractTypeForHierarchy", Type.class, TypeVariable.class);
                method.setAccessible(true);
        
                // Create a test class hierarchy
                class Parent<T> {}
                class Child extends Parent<String> {}
        
                TypeVariable<?> typeVar = Parent.class.getTypeParameters()[0];
                Type result = (Type) method.invoke(null, Child.class, typeVar);
        
                assertEquals(String.class, result);
            }

    @Test
            public void testExtractTypeForHierarchyWithMultipleLevels() throws Exception {
                // Use reflection to access the private method
                Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                Method method = typeInfoFactoryClass.getDeclaredMethod(
                    "extractTypeForHierarchy", Type.class, TypeVariable.class);
                method.setAccessible(true);
        
                // Create a multi-level test class hierarchy
                class GrandParent<T> {}
                class Parent<U> extends GrandParent<U> {}
                class Child extends Parent<String> {}
        
                TypeVariable<?> typeVar = GrandParent.class.getTypeParameters()[0];
                Type result = (Type) method.invoke(null, Child.class, typeVar);
        
                assertEquals(String.class, result);
            }

    @Test
            public void testExtractRealTypesWithMultipleTypes() throws Exception {
                // Setup mocks
                Type mockType1 = mock(Type.class);
                Type mockType2 = mock(Type.class);
                Type mockParentType = mock(Type.class);
                Class<?> mockRawParentClass = Object.class;
        
                Type[] input = {mockType1, mockType2};
                
                // Use reflection to access non-public class and method
                Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                Method method = typeInfoFactoryClass.getDeclaredMethod(
                    "extractRealTypes", Type[].class, Type.class, Class.class);
                method.setAccessible(true);
                Type[] result = (Type[]) method.invoke(null, input, mockParentType, mockRawParentClass);
        
                assertNotNull(result);
                assertEquals(2, result.length);
            }

    @Test
            public void testExtractRealTypesWithNullInput() throws Exception {
                // Create mock objects
                Type mockParentType = mock(Type.class);
                Class<?> mockRawParentClass = Object.class;
                Type[] mockActualTypeArguments = null;
                
                // Get the TypeInfoFactory class using reflection
                Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                
                // Get and invoke the method using reflection
                Method extractRealTypesMethod = typeInfoFactoryClass.getDeclaredMethod(
                    "extractRealTypes", Type[].class, Type.class, Class.class);
                extractRealTypesMethod.setAccessible(true);
                
                extractRealTypesMethod.invoke(null, mockActualTypeArguments, mockParentType, mockRawParentClass);
            }

    @Test
            public void testExtractRealTypesWithActualTypes() throws Exception {
                Class<?> stringClass = String.class;
                Class<?> integerClass = Integer.class;
                Type[] input = {stringClass, integerClass};
                
                // Create mock objects
                Type mockParentType = new Type() {};
                Class<?> mockRawParentClass = Object.class;
                
                // Get private method via reflection
                Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                Method extractRealTypesMethod = typeInfoFactoryClass.getDeclaredMethod(
                    "extractRealTypes", Type[].class, Type.class, Class.class);
                extractRealTypesMethod.setAccessible(true);
                
                // Invoke method
                Type[] result = (Type[]) extractRealTypesMethod.invoke(
                    null, input, mockParentType, mockRawParentClass);
                
                assertNotNull(result);
                assertEquals(2, result.length);
                assertSame(stringClass, result[0]);
                assertSame(integerClass, result[1]);
            }

    @Test
            public void testExtractRealTypesWithTypeVariables() throws Exception {
                // Get the non-public TypeInfoFactory class using reflection
                Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                
                TypeVariable<?> typeVariable = mock(TypeVariable.class);
                Type resolvedType = String.class;
                Type mockParentType = mock(ParameterizedType.class);
                Class<?> mockRawParentClass = Object.class;
                
                Method getActualTypeMethod = typeInfoFactoryClass.getDeclaredMethod(
                    "getActualType", Type.class, Type.class, Class.class);
                getActualTypeMethod.setAccessible(true);
                
                when(getActualTypeMethod.invoke(null, typeVariable, mockParentType, mockRawParentClass))
                    .thenReturn(resolvedType);
                
                Type[] input = {typeVariable};
                
                Method extractRealTypesMethod = typeInfoFactoryClass.getDeclaredMethod(
                    "extractRealTypes", Type[].class, Type.class, Class.class);
                extractRealTypesMethod.setAccessible(true);
                Type[] result = (Type[]) extractRealTypesMethod.invoke(
                    null, input, mockParentType, mockRawParentClass);
                
                assertNotNull(result);
                assertEquals(1, result.length);
                assertSame(resolvedType, result[0]);
            }

    @Test
        public void testExtractTypeForHierarchyWithParameterizedParentType() throws Exception {
            // Define ParameterizedTypeImpl locally
            class ParameterizedTypeImpl implements ParameterizedType {
                private final Type rawType;
                private final Type[] actualTypeArguments;
                private final Type ownerType;
    
                ParameterizedTypeImpl(Type rawType, Type[] actualTypeArguments, Type ownerType) {
                    this.rawType = rawType;
                    this.actualTypeArguments = actualTypeArguments;
                    this.ownerType = ownerType;
                }
    
                @Override
                public Type[] getActualTypeArguments() {
                    return actualTypeArguments;
                }
    
                @Override
                public Type getRawType() {
                    return rawType;
                }
    
                @Override
                public Type getOwnerType() {
                    return ownerType;
                }
            }
    
            // Get the TypeInfoFactory class using reflection since it's not public
            Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
            Method method = typeInfoFactoryClass.getDeclaredMethod(
                "extractTypeForHierarchy", Type.class, TypeVariable.class);
            method.setAccessible(true);
    
            // Create a test class hierarchy
            class Parent<T> {}
            class Child extends Parent<String> {}
    
            TypeVariable<?> typeVar = Parent.class.getTypeParameters()[0];
            ParameterizedType childType = new ParameterizedTypeImpl(
                Child.class, new Type[]{String.class}, null);
            Type result = (Type) method.invoke(null, childType, typeVar);
    
            assertEquals(String.class, result);
        }

    @Test
        public void testExtractRealTypesWithEmptyArray() throws Exception {
            Type mockParentType = mock(Type.class);
            Class<?> mockRawParentClass = mock(Class.class);
            
            // Use reflection to access the package-private class
            Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
            Method extractRealTypesMethod = typeInfoFactoryClass.getDeclaredMethod(
                "extractRealTypes", Type[].class, Type.class, Class.class);
            extractRealTypesMethod.setAccessible(true);
            
            Type[] result = (Type[]) extractRealTypesMethod.invoke(
                null, new Type[0], mockParentType, mockRawParentClass);
                
            assertNotNull(result);
            assertEquals(0, result.length);
        }

    @Test
        public void testExtractRealTypesWithSingleType() throws Exception {
            Type mockType1 = mock(Type.class);
            Type mockParentType = mock(Type.class);
            Class<?> mockRawParentClass = Object.class;
            
            // Use reflection to access the non-public class
            Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
            Object factory = typeInfoFactoryClass.getDeclaredConstructor().newInstance();
            
            Method method = typeInfoFactoryClass.getDeclaredMethod(
                "extractRealTypes", Type[].class, Type.class, Class.class);
            method.setAccessible(true);
            
            Type[] input = {mockType1};
            Type[] result = (Type[]) method.invoke(factory, input, mockParentType, mockRawParentClass);
            
            assertNotNull(result);
            assertEquals(1, result.length);
        }


}
