package gentest.com.google.gson.internal.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.internal.*;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentNavigableMap;
import java.util.concurrent.ConcurrentSkipListMap;
import com.google.gson.InstanceCreator;
import com.google.gson.JsonIOException;
import com.google.gson.reflect.TypeToken;
 
public class ConstructorConstructorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test(expected = JsonIOException.class)
                                                public void testNewDefaultImplementationConstructor_EnumSetInvalidType() throws Exception {
                                                    ConstructorConstructor constructorConstructor = new ConstructorConstructor(null);
                                                    Method method = ConstructorConstructor.class.getDeclaredMethod(
                                                        "newDefaultImplementationConstructor", Type.class, Class.class);
                                                    method.setAccessible(true);
                                            
                                                    Type type = mock(Type.class);
                                                    Class<?> rawType = EnumSet.class;
                                                    ObjectConstructor<?> constructor = (ObjectConstructor<?>) method.invoke(
                                                        constructorConstructor, type, rawType);
                                            
                                                    constructor.construct();
                                                }

    @Test
                                                public void testNewDefaultImplementationConstructor_Queue() throws Exception {
                                                    ConstructorConstructor constructorConstructor = new ConstructorConstructor(null);
                                                    Method method = ConstructorConstructor.class.getDeclaredMethod(
                                                        "newDefaultImplementationConstructor", Type.class, Class.class);
                                                    method.setAccessible(true);
                                                
                                                    Type type = mock(Type.class);
                                                    Class<?> rawType = Queue.class;
                                                    ObjectConstructor<?> constructor = (ObjectConstructor<?>) method.invoke(
                                                        constructorConstructor, type, rawType);
                                                
                                                    assertNotNull(constructor);
                                                    Object result = constructor.construct();
                                                    assertTrue(result instanceof LinkedList);
                                                }

    @Test
                                                public void testNewDefaultImplementationConstructor_SortedMap() throws Exception {
                                                    ConstructorConstructor constructorConstructor = new ConstructorConstructor(null);
                                                    Method method = ConstructorConstructor.class.getDeclaredMethod(
                                                        "newDefaultImplementationConstructor", Type.class, Class.class);
                                                    method.setAccessible(true);
                                            
                                                    Type type = mock(Type.class);
                                                    Class<?> rawType = SortedMap.class;
                                                    ObjectConstructor<?> constructor = (ObjectConstructor<?>) method.invoke(
                                                        constructorConstructor, type, rawType);
                                            
                                                    assertNotNull(constructor);
                                                    Object result = constructor.construct();
                                                    assertTrue(result instanceof TreeMap);
                                                }

    @Test
                                                public void testNewDefaultImplementationConstructor_MapWithNonStringKey() throws Exception {
                                                    ConstructorConstructor constructorConstructor = new ConstructorConstructor(null);
                                                    Method method = ConstructorConstructor.class.getDeclaredMethod(
                                                        "newDefaultImplementationConstructor", Type.class, Class.class);
                                                    method.setAccessible(true);
                                            
                                                    ParameterizedType type = mock(ParameterizedType.class);
                                                    when(type.getActualTypeArguments()).thenReturn(new Type[]{Integer.class});
                                                    Class<?> rawType = Map.class;
                                                    ObjectConstructor<?> constructor = (ObjectConstructor<?>) method.invoke(
                                                        constructorConstructor, type, rawType);
                                            
                                                    assertNotNull(constructor);
                                                    Object result = constructor.construct();
                                                    assertTrue(result instanceof LinkedHashMap);
                                                }

    @Test
                                                public void testNewDefaultImplementationConstructor_MapWithStringKey() throws Exception {
                                                    ConstructorConstructor constructorConstructor = new ConstructorConstructor(null);
                                                    Method method = ConstructorConstructor.class.getDeclaredMethod(
                                                        "newDefaultImplementationConstructor", Type.class, Class.class);
                                                    method.setAccessible(true);
                                            
                                                    ParameterizedType type = mock(ParameterizedType.class);
                                                    when(type.getActualTypeArguments()).thenReturn(new Type[]{String.class});
                                                    Class<?> rawType = Map.class;
                                                    ObjectConstructor<?> constructor = (ObjectConstructor<?>) method.invoke(
                                                        constructorConstructor, type, rawType);
                                            
                                                    assertNotNull(constructor);
                                                    Object result = constructor.construct();
                                                    assertTrue(result instanceof LinkedTreeMap);
                                                }

    @Test
                                                public void testNewDefaultImplementationConstructor_UnsupportedType() throws Exception {
                                                    ConstructorConstructor constructorConstructor = new ConstructorConstructor(null);
                                                    Method method = ConstructorConstructor.class.getDeclaredMethod(
                                                        "newDefaultImplementationConstructor", Type.class, Class.class);
                                                    method.setAccessible(true);
                                                
                                                    Type type = mock(Type.class);
                                                    Class<?> rawType = String.class;
                                                    ObjectConstructor<?> constructor = (ObjectConstructor<?>) method.invoke(
                                                        constructorConstructor, type, rawType);
                                                
                                                    assertNull(constructor);
                                                }

    @Test
                                            public void testNewDefaultImplementationConstructor_SortedSet() throws Exception {
                                                ConstructorConstructor constructorConstructor = new ConstructorConstructor(null);
                                                Method method = ConstructorConstructor.class.getDeclaredMethod(
                                                    "newDefaultImplementationConstructor", Type.class, Class.class);
                                                method.setAccessible(true);
                                            
                                                Type type = mock(Type.class);
                                                Class<?> rawType = SortedSet.class;
                                                ObjectConstructor<?> constructor = (ObjectConstructor<?>) method.invoke(
                                                    constructorConstructor, type, rawType);
                                            
                                                assertNotNull(constructor);
                                                Object result = constructor.construct();
                                                assertTrue(result instanceof TreeSet);
                                            }

    @Test
                                            public void testNewDefaultImplementationConstructor_ConcurrentNavigableMap() throws Exception {
                                                ConstructorConstructor constructorConstructor = new ConstructorConstructor(null);
                                                Method method = ConstructorConstructor.class.getDeclaredMethod(
                                                    "newDefaultImplementationConstructor", Type.class, Class.class);
                                                method.setAccessible(true);
                                            
                                                Type type = mock(Type.class);
                                                Class<?> rawType = ConcurrentNavigableMap.class;
                                                ObjectConstructor<?> constructor = (ObjectConstructor<?>) method.invoke(
                                                    constructorConstructor, type, rawType);
                                            
                                                assertNotNull(constructor);
                                                Object result = constructor.construct();
                                                assertTrue(result instanceof ConcurrentSkipListMap);
                                            }

    @Test
                                            public void testNewDefaultImplementationConstructor_ConcurrentMap() throws Exception {
                                                Map<Type, InstanceCreator<?>> instanceCreators = mock(Map.class);
                                                ConstructorConstructor constructorConstructor = new ConstructorConstructor(instanceCreators);
                                                Method method = ConstructorConstructor.class.getDeclaredMethod(
                                                    "newDefaultImplementationConstructor", Type.class, Class.class);
                                                method.setAccessible(true);
                                            
                                                Type type = mock(Type.class);
                                                Class<?> rawType = ConcurrentMap.class;
                                                ObjectConstructor<?> constructor = (ObjectConstructor<?>) method.invoke(
                                                    constructorConstructor, type, rawType);
                                            
                                                assertNotNull(constructor);
                                                Object result = constructor.construct();
                                                assertTrue(result instanceof ConcurrentHashMap);
                                            }

    @Test
            public void testNewDefaultImplementationConstructor_EnumSet() throws Exception {
                ConstructorConstructor constructorConstructor = new ConstructorConstructor(null);
                Method method = ConstructorConstructor.class.getDeclaredMethod(
                    "newDefaultImplementationConstructor", Type.class, Class.class);
                method.setAccessible(true);
                
                ParameterizedType type = mock(ParameterizedType.class);
    {}
                Class<?> rawType = EnumSet.class;
                ObjectConstructor<?> constructor = (ObjectConstructor<?>) method.invoke(
                    constructorConstructor, type, rawType);
                
                assertNotNull(constructor);
                Object result = constructor.construct();
                assertTrue(result instanceof EnumSet);
            }

    @Test
        public void testNewDefaultImplementationConstructor_Set() throws Exception {
            ConstructorConstructor constructorConstructor = new ConstructorConstructor(null);
            
            Method method = ConstructorConstructor.class.getDeclaredMethod(
                "newDefaultImplementationConstructor", Type.class, Class.class);
            method.setAccessible(true);
            
            Type type = mock(Type.class);
            Class<?> rawType = Set.class;
            ObjectConstructor<?> constructor = (ObjectConstructor<?>) method.invoke(
                constructorConstructor, type, rawType);
            
            assertNotNull(constructor);
            Object result = constructor.construct();
            assertTrue(result instanceof LinkedHashSet);
        }

    @Test
        public void testNewDefaultImplementationConstructor_Collection() throws Exception {
            ConstructorConstructor constructorConstructor = new ConstructorConstructor(null);
            Method method = ConstructorConstructor.class.getDeclaredMethod(
                "newDefaultImplementationConstructor", Type.class, Class.class);
            method.setAccessible(true);
            
            Type type = mock(Type.class);
            Class<?> rawType = Collection.class;
            ObjectConstructor<?> constructor = (ObjectConstructor<?>) method.invoke(
                constructorConstructor, type, rawType);
            
            assertNotNull(constructor);
            Object result = constructor.construct();
            assertTrue(result instanceof ArrayList);
        }


}
