package gentest.org.apache.commons.math3.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.util.*;
import java.io.PrintStream;
 
public class FastMathTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                public void testSinhSpecialCases() {
                    final double EPSILON = 1.0e-20;
                    
                    // Test NaN input
                    assertTrue(Double.isNaN(FastMath.sinh(Double.NaN)));
                    
                    // Test positive infinity
                    assertEquals(Double.POSITIVE_INFINITY, FastMath.sinh(Double.POSITIVE_INFINITY), EPSILON);
                    
                    // Test negative infinity
                    assertEquals(Double.NEGATIVE_INFINITY, FastMath.sinh(Double.NEGATIVE_INFINITY), EPSILON);
                    
                    // Test zero
                    assertEquals(0.0, FastMath.sinh(0.0), EPSILON);
                    assertEquals(-0.0, FastMath.sinh(-0.0), EPSILON);
                }

    @Test
                public void testSinhSmallValues() {
                    final double EPSILON = 1e-15;
                    
                    // Values between -20 and 20
                    assertEquals(Math.sinh(1.0), FastMath.sinh(1.0), EPSILON);
                    assertEquals(Math.sinh(-1.0), FastMath.sinh(-1.0), EPSILON);
                    assertEquals(Math.sinh(0.5), FastMath.sinh(0.5), EPSILON);
                    assertEquals(Math.sinh(-0.5), FastMath.sinh(-0.5), EPSILON);
                    assertEquals(Math.sinh(10.0), FastMath.sinh(10.0), EPSILON);
                    assertEquals(Math.sinh(-10.0), FastMath.sinh(-10.0), EPSILON);
                    assertEquals(Math.sinh(19.0), FastMath.sinh(19.0), EPSILON);
                    assertEquals(Math.sinh(-19.0), FastMath.sinh(-19.0), EPSILON);
                }

    @Test
                public void testSinhTransitionPoints() {
                    final double EPSILON = 1.0e-16;
                    
                    // Test around the transition point of 0.25
                    assertEquals(Math.sinh(0.24), FastMath.sinh(0.24), EPSILON);
                    assertEquals(Math.sinh(0.25), FastMath.sinh(0.25), EPSILON);
                    assertEquals(Math.sinh(0.26), FastMath.sinh(0.26), EPSILON);
                    
                    // Test around the transition points of ±20
                    assertEquals(Math.sinh(19.9), FastMath.sinh(19.9), EPSILON);
                    assertEquals(Math.sinh(20.0), FastMath.sinh(20.0), EPSILON);
                    assertEquals(Math.sinh(20.1), FastMath.sinh(20.1), EPSILON);
                    assertEquals(Math.sinh(-19.9), FastMath.sinh(-19.9), EPSILON);
                    assertEquals(Math.sinh(-20.0), FastMath.sinh(-20.0), EPSILON);
                    assertEquals(Math.sinh(-20.1), FastMath.sinh(-20.1), EPSILON);
                }

    @Test
                public void testSinhExtremeValues() {
                    final double EPSILON = 0.0;
                    
                    // Very large values
                    assertEquals(Double.POSITIVE_INFINITY, FastMath.sinh(Double.MAX_VALUE), EPSILON);
                    assertEquals(Double.NEGATIVE_INFINITY, FastMath.sinh(-Double.MAX_VALUE), EPSILON);
                    
                    // Very small values (but not zero)
                    assertEquals(1e-300, FastMath.sinh(1e-300), 1e-315);
                    assertEquals(-1e-300, FastMath.sinh(-1e-300), 1e-315);
                }

    @Test
                public void testSinhProperties() {
                    final double EPSILON = 1e-15;
                    
                    // Test odd function property: sinh(-x) = -sinh(x)
                    for (double x = 0.1; x < 100; x += 0.5) {
                        assertEquals(-FastMath.sinh(x), FastMath.sinh(-x), EPSILON);
                    }
                    
                    // Test approximation near zero: sinh(x) ≈ x for small x
                    for (double x = 1e-10; x < 1e-5; x *= 10) {
                        assertEquals(x, FastMath.sinh(x), x * 1e-15);
                    }
                }

    @Test
            public void testSinhLargePositiveValues() {
                final double EPSILON = 1.0e-16;
                
                // Values > 20
                assertEquals(0.5 * Math.exp(21), FastMath.sinh(21), EPSILON);
                assertEquals(0.5 * Math.exp(25), FastMath.sinh(25), EPSILON);
                
                // Values >= LOG_MAX_VALUE (avoid overflow case)
                double LOG_MAX_VALUE;
                try {
                    java.lang.reflect.Field field = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                    field.setAccessible(true);
                    LOG_MAX_VALUE = field.getDouble(null);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
                
                double t = Math.exp(0.5 * LOG_MAX_VALUE);
                double expected = (0.5 * t) * t;
                assertEquals(expected, FastMath.sinh(LOG_MAX_VALUE), EPSILON);
                assertEquals(expected, FastMath.sinh(LOG_MAX_VALUE + 1), EPSILON);
            }

    @Test
        public void testSinhLargeNegativeValues() throws Exception {
            // Define EPSILON constant
            final double EPSILON = 1e-15;
            
            // Get private LOG_MAX_VALUE field using reflection
            Field logMaxField = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
            logMaxField.setAccessible(true);
            double LOG_MAX_VALUE = logMaxField.getDouble(null);
        
            // Values < -20
            assertEquals(-0.5 * Math.exp(21), FastMath.sinh(-21), EPSILON);
            assertEquals(-0.5 * Math.exp(25), FastMath.sinh(-25), EPSILON);
            
            // Values <= -LOG_MAX_VALUE (avoid overflow case)
            double t = Math.exp(-0.5 * LOG_MAX_VALUE);
            double expected = (-0.5 * t) * t;
            assertEquals(expected, FastMath.sinh(-LOG_MAX_VALUE), EPSILON);
            assertEquals(expected, FastMath.sinh(-LOG_MAX_VALUE - 1), EPSILON);
        }


}
