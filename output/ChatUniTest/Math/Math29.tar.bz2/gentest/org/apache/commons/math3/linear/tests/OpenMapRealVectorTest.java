package gentest.org.apache.commons.math3.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.linear.*;
import java.io.Serializable;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.util.OpenIntToDoubleHashMap;
import org.apache.commons.math3.util.OpenIntToDoubleHashMap.Iterator;
import org.apache.commons.math3.util.FastMath;
 
public class OpenMapRealVectorTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testEbeDivideWithSameDimensionVectors() {
            OpenMapRealVector v1 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
            OpenMapRealVector v2 = new OpenMapRealVector(new double[]{2.0, 4.0, 6.0});
            
            RealVector result = v1.ebeDivide(v2);
            
            assertEquals(3, result.getDimension());
            assertEquals(0.5, result.getEntry(0), 1e-15);
            assertEquals(0.5, result.getEntry(1), 1e-15);
            assertEquals(0.5, result.getEntry(2), 1e-15);
        }

    @Test
        public void testEbeDivideWithZeroElements() {
            OpenMapRealVector v1 = new OpenMapRealVector(new double[]{0.0, 0.0, 0.0});
            OpenMapRealVector v2 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
            
            RealVector result = v1.ebeDivide(v2);
            
            assertEquals(3, result.getDimension());
            assertEquals(0.0, result.getEntry(0), 1e-15);
            assertEquals(0.0, result.getEntry(1), 1e-15);
            assertEquals(0.0, result.getEntry(2), 1e-15);
        }

    @Test
        public void testEbeDivideWithBothZeroElements() {
            OpenMapRealVector v1 = new OpenMapRealVector(new double[]{0.0, 0.0, 0.0});
            OpenMapRealVector v2 = new OpenMapRealVector(new double[]{0.0, 0.0, 0.0});
            
            RealVector result = v1.ebeDivide(v2);
            
            assertEquals(3, result.getDimension());
            assertTrue(Double.isNaN(result.getEntry(0)));
            assertTrue(Double.isNaN(result.getEntry(1)));
            assertTrue(Double.isNaN(result.getEntry(2)));
        }

    @Test
        public void testEbeDivideWithDifferentVectorImplementation() {
            OpenMapRealVector v1 = new OpenMapRealVector(new double[]{4.0, 9.0, 16.0});
            RealVector v2 = new ArrayRealVector(new double[]{2.0, 3.0, 4.0});
            
            RealVector result = v1.ebeDivide(v2);
            
            assertEquals(3, result.getDimension());
            assertEquals(2.0, result.getEntry(0), 1e-15);
            assertEquals(3.0, result.getEntry(1), 1e-15);
            assertEquals(4.0, result.getEntry(2), 1e-15);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testEbeDivideWithDifferentDimensions() {
            OpenMapRealVector v1 = new OpenMapRealVector(new double[]{1.0, 2.0});
            OpenMapRealVector v2 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
            
            v1.ebeDivide(v2);
        }

    @Test
        public void testEbeDivideWithInfinityValues() {
            OpenMapRealVector v1 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
            OpenMapRealVector v2 = new OpenMapRealVector(new double[]{0.0, 0.0, 0.0});
            v2.setEntry(0, Double.POSITIVE_INFINITY);
            v2.setEntry(1, Double.NEGATIVE_INFINITY);
            v2.setEntry(2, 1.0);
            
            RealVector result = v1.ebeDivide(v2);
            
            assertEquals(3, result.getDimension());
            assertEquals(0.0, result.getEntry(0), 1e-15);
            assertEquals(0.0, result.getEntry(1), 1e-15);
            assertEquals(3.0, result.getEntry(2), 1e-15);
        }

    @Test
        public void testEbeDivideWithNaNValues() {
            OpenMapRealVector v1 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
            OpenMapRealVector v2 = new OpenMapRealVector(new double[]{Double.NaN, Double.NaN, 1.0});
            
            RealVector result = v1.ebeDivide(v2);
            
            assertEquals(3, result.getDimension());
            assertTrue(Double.isNaN(result.getEntry(0)));
            assertTrue(Double.isNaN(result.getEntry(1)));
            assertEquals(3.0, result.getEntry(2), 1e-15);
        }

    @Test
        public void testEbeDivideWithMixedValues() {
            OpenMapRealVector v1 = new OpenMapRealVector(new double[]{1.0, 0.0, 3.0});
            OpenMapRealVector v2 = new OpenMapRealVector(new double[]{2.0, 0.0, 0.0});
            
            RealVector result = v1.ebeDivide(v2);
            
            assertEquals(3, result.getDimension());
            assertEquals(0.5, result.getEntry(0), 1e-15);
            assertTrue(Double.isNaN(result.getEntry(1)));
            assertTrue(Double.isInfinite(result.getEntry(2)));
        }

    @Test
        public void testEbeMultiplyWithRegularVector() {
            OpenMapRealVector v1 = new OpenMapRealVector(new double[]{1.0, 2.0, 0.0, 4.0});
            RealVector v2 = new ArrayRealVector(new double[]{2.0, 3.0, 5.0, 0.5});
            
            RealVector result = v1.ebeMultiply(v2);
            
            assertEquals(4, result.getDimension());
            assertEquals(2.0, result.getEntry(0), 0.0);
            assertEquals(6.0, result.getEntry(1), 0.0);
            assertEquals(0.0, result.getEntry(2), 0.0);
            assertEquals(2.0, result.getEntry(3), 0.0);
        }

    @Test
        public void testEbeMultiplyWithZeroVector() {
            OpenMapRealVector v1 = new OpenMapRealVector(new double[]{0.0, 0.0, 0.0});
            RealVector v2 = new ArrayRealVector(new double[]{1.0, 2.0, 3.0});
            
            RealVector result = v1.ebeMultiply(v2);
            
            assertEquals(3, result.getDimension());
            assertEquals(0.0, result.getEntry(0), 0.0);
            assertEquals(0.0, result.getEntry(1), 0.0);
            assertEquals(0.0, result.getEntry(2), 0.0);
        }

    @Test
        public void testEbeMultiplyWithNaNVector() {
            OpenMapRealVector v1 = new OpenMapRealVector(new double[]{1.0, 0.0, 2.0});
            RealVector v2 = mock(RealVector.class);
            when(v2.getDimension()).thenReturn(3);
            when(v2.isNaN()).thenReturn(true);
            when(v2.getEntry(0)).thenReturn(Double.NaN);
            when(v2.getEntry(1)).thenReturn(Double.NaN);
            when(v2.getEntry(2)).thenReturn(3.0);
            
            RealVector result = v1.ebeMultiply(v2);
            
            assertEquals(3, result.getDimension());
            assertTrue(Double.isNaN(result.getEntry(0)));
            assertTrue(Double.isNaN(result.getEntry(1)));
            assertEquals(6.0, result.getEntry(2), 0.0);
        }

    @Test
        public void testEbeMultiplyWithInfiniteVector() {
            OpenMapRealVector v1 = new OpenMapRealVector(new double[]{1.0, 0.0, -2.0});
            RealVector v2 = mock(RealVector.class);
            when(v2.getDimension()).thenReturn(3);
            when(v2.isInfinite()).thenReturn(true);
            when(v2.getEntry(0)).thenReturn(Double.POSITIVE_INFINITY);
            when(v2.getEntry(1)).thenReturn(Double.POSITIVE_INFINITY);
            when(v2.getEntry(2)).thenReturn(Double.NEGATIVE_INFINITY);
            
            RealVector result = v1.ebeMultiply(v2);
            
            assertEquals(3, result.getDimension());
            assertEquals(Double.POSITIVE_INFINITY, result.getEntry(0), 0.0);
            assertEquals(0.0, result.getEntry(1), 0.0); // 0 * Infinity = 0
            assertEquals(Double.POSITIVE_INFINITY, result.getEntry(2), 0.0);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testEbeMultiplyWithDifferentDimensions() {
            OpenMapRealVector v1 = new OpenMapRealVector(new double[]{1.0, 2.0});
            RealVector v2 = new ArrayRealVector(new double[]{1.0});
            
            v1.ebeMultiply(v2);
        }

    @Test
        public void testEbeMultiplyWithMixedSpecialCases() {
            OpenMapRealVector v1 = new OpenMapRealVector(new double[]{0.0, 1.0, -1.0, 2.0});
            RealVector v2 = mock(RealVector.class);
            when(v2.getDimension()).thenReturn(4);
            when(v2.isNaN()).thenReturn(false);
            when(v2.isInfinite()).thenReturn(true);
            when(v2.getEntry(0)).thenReturn(Double.NaN);
            when(v2.getEntry(1)).thenReturn(Double.POSITIVE_INFINITY);
            when(v2.getEntry(2)).thenReturn(Double.NEGATIVE_INFINITY);
            when(v2.getEntry(3)).thenReturn(3.0);
            
            RealVector result = v1.ebeMultiply(v2);
            
            assertEquals(4, result.getDimension());
            assertTrue(Double.isNaN(result.getEntry(0))); // NaN takes precedence
            assertEquals(Double.POSITIVE_INFINITY, result.getEntry(1), 0.0);
            assertEquals(Double.POSITIVE_INFINITY, result.getEntry(2), 0.0);
            assertEquals(6.0, result.getEntry(3), 0.0);
        }

    @Test
        public void testEbeMultiplyWithSparseVector() {
            OpenMapRealVector v1 = new OpenMapRealVector(5);
            v1.setEntry(1, 2.0);
            v1.setEntry(3, 3.0);
            
            RealVector v2 = new ArrayRealVector(new double[]{1.0, 2.0, 3.0, 4.0, 5.0});
            
            RealVector result = v1.ebeMultiply(v2);
            
            assertEquals(5, result.getDimension());
            assertEquals(0.0, result.getEntry(0), 0.0);
            assertEquals(4.0, result.getEntry(1), 0.0);
            assertEquals(0.0, result.getEntry(2), 0.0);
            assertEquals(12.0, result.getEntry(3), 0.0);
            assertEquals(0.0, result.getEntry(4), 0.0);
        }

}
