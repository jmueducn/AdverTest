package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.io.Serializable;
import java.math.BigDecimal;
 
public class BigMatrixImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                public void testOperateWithSingleElementMatrix() {
                    BigDecimal[][] singleData = {{new BigDecimal("5")}};
                    BigMatrixImpl singleMatrix = new BigMatrixImpl(singleData);
                    
                    BigDecimal[] vector = {new BigDecimal("2")};
                    BigDecimal[] expected = {new BigDecimal("10")};
                    
                    BigDecimal[] result = singleMatrix.operate(vector);
                    assertArrayEquals(expected, result);
                }

    @Test
                public void testOperateWithDecimalValues() {
                    BigDecimal[][] decimalData = {
                        {new BigDecimal("1.5"), new BigDecimal("2.5")},
                        {new BigDecimal("3.5"), new BigDecimal("4.5")}
                    };
                    BigMatrixImpl decimalMatrix = new BigMatrixImpl(decimalData);
                    
                    BigDecimal[] vector = {
                        new BigDecimal("1.1"), 
                        new BigDecimal("2.2")
                    };
                    
                    BigDecimal[] expected = {
                        new BigDecimal("1.5").multiply(new BigDecimal("1.1"))
                            .add(new BigDecimal("2.5").multiply(new BigDecimal("2.2"))),
                        new BigDecimal("3.5").multiply(new BigDecimal("1.1"))
                            .add(new BigDecimal("4.5").multiply(new BigDecimal("2.2")))
                    };
                    
                    BigDecimal[] result = decimalMatrix.operate(vector);
                    assertArrayEquals(expected, result);
                }

    @Test
                public void testOperateWithEmptyDoubleArray() {
                    // Create a matrix with 0 columns
                    BigMatrixImpl emptyMatrix = new BigMatrixImpl(new BigDecimal[3][0]);
                    double[] v = {};
                    BigDecimal[] result = emptyMatrix.operate(v);
                    assertEquals(3, result.length);
                }

    @Test
            public void testOperateWithValidVector() {
                // Create test matrix data
                BigDecimal[][] data = {
                    {new BigDecimal("1"), new BigDecimal("2"), new BigDecimal("3")},
                    {new BigDecimal("4"), new BigDecimal("5"), new BigDecimal("6")},
                    {new BigDecimal("7"), new BigDecimal("8"), new BigDecimal("9")}
                };
                
                // Create test matrix instance (assuming constructor takes 2D array)
                BigMatrixImpl matrix = new BigMatrixImpl(data);
                
                BigDecimal[] vector = {
                    new BigDecimal("1"),
                    new BigDecimal("2"), 
                    new BigDecimal("3")
                };
                
                BigDecimal[] expected = {
                    new BigDecimal("14"),  // 1*1 + 2*2 + 3*3 = 14
                    new BigDecimal("32"),  // 4*1 + 5*2 + 6*3 = 32
                    new BigDecimal("50")   // 7*1 + 8*2 + 9*3 = 50
                };
                
                BigDecimal[] result = matrix.operate(vector);
                assertArrayEquals(expected, result);
            }

    @Test
            public void testOperateWithZeroVector() {
                // Create a test matrix
                BigDecimal[][] data = {
                    {BigDecimal.ONE, BigDecimal.ZERO, BigDecimal.ZERO},
                    {BigDecimal.ZERO, BigDecimal.ONE, BigDecimal.ZERO},
                    {BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ONE}
                };
                BigMatrixImpl matrix = new BigMatrixImpl(data);
                
                BigDecimal[] vector = {
                    BigDecimal.ZERO,
                    BigDecimal.ZERO, 
                    BigDecimal.ZERO
                };
                
                BigDecimal[] expected = {
                    BigDecimal.ZERO,
                    BigDecimal.ZERO,
                    BigDecimal.ZERO
                };
                
                BigDecimal[] result = matrix.operate(vector);
                assertArrayEquals(expected, result);
            }

    @Test
            public void testOperateWithNegativeValues() {
                BigDecimal[][] data = {
                    {new BigDecimal("1"), new BigDecimal("2"), new BigDecimal("3")},
                    {new BigDecimal("4"), new BigDecimal("5"), new BigDecimal("6")},
                    {new BigDecimal("7"), new BigDecimal("8"), new BigDecimal("9")}
                };
                BigMatrixImpl matrix = new BigMatrixImpl(data);
                
                BigDecimal[] vector = {
                    new BigDecimal("-1"),
                    new BigDecimal("-2"), 
                    new BigDecimal("-3")
                };
                
                BigDecimal[] expected = {
                    new BigDecimal("-14"),  // 1*-1 + 2*-2 + 3*-3 = -14
                    new BigDecimal("-32"),  // 4*-1 + 5*-2 + 6*-3 = -32
                    new BigDecimal("-50")    // 7*-1 + 8*-2 + 9*-3 = -50
                };
                
                BigDecimal[] result = matrix.operate(vector);
                assertArrayEquals(expected, result);
            }

    @Test(expected = IllegalArgumentException.class)
            public void testOperateWithWrongLengthVector() {
                BigDecimal[][] data = {
                    {new BigDecimal("1"), new BigDecimal("2"), new BigDecimal("3")},
                    {new BigDecimal("4"), new BigDecimal("5"), new BigDecimal("6")}
                };
                BigMatrixImpl matrix = new BigMatrixImpl(data);
                
                BigDecimal[] vector = {
                    new BigDecimal("1"),
                    new BigDecimal("2")  // Only 2 elements instead of 3
                };
                matrix.operate(vector);
            }

    @Test
            public void testOperateWithValidDoubleArray() {
                // Create test matrix data
                BigDecimal[][] data = {
                    {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                    {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")},
                    {new BigDecimal("7.0"), new BigDecimal("8.0"), new BigDecimal("9.0")}
                };
                BigMatrixImpl matrix = new BigMatrixImpl(data);
                
                double[] v = {1.0, 2.0, 3.0};
                BigDecimal[] result = matrix.operate(v);
                
                // Expected results calculated manually:
                // [1*1 + 2*2 + 3*3, 4*1 + 5*2 + 6*3, 7*1 + 8*2 + 9*3]
                BigDecimal[] expected = {
                    new BigDecimal("14.0"),
                    new BigDecimal("32.0"),
                    new BigDecimal("50.0")
                };
                
                assertEquals(expected.length, result.length);
                for (int i = 0; i < expected.length; i++) {
                    assertEquals(expected[i].doubleValue(), result[i].doubleValue(), 0.0001);
                }
            }

    @Test(expected = IllegalArgumentException.class)
            public void testOperateWithInvalidLengthDoubleArray() {
                BigMatrixImpl matrix = new BigMatrixImpl(new double[][]{{1.0, 2.0}, {3.0, 4.0}});
                double[] v = {1.0}; // Too short
                matrix.operate(v);
            }

    @Test
            public void testOperateWithZeroValues() {
                BigMatrixImpl matrix = new BigMatrixImpl(new BigDecimal[][] {
                    {BigDecimal.ONE, BigDecimal.ZERO, BigDecimal.ZERO},
                    {BigDecimal.ZERO, BigDecimal.ONE, BigDecimal.ZERO},
                    {BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ONE}
                });
                
                double[] v = {0.0, 0.0, 0.0};
                BigDecimal[] result = matrix.operate(v);
                
                BigDecimal[] expected = {
                    BigDecimal.ZERO,
                    BigDecimal.ZERO,
                    BigDecimal.ZERO
                };
                
                assertEquals(expected.length, result.length);
                for (int i = 0; i < expected.length; i++) {
                    assertEquals(0, expected[i].compareTo(result[i]));
                }
            }

    @Test
            public void testOperateWithNegativeValues1() {
                // Create test matrix
                BigDecimal[][] data = {
                    {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                    {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")},
                    {new BigDecimal("7.0"), new BigDecimal("8.0"), new BigDecimal("9.0")}
                };
                BigMatrixImpl matrix = new BigMatrixImpl(data);
                
                double[] v = {-1.0, -2.0, -3.0};
                BigDecimal[] result = matrix.operate(v);
                
                // Expected results calculated manually:
                BigDecimal[] expected = {
                    new BigDecimal("-14.0"),
                    new BigDecimal("-32.0"),
                    new BigDecimal("-50.0")
                };
                
                assertEquals(expected.length, result.length);
                for (int i = 0; i < expected.length; i++) {
                    assertEquals(expected[i].doubleValue(), result[i].doubleValue(), 0.0001);
                }
            }

    @Test
            public void testOperateWithDecimalValues1() {
                // Create test matrix
                BigDecimal[][] data = {
                    {new BigDecimal(1), new BigDecimal(2), new BigDecimal(3)},
                    {new BigDecimal(4), new BigDecimal(5), new BigDecimal(6)},
                    {new BigDecimal(7), new BigDecimal(8), new BigDecimal(9)}
                };
                BigMatrixImpl matrix = new BigMatrixImpl(data);
                
                double[] v = {1.5, 2.5, 3.5};
                BigDecimal[] result = matrix.operate(v);
                
                // Expected results calculated manually:
                BigDecimal[] expected = {
                    new BigDecimal("17.0"),   // 1*1.5 + 2*2.5 + 3*3.5 = 1.5 + 5.0 + 10.5 = 17.0
                    new BigDecimal("39.5"),    // 4*1.5 + 5*2.5 + 6*3.5 = 6.0 + 12.5 + 21.0 = 39.5
                    new BigDecimal("62.0")     // 7*1.5 + 8*2.5 + 9*3.5 = 10.5 + 20.0 + 31.5 = 62.0
                };
                
                assertEquals(expected.length, result.length);
                for (int i = 0; i < expected.length; i++) {
                    assertEquals(expected[i].doubleValue(), result[i].doubleValue(), 0.0001);
                }
            }

    @Test
            public void testOperateWithLargeValues() {
                BigMatrixImpl matrix = new BigMatrixImpl(new double[][] {
                    {1, 2, 3},
                    {4, 5, 6},
                    {7, 8, 9}
                });
                
                double[] v = {1e10, 2e10, 3e10};
                BigDecimal[] result = matrix.operate(v);
                
                // Expected results calculated manually:
                BigDecimal[] expected = {
                    new BigDecimal("1.4E11"),  // 1*1e10 + 2*2e10 + 3*3e10 = 1e10 + 4e10 + 9e10 = 14e10
                    new BigDecimal("3.2E11"),  // 4*1e10 + 5*2e10 + 6*3e10 = 4e10 + 10e10 + 18e10 = 32e10
                    new BigDecimal("5.0E11")   // 7*1e10 + 8*2e10 + 9*3e10 = 7e10 + 16e10 + 27e10 = 50e10
                };
                
                assertEquals(expected.length, result.length);
                for (int i = 0; i < expected.length; i++) {
                    assertEquals(expected[i].doubleValue(), result[i].doubleValue(), 0.0001);
                }
            }

    @Test(expected = IllegalArgumentException.class)
        public void testOperateWithNullVector() {
            BigDecimal[][] data = new BigDecimal[][] {
                {new BigDecimal("1"), new BigDecimal("2")},
                {new BigDecimal("3"), new BigDecimal("4")}
            };
            BigMatrixImpl matrix = new BigMatrixImpl(data);
            BigDecimal[] vector = null;
            matrix.operate(vector);
        }


}
