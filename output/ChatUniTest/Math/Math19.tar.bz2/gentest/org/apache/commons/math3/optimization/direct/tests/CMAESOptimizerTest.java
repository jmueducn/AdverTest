package gentest.org.apache.commons.math3.optimization.direct.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.optimization.direct.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.math3.analysis.MultivariateFunction;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MathUnsupportedOperationException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.exception.OutOfRangeException;
import org.apache.commons.math3.exception.TooManyEvaluationsException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.EigenDecomposition;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.optimization.ConvergenceChecker;
import org.apache.commons.math3.optimization.GoalType;
import org.apache.commons.math3.optimization.MultivariateOptimizer;
import org.apache.commons.math3.optimization.PointValuePair;
import org.apache.commons.math3.optimization.SimpleValueChecker;
import org.apache.commons.math3.random.MersenneTwister;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.util.MathArrays;
 
public class CMAESOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
            public void testCheckParametersWithNoBounds() throws Exception {
                // Create mock optimizer
                CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                
                // Setup mock behavior
                when(optimizer.getStartPoint()).thenReturn(new double[]{1.0, 2.0});
                when(optimizer.getLowerBound()).thenReturn(new double[]{Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY});
                when(optimizer.getUpperBound()).thenReturn(new double[]{Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY});
                
                // Use reflection to access private method
                Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                checkParametersMethod.setAccessible(true);
                
                // Set inputSigma to null
                Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                inputSigmaField.setAccessible(true);
                inputSigmaField.set(optimizer, null);
                
                // Invoke the method
                checkParametersMethod.invoke(optimizer);
                
                // Verify boundaries is null
                Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                boundariesField.setAccessible(true);
                assertNull(boundariesField.get(optimizer));
            }

    @Test
            public void testCheckParametersWithAllFiniteBounds() throws Exception {
                // Create mock optimizer
                CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                
                // Setup reflection to access private method
                Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                checkParametersMethod.setAccessible(true);
                
                // Mock method calls
                when(optimizer.getStartPoint()).thenReturn(new double[]{1.0, 2.0});
                when(optimizer.getLowerBound()).thenReturn(new double[]{0.0, 1.0});
                when(optimizer.getUpperBound()).thenReturn(new double[]{2.0, 3.0});
                
                // Set inputSigma to null
                CMAESOptimizer.class.getDeclaredField("inputSigma").set(optimizer, null);
                
                // Invoke the method
                checkParametersMethod.invoke(optimizer);
                
                // Get boundaries field
                double[][] boundaries = (double[][]) CMAESOptimizer.class.getDeclaredField("boundaries").get(optimizer);
                
                // Assertions
                assertNotNull(boundaries);
                assertEquals(2, boundaries.length);
                assertArrayEquals(new double[]{0.0, 1.0}, boundaries[0], 0.0);
                assertArrayEquals(new double[]{2.0, 3.0}, boundaries[1], 0.0);
            }

    @Test
            public void testCheckParametersWithMixedFiniteAndInfiniteBounds() throws Exception {
                // Create mock optimizer
                CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                
                // Setup mock behavior
                when(optimizer.getStartPoint()).thenReturn(new double[]{1.0, 2.0});
                when(optimizer.getLowerBound()).thenReturn(new double[]{0.0, Double.NEGATIVE_INFINITY});
                when(optimizer.getUpperBound()).thenReturn(new double[]{2.0, Double.POSITIVE_INFINITY});
                
                // Use reflection to set private field
                Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                inputSigmaField.setAccessible(true);
                inputSigmaField.set(optimizer, null);
                
                // Get private method via reflection
                Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                checkParametersMethod.setAccessible(true);
                
                // Invoke the method
                checkParametersMethod.invoke(optimizer);
            }

    @Test
            public void testCheckParametersWithOverflowingBounds() throws Exception {
                // Setup mock
                CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                when(optimizer.getStartPoint()).thenReturn(new double[]{1.0});
                when(optimizer.getLowerBound()).thenReturn(new double[]{-Double.MAX_VALUE});
                when(optimizer.getUpperBound()).thenReturn(new double[]{Double.MAX_VALUE});
        
                // Use reflection to access private method
                Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                checkParametersMethod.setAccessible(true);
        
                // Set inputSigma to null
                CMAESOptimizer.class.getDeclaredField("inputSigma").set(optimizer, null);
                CMAESOptimizer.class.getDeclaredField("boundaries").set(optimizer, null);
        
                // Invoke the method
                checkParametersMethod.invoke(optimizer);
            }

    @Test(expected = NotPositiveException.class)
            public void testCheckParametersWithNegativeInputSigma() throws Exception {
                // Create mock optimizer
                CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                
                // Setup mock behavior
                when(optimizer.getStartPoint()).thenReturn(new double[]{1.0});
                when(optimizer.getLowerBound()).thenReturn(new double[]{Double.NEGATIVE_INFINITY});
                when(optimizer.getUpperBound()).thenReturn(new double[]{Double.POSITIVE_INFINITY});
                
                // Use reflection to set private field
                Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                inputSigmaField.setAccessible(true);
                inputSigmaField.set(optimizer, new double[]{-0.1});
                
                // Get and invoke private method
                Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                checkParametersMethod.setAccessible(true);
                checkParametersMethod.invoke(optimizer);
            }

    @Test
            public void testCheckParametersWithValidInputSigma() throws Exception {
                // Create mock optimizer
                CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                
                // Setup mock behavior
                when(optimizer.getStartPoint()).thenReturn(new double[]{1.0});
                when(optimizer.getLowerBound()).thenReturn(new double[]{0.0});
                when(optimizer.getUpperBound()).thenReturn(new double[]{2.0});
                
                // Use reflection to set private field
                Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                inputSigmaField.setAccessible(true);
                inputSigmaField.set(optimizer, new double[]{0.5}); // Valid sigma
                
                // Get private method via reflection
                Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                checkParametersMethod.setAccessible(true);
                
                // Invoke the method
                checkParametersMethod.invoke(optimizer);
                
                // Verify results
                Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                boundariesField.setAccessible(true);
                double[][][] boundaries = (double[][][]) boundariesField.get(optimizer);
                
                assertNotNull(boundaries);
                assertEquals(2, boundaries[0].length);
                assertArrayEquals(new double[]{0.0}, boundaries[0][0], 0.0);
                assertArrayEquals(new double[]{2.0}, boundaries[0][1], 0.0);
            }

    @Test(expected = Exception.class)
        public void testCheckParametersWithWrongInputSigmaDimension() throws Exception {
            // Setup mock
            CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
            
            // Use reflection to access private method
            Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
            checkParametersMethod.setAccessible(true);
            
            // Use reflection to access private field inputSigma
            Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
            inputSigmaField.setAccessible(true);
            
            // Mock return values
            when(optimizer.getStartPoint()).thenReturn(new double[]{1.0, 2.0});
            when(optimizer.getLowerBound()).thenReturn(new double[]{Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY});
            when(optimizer.getUpperBound()).thenReturn(new double[]{Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY});
            
            // Set wrong dimension inputSigma using reflection
            inputSigmaField.set(optimizer, new double[]{0.1}); // Wrong dimension
            
            // Invoke the method
            checkParametersMethod.invoke(optimizer);
        }

    @Test(expected = Exception.class)
        public void testCheckParametersWithInputSigmaExceedingBounds() throws Exception {
            // Create mock optimizer
            CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
            
            // Setup mock behavior
            when(optimizer.getStartPoint()).thenReturn(new double[]{1.0});
            when(optimizer.getLowerBound()).thenReturn(new double[]{0.0});
            when(optimizer.getUpperBound()).thenReturn(new double[]{1.0});
    
            // Use reflection to set private field
            Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
            inputSigmaField.setAccessible(true);
            inputSigmaField.set(optimizer, new double[]{2.0}); // Sigma exceeds bounds range
    
            // Use reflection to access private method
            Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
            checkParametersMethod.setAccessible(true);
            
            checkParametersMethod.invoke(optimizer);
        }


}
