package gentest.org.apache.commons.math.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.distribution.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.special.Erf;
 
public class NormalDistributionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test(expected = MaxIterationsExceededException.class)
                                            public void testCumulativeProbabilityThrowsException() throws MathException {
                                                double mean = 0.0;
                                                double standardDeviation = 1.0;
                                                NormalDistributionImpl distribution = new NormalDistributionImpl(mean, standardDeviation);
                                                
                                                mockStatic(Erf.class);
                                                when(Erf.erf(anyDouble()))
                                                       .thenThrow(new MaxIterationsExceededException(100));
                                        
                                                double x = mean + 10 * standardDeviation; // Within 20 SD range
                                                distribution.cumulativeProbability(x);
                                            }

    @Test
                                        public void testCumulativeProbabilityStandardCase() throws MathException {
                                            double mean = 5.0;
                                            double standardDeviation = 2.0;
                                            NormalDistributionImpl distribution = new NormalDistributionImpl(mean, standardDeviation);
                                            
                                            mockStatic(Erf.class);
                                            when(Erf.erf((10.0 - mean) / (standardDeviation * Math.sqrt(2.0))))
                                                   .thenReturn(0.999999998);
                                        
                                            double result = distribution.cumulativeProbability(10.0);
                                            assertEquals(0.999999999, result, 1e-9);
                                        }

    @Test
                                        public void testCumulativeProbabilityAtMean() throws Exception {
                                            double mean = 0.0;
                                            double standardDeviation = 1.0;
                                            NormalDistributionImpl distribution = new NormalDistributionImpl(mean, standardDeviation);
                                            
                                            mockStatic(Erf.class);
                                            when(Erf.erf(0.0)).thenReturn(0.0);
                                        
                                            double result = distribution.cumulativeProbability(mean);
                                            assertEquals(0.5, result, 0.0);
                                        }

    @Test
        public void testCumulativeProbabilityVeryLowX() throws MathException {
            when(Erf.erf(anyDouble()))
                   .thenThrow(new MaxIterationsExceededException(100));
            
            double mean = 0.0;
            double standardDeviation = 1.0;
            NormalDistributionImpl distribution = new NormalDistributionImpl(mean, standardDeviation);
            
            double x = mean - 21 * standardDeviation;
            double result = distribution.cumulativeProbability(x);
            assertEquals(0.0, result, 0.0);
        }

    @Test
        public void testCumulativeProbabilityVeryHighX() throws MathException {
            when(Erf.erf(anyDouble()))
                   .thenThrow(new MaxIterationsExceededException(100));
        
            double mean = 0.0;
            double standardDeviation = 1.0;
            NormalDistributionImpl distribution = new NormalDistributionImpl(mean, standardDeviation);
            
            double x = mean + 21 * standardDeviation;
            double result = distribution.cumulativeProbability(x);
            assertEquals(1.0, result, 0.0);
        }

    @Test
        public void testCumulativeProbabilityWithDefaultConstructor() throws Exception {
            NormalDistributionImpl defaultDist = new NormalDistributionImpl();
            when(Erf.erf(1.0 / Math.sqrt(2.0))).thenReturn(0.682689492);
            
            double result = defaultDist.cumulativeProbability(1.0);
            assertEquals(0.841344746, result, 1e-9);
        }


}
