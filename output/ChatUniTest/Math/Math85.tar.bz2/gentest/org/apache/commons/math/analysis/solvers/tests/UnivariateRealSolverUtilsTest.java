package gentest.org.apache.commons.math.analysis.solvers.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.analysis.solvers.*;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.ConvergenceException;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.analysis.UnivariateRealFunction;
 
public class UnivariateRealSolverUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test(expected = IllegalArgumentException.class)
                    public void testBracketNullFunction() throws FunctionEvaluationException, ConvergenceException {
                        UnivariateRealSolverUtils.bracket(null, 2.0, 0.0, 4.0);
                    }

    @Test
                public void testBracketSuccess() throws FunctionEvaluationException, ConvergenceException {
                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                    when(function.value(1.0)).thenReturn(-1.0);
                    when(function.value(3.0)).thenReturn(1.0);
                    
                    double[] result = UnivariateRealSolverUtils.bracket(function, 2.0, 0.0, 4.0);
                    assertArrayEquals(new double[]{1.0, 3.0}, result, 0.0001);
                }

    @Test(expected = IllegalArgumentException.class)
                public void testBracketInvalidInitial() throws FunctionEvaluationException, ConvergenceException {
                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                    UnivariateRealSolverUtils.bracket(function, 5.0, 0.0, 4.0);
                }

    @Test(expected = IllegalArgumentException.class)
                public void testBracketInvalidBounds() throws FunctionEvaluationException, ConvergenceException {
                    UnivariateRealFunction function = new UnivariateRealFunction() {
                        public double value(double x) throws FunctionEvaluationException {
                            return x;
                        }
                    };
                    UnivariateRealSolverUtils.bracket(function, 2.0, 0.0, 4.0);
                }

    @Test(expected = org.apache.commons.math.ConvergenceException.class)
                public void testBracketNoSolution() throws Exception {
                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                    when(function.value(anyDouble())).thenReturn(1.0);
                    UnivariateRealSolverUtils.bracket(function, 2.0, 0.0, 4.0);
                }

    @Test
                public void testBracketAtLowerBound() throws Exception {
                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                    when(function.value(0.0)).thenReturn(-1.0);
                    when(function.value(2.0)).thenReturn(1.0);
                    
                    double[] result = UnivariateRealSolverUtils.bracket(function, 1.0, 0.0, 4.0);
                    assertArrayEquals(new double[]{0.0, 2.0}, result, 0.0001);
                }

    @Test
                public void testBracketAtUpperBound() throws FunctionEvaluationException, ConvergenceException {
                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                    when(function.value(2.0)).thenReturn(-1.0);
                    when(function.value(4.0)).thenReturn(1.0);
            
                    double[] result = UnivariateRealSolverUtils.bracket(function, 3.0, 0.0, 4.0);
                    assertArrayEquals(new double[]{2.0, 4.0}, result, 0.0001);
                }

    @Test
                public void testBracketWithSingleStep() throws Exception {
                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                    when(function.value(1.0)).thenReturn(-1.0);
                    when(function.value(3.0)).thenReturn(1.0);
                    
                    double[] result = UnivariateRealSolverUtils.bracket(function, 2.0, 0.0, 4.0);
                    assertArrayEquals(new double[]{1.0, 3.0}, result, 0.0001);
                }

    @Test(expected = org.apache.commons.math.ConvergenceException.class)
                public void testBracketReachesMaxIterations() throws Exception {
                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                    when(function.value(anyDouble())).thenReturn(1.0);
                    UnivariateRealSolverUtils.bracket(function, 2.0, 0.0, 4.0, 1);
                }

    @Test
                public void testBracket_ReachesMaxIterations() throws Exception {
                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                    when(function.value(anyDouble())).thenReturn(1.0);
                    
                    try {
                        UnivariateRealSolverUtils.bracket(function, 1.0, 0.0, 2.0, 1);
                        fail("Expected ConvergenceException");
                    } catch (ConvergenceException e) {
                        assertTrue(e.getMessage().contains("number of iterations=1"));
                    }
                }

    @Test(expected = IllegalArgumentException.class)
            public void testBracket_NullFunction() throws Exception {
                try {
                    UnivariateRealSolverUtils.bracket(null, 1.0, 0.0, 2.0, 100);
                } catch (ConvergenceException e) {
                    // This catch block is added to handle the possible ConvergenceException
                    throw e;
                }
            }

    @Test(expected = ConvergenceException.class)
            public void testBracket_InvalidMaxIterations() throws Exception {
                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                when(function.value(anyDouble())).thenReturn(1.0);
                try {
                    UnivariateRealSolverUtils.bracket(function, 1.0, 0.0, 2.0, 0);
                } catch (ConvergenceException e) {
                    throw e;
                }
            }

    @Test(expected = ConvergenceException.class)
            public void testBracket_InitialBelowLowerBound() throws FunctionEvaluationException, ConvergenceException {
                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                when(function.value(anyDouble())).thenReturn(1.0);
                UnivariateRealSolverUtils.bracket(function, -1.0, 0.0, 2.0, 100);
            }

    @Test(expected = ConvergenceException.class)
            public void testBracket_InvalidBounds() throws FunctionEvaluationException, ConvergenceException {
                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                when(function.value(anyDouble())).thenReturn(1.0);
                UnivariateRealSolverUtils.bracket(function, 1.0, 2.0, 0.0, 100);
            }

    @Test
            public void testBracket_SuccessFirstTry() throws FunctionEvaluationException, ConvergenceException {
                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                when(function.value(0.0)).thenReturn(-1.0);
                when(function.value(2.0)).thenReturn(1.0);
                
                double[] result = UnivariateRealSolverUtils.bracket(function, 1.0, 0.0, 2.0, 100);
                assertArrayEquals(new double[]{0.0, 2.0}, result, 0.0001);
            }

    @Test
            public void testBracket_SuccessAfterExpanding() throws FunctionEvaluationException, ConvergenceException {
                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                when(function.value(0.0)).thenReturn(1.0);
                when(function.value(1.0)).thenReturn(1.0);
                when(function.value(2.0)).thenReturn(1.0);
                when(function.value(-1.0)).thenReturn(-1.0);
                when(function.value(3.0)).thenReturn(1.0);
                
                double[] result = UnivariateRealSolverUtils.bracket(function, 1.0, -2.0, 4.0, 100);
                assertArrayEquals(new double[]{-1.0, 3.0}, result, 0.0001);
            }

    @Test(expected = ConvergenceException.class)
            public void testBracket_NoBracketFound() throws FunctionEvaluationException, ConvergenceException {
                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                when(function.value(anyDouble())).thenReturn(1.0);
                UnivariateRealSolverUtils.bracket(function, 1.0, 0.0, 2.0, 1);
            }

    @Test
            public void testBracket_HitsLowerBound() throws FunctionEvaluationException {
                try {
                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                    when(function.value(0.0)).thenReturn(-1.0);
                    when(function.value(1.0)).thenReturn(1.0);
                    when(function.value(2.0)).thenReturn(1.0);
                    
                    double[] result = UnivariateRealSolverUtils.bracket(function, 1.0, 0.0, 2.0, 100);
                    assertArrayEquals(new double[]{0.0, 2.0}, result, 0.0001);
                } catch (ConvergenceException e) {
                    fail("ConvergenceException should not be thrown in this test case");
                }
            }

    @Test
            public void testBracket_HitsUpperBound() throws FunctionEvaluationException {
                try {
                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                    when(function.value(0.0)).thenReturn(1.0);
                    when(function.value(1.0)).thenReturn(1.0);
                    when(function.value(2.0)).thenReturn(-1.0);
                    
                    double[] result = UnivariateRealSolverUtils.bracket(function, 1.0, 0.0, 2.0, 100);
                    assertArrayEquals(new double[]{0.0, 2.0}, result, 0.0001);
                } catch (ConvergenceException e) {
                    fail("ConvergenceException should not be thrown in this test case");
                }
            }

    @Test
        public void testBracket_InitialAboveUpperBound() {
            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
            try {
                when(function.value(anyDouble())).thenReturn(1.0);
            } catch (FunctionEvaluationException e) {
                throw new RuntimeException(e);
            }
            try {
                UnivariateRealSolverUtils.bracket(function, 3.0, 0.0, 2.0, 100);
            } catch (ConvergenceException e) {
                // Expected exception
            } catch (FunctionEvaluationException e) {
                // Not expected
                throw new RuntimeException(e);
            }
        }


}
