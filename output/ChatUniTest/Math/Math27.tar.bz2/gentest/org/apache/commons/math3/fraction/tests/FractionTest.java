package gentest.org.apache.commons.math3.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.fraction.*;
import java.io.Serializable;
import java.math.BigInteger;
import org.apache.commons.math3.FieldElement;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.util.ArithmeticUtils;
import org.apache.commons.math3.util.FastMath;
 
public class FractionTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testPercentageValueWithWholeNumber() {
            Fraction fraction = new Fraction(1, 1);
            assertEquals(100.0, fraction.percentageValue(), 0.0001);
        }

    @Test
        public void testPercentageValueWithHalf() {
            Fraction fraction = new Fraction(1, 2);
            assertEquals(50.0, fraction.percentageValue(), 0.0001);
        }

    @Test
        public void testPercentageValueWithQuarter() {
            Fraction fraction = new Fraction(1, 4);
            assertEquals(25.0, fraction.percentageValue(), 0.0001);
        }

    @Test
        public void testPercentageValueWithThird() {
            Fraction fraction = new Fraction(1, 3);
            assertEquals(100.0 / 3, fraction.percentageValue(), 0.0001);
        }

    @Test
        public void testPercentageValueWithZero() {
            Fraction fraction = new Fraction(0, 1);
            assertEquals(0.0, fraction.percentageValue(), 0.0001);
        }

    @Test
        public void testPercentageValueWithNegativeFraction() {
            Fraction fraction = new Fraction(-1, 2);
            assertEquals(-50.0, fraction.percentageValue(), 0.0001);
        }

    @Test
        public void testPercentageValueWithPredefinedFraction() {
            assertEquals(50.0, Fraction.ONE_HALF.percentageValue(), 0.0001);
            assertEquals(25.0, Fraction.ONE_QUARTER.percentageValue(), 0.0001);
            assertEquals(33.333333, Fraction.ONE_THIRD.percentageValue(), 0.0001);
        }

    @Test
        public void testPercentageValueWithLargeDenominator() {
            Fraction fraction = new Fraction(1, 1000);
            assertEquals(0.1, fraction.percentageValue(), 0.0001);
        }

    @Test
        public void testPercentageValueWithLargeNumerator() {
            Fraction fraction = new Fraction(1000, 1);
            assertEquals(100000.0, fraction.percentageValue(), 0.0001);
        }

    @Test
        public void testPercentageValueWithNonReducedFraction() {
            Fraction fraction = new Fraction(2, 4);
            assertEquals(50.0, fraction.percentageValue(), 0.0001);
        }

}
