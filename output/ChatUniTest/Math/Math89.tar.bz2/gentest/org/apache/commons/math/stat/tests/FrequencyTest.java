package gentest.org.apache.commons.math.stat.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.*;
import java.io.Serializable;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.Comparator;
import java.util.TreeMap;
 
public class FrequencyTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                        public void testAddValueIntWithComparator() {
                                                                                                                                                                            Frequency freqWithComparator = new Frequency((o1, o2) -> {
                                                                                                                                                                                Long l1 = (Long) o1;
                                                                                                                                                                                Long l2 = (Long) o2;
                                                                                                                                                                                return l1.compareTo(l2);
                                                                                                                                                                            });
                                                                                                                                                                            
                                                                                                                                                                            freqWithComparator.addValue(5);
                                                                                                                                                                            assertEquals(1, freqWithComparator.getCount(5));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testAddValueLongWithComparator() {
                                                                                                                                                                            Frequency freqWithComparator = new Frequency((o1, o2) -> 0); // All elements considered equal
                                                                                                                                                                            freqWithComparator.addValue(5L);
                                                                                                                                                                            assertEquals(1L, freqWithComparator.getCount(5L));
                                                                                                                                                                    
                                                                                                                                                                            // All values will be considered equal due to comparator
                                                                                                                                                                            freqWithComparator.addValue(10L);
                                                                                                                                                                            assertEquals(2L, freqWithComparator.getCount(5L));
                                                                                                                                                                            assertEquals(2L, freqWithComparator.getCount(10L));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                    public void testAddValueWithComparableObject() {
                                                                                                                                                                        Frequency frequency = new Frequency();
                                                                                                                                                                        Comparable<String> comparableString = "test";
                                                                                                                                                                        frequency.addValue(comparableString);
                                                                                                                                                                        assertEquals(1, frequency.getCount(comparableString));
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testAddValueWithIntegerObject() {
                                                                                                                                                                        Frequency frequency = new Frequency();
                                                                                                                                                                        Integer integerValue = 5;
                                                                                                                                                                        frequency.addValue(integerValue);
                                                                                                                                                                        assertEquals(1, frequency.getCount(integerValue));
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testAddValueWithLongObject() {
                                                                                                                                                                        Frequency frequency = new Frequency();
                                                                                                                                                                        Long longValue = 10L;
                                                                                                                                                                        frequency.addValue(longValue);
                                                                                                                                                                        assertEquals(1, frequency.getCount(longValue));
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testAddValueWithCharacterObject() {
                                                                                                                                                                        Frequency frequency = new Frequency();
                                                                                                                                                                        Character charValue = 'a';
                                                                                                                                                                        frequency.addValue(charValue);
                                                                                                                                                                        assertEquals(1, frequency.getCount(charValue));
                                                                                                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                    public void testAddValueWithNonComparableObject() {
                                                                                                                                                                        Frequency frequency = new Frequency();
                                                                                                                                                                        Object nonComparable = new Object();
                                                                                                                                                                        frequency.addValue(nonComparable);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testAddValueWithNull() {
                                                                                                                                                                        Frequency frequency = new Frequency();
                                                                                                                                                                        try {
                                                                                                                                                                            frequency.addValue(null);
                                                                                                                                                                            fail("Expected IllegalArgumentException");
                                                                                                                                                                        } catch (IllegalArgumentException e) {
                                                                                                                                                                            assertEquals("Object must implement Comparable", e.getMessage());
                                                                                                                                                                        }
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testAddValueWithMultipleComparableObjects() {
                                                                                                                                                                        Frequency frequency = new Frequency();
                                                                                                                                                                        Comparable<String> str1 = "first";
                                                                                                                                                                        Comparable<String> str2 = "second";
                                                                                                                                                                        frequency.addValue(str1);
                                                                                                                                                                        frequency.addValue(str2);
                                                                                                                                                                        frequency.addValue(str1);
                                                                                                                                                                        
                                                                                                                                                                        assertEquals(2, frequency.getCount(str1));
                                                                                                                                                                        assertEquals(1, frequency.getCount(str2));
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testAddValueWithDifferentComparableTypes() {
                                                                                                                                                                        Frequency frequency = new Frequency();
                                                                                                                                                                        
                                                                                                                                                                        // This should work since both are Comparable
                                                                                                                                                                        frequency.addValue("string");
                                                                                                                                                                        frequency.addValue(5);
                                                                                                                                                                        frequency.addValue(10L);
                                                                                                                                                                        
                                                                                                                                                                        assertEquals(1, frequency.getCount("string"));
                                                                                                                                                                        assertEquals(1, frequency.getCount(5));
                                                                                                                                                                        assertEquals(1, frequency.getCount(10L));
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testAddValueWithSameValueDifferentTypes() {
                                                                                                                                                                        Frequency frequency = new Frequency();
                                                                                                                                                                        
                                                                                                                                                                        // This tests the Integer to Long conversion
                                                                                                                                                                        frequency.addValue(5); // int
                                                                                                                                                                        frequency.addValue(Integer.valueOf(5)); // Integer
                                                                                                                                                                        frequency.addValue(5L); // long
                                                                                                                                                                        
                                                                                                                                                                        // All should be counted as the same value (Long)
                                                                                                                                                                        assertEquals(3, frequency.getCount(5L));
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testAddValueWithPrivateMethodThroughReflection() throws Exception {
                                                                                                                                                                        Frequency frequency = new Frequency();
                                                                                                                                                                        
                                                                                                                                                                        // This tests the private method invocation through reflection
                                                                                                                                                                        Method addValueMethod = Frequency.class.getDeclaredMethod("addValue", Comparable.class);
                                                                                                                                                                        addValueMethod.setAccessible(true);
                                                                                                                                                                        
                                                                                                                                                                        Comparable<String> testValue = "reflectionTest";
                                                                                                                                                                        addValueMethod.invoke(frequency, testValue);
                                                                                                                                                                        
                                                                                                                                                                        assertEquals(1, frequency.getCount(testValue));
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testAddValueWithInteger() {
                                                                                                                                                                        // Create mock objects
                                                                                                                                                                        TreeMap<Object, Long> mockFreqTable = mock(TreeMap.class);
                                                                                                                                                                        Frequency frequency = new Frequency();
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to set the private freqTable field
                                                                                                                                                                        try {
                                                                                                                                                                            java.lang.reflect.Field field = Frequency.class.getDeclaredField("freqTable");
                                                                                                                                                                            field.setAccessible(true);
                                                                                                                                                                            field.set(frequency, mockFreqTable);
                                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                                            throw new RuntimeException(e);
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        Integer value = 5;
                                                                                                                                                                        frequency.addValue(value);
                                                                                                                                                                        
                                                                                                                                                                        verify(mockFreqTable).get(Long.valueOf(5L));
                                                                                                                                                                        verify(mockFreqTable).put(Long.valueOf(5L), Long.valueOf(1L));
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testAddValueWithNonIntegerComparable() {
                                                                                                                                                                        TreeMap<Object, Long> mockFreqTable = mock(TreeMap.class);
                                                                                                                                                                        Frequency frequency = new Frequency();
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to set the private freqTable field
                                                                                                                                                                        try {
                                                                                                                                                                            java.lang.reflect.Field field = Frequency.class.getDeclaredField("freqTable");
                                                                                                                                                                            field.setAccessible(true);
                                                                                                                                                                            field.set(frequency, mockFreqTable);
                                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                                            throw new RuntimeException(e);
                                                                                                                                                                        }
                                                                                                                                                                
                                                                                                                                                                        String value = "test";
                                                                                                                                                                        
                                                                                                                                                                        when(mockFreqTable.get(value)).thenReturn(null);
                                                                                                                                                                        
                                                                                                                                                                        frequency.addValue(value);
                                                                                                                                                                        
                                                                                                                                                                        verify(mockFreqTable).get(value);
                                                                                                                                                                        verify(mockFreqTable).put(value, Long.valueOf(1L));
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testAddValueWithNonComparableThrowsException() {
                                                                                                                                                                        // Create mock objects
                                                                                                                                                                        TreeMap<Comparable<?>, Long> mockFreqTable = mock(TreeMap.class);
                                                                                                                                                                        Frequency frequency = new Frequency();
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to set the private freqTable field
                                                                                                                                                                        try {
                                                                                                                                                                            java.lang.reflect.Field field = Frequency.class.getDeclaredField("freqTable");
                                                                                                                                                                            field.setAccessible(true);
                                                                                                                                                                            field.set(frequency, mockFreqTable);
                                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                                            throw new RuntimeException(e);
                                                                                                                                                                        }
                                                                                                                                                                
                                                                                                                                                                        // Create a non-comparable object
                                                                                                                                                                        Object nonComparable = new Object() {
                                                                                                                                                                            @Override
                                                                                                                                                                            public String toString() {
                                                                                                                                                                                return "non-comparable";
                                                                                                                                                                            }
                                                                                                                                                                        };
                                                                                                                                                                        
                                                                                                                                                                        when(mockFreqTable.get(nonComparable)).thenThrow(new ClassCastException());
                                                                                                                                                                        
                                                                                                                                                                        try {
                                                                                                                                                                            frequency.addValue((Comparable<?>) nonComparable);
                                                                                                                                                                        } catch (IllegalArgumentException e) {
                                                                                                                                                                            // Expected exception
                                                                                                                                                                        }
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testAddValueWithNull1() {
                                                                                                                                                                        Frequency frequency = new Frequency();
                                                                                                                                                                        try {
                                                                                                                                                                            frequency.addValue((Comparable<?>) null);
                                                                                                                                                                            fail("Expected NullPointerException");
                                                                                                                                                                        } catch (NullPointerException e) {
                                                                                                                                                                            // Expected exception
                                                                                                                                                                        }
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testAddValueWithIntegerConversion() throws Exception {
                                                                                                                                                                        // Create instance of Frequency class
                                                                                                                                                                        Frequency frequency = new Frequency();
                                                                                                                                                                        
                                                                                                                                                                        Integer value = 7;
                                                                                                                                                                        
                                                                                                                                                                        // Reset to use real TreeMap for this test
                                                                                                                                                                        Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                                                                                                                                                                        freqTableField.setAccessible(true);
                                                                                                                                                                        freqTableField.set(frequency, new TreeMap<Comparable<?>, Long>());
                                                                                                                                                                        
                                                                                                                                                                        frequency.addValue(value);
                                                                                                                                                                        
                                                                                                                                                                        // Verify the value was converted to Long
                                                                                                                                                                        assertEquals(1L, frequency.getCount(7L));
                                                                                                                                                                        assertEquals(0L, frequency.getCount(7)); // Should use long value
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testAddValueInt() {
                                                                                                                                                                        Frequency frequency = new Frequency();
                                                                                                                                                                        
                                                                                                                                                                        // Test adding a single value
                                                                                                                                                                        frequency.addValue(5);
                                                                                                                                                                        assertEquals(1, frequency.getCount(5));
                                                                                                                                                                        
                                                                                                                                                                        // Test adding multiple values
                                                                                                                                                                        frequency.addValue(5);
                                                                                                                                                                        assertEquals(2, frequency.getCount(5));
                                                                                                                                                                        
                                                                                                                                                                        // Test adding different values
                                                                                                                                                                        frequency.addValue(10);
                                                                                                                                                                        assertEquals(1, frequency.getCount(10));
                                                                                                                                                                        assertEquals(2, frequency.getCount(5));
                                                                                                                                                                        
                                                                                                                                                                        // Test adding negative values
                                                                                                                                                                        frequency.addValue(-3);
                                                                                                                                                                        assertEquals(1, frequency.getCount(-3));
                                                                                                                                                                        
                                                                                                                                                                        // Test adding zero
                                                                                                                                                                        frequency.addValue(0);
                                                                                                                                                                        assertEquals(1, frequency.getCount(0));
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testAddValueIntWithExistingLongValues() {
                                                                                                                                                                        Frequency frequency = new Frequency();
                                                                                                                                                                        
                                                                                                                                                                        // First add a long value
                                                                                                                                                                        frequency.addValue(5L);
                                                                                                                                                                        
                                                                                                                                                                        // Then add equivalent int value
                                                                                                                                                                        frequency.addValue(5);
                                                                                                                                                                        
                                                                                                                                                                        // Should be counted together
                                                                                                                                                                        assertEquals(2, frequency.getCount(5));
                                                                                                                                                                        assertEquals(2, frequency.getCount(5L));
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testAddValueIntWithExistingIntegerObjects() {
                                                                                                                                                                        Frequency frequency = new Frequency();
                                                                                                                                                                        
                                                                                                                                                                        // First add an Integer object
                                                                                                                                                                        frequency.addValue(Integer.valueOf(5));
                                                                                                                                                                        
                                                                                                                                                                        // Then add equivalent int primitive
                                                                                                                                                                        frequency.addValue(5);
                                                                                                                                                                        
                                                                                                                                                                        // Should be counted together
                                                                                                                                                                        assertEquals(2, frequency.getCount(5));
                                                                                                                                                                        assertEquals(2, frequency.getCount(Integer.valueOf(5)));
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testAddValueIntUpdatesSumFreq() {
                                                                                                                                                                        Frequency frequency = new Frequency();
                                                                                                                                                                        
                                                                                                                                                                        assertEquals(0, frequency.getSumFreq());
                                                                                                                                                                        
                                                                                                                                                                        frequency.addValue(1);
                                                                                                                                                                        assertEquals(1, frequency.getSumFreq());
                                                                                                                                                                        
                                                                                                                                                                        frequency.addValue(2);
                                                                                                                                                                        assertEquals(2, frequency.getSumFreq());
                                                                                                                                                                        
                                                                                                                                                                        frequency.addValue(1);
                                                                                                                                                                        assertEquals(3, frequency.getSumFreq());
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testAddValueIntAfterClear() {
                                                                                                                                                                        Frequency frequency = new Frequency();
                                                                                                                                                                        frequency.addValue(5);
                                                                                                                                                                        frequency.clear();
                                                                                                                                                                        frequency.addValue(5);
                                                                                                                                                                        assertEquals(1, frequency.getCount(5));
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testAddValueIntWithMaxAndMinValues() {
                                                                                                                                                                        Frequency frequency = new Frequency();
                                                                                                                                                                        frequency.addValue(Integer.MAX_VALUE);
                                                                                                                                                                        assertEquals(1, frequency.getCount(Integer.MAX_VALUE));
                                                                                                                                                                        
                                                                                                                                                                        frequency.addValue(Integer.MIN_VALUE);
                                                                                                                                                                        assertEquals(1, frequency.getCount(Integer.MIN_VALUE));
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testAddValueIntMultipleTimes() {
                                                                                                                                                                        Frequency frequency = new Frequency();
                                                                                                                                                                        for (int i = 0; i < 100; i++) {
                                                                                                                                                                            frequency.addValue(42);
                                                                                                                                                                        }
                                                                                                                                                                        assertEquals(100, frequency.getCount(42));
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testAddValueIntegerWithNull() {
                                                                                                                                                                        Frequency frequency = new Frequency();
                                                                                                                                                                        try {
                                                                                                                                                                            frequency.addValue((Integer) null);
                                                                                                                                                                            fail("Expected NullPointerException");
                                                                                                                                                                        } catch (NullPointerException e) {
                                                                                                                                                                            // Expected exception
                                                                                                                                                                        }
                                                                                                                                                                    }

    @Test
                                                                                                                                                                public void testAddValueLong() {
                                                                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                                                                    
                                                                                                                                                                    // Test adding a single long value
                                                                                                                                                                    frequency.addValue(5L);
                                                                                                                                                                    assertEquals(1L, frequency.getCount(5L));
                                                                                                                                                                    
                                                                                                                                                                    // Test adding multiple same long values
                                                                                                                                                                    frequency.addValue(5L);
                                                                                                                                                                    assertEquals(2L, frequency.getCount(5L));
                                                                                                                                                                    
                                                                                                                                                                    // Test adding different long values
                                                                                                                                                                    frequency.addValue(10L);
                                                                                                                                                                    assertEquals(1L, frequency.getCount(10L));
                                                                                                                                                                    assertEquals(2L, frequency.getCount(5L));
                                                                                                                                                                    
                                                                                                                                                                    // Test adding zero
                                                                                                                                                                    frequency.addValue(0L);
                                                                                                                                                                    assertEquals(1L, frequency.getCount(0L));
                                                                                                                                                                    
                                                                                                                                                                    // Test adding negative value
                                                                                                                                                                    frequency.addValue(-3L);
                                                                                                                                                                    assertEquals(1L, frequency.getCount(-3L));
                                                                                                                                                                    
                                                                                                                                                                    // Test adding Long.MAX_VALUE
                                                                                                                                                                    frequency.addValue(Long.MAX_VALUE);
                                                                                                                                                                    assertEquals(1L, frequency.getCount(Long.MAX_VALUE));
                                                                                                                                                                    
                                                                                                                                                                    // Test adding Long.MIN_VALUE
                                                                                                                                                                    frequency.addValue(Long.MIN_VALUE);
                                                                                                                                                                    assertEquals(1L, frequency.getCount(Long.MIN_VALUE));
                                                                                                                                                                    
                                                                                                                                                                    // Verify total count
                                                                                                                                                                    assertEquals(6L, frequency.getSumFreq());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testAddValueLongWithExistingInt() {
                                                                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                                                                    
                                                                                                                                                                    // Add int value first
                                                                                                                                                                    frequency.addValue(5);
                                                                                                                                                                    assertEquals(1L, frequency.getCount(5L));
                                                                                                                                                            
                                                                                                                                                                    // Add same value as long
                                                                                                                                                                    frequency.addValue(5L);
                                                                                                                                                                    assertEquals(2L, frequency.getCount(5L));
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testAddValueLongWithExistingInteger() {
                                                                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                                                                    
                                                                                                                                                                    // Add Integer value first
                                                                                                                                                                    frequency.addValue(Integer.valueOf(5));
                                                                                                                                                                    assertEquals(1L, frequency.getCount(5L));
                                                                                                                                                            
                                                                                                                                                                    // Add same value as long
                                                                                                                                                                    frequency.addValue(5L);
                                                                                                                                                                    assertEquals(2L, frequency.getCount(5L));
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testAddValueLongEdgeCases() {
                                                                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                                                                    
                                                                                                                                                                    // Test adding same value multiple times
                                                                                                                                                                    for (int i = 0; i < 1000; i++) {
                                                                                                                                                                        frequency.addValue(42L);
                                                                                                                                                                    }
                                                                                                                                                                    assertEquals(1000L, frequency.getCount(42L));
                                                                                                                                                                    
                                                                                                                                                                    // Test adding different values
                                                                                                                                                                    for (long i = 0; i < 100; i++) {
                                                                                                                                                                        frequency.addValue(i);
                                                                                                                                                                    }
                                                                                                                                                                    assertEquals(100L, frequency.getSumFreq() - 1000L);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testAddValueLongAfterClear() {
                                                                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                                                                    frequency.addValue(5L);
                                                                                                                                                                    frequency.clear();
                                                                                                                                                                    assertEquals(0L, frequency.getCount(5L));
                                                                                                                                                                    assertEquals(0L, frequency.getSumFreq());
                                                                                                                                                                    
                                                                                                                                                                    frequency.addValue(5L);
                                                                                                                                                                    assertEquals(1L, frequency.getCount(5L));
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testAddValueChar() {
                                                                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                                                                    
                                                                                                                                                                    // Test adding a single character
                                                                                                                                                                    frequency.addValue('a');
                                                                                                                                                                    assertEquals(1, frequency.getCount('a'));
                                                                                                                                                                    
                                                                                                                                                                    // Test adding multiple characters
                                                                                                                                                                    frequency.addValue('b');
                                                                                                                                                                    frequency.addValue('b');
                                                                                                                                                                    assertEquals(1, frequency.getCount('a'));
                                                                                                                                                                    assertEquals(2, frequency.getCount('b'));
                                                                                                                                                                    
                                                                                                                                                                    // Test adding same character multiple times
                                                                                                                                                                    frequency.addValue('a');
                                                                                                                                                                    frequency.addValue('a');
                                                                                                                                                                    frequency.addValue('a');
                                                                                                                                                                    assertEquals(4, frequency.getCount('a'));
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testAddValueCharWithExistingIntegers() {
                                                                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                                                                    
                                                                                                                                                                    // First add some integers
                                                                                                                                                                    frequency.addValue(1);
                                                                                                                                                                    frequency.addValue(2);
                                                                                                                                                                    frequency.addValue(2);
                                                                                                                                                                    
                                                                                                                                                                    // Then add characters - should work fine
                                                                                                                                                                    frequency.addValue('a');
                                                                                                                                                                    frequency.addValue('b');
                                                                                                                                                                    frequency.addValue('b');
                                                                                                                                                                    
                                                                                                                                                                    assertEquals(1, frequency.getCount(1));
                                                                                                                                                                    assertEquals(2, frequency.getCount(2));
                                                                                                                                                                    assertEquals(1, frequency.getCount('a'));
                                                                                                                                                                    assertEquals(2, frequency.getCount('b'));
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testAddValueCharWithMixedTypes() {
                                                                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                                                                    
                                                                                                                                                                    // Add different types of values
                                                                                                                                                                    frequency.addValue(Character.valueOf('a'));
                                                                                                                                                                    frequency.addValue(Integer.valueOf(1));
                                                                                                                                                                    frequency.addValue("string");
                                                                                                                                                                    frequency.addValue(Character.valueOf('b'));
                                                                                                                                                                    
                                                                                                                                                                    assertEquals(1, frequency.getCount(Character.valueOf('a')));
                                                                                                                                                                    assertEquals(1, frequency.getCount(Integer.valueOf(1)));
                                                                                                                                                                    assertEquals(1, frequency.getCount("string"));
                                                                                                                                                                    assertEquals(1, frequency.getCount(Character.valueOf('b')));
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testAddValueCharSpecialCharacters() {
                                                                                                                                                                    // Create new Frequency instance
                                                                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                                                                    
                                                                                                                                                                    // Test with special characters
                                                                                                                                                                    frequency.addValue(' ');
                                                                                                                                                                    frequency.addValue('\n');
                                                                                                                                                                    frequency.addValue('\t');
                                                                                                                                                                    frequency.addValue('@');
                                                                                                                                                                    frequency.addValue('@');
                                                                                                                                                                    
                                                                                                                                                                    assertEquals(1, frequency.getCount(' '));
                                                                                                                                                                    assertEquals(1, frequency.getCount('\n'));
                                                                                                                                                                    assertEquals(1, frequency.getCount('\t'));
                                                                                                                                                                    assertEquals(2, frequency.getCount('@'));
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testAddValueCharCaseSensitivity() {
                                                                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                                                                    
                                                                                                                                                                    // Test case sensitivity
                                                                                                                                                                    frequency.addValue('A');
                                                                                                                                                                    frequency.addValue('a');
                                                                                                                                                                    frequency.addValue('A');
                                                                                                                                                                    
                                                                                                                                                                    assertEquals(2, frequency.getCount('A'));
                                                                                                                                                                    assertEquals(1, frequency.getCount('a'));
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testAddValueCharAfterClear() {
                                                                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                                                                    frequency.addValue('a');
                                                                                                                                                                    frequency.addValue('b');
                                                                                                                                                                    frequency.clear();
                                                                                                                                                                    
                                                                                                                                                                    frequency.addValue('c');
                                                                                                                                                                    assertEquals(0, frequency.getCount('a'));
                                                                                                                                                                    assertEquals(0, frequency.getCount('b'));
                                                                                                                                                                    assertEquals(1, frequency.getCount('c'));
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testAddValueCharThroughReflection() throws Exception {
                                                                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                                                                    Method method = Frequency.class.getDeclaredMethod("addValue", char.class);
                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                    method.invoke(frequency, 'x');
                                                                                                                                                                    
                                                                                                                                                                    assertEquals(1, frequency.getCount('x'));
                                                                                                                                                                }

    @Test
                                                                                                                                        public void testAddValueCharWithComparator() {
                                                                                                                                            // Define the NaturalComparator inside the test method
                                                                                                                                            class NaturalComparator<T extends Comparable<T>> implements java.util.Comparator<T> {
                                                                                                                                                public int compare(T o1, T o2) {
                                                                                                                                                    return o1.compareTo(o2);
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                            
                                                                                                                                            Frequency freqWithComparator = new Frequency(new NaturalComparator<Character>());
                                                                                                                                            freqWithComparator.addValue('a');
                                                                                                                                            freqWithComparator.addValue('b');
                                                                                                                                            freqWithComparator.addValue('a');
                                                                                                                                            
                                                                                                                                            assertEquals(2, freqWithComparator.getCount('a'));
                                                                                                                                            assertEquals(1, freqWithComparator.getCount('b'));
                                                                                                                                        }

    @Test
                                                                                    public void testAddValueWithCharacter() {
                                                                                        // Create instance of Frequency class
                                                                                        Frequency frequency = new Frequency();
                                                                                        
                                                                                        // Test adding a character value
                                                                                        char testChar = 'a';
                                                                                        frequency.addValue(testChar);
                                                                                        
                                                                                        // Verify the count for the character
                                                                                        assertEquals(1, frequency.getCount(testChar));
                                                                                    }

    @Test
        public void testAddValueIntegerMultipleCalls() throws Exception {
            // Create mock objects
            // Create the Frequency object
            Object frequency = Class.forName("org.apache.commons.math.stat.Frequency").newInstance();
            
            // Use reflection to set the private freqTable field
            Field freqTableField = frequency.getClass().getDeclaredField("freqTable");
            freqTableField.setAccessible(true);
            
            // Test values
            Integer testValue1 = Integer.valueOf(5);
            Integer testValue2 = Integer.valueOf(10);
            
            // First call
            Method addValueMethod = frequency.getClass().getMethod("addValue", Comparable.class);
            addValueMethod.invoke(frequency, testValue1);
            
            // Second call with different value
            addValueMethod.invoke(frequency, testValue2);
            
            // Third call with same value (should increment count)
            addValueMethod.invoke(frequency, testValue1);
        }

    @Test
        public void testAddValueIntegerMaxValue() {
            try {
                // Create instance of Frequency class
                Object frequency = Class.forName("org.apache.commons.math.stat.Frequency").getDeclaredConstructor().newInstance();
                
                // Create mock objects
                
                // Use reflection to set the private freqTable field
                Field freqTableField = frequency.getClass().getDeclaredField("freqTable");
                freqTableField.setAccessible(true);
                
                Integer testValue = Integer.MAX_VALUE;
                
                // Use reflection to call addValue method
                Method addValueMethod = frequency.getClass().getMethod("addValue", Comparable.class);
                addValueMethod.invoke(frequency, testValue);
                
                // Verify the value was added
                Method getCountMethod = frequency.getClass().getMethod("getCount", Comparable.class);
                Long count = (Long) getCountMethod.invoke(frequency, testValue);
                assertEquals(1L, count.longValue());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

    @Test
        public void testAddValueIntegerMinValue() {
            // Create mock frequency table
            // Setup mock behavior
            
            // Create frequency instance and inject mock table using reflection
            org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
            try {
                Field field = frequency.getClass().getDeclaredField("freqTable");
                field.setAccessible(true);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            
            Integer testValue = Integer.MIN_VALUE;
            frequency.addValue(testValue);
            
            // Verify the behavior
        }

    @Test
        public void testAddValueIntegerZero() {
            // Initialize mocks
            
            // Create mock frequency table
            @SuppressWarnings("unchecked")
            // Setup mock behavior
            // Create frequency instance and inject mock table using reflection
            org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
            try {
                java.lang.reflect.Field field = frequency.getClass().getDeclaredField("freqTable");
                field.setAccessible(true);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            
            // Test data
            Integer testValue = Integer.valueOf(0);
            
            // Test execution
            frequency.addValue(testValue);
            
            // Verification
        }

    @Test
        public void testAddValueIntegerWithExistingValue() throws Exception {
            // Create mock objects
            // Create real Frequency object
            Object frequency = Class.forName("org.apache.commons.math.stat.Frequency").newInstance();
            
            // Inject mock using reflection
            Field freqTableField = frequency.getClass().getDeclaredField("freqTable");
            freqTableField.setAccessible(true);
            
            Integer testValue = Integer.valueOf(7);
            Long expectedLongValue = Long.valueOf(7L);
            
            // Simulate existing value
            
            // Invoke addValue method
            Method addValueMethod = frequency.getClass().getMethod("addValue", Comparable.class);
            addValueMethod.invoke(frequency, testValue);
            
        }

    @Test
        public void testAddValueWithExistingValue() {
            // Create mock objects
            @SuppressWarnings("unchecked")
            // Create instance of Frequency class
            org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
            
            // Setup mock behavior
            
            // Use reflection to set the private freqTable field
            try {
                Field field = org.apache.commons.math.stat.Frequency.class.getDeclaredField("freqTable");
                field.setAccessible(true);
            } catch (Exception e) {
                fail("Failed to set freqTable field via reflection");
            }
        
            // Test data
            String valueToAdd = "testValue";
        
            // Call method under test
            frequency.addValue(valueToAdd);
        
            // Verify interactions
        }

    @Test
        public void testAddValueInteger() {
            // Create frequency object
            org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
            
            Integer testValue = Integer.valueOf(5);
            
            // Call the method
            frequency.addValue(testValue);
            
            // Verify the count
            try {
                Field freqTableField = org.apache.commons.math.stat.Frequency.class.getDeclaredField("freqTable");
                freqTableField.setAccessible(true);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

    @Test
        public void testAddValueIntegerNegative() {
            org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
            
            Integer testValue = Integer.valueOf(-42);
            frequency.addValue(testValue);
            
            try {
                Field freqTableField = org.apache.commons.math.stat.Frequency.class.getDeclaredField("freqTable");
                freqTableField.setAccessible(true);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

    @Test
        public void testAddValueWithNewLongValue() {
            // Create mock objects
            @SuppressWarnings("unchecked")
            // Create instance of Frequency
            Frequency frequency = new Frequency();
            
            try {
                // Use reflection to set the private freqTable field
                Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                freqTableField.setAccessible(true);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            
            Long value = 20L;
            
            // Mock behavior
            
            // Call method under test
            frequency.addValue(value);
            
            // Verify behavior
        }


}
