package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.util.Arrays;
import org.apache.commons.math.MathException;
import org.apache.commons.math.MathRuntimeException;
 
public class MathUtilsTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testGcdPositiveNumbers() {
            assertEquals(6, MathUtils.gcd(12, 18));
            assertEquals(1, MathUtils.gcd(13, 17));
            assertEquals(5, MathUtils.gcd(15, 20));
        }

    @Test
        public void testGcdNegativeNumbers() {
            assertEquals(6, MathUtils.gcd(-12, -18));
            assertEquals(1, MathUtils.gcd(-13, -17));
            assertEquals(5, MathUtils.gcd(-15, -20));
        }

    @Test
        public void testGcdMixedSignNumbers() {
            assertEquals(6, MathUtils.gcd(-12, 18));
            assertEquals(1, MathUtils.gcd(13, -17));
            assertEquals(5, MathUtils.gcd(15, -20));
        }

    @Test
        public void testGcdWithZero() {
            assertEquals(12, MathUtils.gcd(12, 0));
            assertEquals(18, MathUtils.gcd(0, 18));
            assertEquals(0, MathUtils.gcd(0, 0));
        }

    @Test
        public void testGcdSameNumber() {
            assertEquals(7, MathUtils.gcd(7, 7));
            assertEquals(1, MathUtils.gcd(1, 1));
            assertEquals(0, MathUtils.gcd(0, 0));
        }

    @Test
        public void testGcdOneIsMultipleOfOther() {
            assertEquals(5, MathUtils.gcd(5, 10));
            assertEquals(5, MathUtils.gcd(10, 5));
            assertEquals(3, MathUtils.gcd(9, 3));
        }

    @Test
        public void testGcdPrimeNumbers() {
            assertEquals(1, MathUtils.gcd(11, 13));
            assertEquals(1, MathUtils.gcd(17, 19));
            assertEquals(1, MathUtils.gcd(23, 29));
        }

    @Test(expected = ArithmeticException.class)
        public void testGcdMinValueWithZero() {
            MathUtils.gcd(Integer.MIN_VALUE, 0);
        }

    @Test(expected = ArithmeticException.class)
        public void testGcdZeroWithMinValue() {
            MathUtils.gcd(0, Integer.MIN_VALUE);
        }

    @Test(expected = ArithmeticException.class)
        public void testGcdBothMinValue() {
            MathUtils.gcd(Integer.MIN_VALUE, Integer.MIN_VALUE);
        }

    @Test
        public void testGcdLargeNumbers() {
            assertEquals(1000, MathUtils.gcd(1000000, 1000));
            assertEquals(1000, MathUtils.gcd(1000, 1000000));
            assertEquals(1, MathUtils.gcd(1000003, 1000007));
        }

    @Test
        public void testGcdPowersOfTwo() {
            assertEquals(8, MathUtils.gcd(16, 24));
            assertEquals(16, MathUtils.gcd(32, 16));
            assertEquals(4, MathUtils.gcd(12, 8));
        }

    @Test
        public void testGcdWithOne() {
            assertEquals(1, MathUtils.gcd(1, 100));
            assertEquals(1, MathUtils.gcd(100, 1));
            assertEquals(1, MathUtils.gcd(1, 1));
        }

    @Test
        public void testGcdWithMaxValue() {
            assertEquals(1, MathUtils.gcd(Integer.MAX_VALUE, Integer.MAX_VALUE - 1));
            assertEquals(1, MathUtils.gcd(Integer.MAX_VALUE, 1));
            assertEquals(1, MathUtils.gcd(1, Integer.MAX_VALUE));
        }

    @Test(expected = ArithmeticException.class)
        public void testGcdOverflowCase() {
            // This tests the case where k == 31 in the algorithm
            MathUtils.gcd(-(1 << 30), -(1 << 30));
        }

    @Test
        public void testLcmWithZero() {
            assertEquals(0, MathUtils.lcm(0, 5));
            assertEquals(0, MathUtils.lcm(5, 0));
            assertEquals(0, MathUtils.lcm(0, 0));
        }

    @Test
        public void testLcmWithPositiveNumbers() {
            assertEquals(12, MathUtils.lcm(3, 4));
            assertEquals(30, MathUtils.lcm(5, 6));
            assertEquals(36, MathUtils.lcm(12, 18));
            assertEquals(77, MathUtils.lcm(7, 11));
        }

    @Test
        public void testLcmWithNegativeNumbers() {
            assertEquals(12, MathUtils.lcm(-3, 4));
            assertEquals(30, MathUtils.lcm(5, -6));
            assertEquals(36, MathUtils.lcm(-12, -18));
        }

    @Test
        public void testLcmWithSameNumbers() {
            assertEquals(5, MathUtils.lcm(5, 5));
            assertEquals(12, MathUtils.lcm(-12, -12));
        }

    @Test
        public void testLcmWithOne() {
            assertEquals(5, MathUtils.lcm(1, 5));
            assertEquals(7, MathUtils.lcm(7, 1));
        }

    @Test
        public void testLcmWithLargeNumbers() {
            assertEquals(1071, MathUtils.lcm(153, 119));
            assertEquals(2147483646, MathUtils.lcm(1073741823, 2));
        }

    @Test(expected = ArithmeticException.class)
        public void testLcmOverflow() {
            MathUtils.lcm(Integer.MIN_VALUE, 1);
        }

    @Test(expected = ArithmeticException.class)
        public void testLcmOverflow1() {
            MathUtils.lcm(1073741824, 2);
        }

}
