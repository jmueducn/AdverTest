package gentest.org.apache.commons.math.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.distribution.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.special.Beta;
 
public class FDistributionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                            public void testGetInitialDomainWhenDenominatorDFLargeValue() throws Exception {
                                                FDistributionImpl fDistribution = spy(new FDistributionImpl(5.0, 1000.0));
                                                when(fDistribution.getDenominatorDegreesOfFreedom()).thenReturn(1000.0);
                                                
                                                Method method = FDistributionImpl.class.getDeclaredMethod("getInitialDomain", double.class);
                                                method.setAccessible(true);
                                                double result = (double) method.invoke(fDistribution, 0.5);
                                                
                                                assertEquals(1000.0 / (1000.0 - 2.0), result, 0.0001);
                                            }

    @Test
                                        public void testGetInitialDomainWhenDenominatorDFLessThan() throws Exception {
                                            FDistributionImpl fDistribution = spy(new FDistributionImpl(5.0, 1.0));
                                            when(fDistribution.getDenominatorDegreesOfFreedom()).thenReturn(1.0);
                                            
                                            Method method = FDistributionImpl.class.getDeclaredMethod("getInitialDomain", double.class);
                                            method.setAccessible(true);
                                            double result = (double) method.invoke(fDistribution, 0.5);
                                            assertEquals(1.0, result, 0.0001);
                                        }

    @Test
                                        public void testGetInitialDomainWhenDenominatorDFJustAbove() throws Exception {
                                            FDistributionImpl fDistribution = spy(new FDistributionImpl(5.0, 2.0001));
                                            when(fDistribution.getDenominatorDegreesOfFreedom()).thenReturn(2.0001);
                                            
                                            Method method = FDistributionImpl.class.getDeclaredMethod("getInitialDomain", double.class);
                                            method.setAccessible(true);
                                            double result = (double) method.invoke(fDistribution, 0.5);
                                            assertEquals(2.0001 / (2.0001 - 2.0), result, 0.0001);
                                        }

    @Test
            public void testGetInitialDomainWhenDenominatorDFGreaterThan1() throws Exception {
                FDistributionImpl fDistribution = spy(new FDistributionImpl(5.0, 3.0));
                when(fDistribution.getDenominatorDegreesOfFreedom()).thenReturn(3.0);
                
                double result = 3.0 / (3.0 - 2.0);
                assertEquals(3.0 / (3.0 - 2.0), result, 0.0001);
            }

    @Test
        public void testGetInitialDomainWhenDenominatorDFGreaterThan() throws Exception {
            FDistributionImpl fDistribution = spy(new FDistributionImpl(5.0, 3.0));
            when(fDistribution.getDenominatorDegreesOfFreedom()).thenReturn(3.0);
            
            // Use reflection to access protected method
            java.lang.reflect.Method method = FDistributionImpl.class.getDeclaredMethod(
                "getInitialDomain", double.class);
            method.setAccessible(true);
            double result = (Double) method.invoke(fDistribution, 0.5);
            
            assertEquals(3.0 / (3.0 - 2.0), result, 0.0001);
        }

    @Test
        public void testGetInitialDomainWhenDenominatorDFGreaterThan2() throws Exception {
            FDistributionImpl fDistribution = spy(new FDistributionImpl(5.0, 3.0));
            when(fDistribution.getDenominatorDegreesOfFreedom()).thenReturn(3.0);
            
            Method method = FDistributionImpl.class.getDeclaredMethod("getInitialDomain", double.class);
            method.setAccessible(true);
            double result = (double) method.invoke(fDistribution, 0.0);
            
            assertEquals(3.0 / (3.0 - 2.0), result, 0.0001);
        }


}
