package gentest.org.apache.commons.math3.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.fraction.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import org.apache.commons.math3.FieldElement;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.exception.ZeroException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.util.ArithmeticUtils;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.MathUtils;
 
public class BigFractionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                        public void testConstructorWithPositiveBigInteger() {
                                                                                            BigInteger num = new BigInteger("12345678901234567890");
                                                                                            BigFraction fraction = new BigFraction(num);
                                                                                            
                                                                                            assertEquals(num, fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithNegativeBigInteger() {
                                                                                            BigInteger num = new BigInteger("-98765432109876543210");
                                                                                            BigFraction fraction = new BigFraction(num);
                                                                                            
                                                                                            assertEquals(num, fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithZero() {
                                                                                            BigInteger num = BigInteger.ZERO;
                                                                                            BigFraction fraction = new BigFraction(num);
                                                                                            
                                                                                            assertEquals(BigInteger.ZERO, fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithOne() {
                                                                                            BigInteger num = BigInteger.ONE;
                                                                                            BigFraction fraction = new BigFraction(num);
                                                                                            
                                                                                            assertEquals(BigInteger.ONE, fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithLargeValue() {
                                                                                            BigInteger num = new BigInteger("9999999999999999999999999999999999999999");
                                                                                            BigFraction fraction = new BigFraction(num);
                                                                                            
                                                                                            assertEquals(num, fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithPredefinedConstants() {
                                                                                            BigFraction fraction = new BigFraction(BigInteger.valueOf(2));
                                                                                            assertEquals(BigFraction.TWO, fraction);
                                                                                            
                                                                                            fraction = new BigFraction(BigInteger.ONE);
                                                                                            assertEquals(BigFraction.ONE, fraction);
                                                                                            
                                                                                            fraction = new BigFraction(BigInteger.ZERO);
                                                                                            assertEquals(BigFraction.ZERO, fraction);
                                                                                            
                                                                                            fraction = new BigFraction(BigInteger.valueOf(-1));
                                                                                            assertEquals(BigFraction.MINUS_ONE, fraction);
                                                                                        }

    @Test(expected = NullArgumentException.class)
                                                                                        public void testConstructorWithNull() {
                                                                                            new BigFraction((BigInteger)null);
                                                                                        }

    @Test
                                                                                        public void testConstructorWithValidArguments() {
                                                                                            BigFraction fraction = new BigFraction(BigInteger.valueOf(3), BigInteger.valueOf(4));
                                                                                            assertEquals(BigInteger.valueOf(3), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(4), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithZeroNumerator() {
                                                                                            BigFraction fraction = new BigFraction(BigInteger.ZERO, BigInteger.valueOf(5));
                                                                                            assertEquals(BigInteger.ZERO, fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test(expected = ZeroException.class)
                                                                                        public void testConstructorWithZeroDenominator() {
                                                                                            new BigFraction(BigInteger.valueOf(1), BigInteger.ZERO);
                                                                                        }

    @Test(expected = NullArgumentException.class)
                                                                                        public void testConstructorWithNullNumerator() {
                                                                                            new BigFraction(null, BigInteger.valueOf(1));
                                                                                        }

    @Test(expected = NullArgumentException.class)
                                                                                        public void testConstructorWithNullDenominator() {
                                                                                            new BigFraction(BigInteger.valueOf(1), null);
                                                                                        }

    @Test
                                                                                        public void testConstructorReducesFraction() {
                                                                                            BigFraction fraction = new BigFraction(BigInteger.valueOf(6), BigInteger.valueOf(8));
                                                                                            assertEquals(BigInteger.valueOf(3), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(4), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorMovesSignToNumerator() {
                                                                                            BigFraction fraction = new BigFraction(BigInteger.valueOf(3), BigInteger.valueOf(-4));
                                                                                            assertEquals(BigInteger.valueOf(-3), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(4), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithNegativeDenominator() {
                                                                                            BigFraction fraction = new BigFraction(BigInteger.valueOf(-3), BigInteger.valueOf(-4));
                                                                                            assertEquals(BigInteger.valueOf(3), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(4), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithGCDGreaterThanOne() {
                                                                                            BigFraction fraction = new BigFraction(BigInteger.valueOf(15), BigInteger.valueOf(20));
                                                                                            assertEquals(BigInteger.valueOf(3), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(4), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithLargeNumbers() {
                                                                                            BigInteger bigNum = new BigInteger("12345678901234567890");
                                                                                            BigInteger bigDen = new BigInteger("98765432109876543210");
                                                                                            BigFraction fraction = new BigFraction(bigNum, bigDen);
                                                                                            
                                                                                            BigInteger gcd = bigNum.gcd(bigDen);
                                                                                            BigInteger expectedNum = bigNum.divide(gcd);
                                                                                            BigInteger expectedDen = bigDen.divide(gcd);
                                                                                            
                                                                                            assertEquals(expectedNum, fraction.getNumerator());
                                                                                            assertEquals(expectedDen, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithOneAsDenominator() {
                                                                                            BigFraction fraction = new BigFraction(BigInteger.valueOf(5), BigInteger.ONE);
                                                                                            assertEquals(BigInteger.valueOf(5), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithNegativeNumerator() {
                                                                                            BigFraction fraction = new BigFraction(BigInteger.valueOf(-5), BigInteger.valueOf(7));
                                                                                            assertEquals(BigInteger.valueOf(-5), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(7), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithBothNegative() {
                                                                                            BigFraction fraction = new BigFraction(BigInteger.valueOf(-5), BigInteger.valueOf(-7));
                                                                                            assertEquals(BigInteger.valueOf(5), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(7), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithAlreadyReducedFraction() {
                                                                                            BigFraction fraction = new BigFraction(BigInteger.valueOf(7), BigInteger.valueOf(11));
                                                                                            assertEquals(BigInteger.valueOf(7), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(11), fraction.getDenominator());
                                                                                        }

    @Test(expected = MathIllegalArgumentException.class)
                                                                                        public void testConstructorWithNaN() {
                                                                                            new BigFraction(Double.NaN);
                                                                                        }

    @Test(expected = MathIllegalArgumentException.class)
                                                                                        public void testConstructorWithPositiveInfinity() {
                                                                                            new BigFraction(Double.POSITIVE_INFINITY);
                                                                                        }

    @Test(expected = MathIllegalArgumentException.class)
                                                                                        public void testConstructorWithNegativeInfinity() {
                                                                                            new BigFraction(Double.NEGATIVE_INFINITY);
                                                                                        }

    @Test
                                                                                        public void testConstructorWithZero1() {
                                                                                            BigFraction fraction = new BigFraction(0.0);
                                                                                            assertEquals(BigInteger.ZERO, fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithPositiveInteger() {
                                                                                            BigFraction fraction = new BigFraction(2.0);
                                                                                            assertEquals(BigInteger.valueOf(2), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithNegativeInteger() {
                                                                                            BigFraction fraction = new BigFraction(-3.0);
                                                                                            assertEquals(BigInteger.valueOf(-3), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithPositiveFraction() {
                                                                                            BigFraction fraction = new BigFraction(0.5);
                                                                                            // Expected value for 0.5 is 1/2
                                                                                            assertEquals(BigInteger.ONE, fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(2), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithNegativeFraction() {
                                                                                            BigFraction fraction = new BigFraction(-0.25);
                                                                                            // Expected value for -0.25 is -1/4
                                                                                            assertEquals(BigInteger.valueOf(-1), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(4), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithDenormalizedNumber() {
                                                                                            // Test with a denormalized number (very small number)
                                                                                            double denormalized = Double.MIN_VALUE;
                                                                                            BigFraction fraction = new BigFraction(denormalized);
                                                                                            assertNotNull(fraction.getNumerator());
                                                                                            assertNotNull(fraction.getDenominator());
                                                                                            assertTrue(fraction.doubleValue() > 0);
                                                                                        }

    @Test
                                                                                        public void testConstructorWithNormalizedNumber() {
                                                                                            // Test with a normalized number
                                                                                            BigFraction fraction = new BigFraction(1.0);
                                                                                            assertEquals(BigInteger.ONE, fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithLargeNumber() {
                                                                                            // Test with a large number
                                                                                            BigFraction fraction = new BigFraction(1.0e20);
                                                                                            assertTrue(fraction.getNumerator().compareTo(BigInteger.ZERO) > 0);
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithSmallNumber() {
                                                                                            // Test with a very small number
                                                                                            BigFraction fraction = new BigFraction(1.0e-20);
                                                                                            assertTrue(fraction.getNumerator().compareTo(BigInteger.ZERO) > 0);
                                                                                            assertTrue(fraction.getDenominator().compareTo(BigInteger.ONE) > 0);
                                                                                        }

    @Test
                                                                                        public void testConstructorWithNegativeExponent() {
                                                                                            // Test case where k < 0 in the implementation
                                                                                            BigFraction fraction = new BigFraction(0.125); // 1/8
                                                                                            assertEquals(BigInteger.ONE, fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(8), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithPositiveExponent() {
                                                                                            // Test case where k >= 0 in the implementation
                                                                                            BigFraction fraction = new BigFraction(8.0); // 8/1
                                                                                            assertEquals(BigInteger.valueOf(8), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithNonTerminatingDecimal() {
                                                                                            // Test with a non-terminating decimal like 1/3
                                                                                            BigFraction fraction = new BigFraction(1.0 / 3.0);
                                                                                            // Verify it's not exactly 1/3 due to double precision
                                                                                            assertNotEquals(BigInteger.ONE, fraction.getNumerator());
                                                                                            assertNotEquals(BigInteger.valueOf(3), fraction.getDenominator());
                                                                                            // But should be close to 1/3
                                                                                            assertEquals(1.0/3.0, fraction.doubleValue(), 1.0e-15);
                                                                                        }

    @Test
                                                                                        public void testConstructorWithExactValue() throws FractionConversionException {
                                                                                            BigFraction fraction = new BigFraction(0.5, 0.0001, 100);
                                                                                            assertEquals(BigInteger.ONE, fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(2), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithApproximateValue() throws FractionConversionException {
                                                                                            BigFraction fraction = new BigFraction(0.33333, 0.0001, 100);
                                                                                            assertEquals(BigInteger.ONE, fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(3), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithSmallEpsilon() throws FractionConversionException {
                                                                                            BigFraction fraction = new BigFraction(0.142857, 0.000001, 100);
                                                                                            assertEquals(BigInteger.ONE, fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(7), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithLargeEpsilon() throws FractionConversionException {
                                                                                            BigFraction fraction = new BigFraction(0.142857, 0.1, 100);
                                                                                            assertEquals(BigInteger.ONE, fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(7), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithIntegerValue() throws FractionConversionException {
                                                                                            BigFraction fraction = new BigFraction(5.0, 0.0001, 100);
                                                                                            assertEquals(BigInteger.valueOf(5), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithNegativeValue() throws FractionConversionException {
                                                                                            BigFraction fraction = new BigFraction(-0.5, 0.0001, 100);
                                                                                            assertEquals(BigInteger.ONE.negate(), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(2), fraction.getDenominator());
                                                                                        }

    @Test(expected = FractionConversionException.class)
                                                                                        public void testConstructorWithMaxIterationsExceeded() throws FractionConversionException {
                                                                                            new BigFraction(Math.PI, 0.0000000001, 5);
                                                                                        }

    @Test
                                                                                        public void testConstructorWithZeroValue() throws FractionConversionException {
                                                                                            BigFraction fraction = new BigFraction(0.0, 0.0001, 100);
                                                                                            assertEquals(BigInteger.ZERO, fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithVerySmallValue() throws FractionConversionException {
                                                                                            BigFraction fraction = new BigFraction(0.00001, 0.000001, 100);
                                                                                            assertEquals(BigInteger.ONE, fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(100000), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithLargeDenominator() throws FractionConversionException {
                                                                                            BigFraction fraction = new BigFraction(0.99999, 0.00001, 100);
                                                                                            assertEquals(BigInteger.valueOf(99999), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(100000), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithGoldenRatioApproximation() throws FractionConversionException {
                                                                                            BigFraction fraction = new BigFraction(1.6180339887, 0.0001, 20);
                                                                                            assertEquals(BigInteger.valueOf(89), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(55), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithPreciseValue() throws FractionConversionException {
                                                                                            BigFraction fraction = new BigFraction(0.123456789, 0.000000001, 100);
                                                                                            assertEquals(BigInteger.valueOf(10), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(81), fraction.getDenominator());
                                                                                        }

    @Test(expected = FractionConversionException.class)
                                                                                        public void testConstructorWithTooStrictEpsilon() throws FractionConversionException {
                                                                                            new BigFraction(0.123456789, 0.0000000000001, 100);
                                                                                        }

    @Test
                                                                                        public void testConstructorWithDoubleAndMaxDenominator() throws FractionConversionException {
                                                                                            // Test simple fraction conversion
                                                                                            BigFraction fraction1 = new BigFraction(0.5, 100);
                                                                                            assertEquals(1, fraction1.getNumeratorAsInt());
                                                                                            assertEquals(2, fraction1.getDenominatorAsInt());
                                                                                    
                                                                                            // Test whole number
                                                                                            BigFraction fraction2 = new BigFraction(3.0, 100);
                                                                                            assertEquals(3, fraction2.getNumeratorAsInt());
                                                                                            assertEquals(1, fraction2.getDenominatorAsInt());
                                                                                    
                                                                                            // Test repeating decimal
                                                                                            BigFraction fraction3 = new BigFraction(0.333333333, 100);
                                                                                            assertEquals(1, fraction3.getNumeratorAsInt());
                                                                                            assertEquals(3, fraction3.getDenominatorAsInt());
                                                                                    
                                                                                            // Test negative number
                                                                                            BigFraction fraction4 = new BigFraction(-0.75, 100);
                                                                                            assertEquals(-3, fraction4.getNumeratorAsInt());
                                                                                            assertEquals(4, fraction4.getDenominatorAsInt());
                                                                                    
                                                                                            // Test with max denominator constraint
                                                                                            BigFraction fraction5 = new BigFraction(0.123456789, 10);
                                                                                            assertEquals(1, fraction5.getNumeratorAsInt());
                                                                                            assertEquals(8, fraction5.getDenominatorAsInt());
                                                                                    
                                                                                            // Test with very small max denominator
                                                                                            BigFraction fraction6 = new BigFraction(0.999, 1);
                                                                                            assertEquals(1, fraction6.getNumeratorAsInt());
                                                                                            assertEquals(1, fraction6.getDenominatorAsInt());
                                                                                    
                                                                                            // Test with PI approximation
                                                                                            BigFraction fraction7 = new BigFraction(Math.PI, 113);
                                                                                            assertEquals(355, fraction7.getNumeratorAsInt());
                                                                                            assertEquals(113, fraction7.getDenominatorAsInt());
                                                                                        }

    @Test(expected = FractionConversionException.class)
                                                                                        public void testConstructorWithInvalidMaxDenominator() throws FractionConversionException {
                                                                                            new BigFraction(Math.PI, 0);
                                                                                        }

    @Test(expected = FractionConversionException.class)
                                                                                        public void testConstructorWithVerySmallMaxDenominator() throws FractionConversionException {
                                                                                            new BigFraction(0.123456789, 1);
                                                                                        }

    @Test
                                                                                        public void testConstructorWithEdgeCases() throws FractionConversionException {
                                                                                            // Test zero
                                                                                            BigFraction fraction1 = new BigFraction(0.0, 100);
                                                                                            assertEquals(0, fraction1.getNumeratorAsInt());
                                                                                            assertEquals(1, fraction1.getDenominatorAsInt());
                                                                                    
                                                                                            // Test very small number
                                                                                            BigFraction fraction2 = new BigFraction(1.0E-10, 1000000);
                                                                                            assertTrue(fraction2.doubleValue() > 0);
                                                                                    
                                                                                            // Test very large number
                                                                                            BigFraction fraction3 = new BigFraction(1.0E10, 100);
                                                                                            assertEquals(10000000000L, fraction3.getNumeratorAsLong());
                                                                                            assertEquals(1, fraction3.getDenominatorAsInt());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithPrecision() throws FractionConversionException {
                                                                                            // Test different precision levels
                                                                                            BigFraction fraction1 = new BigFraction(0.12345, 10);
                                                                                            BigFraction fraction2 = new BigFraction(0.12345, 100);
                                                                                            BigFraction fraction3 = new BigFraction(0.12345, 1000);
                                                                                    
                                                                                            assertNotEquals(fraction1, fraction2);
                                                                                            assertNotEquals(fraction2, fraction3);
                                                                                            assertTrue(Math.abs(0.12345 - fraction3.doubleValue()) < 
                                                                                                      Math.abs(0.12345 - fraction1.doubleValue()));
                                                                                        }

    @Test
                                                                                        public void testPositiveInteger() {
                                                                                            BigFraction fraction = new BigFraction(5);
                                                                                            assertEquals(BigInteger.valueOf(5), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testNegativeInteger() {
                                                                                            BigFraction fraction = new BigFraction(-3);
                                                                                            assertEquals(BigInteger.valueOf(-3), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testZero() {
                                                                                            BigFraction fraction = new BigFraction(0);
                                                                                            assertEquals(BigInteger.ZERO, fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testMaxInteger() {
                                                                                            BigFraction fraction = new BigFraction(Integer.MAX_VALUE);
                                                                                            assertEquals(BigInteger.valueOf(Integer.MAX_VALUE), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testMinInteger() {
                                                                                            BigFraction fraction = new BigFraction(Integer.MIN_VALUE);
                                                                                            assertEquals(BigInteger.valueOf(Integer.MIN_VALUE), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testOne() {
                                                                                            BigFraction fraction = new BigFraction(1);
                                                                                            assertEquals(BigFraction.ONE, fraction);
                                                                                        }

    @Test
                                                                                        public void testTwo() {
                                                                                            BigFraction fraction = new BigFraction(2);
                                                                                            assertEquals(BigFraction.TWO, fraction);
                                                                                        }

    @Test
                                                                                        public void testMinusOne() {
                                                                                            BigFraction fraction = new BigFraction(-1);
                                                                                            assertEquals(BigFraction.MINUS_ONE, fraction);
                                                                                        }

    @Test
                                                                                        public void testEquals() {
                                                                                            BigFraction fraction1 = new BigFraction(10);
                                                                                            BigFraction fraction2 = new BigFraction(10);
                                                                                            assertEquals(fraction1, fraction2);
                                                                                        }

    @Test
                                                                                        public void testNotEquals() {
                                                                                            BigFraction fraction1 = new BigFraction(10);
                                                                                            BigFraction fraction2 = new BigFraction(20);
                                                                                            assertNotEquals(fraction1, fraction2);
                                                                                        }

    @Test
                                                                                        public void testToString() {
                                                                                            BigFraction fraction = new BigFraction(7);
                                                                                            assertEquals("7", fraction.toString());
                                                                                        }

    @Test
                                                                                        public void testDoubleValue() {
                                                                                            BigFraction fraction = new BigFraction(3);
                                                                                            assertEquals(3.0, fraction.doubleValue(), 0.00001);
                                                                                        }

    @Test
                                                                                        public void testIntValue() {
                                                                                            BigFraction fraction = new BigFraction(42);
                                                                                            assertEquals(42, fraction.intValue());
                                                                                        }

    @Test
                                                                                        public void testLongValue() {
                                                                                            BigFraction fraction = new BigFraction(123456789);
                                                                                            assertEquals(123456789L, fraction.longValue());
                                                                                        }

    @Test
                                                                                        public void testFloatValue() {
                                                                                            BigFraction fraction = new BigFraction(5);
                                                                                            assertEquals(5.0f, fraction.floatValue(), 0.00001f);
                                                                                        }

    @Test
                                                                                        public void testCompareTo() {
                                                                                            BigFraction fraction1 = new BigFraction(5);
                                                                                            BigFraction fraction2 = new BigFraction(10);
                                                                                            assertTrue(fraction1.compareTo(fraction2) < 0);
                                                                                            assertTrue(fraction2.compareTo(fraction1) > 0);
                                                                                            assertEquals(0, fraction1.compareTo(new BigFraction(5)));
                                                                                        }

    @Test
                                                                                        public void testConstructorWithPositiveValues() {
                                                                                            BigFraction fraction = new BigFraction(3, 4);
                                                                                            assertEquals(BigInteger.valueOf(3), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(4), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithNegativeNumerator1() {
                                                                                            BigFraction fraction = new BigFraction(-3, 4);
                                                                                            assertEquals(BigInteger.valueOf(-3), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(4), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithNegativeDenominator1() {
                                                                                            BigFraction fraction = new BigFraction(3, -4);
                                                                                            assertEquals(BigInteger.valueOf(-3), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(4), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithBothNegative1() {
                                                                                            BigFraction fraction = new BigFraction(-3, -4);
                                                                                            assertEquals(BigInteger.valueOf(3), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(4), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithZeroNumerator1() {
                                                                                            BigFraction fraction = new BigFraction(0, 5);
                                                                                            assertEquals(BigInteger.ZERO, fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test(expected = ZeroException.class)
                                                                                        public void testConstructorWithZeroDenominator1() {
                                                                                            new BigFraction(3, 0);
                                                                                        }

    @Test
                                                                                        public void testConstructorReducesFraction1() {
                                                                                            BigFraction fraction = new BigFraction(6, 8);
                                                                                            assertEquals(BigInteger.valueOf(3), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(4), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithMaxIntValues() {
                                                                                            BigFraction fraction = new BigFraction(Integer.MAX_VALUE, Integer.MAX_VALUE);
                                                                                            assertEquals(BigInteger.ONE, fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithMinIntValues() {
                                                                                            BigFraction fraction = new BigFraction(Integer.MIN_VALUE, Integer.MIN_VALUE);
                                                                                            assertEquals(BigInteger.ONE, fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithCommonFactor() {
                                                                                            BigFraction fraction = new BigFraction(15, 25);
                                                                                            assertEquals(BigInteger.valueOf(3), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(5), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithDenominatorOne() {
                                                                                            BigFraction fraction = new BigFraction(7, 1);
                                                                                            assertEquals(BigInteger.valueOf(7), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithZero2() {
                                                                                            BigFraction fraction = new BigFraction(0L);
                                                                                            assertEquals(BigInteger.ZERO, fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithPositiveValue() {
                                                                                            BigFraction fraction = new BigFraction(42L);
                                                                                            assertEquals(BigInteger.valueOf(42L), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithNegativeValue1() {
                                                                                            BigFraction fraction = new BigFraction(-123L);
                                                                                            assertEquals(BigInteger.valueOf(-123L), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithMaxLongValue() {
                                                                                            BigFraction fraction = new BigFraction(Long.MAX_VALUE);
                                                                                            assertEquals(BigInteger.valueOf(Long.MAX_VALUE), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithMinLongValue() {
                                                                                            BigFraction fraction = new BigFraction(Long.MIN_VALUE);
                                                                                            assertEquals(BigInteger.valueOf(Long.MIN_VALUE), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testEqualsWithSameValue() {
                                                                                            BigFraction fraction1 = new BigFraction(100L);
                                                                                            BigFraction fraction2 = new BigFraction(100L);
                                                                                            assertEquals(fraction1, fraction2);
                                                                                        }

    @Test
                                                                                        public void testNotEqualsWithDifferentValues() {
                                                                                            BigFraction fraction1 = new BigFraction(100L);
                                                                                            BigFraction fraction2 = new BigFraction(101L);
                                                                                            assertNotEquals(fraction1, fraction2);
                                                                                        }

    @Test
                                                                                        public void testToStringWithLongValue() {
                                                                                            BigFraction fraction = new BigFraction(987654321L);
                                                                                            assertEquals("987654321", fraction.toString());
                                                                                        }

    @Test
                                                                                        public void testIntValue1() {
                                                                                            BigFraction fraction = new BigFraction(123456789L);
                                                                                            assertEquals(123456789, fraction.intValue());
                                                                                        }

    @Test
                                                                                        public void testLongValue1() {
                                                                                            BigFraction fraction = new BigFraction(9876543210L);
                                                                                            assertEquals(9876543210L, fraction.longValue());
                                                                                        }

    @Test
                                                                                        public void testDoubleValue1() {
                                                                                            BigFraction fraction = new BigFraction(5L);
                                                                                            assertEquals(5.0, fraction.doubleValue(), 0.00001);
                                                                                        }

    @Test
                                                                                        public void testFloatValue1() {
                                                                                            BigFraction fraction = new BigFraction(3L);
                                                                                            assertEquals(3.0f, fraction.floatValue(), 0.00001f);
                                                                                        }

    @Test
                                                                                        public void testConstructorWithPositiveValues1() {
                                                                                            BigFraction fraction = new BigFraction(3L, 4L);
                                                                                            assertEquals(BigInteger.valueOf(3), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(4), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithNegativeNumerator2() {
                                                                                            BigFraction fraction = new BigFraction(-3L, 4L);
                                                                                            assertEquals(BigInteger.valueOf(-3), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(4), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithNegativeDenominator2() {
                                                                                            BigFraction fraction = new BigFraction(3L, -4L);
                                                                                            assertEquals(BigInteger.valueOf(-3), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(4), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithBothNegative2() {
                                                                                            BigFraction fraction = new BigFraction(-3L, -4L);
                                                                                            assertEquals(BigInteger.valueOf(3), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(4), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithZeroNumerator2() {
                                                                                            BigFraction fraction = new BigFraction(0L, 4L);
                                                                                            assertEquals(BigInteger.ZERO, fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test(expected = ZeroException.class)
                                                                                        public void testConstructorWithZeroDenominator2() {
                                                                                            new BigFraction(3L, 0L);
                                                                                        }

    @Test
                                                                                        public void testConstructorReducesFraction2() {
                                                                                            BigFraction fraction = new BigFraction(6L, 8L);
                                                                                            assertEquals(BigInteger.valueOf(3), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(4), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithLargeValues() {
                                                                                            BigFraction fraction = new BigFraction(Long.MAX_VALUE, Long.MAX_VALUE - 1);
                                                                                            assertEquals(BigInteger.valueOf(Long.MAX_VALUE), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(Long.MAX_VALUE - 1), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithMinValues() {
                                                                                            BigFraction fraction = new BigFraction(Long.MIN_VALUE, Long.MIN_VALUE + 1);
                                                                                            assertEquals(BigInteger.valueOf(Long.MIN_VALUE), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.valueOf(Long.MIN_VALUE + 1).negate(), fraction.getDenominator());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithDenominatorOne1() {
                                                                                            BigFraction fraction = new BigFraction(5L, 1L);
                                                                                            assertEquals(BigInteger.valueOf(5), fraction.getNumerator());
                                                                                            assertEquals(BigInteger.ONE, fraction.getDenominator());
                                                                                        }

    @Test
                                                                        public void testVerySmallValue() throws Exception {
                                                                            BigFraction fraction = new BigFraction(1, 1000000);
                                                                            assertTrue(fraction.doubleValue() > 0);
                                                                        }

    @Test
                                                            public void testFractionWithMaxDenominator() throws Exception {
                                                                double value = 0.333333;
                                                                double epsilon = 0.0001;
                                                                int maxIterations = 10;
                                                                int maxDenominator = 100;
                                                                
                                                                Constructor<BigFraction> constructor = BigFraction.class.getDeclaredConstructor(
                                                                    double.class, double.class, int.class, int.class);
                                                                constructor.setAccessible(true);
                                                                BigFraction fraction = constructor.newInstance(value, epsilon, maxIterations, maxDenominator);
                                                                
                                                                assertEquals(BigInteger.valueOf(1), fraction.getNumerator());
                                                                assertEquals(BigInteger.valueOf(3), fraction.getDenominator());
                                                            }

    @Test
                                                    public void testGoldenRatio() throws Exception {
                                                        double goldenRatio = (1 + Math.sqrt(5)) / 2;
                                                        BigFraction fraction = new BigFraction(goldenRatio, 0.0001, 100);
                                                        assertEquals(BigInteger.valueOf(89), fraction.getNumerator());
                                                        assertEquals(BigInteger.valueOf(55), fraction.getDenominator());
                                                    }

    @Test
                                                    public void testVerySmallEpsilon() throws Exception {
                                                        BigFraction fraction = new BigFraction(0.123456789, 0.0000000001, 100);
                                                        assertEquals(0.123456789, fraction.doubleValue(), 0.0000000001);
                                                    }

    @Test
                                                public void testOverflow() throws Exception {
                                                    double value = Double.MAX_VALUE;
                                                    double epsilon = 0.0001;
                                                    int maxIterations = Integer.MAX_VALUE;
                                                    int maxDenominator = 100;
                                                    
                                                }

    @Test
                                                public void testDenominatorOverflow() {
                                                    double value = 0.123456789;
                                                    double epsilon = 0.000000001;
                                                    int maxIterations = Integer.MAX_VALUE;
                                                    int maxDenominator = 100;
                                                    
                                                }

    @Test
                                                public void testExceptionMessages() {
                                                    try {
                                                        new BigFraction(Double.NaN);
                                                        fail("Expected MathIllegalArgumentException");
                                                    } catch (MathIllegalArgumentException e) {
                                                    }
                                                    
                                                    try {
                                                        new BigFraction(Double.POSITIVE_INFINITY);
                                                        fail("Expected MathIllegalArgumentException");
                                                    } catch (MathIllegalArgumentException e) {
                                                    }
                                                }

    @Test(expected = FractionConversionException.class)
                                                public void testMaxIterationsExceeded() throws Exception {
                                                    double value = Math.PI;
                                                    double epsilon = 0.0000001;
                                                    int maxIterations = Integer.MAX_VALUE;
                                                    long maxDenominator = Long.MAX_VALUE;
                                                    
                                                    try {
                                                    } catch (FractionConversionException e) {
                                                        throw e;
                                                    }
                                                }

    @Test
                                            public void testLargeDenominatorWithinLimit() throws Exception {
                                                double value = 0.123456789;
                                                double epsilon = 0.0000001;
                                                int maxIterations = 100;
                                                int maxDenominator = 1000000;
                                                BigFraction fraction = new BigFraction(value, epsilon, maxIterations);
                                                
                                                assertTrue(fraction.getDenominator().intValue() <= maxDenominator);
                                            }

    @Test
                                            public void testDenominatorWithinLimit() throws Exception {
                                                double value = 0.123456;
                                                double epsilon = 0.0001;
                                                int maxIterations = 100;
                                                int maxDenominator = 100;
                                                
                                                BigFraction fraction = new BigFraction(value, epsilon, maxIterations);
                                                assertTrue(fraction.getDenominator().intValue() <= maxDenominator);
                                            }

    @Test
                                public void testPrecisionWithinEpsilon() throws Exception {
                                    double value = 0.123456789;
                                    double epsilon = 0.0001;
                                    int maxIterations = 1000;
                                    int maxDenominator = 100;
                                    
                                    BigFraction fraction = new BigFraction(value, epsilon, maxIterations);
                                    double actualValue = fraction.doubleValue();
                                    assertEquals(0.123456789, actualValue, 0.0001);
                                }

    @Test
        public void testZeroEpsilon() {
            double value = 0.333333;
            double epsilon = 0.0;
            int maxIterations = 100;
            int maxDenominator = 100;
            
            
        }

    @Test
        public void testIntegerValue() throws Exception {
            double value = 5.0;
            double epsilon = 0.0001;
            int maxIterations = 100;
            int maxDenominator = 10;
        }

    @Test
        public void testNegativeValue() throws Exception {
            double value = -0.5;
            double epsilon = 0.0001;
            int maxIterations = 100;
            int maxDenominator = 10;
            
        }

    @Test
        public void testAlmostIntegerValue() throws Exception {
            double value = 5.0000001;
            double epsilon = 0.0001;
            int maxIterations = 100;
            int maxDenominator = 10;
            
            
        }

    @Test
        public void testSimpleFraction() throws Exception {
            double value = 0.5;
            double epsilon = 0.0001;
            int maxIterations = 100;
            int maxDenominator = 10;
            
            
        }


}
