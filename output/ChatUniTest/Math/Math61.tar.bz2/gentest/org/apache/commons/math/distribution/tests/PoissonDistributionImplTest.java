package gentest.org.apache.commons.math.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.distribution.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.exception.NotStrictlyPositiveException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.special.Gamma;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class PoissonDistributionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test(expected = IllegalArgumentException.class)
                public void testConstructorWithNegativeMean() {
                    int TEST_MAX_ITERATIONS = 1000;
                    new PoissonDistributionImpl(-1.0, TEST_MAX_ITERATIONS);
                }

    @Test
            public void testConstructorWithZeroMean() {
                double TEST_MAX_ITERATIONS = 1000;
                new PoissonDistributionImpl(0.0, TEST_MAX_ITERATIONS);
            }

    @Test
            public void testConstructorWithDifferentMaxIterations() throws Exception {
                int[] testIterations = {1, 10, 100, 1000, 1000000};
                for (int iterations : testIterations) {
                    PoissonDistributionImpl distribution = new PoissonDistributionImpl(2.5, iterations);
                    
                    // Define getMaxIterations helper method using reflection
                    Method getMaxIterationsMethod = PoissonDistributionImpl.class.getDeclaredMethod("getMaxIterations");
                    getMaxIterationsMethod.setAccessible(true);
                    int actualIterations = (int) getMaxIterationsMethod.invoke(distribution);
                    
                    assertEquals("Max iterations should match constructor argument",
                                 iterations, actualIterations);
                }
            }

    @Test
        public void testConstructorWithMeanAndMaxIterations() throws Exception {
            double mean = 5.0;
            double TEST_EPSILON = 1e-12;
            int TEST_MAX_ITERATIONS = 1000;
            
            PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, TEST_MAX_ITERATIONS);
            
            assertEquals("Mean should match constructor argument", 
                        mean, distribution.getMean(), TEST_EPSILON);
            
            // Use reflection to access private getMaxIterations method
            Method getMaxIterationsMethod = PoissonDistributionImpl.class.getDeclaredMethod("getMaxIterations");
            getMaxIterationsMethod.setAccessible(true);
            int actualMaxIterations = (int) getMaxIterationsMethod.invoke(distribution);
            assertEquals("Max iterations should match constructor argument",
                        TEST_MAX_ITERATIONS, actualMaxIterations);
            
            // Use reflection to access private getEpsilon method
            Method getEpsilonMethod = PoissonDistributionImpl.class.getDeclaredMethod("getEpsilon");
            getEpsilonMethod.setAccessible(true);
            double actualEpsilon = (double) getEpsilonMethod.invoke(distribution);
            assertEquals("Default epsilon should be used",
                        PoissonDistributionImpl.DEFAULT_EPSILON, actualEpsilon, TEST_EPSILON);
        }


}
