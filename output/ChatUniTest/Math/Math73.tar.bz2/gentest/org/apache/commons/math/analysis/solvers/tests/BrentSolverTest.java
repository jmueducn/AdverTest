package gentest.org.apache.commons.math.analysis.solvers.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.analysis.solvers.*;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.analysis.UnivariateRealFunction;
 
public class BrentSolverTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                    public void testSolveWhenMinIsRoot() throws Exception {
                                                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                        BrentSolver solver = new BrentSolver();
                                                                                        
                                                                                        when(function.value(1.0)).thenReturn(0.0);
                                                                                        when(function.value(2.0)).thenReturn(1.0);
                                                                                
                                                                                        double result = solver.solve(function, 1.0, 2.0);
                                                                                        assertEquals(1.0, result, 0.0);
                                                                                    }

    @Test
                                                                                    public void testSolveWhenMaxIsRoot() throws Exception {
                                                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                        BrentSolver solver = new BrentSolver();
                                                                                        
                                                                                        when(function.value(1.0)).thenReturn(-1.0);
                                                                                        when(function.value(2.0)).thenReturn(0.0);
                                                                                
                                                                                        double result = solver.solve(function, 1.0, 2.0);
                                                                                        assertEquals(2.0, result, 0.0);
                                                                                    }

    @Test
                                                                                    public void testSolveWhenFunctionValuesHaveOppositeSigns() throws Exception {
                                                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                        BrentSolver solver = new BrentSolver();
                                                                                        
                                                                                        when(function.value(1.0)).thenReturn(-1.0);
                                                                                        when(function.value(2.0)).thenReturn(1.0);
                                                                                        when(function.value(anyDouble())).thenReturn(0.0);
                                                                                        
                                                                                        double result = solver.solve(function, 1.0, 2.0);
                                                                                        assertNotEquals(Double.NaN, result, 0.0);
                                                                                    }

    @Test(expected = org.apache.commons.math.FunctionEvaluationException.class)
                                                                                    public void testSolveWhenFunctionValuesHaveSameSign() throws Exception {
                                                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                        BrentSolver solver = new BrentSolver();
                                                                                        
                                                                                        when(function.value(1.0)).thenReturn(1.0);
                                                                                        when(function.value(2.0)).thenReturn(2.0);
                                                                                
                                                                                        solver.solve(function, 1.0, 2.0);
                                                                                    }

    @Test
                                                                                    public void testSolveWhenMinEqualsMax() throws Exception {
                                                                                        BrentSolver solver = new BrentSolver();
                                                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                        solver.solve(function, 1.0, 1.0);
                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                    public void testSolveWhenMinGreaterThanMax() throws Exception {
                                                                                        BrentSolver solver = new BrentSolver();
                                                                                        UnivariateRealFunction function = new UnivariateRealFunction() {
                                                                                            public double value(double x) {
                                                                                                return x;
                                                                                            }
                                                                                        };
                                                                                        solver.solve(function, 2.0, 1.0);
                                                                                    }

    @Test(expected = org.apache.commons.math.MaxIterationsExceededException.class)
                                                                                    public void testSolveWhenMaxIterationsExceeded() throws Exception {
                                                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                        when(function.value(1.0)).thenReturn(-1.0);
                                                                                        when(function.value(2.0)).thenReturn(1.0);
                                                                                        when(function.value(anyDouble())).thenReturn(0.5);
                                                                                
                                                                                        BrentSolver limitedSolver = new BrentSolver();
                                                                                        limitedSolver.setMaximalIterationCount(1);
                                                                                        limitedSolver.solve(function, 1.0, 2.0);
                                                                                    }

    @Test(expected = FunctionEvaluationException.class)
                                                                                    public void testSolveWhenFunctionEvaluationFails() throws Exception {
                                                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                        BrentSolver solver = new BrentSolver();
                                                                                        
                                                                                        when(function.value(1.0)).thenReturn(-1.0);
                                                                                        when(function.value(2.0)).thenThrow(new FunctionEvaluationException(2.0));
                                                                                
                                                                                        solver.solve(function, 1.0, 2.0);
                                                                                    }

    @Test
                                                                                    public void testDeprecatedSolveMethod() throws Exception {
                                                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                        BrentSolver deprecatedSolver = new BrentSolver(function);
                                                                                        when(function.value(1.0)).thenReturn(-1.0);
                                                                                        when(function.value(2.0)).thenReturn(1.0);
                                                                                        when(function.value(anyDouble())).thenReturn(0.0);
                                                                                    
                                                                                        double result = deprecatedSolver.solve(1.0, 2.0);
                                                                                        assertNotEquals(Double.NaN, result, 0.0);
                                                                                    }

    @Test
                                                                                    public void testSolveReturnsInitialWhenFunctionValueIsZero() throws Exception {
                                                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                        BrentSolver solver = new BrentSolver();
                                                                                        
                                                                                        when(function.value(1.5)).thenReturn(0.0);
                                                                                        double result = solver.solve(function, 1.0, 2.0, 1.5);
                                                                                        assertEquals(1.5, result, 0.0);
                                                                                    }

    @Test
                                                                                    public void testSolveReturnsMinWhenFunctionValueAtMinIsZero() throws Exception {
                                                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                        BrentSolver solver = new BrentSolver();
                                                                                        
                                                                                        when(function.value(1.0)).thenReturn(0.0);
                                                                                        when(function.value(1.5)).thenReturn(1.0);
                                                                                        double result = solver.solve(function, 1.0, 2.0, 1.5);
                                                                                        assertEquals(1.0, result, 0.0);
                                                                                    }

    @Test
                                                                                    public void testSolveReturnsMaxWhenFunctionValueAtMaxIsZero() throws Exception {
                                                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                        BrentSolver solver = new BrentSolver();
                                                                                        
                                                                                        when(function.value(2.0)).thenReturn(0.0);
                                                                                        when(function.value(1.5)).thenReturn(1.0);
                                                                                        when(function.value(1.0)).thenReturn(1.0);
                                                                                        double result = solver.solve(function, 1.0, 2.0, 1.5);
                                                                                        assertEquals(2.0, result, 0.0);
                                                                                    }

    @Test(expected = org.apache.commons.math.FunctionEvaluationException.class)
                                                                                    public void testSolveThrowsExceptionWhenNoBracketing() throws Exception {
                                                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                        BrentSolver solver = new BrentSolver();
                                                                                        
                                                                                        when(function.value(1.0)).thenReturn(1.0);
                                                                                        when(function.value(1.5)).thenReturn(1.0);
                                                                                        when(function.value(2.0)).thenReturn(1.0);
                                                                                        solver.solve(function, 1.0, 2.0, 1.5);
                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                    public void testSolveThrowsExceptionWhenInitialNotBetweenMinMax() throws Exception {
                                                                                        BrentSolver solver = new BrentSolver();
                                                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                        solver.solve(function, 1.0, 2.0, 0.5);
                                                                                    }

    @Test(expected = MaxIterationsExceededException.class)
                                                                                    public void testSolveThrowsMaxIterationsExceeded() throws Exception {
                                                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                        when(function.value(1.0)).thenReturn(-1.0);
                                                                                        when(function.value(1.5)).thenReturn(1.0);
                                                                                        when(function.value(2.0)).thenReturn(2.0);
                                                                                        
                                                                                        BrentSolver solverWithOneIteration = new BrentSolver();
                                                                                        solverWithOneIteration.setMaximalIterationCount(1);
                                                                                        
                                                                                        // Mock the private solve method to throw exception
                                                                                        BrentSolver spySolver = spy(solverWithOneIteration);
                                                                                        doThrow(new MaxIterationsExceededException(1))
                                                                                            .when(spySolver).solve(any(UnivariateRealFunction.class), anyDouble(), anyDouble());
                                                                                        
                                                                                        spySolver.solve(function, 1.0, 2.0, 1.5);
                                                                                    }

    @Test(expected = FunctionEvaluationException.class)
                                                                                    public void testSolveThrowsFunctionEvaluationException() throws Exception {
                                                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                        BrentSolver solver = new BrentSolver();
                                                                                        
                                                                                        when(function.value(1.0)).thenReturn(-1.0);
                                                                                        when(function.value(1.5)).thenThrow(new FunctionEvaluationException(1.5));
                                                                                        solver.solve(function, 1.0, 2.0, 1.5);
                                                                                    }

    @Test
                                                                                    public void testDeprecatedSolveWithInitial() throws Exception {
                                                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                        when(function.value(1.0)).thenReturn(-1.0);
                                                                                        when(function.value(1.5)).thenReturn(1.0);
                                                                                        when(function.value(2.0)).thenReturn(2.0);
                                                                                        
                                                                                        BrentSolver solverWithFunction = new BrentSolver(function);
                                                                                        BrentSolver spySolver = spy(solverWithFunction);
                                                                                        
                                                                                        // Use reflection to access private solve method
                                                                                        Method privateSolve = BrentSolver.class.getDeclaredMethod(
                                                                                            "solve", 
                                                                                            UnivariateRealFunction.class, 
                                                                                            double.class, 
                                                                                            double.class, 
                                                                                            double.class, 
                                                                                            double.class, 
                                                                                            double.class, 
                                                                                            double.class
                                                                                        );
                                                                                        privateSolve.setAccessible(true);
                                                                                        
                                                                                        when(privateSolve.invoke(
                                                                                            spySolver, 
                                                                                            any(UnivariateRealFunction.class), 
                                                                                            anyDouble(), 
                                                                                            anyDouble(), 
                                                                                            anyDouble(), 
                                                                                            anyDouble(), 
                                                                                            anyDouble(), 
                                                                                            anyDouble()
                                                                                        )).thenReturn(1.25);
                                                                                        
                                                                                        double result = spySolver.solve(1.0, 2.0, 1.5);
                                                                                        assertEquals(1.25, result, 0.0);
                                                                                    }

    @Test
                                                                                    public void testSolve_InitialGuessIsSolution() throws Exception {
                                                                                        // Define constants
                                                                                        final double MIN = -1.0;
                                                                                        final double MAX = 1.0;
                                                                                        final double INITIAL = 0.0;
                                                                                        
                                                                                        // Create mock function
                                                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                        
                                                                                        // Create solver instance
                                                                                        BrentSolver solver = new BrentSolver();
                                                                                        
                                                                                        // Set up mock behavior
                                                                                        when(function.value(INITIAL)).thenReturn(0.0);
                                                                                        
                                                                                        // Execute test
                                                                                        double result = solver.solve(function, MIN, MAX, INITIAL);
                                                                                        
                                                                                        // Verify results
                                                                                        assertEquals(INITIAL, result, 0.0);
                                                                                        verify(function).value(INITIAL);
                                                                                        verify(function, never()).value(MIN);
                                                                                        verify(function, never()).value(MAX);
                                                                                    }

    @Test
                                                                                    public void testSolve_MinIsSolution() throws Exception {
                                                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                        BrentSolver solver = new BrentSolver();
                                                                                        
                                                                                        double MIN = 0.0;
                                                                                        double MAX = 10.0;
                                                                                        double INITIAL = 5.0;
                                                                                        
                                                                                        when(function.value(INITIAL)).thenReturn(1.0);
                                                                                        when(function.value(MIN)).thenReturn(0.0);
                                                                                        
                                                                                        double result = solver.solve(function, MIN, MAX, INITIAL);
                                                                                        
                                                                                        assertEquals(MIN, result, 0.0);
                                                                                        verify(function).value(INITIAL);
                                                                                        verify(function).value(MIN);
                                                                                        verify(function, never()).value(MAX);
                                                                                    }

    @Test
                                                                                public void testSolve_MaxIsSolution() throws Exception {
                                                                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                    BrentSolver solver = new BrentSolver();
                                                                                    
                                                                                    double MIN = 0.0;
                                                                                    double MAX = 2.0;
                                                                                    double INITIAL = 1.0;
                                                                                    
                                                                                    when(function.value(INITIAL)).thenReturn(1.0);
                                                                                    when(function.value(MIN)).thenReturn(1.0);
                                                                                    when(function.value(MAX)).thenReturn(0.0);
                                                                                    
                                                                                    double result = solver.solve(function, MIN, MAX, INITIAL);
                                                                                    
                                                                                    assertEquals(MAX, result, 0.0);
                                                                                    verify(function).value(INITIAL);
                                                                                    verify(function).value(MIN);
                                                                                    verify(function).value(MAX);
                                                                                }

    @Test
                                                                                public void testSolveWithRootAtMax() throws Exception {
                                                                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                    BrentSolver solver = new BrentSolver();
                                                                                    
                                                                                    when(function.value(1.0)).thenReturn(-1.0);
                                                                                    when(function.value(2.0)).thenReturn(0.0);
                                                                            
                                                                                    double result = solver.solve(function, 1.0, 2.0);
                                                                                    assertEquals(2.0, result, 0.0);
                                                                                }

    @Test
                                                                            public void testSolveWithBracketing() throws Exception {
                                                                                // Create mock function
                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                when(function.value(1.0)).thenReturn(-1.0);
                                                                                when(function.value(2.0)).thenReturn(1.0);
                                                                                when(function.value(1.5)).thenReturn(0.0);
                                                                                
                                                                                // Create solver instance
                                                                                BrentSolver solver = new BrentSolver();
                                                                                
                                                                                double result = solver.solve(function, 1.0, 2.0);
                                                                                assertEquals(1.5, result, 0.0);
                                                                            }

    @Test
                                                                            public void testSolveWithYMaxZero() throws Exception {
                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                BrentSolver solver = new BrentSolver();
                                                                                
                                                                                when(function.value(1.0)).thenReturn(0.0);
                                                                                when(function.value(2.0)).thenReturn(0.0);
                                                                                
                                                                                // This will test the else branch where yMin is not zero but yMax is
                                                                                // We need to make sure yMin is not exactly zero but close to it
                                                                                when(function.value(1.0)).thenReturn(1e-20);
                                                                                
                                                                                double result = solver.solve(function, 1.0, 2.0);
                                                                                assertEquals(2.0, result, 0.0);
                                                                            }

    @Test
                                                                            public void testSolveConvergesWithTolerance() throws Exception {
                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                when(function.value(1.0)).thenReturn(0.1);
                                                                                when(function.value(1.000001)).thenReturn(0.0);
                                                                                
                                                                                BrentSolver solver = new BrentSolver();
                                                                                Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                    "solve", 
                                                                                    UnivariateRealFunction.class,
                                                                                    double.class, double.class,
                                                                                    double.class, double.class,
                                                                                    double.class, double.class
                                                                                );
                                                                                solveMethod.setAccessible(true);
                                                                                
                                                                                double result = (double) solveMethod.invoke(
                                                                                    solver, 
                                                                                    function,
                                                                                    0.0, 1.0,
                                                                                    1.0, 0.1,
                                                                                    2.0, 1.0
                                                                                );
                                                                                
                                                                                assertEquals(1.0, result, 0.0001);
                                                                            }

    @Test
                                                                            public void testSolveUsesBisectionWhenProgressIsSlow() throws Exception {
                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                BrentSolver solver = new BrentSolver();
                                                                                
                                                                                Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                    "solve", 
                                                                                    UnivariateRealFunction.class, 
                                                                                    double.class, double.class, 
                                                                                    double.class, double.class, 
                                                                                    double.class, double.class
                                                                                );
                                                                                solveMethod.setAccessible(true);
                                                                        
                                                                                when(function.value(1.0)).thenReturn(0.5);
                                                                                when(function.value(1.5)).thenReturn(0.25);
                                                                                when(function.value(1.75)).thenReturn(0.125);
                                                                                when(function.value(1.875)).thenReturn(0.0);
                                                                                
                                                                                double result = (double) solveMethod.invoke(
                                                                                    solver, 
                                                                                    function, 
                                                                                    0.0, 1.0, 
                                                                                    1.0, 0.5, 
                                                                                    2.0, 1.0
                                                                                );
                                                                                
                                                                                assertEquals(1.875, result, 0.001);
                                                                            }

    @Test
                                                                            public void testSolveUsesLinearInterpolation() throws Exception {
                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                BrentSolver solver = new BrentSolver();
                                                                                
                                                                                Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                    "solve", 
                                                                                    UnivariateRealFunction.class, 
                                                                                    double.class, double.class, 
                                                                                    double.class, double.class,
                                                                                    double.class, double.class
                                                                                );
                                                                                solveMethod.setAccessible(true);
                                                                        
                                                                                when(function.value(1.0)).thenReturn(0.5);
                                                                                when(function.value(1.5)).thenReturn(0.25);
                                                                                when(function.value(1.666)).thenReturn(0.0);
                                                                                
                                                                                double result = (double) solveMethod.invoke(
                                                                                    solver,
                                                                                    function,
                                                                                    1.0, 0.5,
                                                                                    2.0, 1.0,
                                                                                    1.0, 0.5
                                                                                );
                                                                                
                                                                                assertEquals(1.666, result, 0.001);
                                                                            }

    @Test
                                                                            public void testSolveUsesInverseQuadraticInterpolation() throws Exception {
                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                BrentSolver solver = new BrentSolver();
                                                                                
                                                                                Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                    "solve", 
                                                                                    UnivariateRealFunction.class, 
                                                                                    double.class, double.class, 
                                                                                    double.class, double.class, 
                                                                                    double.class, double.class
                                                                                );
                                                                                solveMethod.setAccessible(true);
                                                                        
                                                                                when(function.value(1.0)).thenReturn(0.5);
                                                                                when(function.value(1.5)).thenReturn(0.25);
                                                                                when(function.value(1.8)).thenReturn(0.1);
                                                                                when(function.value(1.9)).thenReturn(0.0);
                                                                                
                                                                                double result = (double) solveMethod.invoke(
                                                                                    solver, 
                                                                                    function, 
                                                                                    0.0, 1.0, 
                                                                                    1.0, 0.5, 
                                                                                    2.0, 1.0
                                                                                );
                                                                                
                                                                                assertEquals(1.9, result, 0.1);
                                                                            }

    @Test
                                                                            public void testSolveSwapsPointsWhenY2IsBetter() throws Exception {
                                                                                // Create mock function
                                                                                org.apache.commons.math.analysis.UnivariateRealFunction function = 
                                                                                    mock(org.apache.commons.math.analysis.UnivariateRealFunction.class);
                                                                                
                                                                                // Setup mock behavior
                                                                                when(function.value(1.0)).thenReturn(0.1);
                                                                                when(function.value(0.5)).thenReturn(0.05);
                                                                                when(function.value(0.25)).thenReturn(0.0);
                                                                                
                                                                                // Create solver instance
                                                                                org.apache.commons.math.analysis.solvers.BrentSolver solver = 
                                                                                    new org.apache.commons.math.analysis.solvers.BrentSolver();
                                                                                
                                                                                // Get private solve method via reflection
                                                                                Method solveMethod = org.apache.commons.math.analysis.solvers.BrentSolver.class
                                                                                    .getDeclaredMethod("solve", 
                                                                                        org.apache.commons.math.analysis.UnivariateRealFunction.class,
                                                                                        double.class, double.class,
                                                                                        double.class, double.class,
                                                                                        double.class, double.class);
                                                                                solveMethod.setAccessible(true);
                                                                                
                                                                                // Invoke the method
                                                                                double result = (double) solveMethod.invoke(
                                                                                    solver,
                                                                                    function,
                                                                                    0.0, 1.0,
                                                                                    1.0, 0.1,
                                                                                    0.5, 0.05
                                                                                );
                                                                                
                                                                                // Verify result
                                                                                assertEquals(0.25, result, 0.01);
                                                                            }

    @Test
                                                                            public void testSolveHandlesNegativeValues() throws Exception {
                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                BrentSolver solver = new BrentSolver();
                                                                                
                                                                                Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                    "solve", 
                                                                                    UnivariateRealFunction.class, 
                                                                                    double.class, 
                                                                                    double.class, 
                                                                                    double.class, 
                                                                                    double.class
                                                                                );
                                                                                solveMethod.setAccessible(true);
                                                                        
                                                                                when(function.value(-1.0)).thenReturn(-0.5);
                                                                                when(function.value(-0.5)).thenReturn(-0.25);
                                                                                when(function.value(-0.25)).thenReturn(0.0);
                                                                                
                                                                                double result = (double) solveMethod.invoke(
                                                                                    solver,
                                                                                    function,
                                                                                    -2.0, -1.0,
                                                                                    -1.0, -0.5
                                                                                );
                                                                                
                                                                                assertEquals(-0.25, result, 0.01);
                                                                            }

    @Test
                                                                            public void testSolveWhenMinAndInitialBracketRoot() throws Exception {
                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                BrentSolver solver = new BrentSolver();
                                                                                
                                                                                when(function.value(1.0)).thenReturn(-1.0);
                                                                                when(function.value(1.5)).thenReturn(1.0);
                                                                                when(function.value(2.0)).thenReturn(2.0);
                                                                                
                                                                                // Mock the private solve method behavior
                                                                                BrentSolver spySolver = spy(solver);
                                                                                doReturn(1.25).when(spySolver).solve(
                                                                                    any(UnivariateRealFunction.class), 
                                                                                    anyDouble(), 
                                                                                    anyDouble(), 
                                                                                    anyDouble()
                                                                                );
                                                                                
                                                                                double result = spySolver.solve(function, 1.0, 2.0, 1.5);
                                                                                assertEquals(1.25, result, 0.0);
                                                                            }

    @Test
                                                                            public void testSolveWhenInitialAndMaxBracketRoot() throws Exception {
                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                BrentSolver solver = new BrentSolver();
                                                                                
                                                                                when(function.value(1.0)).thenReturn(1.0);
                                                                                when(function.value(1.5)).thenReturn(-1.0);
                                                                                when(function.value(2.0)).thenReturn(1.0);
                                                                                
                                                                                // Mock the private solve method behavior
                                                                                BrentSolver spySolver = spy(solver);
                                                                                doReturn(1.75).when(spySolver).solve(
                                                                                                      any(UnivariateRealFunction.class), 
                                                                                                      anyDouble(), anyDouble(), anyDouble());
                                                                                
                                                                                double result = spySolver.solve(function, 1.0, 2.0, 1.5);
                                                                                assertEquals(1.75, result, 0.0);
                                                                            }

    @Test(expected = org.apache.commons.math.FunctionEvaluationException.class)
                                                                            public void testSolve_NonBracketingInterval() throws Exception {
                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                double MIN = 0.0;
                                                                                double MAX = 1.0;
                                                                                double INITIAL = 0.5;
                                                                                
                                                                                when(function.value(INITIAL)).thenReturn(1.0);
                                                                                when(function.value(MIN)).thenReturn(1.0);
                                                                                when(function.value(MAX)).thenReturn(1.0);
                                                                                
                                                                                BrentSolver solver = new BrentSolver();
                                                                                solver.solve(function, MIN, MAX, INITIAL);
                                                                            }

    @Test(expected = IllegalArgumentException.class)
                                                                            public void testSolve_InvalidSequence() throws Exception {
                                                                                BrentSolver solver = new BrentSolver();
                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                double MIN = 1.0;
                                                                                double MAX = 0.0;
                                                                                double INITIAL = 0.5;
                                                                                
                                                                                when(function.value(MIN)).thenReturn(1.0);
                                                                                when(function.value(MAX)).thenReturn(1.0);
                                                                                when(function.value(INITIAL)).thenReturn(1.0);
                                                                                
                                                                                solver.solve(function, MAX, MIN, INITIAL);
                                                                            }

    @Test
                                                                        public void testSolveConvergesWithFunctionValueAccuracy() throws Exception {
                                                                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                            BrentSolver solver = new BrentSolver();
                                                                            
                                                                            Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                "solve", 
                                                                                UnivariateRealFunction.class, 
                                                                                double.class, 
                                                                                double.class, 
                                                                                double.class, 
                                                                                double.class, 
                                                                                double.class, 
                                                                                double.class
                                                                            );
                                                                            solveMethod.setAccessible(true);
                                                                    
                                                                            when(function.value(1.0)).thenReturn(0.0);
                                                                            
                                                                            double result = (double) solveMethod.invoke(
                                                                                solver, 
                                                                                function, 
                                                                                0.0, 1.0,
                                                                                1.0, 0.0,
                                                                                2.0, 1.0
                                                                            );
                                                                            
                                                                            assertEquals(1.0, result, 0.0);
                                                                        }

    @Test
                                                                        public void testSolve_MinAndInitialBracketRoot() throws Exception {
                                                                            // Define constants inside the method
                                                                            double MIN = 0.0;
                                                                            double MAX = 2.0;
                                                                            double INITIAL = 1.0;
                                                                            
                                                                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                            BrentSolver solver = new BrentSolver();
                                                                            
                                                                            when(function.value(INITIAL)).thenReturn(-1.0);
                                                                            when(function.value(MIN)).thenReturn(1.0);
                                                                            when(function.value(MAX)).thenReturn(1.0);
                                                                            
                                                                            // Use reflection to access private solve method
                                                                            Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                "solve", 
                                                                                UnivariateRealFunction.class, 
                                                                                double.class, 
                                                                                double.class, 
                                                                                double.class, 
                                                                                double.class, 
                                                                                double.class, 
                                                                                double.class
                                                                            );
                                                                            solveMethod.setAccessible(true);
                                                                            
                                                                            // Mock the private solve method
                                                                            BrentSolver spySolver = spy(solver);
                                                                            doReturn(0.5).when(spySolver).solve(
                                                                                any(UnivariateRealFunction.class), 
                                                                                eq(MIN), 
                                                                                eq(MAX), 
                                                                                eq(INITIAL)
                                                                            );
                                                                            
                                                                            double result = spySolver.solve(function, MIN, MAX, INITIAL);
                                                                            
                                                                            assertEquals(0.5, result, 0.0);
                                                                            verify(function).value(INITIAL);
                                                                            verify(function).value(MIN);
                                                                            verify(function).value(MAX);
                                                                        }

    @Test
                                                                        public void testSolve_InitialAndMaxBracketRoot() throws Exception {
                                                                            // Define constants within the method
                                                                            final double INITIAL = 1.0;
                                                                            final double MIN = 0.0;
                                                                            final double MAX = 2.0;
                                                                            
                                                                            // Create mock function
                                                                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                            when(function.value(INITIAL)).thenReturn(-1.0);
                                                                            when(function.value(MIN)).thenReturn(-1.0);
                                                                            when(function.value(MAX)).thenReturn(1.0);
                                                                            
                                                                            // Create solver instance
                                                                            BrentSolver solver = new BrentSolver();
                                                                            
                                                                            // Get private solve method via reflection
                                                                            Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                "solve", 
                                                                                UnivariateRealFunction.class, 
                                                                                double.class, 
                                                                                double.class, 
                                                                                double.class, 
                                                                                double.class, 
                                                                                double.class, 
                                                                                double.class
                                                                            );
                                                                            solveMethod.setAccessible(true);
                                                                            
                                                                            // Create spy and mock the private method
                                                                            BrentSolver spySolver = spy(solver);
                                                                            when(spySolver.solve(
                                                                                any(UnivariateRealFunction.class), 
                                                                                eq(MIN), 
                                                                                eq(MAX), 
                                                                                eq(INITIAL)
                                                                            )).thenReturn(1.5);
                                                                            
                                                                            double result = spySolver.solve(function, MIN, MAX, INITIAL);
                                                                            
                                                                            assertEquals(1.5, result, 0.0);
                                                                            verify(function).value(INITIAL);
                                                                            verify(function).value(MIN);
                                                                            verify(function).value(MAX);
                                                                        }

    @Test
                                                                        public void testSolve_FullBrentAlgorithm() throws Exception {
                                                                            // Define test constants
                                                                            double MIN = -10.0;
                                                                            double MAX = 10.0;
                                                                            double INITIAL = 0.0;
                                                                            
                                                                            // Create mock function
                                                                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                            when(function.value(INITIAL)).thenReturn(1.0);
                                                                            when(function.value(MIN)).thenReturn(-1.0);
                                                                            when(function.value(MAX)).thenReturn(1.0);
                                                                            
                                                                            // Create solver and spy
                                                                            BrentSolver solver = new BrentSolver();
                                                                            BrentSolver spySolver = spy(solver);
                                                                            
                                                                            // Get private solve method via reflection
                                                                            Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                "solve", 
                                                                                UnivariateRealFunction.class, 
                                                                                double.class, 
                                                                                double.class, 
                                                                                double.class, 
                                                                                double.class, 
                                                                                double.class, 
                                                                                double.class
                                                                            );
                                                                            solveMethod.setAccessible(true);
                                                                            
                                                                            // Mock the private solve method
                                                                            doReturn(0.5).when(spySolver).solve(
                                                                                any(UnivariateRealFunction.class), 
                                                                                eq(MIN), 
                                                                                eq(MAX), 
                                                                                eq(INITIAL)
                                                                            );
                                                                            
                                                                            double result = spySolver.solve(function, MIN, MAX, INITIAL);
                                                                            
                                                                            assertEquals(0.5, result, 0.0);
                                                                            verify(function).value(INITIAL);
                                                                            verify(function).value(MIN);
                                                                            verify(function).value(MAX);
                                                                        }

    @Test(expected = org.apache.commons.math.MaxIterationsExceededException.class)
                                                                    public void testSolveWithMaxIterationsExceeded() throws Exception {
                                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                        BrentSolver solver = new BrentSolver();
                                                                        
                                                                        when(function.value(1.0)).thenReturn(-1.0);
                                                                        when(function.value(2.0)).thenReturn(1.0);
                                                                        when(function.value(anyDouble())).thenReturn(0.5); // Never reaches zero
                                                                        
                                                                        solver.setMaximalIterationCount(1);
                                                                        solver.solve(function, 1.0, 2.0);
                                                                    }

    @Test
                                            public void testSolveWithRootAtMin() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                BrentSolver solver = new BrentSolver();
                                                
                                                when(function.value(1.0)).thenReturn(0.0);
                                                when(function.value(2.0)).thenReturn(1.0);
                                            
                                                double result = solver.solve(function, 1.0, 2.0);
                                                assertEquals(1.0, result, 0.0);
                                            }

    @Test
                                            public void testSolveWithFunctionValueAccuracyAtMin() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                BrentSolver solver = new BrentSolver();
                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                
                                                solver.setFunctionValueAccuracy(0.1);
                                                when(function.value(1.0)).thenReturn(0.05);
                                                when(function.value(2.0)).thenReturn(1.0);
                                                
                                                double result = solver.solve(function, 1.0, 2.0);
                                                assertEquals(1.0, result, 0.0);
                                            }

    @Test
                                            public void testSolveWithFunctionValueAccuracyAtMax() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                BrentSolver solver = new BrentSolver();
                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                
                                                solver.setFunctionValueAccuracy(0.1);
                                                when(function.value(1.0)).thenReturn(-1.0);
                                                when(function.value(2.0)).thenReturn(0.05);
                                                
                                                double result = solver.solve(function, 1.0, 2.0);
                                                assertEquals(2.0, result, 0.0);
                                            }

    @Test(expected = MaxIterationsExceededException.class)
                                            public void testSolveWithNonBracketing() throws Exception {
                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                BrentSolver solver = new BrentSolver();
                                                
                                                when(function.value(1.0)).thenReturn(1.0);
                                                when(function.value(2.0)).thenReturn(2.0);
                                                
                                                solver.solve(function, 1.0, 2.0);
                                            }

    @Test(expected = MaxIterationsExceededException.class)
                                            public void testSolveWithInvalidInterval() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                BrentSolver solver = new BrentSolver();
                                                UnivariateRealFunction function = new UnivariateRealFunction() {
                                                    public double value(double x) throws FunctionEvaluationException {
                                                        return x * x - 2;
                                                    }
                                                };
                                                solver.solve(function, 2.0, 1.0);
                                            }

    @Test
                                            public void testSolveWithYMinZero() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                BrentSolver solver = new BrentSolver();
                                                
                                                when(function.value(1.0)).thenReturn(0.0);
                                                when(function.value(2.0)).thenReturn(0.0);
                                                
                                                double result = solver.solve(function, 1.0, 2.0);
                                                assertEquals(1.0, result, 0.0);
                                            }

    @Test
        public void testSolveThrowsWhenMaxIterationsExceeded() throws Exception {
            // Setup
            BrentSolver solver = new BrentSolver();
            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
            
            // Get private solve method via reflection
            Method solveMethod = BrentSolver.class.getDeclaredMethod(
                "solve",
                UnivariateRealFunction.class, 
                double.class, 
                double.class, 
                double.class, 
                double.class, 
                double.class, 
                double.class
            );
            solveMethod.setAccessible(true);
        
            // Mock function behavior
            when(function.value(anyDouble())).thenReturn(1.0);
            
            // Test
            try {
                solveMethod.invoke(
                    solver, 
                    function, 
                    0.0, 1.0, 
                    1.0, 1.0, 
                    2.0, 1.0
                );
                fail("Expected ConvergenceException");
            } catch (InvocationTargetException e) {
{
                    // Expected exception
                    return;
                }
            }
        }


}
