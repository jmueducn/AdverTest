package gentest.org.apache.commons.math.stat.inference.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.inference.*;
import org.apache.commons.math.MathException;
import org.apache.commons.math.distribution.ChiSquaredDistribution;
import org.apache.commons.math.distribution.ChiSquaredDistributionImpl;
import org.apache.commons.math.distribution.DistributionFactory;
 
public class ChiSquareTestImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
        public void testChiSquareHappyPath() {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            double[] expected = {10.0, 20.0, 30.0};
            long[] observed = {12L, 18L, 30L};
            double result = chiSquareTest.chiSquare(expected, observed);
            assertTrue(result > 0);
        }

    @Test
        public void testChiSquareWithRescaling() {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            double[] expected = {10.0, 20.0, 30.0};
            long[] observed = {15L, 25L, 40L}; // Sums differ
            double result = chiSquareTest.chiSquare(expected, observed);
            assertTrue(result > 0);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testChiSquareInvalidArrayLength() {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            double[] expected = {10.0, 20.0};
            long[] observed = {12L};
            chiSquareTest.chiSquare(expected, observed);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testChiSquareTooShortArray() {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            double[] expected = {10.0};
            long[] observed = {12L};
            chiSquareTest.chiSquare(expected, observed);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testChiSquareNegativeObserved() {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            double[] expected = {10.0, 20.0};
            long[] observed = {12L, -1L};
            chiSquareTest.chiSquare(expected, observed);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testChiSquareNonPositiveExpected() {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            double[] expected = {10.0, 0.0};
            long[] observed = {12L, 15L};
            chiSquareTest.chiSquare(expected, observed);
        }

    @Test
        public void testIsPositivePrivateMethod() throws Exception {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            Method method = ChiSquareTestImpl.class.getDeclaredMethod("isPositive", double[].class);
            method.setAccessible(true);
            
            double[] positiveArray = {1.0, 2.0, 3.0};
            assertTrue((boolean) method.invoke(chiSquareTest, (Object) positiveArray));
            
            double[] nonPositiveArray = {1.0, 0.0, 3.0};
            assertFalse((boolean) method.invoke(chiSquareTest, (Object) nonPositiveArray));
        }

    @Test
        public void testIsNonNegativePrivateMethod() throws Exception {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            Method method = ChiSquareTestImpl.class.getDeclaredMethod("isNonNegative", long[].class);
            method.setAccessible(true);
            
            long[] nonNegativeArray = {1L, 2L, 3L};
            assertTrue((boolean) method.invoke(chiSquareTest, (Object) nonNegativeArray));
            
            long[] negativeArray = {1L, -1L, 3L};
            assertFalse((boolean) method.invoke(chiSquareTest, (Object) negativeArray));
        }

    @Test
        public void testChiSquareExactMatch() {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            double[] expected = {10.0, 20.0, 30.0};
            long[] observed = {10L, 20L, 30L};
            double result = chiSquareTest.chiSquare(expected, observed);
            assertEquals(0.0, result, 0.0001);
        }

    @Test
        public void testChiSquarePrecision() {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            double[] expected = {1000000.0, 2000000.0};
            long[] observed = {1000001L, 1999999L};
            double result = chiSquareTest.chiSquare(expected, observed);
            assertTrue(result > 0);
            assertTrue(result < 0.0001);
        }

    @Test
        public void testChiSquareValidInput() {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            long[][] counts = {{10, 20}, {30, 40}};
            double result = chiSquareTest.chiSquare(counts);
            assertEquals(0.14814814814814814, result, 1E-10);
        }

    @Test
        public void testChiSquareDifferentDimensions() {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            long[][] counts = {{10, 20, 30}, {40, 50, 60}};
            double result = chiSquareTest.chiSquare(counts);
            assertEquals(0.0, result, 1E-10);
        }

    @Test
        public void testChiSquareSingleRow() {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            long[][] counts = {{10, 20}};
            double result = chiSquareTest.chiSquare(counts);
            // Add assertion if needed
        }

    @Test
        public void testChiSquareSingleColumn() {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            long[][] counts = {{10}, {20}};
            chiSquareTest.chiSquare(counts);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testChiSquareNonRectangular() {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            long[][] counts = {{10, 20}, {30}};
            chiSquareTest.chiSquare(counts);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testChiSquareNegativeValues() {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            long[][] counts = {{-1, 2}, {3, 4}};
            chiSquareTest.chiSquare(counts);
        }

    @Test
        public void testChiSquareZeroValues() {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            long[][] counts = {{0, 0}, {0, 0}};
            double result = chiSquareTest.chiSquare(counts);
            assertEquals(Double.NaN, result, 1E-10);
        }

    @Test
        public void testChiSquareLargeValues() {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            long[][] counts = {{1000000, 2000000}, {3000000, 4000000}};
            double result = chiSquareTest.chiSquare(counts);
            assertEquals(0.14814814814814814, result, 1E-10);
        }

    @Test
        public void testCheckArrayValid() throws Exception {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            long[][] validArray = {{1, 2}, {3, 4}};
            Method method = ChiSquareTestImpl.class.getDeclaredMethod("checkArray", long[][].class);
            method.setAccessible(true);
            method.invoke(chiSquareTest, (Object) validArray);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testCheckArraySingleRow() throws Exception {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            long[][] invalidArray = {{1, 2}};
            Method method = ChiSquareTestImpl.class.getDeclaredMethod("checkArray", long[][].class);
            method.setAccessible(true);
            method.invoke(chiSquareTest, (Object) invalidArray);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testCheckArraySingleColumn() throws Exception {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            long[][] invalidArray = {{1}, {2}};
            Method method = ChiSquareTestImpl.class.getDeclaredMethod("checkArray", long[][].class);
            method.setAccessible(true);
            method.invoke(chiSquareTest, (Object) invalidArray);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testCheckArrayNonRectangular() throws Exception {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            long[][] invalidArray = {{1, 2}, {3}};
            Method method = ChiSquareTestImpl.class.getDeclaredMethod("checkArray", long[][].class);
            method.setAccessible(true);
            method.invoke(chiSquareTest, (Object) invalidArray);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testCheckArrayNegativeValues() throws Exception {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            long[][] invalidArray = {{-1, 2}, {3, 4}};
            Method method = ChiSquareTestImpl.class.getDeclaredMethod("checkArray", long[][].class);
            method.setAccessible(true);
            method.invoke(chiSquareTest, (Object) invalidArray);
        }

    @Test
        public void testIsRectangular() throws Exception {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            long[][] rectangular = {{1, 2}, {3, 4}};
            long[][] nonRectangular = {{1, 2}, {3}};
            
            Method method = ChiSquareTestImpl.class.getDeclaredMethod("isRectangular", long[][].class);
            method.setAccessible(true);
            
            assertTrue((Boolean) method.invoke(chiSquareTest, (Object) rectangular));
            assertFalse((Boolean) method.invoke(chiSquareTest, (Object) nonRectangular));
        }

    @Test
        public void testIsNonNegative() throws Exception {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            long[] nonNegative = {0, 1, 2};
            long[] negative = {-1, 0, 1};
            
            Method method = ChiSquareTestImpl.class.getDeclaredMethod("isNonNegative", long[].class);
            method.setAccessible(true);
            
            assertTrue((Boolean) method.invoke(chiSquareTest, (Object) nonNegative));
            assertFalse((Boolean) method.invoke(chiSquareTest, (Object) negative));
        }

    @Test
        public void testIsNonNegative2D() throws Exception {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            long[][] nonNegative = {{0, 1}, {2, 3}};
            long[][] negative = {{-1, 0}, {1, 2}};
            
            Method method = ChiSquareTestImpl.class.getDeclaredMethod("isNonNegative", long[][].class);
            method.setAccessible(true);
            
            assertTrue((Boolean) method.invoke(chiSquareTest, (Object) nonNegative));
            assertFalse((Boolean) method.invoke(chiSquareTest, (Object) negative));
        }


}
