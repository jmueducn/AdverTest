package gentest.org.apache.commons.math.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.fraction.*;
import java.math.BigInteger;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.util.MathUtils;
 
public class FractionTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testCompareToEqualFractions() {
            Fraction f1 = new Fraction(1, 2);
            Fraction f2 = new Fraction(1, 2);
            assertEquals(0, f1.compareTo(f2));
        }

    @Test
        public void testCompareToSmallerFraction() {
            Fraction f1 = new Fraction(1, 3);
            Fraction f2 = new Fraction(1, 2);
            assertTrue(f1.compareTo(f2) < 0);
        }

    @Test
        public void testCompareToLargerFraction() {
            Fraction f1 = new Fraction(3, 4);
            Fraction f2 = new Fraction(1, 2);
            assertTrue(f1.compareTo(f2) > 0);
        }

    @Test
        public void testCompareToNegativeFractions() {
            Fraction f1 = new Fraction(-1, 2);
            Fraction f2 = new Fraction(1, 2);
            assertTrue(f1.compareTo(f2) < 0);
        }

    @Test
        public void testCompareToBothNegativeFractions() {
            Fraction f1 = new Fraction(-1, 3);
            Fraction f2 = new Fraction(-1, 2);
            assertTrue(f1.compareTo(f2) > 0);
        }

    @Test
        public void testCompareToDifferentDenominators() {
            Fraction f1 = new Fraction(2, 3);
            Fraction f2 = new Fraction(3, 4);
            assertTrue(f1.compareTo(f2) < 0);
        }

    @Test
        public void testCompareToSameNumerator() {
            Fraction f1 = new Fraction(1, 3);
            Fraction f2 = new Fraction(1, 2);
            assertTrue(f1.compareTo(f2) < 0);
        }

    @Test
        public void testCompareToSameDenominator() {
            Fraction f1 = new Fraction(2, 5);
            Fraction f2 = new Fraction(3, 5);
            assertTrue(f1.compareTo(f2) < 0);
        }

    @Test
        public void testCompareToWholeNumbers() {
            Fraction f1 = new Fraction(2, 1);
            Fraction f2 = new Fraction(3, 1);
            assertTrue(f1.compareTo(f2) < 0);
        }

    @Test
        public void testCompareToZero() {
            Fraction f1 = new Fraction(0, 1);
            Fraction f2 = new Fraction(1, 2);
            assertTrue(f1.compareTo(f2) < 0);
        }

    @Test
        public void testCompareToZeroVsNegative() {
            Fraction f1 = new Fraction(0, 1);
            Fraction f2 = new Fraction(-1, 2);
            assertTrue(f1.compareTo(f2) > 0);
        }

    @Test
        public void testCompareToLargeValues() {
            Fraction f1 = new Fraction(Integer.MAX_VALUE - 1, Integer.MAX_VALUE);
            Fraction f2 = new Fraction(Integer.MAX_VALUE, Integer.MAX_VALUE - 1);
            assertTrue(f1.compareTo(f2) < 0);
        }

    @Test
        public void testCompareToEquivalentFractions() {
            Fraction f1 = new Fraction(2, 4);
            Fraction f2 = new Fraction(1, 2);
            assertEquals(0, f1.compareTo(f2));
        }

}
