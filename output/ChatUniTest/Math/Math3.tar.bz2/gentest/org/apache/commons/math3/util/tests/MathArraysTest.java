package gentest.org.apache.commons.math3.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.util.*;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.exception.MathInternalError;
import org.apache.commons.math3.exception.NoDataException;
import org.apache.commons.math3.exception.NonMonotonicSequenceException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
 
public class MathArraysTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                public void testLinearCombinationSameLength() {
                                                    double[] a = {1.0, 2.0, 3.0};
                                                    double[] b = {4.0, 5.0, 6.0};
                                                    double expected = 1.0*4.0 + 2.0*5.0 + 3.0*6.0;
                                                    double result = MathArrays.linearCombination(a, b);
                                                    assertEquals(expected, result, 1e-15);
                                                }

    @Test(expected = DimensionMismatchException.class)
                                                public void testLinearCombinationDifferentLengths() {
                                                    double[] a = {1.0, 2.0};
                                                    double[] b = {3.0};
                                                    MathArrays.linearCombination(a, b);
                                                }

    @Test
                                                public void testLinearCombinationSingleElement() {
                                                    double[] a = {2.5};
                                                    double[] b = {3.5};
                                                    double expected = 2.5 * 3.5;
                                                    double result = MathArrays.linearCombination(a, b);
                                                    assertEquals(expected, result, 1e-15);
                                                }

    @Test
                                                public void testLinearCombinationWithNaN() {
                                                    double[] a = {1.0, Double.NaN, 3.0};
                                                    double[] b = {4.0, 5.0, 6.0};
                                                    double expected = 1.0*4.0 + 3.0*6.0; // NaN should trigger fallback to simple multiplication
                                                    double result = MathArrays.linearCombination(a, b);
                                                    assertEquals(expected, result, 1e-15);
                                                }

    @Test
                                                public void testLinearCombinationWithInfinity() {
                                                    double[] a = {1.0, Double.POSITIVE_INFINITY, 3.0};
                                                    double[] b = {4.0, 5.0, 6.0};
                                                    double expected = 1.0*4.0 + Double.POSITIVE_INFINITY*5.0 + 3.0*6.0;
                                                    double result = MathArrays.linearCombination(a, b);
                                                    assertEquals(expected, result, 1e-15);
                                                }

    @Test
                                                public void testLinearCombinationLargeValues() {
                                                    double[] a = {1e100, 2e100, 3e100};
                                                    double[] b = {4e100, 5e100, 6e100};
                                                    double expected = 1e100*4e100 + 2e100*5e100 + 3e100*6e100;
                                                    double result = MathArrays.linearCombination(a, b);
                                                    assertEquals(expected, result, 1e15); // Larger delta due to magnitude
                                                }

    @Test
                                                public void testLinearCombinationSmallValues() {
                                                    double[] a = {1e-100, 2e-100, 3e-100};
                                                    double[] b = {4e-100, 5e-100, 6e-100};
                                                    double expected = 1e-100*4e-100 + 2e-100*5e-100 + 3e-100*6e-100;
                                                    double result = MathArrays.linearCombination(a, b);
                                                    assertEquals(expected, result, 1e-215); // Very small delta
                                                }

    @Test
                                                public void testLinearCombinationMixedValues() {
                                                    double[] a = {1e100, 2e-100, 3e100};
                                                    double[] b = {4e-100, 5e100, 6e-100};
                                                    double expected = 1e100*4e-100 + 2e-100*5e100 + 3e100*6e-100;
                                                    double result = MathArrays.linearCombination(a, b);
                                                    assertEquals(expected, result, 1e-15);
                                                }

    @Test
                                                public void testLinearCombinationZeroValues() {
                                                    double[] a = {0.0, 0.0, 0.0};
                                                    double[] b = {4.0, 5.0, 6.0};
                                                    double expected = 0.0;
                                                    double result = MathArrays.linearCombination(a, b);
                                                    assertEquals(expected, result, 0.0);
                                                }

    @Test
                                                public void testLinearCombinationCancellation() {
                                                    double[] a = {1.0, 1.0, -1.0};
                                                    double[] b = {1.0, 1.0, 2.0};
                                                    double expected = 1.0*1.0 + 1.0*1.0 + -1.0*2.0;
                                                    double result = MathArrays.linearCombination(a, b);
                                                    assertEquals(expected, result, 1e-15);
                                                }

    @Test
                                                public void testLinearCombinationBasic() {
                                                    double result = MathArrays.linearCombination(1.0, 2.0, 3.0, 4.0);
                                                    assertEquals(1.0 * 2.0 + 3.0 * 4.0, result, 1e-15);
                                                }

    @Test
                                                public void testLinearCombinationWithZero() {
                                                    double result = MathArrays.linearCombination(0.0, 2.0, 3.0, 0.0);
                                                    assertEquals(0.0 * 2.0 + 3.0 * 0.0, result, 1e-15);
                                                }

    @Test
                                                public void testLinearCombinationWithLargeNumbers() {
                                                    double a1 = 1.0e100;
                                                    double b1 = 2.0e100;
                                                    double a2 = 3.0e100;
                                                    double b2 = 4.0e100;
                                                    double result = MathArrays.linearCombination(a1, b1, a2, b2);
                                                    assertEquals(a1 * b1 + a2 * b2, result, 1e15);
                                                }

    @Test
                                                public void testLinearCombinationWithSmallNumbers() {
                                                    double a1 = 1.0e-100;
                                                    double b1 = 2.0e-100;
                                                    double a2 = 3.0e-100;
                                                    double b2 = 4.0e-100;
                                                    double result = MathArrays.linearCombination(a1, b1, a2, b2);
                                                    assertEquals(a1 * b1 + a2 * b2, result, 1e-115);
                                                }

    @Test
                                                public void testLinearCombinationWithMixedNumbers() {
                                                    double a1 = 1.0e100;
                                                    double b1 = 2.0e-100;
                                                    double a2 = 3.0e-100;
                                                    double b2 = 4.0e100;
                                                    double result = MathArrays.linearCombination(a1, b1, a2, b2);
                                                    assertEquals(a1 * b1 + a2 * b2, result, 1e-15);
                                                }

    @Test
                                                public void testLinearCombinationWithNaN1() {
                                                    double result = MathArrays.linearCombination(Double.NaN, 2.0, 3.0, 4.0);
                                                    assertTrue(Double.isNaN(result));
                                                }

    @Test
                                                public void testLinearCombinationWithInfinity1() {
                                                    double result = MathArrays.linearCombination(Double.POSITIVE_INFINITY, 2.0, 3.0, 4.0);
                                                    assertEquals(Double.POSITIVE_INFINITY * 2.0 + 3.0 * 4.0, result, 1e-15);
                                                }

    @Test
                                                public void testLinearCombinationWithNegativeInfinity() {
                                                    double result = MathArrays.linearCombination(Double.NEGATIVE_INFINITY, 2.0, 3.0, 4.0);
                                                    assertEquals(Double.NEGATIVE_INFINITY * 2.0 + 3.0 * 4.0, result, 1e-15);
                                                }

    @Test
                                                public void testLinearCombinationWithOppositeSigns() {
                                                    double a1 = 1.0;
                                                    double b1 = -2.0;
                                                    double a2 = -3.0;
                                                    double b2 = 4.0;
                                                    double result = MathArrays.linearCombination(a1, b1, a2, b2);
                                                    assertEquals(a1 * b1 + a2 * b2, result, 1e-15);
                                                }

    @Test
                                                public void testLinearCombinationWithCancellation() {
                                                    double a1 = 1.0e100;
                                                    double b1 = 1.0;
                                                    double a2 = -1.0e100;
                                                    double b2 = 1.0 + 1.0e-15;
                                                    double result = MathArrays.linearCombination(a1, b1, a2, b2);
                                                    assertEquals(1.0e-15, result, 1e-30);
                                                }

    @Test
                                                public void testLinearCombinationWithExtremeValues() {
                                                    double a1 = Double.MAX_VALUE;
                                                    double b1 = Double.MAX_VALUE;
                                                    double a2 = Double.MIN_VALUE;
                                                    double b2 = Double.MIN_VALUE;
                                                    double result = MathArrays.linearCombination(a1, b1, a2, b2);
                                                    assertEquals(a1 * b1 + a2 * b2, result, 1e292);
                                                }

    @Test
                                                public void testLinearCombinationBasic1() {
                                                    double a1 = 1.0;
                                                    double b1 = 2.0;
                                                    double a2 = 3.0;
                                                    double b2 = 4.0;
                                                    double a3 = 5.0;
                                                    double b3 = 6.0;
                                                    
                                                    double expected = a1 * b1 + a2 * b2 + a3 * b3;
                                                    double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
                                                    
                                                    assertEquals(expected, actual, 1e-15);
                                                }

    @Test
                                                public void testLinearCombinationWithZero1() {
                                                    double a1 = 0.0;
                                                    double b1 = 2.0;
                                                    double a2 = 3.0;
                                                    double b2 = 0.0;
                                                    double a3 = 0.0;
                                                    double b3 = 6.0;
                                                    
                                                    double expected = a1 * b1 + a2 * b2 + a3 * b3;
                                                    double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
                                                    
                                                    assertEquals(expected, actual, 1e-15);
                                                }

    @Test
                                                public void testLinearCombinationWithLargeNumbers1() {
                                                    double a1 = 1e100;
                                                    double b1 = 2e100;
                                                    double a2 = 3e100;
                                                    double b2 = 4e100;
                                                    double a3 = 5e100;
                                                    double b3 = 6e100;
                                                    
                                                    double expected = a1 * b1 + a2 * b2 + a3 * b3;
                                                    double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
                                                    
                                                    assertEquals(expected, actual, 1e185); // Larger tolerance for very large numbers
                                                }

    @Test
                                                public void testLinearCombinationWithSmallNumbers1() {
                                                    double a1 = 1e-100;
                                                    double b1 = 2e-100;
                                                    double a2 = 3e-100;
                                                    double b2 = 4e-100;
                                                    double a3 = 5e-100;
                                                    double b3 = 6e-100;
                                                    
                                                    double expected = a1 * b1 + a2 * b2 + a3 * b3;
                                                    double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
                                                    
                                                    assertEquals(expected, actual, 1e-115); // Smaller tolerance for very small numbers
                                                }

    @Test
                                                public void testLinearCombinationWithMixedNumbers1() {
                                                    double a1 = 1e100;
                                                    double b1 = 2e-100;
                                                    double a2 = 3e-100;
                                                    double b2 = 4e100;
                                                    double a3 = 5e50;
                                                    double b3 = 6e50;
                                                    
                                                    double expected = a1 * b1 + a2 * b2 + a3 * b3;
                                                    double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
                                                    
                                                    assertEquals(expected, actual, 1e-15 * Math.abs(expected));
                                                }

    @Test
                                                public void testLinearCombinationWithNaN2() {
                                                    double a1 = Double.NaN;
                                                    double b1 = 2.0;
                                                    double a2 = 3.0;
                                                    double b2 = 4.0;
                                                    double a3 = 5.0;
                                                    double b3 = 6.0;
                                                    
                                                    double result = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
                                                    assertTrue(Double.isNaN(result));
                                                }

    @Test
                                                public void testLinearCombinationWithInfinity2() {
                                                    double a1 = Double.POSITIVE_INFINITY;
                                                    double b1 = 2.0;
                                                    double a2 = 3.0;
                                                    double b2 = 4.0;
                                                    double a3 = 5.0;
                                                    double b3 = 6.0;
                                                    
                                                    double expected = a1 * b1 + a2 * b2 + a3 * b3;
                                                    double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
                                                    
                                                    assertEquals(expected, actual, 0.0);
                                                }

    @Test
                                                public void testLinearCombinationWithNegativeInfinity1() {
                                                    double a1 = Double.NEGATIVE_INFINITY;
                                                    double b1 = 2.0;
                                                    double a2 = 3.0;
                                                    double b2 = 4.0;
                                                    double a3 = 5.0;
                                                    double b3 = 6.0;
                                                    
                                                    double expected = a1 * b1 + a2 * b2 + a3 * b3;
                                                    double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
                                                    
                                                    assertEquals(expected, actual, 0.0);
                                                }

    @Test
                                                public void testLinearCombinationWithCancellation1() {
                                                    double a1 = 1.0;
                                                    double b1 = 1.0;
                                                    double a2 = 1.0;
                                                    double b2 = -1.0;
                                                    double a3 = 1.0e-16;
                                                    double b3 = 1.0e16;
                                                    
                                                    // The exact result should be 1.0 (1*1 + 1*(-1) + 1e-16*1e16 = 1 - 1 + 1)
                                                    double expected = 1.0;
                                                    double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
                                                    
                                                    assertEquals(expected, actual, 1e-15);
                                                }

    @Test
                                                public void testLinearCombinationWithExtremeCancellation() {
                                                    double a1 = 1.0e100;
                                                    double b1 = 1.0;
                                                    double a2 = 1.0;
                                                    double b2 = -1.0e100;
                                                    double a3 = 1.0;
                                                    double b3 = 1.0;
                                                    
                                                    // The exact result should be 1.0 (1e100*1 + 1*(-1e100) + 1*1 = 1e100 - 1e100 + 1)
                                                    double expected = 1.0;
                                                    double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
                                                    
                                                    assertEquals(expected, actual, 1e-15);
                                                }

    @Test
                                                public void testLinearCombinationWithNaN3() {
                                                    double actual = MathArrays.linearCombination(Double.NaN, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0);
                                                    assertTrue(Double.isNaN(actual));
                                                }

    @Test
                                                public void testLinearCombinationWithInfinity3() {
                                                    double actual = MathArrays.linearCombination(Double.POSITIVE_INFINITY, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0);
                                                    assertEquals(Double.POSITIVE_INFINITY, actual, 0.0);
                                                }

    @Test
                                                public void testLinearCombinationWithOppositeInfinities() {
                                                    double actual = MathArrays.linearCombination(Double.POSITIVE_INFINITY, 1.0, Double.NEGATIVE_INFINITY, 1.0, 1.0, 1.0, 1.0, 1.0);
                                                    assertTrue(Double.isNaN(actual));
                                                }

    @Test
                                                public void testLinearCombinationWithCancellation2() {
                                                    // This test verifies that the method handles cancellation better than naive implementation
                                                    double x = 1.0 + 1e-10;
                                                    double y = 1.0 - 1e-10;
                                                    double naive = x * y + y * x;
                                                    double accurate = MathArrays.linearCombination(x, y, y, x, 0.0, 0.0, 0.0, 0.0);
                                                    assertNotEquals(naive, accurate, 0.0);
                                                    assertEquals(2.0, accurate, 1e-15);
                                                }

    @Test
                                            public void testLinearCombination() {
                                                // Define test variables
                                                double a1 = 1.0;
                                                double b1 = 2.0;
                                                double a2 = 3.0;
                                                double b2 = 4.0;
                                                double a3 = 5.0;
                                                double b3 = 6.0;
                                                double a4 = 7.0;
                                                double b4 = 8.0;
                                                
                                                // Calculate expected value
                                                double expected = a1 * b1 + a2 * b2 + a3 * b3 + a4 * b4;
                                                
                                                // Call method under test
                                                double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3, a4, b4);
                                                
                                                // Assertions
                                                if (Double.isNaN(expected)) {
                                                    assertTrue(Double.isNaN(actual));
                                                } else {
                                                    assertEquals(expected, actual, 1e-15 * Math.abs(expected));
                                                }
                                            }


}
