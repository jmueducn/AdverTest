package gentest.org.apache.commons.math3.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.complex.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math3.FieldElement;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.MathUtils;
 
public class ComplexTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testReciprocalNaN() {
            Complex c = new Complex(Double.NaN, 1.0);
            Complex result = c.reciprocal();
            assertTrue(result.isNaN());
        }

    @Test
        public void testReciprocalZero() {
            Complex c = new Complex(0.0, 0.0);
            Complex result = c.reciprocal();
            assertEquals(Complex.INF, result);
        }

    @Test
        public void testReciprocalInfinite() {
            Complex c = new Complex(Double.POSITIVE_INFINITY, 1.0);
            Complex result = c.reciprocal();
            assertEquals(Complex.ZERO, result);
        }

    @Test
        public void testReciprocalRealDominant() {
            Complex c = new Complex(2.0, 1.0);
            Complex result = c.reciprocal();
            assertEquals(0.4, result.getReal(), 1e-15);
            assertEquals(-0.2, result.getImaginary(), 1e-15);
        }

    @Test
        public void testReciprocalImaginaryDominant() {
            Complex c = new Complex(1.0, 2.0);
            Complex result = c.reciprocal();
            assertEquals(0.2, result.getReal(), 1e-15);
            assertEquals(-0.4, result.getImaginary(), 1e-15);
        }

    @Test
        public void testReciprocalNegativeReal() {
            Complex c = new Complex(-3.0, 1.0);
            Complex result = c.reciprocal();
            assertEquals(-0.3, result.getReal(), 1e-15);
            assertEquals(0.1, result.getImaginary(), 1e-15);
        }

    @Test
        public void testReciprocalNegativeImaginary() {
            Complex c = new Complex(1.0, -4.0);
            Complex result = c.reciprocal();
            assertEquals(0.058823529411764705, result.getReal(), 1e-15);
            assertEquals(0.23529411764705882, result.getImaginary(), 1e-15);
        }

    @Test
        public void testReciprocalPureReal() {
            Complex c = new Complex(5.0, 0.0);
            Complex result = c.reciprocal();
            assertEquals(0.2, result.getReal(), 1e-15);
            assertEquals(0.0, result.getImaginary(), 1e-15);
        }

    @Test
        public void testReciprocalPureImaginary() {
            Complex c = new Complex(0.0, 5.0);
            Complex result = c.reciprocal();
            assertEquals(0.0, result.getReal(), 1e-15);
            assertEquals(-0.2, result.getImaginary(), 1e-15);
        }

    @Test
        public void testReciprocalSmallValues() {
            Complex c = new Complex(1e-10, 1e-20);
            Complex result = c.reciprocal();
            assertEquals(1e10, result.getReal(), 1e-5);
            assertEquals(-1e-10, result.getImaginary(), 1e-20);
        }

    @Test
        public void testReciprocalLargeValues() {
            Complex c = new Complex(1e10, 1e20);
            Complex result = c.reciprocal();
            assertEquals(1e-20, result.getReal(), 1e-30);
            assertEquals(-1e-10, result.getImaginary(), 1e-20);
        }

}
