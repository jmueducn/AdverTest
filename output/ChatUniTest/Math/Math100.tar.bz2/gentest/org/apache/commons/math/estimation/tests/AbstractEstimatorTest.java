package gentest.org.apache.commons.math.estimation.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.estimation.*;
import java.util.Arrays;
import org.apache.commons.math.linear.InvalidMatrixException;
import org.apache.commons.math.linear.RealMatrixImpl;
 
public class AbstractEstimatorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                        public void testGetCovariancesSuccess() throws Exception {
                                                                            // Create test objects
                                                                            WeightedMeasurement[] measurements = new WeightedMeasurement[2];
                                                                            EstimatedParameter[] parameters = new EstimatedParameter[2];
                                                                            parameters[0] = new EstimatedParameter("p0", 0);
                                                                            parameters[1] = new EstimatedParameter("p1", 0);
                                                                            
                                                                            // Create mock problem
                                                                            EstimationProblem problem = mock(EstimationProblem.class);
                                                                            when(problem.getMeasurements()).thenReturn(measurements);
                                                                            when(problem.getUnboundParameters()).thenReturn(parameters);
                                                                            
                                                                            // Create estimator and set up jacobian via reflection
                                                                            AbstractEstimator estimator = new LevenbergMarquardtEstimator();
                                                                            Field jacobianField = AbstractEstimator.class.getDeclaredField("jacobian");
                                                                            jacobianField.setAccessible(true);
                                                                            
                                                                            // Setup jacobian values that will produce an invertible matrix
                                                                            double[] jacobian = {1.0, 0.0, 0.0, 1.0};
                                                                            jacobianField.set(estimator, jacobian);
                                                                    
                                                                            double[][] result = estimator.getCovariances(problem);
                                                                    
                                                                            assertNotNull(result);
                                                                            assertEquals(2, result.length);
                                                                            assertEquals(2, result[0].length);
                                                                            assertEquals(1.0, result[0][0], 1e-10);
                                                                            assertEquals(0.0, result[0][1], 1e-10);
                                                                            assertEquals(0.0, result[1][0], 1e-10);
                                                                            assertEquals(1.0, result[1][1], 1e-10);
                                                                        }

    @Test
                                                                        public void testGetCovariancesWithZeroMeasurements() throws Exception {
                                                                            // Create mocks and test objects
                                                                            AbstractEstimator estimator = mock(AbstractEstimator.class);
                                                                            EstimationProblem problem = mock(EstimationProblem.class);
                                                                            EstimatedParameter parameter1 = new EstimatedParameter("param1", 0.0);
                                                                            
                                                                            // Set up fields using reflection
                                                                            Field rowsField = AbstractEstimator.class.getDeclaredField("rows");
                                                                            rowsField.setAccessible(true);
                                                                            Field colsField = AbstractEstimator.class.getDeclaredField("cols");
                                                                            colsField.setAccessible(true);
                                                                            Field jacobianField = AbstractEstimator.class.getDeclaredField("jacobian");
                                                                            jacobianField.setAccessible(true);
                                                                    
                                                                            // Configure mocks
                                                                            when(problem.getMeasurements()).thenReturn(new WeightedMeasurement[0]);
                                                                            when(problem.getUnboundParameters()).thenReturn(new EstimatedParameter[]{parameter1});
                                                                    
                                                                            // Set field values
                                                                            rowsField.set(estimator, 0);
                                                                            colsField.set(estimator, 1);
                                                                            jacobianField.set(estimator, new double[0]);
                                                                    
                                                                            try {
                                                                                estimator.getCovariances(problem);
                                                                                fail("Expected EstimationException");
                                                                            } catch (EstimationException e) {
                                                                                assertEquals("unable to compute covariances: singular problem", e.getMessage());
                                                                            }
                                                                        }

    @Test
                                                                        public void testGetCovariancesWithSingleParameter() throws Exception {
                                                                            // Create mock objects
                                                                            EstimationProblem problem = mock(EstimationProblem.class);
                                                                            WeightedMeasurement measurement1 = mock(WeightedMeasurement.class);
                                                                            WeightedMeasurement measurement2 = mock(WeightedMeasurement.class);
                                                                            EstimatedParameter parameter1 = mock(EstimatedParameter.class);
                                                                            
                                                                            // Create real estimator instance (assuming AbstractEstimator is abstract)
                                                                            AbstractEstimator estimator = mock(AbstractEstimator.class, 
                                                                                CALLS_REAL_METHODS);
                                                                            
                                                                            // Set up reflection fields
                                                                            Field rowsField = AbstractEstimator.class.getDeclaredField("rows");
                                                                            rowsField.setAccessible(true);
                                                                            Field colsField = AbstractEstimator.class.getDeclaredField("cols");
                                                                            colsField.setAccessible(true);
                                                                            Field jacobianField = AbstractEstimator.class.getDeclaredField("jacobian");
                                                                            jacobianField.setAccessible(true);
                                                                    
                                                                            // Configure mocks
                                                                            when(problem.getMeasurements()).thenReturn(new WeightedMeasurement[]{measurement1, measurement2});
                                                                            when(problem.getUnboundParameters()).thenReturn(new EstimatedParameter[]{parameter1});
                                                                    
                                                                            // Set private fields
                                                                            rowsField.set(estimator, 2);
                                                                            colsField.set(estimator, 1);
                                                                            jacobianField.set(estimator, new double[]{1.0, 2.0});
                                                                    
                                                                            // Call method under test
                                                                            double[][] result = estimator.getCovariances(problem);
                                                                    
                                                                            // Verify results
                                                                            assertEquals(1, result.length);
                                                                            assertEquals(1, result[0].length);
                                                                            assertEquals(1.0/(1.0 + 4.0), result[0][0], 1e-10);  // 1/(1^2 + 2^2)
                                                                        }

    @Test(expected = EstimationException.class)
                                                                        public void testGuessParametersErrorsErrorsWhenMeasurementsLessThanOrEqualToParameters() throws EstimationException {
                                                                            // Create mock objects
                                                                            AbstractEstimator estimator = mock(AbstractEstimator.class);
                                                                            EstimationProblem problem = mock(EstimationProblem.class);
                                                                            WeightedMeasurement measurement1 = mock(WeightedMeasurement.class);
                                                                            EstimatedParameter parameter1 = mock(EstimatedParameter.class);
                                                                            EstimatedParameter parameter2 = mock(EstimatedParameter.class);
                                                                    
                                                                            // Setup mock behavior
                                                                            when(problem.getMeasurements()).thenReturn(new WeightedMeasurement[]{measurement1});
                                                                            when(problem.getUnboundParameters()).thenReturn(new EstimatedParameter[]{parameter1, parameter2});
                                                                            
                                                                            // Call the method under test
                                                                            when(estimator.guessParametersErrors(problem)).thenCallRealMethod();
                                                                            estimator.guessParametersErrors(problem);
                                                                        }

    @Test
                                                                        public void testGuessParametersErrors() throws EstimationException {
                                                                            // Create mock objects
                                                                            EstimationProblem problem = mock(EstimationProblem.class);
                                                                            WeightedMeasurement measurement1 = mock(WeightedMeasurement.class);
                                                                            WeightedMeasurement measurement2 = mock(WeightedMeasurement.class);
                                                                            WeightedMeasurement measurement3 = mock(WeightedMeasurement.class);
                                                                            EstimatedParameter parameter1 = mock(EstimatedParameter.class);
                                                                            EstimatedParameter parameter2 = mock(EstimatedParameter.class);
                                                                            AbstractEstimator estimator = mock(AbstractEstimator.class);
                                                                    
                                                                            // Setup mocks
                                                                            when(problem.getMeasurements()).thenReturn(new WeightedMeasurement[]{measurement1, measurement2, measurement3});
                                                                            when(problem.getUnboundParameters()).thenReturn(new EstimatedParameter[]{parameter1, parameter2});
                                                                    
                                                                            // Mock getChiSquare
                                                                            AbstractEstimator spyEstimator = spy(estimator);
                                                                            when(spyEstimator.getChiSquare(problem)).thenReturn(4.0);
                                                                    
                                                                            // Mock getCovariances
                                                                            double[][] covariances = {{1.0, 0.5}, {0.5, 1.0}};
                                                                            when(spyEstimator.getCovariances(problem)).thenReturn(covariances);
                                                                    
                                                                            double[] errors = spyEstimator.guessParametersErrors(problem);
                                                                    
                                                                            assertEquals(2, errors.length);
                                                                            assertEquals(Math.sqrt(1.0) * Math.sqrt(4.0 / (3 - 2)), errors[0], 0.0001);
                                                                            assertEquals(Math.sqrt(1.0) * Math.sqrt(4.0 / (3 - 2)), errors[1], 0.0001);
                                                                        }

    @Test
                                                                        public void testGuessParametersErrorsWithDifferentCovarianceValues() throws EstimationException {
                                                                            // Create mock objects
                                                                            EstimationProblem problem = mock(EstimationProblem.class);
                                                                            WeightedMeasurement measurement1 = mock(WeightedMeasurement.class);
                                                                            WeightedMeasurement measurement2 = mock(WeightedMeasurement.class);
                                                                            WeightedMeasurement measurement3 = mock(WeightedMeasurement.class);
                                                                            EstimatedParameter parameter1 = mock(EstimatedParameter.class);
                                                                            EstimatedParameter parameter2 = mock(EstimatedParameter.class);
                                                                            
                                                                            // Create real estimator instance (assuming it's abstract, we'll use a concrete subclass)
                                                                            AbstractEstimator estimator = new LevenbergMarquardtEstimator();
                                                                            
                                                                            // Set up mock behavior
                                                                            when(problem.getMeasurements()).thenReturn(new WeightedMeasurement[]{measurement1, measurement2, measurement3});
                                                                            when(problem.getUnboundParameters()).thenReturn(new EstimatedParameter[]{parameter1, parameter2});
                                                                            
                                                                            AbstractEstimator spyEstimator = spy(estimator);
                                                                            when(spyEstimator.getChiSquare(problem)).thenReturn(9.0);
                                                                            
                                                                            double[][] covariances = {{4.0, 0.0}, {0.0, 9.0}};
                                                                            when(spyEstimator.getCovariances(problem)).thenReturn(covariances);
                                                                            
                                                                            double[] errors = spyEstimator.guessParametersErrors(problem);
                                                                            
                                                                            assertEquals(2, errors.length);
                                                                            assertEquals(Math.sqrt(4.0) * Math.sqrt(9.0 / (3 - 2)), errors[0], 0.0001);
                                                                            assertEquals(Math.sqrt(9.0) * Math.sqrt(9.0 / (3 - 2)), errors[1], 0.0001);
                                                                        }

    @Test
                                                                    public void testGetCovariancesJacobianCalculation() throws Exception {
                                                                        // Create mock objects
                                                                        EstimationProblem problem = mock(EstimationProblem.class);
                                                                        WeightedMeasurement measurement1 = mock(WeightedMeasurement.class);
                                                                        WeightedMeasurement measurement2 = mock(WeightedMeasurement.class);
                                                                        EstimatedParameter parameter1 = mock(EstimatedParameter.class);
                                                                        EstimatedParameter parameter2 = mock(EstimatedParameter.class);
                                                                        
                                                                        // Setup mock measurements and parameters
                                                                        when(problem.getMeasurements()).thenReturn(new WeightedMeasurement[]{measurement1, measurement2});
                                                                        when(problem.getUnboundParameters()).thenReturn(new EstimatedParameter[]{parameter1, parameter2});
                                                                        when(measurement1.getWeight()).thenReturn(1.0);
                                                                        when(measurement2.getWeight()).thenReturn(1.0);
                                                                        when(measurement1.getPartial(parameter1)).thenReturn(2.0);
                                                                        when(measurement1.getPartial(parameter2)).thenReturn(3.0);
                                                                        when(measurement2.getPartial(parameter1)).thenReturn(4.0);
                                                                        when(measurement2.getPartial(parameter2)).thenReturn(5.0);
                                                                
                                                                        // Create estimator instance and set up reflection for jacobian field
                                                                        AbstractEstimator estimator = new AbstractEstimator() {
                                                                            public void estimate(EstimationProblem problem) {}
                                                                            public double getRMS(EstimationProblem problem) { return 0.0; }
                                                                        };
                                                                        
                                                                        Field jacobianField = AbstractEstimator.class.getDeclaredField("jacobian");
                                                                        jacobianField.setAccessible(true);
                                                                        jacobianField.set(estimator, new double[4]);
                                                                    
                                                                        double[][] result = estimator.getCovariances(problem);
                                                                    
                                                                        // Verify the jacobian was updated (called by getCovariances)
                                                                        double[] jacobian = (double[]) jacobianField.get(estimator);
                                                                        assertEquals(-2.0, jacobian[0], 1e-10);  // -sqrt(1.0) * 2.0
                                                                        assertEquals(-3.0, jacobian[1], 1e-10);  // -sqrt(1.0) * 3.0
                                                                        assertEquals(-4.0, jacobian[2], 1e-10);  // -sqrt(1.0) * 4.0
                                                                        assertEquals(-5.0, jacobian[3], 1e-10);  // -sqrt(1.0) * 5.0
                                                                    
                                                                        // Verify the result matrix is correct (inverse of J^T*J)
                                                                        double expectedDet = (2*2 + 4*4)*(3*3 + 5*5) - (2*3 + 4*5)*(2*3 + 4*5);
                                                                        double[][] expected = {
                                                                            {(3*3 + 5*5)/expectedDet, -(2*3 + 4*5)/expectedDet},
                                                                            {-(2*3 + 4*5)/expectedDet, (2*2 + 4*4)/expectedDet}
                                                                        };
                                                                    
                                                                        assertArrayEquals(expected[0], result[0], 1e-10);
                                                                        assertArrayEquals(expected[1], result[1], 1e-10);
                                                                    }

    @Test(expected = EstimationException.class)
                                    public void testGuessParametersErrorsWhenCovariancesThrowsException() throws EstimationException {
                                        // Create mock objects
                                        WeightedMeasurement measurement1 = mock(WeightedMeasurement.class);
                                        WeightedMeasurement measurement2 = mock(WeightedMeasurement.class);
                                        WeightedMeasurement measurement3 = mock(WeightedMeasurement.class);
                                        EstimatedParameter parameter1 = mock(EstimatedParameter.class);
                                        EstimatedParameter parameter2 = mock(EstimatedParameter.class);
                                        
                                        // Create mock problem
                                        EstimationProblem problem = mock(EstimationProblem.class);
                                        when(problem.getMeasurements()).thenReturn(new WeightedMeasurement[]{measurement1, measurement2, measurement3});
                                        when(problem.getUnboundParameters()).thenReturn(new EstimatedParameter[]{parameter1, parameter2});
                                        
                                        // Create spy estimator
                                        AbstractEstimator estimator = mock(AbstractEstimator.class);
                                        AbstractEstimator spyEstimator = spy(estimator);
                                        when(spyEstimator.getChiSquare(problem)).thenReturn(4.0);
                                        
                                        // Call method under test
                                        spyEstimator.guessParametersErrors(problem);
                                    }

    @Test(expected = EstimationException.class)
        public void testGetCovariancesWithSingularMatrix() throws Exception {
            // Create mock problem
            EstimationProblem problem = new EstimationProblem() {
                @Override
                public WeightedMeasurement[] getMeasurements() {
                    return new WeightedMeasurement[2];
                }
    
                @Override
                public EstimatedParameter[] getUnboundParameters() {
                    return new EstimatedParameter[2];
                }
    
                @Override
                public EstimatedParameter[] getAllParameters() {
                    return new EstimatedParameter[0];
                }
            };
    
            // Create estimator instance
            AbstractEstimator estimator = new AbstractEstimator() {
                @Override
                public void estimate(EstimationProblem problem) throws EstimationException {
                }
    
                @Override
                protected void updateResidualsAndCost() throws EstimationException {
                }
    
                @Override
                public double getRMS(EstimationProblem problem) {
                    return 0;
                }
    
                @Override
                public double getChiSquare(EstimationProblem problem) {
                    return 0;
                }
    
                @Override
                public double[][] getCovariances(EstimationProblem problem) throws EstimationException {
                    return super.getCovariances(problem);
                }
            };
    
            // Setup jacobian field using reflection
            Field jacobianField = AbstractEstimator.class.getDeclaredField("jacobian");
            jacobianField.setAccessible(true);
            
            // Setup jacobian values that will produce a singular matrix
            double[] jacobian = {1.0, 1.0, 1.0, 1.0};
            jacobianField.set(estimator, jacobian);
    
            estimator.getCovariances(problem);
        }


}
