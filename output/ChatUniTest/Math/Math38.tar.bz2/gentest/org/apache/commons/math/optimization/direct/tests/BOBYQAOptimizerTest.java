package gentest.org.apache.commons.math.optimization.direct.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.optimization.direct.*;
import java.util.Arrays;
import org.apache.commons.math.analysis.MultivariateFunction;
import org.apache.commons.math.exception.MathIllegalStateException;
import org.apache.commons.math.exception.NumberIsTooSmallException;
import org.apache.commons.math.exception.OutOfRangeException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.linear.Array2DRowRealMatrix;
import org.apache.commons.math.linear.ArrayRealVector;
import org.apache.commons.math.linear.RealVector;
import org.apache.commons.math.optimization.GoalType;
import org.apache.commons.math.optimization.RealPointValuePair;
import org.apache.commons.math.optimization.MultivariateOptimizer;
 
public class BOBYQAOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                            public void testPrelimInitializesMatrices() throws Exception {
                                                // Setup test data
                                                int numberOfInterpolationPoints = 10;
                                                int dimension = 5;
                                                double[] lowerBound = new double[dimension];
                                                double[] upperBound = new double[dimension];
                                                double[] currentBest = new double[dimension];
                                                
                                                // Create optimizer instance
                                                BOBYQAOptimizer optimizer = new BOBYQAOptimizer(numberOfInterpolationPoints, 
                                                                                               Double.NaN, 
                                                                                               Double.NaN);
                                        
                                                // Get private method via reflection
                                                Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", 
                                                                                                             double[].class, 
                                                                                                             double[].class);
                                                prelimMethod.setAccessible(true);
                                                
                                                // Invoke the method
                                                prelimMethod.invoke(optimizer, lowerBound, upperBound);
                                                
                                                // Verify interpolationPoints matrix is initialized to zeros
                                                Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                interpolationPointsField.setAccessible(true);
                                                Array2DRowRealMatrix interpolationPoints = (Array2DRowRealMatrix) 
                                                    interpolationPointsField.get(optimizer);
                                                for (int i = 0; i < interpolationPoints.getRowDimension(); i++) {
                                                    for (int j = 0; j < interpolationPoints.getColumnDimension(); j++) {
                                                        assertEquals(0.0, interpolationPoints.getEntry(i, j), 1e-15);
                                                    }
                                                }
                                                
                                                // Verify bMatrix is initialized to zeros
                                                Field bMatrixField = BOBYQAOptimizer.class.getDeclaredField("bMatrix");
                                                bMatrixField.setAccessible(true);
                                                Array2DRowRealMatrix bMatrix = (Array2DRowRealMatrix) 
                                                    bMatrixField.get(optimizer);
                                                for (int i = 0; i < bMatrix.getRowDimension(); i++) {
                                                    for (int j = 0; j < bMatrix.getColumnDimension(); j++) {
                                                        assertEquals(0.0, bMatrix.getEntry(i, j), 1e-15);
                                                    }
                                                }
                                                
                                                // Verify zMatrix is initialized to zeros
                                                Field zMatrixField = BOBYQAOptimizer.class.getDeclaredField("zMatrix");
                                                zMatrixField.setAccessible(true);
                                                Array2DRowRealMatrix zMatrix = (Array2DRowRealMatrix) 
                                                    zMatrixField.get(optimizer);
                                                for (int i = 0; i < zMatrix.getRowDimension(); i++) {
                                                    for (int j = 0; j < zMatrix.getColumnDimension(); j++) {
                                                        assertEquals(0.0, zMatrix.getEntry(i, j), 1e-15);
                                                    }
                                                }
                                                
                                                // Verify modelSecondDerivativesValues is initialized to zeros
                                                Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                modelSecondDerivativesValuesField.setAccessible(true);
                                                ArrayRealVector modelSecondDerivativesValues = (ArrayRealVector) 
                                                    modelSecondDerivativesValuesField.get(optimizer);
                                                for (int i = 0; i < modelSecondDerivativesValues.getDimension(); i++) {
                                                    assertEquals(0.0, modelSecondDerivativesValues.getEntry(i), 1e-15);
                                                }
                                                
                                                // Verify modelSecondDerivativesParameters is initialized to zeros
                                                Field modelSecondDerivativesParametersField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesParameters");
                                                modelSecondDerivativesParametersField.setAccessible(true);
                                                ArrayRealVector modelSecondDerivativesParameters = (ArrayRealVector) 
                                                    modelSecondDerivativesParametersField.get(optimizer);
                                                for (int i = 0; i < modelSecondDerivativesParameters.getDimension(); i++) {
                                                    assertEquals(0.0, modelSecondDerivativesParameters.getEntry(i), 1e-15);
                                                }
                                            }

    @Test
                                            public void testPrelimSetsOriginShift() throws Exception {
                                                // Setup test data
                                                double[] lowerBound = new double[]{-1.0, -1.0};
                                                double[] upperBound = new double[]{1.0, 1.0};
                                                double[] startPoint = new double[]{0.5, 0.5};
                                                
                                                // Create optimizer instance
                                                BOBYQAOptimizer optimizer = new BOBYQAOptimizer(5);
                                                
                                                // Set required fields via reflection
                                                Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                currentBestField.setAccessible(true);
                                                currentBestField.set(optimizer, new ArrayRealVector(startPoint));
                                                
                                                Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                interpolationPointsField.setAccessible(true);
                                                interpolationPointsField.set(optimizer, new ArrayRealVector(5, 2));
                                                
                                                // Get private method via reflection
                                                Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                prelimMethod.setAccessible(true);
                                                
                                                // Invoke the method
                                                prelimMethod.invoke(optimizer, lowerBound, upperBound);
                                                
                                                // Verify originShift is set to currentBest
                                                Field originShiftField = BOBYQAOptimizer.class.getDeclaredField("originShift");
                                                originShiftField.setAccessible(true);
                                                ArrayRealVector originShift = (ArrayRealVector) originShiftField.get(optimizer);
                                                
                                                ArrayRealVector currentBest = (ArrayRealVector) currentBestField.get(optimizer);
                                                
                                                assertEquals(currentBest.getDimension(), originShift.getDimension());
                                                for (int i = 0; i < currentBest.getDimension(); i++) {
                                                    assertEquals(currentBest.getEntry(i), originShift.getEntry(i), 1e-15);
                                                }
                                            }

    @Test
                                            public void testPrelimSetsFunctionValues() throws Exception {
                                                // Create test data
                                                double[] lowerBound = new double[]{-1.0, -1.0};
                                                double[] upperBound = new double[]{1.0, 1.0};
                                                
                                                // Create optimizer instance
                                                BOBYQAOptimizer optimizer = new BOBYQAOptimizer(5, 0.1, 0.01);
                                                
                                                // Mock the computeObjectiveValue method using reflection since it's protected
                                                BOBYQAOptimizer spyOptimizer = spy(optimizer);
                                                Method computeObjectiveValueMethod = BOBYQAOptimizer.class.getDeclaredMethod(
                                                    "computeObjectiveValue", double[].class);
                                                computeObjectiveValueMethod.setAccessible(true);
                                                when(computeObjectiveValueMethod.invoke(spyOptimizer, any(double[].class))).thenReturn(42.0);
                                                
                                                // Get private method via reflection
                                                Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod(
                                                    "prelim", double[].class, double[].class);
                                                prelimMethod.setAccessible(true);
                                                
                                                // Invoke the method
                                                prelimMethod.invoke(spyOptimizer, lowerBound, upperBound);
                                                
                                                // Verify fAtInterpolationPoints is populated
                                                Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                                fAtInterpolationPointsField.setAccessible(true);
                                                ArrayRealVector fAtInterpolationPoints = (ArrayRealVector) 
                                                    fAtInterpolationPointsField.get(spyOptimizer);
                                                
                                                for (int i = 0; i < fAtInterpolationPoints.getDimension(); i++) {
                                                    assertEquals(42.0, fAtInterpolationPoints.getEntry(i), 1e-15);
                                                }
                                            }

    @Test
                                            public void testPrelimHandlesBoundsCorrectly() throws Exception {
                                                // Set up bounds that will be hit
                                                double[] tightLowerBound = new double[]{1.0, 2.0, 3.0};
                                                double[] tightUpperBound = new double[]{1.0, 2.0, 3.0};
                                                
                                                // Create optimizer instance with required parameters
                                                int numberOfInterpolationPoints = 10;
                                                double initialTrustRegionRadius = 1.0;
                                                double stoppingTrustRegionRadius = 1e-8;
                                                BOBYQAOptimizer optimizer = new BOBYQAOptimizer(numberOfInterpolationPoints, 
                                                                                              initialTrustRegionRadius, 
                                                                                              stoppingTrustRegionRadius);
                                                
                                                // Set currentBest field via reflection
                                                Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                currentBestField.setAccessible(true);
                                                currentBestField.set(optimizer, new ArrayRealVector(new double[]{1.5, 2.5, 3.5}));
                                                
                                                // Get private method via reflection
                                                Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                prelimMethod.setAccessible(true);
                                                
                                                // Invoke the method
                                                prelimMethod.invoke(optimizer, tightLowerBound, tightUpperBound);
                                                
                                                // Verify currentBest is set to bounds when interpolation points hit bounds
                                                ArrayRealVector currentBest = (ArrayRealVector) 
                                                    optimizer.getClass().getDeclaredField("currentBest").get(optimizer);
                                                
                                                for (int i = 0; i < currentBest.getDimension(); i++) {
                                                    assertTrue(currentBest.getEntry(i) >= tightLowerBound[i]);
                                                    assertTrue(currentBest.getEntry(i) <= tightUpperBound[i]);
                                                }
                                            }

    @Test
        public void testPrelimUpdatesTrustRegionCenterIndex() throws Exception {
            // Setup test data
            double[] lowerBound = new double[]{-1.0, -1.0};
            double[] upperBound = new double[]{1.0, 1.0};
            int numberOfInterpolationPoints = 10;
            
            // Create optimizer instance
            BOBYQAOptimizer optimizer = new BOBYQAOptimizer(numberOfInterpolationPoints);
            
            // Create spy and mock the internal state
            BOBYQAOptimizer spyOptimizer = spy(optimizer);
            when(spyOptimizer.getEvaluations()).thenReturn(0);
            
            // Mock the internal array that stores objective values
            double[] fVal = new double[numberOfInterpolationPoints];
            for (int i = 0; i < fVal.length; i++) {
                fVal[i] = 100.0 - i * 10.0;
            }
            
            // Get private method via reflection
            Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
            prelimMethod.setAccessible(true);
            
            // Invoke the method
            prelimMethod.invoke(spyOptimizer, lowerBound, upperBound);
            
            // Verify trustRegionCenterInterpolationPointIndex is set to the last index
            Field field = BOBYQAOptimizer.class.getDeclaredField("trustRegionCenterInterpolationPointIndex");
            field.setAccessible(true);
            int trustRegionCenterInterpolationPointIndex = field.getInt(spyOptimizer);
            assertEquals(9, trustRegionCenterInterpolationPointIndex);
        }


}
