package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import org.apache.commons.math.exception.DimensionMismatchException;
import org.apache.commons.math.exception.OutOfRangeException;
import org.apache.commons.math.exception.NotStrictlyPositiveException;
import org.apache.commons.math.util.MathUtils;
 
public class MultidimensionalCounterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                public void testGetCountsWithDifferentDimensions() {
                                    MultidimensionalCounter smallCounter = new MultidimensionalCounter(1, 1);
                                    int[] expected = {0, 0};
                                    assertArrayEquals(expected, smallCounter.getCounts(0));
                            
                                    MultidimensionalCounter largeCounter = new MultidimensionalCounter(5, 5, 5, 5);
                                    expected = new int[]{0, 0, 0, 0};
                                    assertArrayEquals(expected, largeCounter.getCounts(0));
                            
                                    expected = new int[]{4, 4, 4, 4};
                                    assertArrayEquals(expected, largeCounter.getCounts(624));
                                }

    @Test
                            public void testGetCountsValidIndex() {
                                int[] sizes = {2, 3, 4};
                                MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                                
                                int[] expected = {0, 0, 0};
                                assertArrayEquals(expected, counter.getCounts(0));
                                
                                expected = new int[]{0, 0, 1};
                                assertArrayEquals(expected, counter.getCounts(1));
                                
                                expected = new int[]{0, 0, 3};
                                assertArrayEquals(expected, counter.getCounts(3));
                                
                                expected = new int[]{0, 1, 0};
                                assertArrayEquals(expected, counter.getCounts(4));
                                
                                expected = new int[]{0, 2, 3};
                                assertArrayEquals(expected, counter.getCounts(11));
                                
                                expected = new int[]{1, 0, 0};
                                assertArrayEquals(expected, counter.getCounts(12));
                                
                                expected = new int[]{1, 2, 3};
                                assertArrayEquals(expected, counter.getCounts(23));
                            }

    @Test(expected = OutOfRangeException.class)
                            public void testGetCountsNegativeIndex() {
                                int[] size = {2, 3};
                                MultidimensionalCounter counter = new MultidimensionalCounter(size);
                                counter.getCounts(-1);
                            }

    @Test(expected = org.apache.commons.math.exception.OutOfRangeException.class)
                            public void testGetCountsIndexEqualToTotalSize() {
                                int[] size = {2, 3, 4};
                                MultidimensionalCounter counter = new MultidimensionalCounter(size);
                                counter.getCounts(24); // 24 = 2*3*4 which equals totalSize
                            }

    @Test(expected = org.apache.commons.math.exception.OutOfRangeException.class)
                            public void testGetCountsIndexGreaterThanTotalSize() {
                                int[] size = {2, 3, 4};
                                MultidimensionalCounter counter = new MultidimensionalCounter(size);
                                counter.getCounts(25);
                            }

    @Test
                            public void testGetCountsBoundaryConditions() {
                                int[] sizes = {1, 2, 3};
                                MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                                
                                int[] expected = {0, 0, 0};
                                assertArrayEquals(expected, counter.getCounts(0));
                                
                                expected = new int[]{1, 2, 2};
                                assertArrayEquals(expected, counter.getCounts(8));
                            }

    @Test
                            public void testGetCountsAfterMultipleNext() {
                                int[] sizes = new int[]{3, 3};
                                MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                                MultidimensionalCounter.Iterator iterator = counter.iterator();
                                
                                iterator.next(); // [0,0]
                                iterator.next(); // [0,1]
                                iterator.next(); // [0,2]
                                iterator.next(); // [1,0]
                                
                                int[] expected = new int[]{1, 0};
                                int[] actual = iterator.getCounts();
                                assertArrayEquals(expected, actual);
                            }

    @Test
                            public void testGetCountsReturnsCopy() {
                                int[] sizes = {2, 3};
                                MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                                MultidimensionalCounter.Iterator iterator = counter.iterator();
                                
                                int[] counts1 = iterator.getCounts();
                                iterator.next();
                                int[] counts2 = iterator.getCounts();
                                
                                assertNotSame(counts1, counts2);
                                assertFalse(java.util.Arrays.equals(counts1, counts2));
                            }

    @Test
                            public void testGetCountsAtEndOfFirstDimension() {
                                // Create a 2x2 counter
                                MultidimensionalCounter counter = new MultidimensionalCounter(2, 2);
                                MultidimensionalCounter.Iterator iterator = counter.iterator();
                                
                                iterator.next(); // [0,0]
                                iterator.next(); // [0,1]
                                iterator.next(); // [1,0]
                                
                                int[] expected = new int[]{1, 0};
                                int[] actual = iterator.getCounts();
                                assertArrayEquals(expected, actual);
                            }

    @Test
                            public void testGetCountsWithSingleDimension() {
                                MultidimensionalCounter counter = new MultidimensionalCounter(3);
                                MultidimensionalCounter.Iterator iterator = counter.iterator();
                                
                                iterator.next(); // [0]
                                iterator.next(); // [1]
                                
                                int[] expected = new int[]{1};
                                int[] actual = iterator.getCounts();
                                assertArrayEquals(expected, actual);
                            }

    @Test
                    public void testGetCountsAfterNext() {
                        class MultidimensionalCounter {
                            private final int[] sizes;
                            private int[] counts;
                
                            public MultidimensionalCounter(int[] sizes) {
                                this.sizes = sizes;
                                this.counts = new int[sizes.length];
                                for (int i = 0; i < counts.length; i++) {
                                    counts[i] = sizes[i] - 1;
                                }
                            }
                
                            public void next() {
                                for (int i = counts.length - 1; i >= 0; i--) {
                                    if (counts[i] > 0) {
                                        counts[i]--;
                                        break;
                                    } else {
                                        counts[i] = sizes[i] - 1;
                                    }
                                }
                            }
                
                            public int[] getCounts() {
                                return counts.clone();
                            }
                        }
                
                        int[] sizes = new int[]{2, 2};
                        MultidimensionalCounter iterator = new MultidimensionalCounter(sizes);
                        iterator.next();
                        int[] expected = new int[]{0, 0};
                        int[] actual = iterator.getCounts();
                        assertArrayEquals(expected, actual);
                    }

    @Test
        public void testGetCountsInitialState() throws Exception {
            int[] sizes = new int[]{2, 3};
            MultidimensionalCounter iterator = new MultidimensionalCounter(sizes);
            int[] expected = new int[]{0, 0};
            
            Field countsField = MultidimensionalCounter.class.getDeclaredField("counts");
            countsField.setAccessible(true);
            int[] actual = (int[]) countsField.get(iterator);
            
            assertArrayEquals(expected, actual);
        }


}
