package gentest.org.apache.commons.math.analysis.solvers.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.analysis.solvers.*;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.analysis.UnivariateRealFunction;
 
public class BisectionSolverTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                    public void testSolveWithInitialValue() throws FunctionEvaluationException, MaxIterationsExceededException {
                        // Create mock function and solver
                        UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                        BisectionSolver bisectionSolver = new BisectionSolver();
                        
                        // Setup mock function behavior
                        when(mockFunction.value(1.0)).thenReturn(-1.0);
                        when(mockFunction.value(2.0)).thenReturn(1.0);
                        when(mockFunction.value(1.5)).thenReturn(0.0);
                    
                        // Set function field using reflection
                        try {
                            java.lang.reflect.Field field = BisectionSolver.class.getDeclaredField("f");
                            field.setAccessible(true);
                            field.set(bisectionSolver, mockFunction);
                        } catch (Exception e) {
                            fail("Failed to set field via reflection");
                        }
                    
                        double result = bisectionSolver.solve(1.0, 2.0, 1.5);
                        assertEquals(1.5, result, 0.0001);
                    }

    @Test(expected = MaxIterationsExceededException.class)
                    public void testSolveThrowsMaxIterationsExceeded() throws FunctionEvaluationException, MaxIterationsExceededException {
                        // Create mock function
                        UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                        
                        // Setup mock function behavior to never converge
                        when(mockFunction.value(anyDouble())).thenReturn(1.0);
                
                        // Create solver with mock function
                        BisectionSolver bisectionSolver = new BisectionSolver(mockFunction);
                
                        // Set function field using reflection
                        try {
                            java.lang.reflect.Field field = BisectionSolver.class.getDeclaredField("f");
                            field.setAccessible(true);
                            field.set(bisectionSolver, mockFunction);
                        } catch (Exception e) {
                            fail("Failed to set field via reflection");
                        }
                
                        // Create solver with very low iteration count
                        BisectionSolver solverWithLowIterations = new BisectionSolver(mockFunction);
                        try {
                            java.lang.reflect.Field maxIterField = BisectionSolver.class.getSuperclass().getDeclaredField("maximalIterationCount");
                            maxIterField.setAccessible(true);
                            maxIterField.set(solverWithLowIterations, 1);
                        } catch (Exception e) {
                            fail("Failed to set maximalIterationCount via reflection");
                        }
                
                        solverWithLowIterations.solve(1.0, 2.0, 1.5);
                    }

    @Test(expected = FunctionEvaluationException.class)
                    public void testSolveThrowsFunctionEvaluationException() throws FunctionEvaluationException, MaxIterationsExceededException {
                        // Create mock function and solver
                        UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                        BisectionSolver bisectionSolver = new BisectionSolver();
                        
                        // Setup mock function to throw exception
                        when(mockFunction.value(anyDouble())).thenThrow(new FunctionEvaluationException(0.0));
                
                        // Set function field using reflection
                        try {
                            java.lang.reflect.Field field = BisectionSolver.class.getDeclaredField("f");
                            field.setAccessible(true);
                            field.set(bisectionSolver, mockFunction);
                        } catch (Exception e) {
                            fail("Failed to set field via reflection");
                        }
                
                        bisectionSolver.solve(1.0, 2.0, 1.5);
                    }

    @Test
                    public void testSolveWithInitialValueIgnoresInitialParameter() throws FunctionEvaluationException, MaxIterationsExceededException {
                        // Create mock function
                        UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                        
                        // Setup mock function behavior
                        when(mockFunction.value(1.0)).thenReturn(-1.0);
                        when(mockFunction.value(2.0)).thenReturn(1.0);
                        when(mockFunction.value(1.5)).thenReturn(0.0);
                        
                        // Create solver instance
                        BisectionSolver bisectionSolver = new BisectionSolver();
                
                        // Set function field using reflection
                        try {
                            java.lang.reflect.Field field = BisectionSolver.class.getDeclaredField("f");
                            field.setAccessible(true);
                            field.set(bisectionSolver, mockFunction);
                        } catch (Exception e) {
                            fail("Failed to set field via reflection");
                        }
                        
                        // The initial parameter (1.9) should be ignored
                        double result = bisectionSolver.solve(1.0, 2.0, 1.9);
                        assertEquals(1.5, result, 0.0001);
                    }

    @Test
                    public void testSolveWithValidRange() throws Exception {
                        UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                        BisectionSolver bisectionSolver = new BisectionSolver();
                        
                        when(mockFunction.value(1.0)).thenReturn(-1.0);
                        when(mockFunction.value(2.0)).thenReturn(1.0);
                        when(mockFunction.value(1.5)).thenReturn(0.0);
                
                        double result = bisectionSolver.solve(mockFunction, 1.0, 2.0);
                        assertEquals(1.5, result, 0.0001);
                    }

    @Test(expected = IllegalArgumentException.class)
                    public void testSolveWithInvalidRange() throws Exception {
                        BisectionSolver bisectionSolver = new BisectionSolver();
                        UnivariateRealFunction f = new UnivariateRealFunction() {
                            public double value(double x) {
                                return x;
                            }
                        };
                        bisectionSolver.solve(f, 2.0, 1.0);
                    }

    @Test
                    public void testSolveWithRootAtMidpoint() throws Exception {
                        UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                        BisectionSolver bisectionSolver = new BisectionSolver();
                        
                        when(mockFunction.value(1.0)).thenReturn(-1.0);
                        when(mockFunction.value(2.0)).thenReturn(1.0);
                        when(mockFunction.value(1.5)).thenReturn(0.0);
                    
                        double result = bisectionSolver.solve(mockFunction, 1.0, 2.0);
                        assertEquals(1.5, result, 0.0001);
                    }

    @Test
                    public void testSolveWithRootNearBoundary() throws Exception {
                        UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                        BisectionSolver bisectionSolver = new BisectionSolver();
                        
                        when(mockFunction.value(1.0)).thenReturn(-0.1);
                        when(mockFunction.value(2.0)).thenReturn(1.0);
                        when(mockFunction.value(1.1)).thenReturn(0.0);
                
                        double result = bisectionSolver.solve(mockFunction, 1.0, 2.0);
                        assertEquals(1.1, result, 0.0001);
                    }

    @Test
                    public void testSolveWithMultipleIterations() throws Exception {
                        UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                        BisectionSolver bisectionSolver = new BisectionSolver();
                        
                        when(mockFunction.value(1.0)).thenReturn(-1.0);
                        when(mockFunction.value(2.0)).thenReturn(1.0);
                        when(mockFunction.value(1.5)).thenReturn(0.5);
                        when(mockFunction.value(1.25)).thenReturn(-0.25);
                        when(mockFunction.value(1.375)).thenReturn(0.125);
                        when(mockFunction.value(1.3125)).thenReturn(-0.0625);
                        when(mockFunction.value(1.34375)).thenReturn(0.03125);
                        when(mockFunction.value(1.328125)).thenReturn(-0.015625);
                        when(mockFunction.value(1.3359375)).thenReturn(0.0078125);
                        when(mockFunction.value(1.33203125)).thenReturn(0.0);
                    
                        double result = bisectionSolver.solve(mockFunction, 1.0, 2.0);
                        assertEquals(1.33203125, result, 0.00000001);
                    }

    @Test
                    public void testSolveWithValidInput() throws FunctionEvaluationException, MaxIterationsExceededException {
                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                        BisectionSolver bisectionSolver = new BisectionSolver();
                        
                        when(function.value(1.0)).thenReturn(-1.0);
                        when(function.value(2.0)).thenReturn(1.0);
                        when(function.value(1.5)).thenReturn(0.0);
                    
                        double result = bisectionSolver.solve(function, 1.0, 2.0, 1.5);
                        assertEquals(1.5, result, 0.0001);
                    }

    @Test
                    public void testSolveWithRootAtMidpoint1() throws FunctionEvaluationException, MaxIterationsExceededException {
                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                        BisectionSolver bisectionSolver = new BisectionSolver();
                        
                        when(function.value(0.0)).thenReturn(-1.0);
                        when(function.value(2.0)).thenReturn(1.0);
                        when(function.value(1.0)).thenReturn(0.0);
                    
                        double result = bisectionSolver.solve(function, 0.0, 2.0, 1.0);
                        assertEquals(1.0, result, 0.0001);
                    }

    @Test
                    public void testSolveWithRootNearLeftBoundary() throws FunctionEvaluationException, MaxIterationsExceededException {
                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                        BisectionSolver bisectionSolver = new BisectionSolver();
                        
                        when(function.value(0.0)).thenReturn(-0.1);
                        when(function.value(1.0)).thenReturn(1.0);
                        when(function.value(0.5)).thenReturn(0.5);
                        when(function.value(0.25)).thenReturn(0.2);
                        when(function.value(0.125)).thenReturn(0.05);
                        when(function.value(0.0625)).thenReturn(-0.025);
                
                        double result = bisectionSolver.solve(function, 0.0, 1.0, 0.5);
                        assertTrue(result > 0.0625 && result < 0.125);
                    }

    @Test(expected = MaxIterationsExceededException.class)
                    public void testSolveThrowsMaxIterationsExceededException() throws FunctionEvaluationException, MaxIterationsExceededException {
                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                        BisectionSolver bisectionSolver = new BisectionSolver();
                        
                        when(function.value(anyDouble())).thenReturn(1.0);
                        bisectionSolver.solve(function, 0.0, 1.0, 0.5);
                    }

    @Test(expected = IllegalArgumentException.class)
                    public void testSolveWithInvalidInterval() throws FunctionEvaluationException, MaxIterationsExceededException {
                        BisectionSolver bisectionSolver = new BisectionSolver();
                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                        bisectionSolver.solve(function, 2.0, 1.0, 1.5);
                    }

    @Test
                    public void testSolveIgnoresInitialValue() throws FunctionEvaluationException, MaxIterationsExceededException {
                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                        BisectionSolver bisectionSolver = new BisectionSolver();
                        
                        when(function.value(1.0)).thenReturn(-1.0);
                        when(function.value(3.0)).thenReturn(1.0);
                        when(function.value(2.0)).thenReturn(0.0);
                    
                        double result = bisectionSolver.solve(function, 1.0, 3.0, 5.0); // initial value 5.0 is ignored
                        assertEquals(2.0, result, 0.0001);
                    }

    @Test
                    public void testSolveWithFunctionEvaluationAtBoundaries() throws FunctionEvaluationException, MaxIterationsExceededException {
                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                        BisectionSolver bisectionSolver = new BisectionSolver();
                        
                        when(function.value(0.0)).thenReturn(0.0);
                        when(function.value(1.0)).thenReturn(1.0);
                        
                        double result = bisectionSolver.solve(function, 0.0, 1.0, 0.5);
                        assertEquals(0.0, result, 0.0001);
                    }

    @Test
                public void testSolveWithSameSignAtEndpoints() throws FunctionEvaluationException {
                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                    BisectionSolver solver = new BisectionSolver();
                    
                    when(function.value(1.0)).thenReturn(1.0);
                    when(function.value(2.0)).thenReturn(1.0);
                    
                    try {
                        solver.solve(function, 1.0, 2.0);
                        fail("Expected MaxIterationsExceededException");
                    } catch (MaxIterationsExceededException e) {
                        // expected
                    }
                }

    @Test(expected = org.apache.commons.math.MaxIterationsExceededException.class)
                public void testSolveExceedsMaxIterations1() throws Exception {
                    UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                    
                    when(mockFunction.value(1.0)).thenReturn(-1.0);
                    when(mockFunction.value(2.0)).thenReturn(1.0);
                    when(mockFunction.value(anyDouble())).thenReturn(0.5); // Never converges
                
                    // Create solver with very low max iterations
                    BisectionSolver lowIterationSolver = new BisectionSolver();
                    lowIterationSolver.setMaximalIterationCount(1);
                    lowIterationSolver.setAbsoluteAccuracy(1E-6);
                    lowIterationSolver.solve(mockFunction, 1.0, 2.0);
                }

    @Test
        public void testSolveConverges() throws FunctionEvaluationException, MaxIterationsExceededException {
            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
            BisectionSolver solver = new BisectionSolver();
            
            when(function.value(1.0)).thenReturn(-1.0);
            when(function.value(2.0)).thenReturn(1.0);
            when(function.value(1.5)).thenReturn(-0.5);
            when(function.value(1.75)).thenReturn(0.25);
            when(function.value(1.625)).thenReturn(-0.125);
            when(function.value(1.6875)).thenReturn(0.0625);
            
            double result = solver.solve(function, 1.0, 2.0);
            
            assertEquals(1.6875, result, 0.0001);
            verify(function, atLeastOnce()).value(anyDouble());
        }

    @Test
        public void testSolveConvergesQuickly() throws FunctionEvaluationException, MaxIterationsExceededException {
            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
            BisectionSolver solver = new BisectionSolver();
            
            when(function.value(1.0)).thenReturn(-1.0);
            when(function.value(2.0)).thenReturn(1.0);
            when(function.value(1.5)).thenReturn(0.0);
            
            double result = solver.solve(function, 1.0, 2.0);
            
            assertEquals(1.5, result, 0.0001);
        }

    @Test(expected = MaxIterationsExceededException.class)
        public void testSolveExceedsMaxIterations() throws Exception {
            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
            when(function.value(anyDouble())).thenReturn(1.0);
            
            BisectionSolver solver = new BisectionSolver();
            solver.setMaximalIterationCount(1);
            solver.solve(function, 1.0, 2.0);
        }

    @Test
        public void testSolveWhenRootAtMin() throws FunctionEvaluationException, MaxIterationsExceededException {
            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
            BisectionSolver solver = new BisectionSolver();
            
            when(function.value(0.0)).thenReturn(0.0);
            when(function.value(1.0)).thenReturn(1.0);
            
            double result = solver.solve(function, 0.0, 1.0);
            
            assertEquals(0.0, result, 0.0001);
        }

    @Test
        public void testSolveWhenRootAtMax() throws FunctionEvaluationException, MaxIterationsExceededException {
            BisectionSolver solver = new BisectionSolver();
            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
            
            when(function.value(0.0)).thenReturn(-1.0);
            when(function.value(1.0)).thenReturn(0.0);
            
            double result = solver.solve(function, 0.0, 1.0);
            
            assertEquals(1.0, result, 0.0001);
        }

    @Test
        public void testSolveWhenRootAtMidpoint() throws FunctionEvaluationException, MaxIterationsExceededException {
            BisectionSolver solver = new BisectionSolver();
            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
            
            when(function.value(0.0)).thenReturn(-1.0);
            when(function.value(1.0)).thenReturn(1.0);
            when(function.value(0.5)).thenReturn(0.0);
            
            double result = solver.solve(function, 0.0, 1.0);
            
            assertEquals(0.5, result, 0.0001);
        }

    @Test(expected = MaxIterationsExceededException.class)
        public void testSolveInvalidInterval() throws FunctionEvaluationException, MaxIterationsExceededException {
            BisectionSolver solver = new BisectionSolver();
            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
            when(function.value(anyDouble())).thenReturn(1.0);
            
            solver.solve(function, 2.0, 1.0);
        }

    @Test
        public void testSolveWithFunctionEvaluationException1() throws FunctionEvaluationException, MaxIterationsExceededException {
            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
            BisectionSolver solver = new BisectionSolver();
            
            when(function.value(anyDouble())).thenThrow(new FunctionEvaluationException(0.0));
            
            try {
                solver.solve(function, 1.0, 2.0);
                fail("Expected FunctionEvaluationException");
            } catch (FunctionEvaluationException e) {
                // expected
            }
        }

    @Test
        public void testSolveWithFunctionEvaluationException() throws FunctionEvaluationException, MaxIterationsExceededException {
            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
            BisectionSolver solver = new BisectionSolver();
            
            when(function.value(anyDouble())).thenThrow(new FunctionEvaluationException(0.0));
            
            try {
                solver.solve(function, 1.0, 2.0);
                fail("Expected FunctionEvaluationException");
            } catch (FunctionEvaluationException e) {
                // expected
            }
        }


}
