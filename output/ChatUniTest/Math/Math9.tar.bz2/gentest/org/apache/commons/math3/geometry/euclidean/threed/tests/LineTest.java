package gentest.org.apache.commons.math3.geometry.euclidean.threed.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.geometry.euclidean.threed.*;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.geometry.Vector;
import org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D;
import org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet;
import org.apache.commons.math3.geometry.euclidean.oned.Vector1D;
import org.apache.commons.math3.geometry.partitioning.Embedding;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Precision;
 
public class LineTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testRevert() {
            // Create original line
            Vector3D p1 = new Vector3D(1, 0, 0);
            Vector3D p2 = new Vector3D(2, 0, 0);
            Line originalLine = new Line(p1, p2);
            
            // Store original direction
            Vector3D originalDirection = originalLine.getDirection();
            
            // Call revert
            Line revertedLine = originalLine.revert();
            
            // Verify the reverted line is a new instance
            assertNotSame(originalLine, revertedLine);
            
            // Verify the direction is negated
            assertEquals(originalDirection.negate(), revertedLine.getDirection());
            
            // Verify the origin point remains the same
            assertEquals(originalLine.getOrigin(), revertedLine.getOrigin());
            
            // Verify the original line wasn't modified
            assertEquals(originalDirection, originalLine.getDirection());
        }

    @Test
        public void testRevertWithMock() {
            // Create mock line
            Line mockLine = mock(Line.class);
            Vector3D mockDirection = mock(Vector3D.class);
            Vector3D mockNegatedDirection = mock(Vector3D.class);
            Vector3D mockZero = mock(Vector3D.class);
            
            when(mockLine.getDirection()).thenReturn(mockDirection);
            when(mockDirection.negate()).thenReturn(mockNegatedDirection);
            when(mockLine.getOrigin()).thenReturn(mockZero);
            
            // Create test line using copy constructor
            Line testLine = new Line(mockLine);
            
            // Call revert
            Line revertedLine = testLine.revert();
            
            // Verify interactions
            verify(mockDirection).negate();
            
            // Verify the reverted line has the negated direction
            assertEquals(mockNegatedDirection, revertedLine.getDirection());
            
            // Verify the origin remains the same
            assertEquals(mockZero, revertedLine.getOrigin());
        }

    @Test
        public void testRevertTwiceReturnsOriginal() {
            // Create original line
            Vector3D p1 = new Vector3D(1, 2, 3);
            Vector3D p2 = new Vector3D(4, 5, 6);
            Line originalLine = new Line(p1, p2);
            
            // Revert twice
            Line revertedOnce = originalLine.revert();
            Line revertedTwice = revertedOnce.revert();
            
            // Verify twice reverted line is equal to original
            assertEquals(originalLine.getDirection(), revertedTwice.getDirection());
            assertEquals(originalLine.getOrigin(), revertedTwice.getOrigin());
        }

}
