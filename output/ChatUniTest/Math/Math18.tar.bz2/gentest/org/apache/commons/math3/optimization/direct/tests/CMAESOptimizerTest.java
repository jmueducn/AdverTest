package gentest.org.apache.commons.math3.optimization.direct.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.optimization.direct.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.math3.analysis.MultivariateFunction;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MathUnsupportedOperationException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.exception.OutOfRangeException;
import org.apache.commons.math3.exception.TooManyEvaluationsException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.EigenDecomposition;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.optimization.ConvergenceChecker;
import org.apache.commons.math3.optimization.GoalType;
import org.apache.commons.math3.optimization.MultivariateOptimizer;
import org.apache.commons.math3.optimization.PointValuePair;
import org.apache.commons.math3.optimization.SimpleValueChecker;
import org.apache.commons.math3.random.MersenneTwister;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.util.MathArrays;
 
public class CMAESOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                    public void testEncodeWithNullBoundaries() throws Exception {
                                                                                                        CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                        
                                                                                                        // Use reflection to access private encode method
                                                                                                        Method encodeMethod = CMAESOptimizer.class.getDeclaredMethod("encode", double[].class);
                                                                                                        encodeMethod.setAccessible(true);
                                                                                                        
                                                                                                        // Set boundaries to null
                                                                                                        java.lang.reflect.Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                        boundariesField.setAccessible(true);
                                                                                                        boundariesField.set(optimizer, null);
                                                                                                        
                                                                                                        double[] input = {1.0, 2.0, 3.0};
                                                                                                        double[] result = (double[]) encodeMethod.invoke(optimizer, input);
                                                                                                        
                                                                                                        assertArrayEquals(input, result, 0.0);
                                                                                                    }

    @Test
                                                                                                    public void testDecodeWithNullBoundaries() throws Exception {
                                                                                                        // Setup
                                                                                                        CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                        Method decodeMethod = CMAESOptimizer.class.getDeclaredMethod("decode", double[].class);
                                                                                                        decodeMethod.setAccessible(true);
                                                                                                        
                                                                                                        // Set boundaries to null using reflection
                                                                                                        java.lang.reflect.Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                        boundariesField.setAccessible(true);
                                                                                                        boundariesField.set(optimizer, null);
                                                                                                        
                                                                                                        double[] input = {0.5, 1.0, 1.5};
                                                                                                        
                                                                                                        // Execute
                                                                                                        double[] result = (double[]) decodeMethod.invoke(optimizer, input);
                                                                                                        
                                                                                                        // Verify
                                                                                                        assertArrayEquals(input, result, 0.0);
                                                                                                    }

    @Test
                                                                                                    public void testIsFeasible_NoBoundaries() throws Exception {
                                                                                                        CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                        
                                                                                                        // Use reflection to access private method
                                                                                                        Method isFeasibleMethod = CMAESOptimizer.class.getDeclaredMethod("isFeasible", double[].class);
                                                                                                        isFeasibleMethod.setAccessible(true);
                                                                                                        
                                                                                                        // Set boundaries to null
                                                                                                        java.lang.reflect.Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                        boundariesField.setAccessible(true);
                                                                                                        boundariesField.set(optimizer, null);
                                                                                                        
                                                                                                        double[] x = {1.0, 2.0, 3.0};
                                                                                                        
                                                                                                        boolean result = (boolean) isFeasibleMethod.invoke(optimizer, (Object) x);
                                                                                                        assertTrue(result);
                                                                                                    }

    @Test
                                                                                                public void testEncodeWithBoundaries() throws Exception {
                                                                                                    // Create test objects
                                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                    
                                                                                                    // Set up boundaries using reflection
                                                                                                    Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                    boundariesField.setAccessible(true);
                                                                                                    boundariesField.set(optimizer, new double[][]{{0.0, 0.0, 0.0}, {10.0, 20.0, 30.0}});
                                                                                                    
                                                                                                    // Get private method using reflection
                                                                                                    Method encodeMethod = CMAESOptimizer.class.getDeclaredMethod("encode", double[].class);
                                                                                                    encodeMethod.setAccessible(true);
                                                                                                    
                                                                                                    // Test data
                                                                                                    double[] input = {5.0, 10.0, 15.0};
                                                                                                    double[] expected = {0.5, 0.5, 0.5};
                                                                                                    
                                                                                                    // Invoke method
                                                                                                    double[] result = (double[]) encodeMethod.invoke(optimizer, input);
                                                                                                    
                                                                                                    // Assert
                                                                                                    assertArrayEquals(expected, result, 0.0001);
                                                                                                }

    @Test
                                                                                                public void testEncodeWithDifferentBoundaries() throws Exception {
                                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                    Method encodeMethod = CMAESOptimizer.class.getDeclaredMethod("encode", double[].class);
                                                                                                    encodeMethod.setAccessible(true);
                                                                                                    
                                                                                                    // Access private boundaries field using reflection
                                                                                                    Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                    boundariesField.setAccessible(true);
                                                                                                    boundariesField.set(optimizer, new double[][]{{1.0, 2.0, 3.0}, {11.0, 22.0, 33.0}});
                                                                                                    
                                                                                                    double[] input = {6.0, 12.0, 18.0};
                                                                                                    double[] expected = {0.5, 0.5, 0.5};
                                                                                                    
                                                                                                    double[] result = (double[]) encodeMethod.invoke(optimizer, input);
                                                                                                    
                                                                                                    assertArrayEquals(expected, result, 0.0001);
                                                                                                }

    @Test
                                                                                                public void testEncodeWithZeroRangeBoundaries() throws Exception {
                                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                    
                                                                                                    // Set private boundaries field using reflection
                                                                                                    Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                    boundariesField.setAccessible(true);
                                                                                                    boundariesField.set(optimizer, new double[][]{{5.0, 5.0, 5.0}, {5.0, 5.0, 5.0}});
                                                                                                    
                                                                                                    double[] input = {5.0, 5.0, 5.0};
                                                                                                    
                                                                                                    Method encodeMethod = CMAESOptimizer.class.getDeclaredMethod("encode", double[].class);
                                                                                                    encodeMethod.setAccessible(true);
                                                                                                    
                                                                                                    try {
                                                                                                        encodeMethod.invoke(optimizer, input);
                                                                                                        fail("Expected NumberIsTooLargeException");
                                                                                                    } catch (Exception e) {
                                                                                                        assertTrue(e.getCause() instanceof NumberIsTooLargeException);
                                                                                                    }
                                                                                                }

    @Test
                                                                                                public void testEncodeWithSingleDimension() throws Exception {
                                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                    Method encodeMethod = CMAESOptimizer.class.getDeclaredMethod("encode", double[].class);
                                                                                                    encodeMethod.setAccessible(true);
                                                                                                    
                                                                                                    // Set private boundaries field using reflection
                                                                                                    Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                    boundariesField.setAccessible(true);
                                                                                                    boundariesField.set(optimizer, new double[][]{{0.0}, {100.0}});
                                                                                                    
                                                                                                    double[] input = {25.0};
                                                                                                    double[] expected = {0.25};
                                                                                                    
                                                                                                    double[] result = (double[]) encodeMethod.invoke(optimizer, input);
                                                                                                    
                                                                                                    assertArrayEquals(expected, result, 0.0001);
                                                                                                }

    @Test
                                                                                                public void testEncodeWithLargeValues() throws Exception {
                                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                    
                                                                                                    // Use reflection to set private boundaries field
                                                                                                    Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                    boundariesField.setAccessible(true);
                                                                                                    boundariesField.set(optimizer, new double[][]{{0.0, 0.0}, {Double.MAX_VALUE/2, Double.MAX_VALUE/2}});
                                                                                                    
                                                                                                    Method encodeMethod = CMAESOptimizer.class.getDeclaredMethod("encode", double[].class);
                                                                                                    encodeMethod.setAccessible(true);
                                                                                                    
                                                                                                    double[] input = {Double.MAX_VALUE/4, Double.MAX_VALUE/4};
                                                                                                    double[] expected = {0.5, 0.5};
                                                                                                    
                                                                                                    double[] result = (double[]) encodeMethod.invoke(optimizer, input);
                                                                                                    
                                                                                                    assertArrayEquals(expected, result, 0.0001);
                                                                                                }

    @Test
                                                                                                public void testDecodeWithBoundaries() throws Exception {
                                                                                                    // Setup
                                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                    
                                                                                                    // Use reflection to access private boundaries field
                                                                                                    Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                    boundariesField.setAccessible(true);
                                                                                                    boundariesField.set(optimizer, new double[][] {
                                                                                                        {0.0, 0.0, 0.0},  // lower bounds
                                                                                                        {2.0, 4.0, 6.0}    // upper bounds
                                                                                                    });
                                                                                                    
                                                                                                    // Use reflection to access private decode method
                                                                                                    Method decodeMethod = CMAESOptimizer.class.getDeclaredMethod("decode", double[].class);
                                                                                                    decodeMethod.setAccessible(true);
                                                                                                    
                                                                                                    double[] input = {0.5, 0.25, 1.0};
                                                                                                    double[] expected = {1.0, 1.0, 6.0}; // (2-0)*0.5, (4-0)*0.25, (6-0)*1.0
                                                                                                    
                                                                                                    // Execute
                                                                                                    double[] result = (double[]) decodeMethod.invoke(optimizer, input);
                                                                                                    
                                                                                                    // Verify
                                                                                                    assertArrayEquals(expected, result, 0.0001);
                                                                                                }

    @Test
                                                                                                public void testDecodeWithSingleElement() throws Exception {
                                                                                                    // Setup
                                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                    Method decodeMethod = CMAESOptimizer.class.getDeclaredMethod("decode", double[].class);
                                                                                                    decodeMethod.setAccessible(true);
                                                                                                    
                                                                                                    // Set private boundaries field using reflection
                                                                                                    Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                    boundariesField.setAccessible(true);
                                                                                                    boundariesField.set(optimizer, new double[][] {
                                                                                                        {10.0},  // lower bound
                                                                                                        {20.0}    // upper bound
                                                                                                    });
                                                                                                    
                                                                                                    double[] input = {0.5};
                                                                                                    double[] expected = {15.0}; // 10 + (20-10)*0.5
                                                                                                    
                                                                                                    // Execute
                                                                                                    double[] result = (double[]) decodeMethod.invoke(optimizer, input);
                                                                                                    
                                                                                                    // Verify
                                                                                                    assertArrayEquals(expected, result, 0.0001);
                                                                                                }

    @Test
                                                                                                public void testDecodeWithZeroRange() throws Exception {
                                                                                                    // Setup
                                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                    
                                                                                                    // Use reflection to access private method
                                                                                                    Method decodeMethod = CMAESOptimizer.class.getDeclaredMethod("decode", double[].class);
                                                                                                    decodeMethod.setAccessible(true);
                                                                                                    
                                                                                                    // Use reflection to set private boundaries field
                                                                                                    Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                    boundariesField.setAccessible(true);
                                                                                                    boundariesField.set(optimizer, new double[][] {
                                                                                                        {5.0, 5.0},  // lower bounds
                                                                                                        {5.0, 5.0}   // upper bounds (same as lower)
                                                                                                    });
                                                                                                    
                                                                                                    double[] input = {0.5, 1.0};
                                                                                                    double[] expected = {0.0, 0.0}; // (5-5)*0.5, (5-5)*1.0
                                                                                                    
                                                                                                    // Execute
                                                                                                    double[] result = (double[]) decodeMethod.invoke(optimizer, input);
                                                                                                    
                                                                                                    // Verify
                                                                                                    assertArrayEquals(expected, result, 0.0001);
                                                                                                }

    @Test
                                                                                                public void testDecodeWithNegativeValues() throws Exception {
                                                                                                    // Setup
                                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                    Method decodeMethod = CMAESOptimizer.class.getDeclaredMethod("decode", double[].class);
                                                                                                    decodeMethod.setAccessible(true);
                                                                                                    
                                                                                                    // Access private boundaries field
                                                                                                    Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                    boundariesField.setAccessible(true);
                                                                                                    boundariesField.set(optimizer, new double[][] {
                                                                                                        {-10.0, -5.0},  // lower bounds
                                                                                                        {10.0, 5.0}     // upper bounds
                                                                                                    });
                                                                                                    
                                                                                                    double[] input = {0.5, 0.0};
                                                                                                    double[] expected = {10.0, -5.0}; // (10-(-10))*0.5, (5-(-5))*0.0
                                                                                                    
                                                                                                    // Execute
                                                                                                    double[] result = (double[]) decodeMethod.invoke(optimizer, input);
                                                                                                    
                                                                                                    // Verify
                                                                                                    assertArrayEquals(expected, result, 0.0001);
                                                                                                }

    @Test
                                                                                                public void testIsFeasible_WithinBounds() throws Exception {
                                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                    
                                                                                                    // Set private boundaries field using reflection
                                                                                                    Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                    boundariesField.setAccessible(true);
                                                                                                    boundariesField.set(optimizer, new double[][]{{0.0, 0.0}, {10.0, 10.0}});
                                                                                                    
                                                                                                    Method isFeasibleMethod = CMAESOptimizer.class.getDeclaredMethod("isFeasible", double[].class);
                                                                                                    isFeasibleMethod.setAccessible(true);
                                                                                                    
                                                                                                    double[] x = {5.0, 5.0};
                                                                                                    boolean result = (boolean) isFeasibleMethod.invoke(optimizer, (Object) x);
                                                                                                    assertTrue(result);
                                                                                                }

    @Test
                                                                                                public void testIsFeasible_BelowLowerBound() throws Exception {
                                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                    
                                                                                                    // Set private boundaries field using reflection
                                                                                                    Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                    boundariesField.setAccessible(true);
                                                                                                    boundariesField.set(optimizer, new double[][]{{1.0, 1.0}, {10.0, 10.0}});
                                                                                                    
                                                                                                    Method isFeasibleMethod = CMAESOptimizer.class.getDeclaredMethod("isFeasible", double[].class);
                                                                                                    isFeasibleMethod.setAccessible(true);
                                                                                                    
                                                                                                    double[] x = {0.5, 1.5};
                                                                                                    boolean result = (boolean) isFeasibleMethod.invoke(optimizer, (Object) x);
                                                                                                    assertFalse(result);
                                                                                                }

    @Test
                                                                                                public void testIsFeasible_AboveUpperBound() throws Exception {
                                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                    
                                                                                                    // Set private boundaries field using reflection
                                                                                                    Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                    boundariesField.setAccessible(true);
                                                                                                    boundariesField.set(optimizer, new double[][]{{1.0, 1.0}, {10.0, 10.0}});
                                                                                                    
                                                                                                    Method isFeasibleMethod = CMAESOptimizer.class.getDeclaredMethod("isFeasible", double[].class);
                                                                                                    isFeasibleMethod.setAccessible(true);
                                                                                                    
                                                                                                    double[] x = {5.0, 10.5};
                                                                                                    boolean result = (boolean) isFeasibleMethod.invoke(optimizer, (Object) x);
                                                                                                    assertFalse(result);
                                                                                                }

    @Test
                                                                                                public void testIsFeasible_OnLowerBound() throws Exception {
                                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                    
                                                                                                    // Set private boundaries field using reflection
                                                                                                    Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                    boundariesField.setAccessible(true);
                                                                                                    boundariesField.set(optimizer, new double[][]{{1.0, 1.0}, {10.0, 10.0}});
                                                                                                    
                                                                                                    double[] x = {1.0, 1.0};
                                                                                                    
                                                                                                    Method isFeasibleMethod = CMAESOptimizer.class.getDeclaredMethod("isFeasible", double[].class);
                                                                                                    isFeasibleMethod.setAccessible(true);
                                                                                                    
                                                                                                    boolean result = (boolean) isFeasibleMethod.invoke(optimizer, (Object) x);
                                                                                                    assertTrue(result);
                                                                                                }

    @Test
                                                                                                public void testIsFeasible_OnUpperBound() throws Exception {
                                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                    
                                                                                                    // Set private boundaries field using reflection
                                                                                                    Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                    boundariesField.setAccessible(true);
                                                                                                    boundariesField.set(optimizer, new double[][]{{1.0, 1.0}, {10.0, 10.0}});
                                                                                                    
                                                                                                    Method isFeasibleMethod = CMAESOptimizer.class.getDeclaredMethod("isFeasible", double[].class);
                                                                                                    isFeasibleMethod.setAccessible(true);
                                                                                                    
                                                                                                    double[] x = {10.0, 10.0};
                                                                                                    boolean result = (boolean) isFeasibleMethod.invoke(optimizer, (Object) x);
                                                                                                    assertTrue(result);
                                                                                                }

    @Test
                                                                                                public void testIsFeasible_MixedBounds() throws Exception {
                                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                    Method isFeasibleMethod = CMAESOptimizer.class.getDeclaredMethod("isFeasible", double[].class);
                                                                                                    isFeasibleMethod.setAccessible(true);
                                                                                                    
                                                                                                    // Use reflection to set private boundaries field
                                                                                                    Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                    boundariesField.setAccessible(true);
                                                                                                    boundariesField.set(optimizer, new double[][]{{1.0, 2.0}, {5.0, 6.0}});
                                                                                                    
                                                                                                    double[] x1 = {3.0, 4.0}; // within bounds
                                                                                                    double[] x2 = {0.5, 4.0}; // below lower bound on first dimension
                                                                                                    double[] x3 = {3.0, 6.5}; // above upper bound on second dimension
                                                                                                    
                                                                                                    assertTrue((boolean) isFeasibleMethod.invoke(optimizer, (Object) x1));
                                                                                                    assertFalse((boolean) isFeasibleMethod.invoke(optimizer, (Object) x2));
                                                                                                    assertFalse((boolean) isFeasibleMethod.invoke(optimizer, (Object) x3));
                                                                                                }

    @Test
                                                                                                public void testIsFeasible_SingleDimension() throws Exception {
                                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                    Method isFeasibleMethod = CMAESOptimizer.class.getDeclaredMethod("isFeasible", double[].class);
                                                                                                    isFeasibleMethod.setAccessible(true);
                                                                                                    
                                                                                                    Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                    boundariesField.setAccessible(true);
                                                                                                    boundariesField.set(optimizer, new double[][]{{1.0}, {10.0}});
                                                                                                    
                                                                                                    double[] x1 = {5.0}; // within bounds
                                                                                                    double[] x2 = {0.5}; // below lower bound
                                                                                                    double[] x3 = {10.5}; // above upper bound
                                                                                                    
                                                                                                    assertTrue((boolean) isFeasibleMethod.invoke(optimizer, (Object) x1));
                                                                                                    assertFalse((boolean) isFeasibleMethod.invoke(optimizer, (Object) x2));
                                                                                                    assertFalse((boolean) isFeasibleMethod.invoke(optimizer, (Object) x3));
                                                                                                }

    @Test
                                                                                                public void testIsFeasible_EmptyInput() throws Exception {
                                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                    Method isFeasibleMethod = CMAESOptimizer.class.getDeclaredMethod("isFeasible", double[].class);
                                                                                                    isFeasibleMethod.setAccessible(true);
                                                                                                    
                                                                                                    Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                    boundariesField.setAccessible(true);
                                                                                                    boundariesField.set(optimizer, new double[][]{{}, {}});
                                                                                                    
                                                                                                    double[] x = {};
                                                                                                    
                                                                                                    boolean result = (boolean) isFeasibleMethod.invoke(optimizer, (Object) x);
                                                                                                    assertTrue(result);
                                                                                                }

    @Test
        public void testEncodeWithNegativeValues() throws Exception {
            // Define test classes inside the method
            class PopulationSize {
                private final int lambda;
                public PopulationSize(int lambda) {
                    this.lambda = lambda;
                }
                public int getLambda() {
                    return lambda;
                }
            }
            
            class Sigma {
                private final double[] sigma;
                public Sigma(double[] s) {
                    this.sigma = s;
                }
                public double[] getSigma() {
                    return sigma;
                }
            }
            
            class RandomGenerator {
                public RandomGenerator() {}
            }
    
            // Define CMAESOptimizer class with minimal implementation for test
            class CMAESOptimizer {
                private final PopulationSize populationSize;
                private final Sigma sigma;
                private final RandomGenerator randomGenerator;
                
                public CMAESOptimizer(int maxIterations, double stopFitness, boolean isActiveCMA, 
                                     int diagonalOnly, int checkFeasableCount, 
                                     PopulationSize populationSize, Sigma sigma, RandomGenerator randomGenerator) {
                    this.populationSize = populationSize;
                    this.sigma = sigma;
                    this.randomGenerator = randomGenerator;
                }
                
                private double[] encode(double[] input) {
                    double[] result = new double[input.length];
                    for (int i = 0; i < input.length; i++) {
                        result[i] = input[i] + 0.5;
                    }
                    return result;
                }
            }
            
            // Create test objects
            CMAESOptimizer optimizer = new CMAESOptimizer(
                1000, 
                0.5, 
                true, 
                0, 
                0, 
                new PopulationSize(5), 
                new Sigma(new double[]{1.0}), 
                new RandomGenerator());
        
            // Get private method using reflection
            Method encodeMethod = CMAESOptimizer.class.getDeclaredMethod("encode", double[].class);
            encodeMethod.setAccessible(true);
            
            // Test data
            double[] input = {0.0, 0.0, 0.0};
            double[] expected = {0.5, 0.5, 0.5};
            
            // Invoke method and verify
            double[] result = (double[]) encodeMethod.invoke(optimizer, input);
            assertArrayEquals(expected, result, 0.0001);
        }


}
