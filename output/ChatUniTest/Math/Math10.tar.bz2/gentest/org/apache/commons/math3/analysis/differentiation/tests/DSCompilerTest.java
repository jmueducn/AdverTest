package gentest.org.apache.commons.math3.analysis.differentiation.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.analysis.differentiation.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.util.ArithmeticUtils;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.MathArrays;
 
public class DSCompilerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
            public void testAtan2NegativeX() {
                // Define size based on the compiler's expected size
                DSCompiler compiler = DSCompiler.getCompiler(2, 2);
                int size = compiler.getSize();
                
                double[] y = new double[size];
                double[] x = new double[size];
                double[] result = new double[size];
                
                // Set values and derivatives
                y[0] = 1.0;  // y value
                y[1] = 0.5;   // dy/dx
                y[2] = 0.25;  // d²y/dx²
                y[3] = 0.1;   // dy/dy
                y[4] = 0.05;  // d²y/dy²
                y[5] = 0.01;  // d²y/dxdy
                
                x[0] = -2.0;  // x value (negative)
                x[1] = 0.3;   // dx/dx
                x[2] = 0.15;  // d²x/dx²
                x[3] = 0.2;   // dx/dy
                x[4] = 0.1;   // d²x/dy²
                x[5] = 0.05; // d²x/dxdy
                
                compiler.atan2(y, 0, x, 0, result, 0);
                
                // Verify value
                assertEquals(FastMath.atan2(y[0], x[0]), result[0], 1e-15);
                
                // Verify derivatives (approximate checks)
                assertNotEquals(0.0, result[1], 1e-15); // d/dx
                assertNotEquals(0.0, result[3], 1e-15); // d/dy
                assertNotEquals(0.0, result[2], 1e-15); // d²/dx²
                assertNotEquals(0.0, result[4], 1e-15); // d²/dy²
                assertNotEquals(0.0, result[5], 1e-15); // d²/dxdy
            }

    @Test
            public void testAtan2ZeroY() {
                DSCompiler compiler = DSCompiler.getCompiler(2, 2);
                int size = compiler.getSize();
                
                double[] y = new double[size];
                double[] x = new double[size];
                double[] result = new double[size];
                
                // Set values and derivatives
                y[0] = 0.0;   // y value (zero)
                java.util.Arrays.fill(y, 1, size, 0.0); // zero derivatives
                
                x[0] = 1.0;   // x value
                x[1] = 0.3;   // dx/dx
                x[2] = 0.15;  // d²x/dx²
                x[3] = 0.2;   // dx/dy
                x[4] = 0.1;   // d²x/dy²
                x[5] = 0.05; // d²x/dxdy
                
                compiler.atan2(y, 0, x, 0, result, 0);
                
                assertEquals(0.0, result[0], 1e-15); // atan2(0, x) = 0 for x > 0
                assertEquals(0.0, result[1], 1e-15); // d/dx should be 0
                assertEquals(0.0, result[3], 1e-15); // d/dy should be 0
            }

    @Test
            public void testAtan2ZeroX() {
                DSCompiler compiler = DSCompiler.getCompiler(2, 2);
                int size = compiler.getSize();
                
                double[] y = new double[size];
                double[] x = new double[size];
                double[] result = new double[size];
                
                // Set values and derivatives
                y[0] = 1.0;   // y value
                y[1] = 0.5;   // dy/dx
                y[2] = 0.25;  // d²y/dx²
                y[3] = 0.1;   // dy/dy
                y[4] = 0.05;  // d²y/dy²
                y[5] = 0.01;  // d²y/dxdy
                
                x[0] = 0.0;   // x value (zero)
                java.util.Arrays.fill(x, 1, size, 0.0); // zero derivatives
                
                compiler.atan2(y, 0, x, 0, result, 0);
                
                assertEquals(FastMath.PI/2, result[0], 1e-15); // atan2(y, 0) = π/2 for y > 0
                assertNotEquals(0.0, result[1], 1e-15); // d/dx
                assertNotEquals(0.0, result[3], 1e-15); // d/dy
            }

    @Test
            public void testAtan2SpecialCases() {
                DSCompiler compiler = DSCompiler.getCompiler(1, 1);
                int size = compiler.getSize();
                
                double[] y = new double[size];
                double[] x = new double[size];
                double[] result = new double[size];
                
                // Test positive infinity
                y[0] = Double.POSITIVE_INFINITY;
                x[0] = 1.0;
                compiler.atan2(y, 0, x, 0, result, 0);
                assertEquals(FastMath.PI/2, result[0], 1e-15);
                
                // Test negative infinity
                y[0] = Double.NEGATIVE_INFINITY;
                x[0] = 1.0;
                compiler.atan2(y, 0, x, 0, result, 0);
                assertEquals(-FastMath.PI/2, result[0], 1e-15);
                
                // Test both positive infinity
                y[0] = Double.POSITIVE_INFINITY;
                x[0] = Double.POSITIVE_INFINITY;
                compiler.atan2(y, 0, x, 0, result, 0);
                assertEquals(FastMath.PI/4, result[0], 1e-15);
            }

    @Test
        public void testAtan2PositiveX() {
            DSCompiler compiler = DSCompiler.getCompiler(2, 2);
            int size = compiler.getSize();
            
            double[] y = new double[size];
            double[] x = new double[size];
            double[] result = new double[size];
            
            // Set values and derivatives
            y[0] = 1.0;  // y value
            y[1] = 0.5;   // dy/dx
            y[2] = 0.25;  // d²y/dx²
            y[3] = 0.1;   // dy/dy
            y[4] = 0.05;  // d²y/dy²
            y[5] = 0.01;  // d²y/dxdy
            
            x[0] = 2.0;   // x value (positive)
            x[1] = 0.3;   // dx/dx
            x[2] = 0.15;  // d²x/dx²
            x[3] = 0.2;   // dx/dy
            x[4] = 0.1;   // d²x/dy²
            x[5] = 0.05; // d²x/dxdy
            
            compiler.atan2(y, 0, x, 0, result, 0);
            
            // Verify value
            assertEquals(FastMath.atan2(y[0], x[0]), result[0], 1e-15);
            
            // Verify derivatives (approximate checks)
            assertNotEquals(0.0, result[1], 1e-15); // d/dx
            assertNotEquals(0.0, result[3], 1e-15); // d/dy
            assertNotEquals(0.0, result[2], 1e-15); // d²/dx²
            assertNotEquals(0.0, result[4], 1e-15); // d²/dy²
            assertNotEquals(0.0, result[5], 1e-15); // d²/dxdy
        }


}
