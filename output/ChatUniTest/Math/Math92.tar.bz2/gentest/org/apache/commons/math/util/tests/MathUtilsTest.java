package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.util.Arrays;
 
public class MathUtilsTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testBinomialCoefficientBasicCases() {
            assertEquals(1, MathUtils.binomialCoefficient(5, 0));
            assertEquals(1, MathUtils.binomialCoefficient(5, 5));
            assertEquals(5, MathUtils.binomialCoefficient(5, 1));
            assertEquals(5, MathUtils.binomialCoefficient(5, 4));
        }

    @Test
        public void testBinomialCoefficientSymmetry() {
            assertEquals(10, MathUtils.binomialCoefficient(5, 2));
            assertEquals(10, MathUtils.binomialCoefficient(5, 3));
        }

    @Test
        public void testBinomialCoefficientSmallN() {
            assertEquals(1, MathUtils.binomialCoefficient(0, 0));
            assertEquals(6, MathUtils.binomialCoefficient(4, 2));
            assertEquals(35, MathUtils.binomialCoefficient(7, 3));
        }

    @Test
        public void testBinomialCoefficientMediumN() {
            assertEquals(252, MathUtils.binomialCoefficient(10, 5));
            assertEquals(3003, MathUtils.binomialCoefficient(15, 5));
        }

    @Test
        public void testBinomialCoefficientLargeN() {
            assertEquals(18564, MathUtils.binomialCoefficient(18, 7));
            assertEquals(20349, MathUtils.binomialCoefficient(21, 2));
        }

    @Test
        public void testBinomialCoefficientEdgeCases() {
            assertEquals(1, MathUtils.binomialCoefficient(1, 0));
            assertEquals(1, MathUtils.binomialCoefficient(1, 1));
            assertEquals(1, MathUtils.binomialCoefficient(2, 0));
            assertEquals(2, MathUtils.binomialCoefficient(2, 1));
            assertEquals(1, MathUtils.binomialCoefficient(2, 2));
        }

    @Test(expected = IllegalArgumentException.class)
        public void testBinomialCoefficientNegativeN() {
            MathUtils.binomialCoefficient(-1, 1);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testBinomialCoefficientKGreaterThanN() {
            MathUtils.binomialCoefficient(5, 6);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testBinomialCoefficientNegativeK() {
            MathUtils.binomialCoefficient(5, -1);
        }

    @Test
        public void testBinomialCoefficientN() {
            // 61 is the threshold for the first algorithm
            assertEquals(8917947893L, MathUtils.binomialCoefficient(61, 30));
        }

    @Test
        public void testBinomialCoefficientN1() {
            // 66 is the threshold for the second algorithm
            assertEquals(7219428434016265740L, MathUtils.binomialCoefficient(66, 33));
        }

    @Test(expected = ArithmeticException.class)
        public void testBinomialCoefficientOverflow() {
            // This should cause an overflow
            MathUtils.binomialCoefficient(67, 33);
        }

    @Test
        public void testBinomialCoefficientDouble_NEqualsK() {
            assertEquals(1.0, MathUtils.binomialCoefficientDouble(5, 5), 0.0);
            assertEquals(1.0, MathUtils.binomialCoefficientDouble(0, 0), 0.0);
        }

    @Test
        public void testBinomialCoefficientDouble_KEqZero() {
            assertEquals(1.0, MathUtils.binomialCoefficientDouble(10, 0), 0.0);
        }

    @Test
        public void testBinomialCoefficientDouble_KEqOneOrNMinusOne() {
            assertEquals(5.0, MathUtils.binomialCoefficientDouble(5, 1), 0.0);
            assertEquals(5.0, MathUtils.binomialCoefficientDouble(5, 4), 0.0);
        }

    @Test
        public void testBinomialCoefficientDouble_KGreaterThanHalfN() {
            assertEquals(10.0, MathUtils.binomialCoefficientDouble(5, 3), 0.0);
            assertEquals(35.0, MathUtils.binomialCoefficientDouble(7, 4), 0.0);
        }

    @Test
        public void testBinomialCoefficientDouble_NLessThan() {
            assertEquals(6.0, MathUtils.binomialCoefficientDouble(4, 2), 0.0);
            assertEquals(20.0, MathUtils.binomialCoefficientDouble(6, 3), 0.0);
        }

    @Test
        public void testBinomialCoefficientDouble_NGreaterThanOrEqual() {
            assertEquals(1.07507272E8, MathUtils.binomialCoefficientDouble(100, 5), 1.0);
            assertEquals(1.4297028E8, MathUtils.binomialCoefficientDouble(100, 6), 1.0);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testBinomialCoefficientDouble_NLessThanK() {
            MathUtils.binomialCoefficientDouble(3, 5);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testBinomialCoefficientDouble_NegativeN() {
            MathUtils.binomialCoefficientDouble(-1, 2);
        }

    @Test
        public void testBinomialCoefficientDouble_LargeValues() {
            assertEquals(1.4297028E8, MathUtils.binomialCoefficientDouble(100, 6), 1.0);
            assertEquals(1.6007568E9, MathUtils.binomialCoefficientDouble(100, 7), 1.0);
        }

    @Test
        public void testBinomialCoefficientDouble_Rounding() {
            assertEquals(1.0, MathUtils.binomialCoefficientDouble(1, 1), 0.0);
            assertEquals(2.0, MathUtils.binomialCoefficientDouble(2, 1), 0.0);
            assertEquals(3.0, MathUtils.binomialCoefficientDouble(3, 1), 0.0);
        }

    @Test
        public void testBinomialCoefficientDouble_BoundaryCases() {
            assertEquals(1.0, MathUtils.binomialCoefficientDouble(66, 33), 1.0);
            assertEquals(1.0, MathUtils.binomialCoefficientDouble(67, 0), 0.0);
            assertEquals(67.0, MathUtils.binomialCoefficientDouble(67, 1), 0.0);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testBinomialCoefficientLog_NLessThanK() {
            MathUtils.binomialCoefficientLog(3, 5);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testBinomialCoefficientLog_NegativeN() {
            MathUtils.binomialCoefficientLog(-2, 1);
        }

    @Test
        public void testBinomialCoefficientLog_NEqualsK() {
            assertEquals(0.0, MathUtils.binomialCoefficientLog(5, 5), 0.0);
        }

    @Test
        public void testBinomialCoefficientLog_KEqualsZero() {
            assertEquals(0.0, MathUtils.binomialCoefficientLog(10, 0), 0.0);
        }

    @Test
        public void testBinomialCoefficientLog_KEqualsOne() {
            assertEquals(Math.log(5), MathUtils.binomialCoefficientLog(5, 1), 0.0);
        }

    @Test
        public void testBinomialCoefficientLog_KEqualsNMinusOne() {
            assertEquals(Math.log(10), MathUtils.binomialCoefficientLog(10, 9), 0.0);
        }

    @Test
        public void testBinomialCoefficientLog_SmallN() {
            // n < 67 case
            double expected = Math.log(MathUtils.binomialCoefficient(10, 3));
            assertEquals(expected, MathUtils.binomialCoefficientLog(10, 3), 0.0001);
        }

    @Test
        public void testBinomialCoefficientLog_MediumN() {
            // n < 1030 case
            double expected = Math.log(MathUtils.binomialCoefficientDouble(100, 50));
            assertEquals(expected, MathUtils.binomialCoefficientLog(100, 50), 0.0001);
        }

    @Test
        public void testBinomialCoefficientLog_LargeN() {
            // n >= 1030 case
            int n = 2000;
            int k = 1000;
            double logSum = 0;
            
            // n!/k!
            for (int i = k + 1; i <= n; i++) {
                logSum += Math.log((double)i);
            }
            
            // divide by (n-k)!
            for (int i = 2; i <= n - k; i++) {
                logSum -= Math.log((double)i);
            }
            
            assertEquals(logSum, MathUtils.binomialCoefficientLog(n, k), 0.0001);
        }

    @Test
        public void testBinomialCoefficientLog_SymmetryProperty() {
            int n = 50;
            int k = 10;
            assertEquals(MathUtils.binomialCoefficientLog(n, k), 
                        MathUtils.binomialCoefficientLog(n, n - k), 0.0001);
        }

    @Test
        public void testBinomialCoefficientLog_BoundaryCase() {
            // Test boundary between small and medium cases (n = 66 vs n = 67)
            double smallCase = MathUtils.binomialCoefficientLog(66, 33);
            double mediumCase = MathUtils.binomialCoefficientLog(67, 33);
            assertNotEquals(smallCase, mediumCase, 0.0001);
        }

    @Test
        public void testBinomialCoefficientLog_BoundaryCase1() {
            // Test boundary between medium and large cases (n = 1029 vs n = 1030)
            double mediumCase = MathUtils.binomialCoefficientLog(1029, 500);
            double largeCase = MathUtils.binomialCoefficientLog(1030, 500);
            assertNotEquals(mediumCase, largeCase, 0.0001);
        }

}
