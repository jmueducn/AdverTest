package gentest.org.apache.commons.math3.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.distribution.*;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.EigenDecomposition;
import org.apache.commons.math3.linear.NonPositiveDefiniteMatrixException;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.SingularMatrixException;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.MathArrays;
 
public class MultivariateNormalDistributionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                public void testDensityWithValidInput() throws Exception {
                                                    double[] means = {1.0, 2.0};
                                                    double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
                                                    MultivariateNormalDistribution distribution = new MultivariateNormalDistribution(means, covariances);
                                                    
                                                    double[] vals = {1.5, 2.5};
                                                    double result = distribution.density(vals);
                                                    
                                                    assertTrue(result > 0);
                                                }

    @Test(expected = DimensionMismatchException.class)
                                                public void testDensityWithInvalidDimension() {
                                                    double[] means = {1.0, 2.0};
                                                    double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
                                                    MultivariateNormalDistribution distribution = new MultivariateNormalDistribution(means, covariances);
                                                    
                                                    double[] vals = {1.5}; // Wrong dimension
                                                    distribution.density(vals);
                                                }

    @Test
                                                public void testDensityCalculation() throws Exception {
                                                    double[] means = {0.0, 0.0};
                                                    double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
                                                    MultivariateNormalDistribution distribution = new MultivariateNormalDistribution(means, covariances);
                                                    
                                                    double[] vals = {0.0, 0.0};
                                                    double expected = 1.0 / (2 * Math.PI); // For 2D standard normal at mean
                                                    double actual = distribution.density(vals);
                                                    
                                                    assertEquals(expected, actual, 1e-10);
                                                }

    @Test
                                                public void testGetExponentTermViaReflection() throws Exception {
                                                    double[] means = {1.0, 2.0};
                                                    double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
                                                    MultivariateNormalDistribution distribution = new MultivariateNormalDistribution(means, covariances);
                                                    
                                                    Method method = MultivariateNormalDistribution.class.getDeclaredMethod("getExponentTerm", double[].class);
                                                    method.setAccessible(true);
                                                    
                                                    double[] vals = {1.0, 2.0};
                                                    double result = (double) method.invoke(distribution, vals);
                                                    
                                                    assertEquals(1.0, result, 1e-10); // Should be exp(0) = 1 when at mean
                                                }

    @Test
                                                public void testDensityWithNonIdentityCovariance() {
                                                    double[] means = {0.0, 0.0};
                                                    double[][] covariances = {{2.0, 0.0}, {0.0, 2.0}};
                                                    MultivariateNormalDistribution distribution = new MultivariateNormalDistribution(means, covariances);
                                                    
                                                    double[] vals = {0.0, 0.0};
                                                    double result = distribution.density(vals);
                                                    
                                                    double expected = 1.0 / (4 * Math.PI); // det=4, dim=2
                                                    assertEquals(expected, result, 1e-10);
                                                }

    @Test
        public void testDensityWithMockedExponentTerm() throws Exception {
            // Create a spy of the real object
            double[] means = {0.0, 0.0};
            double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
            MultivariateNormalDistribution distribution = new MultivariateNormalDistribution(means, covariances);
            MultivariateNormalDistribution spyDist = spy(distribution);
            
            // Use reflection to mock the private field
            when(spyDist.getDimension()).thenReturn(2);
            
            // Mock the private method using reflection
            MultivariateNormalDistribution spyForPrivate = spy(spyDist);
            
            double[] vals = {0.0, 0.0};
            double result = spyForPrivate.density(vals);
            
            double expected = FastMath.pow(2 * FastMath.PI, -1.0) * 1.0; // dim=2, det=1
            assertEquals(expected, result, 1e-10);
        }


}
