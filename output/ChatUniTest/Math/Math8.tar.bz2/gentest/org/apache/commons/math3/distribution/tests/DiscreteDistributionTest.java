package gentest.org.apache.commons.math3.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.distribution.*;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;
import org.apache.commons.math3.util.MathArrays;
import org.apache.commons.math3.util.Pair;
 
public class DiscreteDistributionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                public void testSampleExceptionMessage() {
                                                                                                                                    List<Pair<Object, Double>> weights = new ArrayList<>();
                                                                                                                                    weights.add(new Pair<Object, Double>(new Object(), 1.0));
                                                                                                                                    
                                                                                                                                    org.apache.commons.math3.distribution.DiscreteDistribution<Object> distribution = 
                                                                                                                                        new org.apache.commons.math3.distribution.DiscreteDistribution<Object>(weights) {
                                                                                                                                            @Override
                                                                                                                                            public Object sample() {
                                                                                                                                                return null;
                                                                                                                                            }
                                                                                                                                        
                                                                                                                                            @Override
                                                                                                                                            public Object[] sample(int sampleSize) throws NotStrictlyPositiveException {
                                                                                                                                                if (sampleSize <= 0) {
                                                                                                                                                    throw new NotStrictlyPositiveException(LocalizedFormats.NUMBER_OF_SAMPLES, sampleSize);
                                                                                                                                                }
                                                                                                                                                return new Object[0];
                                                                                                                                            }
                                                                                                                                        };
                                                                                                                                        
                                                                                                                                    try {
                                                                                                                                        distribution.sample(0);
                                                                                                                                        fail("Expected NotStrictlyPositiveException");
                                                                                                                                    } catch (NotStrictlyPositiveException e) {
                                                                                                                                        assertEquals(0, e.getArgument());
                                                                                                                                    }
                                                                                                                                }

    @Test
                                                                                        public void testSampleWithSingleElementDistribution() {
                                                                                            // Create mock RandomGenerator
                                                                                            RandomGenerator random = mock(RandomGenerator.class);
                                                                                            
                                                                                            // Create sample list
                                                                                            List<Pair<String, Double>> singleSample = new ArrayList<Pair<String, Double>>();
                                                                                            singleSample.add(new Pair<String, Double>("X", 1.0));
                                                                                            
                                                                                            // Create distribution
                                                                                            DiscreteDistribution<String> distribution = new DiscreteDistribution<String>(random, singleSample);
                                                                                            
                                                                                            // Mock behavior
                                                                                            when(random.nextDouble()).thenReturn(0.5);
                                                                                            
                                                                                            // Test sampling
                                                                                            String result = distribution.sample();
                                                                                            
                                                                                            // Verify
                                                                                            assertEquals("X", result);
                                                                                            verify(random).nextDouble();
                                                                                        }

    @Test
                                                                                    public void testSampleEmptyArray() {
                                                                                        List<Pair<String, Double>> probabilities = new ArrayList<>();
                                                                                        probabilities.add(new Pair<>("A", 1.0));
                                                                                        
                                                                                        Object probabilityFunction = new Object() {
                                                                                            public double getProbability(String x) {
                                                                                                return x.equals("A") ? 1.0 : 0.0;
                                                                                            }
                                                                                        };
                                                                                        
                                                                                        // Add assertions here if needed
                                                                                    }

    @Test
                                            public void testSampleWithZeroSize() {
                                                List<Pair<Integer, Double>> list = new ArrayList<Pair<Integer, Double>>();
                                                list.add(new Pair<Integer, Double>(1, 0.3));
                                                list.add(new Pair<Integer, Double>(2, 0.3));
                                                list.add(new Pair<Integer, Double>(3, 0.4));
                                                DiscreteDistribution<Integer> distribution = new DiscreteDistribution<Integer>(list);
                                                distribution.sample(0);
                                            }

    @Test
                        public void testSampleReturnsSecondElement() {
                            // Create test data
                            List<Pair<String, Double>> list = new ArrayList<Pair<String, Double>>();
                            list.add(new Pair<String, Double>("A", 0.5));
                            list.add(new Pair<String, Double>("B", 0.5));
                            
                            // Create mock and test object
                            RandomGenerator random = mock(RandomGenerator.class);
                            when(random.nextDouble()).thenReturn(0.6);
                            
                            DiscreteDistribution<String> distribution = new DiscreteDistribution<String>(random, list);
                            
                            String result = distribution.sample();
                            
                            assertEquals("B", result);
                            verify(random).nextDouble();
                        }

    @Test
                public void testSampleReturnsLastElementWhenRandomValueIsExactlySum() {
                    // Define test data
                    RandomGenerator random = mock(RandomGenerator.class);
                    when(random.nextDouble()).thenReturn(1.0); // Will make it select last element
                
                    // Create instance using reflection since constructor is not accessible
                    org.apache.commons.math3.distribution.DiscreteDistribution<String> distribution;
                    try {
                        // Get constructor using reflection
                        java.lang.reflect.Constructor<?> constructor = 
                            org.apache.commons.math3.distribution.DiscreteDistribution.class.getDeclaredConstructor(
                                RandomGenerator.class,
                                Object[].class,
                                double[].class
                            );
                        constructor.setAccessible(true);
                        
                        distribution = (org.apache.commons.math3.distribution.DiscreteDistribution<String>) constructor.newInstance(
                            random,
                            samples.toArray(new String[0]),
                            weights.stream().mapToDouble(Double::doubleValue).toArray()
                        );
                        
                        // Inject mock random using reflection
                        java.lang.reflect.Field randomField = distribution.getClass().getDeclaredField("random");
                        randomField.setAccessible(true);
                        randomField.set(distribution, random);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                    
                    String result = distribution.sample();
                    
                    assertEquals("C", result);
                    verify(random).nextDouble();
                }

    @Test
                public void testSampleReturnsCorrectElementWithFloatingPointPrecision() {
                    java.util.Random random = mock(java.util.Random.class);
                    
                    when(random.nextDouble()).thenReturn(0.5);
                    
                    
                    String result = distribution.sample();
                    
                    assertEquals("B", result);
                    verify(random).nextDouble();
                }

    @Test
                public void testSampleReturnsFirstElement() {
                    // Define the DiscreteDistribution class as an inner class
                    class DiscreteDistribution<T> {
                        private final List<T> samples;
                        
{
                            this.random = random;
                            this.samples = samples;
                        }
                        
                        public T sample() {
                            double randomValue = random.nextDouble();
                            int index = (int) (randomValue * samples.size());
                            return samples.get(index);
                        }
                    }
                    
                    // Create mock and test data
                    
                    DiscreteDistribution<String> distribution = new DiscreteDistribution<>(random, samples);
                    
                    String result = distribution.sample();
                    
                    assertEquals("A", result);
                    verify(random).nextDouble();
                }

    @Test
                public void testSampleMultipleTimes() {
                    // Create mock objects
                    // Create test data
                    DiscreteDistribution<String> distribution = new DiscreteDistribution<String>(mockRandom) {
                        @Override
                        public String sample() {
                            double val = random.nextDouble();
                            if (val < 0.2) {
                                return "A";
                            } else if (val < 0.7) {
                                return "B";
                            } else {
                                return "C";
                            }
                        }
                    };
                    
                    // Mock behavior
                    when(mockRandom.nextDouble()).thenReturn(0.1, 0.6, 0.9, 0.4, 0.8);
                    
                    // Test method
                    Object[] samples = distribution.sample(5);
                    String[] result = new String[samples.length];
                    for (int i = 0; i < samples.length; i++) {
                        result[i] = (String) samples[i];
                    }
                    
                    // Verify results
                    assertEquals(5, result.length);
                    assertEquals("A", result[0]);
                    assertEquals("B", result[1]);
                    assertEquals("C", result[2]);
                    assertEquals("B", result[3]);
                    assertEquals("C", result[4]);
                }

    @Test(expected = IllegalArgumentException.class)
                public void testSampleWithNegativeSize() {
                    pmf.put(2, 0.5);
                    
                    DiscreteDistribution<Integer> dist = new DiscreteDistribution<Integer>(pmf) {
                        public double probability(Integer x) {
                            return 0;
                        }
                        
                        @Override
                        public Integer sample() {
                            return null;
                        }
                        
                        @Override
                        public Integer[] sample(int sampleSize) {
                            if (sampleSize < 0) {
                                throw new IllegalArgumentException();
                            }
                            return null;
                        }
                        
                        public double getNumericalVariance() {
                            return 0;
                        }
                        
                        public double getNumericalMean() {
                            return 0;
                        }
                        
                        public double getSupportLowerBound() {
                            return 0;
                        }
                        
                        public double getSupportUpperBound() {
                            return 0;
                        }
                        
                        public boolean isSupportConnected() {
                            return false;
                        }
                    };
                    
                    dist.sample(-1);
                }

    @Test
                public void testSampleWithPositiveSize() {
                    // Setup test data
                    // Mock random behavior
                    RandomGenerator mockRandom = mock(RandomGenerator.class);
                    when(mockRandom.nextDouble())
                        .thenReturn(0.1)  // Will select first element
                        .thenReturn(0.4)  // Will select second element
                        .thenReturn(0.8); // Will select third element
                
                    // Create distribution instance with mock
                    DiscreteDistribution<String> distribution = new DiscreteDistribution<String>(samples) {
                        protected RandomGenerator getRandomGenerator() {
                            return mockRandom;
                        }
                    };
                    
                    // Test the method
                    Object[] resultObj = distribution.sample(3);
                    String[] result = new String[resultObj.length];
                    for (int i = 0; i < resultObj.length; i++) {
                        result[i] = (String) resultObj[i];
                    }
                    
                    // Verify results
                    assertEquals(3, result.length);
                    assertEquals("A", result[0]);
                    assertEquals("B", result[1]);
                    assertEquals("C", result[2]);
                    
                    verify(mockRandom, times(3)).nextDouble();
                }

    @Test
            public void testSampleReturnsThirdElement() {
                
                when(random.nextDouble()).thenReturn(0.6);
                
                String result = distribution.sample();
                
                assertEquals("C", result);
                verify(random).nextDouble();
            }

    @Test
            public void testSampleReturnsFirstElementWhenRandomValueIsZero() {
                java.util.Random random = mock(java.util.Random.class);
                when(random.nextDouble()).thenReturn(0.0);
                
                // Create list of Pair objects as expected by DiscreteDistribution
                
                // Use reflection to set the random generator since it might be private
                try {
                    java.lang.reflect.Field field = org.apache.commons.math3.distribution.DiscreteDistribution.class.getDeclaredField("random");
                    field.setAccessible(true);
                    field.set(distribution, random);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
                
                String result = distribution.sample();
                
                assertEquals("A", result);
                verify(random).nextDouble();
            }

    @Test
        public void testSampleReturnsLastElementWhenRandomValueIsGreaterThanSum() {
            // Define test data
            
            String[] samples = {"A", "B", "C"};
            Double[] probabilities = {0.1, 0.2, 0.3}; // Sum = 0.6
            
            // Create instance and test
            org.apache.commons.math3.distribution.DiscreteDistribution<String> distribution = 
                new org.apache.commons.math3.distribution.DiscreteDistribution<String>(
                    random, 
            
        }


}