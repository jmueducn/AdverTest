package gentest.org.apache.commons.math.geometry.euclidean.threed.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.geometry.euclidean.threed.*;
import java.io.Serializable;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.FastMath;
 
public class RotationTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                        public void testConstructorWithZeroValues() {
                            // Test with zero values (should still work)
                            Rotation rotation = new Rotation(0.0, 0.0, 0.0, 0.0, true);
                            
                            // After normalization, all components should be NaN (0/0)
                            assertTrue(Double.isNaN(rotation.getQ0()));
                            assertTrue(Double.isNaN(rotation.getQ1()));
                            assertTrue(Double.isNaN(rotation.getQ2()));
                            assertTrue(Double.isNaN(rotation.getQ3()));
                        }

    @Test(expected = ArithmeticException.class)
                        public void testConstructorWithZeroNormAxis() {
                            Vector3D axis = new Vector3D(0, 0, 0);
                            new Rotation(axis, Math.PI);
                        }

    @Test(expected = NotARotationMatrixException.class)
                        public void testInvalidMatrixDimensions() throws NotARotationMatrixException {
                            double[][] invalidMatrix = {{1, 0}, {0, 1}};
                            new Rotation(invalidMatrix, 1.0e-12);
                        }

    @Test(expected = NotARotationMatrixException.class)
                        public void testNegativeDeterminant() throws NotARotationMatrixException {
                            double[][] matrix = {
                                {1, 0, 0},
                                {0, 1, 0},
                                {0, 0, -1} // This will make determinant negative
                            };
                            new Rotation(matrix, 1.0e-12);
                        }

    @Test
                        public void testValidRotationMatrix() throws NotARotationMatrixException {
                            double[][] matrix = {
                                {1, 0, 0},
                                {0, 1, 0},
                                {0, 0, 1}
                            };
                            Rotation rotation = new Rotation(matrix, 1.0e-12);
                            
                            assertEquals(1.0, rotation.getQ0(), 1.0e-12);
                            assertEquals(0.0, rotation.getQ1(), 1.0e-12);
                            assertEquals(0.0, rotation.getQ2(), 1.0e-12);
                            assertEquals(0.0, rotation.getQ3(), 1.0e-12);
                        }

    @Test
                        public void testFirstBranchQuaternionCalculation() throws NotARotationMatrixException {
                            double[][] matrix = {
                                {0.36, 0.48, -0.8},
                                {-0.8, 0.6, 0.0},
                                {0.48, 0.64, 0.6}
                            };
                            Rotation rotation = new Rotation(matrix, 1.0e-12);
                            
                            // Verify quaternion components are calculated correctly
                            assertTrue(rotation.getQ0() > 0.45);
                            assertEquals(1.0, 
                                rotation.getQ0() * rotation.getQ0() + 
                                rotation.getQ1() * rotation.getQ1() + 
                                rotation.getQ2() * rotation.getQ2() + 
                                rotation.getQ3() * rotation.getQ3(), 
                                1.0e-12);
                        }

    @Test
                        public void testSecondBranchQuaternionCalculation() throws NotARotationMatrixException {
                            double[][] matrix = {
                                {0.8, 0.288, 0.384},
                                {0.288, 0.512, -0.768},
                                {0.384, -0.768, -0.512}
                            };
                            Rotation rotation = new Rotation(matrix, 1.0e-12);
                            
                            // Verify quaternion components are calculated correctly
                            assertTrue(rotation.getQ1() > 0.45);
                            assertEquals(1.0, 
                                rotation.getQ0() * rotation.getQ0() + 
                                rotation.getQ1() * rotation.getQ1() + 
                                rotation.getQ2() * rotation.getQ2() + 
                                rotation.getQ3() * rotation.getQ3(), 
                                1.0e-12);
                        }

    @Test
                        public void testThirdBranchQuaternionCalculation() throws NotARotationMatrixException {
                            double[][] matrix = {
                                {-0.8, 0.288, 0.384},
                                {0.288, 0.512, 0.768},
                                {0.384, 0.768, -0.512}
                            };
                            Rotation rotation = new Rotation(matrix, 1.0e-12);
                            
                            // Verify quaternion components are calculated correctly
                            assertTrue(rotation.getQ2() > 0.45);
                            assertEquals(1.0, 
                                rotation.getQ0() * rotation.getQ0() + 
                                rotation.getQ1() * rotation.getQ1() + 
                                rotation.getQ2() * rotation.getQ2() + 
                                rotation.getQ3() * rotation.getQ3(), 
                                1.0e-12);
                        }

    @Test
                        public void testFourthBranchQuaternionCalculation() throws NotARotationMatrixException {
                            double[][] matrix = {
                                {-0.8, 0.288, 0.384},
                                {0.288, -0.512, 0.768},
                                {0.384, 0.768, 0.512}
                            };
                            Rotation rotation = new Rotation(matrix, 1.0e-12);
                            
                            // Verify quaternion components are calculated correctly
                            assertTrue(rotation.getQ3() > 0.45);
                            assertEquals(1.0, 
                                rotation.getQ0() * rotation.getQ0() + 
                                rotation.getQ1() * rotation.getQ1() + 
                                rotation.getQ2() * rotation.getQ2() + 
                                rotation.getQ3() * rotation.getQ3(), 
                                1.0e-12);
                        }

    @Test
                        public void testOrthogonalization() throws NotARotationMatrixException {
                            double[][] matrix = {
                                {0.8, 0.288, 0.384},
                                {0.288, 0.512, -0.768},
                                {0.384, -0.768, -0.512}
                            };
                            Rotation rotation = new Rotation(matrix, 1.0e-12);
                            
                            // Verify the rotation matrix is orthogonal
                            double[][] result = rotation.getMatrix();
                            double[][] product = new double[3][3];
                            
                            // Multiply rotation matrix by its transpose
                            for (int i = 0; i < 3; i++) {
                                for (int j = 0; j < 3; j++) {
                                    product[i][j] = 0;
                                    for (int k = 0; k < 3; k++) {
                                        product[i][j] += result[i][k] * result[j][k];
                                    }
                                }
                            }
                            
                            // Should be identity matrix
                            assertEquals(1.0, product[0][0], 1.0e-12);
                            assertEquals(0.0, product[0][1], 1.0e-12);
                            assertEquals(0.0, product[0][2], 1.0e-12);
                            assertEquals(0.0, product[1][0], 1.0e-12);
                            assertEquals(1.0, product[1][1], 1.0e-12);
                            assertEquals(0.0, product[1][2], 1.0e-12);
                            assertEquals(0.0, product[2][0], 1.0e-12);
                            assertEquals(0.0, product[2][1], 1.0e-12);
                            assertEquals(1.0, product[2][2], 1.0e-12);
                        }

    @Test
                        public void testConstructorWithRandomVectors() {
                            Vector3D rand1 = new Vector3D(Math.random(), Math.random(), Math.random());
                            Vector3D rand2 = new Vector3D(Math.random(), Math.random(), Math.random());
                            Vector3D rand3 = new Vector3D(Math.random(), Math.random(), Math.random());
                            Vector3D rand4 = new Vector3D(Math.random(), Math.random(), Math.random());
                            Rotation rotation = new Rotation(rand1, rand2, rand3, rand4);
                            assertNotNull(rotation);
                        }

    @Test
                        public void testConstructorWithOppositeVectors() {
                            Vector3D u = new Vector3D(1, 0, 0);
                            Vector3D v = new Vector3D(-1, 0, 0);
                            
                            Rotation rotation = new Rotation(u, v);
                            
                            assertEquals(0.0, rotation.getQ0(), 1e-15);
                            assertNotEquals(0.0, rotation.getQ1(), 1e-15);
                            assertNotEquals(0.0, rotation.getQ2(), 1e-15);
                            assertNotEquals(0.0, rotation.getQ3(), 1e-15);
                            
                            // Verify the rotation angle is PI
                            assertEquals(Math.PI, rotation.getAngle(), 1e-15);
                        }

    @Test
                        public void testConstructorWithGeneralCase() {
                            Vector3D u = new Vector3D(1, 0, 0);
                            Vector3D v = new Vector3D(0, 1, 0);
                            
                            Rotation rotation = new Rotation(u, v);
                            
                            // Verify quaternion components
                            assertEquals(FastMath.sqrt(0.5), rotation.getQ0(), 1e-15);
                            assertEquals(0.0, rotation.getQ1(), 1e-15);
                            assertEquals(0.0, rotation.getQ2(), 1e-15);
                            assertEquals(FastMath.sqrt(0.5), rotation.getQ3(), 1e-15);
                            
                            // Verify the rotation angle is PI/2
                            assertEquals(Math.PI/2, rotation.getAngle(), 1e-15);
                            
                            // Verify the rotation axis is Z axis
                            Vector3D axis = rotation.getAxis();
                            assertEquals(0.0, axis.getX(), 1e-15);
                            assertEquals(0.0, axis.getY(), 1e-15);
                            assertEquals(1.0, axis.getZ(), 1e-15);
                        }

    @Test
                        public void testConstructorWithSameVectors() {
                            Vector3D u = new Vector3D(1, 0, 0);
                            Vector3D v = new Vector3D(1, 0, 0);
                            
                            Rotation rotation = new Rotation(u, v);
                            
                            // Should be identity rotation
                            assertEquals(1.0, rotation.getQ0(), 1e-15);
                            assertEquals(0.0, rotation.getQ1(), 1e-15);
                            assertEquals(0.0, rotation.getQ2(), 1e-15);
                            assertEquals(0.0, rotation.getQ3(), 1e-15);
                        }

    @Test
                        public void testConstructorWithAlmostOppositeVectors() {
                            Vector3D u = new Vector3D(1, 0, 0);
                            Vector3D v = new Vector3D(-1.0001, 0, 0);
                            
                            Rotation rotation = new Rotation(u, v);
                            
                            // Should still trigger the special case
                            assertEquals(0.0, rotation.getQ0(), 1e-15);
                            assertNotEquals(0.0, rotation.getQ1(), 1e-15);
                            assertNotEquals(0.0, rotation.getQ2(), 1e-15);
                            assertNotEquals(0.0, rotation.getQ3(), 1e-15);
                        }

    @Test
                        public void testConstructorWithNonUnitVectors() {
                            Vector3D u = new Vector3D(2, 0, 0);
                            Vector3D v = new Vector3D(0, 3, 0);
                            
                            Rotation rotation = new Rotation(u, v);
                            
                            // The rotation should be the same as with unit vectors in same directions
                            Rotation expected = new Rotation(new Vector3D(1, 0, 0), new Vector3D(0, 1, 0));
                            assertEquals(expected.getQ0(), rotation.getQ0(), 1e-15);
                            assertEquals(expected.getQ1(), rotation.getQ1(), 1e-15);
                            assertEquals(expected.getQ2(), rotation.getQ2(), 1e-15);
                            assertEquals(expected.getQ3(), rotation.getQ3(), 1e-15);
                        }

    @Test
                        public void testConstructorWithRotationOrderAndAngles() {
                            // Test with XYZ order
                            RotationOrder xyzOrder = RotationOrder.XYZ;
                            Rotation rotationXYZ = new Rotation(xyzOrder, Math.PI/4, Math.PI/3, Math.PI/2);
                            assertNotNull(rotationXYZ);
                            assertEquals(1.0, rotationXYZ.getQ0() * rotationXYZ.getQ0() + 
                                             rotationXYZ.getQ1() * rotationXYZ.getQ1() + 
                                             rotationXYZ.getQ2() * rotationXYZ.getQ2() + 
                                             rotationXYZ.getQ3() * rotationXYZ.getQ3(), 1e-15);
                    
                            // Test with XZY order
                            RotationOrder xzyOrder = RotationOrder.XZY;
                            Rotation rotationXZY = new Rotation(xzyOrder, Math.PI/6, Math.PI/4, Math.PI/3);
                            assertNotNull(rotationXZY);
                            assertEquals(1.0, rotationXZY.getQ0() * rotationXZY.getQ0() + 
                                             rotationXZY.getQ1() * rotationXZY.getQ1() + 
                                             rotationXZY.getQ2() * rotationXZY.getQ2() + 
                                             rotationXZY.getQ3() * rotationXZY.getQ3(), 1e-15);
                    
                            // Test with YXZ order
                            RotationOrder yxzOrder = RotationOrder.YXZ;
                            Rotation rotationYXZ = new Rotation(yxzOrder, 0.1, 0.2, 0.3);
                            assertNotNull(rotationYXZ);
                            assertEquals(1.0, rotationYXZ.getQ0() * rotationYXZ.getQ0() + 
                                             rotationYXZ.getQ1() * rotationYXZ.getQ1() + 
                                             rotationYXZ.getQ2() * rotationYXZ.getQ2() + 
                                             rotationYXZ.getQ3() * rotationYXZ.getQ3(), 1e-15);
                    
                            // Test with YZX order
                            RotationOrder yzxOrder = RotationOrder.YZX;
                            Rotation rotationYZX = new Rotation(yzxOrder, 0.5, 0.6, 0.7);
                            assertNotNull(rotationYZX);
                            assertEquals(1.0, rotationYZX.getQ0() * rotationYZX.getQ0() + 
                                             rotationYZX.getQ1() * rotationYZX.getQ1() + 
                                             rotationYZX.getQ2() * rotationYZX.getQ2() + 
                                             rotationYZX.getQ3() * rotationYZX.getQ3(), 1e-15);
                    
                            // Test with ZXY order
                            RotationOrder zxyOrder = RotationOrder.ZXY;
                            Rotation rotationZXY = new Rotation(zxyOrder, 1.0, 1.1, 1.2);
                            assertNotNull(rotationZXY);
                            assertEquals(1.0, rotationZXY.getQ0() * rotationZXY.getQ0() + 
                                             rotationZXY.getQ1() * rotationZXY.getQ1() + 
                                             rotationZXY.getQ2() * rotationZXY.getQ2() + 
                                             rotationZXY.getQ3() * rotationZXY.getQ3(), 1e-15);
                    
                            // Test with ZYX order
                            RotationOrder zyxOrder = RotationOrder.ZYX;
                            Rotation rotationZYX = new Rotation(zyxOrder, 0.8, 0.9, 1.0);
                            assertNotNull(rotationZYX);
                            assertEquals(1.0, rotationZYX.getQ0() * rotationZYX.getQ0() + 
                                             rotationZYX.getQ1() * rotationZYX.getQ1() + 
                                             rotationZYX.getQ2() * rotationZYX.getQ2() + 
                                             rotationZYX.getQ3() * rotationZYX.getQ3(), 1e-15);
                        }

    @Test
                        public void testConstructorWithZeroAngles() {
                            RotationOrder order = RotationOrder.XYZ;
                            Rotation rotation = new Rotation(order, 0.0, 0.0, 0.0);
                            
                            assertEquals(1.0, rotation.getQ0(), 1e-15);
                            assertEquals(0.0, rotation.getQ1(), 1e-15);
                            assertEquals(0.0, rotation.getQ2(), 1e-15);
                            assertEquals(0.0, rotation.getQ3(), 1e-15);
                        }

    @Test
                        public void testConstructorWithNegativeAngles() {
                            RotationOrder order = RotationOrder.XYZ;
                            Rotation rotation = new Rotation(order, -Math.PI/4, -Math.PI/3, -Math.PI/2);
                            
                            assertEquals(1.0, rotation.getQ0() * rotation.getQ0() + 
                                             rotation.getQ1() * rotation.getQ1() + 
                                             rotation.getQ2() * rotation.getQ2() + 
                                             rotation.getQ3() * rotation.getQ3(), 1e-15);
                        }

    @Test
                        public void testConstructorWithLargeAngles() {
                            RotationOrder order = RotationOrder.XYZ;
                            Rotation rotation = new Rotation(order, 3*Math.PI, 4*Math.PI, 5*Math.PI);
                            
                            // The rotation should be normalized even with large angles
                            assertEquals(1.0, rotation.getQ0() * rotation.getQ0() + 
                                             rotation.getQ1() * rotation.getQ1() + 
                                             rotation.getQ2() * rotation.getQ2() + 
                                             rotation.getQ3() * rotation.getQ3(), 1e-15);
                        }

    @Test
                        public void testConstructorConsistencyWithApplyTo() {
                            RotationOrder order = RotationOrder.XYZ;
                            double alpha1 = Math.PI/4;
                            double alpha2 = Math.PI/3;
                            double alpha3 = Math.PI/2;
                            
                            Rotation rotation = new Rotation(order, alpha1, alpha2, alpha3);
                            
                            // Create individual rotations
                            Rotation r1 = new Rotation(order.getA1(), alpha1);
                            Rotation r2 = new Rotation(order.getA2(), alpha2);
                            Rotation r3 = new Rotation(order.getA3(), alpha3);
                            
                            // Apply rotations in order
                            Rotation composed = r1.applyTo(r2.applyTo(r3));
                            
                            // The composed rotation should be equal to the rotation created by the constructor
                            assertEquals(composed.getQ0(), rotation.getQ0(), 1e-15);
                            assertEquals(composed.getQ1(), rotation.getQ1(), 1e-15);
                            assertEquals(composed.getQ2(), rotation.getQ2(), 1e-15);
                            assertEquals(composed.getQ3(), rotation.getQ3(), 1e-15);
                        }

    @Test
                        public void testConstructorWithMockedRotationOrder() {
                            RotationOrder mockOrder = mock(RotationOrder.class);
                            when(mockOrder.getA1()).thenReturn(Vector3D.PLUS_I);
                            when(mockOrder.getA2()).thenReturn(Vector3D.PLUS_J);
                            when(mockOrder.getA3()).thenReturn(Vector3D.PLUS_K);
                            
                            Rotation rotation = new Rotation(mockOrder, 0.1, 0.2, 0.3);
                            
                            assertNotNull(rotation);
                            assertEquals(1.0, rotation.getQ0() * rotation.getQ0() + 
                                             rotation.getQ1() * rotation.getQ1() + 
                                             rotation.getQ2() * rotation.getQ2() + 
                                             rotation.getQ3() * rotation.getQ3(), 1e-15);
                        }

    @Test
                    public void testConstructorWithoutNormalization() {
                        // Test with no normalization needed
                        double EPSILON = 1.0e-12;
                        Rotation rotation = new Rotation(0.5, 0.5, 0.5, 0.5, false);
                        
                        assertEquals(0.5, rotation.getQ0(), EPSILON);
                        assertEquals(0.5, rotation.getQ1(), EPSILON);
                        assertEquals(0.5, rotation.getQ2(), EPSILON);
                        assertEquals(0.5, rotation.getQ3(), EPSILON);
                    }

    @Test
                    public void testConstructorWithVerySmallValues() {
                        // Define EPSILON inside the method
                        double EPSILON = 1.0e-12;
                        
                        // Test with very small values that need normalization
                        Rotation rotation = new Rotation(1e-10, 2e-10, 3e-10, 4e-10, true);
                        
                        double norm = FastMath.sqrt(1e-20 + 4e-20 + 9e-20 + 16e-20);
                        double expectedQ0 = 1e-10 / norm;
                        double expectedQ1 = 2e-10 / norm;
                        double expectedQ2 = 3e-10 / norm;
                        double expectedQ3 = 4e-10 / norm;
                        
                        assertEquals(expectedQ0, rotation.getQ0(), EPSILON);
                        assertEquals(expectedQ1, rotation.getQ1(), EPSILON);
                        assertEquals(expectedQ2, rotation.getQ2(), EPSILON);
                        assertEquals(expectedQ3, rotation.getQ3(), EPSILON);
                    }

    @Test
                    public void testConstructorWithVeryLargeValues() {
                        // Define EPSILON constant inside the method
                        double EPSILON = 1.0e-12;
                        
                        // Test with very large values that need normalization
                        Rotation rotation = new Rotation(1e10, 2e10, 3e10, 4e10, true);
                        
                        double norm = FastMath.sqrt(1e20 + 4e20 + 9e20 + 16e20);
                        double expectedQ0 = 1e10 / norm;
                        double expectedQ1 = 2e10 / norm;
                        double expectedQ2 = 3e10 / norm;
                        double expectedQ3 = 4e10 / norm;
                        
                        assertEquals(expectedQ0, rotation.getQ0(), EPSILON);
                        assertEquals(expectedQ1, rotation.getQ1(), EPSILON);
                        assertEquals(expectedQ2, rotation.getQ2(), EPSILON);
                        assertEquals(expectedQ3, rotation.getQ3(), EPSILON);
                    }

    @Test
                    public void testConstructorWithNonNormalizedAxis() {
                        final double EPSILON = 1.0e-12;
                        Vector3D axis = new Vector3D(2, 0, 0); // Not normalized
                        double angle = Math.PI / 2;
                        Rotation rotation = new Rotation(axis, angle);
                    
                        // The axis should be normalized internally
                        assertEquals(Math.cos(-angle/2), rotation.getQ0(), EPSILON);
                        assertEquals(Math.sin(-angle/2)/2, rotation.getQ1(), EPSILON);
                        assertEquals(0.0, rotation.getQ2(), EPSILON);
                        assertEquals(0.0, rotation.getQ3(), EPSILON);
                    }

    @Test
                    public void testConstructorWithValidVectors() {
                        Vector3D u1 = new Vector3D(1, 0, 0);
                        Vector3D u2 = new Vector3D(0, 1, 0);
                        Vector3D v1 = new Vector3D(1, 0, 0);
                        Vector3D v2 = new Vector3D(0, 1, 0);
                        
                        Rotation rotation = new Rotation(u1, u2, v1, v2);
                        assertNotNull(rotation);
                        assertEquals(1.0, rotation.getQ0(), 1e-10);
                        assertEquals(0.0, rotation.getQ1(), 1e-10);
                        assertEquals(0.0, rotation.getQ2(), 1e-10);
                        assertEquals(0.0, rotation.getQ3(), 1e-10);
                    }

    @Test(expected = IllegalArgumentException.class)
                    public void testConstructorWithZeroNormVector() {
                        Vector3D u1 = new Vector3D(1, 0, 0);
                        Vector3D u2 = new Vector3D(0, 1, 0);
                        Vector3D v1 = new Vector3D(0, 0, 1);
                        Vector3D v2 = new Vector3D(1, 1, 0);
                        new Rotation(u1, new Vector3D(0, 0, 0), v1, v2);
                    }

    @Test
                    public void testConstructorWithColinearVectors() {
                        Vector3D u1 = new Vector3D(1, 0, 0);
                        Vector3D v1 = new Vector3D(0, 1, 0);
                        Vector3D colinear1 = new Vector3D(1, 1, 0);
                        Vector3D colinear2 = new Vector3D(2, 2, 0);
                        Rotation rotation = new Rotation(u1, colinear1, v1, colinear2);
                        assertNotNull(rotation);
                    }

    @Test
                    public void testConstructorWithNonOrthogonalVectors() {
                        Vector3D nonOrth1 = new Vector3D(1, 1, 0);
                        Vector3D nonOrth2 = new Vector3D(0, 1, 1);
                        Vector3D v1 = new Vector3D(1, 0, 0);
                        Vector3D v2 = new Vector3D(0, 1, 0);
                        Rotation rotation = new Rotation(nonOrth1, nonOrth2, v1, v2);
                        assertNotNull(rotation);
                    }

    @Test
                    public void testConstructorWithInPlaneVectors() {
                        Vector3D u1 = new Vector3D(1, 0, 0);
                        Vector3D v1 = new Vector3D(1, 0, 0);
                        Vector3D inPlane1 = new Vector3D(1, 0.001, 0);
                        Vector3D inPlane2 = new Vector3D(0, 1, 0.001);
                        Rotation rotation = new Rotation(u1, inPlane1, v1, inPlane2);
                        assertNotNull(rotation);
                    }

    @Test
                    public void testConstructorWithAlmostAlignedVectors() {
                        Vector3D almostAligned1 = new Vector3D(1, 0.0001, 0);
                        Vector3D almostAligned2 = new Vector3D(0.0001, 1, 0);
                        Vector3D v1 = new Vector3D(1, 0, 0);
                        Vector3D v2 = new Vector3D(0, 1, 0);
                        Rotation rotation = new Rotation(almostAligned1, almostAligned2, v1, v2);
                        assertNotNull(rotation);
                    }

    @Test
                    public void testConstructorResultsInIdentityRotationWhenVectorsAreEqual() {
                        Vector3D u1 = new Vector3D(1, 0, 0);
                        Vector3D u2 = new Vector3D(0, 1, 0);
                        Vector3D v1 = new Vector3D(1, 0, 0);
                        Vector3D v2 = new Vector3D(0, 1, 0);
                        
                        Rotation rotation = new Rotation(u1, u2, v1, v2);
                        assertEquals(1.0, rotation.getQ0(), 1e-10);
                        assertEquals(0.0, rotation.getQ1(), 1e-10);
                        assertEquals(0.0, rotation.getQ2(), 1e-10);
                        assertEquals(0.0, rotation.getQ3(), 1e-10);
                    }

    @Test
                    public void testConstructorWithDifferentVectorNorms() {
                        Vector3D smallNorm = new Vector3D(0.1, 0.1, 0.1);
                        Vector3D largeNorm = new Vector3D(10, 10, 10);
                        Vector3D v1 = new Vector3D(1, 0, 0);
                        Vector3D v2 = new Vector3D(0, 1, 0);
                        Rotation rotation = new Rotation(smallNorm, largeNorm, v1, v2);
                        assertNotNull(rotation);
                    }

    @Test
                    public void testConstructorWithNegativeComponents() {
                        Vector3D neg1 = new Vector3D(-1, -1, 0);
                        Vector3D neg2 = new Vector3D(0, -1, -1);
                        Vector3D v1 = new Vector3D(1, 0, 0);
                        Vector3D v2 = new Vector3D(0, 1, 0);
                        Rotation rotation = new Rotation(neg1, neg2, v1, v2);
                        assertNotNull(rotation);
                    }

    @Test(expected = IllegalArgumentException.class)
                public void testConstructorWithZeroNormVector1() {
                    Vector3D u1 = new Vector3D(1, 0, 0);
                    Vector3D u2 = new Vector3D(0, 1, 0);
                    Vector3D v2 = new Vector3D(0, 0, 1);
                    new Rotation(u1, u2, new Vector3D(0, 0, 0), v2);
                }

    @Test(expected = IllegalArgumentException.class)
                public void testConstructorWithZeroNormVector2() {
                    Vector3D u1 = new Vector3D(1, 0, 0);
                    Vector3D u2 = new Vector3D(0, 1, 0);
                    Vector3D v1 = new Vector3D(1, 0, 0);
                    new Rotation(u1, u2, v1, new Vector3D(0, 0, 0));
                }

    @Test
                public void testConstructorWithNormalization() {
                    // Define EPSILON constant inside the method
                    final double EPSILON = 1.0e-12;
                    
                    // Test with normalization needed
                    Rotation rotation = new Rotation(2.0, 2.0, 2.0, 2.0, true);
                    
                    double norm = FastMath.sqrt(4.0 + 4.0 + 4.0 + 4.0);
                    double expected = 2.0 / norm;
                    
                    assertEquals(expected, rotation.getQ0(), EPSILON);
                    assertEquals(expected, rotation.getQ1(), EPSILON);
                    assertEquals(expected, rotation.getQ2(), EPSILON);
                    assertEquals(expected, rotation.getQ3(), EPSILON);
                }

    @Test
                public void testConstructorWithAngleZero() {
                    double EPSILON = 1.0e-12;
                    Vector3D axis = new Vector3D(1, 0, 0);
                    double angle = 0.0;
                    Rotation rotation = new Rotation(axis, angle);
                    
                    assertEquals(1.0, rotation.getQ0(), EPSILON);
                    assertEquals(0.0, rotation.getQ1(), EPSILON);
                    assertEquals(0.0, rotation.getQ2(), EPSILON);
                    assertEquals(0.0, rotation.getQ3(), EPSILON);
                }

    @Test
                public void testConstructorWithAnglePi() {
                    double EPSILON = 1.0e-12;
                    Vector3D axis = new Vector3D(0, 1, 0);
                    double angle = Math.PI;
                    Rotation rotation = new Rotation(axis, angle);
                
                    assertEquals(0.0, rotation.getQ0(), EPSILON);
                    assertEquals(0.0, rotation.getQ1(), EPSILON);
                    assertEquals(-1.0, rotation.getQ2(), EPSILON);
                    assertEquals(0.0, rotation.getQ3(), EPSILON);
                }

    @Test
                public void testConstructorWithNegativeAngle() {
                    // Define EPSILON constant inside the method
                    double EPSILON = 1.0e-12;
                    
                    Vector3D axis = new Vector3D(0, 0, 1);
                    double angle = -Math.PI / 2;
                    Rotation rotation = new Rotation(axis, angle);
                
                    assertEquals(Math.cos(Math.PI/4), rotation.getQ0(), EPSILON);
                    assertEquals(0.0, rotation.getQ1(), EPSILON);
                    assertEquals(0.0, rotation.getQ2(), EPSILON);
                    assertEquals(-Math.sin(Math.PI/4), rotation.getQ3(), EPSILON);
                }

    @Test
                public void testConstructorWithLargeAngle() {
                    // Define EPSILON constant within the method
                    final double EPSILON = 1.0e-12;
                    
                    Vector3D axis = new Vector3D(0, 1, 0);
                    double angle = 3 * Math.PI;
                    Rotation rotation = new Rotation(axis, angle);
                
                    // Should be equivalent to -π rotation
                    assertEquals(0.0, rotation.getQ0(), EPSILON);
                    assertEquals(0.0, rotation.getQ1(), EPSILON);
                    assertEquals(1.0, rotation.getQ2(), EPSILON);
                    assertEquals(0.0, rotation.getQ3(), EPSILON);
                }

    @Test
                public void testConstructorWithSmallAngle() {
                    double EPSILON = 1.0e-12;
                    Vector3D axis = new Vector3D(1, 0, 0);
                    double angle = 1e-10;
                    Rotation rotation = new Rotation(axis, angle);
                
                    assertEquals(1.0, rotation.getQ0(), EPSILON);
                    assertEquals(-5e-11, rotation.getQ1(), EPSILON);
                    assertEquals(0.0, rotation.getQ2(), EPSILON);
                    assertEquals(0.0, rotation.getQ3(), EPSILON);
                }

    @Test(expected = IllegalArgumentException.class)
            public void testConstructorWithZeroNormVector3() {
                Vector3D u1 = new Vector3D(1, 0, 0);
                Vector3D u2 = new Vector3D(0, 1, 0);
                Vector3D v2 = new Vector3D(0, 0, 1);
                new Rotation(u1, u2, new Vector3D(0, 0, 0), v2);
            }

    @Test(expected = IllegalArgumentException.class)
            public void testConstructorWithZeroNormVector4() {
                Vector3D u1 = new Vector3D(1, 0, 0);
                Vector3D u2 = new Vector3D(0, 1, 0);
                Vector3D v1 = new Vector3D(1, 0, 0);
                new Rotation(u1, u2, v1, new Vector3D(0, 0, 0));
            }

    @Test
            public void testConstructorWithNegativeValues() {
                // Define EPSILON constant
                final double EPSILON = 1.0e-12;
                
                // Test with negative values
                Rotation rotation = new Rotation(-1.0, -2.0, -3.0, -4.0, true);
                
                double norm = FastMath.sqrt(1.0 + 4.0 + 9.0 + 16.0);
                double expectedQ0 = -1.0 / norm;
                double expectedQ1 = -2.0 / norm;
                double expectedQ2 = -3.0 / norm;
                double expectedQ3 = -4.0 / norm;
                
                assertEquals(expectedQ0, rotation.getQ0(), EPSILON);
                assertEquals(expectedQ1, rotation.getQ1(), EPSILON);
                assertEquals(expectedQ2, rotation.getQ2(), EPSILON);
                assertEquals(expectedQ3, rotation.getQ3(), EPSILON);
            }

    @Test
            public void testConstructorWithMixedValues() {
                // Define EPSILON constant inside the method
                final double EPSILON = 1.0e-12;
                
                // Test with mixed positive and negative values
                Rotation rotation = new Rotation(1.0, -1.0, 2.0, -2.0, true);
                
                double norm = FastMath.sqrt(1.0 + 1.0 + 4.0 + 4.0);
                double expectedQ0 = 1.0 / norm;
                double expectedQ1 = -1.0 / norm;
                double expectedQ2 = 2.0 / norm;
                double expectedQ3 = -2.0 / norm;
                
                assertEquals(expectedQ0, rotation.getQ0(), EPSILON);
                assertEquals(expectedQ1, rotation.getQ1(), EPSILON);
                assertEquals(expectedQ2, rotation.getQ2(), EPSILON);
                assertEquals(expectedQ3, rotation.getQ3(), EPSILON);
            }

    @Test
            public void testConstructorWithValidAxisAndAngle() {
                double EPSILON = 1.0e-12;
                Vector3D axis = new Vector3D(1, 0, 0);
                double angle = Math.PI / 2;
                Rotation rotation = new Rotation(axis, angle);
                
                assertEquals(1.0, axis.getNorm(), EPSILON);
                assertEquals(Math.cos(angle/2), rotation.getQ0(), EPSILON);
                assertEquals(Math.sin(angle/2), rotation.getQ1(), EPSILON);
                assertEquals(0.0, rotation.getQ2(), EPSILON);
                assertEquals(0.0, rotation.getQ3(), EPSILON);
            }

    @Test
            public void testConstructorWithArbitraryAxis() {
                final double EPSILON = 1.0e-12;
                Vector3D axis = new Vector3D(1, 1, 1);
                double angle = Math.PI / 3;
                Rotation rotation = new Rotation(axis, angle);
            
                double norm = Math.sqrt(axis.getX() * axis.getX() + 
                                       axis.getY() * axis.getY() + 
                                       axis.getZ() * axis.getZ());
                double halfAngle = -0.5 * angle;
                double coeff = Math.sin(halfAngle) / norm;
            
                assertEquals(Math.cos(halfAngle), rotation.getQ0(), EPSILON);
                assertEquals(coeff * axis.getX(), rotation.getQ1(), EPSILON);
                assertEquals(coeff * axis.getY(), rotation.getQ2(), EPSILON);
                assertEquals(coeff * axis.getZ(), rotation.getQ3(), EPSILON);
            }

    @Test
        public void testConstructorWithAlreadyNormalized() {
            // Test with values that are already normalized
            double q0 = 0.5;
            double q1 = 0.5;
            double q2 = 0.5;
            double q3 = 0.5;
            double norm = q0*q0 + q1*q1 + q2*q2 + q3*q3;
            double EPSILON = 1.0e-12; // Define epsilon here
            assertTrue(FastMath.abs(norm - 1.0) < EPSILON); // verify they're normalized
            
            Rotation rotation = new Rotation(q0, q1, q2, q3, false);
            
            assertEquals(q0, rotation.getQ0(), EPSILON);
            assertEquals(q1, rotation.getQ1(), EPSILON);
            assertEquals(q2, rotation.getQ2(), EPSILON);
            assertEquals(q3, rotation.getQ3(), EPSILON);
        }


}
