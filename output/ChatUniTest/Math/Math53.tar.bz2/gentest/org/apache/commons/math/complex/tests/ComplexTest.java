package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math.FieldElement;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class ComplexTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testAdd_ValidComplexNumbers() {
            Complex c1 = new Complex(3.0, 4.0);
            Complex c2 = new Complex(2.0, 5.0);
            Complex result = c1.add(c2);
            
            assertEquals(5.0, result.getReal(), 0.0001);
            assertEquals(9.0, result.getImaginary(), 0.0001);
        }

    @Test
        public void testAdd_WithZero() {
            Complex c1 = new Complex(3.0, 4.0);
            Complex c2 = Complex.ZERO;
            Complex result = c1.add(c2);
            
            assertEquals(3.0, result.getReal(), 0.0001);
            assertEquals(4.0, result.getImaginary(), 0.0001);
        }

    @Test
        public void testAdd_WithNaN() {
            Complex c1 = new Complex(3.0, 4.0);
            Complex c2 = Complex.NaN;
            Complex result = c1.add(c2);
            
            assertTrue(result.isNaN());
        }

    @Test
        public void testAdd_WhenFirstIsNaN() {
            Complex c1 = Complex.NaN;
            Complex c2 = new Complex(2.0, 5.0);
            Complex result = c1.add(c2);
            
            assertTrue(result.isNaN());
        }

    @Test
        public void testAdd_WithInfinity() {
            Complex c1 = new Complex(3.0, 4.0);
            Complex c2 = Complex.INF;
            Complex result = c1.add(c2);
            
            assertEquals(Double.POSITIVE_INFINITY, result.getReal(), 0.0001);
            assertEquals(Double.POSITIVE_INFINITY, result.getImaginary(), 0.0001);
        }

    @Test(expected = NullArgumentException.class)
        public void testAdd_NullArgument() {
            Complex c1 = new Complex(3.0, 4.0);
            c1.add(null);
        }

    @Test
        public void testAdd_WithNegativeNumbers() {
            Complex c1 = new Complex(-3.0, -4.0);
            Complex c2 = new Complex(-2.0, -5.0);
            Complex result = c1.add(c2);
            
            assertEquals(-5.0, result.getReal(), 0.0001);
            assertEquals(-9.0, result.getImaginary(), 0.0001);
        }

    @Test
        public void testAdd_MixedSignNumbers() {
            Complex c1 = new Complex(3.0, -4.0);
            Complex c2 = new Complex(-2.0, 5.0);
            Complex result = c1.add(c2);
            
            assertEquals(1.0, result.getReal(), 0.0001);
            assertEquals(1.0, result.getImaginary(), 0.0001);
        }

    @Test
        public void testAdd_WithOne() {
            Complex c1 = new Complex(3.0, 4.0);
            Complex c2 = Complex.ONE;
            Complex result = c1.add(c2);
            
            assertEquals(4.0, result.getReal(), 0.0001);
            assertEquals(4.0, result.getImaginary(), 0.0001);
        }

    @Test
        public void testAdd_WithI() {
            Complex c1 = new Complex(3.0, 4.0);
            Complex c2 = Complex.I;
            Complex result = c1.add(c2);
            
            assertEquals(3.0, result.getReal(), 0.0001);
            assertEquals(5.0, result.getImaginary(), 0.0001);
        }

}
