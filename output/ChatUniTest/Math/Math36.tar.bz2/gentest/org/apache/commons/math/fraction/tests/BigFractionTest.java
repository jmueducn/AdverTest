package gentest.org.apache.commons.math.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.fraction.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import org.apache.commons.math.FieldElement;
import org.apache.commons.math.exception.MathIllegalArgumentException;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.ZeroException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.FastMath;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.ArithmeticUtils;
 
public class BigFractionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
            public void testDoubleValueSimpleFraction() {
                BigFraction fraction = new BigFraction(1, 2);
                assertEquals(0.5, fraction.doubleValue(), 0.0);
            }

    @Test
            public void testDoubleValueWholeNumber() {
                BigFraction fraction = new BigFraction(5, 1);
                assertEquals(5.0, fraction.doubleValue(), 0.0);
            }

    @Test
            public void testDoubleValueLargeNumerator() {
                BigFraction fraction = new BigFraction(new BigInteger("12345678901234567890"), BigInteger.ONE);
                assertEquals(1.2345678901234567E19, fraction.doubleValue(), 0.0);
            }

    @Test
            public void testDoubleValueLargeDenominator() {
                BigFraction fraction = new BigFraction(BigInteger.ONE, new BigInteger("12345678901234567890"));
                assertEquals(8.100000072900001E-20, fraction.doubleValue(), 0.0);
            }

    @Test
            public void testDoubleValueVeryLargeNumbers() {
                BigInteger hugeNum = new BigInteger("1234567890123456789012345678901234567890");
                BigInteger hugeDen = new BigInteger("9876543210987654321098765432109876543210");
                BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                
                // Expected value is approximately 0.1249999988609375
                assertEquals(0.1249999988609375, fraction.doubleValue(), 1e-15);
            }

    @Test
            public void testDoubleValueWithShiftNeeded() {
                // Create numbers that would overflow double representation
                BigInteger hugeNum = BigInteger.valueOf(2).pow(1024);
                BigInteger hugeDen = BigInteger.valueOf(3).pow(1024);
                BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                
                // The actual value should be (2/3)^1024, but we test that it returns a finite value
                double result = fraction.doubleValue();
                assertFalse(Double.isNaN(result));
                assertFalse(Double.isInfinite(result));
                assertTrue(result > 0.0);
            }

    @Test
            public void testDoubleValueZeroNumerator() {
                BigFraction fraction = new BigFraction(0, 1);
                assertEquals(0.0, fraction.doubleValue(), 0.0);
            }

    @Test
            public void testDoubleValueNegativeFraction() {
                BigFraction fraction = new BigFraction(-1, 2);
                assertEquals(-0.5, fraction.doubleValue(), 0.0);
            }

    @Test
            public void testDoubleValueExtremeValues() {
                BigInteger maxLong = BigInteger.valueOf(Long.MAX_VALUE);
                BigInteger minLong = BigInteger.valueOf(Long.MIN_VALUE);
                
                BigFraction fraction1 = new BigFraction(maxLong, maxLong);
                assertEquals(1.0, fraction1.doubleValue(), 0.0);
                
                BigFraction fraction2 = new BigFraction(minLong, maxLong);
                assertEquals(-0.9999999999999999, fraction2.doubleValue(), 0.0);
            }

    @Test
            public void testFloatValueNormalCase() {
                BigFraction fraction = new BigFraction(1, 2);
                assertEquals(0.5f, fraction.floatValue(), 0.000001f);
            }

    @Test
            public void testFloatValueWholeNumber() {
                BigFraction fraction = new BigFraction(3, 1);
                assertEquals(3.0f, fraction.floatValue(), 0.000001f);
            }

    @Test
            public void testFloatValueNegativeFraction() {
                BigFraction fraction = new BigFraction(-1, 4);
                assertEquals(-0.25f, fraction.floatValue(), 0.000001f);
            }

    @Test
            public void testFloatValueLargeNumbers() {
                BigFraction fraction = new BigFraction(123456789, 987654321);
                assertEquals(0.125f, fraction.floatValue(), 0.001f);
            }

    @Test
            public void testFloatValueWithZeroNumerator() {
                BigFraction fraction = new BigFraction(0, 5);
                assertEquals(0.0f, fraction.floatValue(), 0.0f);
            }

    @Test
            public void testFloatValueWithVeryLargeNumbers() {
                BigInteger hugeNum = new BigInteger("123456789012345678901234567890");
                BigInteger hugeDen = new BigInteger("987654321098765432109876543210");
                BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                
                // This will trigger the NaN case and shift right logic
                float result = fraction.floatValue();
                assertFalse(Float.isNaN(result));
                assertTrue(result > 0.0f && result < 1.0f);
            }

    @Test
            public void testFloatValueWithNumbersNearFloatLimits() {
                BigInteger nearMaxNum = BigInteger.valueOf((long)(Float.MAX_VALUE / 2));
                BigInteger nearMaxDen = BigInteger.valueOf((long)(Float.MAX_VALUE / 4));
                BigFraction fraction = new BigFraction(nearMaxNum, nearMaxDen);
                
                float result = fraction.floatValue();
                assertFalse(Float.isNaN(result));
                assertEquals(2.0f, result, 0.000001f);
            }

    @Test
            public void testFloatValueWithDifferentBitLengths() {
                BigInteger num = new BigInteger("1").shiftLeft(200);
                BigInteger den = new BigInteger("1").shiftLeft(100);
                BigFraction fraction = new BigFraction(num, den);
                
                float result = fraction.floatValue();
                assertFalse(Float.isNaN(result));
                assertEquals((float)Math.pow(2, 100), result, 1e30f);
            }

    @Test
        public void testDoubleValueWithVerySmallResult() {
            BigInteger tinyNum = BigInteger.ONE;
            BigInteger hugeDen = new BigInteger("1" + new String(new char[100]).replace("\0", "0"));
            BigFraction fraction = new BigFraction(tinyNum, hugeDen);
            
            assertEquals(0.0, fraction.doubleValue(), 0.0);
        }

    @Test
        public void testFloatValueWithExtremeNumbers() {
            BigInteger maxNum = new BigInteger("1").shiftLeft(Float.MAX_EXPONENT + 1);
            BigInteger maxDen = new BigInteger("1").shiftLeft(Float.MAX_EXPONENT + 1);
            BigFraction fraction = new BigFraction(maxNum, maxDen);
            
            // This will definitely trigger the NaN case and shift right logic
            float result = fraction.floatValue();
            assertFalse(Float.isNaN(result));
            assertEquals(1.0f, result, 0.000001f);
        }


}
