package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math.FieldElement;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.NotPositiveException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class ComplexTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testDivide_NaN_Divisor() {
            Complex c = new Complex(3.0, 4.0);
            Complex result = c.divide(Double.NaN);
            assertTrue(result.isNaN());
        }

    @Test
        public void testDivide_NaN_Complex() {
            Complex c = new Complex(Double.NaN, Double.NaN);
            Complex result = c.divide(2.0);
            assertTrue(result.isNaN());
        }

    @Test
        public void testDivide_ZeroDivisor() {
            Complex c = new Complex(3.0, 4.0);
            Complex result = c.divide(0.0);
            assertTrue(result.isNaN());
        }

    @Test
        public void testDivide_InfiniteDivisor_FiniteComplex() {
            Complex c = new Complex(3.0, 4.0);
            Complex result = c.divide(Double.POSITIVE_INFINITY);
            assertEquals(Complex.ZERO, result);
        }

    @Test
        public void testDivide_InfiniteDivisor_InfiniteComplex() {
            Complex c = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
            Complex result = c.divide(Double.POSITIVE_INFINITY);
            assertTrue(result.isNaN());
        }

    @Test
        public void testDivide_RegularCase() {
            Complex c = new Complex(6.0, 8.0);
            Complex result = c.divide(2.0);
            assertEquals(3.0, result.getReal(), 0.0001);
            assertEquals(4.0, result.getImaginary(), 0.0001);
        }

    @Test
        public void testDivide_ZeroComplex() {
            Complex c = Complex.ZERO;
            Complex result = c.divide(2.0);
            assertEquals(0.0, result.getReal(), 0.0001);
            assertEquals(0.0, result.getImaginary(), 0.0001);
        }

    @Test
        public void testDivide_NegativeDivisor() {
            Complex c = new Complex(6.0, 8.0);
            Complex result = c.divide(-2.0);
            assertEquals(-3.0, result.getReal(), 0.0001);
            assertEquals(-4.0, result.getImaginary(), 0.0001);
        }

    @Test
        public void testDivide_ImaginaryPartOnly() {
            Complex c = new Complex(0.0, 8.0);
            Complex result = c.divide(2.0);
            assertEquals(0.0, result.getReal(), 0.0001);
            assertEquals(4.0, result.getImaginary(), 0.0001);
        }

    @Test
        public void testDivide_RealPartOnly() {
            Complex c = new Complex(6.0, 0.0);
            Complex result = c.divide(2.0);
            assertEquals(3.0, result.getReal(), 0.0001);
            assertEquals(0.0, result.getImaginary(), 0.0001);
        }

}
