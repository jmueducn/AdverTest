package gentest.org.apache.commons.math3.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.distribution.*;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;
 
public class HypergeometricDistributionTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testGetNumericalMeanWithValidParameters() {
            HypergeometricDistribution distribution = new HypergeometricDistribution(100, 20, 10);
            double expectedMean = 10 * (20 / 100.0);
            assertEquals(expectedMean, distribution.getNumericalMean(), 0.0001);
        }

    @Test
        public void testGetNumericalMeanWhenAllPopulationIsSuccess() {
            HypergeometricDistribution distribution = new HypergeometricDistribution(100, 100, 10);
            double expectedMean = 10 * (100 / 100.0);
            assertEquals(expectedMean, distribution.getNumericalMean(), 0.0001);
        }

    @Test
        public void testGetNumericalMeanWhenNoSuccessInPopulation() {
            HypergeometricDistribution distribution = new HypergeometricDistribution(100, 0, 10);
            double expectedMean = 10 * (0 / 100.0);
            assertEquals(expectedMean, distribution.getNumericalMean(), 0.0001);
        }

    @Test
        public void testGetNumericalMeanWhenSampleSizeEqualsPopulation() {
            HypergeometricDistribution distribution = new HypergeometricDistribution(100, 20, 100);
            double expectedMean = 100 * (20 / 100.0);
            assertEquals(expectedMean, distribution.getNumericalMean(), 0.0001);
        }

    @Test
        public void testGetNumericalMeanWhenSampleSizeIsZero() {
            HypergeometricDistribution distribution = new HypergeometricDistribution(100, 20, 0);
            double expectedMean = 0 * (20 / 100.0);
            assertEquals(expectedMean, distribution.getNumericalMean(), 0.0001);
        }

    @Test
        public void testGetNumericalMeanWithLargeNumbers() {
            HypergeometricDistribution distribution = new HypergeometricDistribution(1000000, 200000, 100000);
            double expectedMean = 100000 * (200000 / 1000000.0);
            assertEquals(expectedMean, distribution.getNumericalMean(), 0.0001);
        }

    @Test
        public void testGetNumericalMeanWithFractionalResult() {
            HypergeometricDistribution distribution = new HypergeometricDistribution(7, 3, 5);
            double expectedMean = 5 * (3 / 7.0);
            assertEquals(expectedMean, distribution.getNumericalMean(), 0.0001);
        }

}
