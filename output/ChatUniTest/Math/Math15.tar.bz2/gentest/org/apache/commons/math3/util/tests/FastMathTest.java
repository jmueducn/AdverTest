package gentest.org.apache.commons.math3.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.util.*;
import java.io.PrintStream;
 
public class FastMathTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testPowZeroExponent() {
            assertEquals(1.0, FastMath.pow(0.0, 0), 0.0);
            assertEquals(1.0, FastMath.pow(1.0, 0), 0.0);
            assertEquals(1.0, FastMath.pow(-1.0, 0), 0.0);
            assertEquals(1.0, FastMath.pow(Double.MAX_VALUE, 0), 0.0);
            assertEquals(1.0, FastMath.pow(Double.MIN_VALUE, 0), 0.0);
        }

    @Test
        public void testPowPositiveExponent() {
            assertEquals(8.0, FastMath.pow(2.0, 3), 0.0);
            assertEquals(1.0, FastMath.pow(1.0, 5), 0.0);
            assertEquals(0.125, FastMath.pow(0.5, 3), 1e-15);
            assertEquals(1.0E-6, FastMath.pow(0.1, 6), 1e-15);
            assertEquals(1.0E6, FastMath.pow(10.0, 6), 1e-15);
        }

    @Test
        public void testPowNegativeExponent() {
            assertEquals(0.125, FastMath.pow(2.0, -3), 1e-15);
            assertEquals(1.0, FastMath.pow(1.0, -5), 0.0);
            assertEquals(8.0, FastMath.pow(0.5, -3), 1e-15);
            assertEquals(1.0E6, FastMath.pow(0.1, -6), 1e-15);
            assertEquals(1.0E-6, FastMath.pow(10.0, -6), 1e-15);
        }

    @Test
        public void testPowSpecialCases() {
            assertEquals(0.0, FastMath.pow(0.0, 1), 0.0);
            assertEquals(0.0, FastMath.pow(0.0, 2), 0.0);
            assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(0.0, -1), 0.0);
            assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(0.0, -2), 0.0);
            
            assertEquals(1.0, FastMath.pow(1.0, Integer.MAX_VALUE), 0.0);
            assertEquals(1.0, FastMath.pow(1.0, Integer.MIN_VALUE), 0.0);
            
            assertEquals(0.0, FastMath.pow(0.5, Integer.MAX_VALUE), 0.0);
            assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(1.5, Integer.MAX_VALUE), 0.0);
        }

    @Test
        public void testPowNegativeBase() {
            assertEquals(-8.0, FastMath.pow(-2.0, 3), 1e-15);
            assertEquals(16.0, FastMath.pow(-2.0, 4), 1e-15);
            assertEquals(-0.125, FastMath.pow(-2.0, -3), 1e-15);
            assertEquals(0.0625, FastMath.pow(-2.0, -4), 1e-15);
        }

    @Test
        public void testPowLargeExponents() {
            assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(2.0, 1024), 0.0);
            assertEquals(0.0, FastMath.pow(0.5, 1024), 0.0);
            assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(1.5, 1024), 0.0);
            
            assertEquals(0.0, FastMath.pow(2.0, -1024), 0.0);
            assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(0.5, -1024), 0.0);
        }

    @Test
        public void testPowEdgeCases() {
            assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(Double.MAX_VALUE, 2), 0.0);
            assertEquals(0.0, FastMath.pow(Double.MIN_VALUE, 2), 0.0);
            
            assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(Double.MAX_VALUE, Integer.MAX_VALUE), 0.0);
            assertEquals(0.0, FastMath.pow(Double.MIN_VALUE, Integer.MAX_VALUE), 0.0);
            
            assertEquals(0.0, FastMath.pow(Double.MAX_VALUE, Integer.MIN_VALUE), 0.0);
            assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(Double.MIN_VALUE, Integer.MIN_VALUE), 0.0);
        }

    @Test
        public void testPowNaNInput() {
            assertTrue(Double.isNaN(FastMath.pow(Double.NaN, 0)));
            assertTrue(Double.isNaN(FastMath.pow(Double.NaN, 1)));
            assertTrue(Double.isNaN(FastMath.pow(Double.NaN, -1)));
        }

    @Test
        public void testPowInfinityInput() {
            assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(Double.POSITIVE_INFINITY, 2), 0.0);
            assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(Double.POSITIVE_INFINITY, 1), 0.0);
            assertEquals(0.0, FastMath.pow(Double.POSITIVE_INFINITY, -1), 0.0);
            
            assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(Double.NEGATIVE_INFINITY, 2), 0.0);
            assertEquals(Double.NEGATIVE_INFINITY, FastMath.pow(Double.NEGATIVE_INFINITY, 1), 0.0);
            assertEquals(0.0, FastMath.pow(Double.NEGATIVE_INFINITY, -2), 0.0);
        }

}
