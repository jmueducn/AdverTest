package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import org.apache.commons.math.MathRuntimeException;
 
public class CholeskyDecompositionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
            public void testConstructorWithValidMatrix() {
                double[][] data = {
                    {4, 12, -16},
                    {12, 37, -43},
                    {-16, -43, 98}
                };
                RealMatrix matrix = new RealMatrixImpl(data);
                
                CholeskyDecompositionImpl decomposition = new CholeskyDecompositionImpl(matrix);
                
                assertNotNull(decomposition.getL());
                assertNotNull(decomposition.getLT());
            }

    @Test(expected = NotSymmetricMatrixException.class)
            public void testConstructorWithNonSymmetricMatrix() {
                double[][] nonSymmetricData = {
                    {1, 2, 3},
                    {4, 5, 6},
                    {7, 8, 9}
                };
                RealMatrix nonSymmetricMatrix = new RealMatrixImpl(nonSymmetricData);
                
                new CholeskyDecompositionImpl(nonSymmetricMatrix);
            }

    @Test(expected = NotPositiveDefiniteMatrixException.class)
            public void testConstructorWithNonPositiveDefiniteMatrix() {
                double[][] nonPositiveDefiniteData = {
                    {1, 2, 3},
                    {2, 4, 5},
                    {3, 5, 6}
                };
                RealMatrix nonPositiveDefiniteMatrix = new RealMatrixImpl(nonPositiveDefiniteData);
                
                new CholeskyDecompositionImpl(nonPositiveDefiniteMatrix);
            }

    @Test
            public void testConstructorUsesDefaultThresholds() {
                double[][] data = {
                    {4, 12, -16},
                    {12, 37, -43},
                    {-16, -43, 98}
                };
                RealMatrix matrix = new RealMatrixImpl(data);
                
                CholeskyDecompositionImpl decomposition = new CholeskyDecompositionImpl(matrix);
                
                // Verify the decomposition worked by checking L * LT equals original matrix
                RealMatrix L = decomposition.getL();
                RealMatrix LT = decomposition.getLT();
                RealMatrix reconstructed = L.multiply(LT);
                
                for (int i = 0; i < data.length; i++) {
                    for (int j = 0; j < data[i].length; j++) {
                        assertEquals(data[i][j], reconstructed.getEntry(i, j), 1e-10);
                    }
                }
            }

    @Test
            public void testConstructorWithIdentityMatrix() {
                RealMatrix identity = MatrixUtils.createRealIdentityMatrix(3);
                
                CholeskyDecompositionImpl decomposition = new CholeskyDecompositionImpl(identity);
                
                RealMatrix L = decomposition.getL();
                RealMatrix LT = decomposition.getLT();
                
                // For identity matrix, L should be identity as well
                assertEquals(1.0, L.getEntry(0, 0), 1e-10);
                assertEquals(0.0, L.getEntry(0, 1), 1e-10);
                assertEquals(1.0, L.getEntry(1, 1), 1e-10);
            }

    @Test(expected = IllegalArgumentException.class)
        public void testConstructorWithNonSquareMatrix() {
            RealMatrix mockMatrix = mock(RealMatrix.class);
            when(mockMatrix.getRowDimension()).thenReturn(2);
            when(mockMatrix.getColumnDimension()).thenReturn(3);
            when(mockMatrix.isSquare()).thenReturn(false);
            
            new CholeskyDecompositionImpl(mockMatrix);
        }

    @Test(expected = NonSquareMatrixException.class)
        public void testNonSquareMatrix() {
            RealMatrix nonSquareMatrix = mock(RealMatrix.class);
            when(nonSquareMatrix.isSquare()).thenReturn(false);
            when(nonSquareMatrix.getRowDimension()).thenReturn(2);
            when(nonSquareMatrix.getColumnDimension()).thenReturn(3);
            
            new CholeskyDecompositionImpl(nonSquareMatrix, 1e-15, 1e-10);
        }

    @Test(expected = NotSymmetricMatrixException.class)
        public void testNonSymmetricMatrix() {
            RealMatrix nonSymmetricMatrix = mock(RealMatrix.class);
            int order = 2;
            when(nonSymmetricMatrix.isSquare()).thenReturn(true);
            when(nonSymmetricMatrix.getRowDimension()).thenReturn(order);
            when(nonSymmetricMatrix.getColumnDimension()).thenReturn(order);
            when(nonSymmetricMatrix.getData()).thenReturn(new double[][] {
                {1.0, 2.0},
                {3.0, 4.0}  // Not symmetric (2.0 != 3.0)
            });
            
            new CholeskyDecompositionImpl(nonSymmetricMatrix, 1e-15, 1e-10);
        }

    @Test(expected = NotPositiveDefiniteMatrixException.class)
        public void testNonPositiveDefiniteMatrix() {
            RealMatrix nonPositiveDefiniteMatrix = mock(RealMatrix.class);
            int order = 2;
            when(nonPositiveDefiniteMatrix.isSquare()).thenReturn(true);
            when(nonPositiveDefiniteMatrix.getRowDimension()).thenReturn(order);
            when(nonPositiveDefiniteMatrix.getColumnDimension()).thenReturn(order);
            when(nonPositiveDefiniteMatrix.getData()).thenReturn(new double[][] {
                {1.0, 0.0},
                {0.0, -1.0}  // Negative diagonal element
            });
            
            new CholeskyDecompositionImpl(nonPositiveDefiniteMatrix, 1e-15, 1e-10);
        }

    @Test
        public void testValidDecomposition() {
            // Create mock objects
            RealMatrix symmetricMatrix = mock(RealMatrix.class);
            
            int order = 2;
            when(symmetricMatrix.isSquare()).thenReturn(true);
            when(symmetricMatrix.getRowDimension()).thenReturn(order);
            when(symmetricMatrix.getColumnDimension()).thenReturn(order);
            when(symmetricMatrix.getData()).thenReturn(new double[][] {
                {4.0, 1.0},
                {1.0, 4.0}  // Symmetric and positive definite
            });
            
            CholeskyDecompositionImpl decomposition = 
                new CholeskyDecompositionImpl(symmetricMatrix, 1e-15, 1e-10);
            
            RealMatrix l = decomposition.getL();
            RealMatrix lt = decomposition.getLT();
            
            assertNotNull(l);
            assertNotNull(lt);
            assertEquals(2, l.getRowDimension());
            assertEquals(2, l.getColumnDimension());
            assertEquals(2, lt.getRowDimension());
            assertEquals(2, lt.getColumnDimension());
            
            // Verify L is lower triangular
            assertEquals(0.0, l.getEntry(0, 1), 1e-10);
            
            // Verify LT is upper triangular
            assertEquals(0.0, lt.getEntry(1, 0), 1e-10);
        }

    @Test
        public void testDefaultConstructor() {
            RealMatrix symmetricMatrix = mock(RealMatrix.class);
            int order = 2;
            when(symmetricMatrix.isSquare()).thenReturn(true);
            when(symmetricMatrix.getRowDimension()).thenReturn(order);
            when(symmetricMatrix.getData()).thenReturn(new double[][] {
                {4.0, 1.0},
                {1.0, 4.0}
            });
            
            CholeskyDecompositionImpl decomposition = 
                new CholeskyDecompositionImpl(symmetricMatrix);
            
            assertNotNull(decomposition.getL());
            assertNotNull(decomposition.getLT());
        }

    @Test
        public void testGetDeterminant() {
            RealMatrix symmetricMatrix = mock(RealMatrix.class);
            int order = 2;
            when(symmetricMatrix.isSquare()).thenReturn(true);
            when(symmetricMatrix.getRowDimension()).thenReturn(order);
            when(symmetricMatrix.getColumnDimension()).thenReturn(order);
            when(symmetricMatrix.getData()).thenReturn(new double[][] {
                {4.0, 1.0},
                {1.0, 4.0}
            });
            
            CholeskyDecompositionImpl decomposition = 
                new CholeskyDecompositionImpl(symmetricMatrix);
            
            double determinant = decomposition.getDeterminant();
            assertTrue(determinant > 0);
        }

    @Test
        public void testGetSolver() {
            int order = 2;
            RealMatrix symmetricMatrix = mock(RealMatrix.class);
            when(symmetricMatrix.isSquare()).thenReturn(true);
            when(symmetricMatrix.getRowDimension()).thenReturn(order);
            when(symmetricMatrix.getColumnDimension()).thenReturn(order);
            when(symmetricMatrix.getData()).thenReturn(new double[][] {
                {4.0, 1.0},
                {1.0, 4.0}
            });
            
            CholeskyDecompositionImpl decomposition = 
                new CholeskyDecompositionImpl(symmetricMatrix);
            
            DecompositionSolver solver = decomposition.getSolver();
            assertNotNull(solver);
            assertTrue(solver.isNonSingular());
        }


}
