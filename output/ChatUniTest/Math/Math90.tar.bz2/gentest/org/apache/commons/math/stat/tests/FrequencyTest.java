package gentest.org.apache.commons.math.stat.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.*;
import java.io.Serializable;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.Comparator;
import java.util.TreeMap;
 
public class FrequencyTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                        public void testAddValueWithCustomComparator() {
                                                                                            Comparator<Object> comparator = mock(Comparator.class);
                                                                                            Frequency customFrequency = new Frequency(comparator);
                                                                                            
                                                                                            Object value = new Object();
                                                                                            customFrequency.addValue(value);
                                                                                            
                                                                                            verify(comparator, atLeastOnce()).compare(any(), any());
                                                                                            assertEquals(1, customFrequency.getCount(value));
                                                                                        }

    @Test
                                                                                        public void testAddValueWithNewInteger() {
                                                                                            Frequency freq = new Frequency();
                                                                                            freq.addValue(5);
                                                                                            assertEquals(1, freq.getCount(5L));
                                                                                        }

    @Test
                                                                                        public void testAddValueWithExistingInteger() {
                                                                                            Frequency freq = new Frequency();
                                                                                            freq.addValue(5);
                                                                                            freq.addValue(5);
                                                                                            assertEquals(2, freq.getCount(5L));
                                                                                        }

    @Test
                                                                                        public void testAddValueWithNewLong() {
                                                                                            Frequency freq = new Frequency();
                                                                                            freq.addValue(10L);
                                                                                            assertEquals(1, freq.getCount(10L));
                                                                                        }

    @Test
                                                                                        public void testAddValueWithExistingLong() {
                                                                                            Frequency freq = new Frequency();
                                                                                            freq.addValue(10L);
                                                                                            freq.addValue(10L);
                                                                                            assertEquals(2, freq.getCount(10L));
                                                                                        }

    @Test
                                                                                        public void testAddValueWithNewComparable() {
                                                                                            Frequency freq = new Frequency();
                                                                                            String value = "test";
                                                                                            freq.addValue(value);
                                                                                            assertEquals(1, freq.getCount(value));
                                                                                        }

    @Test
                                                                                        public void testAddValueWithExistingComparable() {
                                                                                            Frequency freq = new Frequency();
                                                                                            String value = "test";
                                                                                            freq.addValue(value);
                                                                                            freq.addValue(value);
                                                                                            assertEquals(2, freq.getCount(value));
                                                                                        }

    @Test
                                                                                        public void testAddValueWithIntegerConversion() {
                                                                                            Frequency freq = new Frequency();
                                                                                            freq.addValue(Integer.valueOf(7));
                                                                                            assertEquals(1, freq.getCount(7L));
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testAddValueWithIncomparableObject() {
                                                                                            Frequency freq = new Frequency();
                                                                                            // First add a comparable value
                                                                                            freq.addValue("string");
                                                                                            // Then try to add an incomparable value
                                                                                            freq.addValue(new Object());
                                                                                        }

    @Test
                                                                                        public void testAddValueWithNull() {
                                                                                            Frequency freq = new Frequency();
                                                                                            try {
                                                                                                freq.addValue((Comparable<?>) null);
                                                                                                fail("Expected NullPointerException");
                                                                                            } catch (NullPointerException e) {
                                                                                                // expected
                                                                                            }
                                                                                        }

    @Test
                                                                                        public void testAddValueWithCharacter() {
                                                                                            Frequency freq = new Frequency();
                                                                                            freq.addValue('a');
                                                                                            assertEquals(1, freq.getCount('a'));
                                                                                        }

    @Test
                                                                                        public void testAddValueWithMultipleTypes() {
                                                                                            Frequency freq = new Frequency();
                                                                                            freq.addValue(1);
                                                                                            freq.addValue(2L);
                                                                                            freq.addValue('a');
                                                                                            freq.addValue("test");
                                                                                            
                                                                                            assertEquals(1, freq.getCount(1L));
                                                                                            assertEquals(1, freq.getCount(2L));
                                                                                            assertEquals(1, freq.getCount('a'));
                                                                                            assertEquals(1, freq.getCount("test"));
                                                                                        }

    @Test
                                                                                        public void testAddValueIntWithComparator() {
                                                                                            // Create frequency with custom comparator
                                                                                            Frequency customFrequency = new Frequency((o1, o2) -> 0); // All values considered equal
                                                                                    
                                                                                            // Add some int values
                                                                                            customFrequency.addValue(1);
                                                                                            customFrequency.addValue(2);
                                                                                            customFrequency.addValue(1);
                                                                                    
                                                                                            // With this comparator, all values should be counted together
                                                                                            assertEquals(3, customFrequency.getCount(1));
                                                                                            assertEquals(3, customFrequency.getCount(2));
                                                                                            assertEquals(3, customFrequency.getSumFreq());
                                                                                        }

    @Test
                                                                                        public void testAddValueIntegerWithComparator() {
                                                                                            Frequency freqWithComparator = new Frequency((o1, o2) -> 0); // All values considered equal
                                                                                            freqWithComparator.addValue(Integer.valueOf(5));
                                                                                            freqWithComparator.addValue(Integer.valueOf(10));
                                                                                            
                                                                                            // With this comparator, all values go to the same bucket
                                                                                            assertEquals(2, freqWithComparator.getCount(5));
                                                                                            assertEquals(2, freqWithComparator.getCount(10));
                                                                                        }

    @Test
                                                                                        public void testAddValueLongWithComparator() {
                                                                                            // Create frequency with custom comparator
                                                                                            Frequency customFrequency = new Frequency((o1, o2) -> 0); // All values considered equal
                                                                                    
                                                                                            // Add long values - all should increment same counter
                                                                                            customFrequency.addValue(1L);
                                                                                            customFrequency.addValue(2L);
                                                                                            customFrequency.addValue(3L);
                                                                                    
                                                                                            // All values map to the same count (last one added)
                                                                                            assertEquals(3, customFrequency.getCount(3L));
                                                                                            assertEquals(3, customFrequency.getSumFreq());
                                                                                        }

    @Test
                                                                                        public void testAddValueCharWithComparator() {
                                                                                            // Create frequency with custom comparator
                                                                                            Frequency freqWithComparator = new Frequency((o1, o2) -> {
                                                                                                Character c1 = (Character) o1;
                                                                                                Character c2 = (Character) o2;
                                                                                                return c1.compareTo(c2);
                                                                                            });
                                                                                            
                                                                                            freqWithComparator.addValue('z');
                                                                                            freqWithComparator.addValue('a');
                                                                                            freqWithComparator.addValue('m');
                                                                                            
                                                                                            assertEquals(1, freqWithComparator.getCount('a'));
                                                                                            assertEquals(1, freqWithComparator.getCount('m'));
                                                                                            assertEquals(1, freqWithComparator.getCount('z'));
                                                                                        }

    @Test
                                                                                    public void testAddValueWithObject() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        Object value = new Object() {
                                                                                            @Override
                                                                                            public String toString() {
                                                                                                return "testObject";
                                                                                            }
                                                                                        };
                                                                                        
                                                                                        frequency.addValue((Comparable<?>) value);
                                                                                        assertEquals(1, frequency.getCount(value));
                                                                                    }

    @Test
                                                                                    public void testAddValueWithIntegerObject() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        Integer value = 5;
                                                                                        frequency.addValue(value);
                                                                                        assertEquals(1, frequency.getCount(value));
                                                                                        assertEquals(1, frequency.getCount(5L)); // Verify it was converted to Long
                                                                                    }

    @Test
                                                                                    public void testAddValueWithStringObject() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        String value = "testString";
                                                                                        frequency.addValue(value);
                                                                                        assertEquals(1, frequency.getCount(value));
                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                    public void testAddValueWithIncomparableObjects() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        frequency.addValue("string1");
                                                                                        frequency.addValue(123);
                                                                                    }

    @Test
                                                                                    public void testAddValueWithNull1() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        try {
                                                                                            frequency.addValue((Comparable<?>)null);
                                                                                            fail("Expected NullPointerException");
                                                                                        } catch (NullPointerException e) {
                                                                                            // Expected
                                                                                        }
                                                                                    }

    @Test
                                                                                    public void testAddValueIncrementsCount() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        Comparable<?> value = "testValue";
                                                                                        frequency.addValue(value);
                                                                                        frequency.addValue(value);
                                                                                        assertEquals(2, frequency.getCount(value));
                                                                                    }

    @Test
                                                                                    public void testAddValueWithCharacterObject() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        Character value = 'a';
                                                                                        frequency.addValue(value);
                                                                                        assertEquals(1, frequency.getCount(value));
                                                                                    }

    @Test
                                                                                    public void testAddValueWithLongObject() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        Long value = 100L;
                                                                                        frequency.addValue(value);
                                                                                        assertEquals(1, frequency.getCount(value));
                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                    public void testAddValueWithClassCastExceptionInMock() {
                                                                                        TreeMap<Object, Long> mockFreqTable = mock(TreeMap.class);
                                                                                        Frequency freq = new Frequency() {
                                                                                            {
                                                                                                try {
                                                                                                    java.lang.reflect.Field field = Frequency.class.getDeclaredField("freqTable");
                                                                                                    field.setAccessible(true);
                                                                                                    field.set(this, mockFreqTable);
                                                                                                } catch (Exception e) {
                                                                                                    throw new RuntimeException(e);
                                                                                                }
                                                                                            }
                                                                                        };
                                                                                        
                                                                                        when(mockFreqTable.get("incomparable")).thenThrow(new ClassCastException());
                                                                                        
                                                                                        freq.addValue("incomparable");
                                                                                    }

    @Test
                                                                                    public void testAddValueInt() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        
                                                                                        // Test adding a single value
                                                                                        frequency.addValue(5);
                                                                                        assertEquals(1, frequency.getCount(5));
                                                                                        assertEquals(1, frequency.getSumFreq());
                                                                                    
                                                                                        // Test adding multiple values
                                                                                        frequency.addValue(10);
                                                                                        frequency.addValue(5); // same value again
                                                                                        assertEquals(2, frequency.getCount(5));
                                                                                        assertEquals(1, frequency.getCount(10));
                                                                                        assertEquals(3, frequency.getSumFreq());
                                                                                    
                                                                                        // Test adding zero
                                                                                        frequency.addValue(0);
                                                                                        assertEquals(1, frequency.getCount(0));
                                                                                        assertEquals(4, frequency.getSumFreq());
                                                                                    
                                                                                        // Test adding negative value
                                                                                        frequency.addValue(-3);
                                                                                        assertEquals(1, frequency.getCount(-3));
                                                                                        assertEquals(5, frequency.getSumFreq());
                                                                                    }

    @Test
                                                                                    public void testAddValueIntWithExistingLongValues() {
                                                                                        // Create new Frequency instance
                                                                                        Frequency frequency = new Frequency();
                                                                                        
                                                                                        // First add some long values
                                                                                        frequency.addValue(Long.valueOf(5L));
                                                                                        frequency.addValue(Long.valueOf(10L));
                                                                                
                                                                                        // Then add int values
                                                                                        frequency.addValue(Integer.valueOf(5));
                                                                                        frequency.addValue(Integer.valueOf(15));
                                                                                
                                                                                        // Verify counts - int and long versions should be combined
                                                                                        assertEquals(2, frequency.getCount(5));
                                                                                        assertEquals(1, frequency.getCount(10));
                                                                                        assertEquals(1, frequency.getCount(15));
                                                                                        assertEquals(4, frequency.getSumFreq());
                                                                                    }

    @Test
                                                                                    public void testAddValueIntEdgeCases() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        
                                                                                        // Test Integer.MAX_VALUE
                                                                                        frequency.addValue(Integer.MAX_VALUE);
                                                                                        assertEquals(1, frequency.getCount(Integer.MAX_VALUE));
                                                                                    
                                                                                        // Test Integer.MIN_VALUE
                                                                                        frequency.addValue(Integer.MIN_VALUE);
                                                                                        assertEquals(1, frequency.getCount(Integer.MIN_VALUE));
                                                                                    
                                                                                        // Verify they are stored as Long values
                                                                                        assertEquals(1, frequency.getCount((long)Integer.MAX_VALUE));
                                                                                        assertEquals(1, frequency.getCount((long)Integer.MIN_VALUE));
                                                                                    }

    @Test
                                                                                    public void testAddValueIntAfterClear() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        frequency.addValue(1);
                                                                                        frequency.addValue(2);
                                                                                        frequency.clear();
                                                                                        
                                                                                        frequency.addValue(3);
                                                                                        assertEquals(1, frequency.getCount(3));
                                                                                        assertEquals(0, frequency.getCount(1));
                                                                                        assertEquals(1, frequency.getSumFreq());
                                                                                    }

    @Test
                                                                                    public void testAddValueIntWithMixedTypes() {
                                                                                        // Create new Frequency instance
                                                                                        Frequency frequency = new Frequency();
                                                                                        
                                                                                        // Add different types that can be converted to Long
                                                                                        frequency.addValue(1);    // int
                                                                                        frequency.addValue(2L);   // long
                                                                                        frequency.addValue(new Integer(3)); // Integer
                                                                                        
                                                                                        // All should be counted correctly
                                                                                        assertEquals(1, frequency.getCount(1));
                                                                                        assertEquals(1, frequency.getCount(2));
                                                                                        assertEquals(1, frequency.getCount(3));
                                                                                        assertEquals(3, frequency.getSumFreq());
                                                                                    }

    @Test
                                                                                    public void testAddValueInteger() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        Integer value = 5;
                                                                                        frequency.addValue(value);
                                                                                        
                                                                                        // Verify the value was converted to Long and added
                                                                                        assertEquals(1, frequency.getCount(value));
                                                                                        assertEquals(1, frequency.getCount(5L)); // Verify as long
                                                                                        
                                                                                        // Add another value and verify count increases
                                                                                        frequency.addValue(value);
                                                                                        assertEquals(2, frequency.getCount(value));
                                                                                        assertEquals(2, frequency.getCount(5L));
                                                                                    }

    @Test
                                                                                    public void testAddValueIntegerNull() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        try {
                                                                                            frequency.addValue((Integer) null);
                                                                                            fail("Expected NullPointerException");
                                                                                        } catch (NullPointerException e) {
                                                                                            // Expected exception
                                                                                        }
                                                                                    }

    @Test
                                                                                    public void testAddValueIntegerMultipleValues() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        frequency.addValue(1);
                                                                                        frequency.addValue(2);
                                                                                        frequency.addValue(3);
                                                                                        
                                                                                        assertEquals(1, frequency.getCount(1));
                                                                                        assertEquals(1, frequency.getCount(2));
                                                                                        assertEquals(1, frequency.getCount(3));
                                                                                        assertEquals(3, frequency.getSumFreq());
                                                                                    }

    @Test
                                                                                    public void testAddValueIntegerWithExistingLong() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        frequency.addValue(5L);
                                                                                        frequency.addValue(Integer.valueOf(5));
                                                                                        
                                                                                        assertEquals(2, frequency.getCount(5L));
                                                                                        assertEquals(2, frequency.getCount(Integer.valueOf(5)));
                                                                                    }

    @Test
                                                                                    public void testAddValueIntegerMaxValue() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        frequency.addValue(Integer.MAX_VALUE);
                                                                                        assertEquals(1, frequency.getCount(Integer.MAX_VALUE));
                                                                                        assertEquals(1, frequency.getCount((long) Integer.MAX_VALUE));
                                                                                    }

    @Test
                                                                                    public void testAddValueIntegerMinValue() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        frequency.addValue(Integer.MIN_VALUE);
                                                                                        assertEquals(1, frequency.getCount(Integer.MIN_VALUE));
                                                                                        assertEquals(1, frequency.getCount((long) Integer.MIN_VALUE));
                                                                                    }

    @Test
                                                                                    public void testAddValueIntegerMixedTypes() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        frequency.addValue(5);
                                                                                        frequency.addValue(Long.valueOf(5L));
                                                                                        frequency.addValue(Integer.valueOf(5));
                                                                                        
                                                                                        assertEquals(3, frequency.getCount(5));
                                                                                        assertEquals(3, frequency.getCount(5L));
                                                                                    }

    @Test
                                                                                    public void testAddValueLong() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        
                                                                                        // Test adding a single long value
                                                                                        frequency.addValue(5L);
                                                                                        assertEquals(1, frequency.getCount(5L));
                                                                                        assertEquals(1, frequency.getSumFreq());
                                                                                    
                                                                                        // Test adding multiple long values
                                                                                        frequency.addValue(10L);
                                                                                        frequency.addValue(10L);
                                                                                        assertEquals(1, frequency.getCount(5L));
                                                                                        assertEquals(2, frequency.getCount(10L));
                                                                                        assertEquals(3, frequency.getSumFreq());
                                                                                    
                                                                                        // Test adding zero
                                                                                        frequency.addValue(0L);
                                                                                        assertEquals(1, frequency.getCount(0L));
                                                                                        assertEquals(4, frequency.getSumFreq());
                                                                                    
                                                                                        // Test adding negative value
                                                                                        frequency.addValue(-3L);
                                                                                        assertEquals(1, frequency.getCount(-3L));
                                                                                        assertEquals(5, frequency.getSumFreq());
                                                                                    
                                                                                        // Test adding Long.MAX_VALUE
                                                                                        frequency.addValue(Long.MAX_VALUE);
                                                                                        assertEquals(1, frequency.getCount(Long.MAX_VALUE));
                                                                                        assertEquals(6, frequency.getSumFreq());
                                                                                    
                                                                                        // Test adding Long.MIN_VALUE
                                                                                        frequency.addValue(Long.MIN_VALUE);
                                                                                        assertEquals(1, frequency.getCount(Long.MIN_VALUE));
                                                                                        assertEquals(7, frequency.getSumFreq());
                                                                                    }

    @Test
                                                                                public void testAddValueLongWithExistingValues() {
                                                                                    // Create new Frequency instance
                                                                                    Frequency frequency = new Frequency();
                                                                                    
                                                                                    // Add some initial values
                                                                                    frequency.addValue(1L);
                                                                                    frequency.addValue(2L);
                                                                                    frequency.addValue(2L);
                                                                                    
                                                                                    // Add new long value
                                                                                    frequency.addValue(3L);
                                                                                    assertEquals(1, frequency.getCount(1L));
                                                                                    assertEquals(2, frequency.getCount(2L));
                                                                                    assertEquals(1, frequency.getCount(3L));
                                                                                    assertEquals(4, frequency.getSumFreq());
                                                                                    
                                                                                    // Add duplicate long value
                                                                                    frequency.addValue(2L);
                                                                                    assertEquals(3, frequency.getCount(2L));
                                                                                    assertEquals(5, frequency.getSumFreq());
                                                                                }

    @Test
                                                                                public void testAddValueLongWithMixedTypes() {
                                                                                    Frequency frequency = new Frequency();
                                                                                    
                                                                                    // Add different types of values
                                                                                    frequency.addValue(1); // int
                                                                                    frequency.addValue(2L); // long
                                                                                    frequency.addValue(Integer.valueOf(3)); // Integer
                                                                                    frequency.addValue(Long.valueOf(4)); // Long
                                                                                    
                                                                                    // All should be treated as Long values
                                                                                    assertEquals(1, frequency.getCount(1L));
                                                                                    assertEquals(1, frequency.getCount(2L));
                                                                                    assertEquals(1, frequency.getCount(3L));
                                                                                    assertEquals(1, frequency.getCount(4L));
                                                                                    assertEquals(4, frequency.getSumFreq());
                                                                                }

    @Test
                                                                                public void testAddValueLongEdgeCases() {
                                                                                    Frequency frequency = new Frequency();
                                                                                    
                                                                                    // Test with empty frequency
                                                                                    assertEquals(0, frequency.getSumFreq());
                                                                                    
                                                                                    // Add value to empty frequency
                                                                                    frequency.addValue(100L);
                                                                                    assertEquals(1, frequency.getCount(100L));
                                                                                    assertEquals(1, frequency.getSumFreq());
                                                                                    
                                                                                    // Clear and test again
                                                                                    frequency.clear();
                                                                                    assertEquals(0, frequency.getSumFreq());
                                                                                    frequency.addValue(200L);
                                                                                    assertEquals(1, frequency.getCount(200L));
                                                                                    assertEquals(1, frequency.getSumFreq());
                                                                                }

    @Test
                                                                                public void testAddValueLongPrivateMethod() throws Exception {
                                                                                    Frequency frequency = new Frequency();
                                                                                    
                                                                                    // Use reflection to test private method behavior
                                                                                    Method addValueMethod = Frequency.class.getDeclaredMethod("addValue", Comparable.class);
                                                                                    addValueMethod.setAccessible(true);
                                                                            
                                                                                    // Invoke private method with Long value
                                                                                    addValueMethod.invoke(frequency, Long.valueOf(42L));
                                                                                    assertEquals(1, frequency.getCount(42L));
                                                                                }

    @Test
                                                                                public void testAddValueChar() {
                                                                                    Frequency frequency = new Frequency();
                                                                                    
                                                                                    // Test adding a single character
                                                                                    frequency.addValue('a');
                                                                                    assertEquals(1, frequency.getCount('a'));
                                                                                    
                                                                                    // Test adding the same character multiple times
                                                                                    frequency.addValue('a');
                                                                                    frequency.addValue('a');
                                                                                    assertEquals(3, frequency.getCount('a'));
                                                                                    
                                                                                    // Test adding different characters
                                                                                    frequency.addValue('b');
                                                                                    frequency.addValue('c');
                                                                                    assertEquals(1, frequency.getCount('b'));
                                                                                    assertEquals(1, frequency.getCount('c'));
                                                                                    
                                                                                    // Test adding special characters
                                                                                    frequency.addValue(' ');
                                                                                    frequency.addValue('@');
                                                                                    frequency.addValue('1');
                                                                                    assertEquals(1, frequency.getCount(' '));
                                                                                    assertEquals(1, frequency.getCount('@'));
                                                                                    assertEquals(1, frequency.getCount('1'));
                                                                                }

    @Test
                                                                                public void testAddValueCharWithExistingIntegers() {
                                                                                    Frequency frequency = new Frequency();
                                                                                    
                                                                                    // First add some integer values
                                                                                    frequency.addValue(1);
                                                                                    frequency.addValue(2);
                                                                                    
                                                                                    // Then add character values - should work fine
                                                                                    frequency.addValue('a');
                                                                                    frequency.addValue('b');
                                                                                    
                                                                                    assertEquals(1, frequency.getCount(1));
                                                                                    assertEquals(1, frequency.getCount(2));
                                                                                    assertEquals(1, frequency.getCount('a'));
                                                                                    assertEquals(1, frequency.getCount('b'));
                                                                                }

    @Test
                                                                                public void testAddValueCharEdgeCases() {
                                                                                    Frequency frequency = new Frequency();
                                                                                    
                                                                                    // Test minimum char value
                                                                                    frequency.addValue(Character.MIN_VALUE);
                                                                                    assertEquals(1, frequency.getCount(Character.MIN_VALUE));
                                                                                    
                                                                                    // Test maximum char value
                                                                                    frequency.addValue(Character.MAX_VALUE);
                                                                                    assertEquals(1, frequency.getCount(Character.MAX_VALUE));
                                                                                    
                                                                                    // Test non-printable characters
                                                                                    frequency.addValue('\n');
                                                                                    frequency.addValue('\t');
                                                                                    assertEquals(1, frequency.getCount('\n'));
                                                                                    assertEquals(1, frequency.getCount('\t'));
                                                                                }

    @Test
                                                                                public void testAddValueCharThroughReflection() throws Exception {
                                                                                    Frequency frequency = new Frequency();
                                                                                    
                                                                                    // Use reflection to test the private method call
                                                                                    Method method = Frequency.class.getDeclaredMethod("addValue", Character.class);
                                                                                    method.setAccessible(true);
                                                                                    
                                                                                    method.invoke(frequency, 'x');
                                                                                    assertEquals(1, frequency.getCount('x'));
                                                                                    
                                                                                    method.invoke(frequency, 'x');
                                                                                    assertEquals(2, frequency.getCount('x'));
                                                                                }

    @Test
                                                                                public void testAddValueCharMaintainsCount() {
                                                                                    Frequency frequency = new Frequency();
                                                                                    
                                                                                    // Verify that counts are maintained correctly
                                                                                    for (char c = 'a'; c <= 'z'; c++) {
                                                                                        frequency.addValue(c);
                                                                                    }
                                                                                    
                                                                                    for (char c = 'a'; c <= 'z'; c++) {
                                                                                        assertEquals(1, frequency.getCount(c));
                                                                                    }
                                                                                    
                                                                                    assertEquals(26, frequency.getSumFreq());
                                                                                }

    @Test
        public void testAddValueWithMock() throws Exception {
            // Create mock frequency table
            // Create Frequency instance
            Object freq = Class.forName("org.apache.commons.math.stat.Frequency").newInstance();
            
            // Use reflection to set private freqTable field
            Field freqTableField = freq.getClass().getDeclaredField("freqTable");
            freqTableField.setAccessible(true);
        
            // Set up mock behavior
        
            // Call method under test
            Method addValueMethod = freq.getClass().getMethod("addValue", int.class);
            addValueMethod.invoke(freq, 10);
            
            // Verify behavior
        }

    @Test
        public void testAddValueWithExistingValueInMock() throws Exception {
            // Create mock frequency table
            @SuppressWarnings("unchecked")
            // Create Frequency instance
            Frequency freq = new Frequency();
            
            // Use reflection to set private freqTable field
            Field freqTableField = Frequency.class.getDeclaredField("freqTable");
            freqTableField.setAccessible(true);
            
            // Set up mock behavior
            
            // Call method under test
            freq.addValue(10);
            
            // Verify mock interaction
        }


}
