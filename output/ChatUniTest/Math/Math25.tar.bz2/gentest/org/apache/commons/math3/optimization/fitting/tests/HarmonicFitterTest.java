package gentest.org.apache.commons.math3.optimization.fitting.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.optimization.fitting.*;
import org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer;
import org.apache.commons.math3.analysis.function.HarmonicOscillator;
import org.apache.commons.math3.exception.ZeroException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.apache.commons.math3.exception.MathIllegalStateException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.util.FastMath;
 
public class HarmonicFitterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
            public void testGuessAOmegaWithValidData() throws Exception {
                WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                        new WeightedObservedPoint(1.0, 0.0, 1.0),
                        new WeightedObservedPoint(1.0, 1.0, 1.0),
                        new WeightedObservedPoint(1.0, 2.0, 1.0),
                        new WeightedObservedPoint(1.0, 3.0, 1.0)
                };
                
                HarmonicFitter.ParameterGuesser guesser = new HarmonicFitter.ParameterGuesser(observations);
                
                Method guessAOmegaMethod = HarmonicFitter.ParameterGuesser.class.getDeclaredMethod("guessAOmega");
                guessAOmegaMethod.setAccessible(true);
                guessAOmegaMethod.invoke(guesser);
                
                // Use reflection to access private fields
                Field aField = HarmonicFitter.ParameterGuesser.class.getDeclaredField("a");
                aField.setAccessible(true);
                double a = aField.getDouble(guesser);
                
                Field omegaField = HarmonicFitter.ParameterGuesser.class.getDeclaredField("omega");
                omegaField.setAccessible(true);
                double omega = omegaField.getDouble(guesser);
                
                // Verify amplitude and omega are set (exact values depend on calculations)
                assertTrue(a > 0);
                assertTrue(omega > 0);
            }

    @Test
            public void testGuessAOmegaWithZeroRange() throws Exception {
                WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                        new WeightedObservedPoint(1.0, 0.0, 1.0),
                        new WeightedObservedPoint(1.0, 0.0, 1.0),
                        new WeightedObservedPoint(1.0, 0.0, 1.0),
                        new WeightedObservedPoint(1.0, 0.0, 1.0)
                };
                
                HarmonicFitter.ParameterGuesser guesser = new HarmonicFitter.ParameterGuesser(observations);
                
                Method guessAOmegaMethod = HarmonicFitter.ParameterGuesser.class.getDeclaredMethod("guessAOmega");
                guessAOmegaMethod.setAccessible(true);
                
                try {
                    guessAOmegaMethod.invoke(guesser);
                    fail("Expected ZeroException");
                } catch (Exception e) {
                    assertTrue(e.getCause() instanceof ZeroException);
                }
            }

    @Test
            public void testGuessAOmegaWithNegativeRatios() throws Exception {
                WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                        new WeightedObservedPoint(1.0, 0.0, 1.0),
                        new WeightedObservedPoint(1.0, 10.0, 1.0),
                        new WeightedObservedPoint(1.0, -10.0, 1.0),
                        new WeightedObservedPoint(1.0, 0.0, 1.0)
                };
                
                HarmonicFitter.ParameterGuesser guesser = new HarmonicFitter.ParameterGuesser(observations);
                
                Method guessAOmegaMethod = HarmonicFitter.ParameterGuesser.class.getDeclaredMethod("guessAOmega");
                guessAOmegaMethod.setAccessible(true);
                guessAOmegaMethod.invoke(guesser);
                
                // Use reflection to access private fields
                Field aField = HarmonicFitter.ParameterGuesser.class.getDeclaredField("a");
                aField.setAccessible(true);
                double a = aField.getDouble(guesser);
                
                Field omegaField = HarmonicFitter.ParameterGuesser.class.getDeclaredField("omega");
                omegaField.setAccessible(true);
                double omega = omegaField.getDouble(guesser);
                
                // Should use the fallback calculation based on min/max
                assertTrue(a > 0);
                assertTrue(omega > 0);
            }

    @Test
            public void testGuessAOmegaWithSinglePointRange() throws Exception {
                WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                        new WeightedObservedPoint(1.0, 0.0, 1.0),
                        new WeightedObservedPoint(1.0, 1.0, 1.0),
                        new WeightedObservedPoint(1.0, 1.0, 1.0),
                        new WeightedObservedPoint(1.0, 1.0, 1.0)
                };
                
                HarmonicFitter.ParameterGuesser guesser = new HarmonicFitter.ParameterGuesser(observations);
                
                Method guessAOmegaMethod = HarmonicFitter.ParameterGuesser.class.getDeclaredMethod("guessAOmega");
                guessAOmegaMethod.setAccessible(true);
                guessAOmegaMethod.invoke(guesser);
                
                // Get private fields using reflection
                Field aField = HarmonicFitter.ParameterGuesser.class.getDeclaredField("a");
                aField.setAccessible(true);
                double a = aField.getDouble(guesser);
                
                Field omegaField = HarmonicFitter.ParameterGuesser.class.getDeclaredField("omega");
                omegaField.setAccessible(true);
                double omega = omegaField.getDouble(guesser);
                
                // Should use the fallback calculation based on min/max
                assertEquals(0.0, a, 1e-10);
                assertTrue(omega > 0);
            }

    @Test
        public void testGuessAOmegaWithIllConditionedCase() throws Exception {
            // Create data that will make c2 == 0 in the calculations
            WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                    new WeightedObservedPoint(1.0, 0.0, 1.0),
                    new WeightedObservedPoint(1.0, 1.0, 1.0),
                    new WeightedObservedPoint(1.0, 1.0, 1.0),
                    new WeightedObservedPoint(1.0, 0.0, 1.0)
            };
            
            HarmonicFitter.ParameterGuesser guesser = new HarmonicFitter.ParameterGuesser(observations);
            
            Method guessAOmegaMethod = HarmonicFitter.ParameterGuesser.class.getDeclaredMethod("guessAOmega");
            guessAOmegaMethod.setAccessible(true);
            
            try {
                guessAOmegaMethod.invoke(guesser);
                fail("Expected MathIllegalStateException");
            } catch (Exception e) {
                assertTrue(e.getCause() instanceof MathIllegalStateException);
                assertEquals("zero denominator", 
                    ((MathIllegalStateException)e.getCause()).getMessage());
            }
        }


}
