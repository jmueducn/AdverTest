package gentest.org.apache.commons.math3.optimization.direct.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.optimization.direct.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.math3.analysis.MultivariateFunction;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MathUnsupportedOperationException;
import org.apache.commons.math3.exception.MathIllegalStateException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.OutOfRangeException;
import org.apache.commons.math3.exception.TooManyEvaluationsException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.EigenDecomposition;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.optimization.ConvergenceChecker;
import org.apache.commons.math3.optimization.GoalType;
import org.apache.commons.math3.optimization.MultivariateOptimizer;
import org.apache.commons.math3.optimization.PointValuePair;
import org.apache.commons.math3.optimization.SimpleValueChecker;
import org.apache.commons.math3.random.MersenneTwister;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.util.MathArrays;
 
public class CMAESOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                public void testRepairAndDecodeWithNullBoundaries() throws Exception {
                                                    CMAESOptimizer optimizer = new CMAESOptimizer();
                                                    double[] input = {0.5, 1.5, -0.5};
                                                    
                                                    Method repairAndDecodeMethod = CMAESOptimizer.class.getDeclaredMethod(
                                                        "repairAndDecode", double[].class);
                                                    repairAndDecodeMethod.setAccessible(true);
                                                    
                                                    double[] result = (double[]) repairAndDecodeMethod.invoke(optimizer, input);
                                                    assertArrayEquals(input, result, 1e-15);
                                                }

    @Test
                                                public void testRepairAndDecodeWithDifferentBoundRanges() throws Exception {
                                                    // Setup test objects
                                                    CMAESOptimizer optimizer = new CMAESOptimizer();
                                                    MultivariateFunction fitnessFunction = new MultivariateFunction() {
                                                        @Override
                                                        public double value(double[] point) {
                                                            return 0;
                                                        }
                                                    };
                                                    
                                                    // Use reflection to set private fields
                                                    java.lang.reflect.Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                    boundariesField.setAccessible(true);
                                                    boundariesField.set(optimizer, new double[][]{{-5, 0, 10}, {5, 10, 20}});
                                            
                                                    java.lang.reflect.Field isRepairModeField = CMAESOptimizer.class.getDeclaredField("isRepairMode");
                                                    isRepairModeField.setAccessible(true);
                                                    isRepairModeField.set(optimizer, true);
                                            
                                                    // Get private method via reflection
                                                    Method repairAndDecodeMethod = CMAESOptimizer.class.getDeclaredMethod("repairAndDecode", double[].class);
                                                    repairAndDecodeMethod.setAccessible(true);
                                            
                                                    // Test within bounds
                                                    double[] input1 = {0.5, 0.5, 0.5};
                                                    double[] expected1 = {0.0, 5.0, 15.0};
                                                    assertArrayEquals(expected1, (double[]) repairAndDecodeMethod.invoke(optimizer, (Object) input1), 1e-15);
                                                    
                                                    // Test boundary cases
                                                    double[] input2 = {0.0, 0.0, 0.0};
                                                    double[] expected2 = {-5.0, 0.0, 10.0};
                                                    assertArrayEquals(expected2, (double[]) repairAndDecodeMethod.invoke(optimizer, (Object) input2), 1e-15);
                                                    
                                                    double[] input3 = {1.0, 1.0, 1.0};
                                                    double[] expected3 = {5.0, 10.0, 20.0};
                                                    assertArrayEquals(expected3, (double[]) repairAndDecodeMethod.invoke(optimizer, (Object) input3), 1e-15);
                                                }

    @Test
                                            public void testRepairAndDecodeWithBoundariesAndRepairMode() throws Exception {
                                                CMAESOptimizer optimizer = new CMAESOptimizer();
                                                
                                                // Create mock fitness function
                                                class FitnessFunction {
                                                    boolean isRepairMode;
                                                }
                                                FitnessFunction fitnessFunction = new FitnessFunction();
                                                
                                                // Set up test conditions
                                                Method setBoundaries = CMAESOptimizer.class.getDeclaredMethod("setBoundaries", double[][].class);
                                                setBoundaries.setAccessible(true);
                                                setBoundaries.invoke(optimizer, new double[][]{{0, 0, 0}, {10, 10, 10}});
                                                
                                                Method setFitnessFunction = CMAESOptimizer.class.getDeclaredMethod("setFitnessFunction", Object.class);
                                                setFitnessFunction.setAccessible(true);
                                                setFitnessFunction.invoke(optimizer, fitnessFunction);
                                                
                                                fitnessFunction.isRepairMode = true;
                                                
                                                // Get private method via reflection
                                                Method repairAndDecode = CMAESOptimizer.class.getDeclaredMethod("repairAndDecode", double[].class);
                                                repairAndDecode.setAccessible(true);
                                                
                                                // Test within bounds
                                                double[] input1 = {0.5, 0.5, 0.5};
                                                double[] expected1 = {5.0, 5.0, 5.0};
                                                assertArrayEquals(expected1, (double[]) repairAndDecode.invoke(optimizer, input1), 1e-15);
                                                
                                                // Test below lower bound
                                                double[] input2 = {-0.5, 0.5, 0.5};
                                                double[] expected2 = {0.0, 5.0, 5.0};
                                                assertArrayEquals(expected2, (double[]) repairAndDecode.invoke(optimizer, input2), 1e-15);
                                                
                                                // Test above upper bound
                                                double[] input3 = {0.5, 1.5, 0.5};
                                                double[] expected3 = {5.0, 10.0, 5.0};
                                                assertArrayEquals(expected3, (double[]) repairAndDecode.invoke(optimizer, input3), 1e-15);
                                            }

    @Test
                                            public void testRepairAndDecodeWithSingleDimension() throws Exception {
                                                CMAESOptimizer optimizer = new CMAESOptimizer();
                                                
                                                // Create a mock fitness function using reflection
                                                Class<?> fitnessFunctionClass = Class.forName("org.apache.commons.math3.optimization.direct.CMAESOptimizer$FitnessFunction");
                                                Object fitnessFunction = fitnessFunctionClass.getDeclaredConstructor(CMAESOptimizer.class).newInstance(optimizer);
                                                
                                                // Set up test using reflection since fields are private
                                                Method setBoundaries = CMAESOptimizer.class.getDeclaredMethod("setBoundaries", double[][].class);
                                                setBoundaries.setAccessible(true);
                                                setBoundaries.invoke(optimizer, new double[][]{{0}, {100}});
                                                
                                                Method setIsRepairMode = fitnessFunctionClass.getDeclaredMethod("setRepairMode", boolean.class);
                                                setIsRepairMode.setAccessible(true);
                                                setIsRepairMode.invoke(fitnessFunction, true);
                                                
                                                // Get private method to test
                                                Method repairAndDecode = CMAESOptimizer.class.getDeclaredMethod("repairAndDecode", double[].class);
                                                repairAndDecode.setAccessible(true);
                                                
                                                double[] input1 = {0.5};
                                                double[] expected1 = {50.0};
                                                assertArrayEquals(expected1, (double[]) repairAndDecode.invoke(optimizer, input1), 1e-15);
                                                
                                                double[] input2 = {1.5};
                                                double[] expected2 = {100.0};
                                                assertArrayEquals(expected2, (double[]) repairAndDecode.invoke(optimizer, input2), 1e-15);
                                            }

    @Test
        public void testRepairAndDecodeWithBoundariesAndNoRepairMode() throws Exception {
            // Create mock and test objects
            CMAESOptimizer optimizer = new CMAESOptimizer();
            MultivariateFunction fitnessFunction = mock(MultivariateFunction.class);
            
            // Set up test conditions
            Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
            boundariesField.setAccessible(true);
            boundariesField.set(optimizer, new double[][]{{0, 0, 0}, {10, 10, 10}});
            
            Field fitnessFunctionField = CMAESOptimizer.class.getDeclaredField("fitnessFunction");
            fitnessFunctionField.setAccessible(true);
            fitnessFunctionField.set(optimizer, fitnessFunction);
            
            Field isRepairModeField = CMAESOptimizer.class.getDeclaredField("isRepairMode");
            isRepairModeField.setAccessible(true);
            isRepairModeField.set(optimizer, false);
        
            // Get private method via reflection
            Method repairAndDecodeMethod = CMAESOptimizer.class.getDeclaredMethod("repairAndDecode", double[].class);
            repairAndDecodeMethod.setAccessible(true);
        
            // Test within bounds
            double[] input1 = {0.5, 0.5, 0.5};
            double[] expected1 = {5.0, 5.0, 5.0};
            assertArrayEquals(expected1, (double[]) repairAndDecodeMethod.invoke(optimizer, input1), 1e-15);
        
            // Test below lower bound (no repair)
            double[] input2 = {-0.5, 0.5, 0.5};
            double[] expected2 = {-5.0, 5.0, 5.0};
            assertArrayEquals(expected2, (double[]) repairAndDecodeMethod.invoke(optimizer, input2), 1e-15);
        
            // Test above upper bound (no repair)
            double[] input3 = {0.5, 1.5, 0.5};
            double[] expected3 = {5.0, 15.0, 5.0};
            assertArrayEquals(expected3, (double[]) repairAndDecodeMethod.invoke(optimizer, input3), 1e-15);
        }


}
