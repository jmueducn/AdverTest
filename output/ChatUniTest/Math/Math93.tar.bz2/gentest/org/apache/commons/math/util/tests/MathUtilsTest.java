package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.util.Arrays;
 
public class MathUtilsTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testFactorialForZero() {
            assertEquals(1, MathUtils.factorial(0));
        }

    @Test
        public void testFactorialForOne() {
            assertEquals(1, MathUtils.factorial(1));
        }

    @Test
        public void testFactorialForSmallNumbers() {
            assertEquals(2, MathUtils.factorial(2));
            assertEquals(6, MathUtils.factorial(3));
            assertEquals(24, MathUtils.factorial(4));
            assertEquals(120, MathUtils.factorial(5));
        }

    @Test
        public void testFactorialForMediumNumbers() {
            assertEquals(720, MathUtils.factorial(6));
            assertEquals(5040, MathUtils.factorial(7));
            assertEquals(40320, MathUtils.factorial(8));
            assertEquals(362880, MathUtils.factorial(9));
            assertEquals(3628800, MathUtils.factorial(10));
        }

    @Test
        public void testFactorialForLargeNumbers() {
            assertEquals(39916800, MathUtils.factorial(11));
            assertEquals(479001600, MathUtils.factorial(12));
            assertEquals(6227020800L, MathUtils.factorial(13));
            assertEquals(87178291200L, MathUtils.factorial(14));
            assertEquals(1307674368000L, MathUtils.factorial(15));
            assertEquals(20922789888000L, MathUtils.factorial(16));
            assertEquals(355687428096000L, MathUtils.factorial(17));
            assertEquals(6402373705728000L, MathUtils.factorial(18));
            assertEquals(121645100408832000L, MathUtils.factorial(19));
            assertEquals(2432902008176640000L, MathUtils.factorial(20));
        }

    @Test(expected = IllegalArgumentException.class)
        public void testFactorialNegativeNumber() {
            MathUtils.factorial(-1);
        }

    @Test(expected = ArithmeticException.class)
        public void testFactorialTooLargeNumber() {
            MathUtils.factorial(21);
        }

    @Test(expected = ArithmeticException.class)
        public void testFactorialMaxBoundary() {
            MathUtils.factorial(Integer.MAX_VALUE);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testFactorialMinBoundary() {
            MathUtils.factorial(Integer.MIN_VALUE);
        }

    @Test
        public void testFactorialDoubleNegativeInput() {
            try {
                MathUtils.factorialDouble(-1);
                fail("Expected IllegalArgumentException");
            } catch (IllegalArgumentException e) {
                assertEquals("must have n >= 0 for n!", e.getMessage());
            }
        }

    @Test
        public void testFactorialDoubleZero() {
            double result = MathUtils.factorialDouble(0);
            assertEquals(1.0, result, 0.0);
        }

    @Test
        public void testFactorialDoubleOne() {
            double result = MathUtils.factorialDouble(1);
            assertEquals(1.0, result, 0.0);
        }

    @Test
        public void testFactorialDoubleSmallValue() {
            double result = MathUtils.factorialDouble(5);
            assertEquals(120.0, result, 0.0);
        }

    @Test
        public void testFactorialDoubleBoundaryValue() {
            double result = MathUtils.factorialDouble(20);
            assertEquals(2432902008176640000L, (long)result);
        }

    @Test
        public void testFactorialDoubleLargeValue() {
            double result = MathUtils.factorialDouble(21);
            // Verify it uses the log-based calculation for values >= 21
            double expected = Math.floor(Math.exp(MathUtils.factorialLog(21)) + 0.5);
            assertEquals(expected, result, 0.0);
        }

    @Test
        public void testFactorialDoubleVeryLargeValue() {
            double result = MathUtils.factorialDouble(100);
            // Just verify it doesn't throw exception and returns a positive value
            assertTrue(result > 0);
            assertFalse(Double.isInfinite(result));
            assertFalse(Double.isNaN(result));
        }

    @Test
        public void testFactorialLogNegativeInput() {
            try {
                MathUtils.factorialLog(-1);
                fail("Expected IllegalArgumentException");
            } catch (IllegalArgumentException e) {
                assertEquals("must have n > 0 for n!", e.getMessage());
            }
        }

    @Test
        public void testFactorialLogZeroInput() {
            try {
                MathUtils.factorialLog(0);
                fail("Expected IllegalArgumentException");
            } catch (IllegalArgumentException e) {
                assertEquals("must have n > 0 for n!", e.getMessage());
            }
        }

    @Test
        public void testFactorialLogSmallValues() {
            // Test values less than 21 (uses factorial table)
            assertEquals(Math.log(1), MathUtils.factorialLog(1), 1e-10);
            assertEquals(Math.log(2), MathUtils.factorialLog(2), 1e-10);
            assertEquals(Math.log(6), MathUtils.factorialLog(3), 1e-10);
            assertEquals(Math.log(24), MathUtils.factorialLog(4), 1e-10);
            assertEquals(Math.log(120), MathUtils.factorialLog(5), 1e-10);
            assertEquals(Math.log(3628800), MathUtils.factorialLog(10), 1e-10);
            assertEquals(Math.log(2432902008176640000L), MathUtils.factorialLog(20), 1e-10);
        }

    @Test
        public void testFactorialLogLargeValues() {
            // Test values >= 21 (uses log sum calculation)
            double expected21 = 0;
            for (int i = 2; i <= 21; i++) {
                expected21 += Math.log(i);
            }
            assertEquals(expected21, MathUtils.factorialLog(21), 1e-10);
    
            double expected30 = 0;
            for (int i = 2; i <= 30; i++) {
                expected30 += Math.log(i);
            }
            assertEquals(expected30, MathUtils.factorialLog(30), 1e-10);
    
            double expected100 = 0;
            for (int i = 2; i <= 100; i++) {
                expected100 += Math.log(i);
            }
            assertEquals(expected100, MathUtils.factorialLog(100), 1e-10);
        }

    @Test
        public void testFactorialLogBoundaryValue() {
            // Test boundary value (20 vs 21)
            double log20 = Math.log(2432902008176640000L);
            assertEquals(log20, MathUtils.factorialLog(20), 1e-10);
    
            double log21 = log20 + Math.log(21);
            assertEquals(log21, MathUtils.factorialLog(21), 1e-10);
        }

}
