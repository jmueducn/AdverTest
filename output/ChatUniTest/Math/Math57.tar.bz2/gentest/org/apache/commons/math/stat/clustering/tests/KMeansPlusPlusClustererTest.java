package gentest.org.apache.commons.math.stat.clustering.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.clustering.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Random;
import org.apache.commons.math.exception.ConvergenceException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.stat.descriptive.moment.Variance;
 
public class KMeansPlusPlusClustererTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test(expected = IllegalArgumentException.class)
                                                                                    public void testChooseInitialCentersWithEmptyPoints() throws Exception {
                                                                                        // Setup
                                                                                        List<Clusterable> emptyPoints = new ArrayList<>();
                                                                                        Random mockRandom = mock(Random.class);
                                                                                
                                                                                        // Get private method via reflection
                                                                                        Method method = KMeansPlusPlusClusterer.class.getDeclaredMethod(
                                                                                            "chooseInitialCenters", Collection.class, int.class, Random.class);
                                                                                        method.setAccessible(true);
                                                                                
                                                                                        // Test with empty points
                                                                                        method.invoke(null, emptyPoints, 1, mockRandom);
                                                                                    }

    @Test
                                        public void testChooseInitialCentersWithKGreaterThanPoints() throws Exception {
                                            // Setup
                                            Random mockRandom = mock(Random.class);
                                            when(mockRandom.nextInt(anyInt())).thenReturn(0);
                                            when(mockRandom.nextDouble()).thenReturn(0.0);
                                            
                                            // Create test points
                                            List<EuclideanIntegerPoint> points = new ArrayList<EuclideanIntegerPoint>();
                                            points.add(new EuclideanIntegerPoint(new int[]{1, 2}));
                                            points.add(new EuclideanIntegerPoint(new int[]{3, 4}));
                                            points.add(new EuclideanIntegerPoint(new int[]{5, 6}));
                                    
                                            // Get private method via reflection
                                            Method method = KMeansPlusPlusClusterer.class.getDeclaredMethod(
                                                "chooseInitialCenters", Collection.class, int.class, Random.class);
                                            method.setAccessible(true);
                                        
                                            // Test with k > points.size()
                                            method.invoke(null, points, 4, mockRandom);
                                        }

    @Test
                                        public void testChooseInitialCentersProbabilitySelection() throws Exception {
                                            // Setup
                                            Random mockRandom = mock(Random.class);
                                            EuclideanIntegerPoint mockPoint1 = mock(EuclideanIntegerPoint.class);
                                            EuclideanIntegerPoint mockPoint2 = mock(EuclideanIntegerPoint.class);
                                            EuclideanIntegerPoint mockPoint3 = mock(EuclideanIntegerPoint.class);
                                            
                                            List<EuclideanIntegerPoint> points = new ArrayList<>();
                                            points.add(mockPoint1);
                                            points.add(mockPoint2);
                                            points.add(mockPoint3);
                                    
                                            when(mockRandom.nextInt(anyInt())).thenReturn(0);
                                            when(mockRandom.nextDouble()).thenReturn(0.5);
                                        
                                            when(mockPoint1.distanceFrom(any(EuclideanIntegerPoint.class))).thenReturn(1.0);
                                            when(mockPoint2.distanceFrom(any(EuclideanIntegerPoint.class))).thenReturn(2.0);
                                            when(mockPoint3.distanceFrom(any(EuclideanIntegerPoint.class))).thenReturn(3.0);
                                        
                                            // Get private method via reflection
                                            Method method = KMeansPlusPlusClusterer.class.getDeclaredMethod(
                                                "chooseInitialCenters", Collection.class, int.class, Random.class);
                                            method.setAccessible(true);
                                        
                                            // Test with k=2
                                            @SuppressWarnings("unchecked")
                                            List<Cluster<EuclideanIntegerPoint>> result = (List<Cluster<EuclideanIntegerPoint>>) method.invoke(
                                                null, points, 2, mockRandom);
                                        
                                            // Verify probability-based selection occurred
                                            assertEquals(2, result.size());
                                            verify(mockRandom, atLeastOnce()).nextDouble();
                                        }

    @Test
                                        public void testChooseInitialCentersWithExactKPoints() throws Exception {
                                            // Setup
                                            Random mockRandom = mock(Random.class);
                                            when(mockRandom.nextInt(anyInt())).thenReturn(0);
                                            when(mockRandom.nextDouble()).thenReturn(0.5);
                                            
                                            List<Double> point1 = new ArrayList<Double>();
                                            point1.add(1.0);
                                            List<Double> point2 = new ArrayList<Double>();
                                            point2.add(2.0);
                                            List<Double> point3 = new ArrayList<Double>();
                                            point3.add(3.0);
                                            Collection<List<Double>> points = new ArrayList<List<Double>>();
                                            points.add(point1);
                                            points.add(point2);
                                            points.add(point3);
                                        
                                            // Get private method via reflection
                                            Method method = KMeansPlusPlusClusterer.class.getDeclaredMethod(
                                                "chooseInitialCenters", Collection.class, int.class, Random.class);
                                            method.setAccessible(true);
                                        
                                            // Test with k = points.size()
                                            @SuppressWarnings("unchecked")
                                            Collection<List<Double>> result = (Collection<List<Double>>) method.invoke(
                                                null, points, points.size(), mockRandom);
                                        
                                            // Verify
                                            assertEquals(3, result.size());
                                            verify(mockRandom, times(1)).nextInt(3);
                                        }

    @Test
                                    public void testChooseInitialCenters() throws Exception {
                                        // Setup
                                        Random mockRandom = mock(Random.class);
                                        EuclideanIntegerPoint mockPoint1 = mock(EuclideanIntegerPoint.class);
                                        EuclideanIntegerPoint mockPoint2 = mock(EuclideanIntegerPoint.class);
                                        EuclideanIntegerPoint mockPoint3 = mock(EuclideanIntegerPoint.class);
                                        
                                        List<EuclideanIntegerPoint> points = new ArrayList<>();
                                        points.add(mockPoint1);
                                        points.add(mockPoint2);
                                        points.add(mockPoint3);
                                        
                                        when(mockRandom.nextInt(anyInt())).thenReturn(0);
                                        when(mockRandom.nextDouble()).thenReturn(0.5);
                                        
                                        when(mockPoint1.distanceFrom(any(EuclideanIntegerPoint.class))).thenReturn(1.0);
                                        when(mockPoint2.distanceFrom(any(EuclideanIntegerPoint.class))).thenReturn(2.0);
                                        when(mockPoint3.distanceFrom(any(EuclideanIntegerPoint.class))).thenReturn(3.0);
                                        
                                        // Get private method via reflection
                                        Method method = KMeansPlusPlusClusterer.class.getDeclaredMethod(
                                            "chooseInitialCenters", Collection.class, int.class, Random.class);
                                        method.setAccessible(true);
                                        
                                        // Test with k=2
                                        @SuppressWarnings("unchecked")
                                        List<Cluster<EuclideanIntegerPoint>> result = (List<Cluster<EuclideanIntegerPoint>>) method.invoke(
                                            null, points, 2, mockRandom);
                                        
                                        // Verify
                                        assertEquals(2, result.size());
                                        verify(mockRandom, times(1)).nextInt(3);
                                        verify(mockRandom, atLeastOnce()).nextDouble();
                                    }

    @Test
        public void testChooseInitialCentersWithSinglePoint() throws Exception {
            // Setup
            Random mockRandom = mock(Random.class);
            Clusterable mockPoint1 = new Clusterable() {
                public double[] getPoint() {
                    return new double[]{0.0};
                }
                
                public double distanceFrom(Clusterable p) {
                    return 0.0;
                }
                
                @Override
                public double distanceFrom(Object p) {
                    return 0.0;
                }
                
                @SuppressWarnings("unchecked")
                public Clusterable centroidOf(Collection points) {
                    return this;
                }
            };
            
            Collection<Clusterable> singlePoint = new ArrayList<>();
            singlePoint.add(mockPoint1);
            
            when(mockRandom.nextInt(anyInt())).thenReturn(0);
            when(mockRandom.nextDouble()).thenReturn(0.0);
        
            // Get private method via reflection
            Method method = KMeansPlusPlusClusterer.class.getDeclaredMethod(
                "chooseInitialCenters", Collection.class, int.class, Random.class);
            method.setAccessible(true);
        
            // Test with k=1
            @SuppressWarnings("unchecked")
            Collection<Clusterable> result = (Collection<Clusterable>) method.invoke(
                null, singlePoint, 1, mockRandom);
        
            // Verify
            assertEquals(1, result.size());
            verify(mockRandom, times(1)).nextInt(1);
        }


}
