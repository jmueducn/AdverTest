package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Iterator;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.util.MathUtils;
 
public class ArrayRealVectorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
            public void testMapInvToSelfWithNegativeValues() {
                ArrayRealVector vec = new ArrayRealVector(new double[]{-2.0, -4.0});
                ArrayRealVector result = (ArrayRealVector) vec.mapInvToSelf();
                
                assertEquals(-0.5, result.getEntry(0), 0.0001);
                assertEquals(-0.25, result.getEntry(1), 0.0001);
            }

    @Test
            public void testMapInvToSelfWithMixedValues() {
                ArrayRealVector vec = new ArrayRealVector(new double[]{1.0, -1.0, 0.5});
                ArrayRealVector result = (ArrayRealVector) vec.mapInvToSelf();
                
                assertEquals(1.0, result.getEntry(0), 0.0001);
                assertEquals(-1.0, result.getEntry(1), 0.0001);
                assertEquals(2.0, result.getEntry(2), 0.0001);
            }

    @Test
            public void testMapInvToSelfWithSingleElement() {
                ArrayRealVector vec = new ArrayRealVector(new double[]{10.0});
                ArrayRealVector result = (ArrayRealVector) vec.mapInvToSelf();
                
                assertEquals(0.1, result.getEntry(0), 0.0001);
            }

    @Test(expected = ArithmeticException.class)
            public void testMapInvToSelfWithZero() {
                ArrayRealVector vec = new ArrayRealVector(new double[]{1.0, 0.0, 2.0});
                vec.mapInvToSelf(); // Should throw ArithmeticException for division by zero
            }

    @Test
            public void testMapInvToSelfWithEmptyVector() {
                ArrayRealVector vec = new ArrayRealVector(new double[0]);
                ArrayRealVector result = (ArrayRealVector) vec.mapInvToSelf();
                
                assertEquals(0, result.getDimension());
            }

    @Test
        public void testMapInvToSelfWithPositiveValues() {
            double[] testData = {2.0, 4.0, 8.0};
            ArrayRealVector vector = new ArrayRealVector(testData);
            
            ArrayRealVector result = (ArrayRealVector) vector.mapInvToSelf();
            
            assertSame(vector, result); // Should return same instance
            assertEquals(0.5, result.getEntry(0), 0.0001);
            assertEquals(0.25, result.getEntry(1), 0.0001);
            assertEquals(0.125, result.getEntry(2), 0.0001);
        }

    @Test
        public void testGetLInfNormWithPositiveValues() {
            double[] data = {1.0, 2.0, 3.0, 4.0};
            ArrayRealVector vector = new ArrayRealVector(data);
            assertEquals(4.0, vector.getLInfNorm(), 0.0001);
        }

    @Test
        public void testGetLInfNormWithNegativeValues() {
            double[] data = {-1.0, -2.0, -3.0, -4.0};
            ArrayRealVector vector = new ArrayRealVector(data);
            assertEquals(4.0, vector.getLInfNorm(), 0.0001);
        }

    @Test
        public void testGetLInfNormWithMixedValues() {
            double[] data = {-5.0, 3.0, -2.0, 4.0};
            ArrayRealVector vector = new ArrayRealVector(data);
            assertEquals(5.0, vector.getLInfNorm(), 0.0001);
        }

    @Test
        public void testGetLInfNormWithSingleElement() {
            double[] data = {7.0};
            ArrayRealVector vector = new ArrayRealVector(data);
            assertEquals(7.0, vector.getLInfNorm(), 0.0001);
        }

    @Test
        public void testGetLInfNormWithZeroVector() {
            double[] data = {0.0, 0.0, 0.0};
            ArrayRealVector vector = new ArrayRealVector(data);
            assertEquals(0.0, vector.getLInfNorm(), 0.0001);
        }

    @Test
        public void testGetLInfNormWithEmptyVector() {
            double[] data = {};
            ArrayRealVector vector = new ArrayRealVector(data);
            assertEquals(0.0, vector.getLInfNorm(), 0.0001);
        }

    @Test
        public void testGetLInfNormWithEqualAbsoluteValues() {
            double[] data = {5.0, -5.0, 5.0, -5.0};
            ArrayRealVector vector = new ArrayRealVector(data);
            assertEquals(5.0, vector.getLInfNorm(), 0.0001);
        }

    @Test
        public void testGetLInfNormWithLargeValues() {
            double[] data = {Double.MAX_VALUE, -Double.MAX_VALUE};
            ArrayRealVector vector = new ArrayRealVector(data);
            assertEquals(Double.MAX_VALUE, vector.getLInfNorm(), 0.0001);
        }

    @Test
        public void testGetLInfNormWithSmallValues() {
            double[] data = {Double.MIN_VALUE, -Double.MIN_VALUE};
            ArrayRealVector vector = new ArrayRealVector(data);
            assertEquals(Double.MIN_VALUE, vector.getLInfNorm(), 0.0001);
        }


}
