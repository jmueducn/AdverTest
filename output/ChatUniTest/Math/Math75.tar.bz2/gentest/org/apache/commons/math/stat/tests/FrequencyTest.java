package gentest.org.apache.commons.math.stat.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.*;
import java.io.Serializable;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.Comparator;
import java.util.TreeMap;
import org.apache.commons.math.MathRuntimeException;
 
public class FrequencyTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
            public void testGetPctWithNullObject() {
                Frequency frequency = new Frequency();
                double result = frequency.getPct((Object) null);
                assertEquals(0.0, result, 0.0001);
            }

    @Test
            public void testGetPctWithNonComparableObject() {
                Frequency frequency = new Frequency();
                Object nonComparable = new Object();
                double result = frequency.getPct(nonComparable);
                assertEquals(0.0, result, 0.0001);
            }

    @Test
            public void testGetPctWithEmptyFrequencyTable() {
                Frequency frequency = new Frequency();
                Comparable<?> value = 5;
                double result = frequency.getPct(value);
                assertTrue(Double.isNaN(result));
            }

    @Test
            public void testGetPctWithExistingValue() {
                Frequency frequency = new Frequency();
                frequency.addValue(5);
                frequency.addValue(5);
                frequency.addValue(10);
                
                double result = frequency.getPct((Object) 5);
                assertEquals(0.6666, result, 0.0001);
            }

    @Test
            public void testGetPctWithNonExistingValue() {
                Frequency frequency = new Frequency();
                frequency.addValue(10);
                frequency.addValue(20);
                
                double result = frequency.getPct(15);
                assertEquals(0.0, result, 0.0001);
            }

    @Test
            public void testGetPctWithIntegerObject() {
                Frequency frequency = new Frequency();
                frequency.addValue(5);
                frequency.addValue(5);
                frequency.addValue(10);
                
                Integer value = Integer.valueOf(5);
                double result = frequency.getPct((Object) value);
                assertEquals(0.6666, result, 0.0001);
            }

    @Test
            public void testGetPctWithLongObject() {
                Frequency frequency = new Frequency();
                frequency.addValue(5L);
                frequency.addValue(5L);
                frequency.addValue(10L);
                
                Long value = Long.valueOf(5L);
                double result = frequency.getPct((Object) value);
                assertEquals(0.6666, result, 0.0001);
            }

    @Test
            public void testGetPctWithCharacterObject() {
                Frequency frequency = new Frequency();
                frequency.addValue('a');
                frequency.addValue('a');
                frequency.addValue('b');
                
                Character value = Character.valueOf('a');
                double result = frequency.getPct((Object) value);
                assertEquals(0.6666, result, 0.0001);
            }

    @Test
            public void testGetPctWithStringObject() {
                Frequency frequency = new Frequency();
                frequency.addValue("test");
                frequency.addValue("test");
                frequency.addValue("other");
                
                String value = "test";
                double result = frequency.getPct((Object) value);
                assertEquals(0.6666, result, 0.0001);
            }

    @Test
            public void testGetPctDelegatesToComparableVersion() throws Exception {
                Frequency frequency = new Frequency();
                Frequency spy = spy(frequency);
                Object testValue = 5;
                
                spy.getPct(testValue);
                
                verify(spy).getPct((Comparable<?>) testValue);
            }

    @Test
            public void testGetPctWithEmptyFrequency() {
                Frequency frequency = new Frequency();
                Comparable<?> value = Integer.valueOf(1);
                double result = frequency.getPct(value);
                assertTrue(Double.isNaN(result));
            }

    @Test
            public void testGetPctWithSingleValue() {
                Frequency frequency = new Frequency();
                Comparable<?> value = Integer.valueOf(5);
                frequency.addValue(value);
                double result = frequency.getPct(value);
                assertEquals(1.0, result, 0.0001);
            }

    @Test
            public void testGetPctWithMultipleValues() {
                Frequency frequency = new Frequency();
                Integer value1 = 5;
                Integer value2 = 10;
                frequency.addValue(value1);
                frequency.addValue(value1);
                frequency.addValue(value2);
                
                double result1 = frequency.getPct(value1);
                double result2 = frequency.getPct(value2);
                
                assertEquals(0.6666, result1, 0.0001);
                assertEquals(0.3333, result2, 0.0001);
            }

    @Test
            public void testGetPctWithNonExistentValue() {
                Frequency frequency = new Frequency();
                Comparable<?> existingValue = Integer.valueOf(5);
                Comparable<?> nonExistentValue = Integer.valueOf(10);
                frequency.addValue(existingValue);
                
                double result = frequency.getPct(nonExistentValue);
                assertEquals(0.0, result, 0.0001);
            }

    @Test
            public void testGetPctWithDifferentTypes() {
                Frequency frequency = new Frequency();
                
                Comparable<?> intValue = Integer.valueOf(5);
                Comparable<?> longValue = Long.valueOf(5L);
                Comparable<?> charValue = Character.valueOf('a');
                
                frequency.addValue(intValue);
                frequency.addValue(longValue);
                frequency.addValue(charValue);
                
                double intResult = frequency.getPct(intValue);
                double longResult = frequency.getPct(longValue);
                double charResult = frequency.getPct(charValue);
                
                assertEquals(0.6666, intResult, 0.0001);
                assertEquals(0.6666, longResult, 0.0001);
                assertEquals(0.3333, charResult, 0.0001);
            }

    @Test
            public void testGetPctWithNullValue() {
                Frequency frequency = new Frequency();
                frequency.addValue(1);
                frequency.addValue(2);
                
                double result = frequency.getPct(null);
                assertEquals(0.0, result, 0.0001);
            }

    @Test
            public void testGetPctWithIncomparableValue() {
                Frequency frequency = new Frequency();
                frequency.addValue(1);
                frequency.addValue(2);
                
                // Create an incomparable object
                Object incomparable = new Object();
                
                double result = frequency.getPct((Comparable<?>) incomparable);
                assertEquals(0.0, result, 0.0001);
            }

    @Test
            public void testGetPctWithIntegerVsLong() {
                Frequency frequency = new Frequency();
                frequency.addValue(5);
                frequency.addValue(5L);
                frequency.addValue(10);
                
                double intResult = frequency.getPct(5);
                double longResult = frequency.getPct(5L);
                
                assertEquals(0.6666, intResult, 0.0001);
                assertEquals(0.6666, longResult, 0.0001);
            }

    @Test
            public void testGetPctIntWithEmptyFrequency() {
                Frequency frequency = new Frequency();
                double result = frequency.getPct(5);
                assertTrue(Double.isNaN(result));
            }

    @Test
            public void testGetPctIntWithSingleValue() {
                Frequency frequency = new Frequency();
                frequency.addValue(5);
                double result = frequency.getPct(5);
                assertEquals(1.0, result, 0.0001);
            }

    @Test
            public void testGetPctIntWithMultipleValues() {
                Frequency frequency = new Frequency();
                frequency.addValue(5);
                frequency.addValue(10);
                frequency.addValue(5);
                frequency.addValue(15);
                
                double result = frequency.getPct(5);
                assertEquals(0.5, result, 0.0001);
                
                result = frequency.getPct(10);
                assertEquals(0.25, result, 0.0001);
                
                result = frequency.getPct(15);
                assertEquals(0.25, result, 0.0001);
            }

    @Test
            public void testGetPctIntWithNonExistentValue() {
                Frequency frequency = new Frequency();
                frequency.addValue(5);
                frequency.addValue(10);
                
                double result = frequency.getPct(15);
                assertEquals(0.0, result, 0.0001);
            }

    @Test
            public void testGetPctIntWithMixedTypes() {
                Frequency frequency = new Frequency();
                frequency.addValue(5);
                frequency.addValue(10L);
                frequency.addValue('a');
                
                double result = frequency.getPct(5);
                assertEquals(0.3333, result, 0.0001);
            }

    @Test
            public void testGetPctIntWithNegativeValue() {
                Frequency frequency = new Frequency();
                frequency.addValue(-5L);
                frequency.addValue(10L);
                
                double result = frequency.getPct(-5L);
                assertEquals(0.5, result, 0.0001);
            }

    @Test
            public void testGetPctIntWithZeroValue() {
                Frequency frequency = new Frequency();
                frequency.addValue(0);
                frequency.addValue(10);
                
                double result = frequency.getPct(0);
                assertEquals(0.5, result, 0.0001);
            }

    @Test
            public void testGetPctIntWithLargeValue() {
                Frequency frequency = new Frequency();
                frequency.addValue(Integer.MAX_VALUE);
                frequency.addValue(10);
                
                double result = frequency.getPct(Integer.MAX_VALUE);
                assertEquals(0.5, result, 0.0001);
            }

    @Test
            public void testGetPctIntWithMinimumValue() {
                Frequency frequency = new Frequency();
                frequency.addValue(Integer.MIN_VALUE);
                frequency.addValue(10);
                
                double result = frequency.getPct(Integer.MIN_VALUE);
                assertEquals(0.5, result, 0.0001);
            }

    @Test
            public void testGetPctLongWithEmptyFrequency() {
                Frequency frequency = new Frequency();
                double result = frequency.getPct(5L);
                assertTrue(Double.isNaN(result));
            }

    @Test
            public void testGetPctLongWithSingleValue() {
                Frequency frequency = new Frequency();
                frequency.addValue(5L);
                double result = frequency.getPct(5L);
                assertEquals(1.0, result, 0.0001);
            }

    @Test
            public void testGetPctLongWithMultipleValues() {
                Frequency frequency = new Frequency();
                frequency.addValue(5L);
                frequency.addValue(10L);
                frequency.addValue(5L);
                double result = frequency.getPct(5L);
                assertEquals(0.6666, result, 0.0001);
            }

    @Test
            public void testGetPctLongWithNonExistingValue() {
                Frequency frequency = new Frequency();
                frequency.addValue(10L);
                frequency.addValue(20L);
                double result = frequency.getPct(5L);
                assertEquals(0.0, result, 0.0001);
            }

    @Test
            public void testGetPctLongWithMixedTypes() {
                Frequency frequency = new Frequency();
                frequency.addValue(5L);
                frequency.addValue(10);
                frequency.addValue(5);
                double result = frequency.getPct(5L);
                assertEquals(0.6666, result, 0.0001);
            }

    @Test
            public void testGetPctLongWithZeroValue() {
                Frequency frequency = new Frequency();
                frequency.addValue(0L);
                frequency.addValue(0L);
                frequency.addValue(1L);
                double result = frequency.getPct(0L);
                assertEquals(0.6666, result, 0.0001);
            }

    @Test
        public void testGetPctLongWithNegativeValue() {
            Frequency frequency = new Frequency();
            frequency.addValue(-5L);
            frequency.addValue(10L);
            double result = frequency.getPct(-5L);
            assertEquals(0.5, result, 0.0001);
        }

    @Test
        public void testGetPctLongWithLargeValue() {
            Frequency frequency = new Frequency();
            frequency.addValue(Long.MAX_VALUE);
            frequency.addValue(Long.MAX_VALUE);
            frequency.addValue(1L);
            double result = frequency.getPct(Long.MAX_VALUE);
            assertEquals(0.6666, result, 0.0001);
        }

    @Test
        public void testGetPctCharWithEmptyFrequency() {
            Frequency frequency = new Frequency();
            char testChar = 'a';
            double result = frequency.getPct(testChar);
            assertTrue(Double.isNaN(result));
        }

    @Test
        public void testGetPctCharWithSingleOccurrence() {
            Frequency frequency = new Frequency();
            char testChar = 'b';
            frequency.addValue(testChar);
            double result = frequency.getPct(testChar);
            assertEquals(1.0, result, 0.0001);
        }

    @Test
        public void testGetPctCharWithMultipleValues() {
            org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
            
            frequency.addValue('a');
            frequency.addValue('b');
            frequency.addValue('b');
            frequency.addValue('c');
            
            double resultA = frequency.getPct('a');
            double resultB = frequency.getPct('b');
            double resultC = frequency.getPct('c');
            double resultD = frequency.getPct('d');
            
            assertEquals(0.25, resultA, 0.0001);
            assertEquals(0.5, resultB, 0.0001);
            assertEquals(0.25, resultC, 0.0001);
            assertEquals(0.0, resultD, 0.0001);
        }

    @Test
        public void testGetPctCharWithNonExistentValue() {
            Frequency frequency = new Frequency();
            frequency.addValue('x');
            frequency.addValue('y');
            double result = frequency.getPct('z');
            assertEquals(0.0, result, 0.0001);
        }

    @Test
        public void testGetPctCharAfterClear() {
            Frequency frequency = new Frequency();
            frequency.addValue('a');
            frequency.addValue('a');
            frequency.clear();
            double result = frequency.getPct('a');
            assertTrue(Double.isNaN(result));
        }

    @Test
        public void testGetPctCharWithMixedTypes() {
            Frequency frequency = new Frequency();
            
            frequency.addValue('a');
            frequency.addValue(1);
            frequency.addValue(2L);
            frequency.addValue('b');
            
            double resultA = frequency.getPct('a');
            double resultB = frequency.getPct('b');
            
            assertEquals(0.25, resultA, 0.0001);
            assertEquals(0.25, resultB, 0.0001);
        }


}
