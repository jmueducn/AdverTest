package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.io.Serializable;
import org.apache.commons.math.exception.MathArithmeticException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.OpenIntToDoubleHashMap;
import org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator;
import org.apache.commons.math.util.FastMath;
 
public class OpenMapRealVectorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                    public void testEbeDivideWithValidVector() {
                                                        double[] values1 = {1.0, 2.0, 3.0};
                                                        double[] values2 = {2.0, 4.0, 6.0};
                                                        OpenMapRealVector vector1 = new OpenMapRealVector(values1);
                                                        OpenMapRealVector vector2 = new OpenMapRealVector(values2);
                                                
                                                        OpenMapRealVector result = vector1.ebeDivide(vector2);
                                                
                                                        assertEquals(3, result.getDimension());
                                                        assertEquals(0.5, result.getEntry(0), 1e-15);
                                                        assertEquals(0.5, result.getEntry(1), 1e-15);
                                                        assertEquals(0.5, result.getEntry(2), 1e-15);
                                                    }

    @Test
                                                    public void testEbeDivideWithSparseVector() {
                                                        double[] values1 = {0.0, 2.0, 0.0, 4.0};
                                                        double[] values2 = {1.0, 2.0, 3.0, 4.0};
                                                        OpenMapRealVector vector1 = new OpenMapRealVector(values1);
                                                        OpenMapRealVector vector2 = new OpenMapRealVector(values2);
                                                
                                                        OpenMapRealVector result = vector1.ebeDivide(vector2);
                                                
                                                        assertEquals(4, result.getDimension());
                                                        assertEquals(0.0, result.getEntry(0), 1e-15);
                                                        assertEquals(1.0, result.getEntry(1), 1e-15);
                                                        assertEquals(0.0, result.getEntry(2), 1e-15);
                                                        assertEquals(1.0, result.getEntry(3), 1e-15);
                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                    public void testEbeDivideWithInvalidDimension() {
                                                        double[] values1 = {1.0, 2.0, 3.0};
                                                        double[] values2 = {1.0, 2.0};
                                                        OpenMapRealVector vector1 = new OpenMapRealVector(values1);
                                                        OpenMapRealVector vector2 = new OpenMapRealVector(values2);
                                                
                                                        vector1.ebeDivide(vector2);
                                                    }

    @Test
                                                    public void testEbeDivideWithZeroValues() {
                                                        double[] values1 = {0.0, 0.0, 5.0};
                                                        double[] values2 = {1.0, 2.0, 5.0};
                                                        OpenMapRealVector vector1 = new OpenMapRealVector(values1);
                                                        OpenMapRealVector vector2 = new OpenMapRealVector(values2);
                                                
                                                        OpenMapRealVector result = vector1.ebeDivide(vector2);
                                                
                                                        assertEquals(3, result.getDimension());
                                                        assertEquals(0.0, result.getEntry(0), 1e-15);
                                                        assertEquals(0.0, result.getEntry(1), 1e-15);
                                                        assertEquals(1.0, result.getEntry(2), 1e-15);
                                                    }

    @Test
                                                    public void testEbeDividePreservesSparsity() {
                                                        double[] values1 = {0.0, 2.0, 0.0, 0.0};
                                                        double[] values2 = {1.0, 2.0, 3.0, 4.0};
                                                        OpenMapRealVector vector1 = new OpenMapRealVector(values1);
                                                        OpenMapRealVector vector2 = new OpenMapRealVector(values2);
                                                
                                                        OpenMapRealVector result = vector1.ebeDivide(vector2);
                                                
                                                        assertEquals(4, result.getDimension());
                                                        assertEquals(0.0, result.getEntry(0), 1e-15);
                                                        assertEquals(1.0, result.getEntry(1), 1e-15);
                                                        assertEquals(0.0, result.getEntry(2), 1e-15);
                                                        assertEquals(0.0, result.getEntry(3), 1e-15);
                                                        // Check sparsity is preserved
                                                        assertTrue(result.getEntry(0) == 0.0);
                                                        assertTrue(result.getEntry(2) == 0.0);
                                                        assertTrue(result.getEntry(3) == 0.0);
                                                    }

    @Test
                                                    public void testEbeDivideWithZeroValues1() {
                                                        double[] values = {1.0, 0.0, 3.0};
                                                        OpenMapRealVector testVector = new OpenMapRealVector(values);
                                                        double[] divisor = {1.0, 1.0, 1.0};
                                                        
                                                        OpenMapRealVector result = testVector.ebeDivide(divisor);
                                                        
                                                        assertEquals(1.0, result.getEntry(0), 0.0001);
                                                        assertEquals(0.0, result.getEntry(1), 0.0001);
                                                        assertEquals(3.0, result.getEntry(2), 0.0001);
                                                    }

    @Test
                                                    public void testEbeDivideWithEmptyVector() {
                                                        OpenMapRealVector emptyVector = new OpenMapRealVector(0);
                                                        double[] emptyDivisor = {};
                                                        OpenMapRealVector result = emptyVector.ebeDivide(emptyDivisor);
                                                        
                                                        assertEquals(0, result.getDimension());
                                                    }

    @Test
                                                    public void testEbeDividePreservesSparsity1() {
                                                        double[] sparseValues = {0.0, 0.0, 3.0, 0.0, 0.0};
                                                        OpenMapRealVector sparseVector = new OpenMapRealVector(sparseValues);
                                                        double[] divisor = {1.0, 1.0, 1.0, 1.0, 1.0};
                                                        
                                                        OpenMapRealVector result = sparseVector.ebeDivide(divisor);
                                                        
                                                        assertEquals(0.0, result.getEntry(0), 0.0001);
                                                        assertEquals(0.0, result.getEntry(1), 0.0001);
                                                        assertEquals(3.0, result.getEntry(2), 0.0001);
                                                        assertEquals(0.0, result.getEntry(3), 0.0001);
                                                        assertEquals(0.0, result.getEntry(4), 0.0001);
                                                    }

    @Test
                                                    public void testEbeDivideWithNegativeValues() {
                                                        double[] values = {-1.0, -2.0, -3.0};
                                                        OpenMapRealVector testVector = new OpenMapRealVector(values);
                                                        double[] divisor = {1.0, -2.0, 3.0};
                                                        
                                                        OpenMapRealVector result = testVector.ebeDivide(divisor);
                                                        
                                                        assertEquals(-1.0, result.getEntry(0), 0.0001);
                                                        assertEquals(1.0, result.getEntry(1), 0.0001);
                                                        assertEquals(-1.0, result.getEntry(2), 0.0001);
                                                    }

    @Test
                                                public void testEbeDivideWithMockVector() {
                                                    double[] values = {1.0, 2.0, 3.0};
                                                    OpenMapRealVector vector = new OpenMapRealVector(values);
                                                    
                                                    RealVector mockVector = mock(RealVector.class);
                                                    when(mockVector.getDimension()).thenReturn(3);
                                                    when(mockVector.getEntry(0)).thenReturn(2.0);
                                                    when(mockVector.getEntry(1)).thenReturn(1.0);
                                                    when(mockVector.getEntry(2)).thenReturn(3.0);
                                                    
                                                    OpenMapRealVector result = vector.ebeDivide(mockVector);
                                                    
                                                    assertEquals(3, result.getDimension());
                                                    assertEquals(0.5, result.getEntry(0), 1e-15);
                                                    assertEquals(2.0, result.getEntry(1), 1e-15);
                                                    assertEquals(1.0, result.getEntry(2), 1e-15);
                                                }

    @Test(expected = IllegalArgumentException.class)
                                                public void testEbeDivideWithMockInvalidDimension() {
                                                    double[] values = {1.0, 2.0, 3.0};
                                                    OpenMapRealVector vector = new OpenMapRealVector(values);
                                                    OpenMapRealVector mockVector = mock(OpenMapRealVector.class);
                                                    
                                                    when(mockVector.getDimension()).thenReturn(2);
                                            
                                                    vector.ebeDivide(mockVector);
                                                }

    @Test
                                                public void testEbeDivideWithValidInput() {
                                                    double[] data = {1.0, 2.0, 3.0, 0.0, 5.0};
                                                    OpenMapRealVector vector = new OpenMapRealVector(data);
                                                    double[] divisor = {1.0, 2.0, 3.0, 4.0, 5.0};
                                                    OpenMapRealVector result = vector.ebeDivide(divisor);
                                                    
                                                    assertEquals(1.0, result.getEntry(0), 0.0001);
                                                    assertEquals(1.0, result.getEntry(1), 0.0001);
                                                    assertEquals(1.0, result.getEntry(2), 0.0001);
                                                    assertEquals(0.0, result.getEntry(3), 0.0001);
                                                    assertEquals(1.0, result.getEntry(4), 0.0001);
                                                }

    @Test
                                                public void testEbeDivideWithValidDimensions() {
                                                    double[] data = {4.0, 6.0, 8.0};
                                                    OpenMapRealVector vector = new OpenMapRealVector(data);
                                                    double[] divisor = {2.0, 3.0, 4.0};
                                                    OpenMapRealVector result = vector.ebeDivide(divisor);
                                                    
                                                    assertEquals(2.0, result.getEntry(0), 0.0001);
                                                    assertEquals(2.0, result.getEntry(1), 0.0001);
                                                    assertEquals(2.0, result.getEntry(2), 0.0001);
                                                }

    @Test
                                                public void testEbeDivideWithDivisionByZero() {
                                                    double[] data = {1.0, 2.0, 3.0, 0.0, 5.0};
                                                    OpenMapRealVector vector = new OpenMapRealVector(data);
                                                    double[] divisor = {1.0, 0.0, 1.0, 1.0, 1.0};
                                                    OpenMapRealVector result = vector.ebeDivide(divisor);
                                                    
                                                    assertEquals(1.0, result.getEntry(0), 0.0001);
                                                    assertTrue(Double.isInfinite(result.getEntry(1)));
                                                    assertEquals(3.0, result.getEntry(2), 0.0001);
                                                    assertEquals(0.0, result.getEntry(3), 0.0001);
                                                    assertEquals(5.0, result.getEntry(4), 0.0001);
                                                }

    @Test
                                                public void testEbeMultiplyWithEmptyVector() {
                                                    OpenMapRealVector vector = new OpenMapRealVector(3);
                                                    OpenMapRealVector mockVector = mock(OpenMapRealVector.class);
                                                    
                                                    when(mockVector.getDimension()).thenReturn(3);
                                                    when(mockVector.getEntry(anyInt())).thenReturn(1.0);
                                            
                                                    OpenMapRealVector result = vector.ebeMultiply(mockVector);
                                                    
                                                    assertEquals(3, result.getDimension());
                                                    assertEquals(0.0, result.getEntry(0), 0.0);
                                                    assertEquals(0.0, result.getEntry(1), 0.0);
                                                    assertEquals(0.0, result.getEntry(2), 0.0);
                                                }

    @Test
                                                public void testEbeMultiplyWithNonEmptyVector() {
                                                    double[] values = {1.0, 2.0, 3.0};
                                                    OpenMapRealVector vector = new OpenMapRealVector(values);
                                                    
                                                    OpenMapRealVector mockVector = mock(OpenMapRealVector.class);
                                                    when(mockVector.getDimension()).thenReturn(3);
                                                    when(mockVector.getEntry(0)).thenReturn(2.0);
                                                    when(mockVector.getEntry(1)).thenReturn(3.0);
                                                    when(mockVector.getEntry(2)).thenReturn(4.0);
                                                
                                                    OpenMapRealVector result = vector.ebeMultiply(mockVector);
                                                    
                                                    assertEquals(3, result.getDimension());
                                                    assertEquals(2.0, result.getEntry(0), 0.0);
                                                    assertEquals(6.0, result.getEntry(1), 0.0);
                                                    assertEquals(12.0, result.getEntry(2), 0.0);
                                                }

    @Test
                                                public void testEbeMultiplyWithSparseVector() {
                                                    OpenMapRealVector vector = new OpenMapRealVector(5);
                                                    vector.setEntry(1, 2.0);
                                                    vector.setEntry(3, 4.0);
                                                    
                                                    RealVector mockVector = mock(RealVector.class);
                                                    when(mockVector.getDimension()).thenReturn(5);
                                                    when(mockVector.getEntry(0)).thenReturn(1.0);
                                                    when(mockVector.getEntry(1)).thenReturn(3.0);
                                                    when(mockVector.getEntry(2)).thenReturn(1.0);
                                                    when(mockVector.getEntry(3)).thenReturn(5.0);
                                                    when(mockVector.getEntry(4)).thenReturn(1.0);
                                                
                                                    OpenMapRealVector result = vector.ebeMultiply(mockVector);
                                                
                                                    assertEquals(5, result.getDimension());
                                                    assertEquals(0.0, result.getEntry(0), 0.0);
                                                    assertEquals(6.0, result.getEntry(1), 0.0);
                                                    assertEquals(0.0, result.getEntry(2), 0.0);
                                                    assertEquals(20.0, result.getEntry(3), 0.0);
                                                    assertEquals(0.0, result.getEntry(4), 0.0);
                                                }

    @Test(expected = IllegalArgumentException.class)
                                                public void testEbeMultiplyWithDifferentDimensions() {
                                                    OpenMapRealVector vector = new OpenMapRealVector(3);
                                                    OpenMapRealVector mockVector = mock(OpenMapRealVector.class);
                                                    when(mockVector.getDimension()).thenReturn(4);
                                                    
                                                    vector.ebeMultiply(mockVector);
                                                }

    @Test
                                                public void testEbeMultiplyWithZeroValues() {
                                                    double[] values = {0.0, 1.0, 0.0};
                                                    OpenMapRealVector vector = new OpenMapRealVector(values);
                                                    
                                                    OpenMapRealVector mockVector = mock(OpenMapRealVector.class);
                                                    when(mockVector.getDimension()).thenReturn(3);
                                                    when(mockVector.getEntry(0)).thenReturn(5.0);
                                                    when(mockVector.getEntry(1)).thenReturn(0.0);
                                                    when(mockVector.getEntry(2)).thenReturn(5.0);
                                                
                                                    OpenMapRealVector result = vector.ebeMultiply(mockVector);
                                                    
                                                    assertEquals(3, result.getDimension());
                                                    assertEquals(0.0, result.getEntry(0), 0.0);
                                                    assertEquals(0.0, result.getEntry(1), 0.0);
                                                    assertEquals(0.0, result.getEntry(2), 0.0);
                                                }

    @Test
                                                public void testEbeMultiplyWithValidInput() {
                                                    double[] input = {1.0, 2.0, 3.0, 4.0, 5.0};
                                                    
                                                    OpenMapRealVector vector = new OpenMapRealVector(input.length);
                                                    OpenIntToDoubleHashMap entries = mock(OpenIntToDoubleHashMap.class);
                                                    OpenIntToDoubleHashMap.Iterator mockIterator = mock(OpenIntToDoubleHashMap.Iterator.class);
                                                    
                                                    when(entries.iterator()).thenReturn(mockIterator);
                                                    when(mockIterator.hasNext()).thenReturn(true, true, false);
                                                    when(mockIterator.key()).thenReturn(1, 3);
                                                    when(mockIterator.value()).thenReturn(2.0, 4.0);
                                                    
                                                    // Use reflection to set the private entries field
                                                    try {
                                                        java.lang.reflect.Field entriesField = OpenMapRealVector.class.getDeclaredField("entries");
                                                        entriesField.setAccessible(true);
                                                        entriesField.set(vector, entries);
                                                    } catch (Exception e) {
                                                        fail("Failed to set entries field via reflection");
                                                    }
                                                    
                                                    OpenMapRealVector result = vector.ebeMultiply(input);
                                                    
                                                    assertNotNull(result);
                                                    verify(mockIterator, times(2)).advance();
                                                    // Verify the entries were multiplied correctly
                                                    assertEquals(2.0 * 2.0, result.getEntry(1), 0.0001);
                                                    assertEquals(4.0 * 4.0, result.getEntry(3), 0.0001);
                                                }

    @Test
                                                public void testEbeMultiplyWithEmptyVector1() {
                                                    double[] input = new double[5];
                                                    OpenIntToDoubleHashMap entries = mock(OpenIntToDoubleHashMap.class);
                                                    OpenIntToDoubleHashMap.Iterator mockIterator = mock(OpenIntToDoubleHashMap.Iterator.class);
                                                    OpenMapRealVector vector = new OpenMapRealVector(5);
                                                    
                                                    when(entries.iterator()).thenReturn(mockIterator);
                                                    when(mockIterator.hasNext()).thenReturn(false);
                                                    
                                                    OpenMapRealVector result = vector.ebeMultiply(input);
                                                    
                                                    assertNotNull(result);
                                                    verify(mockIterator, never()).advance();
                                                }

    @Test(expected = IllegalArgumentException.class)
                                                public void testEbeMultiplyWithInvalidDimensions() {
                                                    OpenMapRealVector vector = new OpenMapRealVector(new double[]{1.0, 2.0});
                                                    double[] input = {1.0, 2.0, 3.0}; // Wrong dimension
                                                    vector.ebeMultiply(input);
                                                }

    @Test
                                                public void testEbeMultiplyWithZeroValues1() {
                                                    double[] input = {0.0, 0.0, 0.0, 0.0, 0.0};
                                                    
                                                    OpenMapRealVector vector = new OpenMapRealVector(input.length);
                                                    OpenIntToDoubleHashMap entries = new OpenIntToDoubleHashMap();
                                                    
                                                    OpenIntToDoubleHashMap.Iterator mockIterator = mock(OpenIntToDoubleHashMap.Iterator.class);
                                                    when(entries.iterator()).thenReturn(mockIterator);
                                                    when(mockIterator.hasNext()).thenReturn(true, true, false);
                                                    when(mockIterator.key()).thenReturn(0, 2);
                                                    when(mockIterator.value()).thenReturn(1.5, 3.0);
                                                    
                                                    OpenMapRealVector result = vector.ebeMultiply(input);
                                                    
                                                    assertNotNull(result);
                                                    assertEquals(0.0, result.getEntry(0), 0.0001);
                                                    assertEquals(0.0, result.getEntry(2), 0.0001);
                                                }

    @Test
                                                public void testEbeMultiplyWithNegativeValues() {
                                                    double[] input = {-1.0, -2.0, -3.0, -4.0, -5.0};
                                                    
                                                    // Create a real vector with some values
                                                    OpenMapRealVector vector = new OpenMapRealVector(5);
                                                    vector.setEntry(1, 2.0);
                                                    vector.setEntry(4, -3.0);
                                                    
                                                    // Mock the iterator
                                                    OpenIntToDoubleHashMap.Iterator mockIterator = mock(OpenIntToDoubleHashMap.Iterator.class);
                                                    OpenIntToDoubleHashMap entries = mock(OpenIntToDoubleHashMap.class);
                                                    when(entries.iterator()).thenReturn(mockIterator);
                                                    when(mockIterator.hasNext()).thenReturn(true, true, false);
                                                    when(mockIterator.key()).thenReturn(1, 4);
                                                    when(mockIterator.value()).thenReturn(2.0, -3.0);
                                                    
                                                    // Use reflection to set the private entries field
                                                    try {
                                                        java.lang.reflect.Field entriesField = OpenMapRealVector.class.getDeclaredField("entries");
                                                        entriesField.setAccessible(true);
                                                        entriesField.set(vector, entries);
                                                    } catch (Exception e) {
                                                        fail("Failed to set entries field via reflection");
                                                    }
                                                    
                                                    OpenMapRealVector result = vector.ebeMultiply(input);
                                                    
                                                    assertNotNull(result);
                                                    assertEquals(2.0 * -2.0, result.getEntry(1), 0.0001);
                                                    assertEquals(-3.0 * -5.0, result.getEntry(4), 0.0001);
                                                }

    @Test
        public void testEbeMultiplyPreservesSparsity1() throws Exception {
            OpenMapRealVector vector = new OpenMapRealVector(4);
            vector.setEntry(1, 2.0);
            vector.setEntry(3, 3.0);
            
            RealVector mockVector = mock(RealVector.class);
            when(mockVector.getDimension()).thenReturn(4);
            when(mockVector.getEntry(0)).thenReturn(1.0);
            when(mockVector.getEntry(1)).thenReturn(0.0);
            when(mockVector.getEntry(2)).thenReturn(1.0);
            when(mockVector.getEntry(3)).thenReturn(2.0);
        
            OpenMapRealVector result = vector.ebeMultiply(mockVector);
            
            assertEquals(4, result.getDimension());
            assertEquals(0.0, result.getEntry(0), 0.0);
            assertEquals(0.0, result.getEntry(1), 0.0);
            assertEquals(0.0, result.getEntry(2), 0.0);
            assertEquals(6.0, result.getEntry(3), 0.0);
            
            Method getEntriesMethod = OpenMapRealVector.class.getDeclaredMethod("getEntries");
            getEntriesMethod.setAccessible(true);
            @SuppressWarnings("unchecked")
            OpenIntToDoubleHashMap entries = (OpenIntToDoubleHashMap) getEntriesMethod.invoke(result);
            assertEquals(1, entries.size());
        }

    @Test
        public void testEbeMultiplyPreservesSparsity() throws Exception {
            OpenMapRealVector vector = new OpenMapRealVector(4);
            vector.setEntry(1, 2.0);
            vector.setEntry(3, 3.0);
            
            RealVector mockVector = mock(RealVector.class);
            when(mockVector.getDimension()).thenReturn(4);
            when(mockVector.getEntry(0)).thenReturn(1.0);
            when(mockVector.getEntry(1)).thenReturn(0.0);
            when(mockVector.getEntry(2)).thenReturn(1.0);
            when(mockVector.getEntry(3)).thenReturn(2.0);
        
            OpenMapRealVector result = vector.ebeMultiply(mockVector);
            
            assertEquals(4, result.getDimension());
            assertEquals(0.0, result.getEntry(0), 0.0);
            assertEquals(0.0, result.getEntry(1), 0.0);
            assertEquals(0.0, result.getEntry(2), 0.0);
            assertEquals(6.0, result.getEntry(3), 0.0);
            
            Method getEntriesMethod = OpenMapRealVector.class.getDeclaredMethod("getEntries");
            getEntriesMethod.setAccessible(true);
            Object entries = getEntriesMethod.invoke(result);
            assertNotNull(entries);
        }


}
