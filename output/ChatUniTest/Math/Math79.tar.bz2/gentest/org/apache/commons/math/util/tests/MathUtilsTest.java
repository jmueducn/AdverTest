package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Arrays;
import org.apache.commons.math.MathRuntimeException;
 
public class MathUtilsTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testDistanceSamePoint() {
            double[] p1 = {1.0, 2.0, 3.0};
            double[] p2 = {1.0, 2.0, 3.0};
            double result = MathUtils.distance(p1, p2);
            assertEquals(0.0, result, 0.0001);
        }

    @Test
        public void testDistance1D() {
            double[] p1 = {0.0};
            double[] p2 = {3.0};
            double result = MathUtils.distance(p1, p2);
            assertEquals(3.0, result, 0.0001);
        }

    @Test
        public void testDistance2D() {
            double[] p1 = {0.0, 0.0};
            double[] p2 = {3.0, 4.0};
            double result = MathUtils.distance(p1, p2);
            assertEquals(5.0, result, 0.0001);
        }

    @Test
        public void testDistance3D() {
            double[] p1 = {1.0, 2.0, 3.0};
            double[] p2 = {4.0, 5.0, 6.0};
            double result = MathUtils.distance(p1, p2);
            assertEquals(Math.sqrt(27), result, 0.0001);
        }

    @Test
        public void testDistanceNegativeValues() {
            double[] p1 = {-1.0, -2.0};
            double[] p2 = {2.0, 3.0};
            double result = MathUtils.distance(p1, p2);
            assertEquals(Math.sqrt(9 + 25), result, 0.0001);
        }

    @Test
        public void testDistanceZeroLengthArrays() {
            double[] p1 = {};
            double[] p2 = {};
            double result = MathUtils.distance(p1, p2);
            assertEquals(0.0, result, 0.0001);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testDistanceDifferentLengthArrays() {
            double[] p1 = {1.0, 2.0};
            double[] p2 = {1.0};
            MathUtils.distance(p1, p2);
        }

    @Test(expected = NullPointerException.class)
        public void testDistanceNullFirstArray() {
            double[] p2 = {1.0, 2.0};
            MathUtils.distance(null, p2);
        }

    @Test(expected = NullPointerException.class)
        public void testDistanceNullSecondArray() {
            double[] p1 = {1.0, 2.0};
            MathUtils.distance(p1, null);
        }

    @Test
        public void testDistanceWithLargeNumbers() {
            double[] p1 = {1.0E300, 2.0E300};
            double[] p2 = {1.0E300, 2.0E300};
            double result = MathUtils.distance(p1, p2);
            assertEquals(0.0, result, 0.0001);
        }

    @Test
        public void testDistanceWithVerySmallNumbers() {
            double[] p1 = {1.0E-300, 2.0E-300};
            double[] p2 = {1.0E-300, 2.0E-300};
            double result = MathUtils.distance(p1, p2);
            assertEquals(0.0, result, 0.0001);
        }

    @Test
        public void testDistanceSamePoint1() {
            int[] p1 = {0, 0};
            int[] p2 = {0, 0};
            double result = MathUtils.distance(p1, p2);
            assertEquals(0.0, result, 0.0001);
        }

    @Test
        public void testDistance1D1() {
            int[] p1 = {0};
            int[] p2 = {3};
            double result = MathUtils.distance(p1, p2);
            assertEquals(3.0, result, 0.0001);
        }

    @Test
        public void testDistance2D1() {
            int[] p1 = {0, 0};
            int[] p2 = {3, 4};
            double result = MathUtils.distance(p1, p2);
            assertEquals(5.0, result, 0.0001);
        }

    @Test
        public void testDistance3D1() {
            int[] p1 = {1, 2, 3};
            int[] p2 = {4, 5, 6};
            double result = MathUtils.distance(p1, p2);
            assertEquals(Math.sqrt(27), result, 0.0001);
        }

    @Test
        public void testDistanceNegativeValues1() {
            int[] p1 = {-1, -2};
            int[] p2 = {2, 3};
            double result = MathUtils.distance(p1, p2);
            assertEquals(Math.sqrt(9 + 25), result, 0.0001);
        }

    @Test
        public void testDistanceLargeValues() {
            int[] p1 = {Integer.MAX_VALUE, Integer.MAX_VALUE};
            int[] p2 = {Integer.MIN_VALUE, Integer.MIN_VALUE};
            double expected = Math.sqrt(2 * Math.pow(2.0 * Integer.MAX_VALUE + 1, 2));
            double result = MathUtils.distance(p1, p2);
            assertEquals(expected, result, 0.0001);
        }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
        public void testDistanceDifferentLengthArrays1() {
            int[] p1 = {1, 2, 3};
            int[] p2 = {4, 5};
            MathUtils.distance(p1, p2);
        }

    @Test(expected = NullPointerException.class)
        public void testDistanceNullFirstArray1() {
            int[] p1 = null;
            int[] p2 = {1, 2};
            MathUtils.distance(p1, p2);
        }

    @Test(expected = NullPointerException.class)
        public void testDistanceNullSecondArray1() {
            int[] p1 = {1, 2};
            int[] p2 = null;
            MathUtils.distance(p1, p2);
        }

    @Test
        public void testDistanceEmptyArrays() {
            int[] p1 = {};
            int[] p2 = {};
            double result = MathUtils.distance(p1, p2);
            assertEquals(0.0, result, 0.0001);
        }

    @Test
        public void testDistanceHighDimensional() {
            int[] p1 = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
            int[] p2 = {11, 12, 13, 14, 15, 16, 17, 18, 19, 20};
            double sum = 0;
            for (int i = 0; i < 10; i++) {
                sum += Math.pow(10, 2);
            }
            double expected = Math.sqrt(sum);
            double result = MathUtils.distance(p1, p2);
            assertEquals(expected, result, 0.0001);
        }

}
