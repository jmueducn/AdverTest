package gentest.org.apache.commons.math3.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.distribution.*;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.special.Beta;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;
 
public class FDistributionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
            public void testGetDenominatorDegreesOfFreedom() {
                double numeratorDF = 5.0;
                double denominatorDF = 10.0;
                FDistribution fDistribution = new FDistribution(numeratorDF, denominatorDF);
                
                assertEquals(denominatorDF, fDistribution.getDenominatorDegreesOfFreedom(), 0.0);
            }

    @Test
            public void testGetDenominatorDegreesOfFreedomWithDifferentValues() {
                double numeratorDF = 3.0;
                double denominatorDF = 7.5;
                FDistribution fDistribution = new FDistribution(numeratorDF, denominatorDF);
                
                assertEquals(denominatorDF, fDistribution.getDenominatorDegreesOfFreedom(), 0.0);
            }

    @Test
            public void testGetDenominatorDegreesOfFreedomWithRandomGenerator() {
                double numeratorDF = 2.0;
                double denominatorDF = 8.0;
                FDistribution fDistribution = new FDistribution(new Well19937c(), numeratorDF, denominatorDF, 1e-9);
                
                assertEquals(denominatorDF, fDistribution.getDenominatorDegreesOfFreedom(), 0.0);
            }

    @Test(expected = NotStrictlyPositiveException.class)
            public void testConstructorThrowsForZeroDenominatorDF() {
                new FDistribution(5.0, 0.0);
            }

    @Test(expected = NotStrictlyPositiveException.class)
            public void testConstructorThrowsForNegativeDenominatorDF() {
                new FDistribution(5.0, -1.0);
            }

    @Test
            public void testIsSupportLowerBoundInclusive() {
                FDistribution fDistribution = new FDistribution(2.0, 5.0);
                assertFalse(fDistribution.isSupportLowerBoundInclusive());
            }

    @Test
            public void testIsSupportLowerBoundInclusiveWithDifferentParameters() {
                FDistribution fDistribution = new FDistribution(1.0, 1.0);
                assertFalse(fDistribution.isSupportLowerBoundInclusive());
            }

    @Test
            public void testIsSupportLowerBoundInclusiveWithLargeParameters() {
                FDistribution fDistribution = new FDistribution(100.0, 100.0);
                assertFalse(fDistribution.isSupportLowerBoundInclusive());
            }

    @Test
            public void testIsSupportLowerBoundInclusiveWithSmallParameters() {
                FDistribution fDistribution = new FDistribution(0.5, 0.5);
                assertFalse(fDistribution.isSupportLowerBoundInclusive());
            }

    @Test
        public void testGetSolverAbsoluteAccuracy() throws Exception {
            // Create FDistribution with specific accuracy
            double expectedAccuracy = 1e-6;
            FDistribution distribution = new FDistribution(2.0, 5.0, expectedAccuracy);
            
            // Use reflection to access protected method
            java.lang.reflect.Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
            method.setAccessible(true);
            double actualAccuracy = (Double) method.invoke(distribution);
            
            assertEquals(expectedAccuracy, actualAccuracy, 0.0);
        }

    @Test
        public void testGetSolverAbsoluteAccuracyWithDefaultConstructor() throws Exception {
            // Create FDistribution with default accuracy
            FDistribution distribution = new FDistribution(2.0, 5.0);
            
            // Use reflection to access protected method
            java.lang.reflect.Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
            method.setAccessible(true);
            double actualAccuracy = (Double) method.invoke(distribution);
            
            assertEquals(FDistribution.DEFAULT_INVERSE_ABSOLUTE_ACCURACY, actualAccuracy, 0.0);
        }

    @Test
        public void testGetSolverAbsoluteAccuracyWithRandomGeneratorConstructor() throws Exception {
            // Create FDistribution with specific accuracy using random generator constructor
            double expectedAccuracy = 1e-7;
            FDistribution distribution = new FDistribution(new Well19937c(), 3.0, 6.0, expectedAccuracy);
            
            // Use reflection to access protected method
            Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
            method.setAccessible(true);
            double actualAccuracy = (Double) method.invoke(distribution);
            
            assertEquals(expectedAccuracy, actualAccuracy, 0.0);
        }

    @Test
        public void testGetSolverAbsoluteAccuracyAfterFieldModification() throws Exception {
            // Create FDistribution
            FDistribution distribution = new FDistribution(4.0, 7.0, 1e-5);
            
            // Modify the field using reflection
            Field field = FDistribution.class.getDeclaredField("solverAbsoluteAccuracy");
            field.setAccessible(true);
            double newAccuracy = 1e-8;
            field.set(distribution, newAccuracy);
            
            // Get the protected method using reflection
            Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
            method.setAccessible(true);
            
            // Test the method
            double actualAccuracy = (double) method.invoke(distribution);
            assertEquals(newAccuracy, actualAccuracy, 0.0);
        }


}
