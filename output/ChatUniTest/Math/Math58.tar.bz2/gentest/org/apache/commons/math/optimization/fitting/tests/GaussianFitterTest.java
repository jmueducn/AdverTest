package gentest.org.apache.commons.math.optimization.fitting.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.optimization.fitting.*;
import java.util.Arrays;
import java.util.Comparator;
import org.apache.commons.math.analysis.function.Gaussian;
import org.apache.commons.math.analysis.ParametricUnivariateRealFunction;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.NumberIsTooSmallException;
import org.apache.commons.math.exception.OutOfRangeException;
import org.apache.commons.math.exception.ZeroException;
import org.apache.commons.math.exception.NotStrictlyPositiveException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer;
import org.apache.commons.math.optimization.fitting.CurveFitter;
import org.apache.commons.math.optimization.fitting.WeightedObservedPoint;
 
public class GaussianFitterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                        public void testFitWithNoObservations() {
                                                                                                                                            DifferentiableMultivariateVectorialOptimizer optimizer = mock(DifferentiableMultivariateVectorialOptimizer.class);
                                                                                                                                            GaussianFitter fitter = new GaussianFitter(optimizer);
                                                                                                                                            
                                                                                                                                            try {
                                                                                                                                                fitter.fit();
                                                                                                                                                fail("Expected NumberIsTooSmallException");
                                                                                                                                            } catch (NumberIsTooSmallException e) {
                                                                                                                                                assertEquals(0, e.getArgument().intValue());
                                                                                                                                                assertEquals(3, e.getMin().intValue());
                                                                                                                                                assertTrue(e.getBoundIsAllowed());
                                                                                                                                            }
                                                                                                                                        }

    @Test
                                                                                                                                        public void testFitWithTooFewObservations() {
                                                                                                                                            WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                                                                                                                                new WeightedObservedPoint(1.0, 1.0, 1.0),
                                                                                                                                                new WeightedObservedPoint(1.0, 2.0, 1.0),
                                                                                                                                                new WeightedObservedPoint(1.0, 3.0, 1.0)
                                                                                                                                            };
                                                                                                                                            WeightedObservedPoint[] fewPoints = Arrays.copyOf(observations, 2);
                                                                                                                                            GaussianFitter.ParameterGuesser guesser = new GaussianFitter.ParameterGuesser(fewPoints);
                                                                                                                                            try {
                                                                                                                                                guesser.guess();
                                                                                                                                                fail("Expected NumberIsTooSmallException");
                                                                                                                                            } catch (NumberIsTooSmallException e) {
                                                                                                                                                assertEquals(2, e.getArgument().intValue());
                                                                                                                                                assertEquals(3, e.getMin().intValue());
                                                                                                                                                assertTrue(e.getBoundIsAllowed());
                                                                                                                                            }
                                                                                                                                        }

    @Test
                                                                                                                                        public void testParameterGuesserBasicGuess() throws Exception {
                                                                                                                                            // Create test observations
                                                                                                                                            WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                                                                                                                                new WeightedObservedPoint(1.0, 1.0, 1.0),
                                                                                                                                                new WeightedObservedPoint(1.0, 2.0, 2.0),
                                                                                                                                                new WeightedObservedPoint(1.0, 3.0, 9.0),
                                                                                                                                                new WeightedObservedPoint(1.0, 4.0, 4.0),
                                                                                                                                                new WeightedObservedPoint(1.0, 5.0, 1.0)
                                                                                                                                            };
                                                                                                                                            
                                                                                                                                            GaussianFitter.ParameterGuesser guesser = new GaussianFitter.ParameterGuesser(observations);
                                                                                                                                            
                                                                                                                                            // Use reflection to test private method
                                                                                                                                            Method basicGuessMethod = GaussianFitter.ParameterGuesser.class
                                                                                                                                                .getDeclaredMethod("basicGuess", WeightedObservedPoint[].class);
                                                                                                                                            basicGuessMethod.setAccessible(true);
                                                                                                                                            
                                                                                                                                            double[] result = (double[]) basicGuessMethod.invoke(guesser, (Object) observations);
                                                                                                                                            assertNotNull(result);
                                                                                                                                            assertEquals(3, result.length);
                                                                                                                                            assertEquals(9.0, result[0], 0.001);  // max Y value
                                                                                                                                            assertEquals(3.0, result[1], 0.001);  // X at max Y
                                                                                                                                        }

    @Test
                                                                                                                                        public void testFindMaxY() throws Exception {
                                                                                                                                            // Create test observations
                                                                                                                                            WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                                                                                                                                new WeightedObservedPoint(1.0, 1.0, 1.0),
                                                                                                                                                new WeightedObservedPoint(1.0, 2.0, 4.0),
                                                                                                                                                new WeightedObservedPoint(1.0, 3.0, 9.0),
                                                                                                                                                new WeightedObservedPoint(1.0, 4.0, 4.0),
                                                                                                                                                new WeightedObservedPoint(1.0, 5.0, 1.0)
                                                                                                                                            };
                                                                                                                                            
                                                                                                                                            GaussianFitter.ParameterGuesser guesser = new GaussianFitter.ParameterGuesser(observations);
                                                                                                                                            
                                                                                                                                            // Use reflection to test private method
                                                                                                                                            Method findMaxYMethod = GaussianFitter.ParameterGuesser.class
                                                                                                                                                .getDeclaredMethod("findMaxY", WeightedObservedPoint[].class);
                                                                                                                                            findMaxYMethod.setAccessible(true);
                                                                                                                                            
                                                                                                                                            int result = (int) findMaxYMethod.invoke(guesser, (Object) observations);
                                                                                                                                            assertEquals(2, result);  // index of point with Y=9.0
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIsBetween() throws Exception {
                                                                                                                                            // Create sample observations
                                                                                                                                            WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                                                                                                                                new WeightedObservedPoint(1.0, 1.0, 1.0),
                                                                                                                                                new WeightedObservedPoint(2.0, 2.0, 1.0),
                                                                                                                                                new WeightedObservedPoint(3.0, 3.0, 1.0)
                                                                                                                                            };
                                                                                                                                            
                                                                                                                                            GaussianFitter.ParameterGuesser guesser = new GaussianFitter.ParameterGuesser(observations);
                                                                                                                                            
                                                                                                                                            // Use reflection to test private method
                                                                                                                                            Method isBetweenMethod = GaussianFitter.ParameterGuesser.class
                                                                                                                                                .getDeclaredMethod("isBetween", double.class, double.class, double.class);
                                                                                                                                            isBetweenMethod.setAccessible(true);
                                                                                                                                            
                                                                                                                                            assertTrue((boolean) isBetweenMethod.invoke(guesser, 2.0, 1.0, 3.0));
                                                                                                                                            assertTrue((boolean) isBetweenMethod.invoke(guesser, 2.0, 3.0, 1.0));
                                                                                                                                            assertFalse((boolean) isBetweenMethod.invoke(guesser, 0.0, 1.0, 3.0));
                                                                                                                                            assertFalse((boolean) isBetweenMethod.invoke(guesser, 4.0, 1.0, 3.0));
                                                                                                                                        }

    @Test
                                                                                                                                public void testFitWithObservations() throws Exception {
                                                                                                                                    // Create test data
                                                                                                                                    List<WeightedObservedPoint> observations = new ArrayList<WeightedObservedPoint>();
                                                                                                                                    observations.add(new WeightedObservedPoint(1.0, 1.0, 1.0));
                                                                                                                                    observations.add(new WeightedObservedPoint(1.0, 2.0, 2.0));
                                                                                                                                    observations.add(new WeightedObservedPoint(1.0, 3.0, 3.0));
                                                                                                                                    
                                                                                                                                    // Create fitter instance with null optimizer (as in original constructor)
                                                                                                                                    GaussianFitter fitter = new GaussianFitter(null);
                                                                                                                                    
                                                                                                                                    // Use reflection to set observations since getObservations() is protected
                                                                                                                                    Method addObservedPointMethod = GaussianFitter.class.getSuperclass()
                                                                                                                                        .getDeclaredMethod("addObservedPoint", double.class, double.class, double.class);
                                                                                                                                    addObservedPointMethod.setAccessible(true);
                                                                                                                                    
                                                                                                                                    for (WeightedObservedPoint point : observations) {
                                                                                                                                        addObservedPointMethod.invoke(fitter, point.getWeight(), point.getX(), point.getY());
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    double[] result = fitter.fit();
                                                                                                                                    assertNotNull(result);
                                                                                                                                    assertEquals(3, result.length);
                                                                                                                                }

    @Test
                                                            public void testFitWithNullObservations() {
                                                                try {
                                                                    WeightedObservedPoint[] nullObservations = null;
                                                                    GaussianFitter.ParameterGuesser guesser = new GaussianFitter.ParameterGuesser(nullObservations);
                                                                    guesser.guess();
                                                                    fail("Expected NullArgumentException");
                                                                } catch (NullArgumentException e) {
                                                                }
                                                            }

    @Test
                                                    public void testFitFunctionValueHandlesException() throws Exception {
                                                        // Define required variables
                                                        DifferentiableMultivariateVectorialOptimizer optimizer = mock(DifferentiableMultivariateVectorialOptimizer.class);
                                                        double[] initialGuess = new double[]{1.0, 2.0, 3.0};
                                                        
                                                        // Create a mock Gaussian.Parametric that throws exception
                                                        ParametricUnivariateRealFunction mockGaussian = mock(ParametricUnivariateRealFunction.class);
                                                        when(mockGaussian.value(anyDouble(), any(double[].class)))
                                                            .thenThrow(new NotStrictlyPositiveException(0.0));
                                                        
                                                        // Use reflection to test the anonymous function
                                                        Method fitMethod = GaussianFitter.class.getDeclaredMethod("fit", double[].class);
                                                        fitMethod.setAccessible(true);
                                                        
                                                        // Create a test instance with our mock Gaussian
                                                        GaussianFitter testFitter = new GaussianFitter(optimizer) {
                                                            @Override
                                                            public double[] fit(ParametricUnivariateRealFunction f, double[] initialGuess) {
                                                                // Test the function's value method
                                                                double result = f.value(1.0, initialGuess);
                                                                assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                                                                return new double[0];
                                                            }
                                                        };
                                                        
                                                        // Replace the Gaussian.Parametric in the anonymous class with our mock
                                                        GaussianFitter spyFitter = spy(testFitter);
                                                        
                                                        fitMethod.invoke(spyFitter, initialGuess);
                                                    }

    @Test
                                                    public void testFitFunctionGradientHandlesException() throws Exception {
                                                        // Create mock optimizer
                                                        DifferentiableMultivariateVectorialOptimizer optimizer = mock(DifferentiableMultivariateVectorialOptimizer.class);
                                                        
                                                        class TestGaussianFitter extends GaussianFitter {
                                                            public TestGaussianFitter(DifferentiableMultivariateVectorialOptimizer optimizer) {
                                                                super(optimizer);
                                                            }
                                                            
                                                            @Override
                                                            public double[] fit(ParametricUnivariateRealFunction f, double[] initialGuess) {
                                                                double[] result = f.gradient(1.0, initialGuess);
                                                                assertEquals(3, result.length);
                                                                assertEquals(Double.POSITIVE_INFINITY, result[0], 0.0);
                                                                assertEquals(Double.POSITIVE_INFINITY, result[1], 0.0);
                                                                assertEquals(Double.POSITIVE_INFINITY, result[2], 0.0);
                                                                return new double[0];
                                                            }
                                                        }
                                                        
                                                        double[] initialGuess = {1.0, 2.0, 3.0};
                                                        
                                                        // Create a mock Gaussian.Parametric that throws exception
                                                        ParametricUnivariateRealFunction mockGaussian = mock(ParametricUnivariateRealFunction.class);
                                                        when(mockGaussian.gradient(anyDouble(), any(double[].class)))
                                                            .thenThrow(new NotStrictlyPositiveException(0.0));
                                                    
                                                        // Use reflection to test the anonymous function
                                                        Method fitMethod = GaussianFitter.class.getDeclaredMethod("fit", double[].class);
                                                        fitMethod.setAccessible(true);
                                                        
                                                        // Create a test instance with our mock Gaussian
                                                        TestGaussianFitter testFitter = new TestGaussianFitter(optimizer);
                                                        
                                                        // Replace the Gaussian.Parametric in the anonymous class with our mock
                                                        TestGaussianFitter spyFitter = spy(testFitter);
                                                        when(spyFitter.fit(any(ParametricUnivariateRealFunction.class), any(double[].class)))
                                                            .thenCallRealMethod();
                                                        
                                                        fitMethod.invoke(spyFitter, initialGuess);
                                                    }

    @Test
                                                    public void testFitWithInitialGuess() throws Exception {
                                                        // Create the fitter instance with proper constructor
                                                        GaussianFitter fitter = new GaussianFitter(null); // Assuming constructor takes a ParametricRealFunction
                                                        
                                                        // Mock the parent class's fit method
                                                        GaussianFitter spyFitter = spy(fitter);
                                                        when(spyFitter.fit(any())).thenReturn(new double[0]);
                                                        
                                                        // Test with initial guess
                                                        double[] initialGuess = new double[0];
                                                        double[] result = spyFitter.fit(initialGuess);
                                                        
                                                        assertNotNull(result);
                                                        assertEquals(0, result.length);
                                                    }

    @Test
                            public void testFitFunctionValueWithValidParameters() throws Exception {
                                // Define test parameters
                                double[] initialGuess = new double[]{1.0, 2.0, 3.0};
                                double expectedValue = 42.0;
                                
                                // Create mock Gaussian.Parametric
                                ParametricUnivariateRealFunction mockGaussian = mock(ParametricUnivariateRealFunction.class);
                                when(mockGaussian.value(anyDouble(), any(double[].class)))
                                    .thenReturn(expectedValue);
                                
                                // Create mock optimizer
                                DifferentiableMultivariateVectorialOptimizer mockOptimizer = mock(DifferentiableMultivariateVectorialOptimizer.class);
                                
                                // Use reflection to test the anonymous function
                                Method fitMethod = GaussianFitter.class.getDeclaredMethod("fit", double[].class);
                                fitMethod.setAccessible(true);
                                
                                // Create a test instance with our mock Gaussian
                                GaussianFitter testFitter = new GaussianFitter(mockOptimizer) {
                                    @Override
                                    public double[] fit(ParametricUnivariateRealFunction f, double[] initialGuess) {
                                        // Test the function's value method
                                        double result = f.value(1.0, initialGuess);
                                        assertEquals(expectedValue, result, 0.0);
                                        return new double[0];
                                    }
                                };
                                
                                // Replace the Gaussian.Parametric in the anonymous class with our mock
                                GaussianFitter spyFitter = spy(testFitter);
                                Method getGaussianFunctionMethod = GaussianFitter.class.getDeclaredMethod("getGaussianFunction");
                                getGaussianFunctionMethod.setAccessible(true);
                                when(getGaussianFunctionMethod.invoke(spyFitter)).thenReturn(mockGaussian);
                                
                                fitMethod.invoke(spyFitter, initialGuess);
                            }

    @Test
        public void testFitFunctionGradientWithValidParameters() throws Exception {
            // Define all required variables inside the method
            double[] initialGuess = {1.0, 2.0, 3.0};
            double[] expectedGradient = {1.0, 2.0, 3.0};
            
            // Create mock objects
            ParametricUnivariateRealFunction mockGaussian = mock(ParametricUnivariateRealFunction.class);
            when(mockGaussian.gradient(anyDouble(), any(double[].class)))
                .thenReturn(expectedGradient);
            
            // Create mock optimizer
            DifferentiableMultivariateVectorialOptimizer mockOptimizer = mock(DifferentiableMultivariateVectorialOptimizer.class);
            
            // Use reflection to test the anonymous function
            Method fitMethod = GaussianFitter.class.getDeclaredMethod("fit", double[].class);
            fitMethod.setAccessible(true);
            
            // Create a test instance with our mock Gaussian
            GaussianFitter testFitter = new GaussianFitter(mockOptimizer) {
                @Override
                public double[] fit(ParametricUnivariateRealFunction f, double[] initialGuess) {
                    // Test the function's gradient method
                    double[] result = f.gradient(1.0, initialGuess);
                    assertArrayEquals(expectedGradient, result, 0.0);
                    return new double[0];
                }
            };
            
            // Replace the Gaussian.Parametric in the anonymous class with our mock
            GaussianFitter spyFitter = spy(testFitter);
            
            fitMethod.invoke(spyFitter, initialGuess);
        }


}
