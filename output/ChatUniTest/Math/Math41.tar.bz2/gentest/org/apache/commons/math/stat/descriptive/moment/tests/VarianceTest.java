package gentest.org.apache.commons.math.stat.descriptive.moment.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.descriptive.moment.*;
import java.io.Serializable;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.stat.descriptive.WeightedEvaluation;
import org.apache.commons.math.stat.descriptive.AbstractStorelessUnivariateStatistic;
import org.apache.commons.math.util.MathUtils;
 
public class VarianceTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test(expected = NullArgumentException.class)
                    public void testEvaluateWithMeanNullArray() {
                        Variance variance = new Variance();
                        variance.evaluate(null, 0.0);
                    }

    @Test
                    public void testEvaluateWithMeanEmptyArray() {
                        Variance variance = new Variance();
                        double result = variance.evaluate(new double[]{}, 0.0);
                        assertTrue(Double.isNaN(result));
                    }

    @Test
                    public void testEvaluateWithMeanSingleValue() {
                        Variance variance = new Variance();
                        double result = variance.evaluate(new double[]{5.0}, 5.0);
                        assertEquals(0.0, result, 0.0);
                    }

    @Test
                    public void testEvaluateWithMeanAllSameValues() {
                        Variance variance = new Variance();
                        double result = variance.evaluate(new double[]{3.0, 3.0, 3.0, 3.0}, 3.0);
                        assertEquals(0.0, result, 0.0);
                    }

    @Test
        public void testEvaluateWithMean() {
            Variance variance = new Variance();
            boolean biasCorrected = true;  // or false depending on test case
            double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};  // sample values
            double mean = 3.0;  // precomputed mean
            double expected = 2.5;  // expected variance result
            
            variance.setBiasCorrected(biasCorrected);
            double result = variance.evaluate(values, mean);
            assertEquals(expected, result, 1e-10);
        }


}
