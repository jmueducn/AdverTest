package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
 
public class FastMathTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testMaxIntFirstArgGreater() {
            int a = 5;
            int b = 3;
            int expected = 5;
            int actual = FastMath.max(a, b);
            assertEquals(expected, actual);
        }

    @Test
        public void testMaxIntSecondArgGreater() {
            int a = 2;
            int b = 7;
            int expected = 7;
            int actual = FastMath.max(a, b);
            assertEquals(expected, actual);
        }

    @Test
        public void testMaxIntEqualArgs() {
            int a = 4;
            int b = 4;
            int expected = 4;
            int actual = FastMath.max(a, b);
            assertEquals(expected, actual);
        }

    @Test
        public void testMaxIntNegativeFirstArgGreater() {
            int a = -1;
            int b = -5;
            int expected = -1;
            int actual = FastMath.max(a, b);
            assertEquals(expected, actual);
        }

    @Test
        public void testMaxIntNegativeSecondArgGreater() {
            int a = -10;
            int b = -3;
            int expected = -3;
            int actual = FastMath.max(a, b);
            assertEquals(expected, actual);
        }

    @Test
        public void testMaxIntMixedSignsFirstArgGreater() {
            int a = 1;
            int b = -1;
            int expected = 1;
            int actual = FastMath.max(a, b);
            assertEquals(expected, actual);
        }

    @Test
        public void testMaxIntMixedSignsSecondArgGreater() {
            int a = -5;
            int b = 5;
            int expected = 5;
            int actual = FastMath.max(a, b);
            assertEquals(expected, actual);
        }

    @Test
        public void testMaxIntMaxValue() {
            int a = Integer.MAX_VALUE;
            int b = Integer.MAX_VALUE - 1;
            int expected = Integer.MAX_VALUE;
            int actual = FastMath.max(a, b);
            assertEquals(expected, actual);
        }

    @Test
        public void testMaxIntMinValue() {
            int a = Integer.MIN_VALUE;
            int b = Integer.MIN_VALUE + 1;
            int expected = Integer.MIN_VALUE + 1;
            int actual = FastMath.max(a, b);
            assertEquals(expected, actual);
        }

    @Test
        public void testMaxIntMaxAndMinValues() {
            int a = Integer.MAX_VALUE;
            int b = Integer.MIN_VALUE;
            int expected = Integer.MAX_VALUE;
            int actual = FastMath.max(a, b);
            assertEquals(expected, actual);
        }

    @Test
        public void testMaxLong() {
            // Test cases where a < b
            assertEquals(5L, FastMath.max(3L, 5L));
            assertEquals(0L, FastMath.max(-1L, 0L));
            assertEquals(Long.MAX_VALUE, FastMath.max(Long.MIN_VALUE, Long.MAX_VALUE));
            
            // Test cases where a > b
            assertEquals(10L, FastMath.max(10L, 5L));
            assertEquals(0L, FastMath.max(0L, -1L));
            assertEquals(Long.MAX_VALUE, FastMath.max(Long.MAX_VALUE, Long.MIN_VALUE));
            
            // Test cases where a == b
            assertEquals(0L, FastMath.max(0L, 0L));
            assertEquals(Long.MAX_VALUE, FastMath.max(Long.MAX_VALUE, Long.MAX_VALUE));
            assertEquals(Long.MIN_VALUE, FastMath.max(Long.MIN_VALUE, Long.MIN_VALUE));
            
            // Test edge cases
            assertEquals(-1L, FastMath.max(-1L, -2L));
            assertEquals(-1L, FastMath.max(-2L, -1L));
            assertEquals(0L, FastMath.max(-0L, 0L));
            assertEquals(0L, FastMath.max(0L, -0L));
        }

    @Test
        public void testMaxLongWithNegativeValues() {
            assertEquals(-10L, FastMath.max(-20L, -10L));
            assertEquals(-5L, FastMath.max(-5L, -10L));
        }

    @Test
        public void testMaxLongWithLargeValues() {
            assertEquals(Long.MAX_VALUE - 1, FastMath.max(Long.MAX_VALUE - 1, Long.MAX_VALUE - 2));
            assertEquals(Long.MAX_VALUE, FastMath.max(Long.MAX_VALUE - 1, Long.MAX_VALUE));
            
            assertEquals(Long.MIN_VALUE + 1, FastMath.max(Long.MIN_VALUE, Long.MIN_VALUE + 1));
            assertEquals(Long.MIN_VALUE + 1, FastMath.max(Long.MIN_VALUE + 1, Long.MIN_VALUE));
        }

    @Test
        public void testMaxLongWithEqualValues() {
            long value = 123456789012345L;
            assertEquals(value, FastMath.max(value, value));
            
            value = -987654321098765L;
            assertEquals(value, FastMath.max(value, value));
        }

    @Test
        public void testMaxFloatRegularValues() {
            // Test with a < b
            assertEquals(5.0f, FastMath.max(3.0f, 5.0f), 0.0f);
            
            // Test with a > b
            assertEquals(7.0f, FastMath.max(7.0f, 2.0f), 0.0f);
            
            // Test with a == b
            assertEquals(4.0f, FastMath.max(4.0f, 4.0f), 0.0f);
            
            // Test with negative numbers
            assertEquals(-1.0f, FastMath.max(-3.0f, -1.0f), 0.0f);
            
            // Test with one positive and one negative
            assertEquals(2.0f, FastMath.max(-5.0f, 2.0f), 0.0f);
        }

    @Test
        public void testMaxFloatWithNaN() {
            // Test with a as NaN
            assertTrue(Float.isNaN(FastMath.max(Float.NaN, 5.0f)));
            
            // Test with b as NaN
            assertTrue(Float.isNaN(FastMath.max(3.0f, Float.NaN)));
            
            // Test with both as NaN
            assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.NaN)));
            
            // Test when sum is NaN but individual numbers aren't
            assertEquals(1.0f, FastMath.max(Float.POSITIVE_INFINITY, 1.0f), 0.0f);
            assertEquals(1.0f, FastMath.max(1.0f, Float.NEGATIVE_INFINITY), 0.0f);
        }

    @Test
        public void testMaxFloatWithInfiniteValues() {
            // Test with positive infinity
            assertEquals(Float.POSITIVE_INFINITY, 
                FastMath.max(Float.POSITIVE_INFINITY, Float.MAX_VALUE), 0.0f);
                
            // Test with negative infinity
            assertEquals(0.0f, 
                FastMath.max(Float.NEGATIVE_INFINITY, 0.0f), 0.0f);
                
            // Test both infinite
            assertEquals(Float.POSITIVE_INFINITY, 
                FastMath.max(Float.POSITIVE_INFINITY, Float.NEGATIVE_INFINITY), 0.0f);
        }

    @Test
        public void testMaxFloatEdgeCases() {
            // Test with Float.MIN_VALUE and 0
            assertEquals(Float.MIN_VALUE, 
                FastMath.max(Float.MIN_VALUE, 0.0f), 0.0f);
                
            // Test with Float.MAX_VALUE
            assertEquals(Float.MAX_VALUE, 
                FastMath.max(Float.MAX_VALUE, 1.0f), 0.0f);
                
            // Test with very close values
            assertEquals(1.000001f, 
                FastMath.max(1.000001f, 1.000000f), 0.0f);
                
            // Test with values that would overflow if added
            assertEquals(Float.MAX_VALUE, 
                FastMath.max(Float.MAX_VALUE, -Float.MAX_VALUE), 0.0f);
        }

    @Test
        public void testMaxDouble() {
            // Test regular cases
            assertEquals(5.0, FastMath.max(3.0, 5.0), 0.0);
            assertEquals(5.0, FastMath.max(5.0, 3.0), 0.0);
            assertEquals(-3.0, FastMath.max(-3.0, -5.0), 0.0);
            assertEquals(-3.0, FastMath.max(-5.0, -3.0), 0.0);
            assertEquals(0.0, FastMath.max(0.0, -0.0), 0.0);
            assertEquals(0.0, FastMath.max(-0.0, 0.0), 0.0);
            
            // Test equal values
            assertEquals(3.0, FastMath.max(3.0, 3.0), 0.0);
            assertEquals(-3.0, FastMath.max(-3.0, -3.0), 0.0);
            
            // Test with NaN
            assertTrue(Double.isNaN(FastMath.max(Double.NaN, 5.0)));
            assertTrue(Double.isNaN(FastMath.max(5.0, Double.NaN)));
            assertTrue(Double.isNaN(FastMath.max(Double.NaN, Double.NaN)));
            
            // Test with infinity
            assertEquals(Double.POSITIVE_INFINITY, 
                FastMath.max(Double.POSITIVE_INFINITY, 5.0), 0.0);
            assertEquals(Double.POSITIVE_INFINITY, 
                FastMath.max(5.0, Double.POSITIVE_INFINITY), 0.0);
            assertEquals(5.0, 
                FastMath.max(Double.NEGATIVE_INFINITY, 5.0), 0.0);
            assertEquals(5.0, 
                FastMath.max(5.0, Double.NEGATIVE_INFINITY), 0.0);
                
            // Test combination of NaN and infinity
            assertTrue(Double.isNaN(FastMath.max(Double.NaN, Double.POSITIVE_INFINITY)));
            assertTrue(Double.isNaN(FastMath.max(Double.POSITIVE_INFINITY, Double.NaN)));
            assertTrue(Double.isNaN(FastMath.max(Double.NaN, Double.NEGATIVE_INFINITY)));
            assertTrue(Double.isNaN(FastMath.max(Double.NEGATIVE_INFINITY, Double.NaN)));
        }

    @Test
        public void testMaxFloat() {
            // Test regular cases
            assertEquals(5.0f, FastMath.max(3.0f, 5.0f), 0.0f);
            assertEquals(5.0f, FastMath.max(5.0f, 3.0f), 0.0f);
            assertEquals(-3.0f, FastMath.max(-3.0f, -5.0f), 0.0f);
            assertEquals(-3.0f, FastMath.max(-5.0f, -3.0f), 0.0f);
            assertEquals(0.0f, FastMath.max(0.0f, -0.0f), 0.0f);
            assertEquals(0.0f, FastMath.max(-0.0f, 0.0f), 0.0f);
            
            // Test equal values
            assertEquals(3.0f, FastMath.max(3.0f, 3.0f), 0.0f);
            assertEquals(-3.0f, FastMath.max(-3.0f, -3.0f), 0.0f);
            
            // Test with NaN
            assertTrue(Float.isNaN(FastMath.max(Float.NaN, 5.0f)));
            assertTrue(Float.isNaN(FastMath.max(5.0f, Float.NaN)));
            assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.NaN)));
            
            // Test with infinity
            assertEquals(Float.POSITIVE_INFINITY, 
                FastMath.max(Float.POSITIVE_INFINITY, 5.0f), 0.0f);
            assertEquals(Float.POSITIVE_INFINITY, 
                FastMath.max(5.0f, Float.POSITIVE_INFINITY), 0.0f);
            assertEquals(5.0f, 
                FastMath.max(Float.NEGATIVE_INFINITY, 5.0f), 0.0f);
            assertEquals(5.0f, 
                FastMath.max(5.0f, Float.NEGATIVE_INFINITY), 0.0f);
                
            // Test combination of NaN and infinity
            assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.POSITIVE_INFINITY)));
            assertTrue(Float.isNaN(FastMath.max(Float.POSITIVE_INFINITY, Float.NaN)));
            assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.NEGATIVE_INFINITY)));
            assertTrue(Float.isNaN(FastMath.max(Float.NEGATIVE_INFINITY, Float.NaN)));
        }

    @Test
        public void testMaxInt() {
            assertEquals(5, FastMath.max(3, 5));
            assertEquals(5, FastMath.max(5, 3));
            assertEquals(-3, FastMath.max(-3, -5));
            assertEquals(-3, FastMath.max(-5, -3));
            assertEquals(0, FastMath.max(0, 0));
            assertEquals(Integer.MAX_VALUE, FastMath.max(Integer.MAX_VALUE, Integer.MIN_VALUE));
            assertEquals(Integer.MAX_VALUE, FastMath.max(Integer.MIN_VALUE, Integer.MAX_VALUE));
        }

    @Test
        public void testMaxLong1() {
            assertEquals(5L, FastMath.max(3L, 5L));
            assertEquals(5L, FastMath.max(5L, 3L));
            assertEquals(-3L, FastMath.max(-3L, -5L));
            assertEquals(-3L, FastMath.max(-5L, -3L));
            assertEquals(0L, FastMath.max(0L, 0L));
            assertEquals(Long.MAX_VALUE, FastMath.max(Long.MAX_VALUE, Long.MIN_VALUE));
            assertEquals(Long.MAX_VALUE, FastMath.max(Long.MIN_VALUE, Long.MAX_VALUE));
        }

}
