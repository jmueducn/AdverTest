package gentest.org.apache.commons.math.stat.descriptive.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.descriptive.*;
import java.io.Serializable;
import org.apache.commons.math.exception.MathIllegalStateException;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.stat.descriptive.moment.GeometricMean;
import org.apache.commons.math.stat.descriptive.moment.Mean;
import org.apache.commons.math.stat.descriptive.moment.SecondMoment;
import org.apache.commons.math.stat.descriptive.moment.Variance;
import org.apache.commons.math.stat.descriptive.rank.Max;
import org.apache.commons.math.stat.descriptive.rank.Min;
import org.apache.commons.math.stat.descriptive.summary.Sum;
import org.apache.commons.math.stat.descriptive.summary.SumOfLogs;
import org.apache.commons.math.stat.descriptive.summary.SumOfSquares;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.Precision;
import org.apache.commons.math.util.FastMath;
 
public class SummaryStatisticsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                public void testAddValueWithDefaultImplementations() throws Exception {
                                                    SummaryStatistics defaultStats = new SummaryStatistics();
                                                    double value = 5.0;
                                                    
                                                    defaultStats.addValue(value);
                                                    
                                                    assertEquals(1, defaultStats.getN());
                                                    assertEquals(value, defaultStats.getSum(), 0.0001);
                                                    assertEquals(value * value, defaultStats.getSumsq(), 0.0001);
                                                    assertEquals(value, defaultStats.getMin(), 0.0001);
                                                    assertEquals(value, defaultStats.getMax(), 0.0001);
                                                }

    @Test
                                            public void testAddValueWithOverriddenMean() throws Exception {
                                                SummaryStatistics stats = new SummaryStatistics();
                                                StorelessUnivariateStatistic customMean = mock(StorelessUnivariateStatistic.class);
                                                
                                                // Use reflection to set private field
                                                java.lang.reflect.Field field = SummaryStatistics.class.getDeclaredField("meanImpl");
                                                field.setAccessible(true);
                                                field.set(stats, customMean);
                                                
                                                double value = 7.5;
                                                stats.addValue(value);
                                                
                                                verify(customMean).increment(value);
                                            }

    @Test
                                            public void testAddValueWithOverriddenVariance() throws Exception {
                                                SummaryStatistics stats = new SummaryStatistics();
                                                StorelessUnivariateStatistic customVariance = mock(StorelessUnivariateStatistic.class);
                                                
                                                // Use reflection to set private field
                                                Field varianceImplField = SummaryStatistics.class.getDeclaredField("varianceImpl");
                                                varianceImplField.setAccessible(true);
                                                varianceImplField.set(stats, customVariance);
                                                
                                                double value = 3.2;
                                                stats.addValue(value);
                                                
                                                verify(customVariance).increment(value);
                                            }

    @Test
                                            public void testAddValueWithOverriddenGeoMean() throws Exception {
                                                SummaryStatistics stats = new SummaryStatistics();
                                                StorelessUnivariateStatistic customGeoMean = mock(StorelessUnivariateStatistic.class);
                                                
                                                // Use reflection to set private field
                                                java.lang.reflect.Field field = SummaryStatistics.class.getDeclaredField("geoMeanImpl");
                                                field.setAccessible(true);
                                                field.set(stats, customGeoMean);
                                                
                                                double value = 4.8;
                                                stats.addValue(value);
                                                
                                                verify(customGeoMean).increment(value);
                                            }

    @Test
                                            public void testAddValueIncrementsCount() {
                                                SummaryStatistics stats = new SummaryStatistics();
                                                assertEquals(0, stats.getN());
                                                
                                                stats.addValue(1.0);
                                                assertEquals(1, stats.getN());
                                                
                                                stats.addValue(2.0);
                                                assertEquals(2, stats.getN());
                                            }

    @Test
        public void testAddValueIncrementsAllStatistics() {
            // Create mock implementations
            StorelessUnivariateStatistic mockSumImpl = mock(StorelessUnivariateStatistic.class);
            StorelessUnivariateStatistic mockSumsqImpl = mock(StorelessUnivariateStatistic.class);
            StorelessUnivariateStatistic mockMinImpl = mock(StorelessUnivariateStatistic.class);
            StorelessUnivariateStatistic mockMaxImpl = mock(StorelessUnivariateStatistic.class);
            StorelessUnivariateStatistic mockSumLogImpl = mock(StorelessUnivariateStatistic.class);
            StorelessUnivariateStatistic mockSecondMoment = mock(StorelessUnivariateStatistic.class);
            StorelessUnivariateStatistic mockMeanImpl = mock(StorelessUnivariateStatistic.class);
            StorelessUnivariateStatistic mockVarianceImpl = mock(StorelessUnivariateStatistic.class);
            StorelessUnivariateStatistic mockGeoMeanImpl = mock(StorelessUnivariateStatistic.class);
            
            // Create stats instance and set the mock implementations
            SummaryStatistics stats = new SummaryStatistics();
            stats.setSumImpl(mockSumImpl);
            stats.setSumsqImpl(mockSumsqImpl);
            stats.setMinImpl(mockMinImpl);
            stats.setMaxImpl(mockMaxImpl);
            stats.setSumLogImpl(mockSumLogImpl);
            stats.setMeanImpl(mockMeanImpl);
            stats.setVarianceImpl(mockVarianceImpl);
            stats.setGeoMeanImpl(mockGeoMeanImpl);
            
            double value = 10.0;
            
            stats.addValue(value);
            
            verify(mockSumImpl).increment(value);
            verify(mockSumsqImpl).increment(value);
            verify(mockMinImpl).increment(value);
            verify(mockMaxImpl).increment(value);
            verify(mockSumLogImpl).increment(value);
            verify(mockSecondMoment).increment(value);
            verify(mockMeanImpl, never()).increment(value);
            verify(mockVarianceImpl, never()).increment(value);
            verify(mockGeoMeanImpl, never()).increment(value);
            
            assertEquals(1, stats.getN());
        }

    @Test
        public void testAddValueMultipleTimes() {
            // Create mock implementations
            StorelessUnivariateStatistic mockSumImpl = mock(StorelessUnivariateStatistic.class);
            StorelessUnivariateStatistic mockSumsqImpl = mock(StorelessUnivariateStatistic.class);
            StorelessUnivariateStatistic mockMinImpl = mock(StorelessUnivariateStatistic.class);
            StorelessUnivariateStatistic mockMaxImpl = mock(StorelessUnivariateStatistic.class);
            StorelessUnivariateStatistic mockSumLogImpl = mock(StorelessUnivariateStatistic.class);
            StorelessUnivariateStatistic mockSecondMoment = mock(StorelessUnivariateStatistic.class);
            StorelessUnivariateStatistic mockMeanImpl = mock(StorelessUnivariateStatistic.class);
            StorelessUnivariateStatistic mockVarianceImpl = mock(StorelessUnivariateStatistic.class);
            StorelessUnivariateStatistic mockGeoMeanImpl = mock(StorelessUnivariateStatistic.class);
            
            // Create stats instance and set the mock implementations
            SummaryStatistics stats = new SummaryStatistics();
            stats.setSumImpl(mockSumImpl);
            stats.setSumsqImpl(mockSumsqImpl);
            stats.setMinImpl(mockMinImpl);
            stats.setMaxImpl(mockMaxImpl);
            stats.setSumLogImpl(mockSumLogImpl);
            stats.setMeanImpl(mockMeanImpl);
            stats.setVarianceImpl(mockVarianceImpl);
            stats.setGeoMeanImpl(mockGeoMeanImpl);
            
            double value1 = 5.0;
            double value2 = 10.0;
            
            stats.addValue(value1);
            stats.addValue(value2);
            
            verify(mockSumImpl).increment(value1);
            verify(mockSumImpl).increment(value2);
            verify(mockSumsqImpl).increment(value1);
            verify(mockSumsqImpl).increment(value2);
            verify(mockMinImpl).increment(value1);
            verify(mockMinImpl).increment(value2);
            verify(mockMaxImpl).increment(value1);
            verify(mockMaxImpl).increment(value2);
            verify(mockSumLogImpl).increment(value1);
            verify(mockSumLogImpl).increment(value2);
            verify(mockSecondMoment).increment(value1);
            verify(mockSecondMoment).increment(value2);
            
            assertEquals(2, stats.getN());
        }


}
