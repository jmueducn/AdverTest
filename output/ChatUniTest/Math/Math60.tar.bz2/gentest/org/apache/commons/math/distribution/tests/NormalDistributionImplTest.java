package gentest.org.apache.commons.math.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.distribution.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.exception.NotStrictlyPositiveException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.special.Erf;
import org.apache.commons.math.util.FastMath;
 
public class NormalDistributionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                            public void testCumulativeProbability_DeviationMoreThan40SD_Negative() throws MathException {
                                                NormalDistributionImpl dist = new NormalDistributionImpl(10.0, 2.0);
                                                double result = dist.cumulativeProbability(-70.0); // x = -70, mean = 10, dev = -80 (40*SD)
                                                assertEquals(0.0, result, 0.0);
                                            }

    @Test
                                            public void testCumulativeProbability_DeviationMoreThan40SD_Positive() throws MathException {
                                                NormalDistributionImpl dist = new NormalDistributionImpl(10.0, 2.0);
                                                double result = dist.cumulativeProbability(90.0); // x = 90, mean = 10, dev = 80 (40*SD)
                                                assertEquals(1.0, result, 0.0);
                                            }

    @Test
                                            public void testCumulativeProbability_ExactlyAtMean() throws MathException {
                                                NormalDistributionImpl dist = new NormalDistributionImpl(10.0, 2.0);
                                                double result = dist.cumulativeProbability(10.0); // x = mean
                                                assertEquals(0.5, result, 1e-10);
                                            }

    @Test
                                            public void testCumulativeProbability_StandardNormal() throws MathException {
                                                NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                double result = dist.cumulativeProbability(1.96); // Standard normal case
                                                // Expected value from standard normal tables for z=1.96
                                                assertEquals(0.9750021048517796, result, 1e-10);
                                            }

    @Test
                                            public void testCumulativeProbability_BoundaryCase() throws MathException {
                                                NormalDistributionImpl dist = new NormalDistributionImpl(10.0, 2.0);
                                                // Exactly 40 standard deviations away (boundary case)
                                                double boundary = 10.0 + 40 * 2.0;
                                                double resultJustBelow = dist.cumulativeProbability(boundary - 1e-10);
                                                double resultJustAbove = dist.cumulativeProbability(boundary + 1e-10);
                                                
                                                // Should still use erf calculation for values very close to boundary
                                                assertTrue(resultJustBelow < 1.0);
                                                assertEquals(1.0, resultJustAbove, 0.0);
                                            }

    @Test
        public void testCumulativeProbability_Within40SD() throws Exception {
            NormalDistributionImpl dist = new NormalDistributionImpl(10.0, 2.0);
            double result = dist.cumulativeProbability(11.0); // x = 11, mean = 10, dev = 1 (<40*SD)
            // Expected value calculated using standard normal distribution tables
            double expected = 0.5 * (1.0 + Erf.erf(1.0 / (2.0 * Math.sqrt(2.0))));
            assertEquals(expected, result, 1e-10);
        }


}
