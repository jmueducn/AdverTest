package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Arrays;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.exception.util.Localizable;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.exception.NonMonotonousSequenceException;
 
public class MathUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
            public void testEqualsWithEqualValues() {
                assertTrue(MathUtils.equals(1.0, 1.0));
                assertTrue(MathUtils.equals(0.0, 0.0));
                assertTrue(MathUtils.equals(-1.0, -1.0));
                assertTrue(MathUtils.equals(Double.MAX_VALUE, Double.MAX_VALUE));
                assertTrue(MathUtils.equals(Double.MIN_VALUE, Double.MIN_VALUE));
            }

    @Test
            public void testEqualsWithDifferentValuesWithinDefaultEpsilon() {
                assertTrue(MathUtils.equals(1.0, 1.0 + MathUtils.EPSILON / 2));
                assertTrue(MathUtils.equals(1.0, 1.0 - MathUtils.EPSILON / 2));
                assertTrue(MathUtils.equals(0.0, MathUtils.EPSILON / 2));
                assertTrue(MathUtils.equals(0.0, -MathUtils.EPSILON / 2));
            }

    @Test
            public void testEqualsWithDifferentValuesOutsideDefaultEpsilon() {
                assertFalse(MathUtils.equals(1.0, 1.0 + MathUtils.EPSILON * 2));
                assertFalse(MathUtils.equals(1.0, 1.0 - MathUtils.EPSILON * 2));
                assertFalse(MathUtils.equals(0.0, MathUtils.EPSILON * 2));
                assertFalse(MathUtils.equals(0.0, -MathUtils.EPSILON * 2));
            }

    @Test
            public void testEqualsWithNaNValues() {
                assertFalse(MathUtils.equals(Double.NaN, Double.NaN));
                assertFalse(MathUtils.equals(Double.NaN, 1.0));
                assertFalse(MathUtils.equals(1.0, Double.NaN));
            }

    @Test
            public void testEqualsWithInfiniteValues() {
                assertTrue(MathUtils.equals(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY));
                assertTrue(MathUtils.equals(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY));
                assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY));
                assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, Double.MAX_VALUE));
                assertFalse(MathUtils.equals(Double.NEGATIVE_INFINITY, -Double.MAX_VALUE));
            }

    @Test
            public void testEqualsWithVerySmallValues() {
                assertTrue(MathUtils.equals(Double.MIN_VALUE, Double.MIN_VALUE));
                assertTrue(MathUtils.equals(-Double.MIN_VALUE, -Double.MIN_VALUE));
                assertFalse(MathUtils.equals(Double.MIN_VALUE, -Double.MIN_VALUE));
            }

    @Test
            public void testEqualsWithVeryLargeValues() {
                assertTrue(MathUtils.equals(Double.MAX_VALUE, Double.MAX_VALUE));
                assertTrue(MathUtils.equals(-Double.MAX_VALUE, -Double.MAX_VALUE));
                assertFalse(MathUtils.equals(Double.MAX_VALUE, -Double.MAX_VALUE));
            }

    @Test
            public void testEqualsWithOppositeSigns() {
                assertFalse(MathUtils.equals(1.0, -1.0));
                assertFalse(MathUtils.equals(0.0, -0.0)); // IEEE 754 considers +0.0 and -0.0 equal
            }

    @Test
            public void testEqualsWithSubnormalNumbers() {
                double subnormal = Double.MIN_VALUE / 2;
                assertTrue(MathUtils.equals(subnormal, subnormal));
                assertFalse(MathUtils.equals(subnormal, subnormal * 2));
            }

    @Test
            public void testEqualsWithEps_ExactEqual() {
                assertTrue(MathUtils.equals(1.0, 1.0, 0.1));
            }

    @Test
            public void testEqualsWithEps_WithinEpsilon() {
                assertTrue(MathUtils.equals(1.0, 1.05, 0.1));
                assertTrue(MathUtils.equals(1.0, 0.95, 0.1));
            }

    @Test
            public void testEqualsWithEps_OutsideEpsilon() {
                assertFalse(MathUtils.equals(1.0, 1.2, 0.1));
                assertFalse(MathUtils.equals(1.0, 0.8, 0.1));
            }

    @Test
            public void testEqualsWithEps_EqualWithinUlps() {
                // Values that are equal within 1 ULP
                double x = 1.0;
                double y = Math.nextAfter(x, Double.POSITIVE_INFINITY);
                assertTrue(MathUtils.equals(x, y, 0.0));
            }

    @Test
            public void testEqualsWithEps_NaNValues() {
                assertFalse(MathUtils.equals(Double.NaN, 1.0, 0.1));
                assertFalse(MathUtils.equals(1.0, Double.NaN, 0.1));
                assertFalse(MathUtils.equals(Double.NaN, Double.NaN, 0.1));
            }

    @Test
            public void testEqualsWithEps_InfiniteValues() {
                assertTrue(MathUtils.equals(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, 0.1));
                assertTrue(MathUtils.equals(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, 0.1));
                assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY, 0.1));
                assertFalse(MathUtils.equals(1.0, Double.POSITIVE_INFINITY, 0.1));
                assertFalse(MathUtils.equals(Double.NEGATIVE_INFINITY, 1.0, 0.1));
            }

    @Test
            public void testEqualsWithEps_ZeroEpsilon() {
                assertTrue(MathUtils.equals(1.0, 1.0, 0.0));
                assertFalse(MathUtils.equals(1.0, 1.000001, 0.0));
            }

    @Test
            public void testEqualsWithEps_LargeEpsilon() {
                assertTrue(MathUtils.equals(1.0, 100.0, 100.0));
                assertTrue(MathUtils.equals(1.0, -99.0, 100.0));
            }

    @Test
            public void testEqualsWithEps_EdgeCases() {
                // Test with very small numbers
                assertTrue(MathUtils.equals(1e-20, 1.1e-20, 1e-19));
                assertFalse(MathUtils.equals(1e-20, 2e-20, 1e-21));
        
                // Test with very large numbers
                assertTrue(MathUtils.equals(1e20, 1.1e20, 1e19));
                assertFalse(MathUtils.equals(1e20, 1.1e20, 1e18));
            }

    @Test
            public void testEqualsWithEps_OppositeSigns() {
                assertFalse(MathUtils.equals(1.0, -1.0, 1.9));
                assertFalse(MathUtils.equals(1.0, -1.0, 2.0));
                assertTrue(MathUtils.equals(1.0, -1.0, 2.1));
            }

    @Test
            public void testEqualsWithSameValues() {
                assertTrue(MathUtils.equals(1.0, 1.0, 1));
                assertTrue(MathUtils.equals(0.0, 0.0, 1));
                assertTrue(MathUtils.equals(-1.0, -1.0, 1));
            }

    @Test
            public void testEqualsWithDifferentValuesWithinUlps() {
                // Values that differ by exactly maxUlps
                assertTrue(MathUtils.equals(1.0, 1.0 + Math.ulp(1.0), 1));
                assertTrue(MathUtils.equals(1.0, 1.0 - Math.ulp(1.0), 1));
                
                // Values that differ by less than maxUlps
                assertTrue(MathUtils.equals(1.0, 1.0 + 0.5 * Math.ulp(1.0), 1));
            }

    @Test
            public void testEqualsWithDifferentValuesOutsideUlps() {
                // Values that differ by more than maxUlps
                assertFalse(MathUtils.equals(1.0, 1.0 + 2 * Math.ulp(1.0), 1));
                assertFalse(MathUtils.equals(1.0, 1.0 - 2 * Math.ulp(1.0), 1));
            }

    @Test
            public void testEqualsWithNegativeNumbers() {
                assertTrue(MathUtils.equals(-1.0, -1.0, 1));
                assertTrue(MathUtils.equals(-1.0, -1.0 - Math.ulp(-1.0), 1));
                assertFalse(MathUtils.equals(-1.0, -1.0 - 2 * Math.ulp(-1.0), 1));
            }

    @Test
            public void testEqualsWithNaN() {
                assertFalse(MathUtils.equals(Double.NaN, Double.NaN, 1));
                assertFalse(MathUtils.equals(1.0, Double.NaN, 1));
                assertFalse(MathUtils.equals(Double.NaN, 1.0, 1));
            }

    @Test
            public void testEqualsWithInfinity() {
                assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, 1));
                assertFalse(MathUtils.equals(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, 1));
                assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY, 1));
                assertFalse(MathUtils.equals(1.0, Double.POSITIVE_INFINITY, 1));
            }

    @Test
            public void testEqualsWithZeroAndNegativeZero() {
                assertTrue(MathUtils.equals(0.0, -0.0, 1));
            }

    @Test
            public void testEqualsWithLargeUlps() {
                double value = 1.0;
                double ulp = Math.ulp(value);
                int largeUlps = 1000;
                assertTrue(MathUtils.equals(value, value + largeUlps * ulp, largeUlps + 1));
                assertFalse(MathUtils.equals(value, value + largeUlps * ulp, largeUlps - 1));
            }

    @Test(expected = AssertionError.class)
            public void testEqualsWithZeroMaxUlps() {
                MathUtils.equals(1.0, 1.0, 0);
            }

    @Test(expected = AssertionError.class)
            public void testEqualsWithNegativeMaxUlps() {
                MathUtils.equals(1.0, 1.0, -1);
            }

    @Test
            public void testEqualsBothNull() {
                assertTrue(MathUtils.equals(null, null));
            }

    @Test
            public void testEqualsFirstNull() {
                double[] y = {1.0, 2.0};
                assertFalse(MathUtils.equals(null, y));
            }

    @Test
            public void testEqualsSecondNull() {
                double[] x = {1.0, 2.0};
                assertFalse(MathUtils.equals(x, null));
            }

    @Test
            public void testEqualsDifferentLengths() {
                double[] x = {1.0, 2.0};
                double[] y = {1.0};
                assertFalse(MathUtils.equals(x, y));
            }

    @Test
            public void testEqualsSameArrays() {
                double[] x = {1.0, 2.0};
                double[] y = {1.0, 2.0};
                assertTrue(MathUtils.equals(x, y));
            }

    @Test
            public void testEqualsDifferentArraysSameLength() {
                double[] x = {1.0, 2.0};
                double[] y = {1.0, 3.0};
                assertFalse(MathUtils.equals(x, y));
            }

    @Test
            public void testEqualsWithNaN1() {
                double[] x = {Double.NaN, 2.0};
                double[] y = {Double.NaN, 2.0};
                assertFalse(MathUtils.equals(x, y));
            }

    @Test
            public void testEqualsWithInfinity1() {
                double[] x = {Double.POSITIVE_INFINITY, 2.0};
                double[] y = {Double.POSITIVE_INFINITY, 2.0};
                assertTrue(MathUtils.equals(x, y));
            }

    @Test
            public void testEqualsWithNegativeInfinity() {
                double[] x = {Double.NEGATIVE_INFINITY, 2.0};
                double[] y = {Double.NEGATIVE_INFINITY, 2.0};
                assertTrue(MathUtils.equals(x, y));
            }

    @Test
            public void testEqualsWithMixedInfinity() {
                double[] x = {Double.POSITIVE_INFINITY, 2.0};
                double[] y = {Double.NEGATIVE_INFINITY, 2.0};
                assertFalse(MathUtils.equals(x, y));
            }

    @Test
            public void testEqualsWithEpsilonDifference() {
                double[] x = {1.0, 2.0};
                double[] y = {1.0 + MathUtils.EPSILON/2, 2.0};
                assertTrue(MathUtils.equals(x, y));
            }

    @Test
            public void testEqualsWithLargeDifference() {
                double[] x = {1.0, 2.0};
                double[] y = {1.0 + 10 * MathUtils.EPSILON, 2.0};
                assertFalse(MathUtils.equals(x, y));
            }

    @Test
            public void testEqualsEmptyArrays() {
                double[] x = {};
                double[] y = {};
                assertTrue(MathUtils.equals(x, y));
            }

    @Test
            public void testEqualsSingleElementArrays() {
                double[] x = {1.0};
                double[] y = {1.0};
                assertTrue(MathUtils.equals(x, y));
            }

    @Test
            public void testEqualsLargeArrays() {
                double[] x = new double[1000];
                double[] y = new double[1000];
                for (int i = 0; i < 1000; i++) {
                    x[i] = i;
                    y[i] = i;
                }
                assertTrue(MathUtils.equals(x, y));
            }

    @Test(expected = IllegalArgumentException.class)
        public void testEqualsWithMaxUlpsTooLarge() {
            final long NAN_GAP = 0x7fffffffffffffffL;
            MathUtils.equals(1.0, 1.0, NAN_GAP);
        }


}
