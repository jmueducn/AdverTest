package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math.FieldElement;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.NotPositiveException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class ComplexTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testTanWithNaN() {
            Complex c = new Complex(Double.NaN, 1.0);
            Complex result = c.tan();
            assertTrue(result.isNaN());
        }

    @Test
        public void testTanWithInfiniteReal() {
            Complex c = new Complex(Double.POSITIVE_INFINITY, 1.0);
            Complex result = c.tan();
            assertTrue(result.isNaN());
        }

    @Test
        public void testTanWithLargePositiveImaginary() {
            Complex c = new Complex(1.0, 25.0);
            Complex result = c.tan();
            assertEquals(0.0, result.getReal(), 0.0001);
            assertEquals(1.0, result.getImaginary(), 0.0001);
        }

    @Test
        public void testTanWithLargeNegativeImaginary() {
            Complex c = new Complex(1.0, -25.0);
            Complex result = c.tan();
            assertEquals(0.0, result.getReal(), 0.0001);
            assertEquals(-1.0, result.getImaginary(), 0.0001);
        }

    @Test
        public void testTanWithZero() {
            Complex c = new Complex(0.0, 0.0);
            Complex result = c.tan();
            assertEquals(0.0, result.getReal(), 0.0001);
            assertEquals(0.0, result.getImaginary(), 0.0001);
        }

    @Test
        public void testTanWithRealNumber() {
            Complex c = new Complex(Math.PI/4, 0.0);
            Complex result = c.tan();
            assertEquals(Math.tan(Math.PI/4), result.getReal(), 0.0001);
            assertEquals(0.0, result.getImaginary(), 0.0001);
        }

    @Test
        public void testTanWithImaginaryNumber() {
            Complex c = new Complex(0.0, 1.0);
            Complex result = c.tan();
            assertEquals(0.0, result.getReal(), 0.0001);
            assertEquals(Math.tanh(1.0), result.getImaginary(), 0.0001);
        }

    @Test
        public void testTanWithComplexNumber() {
            Complex c = new Complex(1.0, 1.0);
            Complex result = c.tan();
            
            double real2 = 2.0 * c.getReal();
            double imaginary2 = 2.0 * c.getImaginary();
            double d = Math.cos(real2) + Math.cosh(imaginary2);
            double expectedReal = Math.sin(real2) / d;
            double expectedImaginary = Math.sinh(imaginary2) / d;
            
            assertEquals(expectedReal, result.getReal(), 0.0001);
            assertEquals(expectedImaginary, result.getImaginary(), 0.0001);
        }

    @Test
        public void testTanWithBoundaryImaginary() {
            Complex c1 = new Complex(1.0, 20.0);
            Complex result1 = c1.tan();
            assertFalse(Double.isNaN(result1.getReal()));
            assertFalse(Double.isNaN(result1.getImaginary()));
    
            Complex c2 = new Complex(1.0, -20.0);
            Complex result2 = c2.tan();
            assertFalse(Double.isNaN(result2.getReal()));
            assertFalse(Double.isNaN(result2.getImaginary()));
        }

    @Test
        public void testTanhWithNaN() {
            Complex complex = new Complex(Double.NaN, 1.0);
            assertEquals(Complex.NaN, complex.tanh());
            
            complex = new Complex(1.0, Double.NaN);
            assertEquals(Complex.NaN, complex.tanh());
        }

    @Test
        public void testTanhWithInfiniteImaginary() {
            Complex complex = new Complex(1.0, Double.POSITIVE_INFINITY);
            assertEquals(Complex.NaN, complex.tanh());
            
            complex = new Complex(1.0, Double.NEGATIVE_INFINITY);
            assertEquals(Complex.NaN, complex.tanh());
        }

    @Test
        public void testTanhWithLargePositiveReal() {
            Complex complex = new Complex(21.0, 1.0);
            Complex expected = new Complex(1.0, 0.0);
            assertEquals(expected, complex.tanh());
        }

    @Test
        public void testTanhWithLargeNegativeReal() {
            Complex complex = new Complex(-21.0, 1.0);
            Complex expected = new Complex(-1.0, 0.0);
            assertEquals(expected, complex.tanh());
        }

    @Test
        public void testTanhWithRegularValues() {
            Complex complex = new Complex(1.0, 1.0);
            Complex result = complex.tanh();
            
            // Calculate expected values using the formula
            double real2 = 2.0 * 1.0;
            double imaginary2 = 2.0 * 1.0;
            double d = Math.cosh(real2) + Math.cos(imaginary2);
            double expectedReal = Math.sinh(real2) / d;
            double expectedImaginary = Math.sin(imaginary2) / d;
            
            assertEquals(expectedReal, result.getReal(), 1e-10);
            assertEquals(expectedImaginary, result.getImaginary(), 1e-10);
        }

    @Test
        public void testTanhWithZeroValues() {
            Complex complex = new Complex(0.0, 0.0);
            Complex result = complex.tanh();
            assertEquals(0.0, result.getReal(), 1e-10);
            assertEquals(0.0, result.getImaginary(), 1e-10);
        }

    @Test
        public void testTanhWithSmallValues() {
            Complex complex = new Complex(0.5, 0.5);
            Complex result = complex.tanh();
            
            // Calculate expected values using the formula
            double real2 = 2.0 * 0.5;
            double imaginary2 = 2.0 * 0.5;
            double d = Math.cosh(real2) + Math.cos(imaginary2);
            double expectedReal = Math.sinh(real2) / d;
            double expectedImaginary = Math.sin(imaginary2) / d;
            
            assertEquals(expectedReal, result.getReal(), 1e-10);
            assertEquals(expectedImaginary, result.getImaginary(), 1e-10);
        }

    @Test
        public void testTanhWithBoundaryValues() {
            Complex complex = new Complex(20.0, 0.0);
            Complex result = complex.tanh();
            assertTrue(result.getReal() > 0.999999 && result.getReal() < 1.0);
            assertEquals(0.0, result.getImaginary(), 1e-10);
    
            complex = new Complex(-20.0, 0.0);
            result = complex.tanh();
            assertTrue(result.getReal() < -0.999999 && result.getReal() > -1.0);
            assertEquals(0.0, result.getImaginary(), 1e-10);
        }

}
