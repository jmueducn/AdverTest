package gentest.org.apache.commons.math3.optim.nonlinear.vector.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.optim.nonlinear.vector.*;
import org.apache.commons.math3.optim.OptimizationData;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.DiagonalMatrix;
import org.apache.commons.math3.linear.NonSquareMatrixException;
 
public class WeightTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testConstructorWithDoubleArray() {
            double[] weights = {1.0, 2.0, 3.0};
            Weight weight = new Weight(weights);
            
            RealMatrix matrix = weight.getWeight();
            assertNotNull(matrix);
            assertTrue(matrix instanceof DiagonalMatrix);
            
            assertEquals(1.0, matrix.getEntry(0, 0), 0.0001);
            assertEquals(2.0, matrix.getEntry(1, 1), 0.0001);
            assertEquals(3.0, matrix.getEntry(2, 2), 0.0001);
            assertEquals(0.0, matrix.getEntry(0, 1), 0.0001);
        }

    @Test(expected = NullPointerException.class)
        public void testConstructorWithNullDoubleArray() {
            new Weight((double[]) null);
        }

    @Test
        public void testConstructorWithRealMatrix() {
            RealMatrix mockMatrix = mock(RealMatrix.class);
            when(mockMatrix.getColumnDimension()).thenReturn(2);
            when(mockMatrix.getRowDimension()).thenReturn(2);
            when(mockMatrix.copy()).thenReturn(mockMatrix);
            
            Weight weight = new Weight(mockMatrix);
            assertNotNull(weight.getWeight());
            verify(mockMatrix).copy();
        }

    @Test(expected = NonSquareMatrixException.class)
        public void testConstructorWithNonSquareMatrix() {
            RealMatrix mockMatrix = mock(RealMatrix.class);
            when(mockMatrix.getColumnDimension()).thenReturn(2);
            when(mockMatrix.getRowDimension()).thenReturn(3);
            
            new Weight(mockMatrix);
        }

    @Test(expected = NullPointerException.class)
        public void testConstructorWithNullMatrix() {
            new Weight((RealMatrix) null);
        }

    @Test
        public void testGetWeight() {
            double[] weights = {4.0, 5.0};
            Weight weight = new Weight(weights);
            
            RealMatrix matrix1 = weight.getWeight();
            RealMatrix matrix2 = weight.getWeight();
            
            assertNotSame(matrix1, matrix2);
            assertEquals(matrix1.getEntry(0, 0), matrix2.getEntry(0, 0), 0.0001);
            assertEquals(matrix1.getEntry(1, 1), matrix2.getEntry(1, 1), 0.0001);
        }

}
