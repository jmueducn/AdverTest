package gentest.org.apache.commons.math.analysis.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.analysis.*;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.MaxIterationsExceededException;
 
public class BrentSolverTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test(expected = IllegalArgumentException.class)
                                                                                                                                public void testSolve_InitialGuessOutsideInterval() throws Exception {
                                                                                                                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                    BrentSolver solver = new BrentSolver(function);
                                                                                                                                    solver.solve(1.0, 2.0, 3.0);
                                                                                                                                }

    @Test
                                                                                                                                public void testSolve_WhenYMinIsZero_ReturnsMin() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                    BrentSolver solver = new BrentSolver(function);
                                                                                                                                    
                                                                                                                                    when(function.value(1.0)).thenReturn(0.0);
                                                                                                                                    when(function.value(2.0)).thenReturn(1.0);
                                                                                                                                    
                                                                                                                                    double result = solver.solve(1.0, 2.0);
                                                                                                                                    assertEquals(1.0, result, 0.0001);
                                                                                                                                }

    @Test
                                                                                                                                public void testSolve_WhenSignsDifferent_CallsPrivateSolve() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                    BrentSolver solver = new BrentSolver(function);
                                                                                                                                    
                                                                                                                                    when(function.value(1.0)).thenReturn(-1.0);
                                                                                                                                    when(function.value(2.0)).thenReturn(1.0);
                                                                                                                                    
                                                                                                                                    double result = solver.solve(1.0, 2.0);
                                                                                                                                    
                                                                                                                                    verify(function, times(2)).value(anyDouble());
                                                                                                                                }

    @Test
                                                                                                                                public void testSolve_WhenYMinIsZeroWithinAccuracy_ReturnsMin() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                    BrentSolver solver = new BrentSolver(function);
                                                                                                                                    
                                                                                                                                    when(function.value(1.0)).thenReturn(1e-7);
                                                                                                                                    when(function.value(2.0)).thenReturn(1.0);
                                                                                                                                    
                                                                                                                                    double result = solver.solve(1.0, 2.0);
                                                                                                                                    assertEquals(1.0, result, 0.0001);
                                                                                                                                }

    @Test
                                                                                                                                public void testSolve_WhenBothYMinAndYMaxAreZero_ReturnsMin() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                    BrentSolver solver = new BrentSolver(function);
                                                                                                                                    
                                                                                                                                    when(function.value(1.0)).thenReturn(0.0);
                                                                                                                                    when(function.value(2.0)).thenReturn(0.0);
                                                                                                                                    
                                                                                                                                    double result = solver.solve(1.0, 2.0);
                                                                                                                                    assertEquals(1.0, result, 0.0001);
                                                                                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                public void testSolve_WhenMinEqualsMax_ThrowsException() throws Exception {
                                                                                                                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                    BrentSolver solver = new BrentSolver(function);
                                                                                                                                    solver.solve(1.0, 1.0);
                                                                                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                public void testSolve_WhenMinGreaterThanMax_ThrowsException() throws Exception {
                                                                                                                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                    BrentSolver solver = new BrentSolver(function);
                                                                                                                                    solver.solve(2.0, 1.0);
                                                                                                                                }

    @Test
                                                                                                                                public void testSolve_WhenSignsDifferentButOneIsZero_ReturnsRoot() throws Exception {
                                                                                                                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                    BrentSolver solver = new BrentSolver(function);
                                                                                                                                    
                                                                                                                                    when(function.value(1.0)).thenReturn(0.0);
                                                                                                                                    when(function.value(2.0)).thenReturn(1.0);
                                                                                                                                    
                                                                                                                                    double result = solver.solve(1.0, 2.0);
                                                                                                                                    assertEquals(1.0, result, 0.0001);
                                                                                                                                }

    @Test
                                                                                                                                public void testSolveConvergesWithY1WithinAccuracy() throws Exception {
                                                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                    BrentSolver solver = new BrentSolver(f);
                                                                                                                                    
                                                                                                                                    Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                        "solve", 
                                                                                                                                        double.class, 
                                                                                                                                        double.class, 
                                                                                                                                        double.class, 
                                                                                                                                        double.class, 
                                                                                                                                        double.class, 
                                                                                                                                        int.class
                                                                                                                                    );
                                                                                                                                    solveMethod.setAccessible(true);
                                                                                                                                    
                                                                                                                                    when(f.value(1.0)).thenReturn(0.0000001);
                                                                                                                                    double result = (double) solveMethod.invoke(solver, 0.0, 1.0, 1.0, 0.0000001, 2.0, 1.0);
                                                                                                                                    assertEquals(1.0, result, 0.0001);
                                                                                                                                }

    @Test
                                                                                                                                public void testSolveConvergesWithDXWithinTolerance() throws Exception {
                                                                                                                                    // Create mock function
                                                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                    
                                                                                                                                    // Create solver instance
                                                                                                                                    BrentSolver solver = new BrentSolver(f);
                                                                                                                                    
                                                                                                                                    // Get private solve method via reflection
                                                                                                                                    Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                        "solve", 
                                                                                                                                        double.class, 
                                                                                                                                        double.class, 
                                                                                                                                        double.class, 
                                                                                                                                        double.class, 
                                                                                                                                        double.class, 
                                                                                                                                        double.class
                                                                                                                                    );
                                                                                                                                    solveMethod.setAccessible(true);
                                                                                                                                    
                                                                                                                                    // Setup mock behavior
                                                                                                                                    when(f.value(1.0)).thenReturn(1.0);
                                                                                                                                    when(f.value(1.000001)).thenReturn(0.0000001);
                                                                                                                                    
                                                                                                                                    // Invoke method and verify result
                                                                                                                                    double result = (double) solveMethod.invoke(solver, 0.0, 1.0, 1.0, 1.0, 1.000001, 0.0000001);
                                                                                                                                    assertEquals(1.0, result, 0.0001);
                                                                                                                                }

    @Test
                                                                                                                                public void testSolveSwapsPointsWhenY2BetterThanY() throws Exception {
                                                                                                                                    // Create mock function
                                                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                    when(f.value(1.0)).thenReturn(1.0);
                                                                                                                                    when(f.value(1.1)).thenReturn(0.1);
                                                                                                                                    when(f.value(1.2)).thenReturn(0.01);
                                                                                                                                    
                                                                                                                                    // Create solver instance
                                                                                                                                    BrentSolver solver = new BrentSolver(f);
                                                                                                                                    
                                                                                                                                    // Set up reflection to access private solve method
                                                                                                                                    Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                        "solve", 
                                                                                                                                        double.class, double.class, 
                                                                                                                                        double.class, double.class, 
                                                                                                                                        double.class, double.class
                                                                                                                                    );
                                                                                                                                    solveMethod.setAccessible(true);
                                                                                                                                    
                                                                                                                                    // Invoke the method
                                                                                                                                    double result = (double) solveMethod.invoke(solver, 1.0, 1.0, 1.1, 0.1, 1.2, 0.01);
                                                                                                                                    
                                                                                                                                    // Assert the result
                                                                                                                                    assertTrue(result > 1.0 && result <= 1.2);
                                                                                                                                }

    @Test(expected = MaxIterationsExceededException.class)
                                                                                                                                public void testSolveThrowsWhenMaxIterationsExceeded() throws Exception {
                                                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                    BrentSolver solver = new BrentSolver(f);
                                                                                                                                    
                                                                                                                                    // Set maximal iterations to 1 to force exception
                                                                                                                                    Method setMaximalIterationsMethod = BrentSolver.class.getDeclaredMethod("setMaximalIterations", int.class);
                                                                                                                                    setMaximalIterationsMethod.setAccessible(true);
                                                                                                                                    setMaximalIterationsMethod.invoke(solver, 1);
                                                                                                                                    
                                                                                                                                    // Get private solve method
                                                                                                                                    Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                        "solve", 
                                                                                                                                        double.class, 
                                                                                                                                        double.class, 
                                                                                                                                        double.class, 
                                                                                                                                        double.class, 
                                                                                                                                        double.class, 
                                                                                                                                        double.class
                                                                                                                                    );
                                                                                                                                    solveMethod.setAccessible(true);
                                                                                                                                    
                                                                                                                                    when(f.value(anyDouble())).thenReturn(1.0);
                                                                                                                                    solveMethod.invoke(solver, 0.0, 1.0, 1.0, 1.0, 2.0, 1.0);
                                                                                                                                }

    @Test
                                                                                                                                public void testSolveUpdatesBracketWhenSameSign() throws Exception {
                                                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                    BrentSolver solver = new BrentSolver(f);
                                                                                                                                    
                                                                                                                                    Method solveMethod = BrentSolver.class.getDeclaredMethod("solve", 
                                                                                                                                        double.class, double.class, double.class, double.class, double.class, double.class);
                                                                                                                                    solveMethod.setAccessible(true);
                                                                                                                                    
                                                                                                                                    when(f.value(1.0)).thenReturn(1.0);
                                                                                                                                    when(f.value(1.5)).thenReturn(0.5);
                                                                                                                                    when(f.value(2.0)).thenReturn(0.25);
                                                                                                                                    double result = (double) solveMethod.invoke(solver, 1.0, 1.0, 1.5, 0.5, 2.0, 0.25);
                                                                                                                                    assertTrue(result > 1.0 && result < 2.0);
                                                                                                                                }

    @Test
                                                                                                                            public void testSolve_InitialGuessIsRoot() throws Exception {
                                                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                BrentSolver solver = new BrentSolver(function);
                                                                                                                                
                                                                                                                                // Set functionValueAccuracy to a small value to ensure test passes
                                                                                                                                solver.setFunctionValueAccuracy(1e-15);
                                                                                                                                
                                                                                                                                when(function.value(1.5)).thenReturn(0.0);
                                                                                                                                double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                                assertEquals(1.5, result, 0.0);
                                                                                                                            }

    @Test
                                                                                                                            public void testSolve_MinEndpointIsRoot() throws Exception {
                                                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                BrentSolver solver = new BrentSolver(function);
                                                                                                                                
                                                                                                                                when(function.value(1.0)).thenReturn(0.0);
                                                                                                                                when(function.value(1.5)).thenReturn(1.0);
                                                                                                                                double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                                assertEquals(1.0, result, 0.0);
                                                                                                                            }

    @Test
                                                                                                                            public void testSolve_MaxEndpointIsRoot() throws Exception {
                                                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                BrentSolver solver = new BrentSolver(function);
                                                                                                                                
                                                                                                                                when(function.value(2.0)).thenReturn(0.0);
                                                                                                                                when(function.value(1.5)).thenReturn(1.0);
                                                                                                                                when(function.value(1.0)).thenReturn(1.0);
                                                                                                                                double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                                assertEquals(2.0, result, 0.0);
                                                                                                                            }

    @Test
                                                                                                                            public void testSolve_MinAndInitialBracketRoot() throws Exception {
                                                                                                                                // Setup mock function
                                                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                when(function.value(1.0)).thenReturn(-1.0);
                                                                                                                                when(function.value(1.5)).thenReturn(1.0);
                                                                                                                                when(function.value(2.0)).thenReturn(1.0);
                                                                                                                                
                                                                                                                                // Create solver instance
                                                                                                                                BrentSolver solver = new BrentSolver(function);
                                                                                                                                
                                                                                                                                // Mock the private solve method behavior
                                                                                                                                BrentSolver spySolver = spy(solver);
                                                                                                                                doReturn(1.25).when(spySolver).solve(anyDouble(), anyDouble(), anyDouble());
                                                                                                                                
                                                                                                                                double result = spySolver.solve(1.0, 2.0, 1.5);
                                                                                                                                assertEquals(1.25, result, 0.0);
                                                                                                                            }

    @Test
                                                                                                                            public void testSolve_InitialAndMaxBracketRoot() throws Exception {
                                                                                                                                // Create mock function
                                                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                when(function.value(1.0)).thenReturn(1.0);
                                                                                                                                when(function.value(1.5)).thenReturn(-1.0);
                                                                                                                                when(function.value(2.0)).thenReturn(1.0);
                                                                                                                                
                                                                                                                                // Create solver instance
                                                                                                                                BrentSolver solver = new BrentSolver(function);
                                                                                                                                
                                                                                                                                // Mock the private solve method behavior
                                                                                                                                BrentSolver spySolver = spy(solver);
                                                                                                                                doReturn(1.75).when(spySolver).solve(anyDouble(), anyDouble(), anyDouble());
                                                                                                                                
                                                                                                                                double result = spySolver.solve(1.0, 2.0, 1.5);
                                                                                                                                assertEquals(1.75, result, 0.0);
                                                                                                                            }

    @Test
                                                                                                                            public void testSolve_FullBrentAlgorithm() throws Exception {
                                                                                                                                // Create mock function
                                                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                when(function.value(1.0)).thenReturn(1.0);
                                                                                                                                when(function.value(1.5)).thenReturn(1.0);
                                                                                                                                when(function.value(2.0)).thenReturn(1.0);
                                                                                                                                
                                                                                                                                // Create solver instance
                                                                                                                                BrentSolver solver = new BrentSolver(function);
                                                                                                                                
                                                                                                                                // Mock the private solve method behavior
                                                                                                                                BrentSolver spySolver = spy(solver);
                                                                                                                                doReturn(1.8).when(spySolver).solve(anyDouble(), anyDouble(), anyDouble());
                                                                                                                                
                                                                                                                                double result = spySolver.solve(1.0, 2.0, 1.5);
                                                                                                                                assertEquals(1.8, result, 0.0);
                                                                                                                            }

    @Test(expected = RuntimeException.class)
                                                                                                                            public void testSolve_MaxIterationsExceeded() throws Exception {
                                                                                                                                // Create mock function
                                                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                when(function.value(1.0)).thenReturn(1.0);
                                                                                                                                when(function.value(1.5)).thenReturn(1.0);
                                                                                                                                when(function.value(2.0)).thenReturn(1.0);
                                                                                                                                
                                                                                                                                // Create solver instance
                                                                                                                                BrentSolver solver = new BrentSolver(function);
                                                                                                                                
                                                                                                                                // Mock the private solve method to throw MaxIterationsExceededException
                                                                                                                                BrentSolver spySolver = spy(solver);
                                                                                                                                doThrow(new MaxIterationsExceededException(100)).when(spySolver)
                                                                                                                                    .solve(anyDouble(), anyDouble(), anyDouble());
                                                                                                                                
                                                                                                                                // Use reflection to access private method
                                                                                                                                try {
                                                                                                                                    java.lang.reflect.Method method = BrentSolver.class.getDeclaredMethod(
                                                                                                                                        "solve", double.class, double.class, double.class);
                                                                                                                                    method.setAccessible(true);
                                                                                                                                    method.invoke(spySolver, 1.0, 2.0, 1.0);
                                                                                                                                } catch (Exception e) {
                                                                                                                                    throw new RuntimeException(e);
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                                                            public void testSolve_WhenYMaxIsZeroWithinAccuracy_ReturnsMax() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                MonitoredFunction monitoredFunction = new MonitoredFunction(function);
                                                                                                                                BrentSolver solver = new BrentSolver(monitoredFunction);
                                                                                                                                
                                                                                                                                solver.setFunctionValueAccuracy(1e-6);
                                                                                                                                
                                                                                                                                when(function.value(1.0)).thenReturn(-1.0);
                                                                                                                                when(function.value(2.0)).thenReturn(1e-7);
                                                                                                                                
                                                                                                                                double result = solver.solve(1.0, 2.0);
                                                                                                                                assertEquals(2.0, result, 0.0001);
                                                                                                                            }

    @Test
                                                                                                                            public void testSolveUsesBisectionWhenOldDeltaSmall() throws Exception {
                                                                                                                                // Setup mock function
                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                when(f.value(1.0)).thenReturn(1.0);
                                                                                                                                when(f.value(1.5)).thenReturn(0.5);
                                                                                                                                when(f.value(2.0)).thenReturn(-0.5);
                                                                                                                            
                                                                                                                                // Create solver instance
                                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                                
                                                                                                                                // Set up reflection to access private solve method
                                                                                                                                Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                    "solve", 
                                                                                                                                    double.class, double.class, double.class, 
                                                                                                                                    double.class, double.class, double.class
                                                                                                                                );
                                                                                                                                solveMethod.setAccessible(true);
                                                                                                                            
                                                                                                                                // Invoke the method
                                                                                                                                double result = (double) solveMethod.invoke(
                                                                                                                                    solver, 
                                                                                                                                    0.0, 1.0, 1.0, 1.0, 2.0, -0.5
                                                                                                                                );
                                                                                                                            
                                                                                                                                // Verify result
                                                                                                                                assertTrue(result > 1.0 && result < 2.0);
                                                                                                                            }

    @Test
                                                                                                                            public void testSolveUsesLinearInterpolation() throws Exception {
                                                                                                                                // Create mock function
                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                
                                                                                                                                // Setup mock behavior
                                                                                                                                when(f.value(1.0)).thenReturn(1.0);
                                                                                                                                when(f.value(1.5)).thenReturn(0.0);
                                                                                                                                when(f.value(2.0)).thenReturn(1.0);
                                                                                                                            
                                                                                                                                // Create solver instance
                                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                            
                                                                                                                                // Get private solve method via reflection
                                                                                                                                Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                    "solve", 
                                                                                                                                    double.class, double.class, double.class, double.class, double.class, double.class
                                                                                                                                );
                                                                                                                                solveMethod.setAccessible(true);
                                                                                                                            
                                                                                                                                // Invoke the method
                                                                                                                                double result = (double) solveMethod.invoke(
                                                                                                                                    solver, 
                                                                                                                                    1.0, 1.0, 2.0, 1.0, 1.0, 1.0
                                                                                                                                );
                                                                                                                            
                                                                                                                                // Verify result
                                                                                                                                assertEquals(1.5, result, 0.0001);
                                                                                                                            }

    @Test
                                                                                                                            public void testSolveUsesInverseQuadraticInterpolation() throws Exception {
                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                Object solver = Class.forName("org.apache.commons.math.analysis.BrentSolver")
                                                                                                                                                   .getDeclaredConstructor()
                                                                                                                                                   .newInstance();
                                                                                                                                
                                                                                                                                Method solveMethod = solver.getClass().getDeclaredMethod(
                                                                                                                                    "solve", 
                                                                                                                                    UnivariateRealFunction.class,
                                                                                                                                    double.class, double.class, double.class, 
                                                                                                                                    double.class, double.class, double.class
                                                                                                                                );
                                                                                                                                solveMethod.setAccessible(true);
                                                                                                                        
                                                                                                                                when(f.value(1.0)).thenReturn(1.0);
                                                                                                                                when(f.value(1.5)).thenReturn(0.5);
                                                                                                                                when(f.value(2.0)).thenReturn(-0.5);
                                                                                                                                when(f.value(1.75)).thenReturn(0.0);
                                                                                                                                
                                                                                                                                double result = (double) solveMethod.invoke(solver, f, 1.0, 1.0, 1.5, 0.5, 2.0, -0.5);
                                                                                                                                assertEquals(1.75, result, 0.1);
                                                                                                                            }

    @Test(expected = FunctionEvaluationException.class)
                                                                                            public void testSolve_FunctionEvaluationException() throws Exception {
                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                            }

    @Test(expected = org.apache.commons.math.FunctionEvaluationException.class)
                                                                                            public void testSolve_WhenSignsSameAndNotCloseToZero_ThrowsException() throws Exception {
                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                
                                                                                                when(function.value(1.0)).thenReturn(1.0);
                                                                                                when(function.value(2.0)).thenReturn(2.0);
                                                                                                
                                                                                            }

    @Test
                        public void testSolveUsesToleranceWhenDeltaSmall() throws Exception {
                            // Setup solver
                            UnivariateRealFunction dummyFunction = mock(UnivariateRealFunction.class);
                            BrentSolver solver = new BrentSolver(dummyFunction);
                            solver.setAbsoluteAccuracy(1e-6);
                            
                            // Create mock function that crosses zero at x=0.5
                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                            when(function.value(0.0)).thenReturn(-1.0);
                            when(function.value(1.0)).thenReturn(1.0);
                            when(function.value(0.5)).thenReturn(0.0);
                            
                            // Set very small absolute accuracy
                            solver.setAbsoluteAccuracy(1e-12);
                            // Create new solver with the mock function
                            solver = new BrentSolver(function);
                            
                            // Solve with small interval
                            double result = solver.solve(0.0, 1.0);
                            
                            // Verify result is within tolerance
                            assertEquals(0.5, result, 1e-12);
                        }

    @Test
        public void testSolve_WhenYMaxIsZero_ReturnsMax() throws Exception {
            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
            UnivariateRealSolver solver = new BrentSolver(function);
            
            when(function.value(1.0)).thenReturn(-1.0);
            when(function.value(2.0)).thenReturn(0.0);
            
            double result = solver.solve(1.0, 2.0);
            assertEquals(2.0, result, 0.0001);
        }


}
