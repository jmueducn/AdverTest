package gentest.org.apache.commons.math.optimization.univariate.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.optimization.univariate.*;
import java.util.Arrays;
import java.util.Comparator;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.analysis.UnivariateRealFunction;
import org.apache.commons.math.exception.MathIllegalStateException;
import org.apache.commons.math.exception.ConvergenceException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.random.RandomGenerator;
import org.apache.commons.math.optimization.GoalType;
import org.apache.commons.math.optimization.ConvergenceChecker;
import org.apache.commons.math.util.FastMath;
 
public class MultiStartUnivariateRealOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                public void testOptimizeCallsOverloadedMethodWithCorrectStartValue() throws Exception {
                                                                                                                    // Setup
                                                                                                                    MultiStartUnivariateRealOptimizer optimizer = mock(MultiStartUnivariateRealOptimizer.class);
                                                                                                                    UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                    double min = 0.0;
                                                                                                                    double max = 10.0;
                                                                                                                    double expectedStartValue = min + 0.5 * (max - min);
                                                                                                                    UnivariateRealPointValuePair expectedResult = new UnivariateRealPointValuePair(5.0, 10.0);
                                                                                                                    
                                                                                                                    when(optimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), anyDouble(), anyDouble(), anyDouble()))
                                                                                                                        .thenReturn(expectedResult);
                                                                                                                    
                                                                                                                    // Test
                                                                                                                    UnivariateRealPointValuePair result = optimizer.optimize(mockFunction, GoalType.MINIMIZE, min, max);
                                                                                                                    
                                                                                                                    // Verify
                                                                                                                    assertEquals(expectedResult, result);
                                                                                                                    verify(optimizer).optimize(mockFunction, GoalType.MINIMIZE, min, max, expectedStartValue);
                                                                                                                }

    @Test
                                                                                                                public void testOptimizeWithSingleStart() throws Exception {
                                                                                                                    // Setup
                                                                                                                    UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                                                                                                                    RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                                                                    MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer<>(mockOptimizer, 1, mockGenerator);
                                                                                                                    UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                    
                                                                                                                    double min = 0.0;
                                                                                                                    double max = 10.0;
                                                                                                                    double expectedStartValue = min + 0.5 * (max - min);
                                                                                                                    UnivariateRealPointValuePair expectedResult = new UnivariateRealPointValuePair(5.0, 10.0);
                                                                                                                    
                                                                                                                    when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), anyDouble(), anyDouble(), anyDouble()))
                                                                                                                        .thenReturn(expectedResult);
                                                                                                                    
                                                                                                                    // Test
                                                                                                                    UnivariateRealPointValuePair result = optimizer.optimize(mockFunction, GoalType.MINIMIZE, min, max);
                                                                                                                    
                                                                                                                    // Verify
                                                                                                                    assertEquals(expectedResult, result);
                                                                                                                    verify(mockOptimizer).optimize(mockFunction, GoalType.MINIMIZE, min, max, expectedStartValue);
                                                                                                                }

    @Test
                                                                                                                public void testOptimizeUpdatesTotalEvaluations() throws Exception {
                                                                                                                    // Setup
                                                                                                                    double min = 0.0;
                                                                                                                    double max = 10.0;
                                                                                                                    int evaluationsPerRun = 10;
                                                                                                                    int starts = 5;
                                                                                                                    
                                                                                                                    UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                                                                                                                    RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                                                                    UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                    
                                                                                                                    MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer<>(mockOptimizer, starts, mockGenerator);
                                                                                                                    
                                                                                                                    UnivariateRealPointValuePair expectedResult = new UnivariateRealPointValuePair(5.0, 10.0);
                                                                                                                    when(mockOptimizer.optimize(any(), any(), anyDouble(), anyDouble(), anyDouble()))
                                                                                                                        .thenReturn(expectedResult);
                                                                                                                    when(mockOptimizer.getEvaluations()).thenReturn(evaluationsPerRun);
                                                                                                                    
                                                                                                                    // Test
                                                                                                                    optimizer.optimize(mockFunction, GoalType.MINIMIZE, min, max);
                                                                                                                    
                                                                                                                    // Verify
                                                                                                                    assertEquals(starts * evaluationsPerRun, optimizer.getEvaluations());
                                                                                                                }

    @Test(expected = IllegalStateException.class)
                                                                                                            public void testGetOptimaBeforeOptimizeThrowsException() {
                                                                                                                MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(
                                                                                                                    mock(org.apache.commons.math.optimization.univariate.UnivariateRealOptimizer.class),
                                                                                                                    10,
                                                                                                                    mock(org.apache.commons.math.random.RandomGenerator.class)
                                                                                                                );
                                                                                                                optimizer.getOptima();
                                                                                                            }

    @Test
                                                                                                            public void testOptimizeHandlesFunctionEvaluationException() throws Exception {
                                                                                                                // Setup mocks and test data
                                                                                                                UnivariateRealOptimizer mockOptimizer = 
                                                                                                                    mock(UnivariateRealOptimizer.class);
                                                                                                                UnivariateRealFunction mockFunction = 
                                                                                                                    mock(UnivariateRealFunction.class);
                                                                                                                RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                                                                
                                                                                                                // Create optimizer instance with 2 starts
                                                                                                                org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer optimizer = 
                                                                                                                    new org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer(
                                                                                                                        mockOptimizer, 2, mockGenerator);
                                                                                                                
                                                                                                                final double MIN = 0.0;
                                                                                                                final double MAX = 10.0;
                                                                                                                final double START_VALUE = 5.0;
                                                                                                            
                                                                                                                // Configure mocks
                                                                                                                when(mockOptimizer.optimize(any(), any(), anyDouble(), anyDouble(), anyDouble()))
                                                                                                                    .thenThrow(new org.apache.commons.math.FunctionEvaluationException(0.0))
                                                                                                                    .thenReturn(new UnivariateRealPointValuePair(3.0, 1.0));
                                                                                                                when(mockGenerator.nextDouble()).thenReturn(0.5);
                                                                                                                when(mockOptimizer.getEvaluations()).thenReturn(10);
                                                                                                            
                                                                                                                // Execute test
                                                                                                                UnivariateRealPointValuePair result = optimizer.optimize(mockFunction, GoalType.MINIMIZE, MIN, MAX, START_VALUE);
                                                                                                            
                                                                                                                // Verify results
                                                                                                                assertNotNull(result);
                                                                                                                assertEquals(20, optimizer.getEvaluations());
                                                                                                            }

    @Test
                                                                        public void testOptimizeFirstStartUsesStartValue() throws Exception {
                                                                            // Define constants
                                                                            final double MIN = 0.0;
                                                                            final double MAX = 10.0;
                                                                            final double START_VALUE = 5.0;
                                                                            final int numStarts = 1;
                                                                            
                                                                            // Create mocks
                                                                            UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                                                                            UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                            
                                                                            // Create test instance
                                                                            MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(
                                                                                mockOptimizer, numStarts, null);
                                                                            
                                                                            // Setup mock behavior
                                                                            when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class),
                                                                                anyDouble(), anyDouble(), anyDouble()))
                                                                                .thenReturn(new UnivariateRealPointValuePair(0, 0));
                                                                            when(mockOptimizer.getEvaluations()).thenReturn(10);
                                                                        
                                                                            // Execute test
                                                                            optimizer.optimize(mockFunction, GoalType.MINIMIZE, MIN, MAX, START_VALUE);
                                                                        
                                                                            // Verify
                                                                            verify(mockOptimizer).optimize(mockFunction, GoalType.MINIMIZE, MIN, MAX, START_VALUE);
                                                                        }

    @Test
                                                                    public void testOptimizeSuccess() throws Exception {
                                                                        // Define constants
                                                                        final int STARTS = 3;
                                                                        final double MIN = 0.0;
                                                                        final double MAX = 5.0;
                                                                        final double START_VALUE = 2.0;
                                                                        
                                                                        // Create mocks
                                                                        UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                                                                        RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                        UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                        
                                                                        // Create test instance
                                                                        MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(mockOptimizer, STARTS, mockGenerator);
                                                                        
                                                                        // Setup test data and expectations
                                                                        UnivariateRealPointValuePair expectedResult = new UnivariateRealPointValuePair(3.0, 1.0);
                                                                        when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), anyDouble(), anyDouble(), anyDouble()))
                                                                            .thenReturn(expectedResult);
                                                                        when(mockGenerator.nextDouble()).thenReturn(0.5);
                                                                        when(mockOptimizer.getEvaluations()).thenReturn(10);
                                                                    
                                                                        // Execute test
                                                                        UnivariateRealPointValuePair result = optimizer.optimize(mockFunction, GoalType.MINIMIZE, MIN, MAX, START_VALUE);
                                                                    
                                                                        // Verify results
                                                                        assertEquals(expectedResult, result);
                                                                        assertEquals(30, optimizer.getEvaluations());
                                                                        verify(mockOptimizer, times(STARTS)).optimize(any(UnivariateRealFunction.class), any(GoalType.class), anyDouble(), anyDouble(), anyDouble());
                                                                    }

    @Test
                                                                    public void testOptimizeHandlesConvergenceException() throws Exception {
                                                                        // Define constants
                                                                        final double MIN = -10.0;
                                                                        final double MAX = 10.0;
                                                                        final double START_VALUE = 0.0;
                                                                        
                                                                        // Create mocks
                                                                        UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                                                                        UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                        RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                        
                                                                        // Create optimizer under test
                                                                        MultiStartUnivariateRealOptimizer optimizer = 
                                                                            new MultiStartUnivariateRealOptimizer(
                                                                                mockOptimizer, 2, mockGenerator);
                                                                        
                                                                        // Setup mock behavior
                                                                        when(mockOptimizer.optimize(any(UnivariateRealFunction.class), 
                                                                                                   any(GoalType.class), 
                                                                                                   anyDouble(), 
                                                                                                   anyDouble(), 
                                                                                                   anyDouble()))
                                                                            .thenThrow(new ConvergenceException())
                                                                            .thenReturn(new UnivariateRealPointValuePair(3.0, 1.0));
                                                                        when(mockGenerator.nextDouble()).thenReturn(0.5);
                                                                        when(mockOptimizer.getEvaluations()).thenReturn(10);
                                                                    
                                                                        UnivariateRealPointValuePair result = optimizer.optimize(mockFunction, GoalType.MINIMIZE, MIN, MAX, START_VALUE);
                                                                    
                                                                        assertNotNull(result);
                                                                        assertEquals(20, optimizer.getEvaluations());
                                                                    }

    @Test(expected = ConvergenceException.class)
                                                                    public void testOptimizeThrowsWhenAllStartsFail() throws Exception {
                                                                        // Define constants
                                                                        final double MIN = 0.0;
                                                                        final double MAX = 10.0;
                                                                        final double START_VALUE = 5.0;
                                                                        
                                                                        // Create mocks
                                                                        UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                                                                        RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                        
                                                                        // Create test object
                                                                        MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(
                                                                            mockOptimizer, 1, mockGenerator);
                                                                        
                                                                        // Mock behavior
                                                                        when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), 
                                                                            anyDouble(), anyDouble(), anyDouble()))
                                                                            .thenThrow(new ConvergenceException());
                                                                        when(mockGenerator.nextDouble()).thenReturn(0.5);
                                                                        when(mockOptimizer.getEvaluations()).thenReturn(10);
                                                                        
                                                                        // Test
                                                                        optimizer.optimize(mock(UnivariateRealFunction.class), 
                                                                                          GoalType.MINIMIZE, MIN, MAX, START_VALUE);
                                                                    }

    @Test
                                                                    public void testOptimizeSubsequentStartsUseRandomValue() throws Exception {
                                                                        // Define constants inside the method
                                                                        final double MIN = 0.0;
                                                                        final double MAX = 10.0;
                                                                        final double START_VALUE = 1.0;
                                                                        
                                                                        // Create mocks
                                                                        UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                                                                        RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                        UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                        
                                                                        // Setup test
                                                                        when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), anyDouble(), anyDouble(), anyDouble()))
                                                                            .thenReturn(new UnivariateRealPointValuePair(0, 0));
                                                                        when(mockOptimizer.getEvaluations()).thenReturn(10);
                                                                        when(mockGenerator.nextDouble()).thenReturn(0.5);
                                                                        
                                                                        // Create optimizer instance (simplified for test)
                                                                        MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(
                                                                            mockOptimizer, 2, mockGenerator);
                                                                        
                                                                        // Execute test
                                                                        optimizer.optimize(mockFunction, GoalType.MINIMIZE, MIN, MAX, START_VALUE);
                                                                        
                                                                        // Verify
                                                                        verify(mockOptimizer).optimize(mockFunction, GoalType.MINIMIZE, MIN, MAX, START_VALUE);
                                                                    }

    @Test
                                                        public void testSortPairsMaximize() throws Exception {
                                                            // Create a mock RandomGenerator
                                                            RandomGenerator generator = new RandomGenerator() {
                                                                public void setSeed(long seed) {}
                                                                public void setSeed(int[] seed) {}
                                                                public void nextBytes(byte[] bytes) {}
                                                                public int nextInt() { return 0; }
                                                                public int nextInt(int n) { return 0; }
                                                                public long nextLong() { return 0L; }
                                                                public boolean nextBoolean() { return false; }
                                                                public float nextFloat() { return 0f; }
                                                                public double nextDouble() { return 0d; }
                                                                public double nextGaussian() { return 0d; }
                                                                public int next(int bits) { return 0; }
                                                                public void setSeed(int seed) {}  // Added missing method
                                                            };
                                                        
                                                            // Create a mock optimizer with reflection
                                                            MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(
                                                                new org.apache.commons.math.optimization.univariate.UnivariateRealOptimizer() {
                                                                    public UnivariateRealPointValuePair optimize(
                                                                        org.apache.commons.math.analysis.UnivariateRealFunction f,
                                                                        GoalType goalType, double min, double max) {
                                                                        return null;
                                                                    }
                                                                    public UnivariateRealPointValuePair optimize(
                                                                        org.apache.commons.math.analysis.UnivariateRealFunction f,
                                                                        GoalType goalType, double min, double max, double startValue) {
                                                                        return null;
                                                                    }
                                                                    public void setMaxEvaluations(int maxEvaluations) {}
                                                                    public int getMaxEvaluations() { return 0; }
                                                                    public int getEvaluations() { return 0; }
                                                                    public void setMaximalIterationCount(int maxIterations) {}
                                                                    public int getMaximalIterationCount() { return 0; }
                                                                    public int getIterationCount() { return 0; }
                                                                    public org.apache.commons.math.optimization.ConvergenceChecker getConvergenceChecker() { return null; }
                                                                    public void setConvergenceChecker(org.apache.commons.math.optimization.ConvergenceChecker checker) {}
                                                                }, 
                                                                10,  // number of starts
                                                                generator  // generator
                                                            );
                                                        
                                                            UnivariateRealPointValuePair[] pairs = new UnivariateRealPointValuePair[] {
                                                                new UnivariateRealPointValuePair(0, 1.0),
                                                                null,
                                                                new UnivariateRealPointValuePair(0, 3.0),
                                                                new UnivariateRealPointValuePair(0, 2.0)
                                                            };
                                                        
                                                            // Use reflection to access private field and method
                                                            Field optimaField = optimizer.getClass().getDeclaredField("optima");
                                                            optimaField.setAccessible(true);
                                                            optimaField.set(optimizer, pairs);
                                                        
                                                            Method sortPairs = optimizer.getClass().getDeclaredMethod("sortPairs", GoalType.class);
                                                            sortPairs.setAccessible(true);
                                                            sortPairs.invoke(optimizer, GoalType.MAXIMIZE);
                                                        
                                                            // Get the sorted optima array back via reflection
                                                            UnivariateRealPointValuePair[] sortedOptima = (UnivariateRealPointValuePair[]) optimaField.get(optimizer);
                                                        
                                                            assertEquals(3.0, sortedOptima[0].getValue(), 0.0);
                                                            assertEquals(2.0, sortedOptima[1].getValue(), 0.0);
                                                            assertEquals(1.0, sortedOptima[2].getValue(), 0.0);
                                                            assertNull(sortedOptima[3]);
                                                        }

    @Test
                                                    public void testOptimizeSetsMaxEvaluationsCorrectly() throws Exception {
                                                        // Setup
                                                        @SuppressWarnings("unchecked")
                                                        UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                                                        UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                        RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                        MultiStartUnivariateRealOptimizer<UnivariateRealFunction> optimizer = 
                                                            new MultiStartUnivariateRealOptimizer<UnivariateRealFunction>(mockOptimizer, 1, mockRandom);
                                                        
                                                        double min = 0.0;
                                                        double max = 10.0;
                                                        int maxEval = 100;
                                                        optimizer.setMaxEvaluations(maxEval);
                                                        
                                                        UnivariateRealPointValuePair expectedResult = new UnivariateRealPointValuePair(5.0, 10.0);
                                                        when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), eq(min), eq(max)))
                                                            .thenReturn(expectedResult);
                                                        when(mockOptimizer.getEvaluations()).thenReturn(10);
                                                        
                                                        // Test
                                                        optimizer.optimize(mockFunction, GoalType.MINIMIZE, min, max);
                                                        
                                                        // Verify
                                                        verify(mockOptimizer).setMaxEvaluations(maxEval);
                                                        verify(mockOptimizer, atLeastOnce()).getEvaluations();
                                                    }

    @Test(expected = Exception.class)
                public void testOptimizePropagatesFunctionEvaluationException() throws Exception {
                    // Setup
                    double min = 0.0;
                    double max = 10.0;
                    int numIterations = 1;
                    int maxEvaluations = 1000;
                    UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                    RandomGenerator mockRandom = mock(RandomGenerator.class);
                    
                    MultiStartUnivariateRealOptimizer optimizer = 
                        new MultiStartUnivariateRealOptimizer(mockOptimizer, numIterations, mockRandom);
                    
                    when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), 
                        eq(min), eq(max))).thenThrow(new Exception());
                    
                    // Test
                    optimizer.optimize(mock(UnivariateRealFunction.class), GoalType.MAXIMIZE, min, max);
                }

    @Test
        public void testSortPairsMinimize() throws Exception {
            // Create mock optimizer instance
            BrentOptimizer underlying = new BrentOptimizer(1e-10, 1e-14);
            MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(
                underlying, 
                10, 
                new org.apache.commons.math.random.RandomGenerator() {
                    public void setSeed(long seed) {}
                    public void setSeed(int[] seed) {}
                    public void setSeed(int seed) {}  // Added missing method
                    public void nextBytes(byte[] bytes) {}
                    public int nextInt() { return 0; }
                    public int nextInt(int n) { return 0; }
                    public long nextLong() { return 0; }
                    public boolean nextBoolean() { return false; }
                    public float nextFloat() { return 0; }
                    public double nextDouble() { return 0; }
                    public double nextGaussian() { return 0; }
                }
            );
            
            UnivariateRealPointValuePair[] pairs = new UnivariateRealPointValuePair[] {
                new UnivariateRealPointValuePair(0, 3.0),
                null,
                new UnivariateRealPointValuePair(0, 1.0),
                new UnivariateRealPointValuePair(0, 2.0)
            };
            
            // Set private optima field using reflection
            Field optimaField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("optima");
            optimaField.setAccessible(true);
            optimaField.set(optimizer, pairs);
            
            // Create GoalType enum instance
            GoalType minimize = GoalType.MINIMIZE;
            
            // Invoke private sortPairs method
            Method sortPairs = MultiStartUnivariateRealOptimizer.class.getDeclaredMethod("sortPairs", GoalType.class);
            sortPairs.setAccessible(true);
            sortPairs.invoke(optimizer, minimize);
            
            // Get sorted result
            UnivariateRealPointValuePair[] result = (UnivariateRealPointValuePair[]) optimaField.get(optimizer);
            
            // Verify results
            assertEquals(1.0, result[0].getValue(), 0.0);
            assertEquals(2.0, result[1].getValue(), 0.0);
            assertEquals(3.0, result[2].getValue(), 0.0);
            assertNull(result[3]);
        }


}
