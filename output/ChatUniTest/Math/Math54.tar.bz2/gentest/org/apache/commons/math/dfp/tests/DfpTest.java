package gentest.org.apache.commons.math.dfp.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.dfp.*;
import java.util.Arrays;
import org.apache.commons.math.FieldElement;
 
public class DfpTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                        public void testOne() {
                            DfpField field = new DfpField(100);
                            Dfp one = field.newDfp(1.0);
                            assertEquals(1.0, one.toDouble(), 0.0);
                            assertEquals(-1.0, one.negate().toDouble(), 0.0);
                        }

    @Test
                        public void testTwo() {
                            DfpField field = new DfpField(100);
                            Dfp two = field.newDfp(2.0);
                            assertEquals(2.0, two.toDouble(), 0.0);
                            assertEquals(-2.0, two.negate().toDouble(), 0.0);
                        }

    @Test
                        public void testNaN() {
                            DfpField field = new DfpField(100);
                            Dfp nan = field.newDfp(Double.NaN);
                            assertTrue(Double.isNaN(nan.toDouble()));
                        }

    @Test
                    public void testSmallNumbers() {
                        DfpField field = new DfpField(100);
                        Dfp small = field.newDfp("0.000000000000123456789");
                        assertEquals(1.23456789E-13, small.toDouble(), 1E-21);
                    }

    @Test
                    public void testLargeNumbers() {
                        DfpField field = new DfpField(100);
                        Dfp large = field.newDfp("12345678901234567890");
                        assertEquals(1.2345678901234567E19, large.toDouble(), 1E11);
                    }

    @Test
                    public void testSubnormalRange() {
                        DfpField field = new DfpField(100);
                        Dfp subnormal = field.newDfp("1.0E-320");
                        assertEquals(0.0, subnormal.toDouble(), 0.0);
                    }

    @Test
                    public void testNormalRange() {
                        DfpField field = new DfpField(20);
                        Dfp normal = field.newDfp("1.234567890123456789");
                        assertEquals(1.2345678901234567, normal.toDouble(), 1E-16);
                    }

    @Test
                    public void testExponentBoundaries() {
                        DfpField field = new DfpField(100);
                        Dfp maxValue = field.newDfp("1.7976931348623157E308");
                        assertEquals(Double.MAX_VALUE, maxValue.toDouble(), 1E292);
                        
                        Dfp minNormal = field.newDfp("2.2250738585072014E-308");
                        assertEquals(Double.MIN_NORMAL, minNormal.toDouble(), 1E-320);
                    }

    @Test
                    public void testRounding() {
                        DfpField field = new DfpField(20);
                        Dfp precise = field.newDfp("1.0000000000000001");
                        assertEquals(1.0, precise.toDouble(), 0.0);
                        
                        Dfp precise2 = field.newDfp("1.0000000000000002");
                        assertEquals(1.0, precise2.toDouble(), 0.0);
                    }

    @Test
                    public void testSpecialCases() {
                        // Create DfpField instance
                        DfpField field = new DfpField(100);
                        
                        // Test power of two exactly representable in double
                        Dfp powerOfTwo = field.newDfp("0.5");
                        assertEquals(0.5, powerOfTwo.toDouble(), 0.0);
                    
                        // Test non-power of two
                        Dfp nonPowerOfTwo = field.newDfp("0.1");
                        assertEquals(0.1, nonPowerOfTwo.toDouble(), 1E-17);
                    }

    @Test
                    public void testNegativeNumbers() {
                        DfpField field = new DfpField(100);
                        Dfp neg = field.newDfp("-123.456");
                        assertEquals(-123.456, neg.toDouble(), 1E-14);
                    }

    @Test
                    public void testDenormalizedNumbers() {
                        DfpField field = new DfpField(100);
                        Dfp denormal = field.newDfp("1.0E-310");
                        assertTrue(denormal.toDouble() > 0.0);
                        assertTrue(denormal.toDouble() < Double.MIN_NORMAL);
                    }

    @Test
                    public void testExponentOverflow() {
                        DfpField field = new DfpField(100);
                        Dfp huge = field.newDfp("1.0E400");
                        assertEquals(Double.POSITIVE_INFINITY, huge.toDouble(), 0.0);
                        
                        Dfp tiny = field.newDfp("-1.0E400");
                        assertEquals(Double.NEGATIVE_INFINITY, tiny.toDouble(), 0.0);
                    }

    @Test
            public void testExponentUnderflow() {
                DfpField field = new DfpField(100);
                Dfp tiny = field.newDfp("1.0E-400");
                assertEquals(0.0, tiny.toDouble(), 0.0);
            }

    @Test
            public void testZero() {
                // Create DfpField and Dfp instances properly within the test method
                DfpField field = new DfpField(100);
                Dfp zero = field.newDfp(0.0);
                assertEquals(0.0, zero.toDouble(), 0.0);
                assertEquals(-0.0, zero.negate().toDouble(), 0.0);
            }

    @Test
            public void testNegativeInfinity() {
                DfpField field = new DfpField(100);
                Dfp negInf = field.newDfp();
                negInf = field.newDfp(Double.NEGATIVE_INFINITY);
                assertEquals(Double.NEGATIVE_INFINITY, negInf.toDouble(), 0.0);
            }

    @Test
        public void testPositiveInfinity() {
            DfpField field = new DfpField(100);
            Dfp posInf = field.newDfp();
            posInf = field.newDfp("1").divide(field.newDfp("0")); // This creates positive infinity
            assertEquals(Double.POSITIVE_INFINITY, posInf.toDouble(), 0.0);
        }


}
