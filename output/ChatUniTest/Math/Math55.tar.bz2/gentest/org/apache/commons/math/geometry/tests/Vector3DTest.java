package gentest.org.apache.commons.math.geometry.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.geometry.*;
import java.io.Serializable;
import org.apache.commons.math.exception.MathArithmeticException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class Vector3DTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testCrossProduct_ZeroVectors() {
            Vector3D v1 = Vector3D.ZERO;
            Vector3D v2 = Vector3D.ZERO;
            Vector3D result = Vector3D.crossProduct(v1, v2);
            assertEquals(Vector3D.ZERO, result);
        }

    @Test
        public void testCrossProduct_OneZeroVector() {
            Vector3D v1 = new Vector3D(1, 2, 3);
            Vector3D v2 = Vector3D.ZERO;
            Vector3D result = Vector3D.crossProduct(v1, v2);
            assertEquals(Vector3D.ZERO, result);
        }

    @Test
        public void testCrossProduct_VerySmallVectors() {
            Vector3D v1 = new Vector3D(Double.MIN_VALUE, Double.MIN_VALUE, Double.MIN_VALUE);
            Vector3D v2 = new Vector3D(Double.MIN_VALUE, Double.MIN_VALUE, Double.MIN_VALUE);
            Vector3D result = Vector3D.crossProduct(v1, v2);
            assertEquals(Vector3D.ZERO, result);
        }

    @Test
        public void testCrossProduct_OrthogonalVectors() {
            Vector3D v1 = new Vector3D(1, 0, 0);
            Vector3D v2 = new Vector3D(0, 1, 0);
            Vector3D expected = new Vector3D(0, 0, 1);
            Vector3D result = Vector3D.crossProduct(v1, v2);
            assertEquals(expected, result);
        }

    @Test
        public void testCrossProduct_ParallelVectors() {
            Vector3D v1 = new Vector3D(1, 2, 3);
            Vector3D v2 = new Vector3D(2, 4, 6);
            Vector3D result = Vector3D.crossProduct(v1, v2);
            assertEquals(Vector3D.ZERO, result);
        }

    @Test
        public void testCrossProduct_GeneralCase() {
            Vector3D v1 = new Vector3D(1, 2, 3);
            Vector3D v2 = new Vector3D(4, 5, 6);
            Vector3D expected = new Vector3D(-3, 6, -3);
            Vector3D result = Vector3D.crossProduct(v1, v2);
            assertEquals(expected, result);
        }

    @Test
        public void testCrossProduct_DifferentMagnitudes() {
            Vector3D v1 = new Vector3D(1e-100, 2e-100, 3e-100);
            Vector3D v2 = new Vector3D(4e100, 5e100, 6e100);
            Vector3D result = Vector3D.crossProduct(v1, v2);
            // The exact expected values might need adjustment based on the scaling behavior
            assertNotEquals(Vector3D.ZERO, result);
        }

    @Test
        public void testCrossProduct_AntiCommutative() {
            Vector3D v1 = new Vector3D(1, 2, 3);
            Vector3D v2 = new Vector3D(4, 5, 6);
            Vector3D result1 = Vector3D.crossProduct(v1, v2);
            Vector3D result2 = Vector3D.crossProduct(v2, v1);
            assertEquals(result1, result2.negate());
        }

    @Test
        public void testCrossProduct_WithCanonicalVectors() {
            Vector3D i = Vector3D.PLUS_I;
            Vector3D j = Vector3D.PLUS_J;
            Vector3D k = Vector3D.PLUS_K;
            
            assertEquals(k, Vector3D.crossProduct(i, j));
            assertEquals(i.negate(), Vector3D.crossProduct(j, k));
            assertEquals(j.negate(), Vector3D.crossProduct(k, i));
        }

    @Test
        public void testCrossProduct_WithDifferentExponents() {
            Vector3D v1 = new Vector3D(1e50, 2e50, 3e50);
            Vector3D v2 = new Vector3D(1e-50, 2e-50, 3e-50);
            Vector3D result = Vector3D.crossProduct(v1, v2);
            // Should not be zero despite the large exponent difference
            assertNotEquals(Vector3D.ZERO, result);
        }

}
