package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import org.apache.commons.math.util.MathUtils;
 
public class ComplexTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testEqualsSameObject() {
            Complex c = new Complex(1.0, 2.0);
            assertTrue(c.equals(c));
        }

    @Test
        public void testEqualsNull() {
            Complex c = new Complex(1.0, 2.0);
            assertFalse(c.equals(null));
        }

    @Test
        public void testEqualsDifferentClass() {
            Complex c = new Complex(1.0, 2.0);
            assertFalse(c.equals("not a complex number"));
        }

    @Test
        public void testEqualsSameValues() {
            Complex c1 = new Complex(1.0, 2.0);
            Complex c2 = new Complex(1.0, 2.0);
            assertTrue(c1.equals(c2));
        }

    @Test
        public void testEqualsDifferentReal() {
            Complex c1 = new Complex(1.0, 2.0);
            Complex c2 = new Complex(3.0, 2.0);
            assertFalse(c1.equals(c2));
        }

    @Test
        public void testEqualsDifferentImaginary() {
            Complex c1 = new Complex(1.0, 2.0);
            Complex c2 = new Complex(1.0, 3.0);
            assertFalse(c1.equals(c2));
        }

    @Test
        public void testEqualsBothNaN() {
            Complex c1 = Complex.NaN;
            Complex c2 = Complex.NaN;
            assertTrue(c1.equals(c2));
        }

    @Test
        public void testEqualsFirstNaN() {
            Complex c1 = Complex.NaN;
            Complex c2 = new Complex(1.0, 2.0);
            assertFalse(c1.equals(c2));
        }

    @Test
        public void testEqualsSecondNaN() {
            Complex c1 = new Complex(1.0, 2.0);
            Complex c2 = Complex.NaN;
            assertFalse(c1.equals(c2));
        }

    @Test
        public void testEqualsPositiveZero() {
            Complex c1 = new Complex(0.0, 0.0);
            Complex c2 = new Complex(0.0, 0.0);
            assertTrue(c1.equals(c2));
        }

    @Test
        public void testEqualsNegativeZero() {
            Complex c1 = new Complex(-0.0, -0.0);
            Complex c2 = new Complex(-0.0, -0.0);
            assertTrue(c1.equals(c2));
        }

    @Test
        public void testEqualsMixedZero() {
            Complex c1 = new Complex(0.0, -0.0);
            Complex c2 = new Complex(-0.0, 0.0);
            assertTrue(c1.equals(c2));
        }

    @Test
        public void testEqualsInfinity() {
            Complex c1 = Complex.INF;
            Complex c2 = Complex.INF;
            assertTrue(c1.equals(c2));
        }

    @Test
        public void testEqualsDifferentInfinity() {
            Complex c1 = Complex.INF;
            Complex c2 = new Complex(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY);
            assertFalse(c1.equals(c2));
        }

}
