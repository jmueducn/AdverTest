package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.util.Arrays;
 
public class MathUtilsTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testGcdBothZero() {
            assertEquals(0, MathUtils.gcd(0, 0));
        }

    @Test
        public void testGcdFirstZero() {
            assertEquals(5, MathUtils.gcd(0, 5));
            assertEquals(5, MathUtils.gcd(0, -5));
        }

    @Test
        public void testGcdSecondZero() {
            assertEquals(5, MathUtils.gcd(5, 0));
            assertEquals(5, MathUtils.gcd(-5, 0));
        }

    @Test
        public void testGcdPositiveNumbers() {
            assertEquals(6, MathUtils.gcd(12, 18));
            assertEquals(6, MathUtils.gcd(18, 12));
        }

    @Test
        public void testGcdNegativeNumbers() {
            assertEquals(6, MathUtils.gcd(-12, -18));
            assertEquals(6, MathUtils.gcd(-18, -12));
        }

    @Test
        public void testGcdMixedSignNumbers() {
            assertEquals(6, MathUtils.gcd(-12, 18));
            assertEquals(6, MathUtils.gcd(12, -18));
        }

    @Test
        public void testGcdPrimeNumbers() {
            assertEquals(1, MathUtils.gcd(13, 17));
            assertEquals(1, MathUtils.gcd(17, 13));
        }

    @Test
        public void testGcdSameNumber() {
            assertEquals(12, MathUtils.gcd(12, 12));
            assertEquals(12, MathUtils.gcd(-12, -12));
        }

    @Test
        public void testGcdOneIsMultipleOfOther() {
            assertEquals(12, MathUtils.gcd(12, 24));
            assertEquals(12, MathUtils.gcd(24, 12));
        }

    @Test
        public void testGcdLargeNumbers() {
            assertEquals(1000, MathUtils.gcd(1000, 1000000));
            assertEquals(1000, MathUtils.gcd(1000000, 1000));
        }

    @Test
        public void testGcdPowerOfTwoNumbers() {
            assertEquals(8, MathUtils.gcd(16, 24));
            assertEquals(8, MathUtils.gcd(24, 16));
        }

    @Test
        public void testGcdMaxIntValues() {
            assertEquals(1, MathUtils.gcd(Integer.MAX_VALUE, Integer.MAX_VALUE - 1));
            assertEquals(1, MathUtils.gcd(Integer.MAX_VALUE - 1, Integer.MAX_VALUE));
        }

    @Test
        public void testGcdMinIntValues() {
            assertEquals(1, MathUtils.gcd(Integer.MIN_VALUE, Integer.MIN_VALUE + 1));
            assertEquals(1, MathUtils.gcd(Integer.MIN_VALUE + 1, Integer.MIN_VALUE));
        }

    @Test(expected = ArithmeticException.class)
        public void testGcdOverflow() {
            // This should throw ArithmeticException because gcd(2^30, 2^30) would be 2^31 which overflows
            MathUtils.gcd(1 << 30, 1 << 30);
        }

}
