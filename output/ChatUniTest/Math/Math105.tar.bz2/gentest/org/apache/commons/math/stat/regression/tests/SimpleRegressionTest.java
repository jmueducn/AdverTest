package gentest.org.apache.commons.math.stat.regression.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.regression.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.distribution.DistributionFactory;
import org.apache.commons.math.distribution.TDistribution;
 
public class SimpleRegressionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
        public void testGetSumSquaredErrorsWithNoData() {
            SimpleRegression regression = new SimpleRegression();
            assertEquals(0.0, regression.getSumSquaredErrors(), 0.0);
        }

    @Test
        public void testGetSumSquaredErrorsWithPositiveResult() {
            SimpleRegression regression = new SimpleRegression();
            regression.addData(new double[][] {
                {1, 2},
                {2, 3},
                {3, 4}
            });
            double expected = 0.0; // Perfect fit, so SSE should be 0
            assertEquals(expected, regression.getSumSquaredErrors(), 0.0001);
        }

    @Test
        public void testGetSumSquaredErrorsWithNegativeCalculation() {
            SimpleRegression regression = new SimpleRegression();
            regression.addData(new double[][] {
                {1, 2},
                {2, 5},
                {3, 3}
            });
            // Force calculation that would be negative without Math.max
            // sumYY = 2.6666, sumXY = 1.0, sumXX = 2.0
            // sumYY - sumXY*sumXY/sumXX = 2.6666 - (1*1/2) = 2.1666 (positive)
            // So we need to manipulate the internal state to get negative value
            try {
                java.lang.reflect.Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                sumXXField.setAccessible(true);
                sumXXField.set(regression, -1.0);
                
                java.lang.reflect.Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                sumYYField.setAccessible(true);
                sumYYField.set(regression, 1.0);
                
                java.lang.reflect.Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                sumXYField.setAccessible(true);
                sumXYField.set(regression, 2.0);
                
                // Calculation would be: 1.0 - (2.0 * 2.0 / -1.0) = 1.0 - (-4.0) = 5.0
                // But we want to test the Math.max(0, ...) part
                // So we'll set values that would make it negative
                sumXXField.set(regression, 1.0);
                sumYYField.set(regression, 1.0);
                sumXYField.set(regression, 2.0);
                // 1.0 - (2.0 * 2.0 / 1.0) = 1.0 - 4.0 = -3.0, but Math.max returns 0
                
                assertEquals(0.0, regression.getSumSquaredErrors(), 0.0001);
            } catch (Exception e) {
                fail("Reflection failed: " + e.getMessage());
            }
        }

    @Test
        public void testGetSumSquaredErrorsWithSingleDataPoint() {
            SimpleRegression regression = new SimpleRegression();
            regression.addData(1.0, 2.0);
            assertEquals(0.0, regression.getSumSquaredErrors(), 0.0);
        }

    @Test
        public void testGetSumSquaredErrorsWithPerfectFit() {
            SimpleRegression regression = new SimpleRegression();
            regression.addData(new double[][] {
                {1, 1},
                {2, 2},
                {3, 3}
            });
            assertEquals(0.0, regression.getSumSquaredErrors(), 0.0001);
        }

    @Test
        public void testGetSumSquaredErrorsWithImperfectFit() {
            SimpleRegression regression = new SimpleRegression();
            regression.addData(new double[][] {
                {1, 1},
                {2, 1.5},
                {3, 2}
            });
            double result = regression.getSumSquaredErrors();
            assertTrue(result > 0.0);
        }


}
