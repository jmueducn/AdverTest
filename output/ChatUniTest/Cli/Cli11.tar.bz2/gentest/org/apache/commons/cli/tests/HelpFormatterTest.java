package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
 
public class HelpFormatterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
            public void testAppendOptionWithShortOptNotRequired() throws Exception {
                Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                    "appendOption", 
                    StringBuffer.class, 
                    Option.class, 
                    boolean.class
                );
                appendOptionMethod.setAccessible(true);
                
                StringBuffer buff = new StringBuffer();
                Option option = new Option("a", "aaa", false, "description");
                option.setArgName("arg");
                
                appendOptionMethod.invoke(null, buff, option, false);
                
                assertEquals("[-a <arg>]", buff.toString());
            }

    @Test
            public void testAppendOptionWithLongOptNotRequired() throws Exception {
                Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                    "appendOption", StringBuffer.class, Option.class, boolean.class);
                appendOptionMethod.setAccessible(true);
                
                StringBuffer buff = new StringBuffer();
                Option option = new Option(null, "long-opt", false, "description");
                option.setArgName("arg");
                
                appendOptionMethod.invoke(null, buff, option, false);
                
                assertEquals("[--long-opt <arg>]", buff.toString());
            }

    @Test
            public void testAppendOptionWithLongOptRequired() throws Exception {
                Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                    "appendOption", StringBuffer.class, Option.class, boolean.class);
                appendOptionMethod.setAccessible(true);
        
                StringBuffer buff = new StringBuffer();
                Option option = new Option(null, "long-opt", true, "description");
                option.setArgName("arg");
                
                appendOptionMethod.invoke(null, buff, option, true);
                
                assertEquals("--long-opt <arg>", buff.toString());
            }

    @Test
            public void testAppendOptionWithShortOptNoArgName() throws Exception {
                Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                    "appendOption", StringBuffer.class, Option.class, boolean.class);
                appendOptionMethod.setAccessible(true);
                
                StringBuffer buff = new StringBuffer();
                Option option = new Option("c", "ccc", true, "description");
                
                appendOptionMethod.invoke(null, buff, option, false);
                
                assertEquals("[-c]", buff.toString());
            }

    @Test
            public void testAppendOptionWithLongOptNoArgName() throws Exception {
                Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                    "appendOption", 
                    StringBuffer.class, 
                    Option.class, 
                    boolean.class
                );
                appendOptionMethod.setAccessible(true);
                
                StringBuffer buff = new StringBuffer();
                Option option = new Option(null, "long-opt-no-arg", false, "description");
                
                appendOptionMethod.invoke(null, buff, option, true);
                
                assertEquals("--long-opt-no-arg", buff.toString());
            }

    @Test
            public void testAppendOptionWithShortOptNoArg() throws Exception {
                StringBuffer buff = new StringBuffer();
                Option option = new Option("d", "ddd", false, "description");
                
                Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                    "appendOption", StringBuffer.class, Option.class, boolean.class);
                appendOptionMethod.setAccessible(true);
                
                appendOptionMethod.invoke(null, buff, option, false);
                
                assertEquals("[-d]", buff.toString());
            }

    @Test
            public void testAppendOptionWithLongOptNoArg() throws Exception {
                StringBuffer buff = new StringBuffer();
                Option option = new Option(null, "long-opt-no-arg", false, "description");
                
                Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                    "appendOption", StringBuffer.class, Option.class, boolean.class);
                appendOptionMethod.setAccessible(true);
                
                appendOptionMethod.invoke(null, buff, option, false);
                
                assertEquals("[--long-opt-no-arg]", buff.toString());
            }

    @Test
        public void testAppendOptionWithShortOptRequired() throws Exception {
            StringBuffer buff = new StringBuffer();
            Option option = new Option("b", "bbb", true, "description");
            option.setArgName("arg");
            
            Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                "appendOption", StringBuffer.class, Option.class, boolean.class);
            appendOptionMethod.setAccessible(true);
            appendOptionMethod.invoke(null, buff, option, true);
            
            assertEquals("-b <arg>", buff.toString());
        }


}
