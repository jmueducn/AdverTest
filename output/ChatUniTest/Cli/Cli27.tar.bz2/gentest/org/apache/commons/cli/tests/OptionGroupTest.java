package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
 
public class OptionGroupTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                    public void testSetSelectedWhenDifferentOptionSelected() throws AlreadySelectedException {
                                                        OptionGroup optionGroup = new OptionGroup();
                                                        Option option1 = new Option("a", false, "description");
                                                        Option option2 = new Option("b", false, "description");
                                                        optionGroup.addOption(option1);
                                                        optionGroup.addOption(option2);
                                                        
                                                        optionGroup.setSelected(option1);
                                                        optionGroup.setSelected(option2);
                                                    }

    @Test
        public void testSetSelectedAfterReset() throws AlreadySelectedException {
            OptionGroup optionGroup = new OptionGroup();
            Option option1 = new Option("opt1", false, "option 1");
            Option option2 = new Option("opt2", false, "option 2");
            optionGroup.addOption(option1);
            optionGroup.addOption(option2);
            
            optionGroup.setSelected(option1);
            optionGroup.setSelected(null);
            optionGroup.setSelected(option2);
            assertEquals("opt2", optionGroup.getSelected());
        }

    @Test
        public void testSetSelectedWhenSameOptionReselected() throws AlreadySelectedException {
            OptionGroup optionGroup = new OptionGroup();
            Option option1 = new Option("opt1", false, "description");
            optionGroup.addOption(option1);
            
            optionGroup.setSelected(option1);
            optionGroup.setSelected(option1);
            assertEquals("opt1", optionGroup.getSelected());
        }

    @Test
        public void testSetSelectedWithNullOption() throws AlreadySelectedException {
            OptionGroup optionGroup = new OptionGroup();
            Option option1 = new Option("test", "test option");
            optionGroup.addOption(option1);
            
            optionGroup.setSelected(option1);
            assertNotNull(optionGroup.getSelected());
            
            optionGroup.setSelected(null);
            assertNull(optionGroup.getSelected());
        }

    @Test
        public void testSetSelectedWhenNoOptionSelected() {
            OptionGroup optionGroup = new OptionGroup();
            Option option1 = new Option("opt1", false, "description");
            
            try {
                optionGroup.setSelected(option1);
                assertEquals("opt1", optionGroup.getSelected());
            } catch (AlreadySelectedException e) {
                fail("Unexpected AlreadySelectedException");
            }
        }


}
