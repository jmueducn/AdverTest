package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
 
public class CommandLineTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                            public void testHasOption_WhenOptionExists_ReturnsTrue() throws Exception {
                                                                                Option mockOption = mock(Option.class);
                                                                                List<Option> options = new ArrayList<>();
                                                                                
                                                                                // Use reflection to create CommandLine instance and set private fields
                                                                                CommandLine commandLine = CommandLine.class.getDeclaredConstructor().newInstance();
                                                                                
                                                                                // Use reflection to set the private 'options' field in CommandLine
                                                                                java.lang.reflect.Field optionsField = CommandLine.class.getDeclaredField("options");
                                                                                optionsField.setAccessible(true);
                                                                                optionsField.set(commandLine, options);
                                                                                
                                                                                when(mockOption.getOpt()).thenReturn("test");
                                                                                when(mockOption.getLongOpt()).thenReturn("testLong");
                                                                                options.add(mockOption);
                                                                                
                                                                                assertTrue(commandLine.hasOption("test"));
                                                                                assertTrue(commandLine.hasOption("testLong"));
                                                                            }

    @Test
                                                                            public void testHasOption_CharVersion() {
                                                                                Option mockOption = mock(Option.class);
                                                                                Set<Option> options = new HashSet<>();
                                                                                
                                                                                // Create CommandLine instance using reflection since constructor is not public
                                                                                CommandLine commandLine;
                                                                                try {
                                                                                    commandLine = CommandLine.class.getDeclaredConstructor().newInstance();
                                                                                } catch (Exception e) {
                                                                                    fail("Failed to create CommandLine instance");
                                                                                    return;
                                                                                }
                                                                                
                                                                                // Use reflection to set the private options field
                                                                                try {
                                                                                    java.lang.reflect.Field optionsField = CommandLine.class.getDeclaredField("options");
                                                                                    optionsField.setAccessible(true);
                                                                                    optionsField.set(commandLine, options);
                                                                                } catch (Exception e) {
                                                                                    fail("Failed to set options field via reflection");
                                                                                }
                                                                                
                                                                                when(mockOption.getOpt()).thenReturn("a");
                                                                                options.add(mockOption);
                                                                                
                                                                                assertTrue(commandLine.hasOption('a'));
                                                                                assertFalse(commandLine.hasOption('b'));
                                                                            }

    @Test
                                                                            public void testHasOption_WithSpecialCharacter() throws Exception {
                                                                                // Use reflection to create CommandLine instance
                                                                                Constructor<CommandLine> constructor = CommandLine.class.getDeclaredConstructor();
                                                                                constructor.setAccessible(true);
                                                                                CommandLine commandLine = constructor.newInstance();
                                                                                
                                                                                Option mockOption = mock(Option.class);
                                                                                
                                                                                when(mockOption.getOpt()).thenReturn("-");
                                                                                
                                                                                // Use reflection to call addOption
                                                                                Method addOptionMethod = CommandLine.class.getDeclaredMethod("addOption", Option.class);
                                                                                addOptionMethod.setAccessible(true);
                                                                                addOptionMethod.invoke(commandLine, mockOption);
                                                                                
                                                                                assertTrue(commandLine.hasOption('-'));
                                                                            }

    @Test
                                                                            public void testHasOption_WithMultipleOptions() {
                                                                                // Create CommandLine instance using reflection since constructor is not public
                                                                                CommandLine commandLine;
                                                                                try {
                                                                                    commandLine = CommandLine.class.newInstance();
                                                                                } catch (Exception e) {
                                                                                    throw new RuntimeException("Failed to create CommandLine instance", e);
                                                                                }
                                                                        
                                                                                Option mockOption1 = mock(Option.class);
                                                                                Option mockOption2 = mock(Option.class);
                                                                                when(mockOption1.getOpt()).thenReturn("x");
                                                                                when(mockOption2.getOpt()).thenReturn("y");
                                                                                
                                                                                // Add options using reflection since addOption is not public
                                                                                try {
                                                                                    CommandLine.class.getDeclaredMethod("addOption", Option.class)
                                                                                        .invoke(commandLine, mockOption1);
                                                                                    CommandLine.class.getDeclaredMethod("addOption", Option.class)
                                                                                        .invoke(commandLine, mockOption2);
                                                                                } catch (Exception e) {
                                                                                    throw new RuntimeException("Failed to add options to CommandLine", e);
                                                                                }
                                                                                
                                                                                assertTrue(commandLine.hasOption('x'));
                                                                                assertTrue(commandLine.hasOption('y'));
                                                                                assertFalse(commandLine.hasOption('z'));
                                                                            }

    @Test
                                                                            public void testGetOptionObjectWithCharOptionExists() throws Exception {
                                                                                // Setup
                                                                                CommandLine commandLine = (CommandLine) CommandLine.class.getDeclaredConstructor().newInstance();
                                                                                Option mockOption = mock(Option.class);
                                                                                when(mockOption.getOpt()).thenReturn("a");
                                                                                when(mockOption.getType()).thenReturn(String.class);
                                                                                when(mockOption.getValues()).thenReturn(new String[]{"testValue"});
                                                                                
                                                                                // Use reflection to access private addOption method
                                                                                Method addOptionMethod = CommandLine.class.getDeclaredMethod("addOption", Option.class);
                                                                                addOptionMethod.setAccessible(true);
                                                                                addOptionMethod.invoke(commandLine, mockOption);
                                                                            
                                                                                // Test
                                                                                Object result = commandLine.getOptionObject('a');
                                                                                
                                                                                // Verify
                                                                                assertNotNull(result);
                                                                                assertEquals("testValue", result);
                                                                            }

    @Test
                                                                            public void testResolveOptionWithDoubleHyphenShortOption() throws Exception {
                                                                                List<Option> options = new ArrayList<>();
                                                                                Option option3 = mock(Option.class);
                                                                                
                                                                                when(option3.getOpt()).thenReturn("c");
                                                                                when(option3.getLongOpt()).thenReturn("gamma");
                                                                                options.add(option3);
                                                                            
                                                                                CommandLine commandLine = (CommandLine) CommandLine.class
                                                                                    .getDeclaredConstructor()
                                                                                    .newInstance();
                                                                                Option result = (Option) CommandLine.class
                                                                                    .getDeclaredMethod("resolveOption", String.class, List.class)
                                                                                    .invoke(commandLine, "--c", options);
                                                                                
                                                                                assertEquals(option3, result);
                                                                            }

    @Test
                                                                            public void testResolveOptionWithEmptyOptions() throws Exception {
                                                                                // Create CommandLine instance using reflection since constructor is not public
                                                                                Class<?> clazz = Class.forName("org.apache.commons.cli.CommandLine");
                                                                                CommandLine commandLine = (CommandLine) clazz.getDeclaredConstructor().newInstance();
                                                                                
                                                                                List<Option> options = new ArrayList<>();
                                                                                
                                                                                // Use reflection to set private field
                                                                                Field optionsField = commandLine.getClass().getDeclaredField("options");
                                                                                optionsField.setAccessible(true);
                                                                                optionsField.set(commandLine, options);
                                                                                
                                                                                // Use reflection to invoke private method
                                                                                Method resolveOptionMethod = commandLine.getClass().getDeclaredMethod("resolveOption", String.class);
                                                                                resolveOptionMethod.setAccessible(true);
                                                                                Option result = (Option) resolveOptionMethod.invoke(commandLine, "a");
                                                                                
                                                                                assertNull(result);
                                                                            }

    @Test
                                                                            public void testResolveOptionWithNullInput() throws Exception {
                                                                                // Create CommandLine instance using reflection since constructor is not public
                                                                                CommandLine commandLine = CommandLine.class.newInstance();
                                                                                List<Option> options = new ArrayList<>();
                                                                                
                                                                                // Use reflection to access private method
                                                                                Method method = CommandLine.class.getDeclaredMethod("resolveOption", String.class, List.class);
                                                                                method.setAccessible(true);
                                                                                
                                                                                Option result = (Option) method.invoke(commandLine, null, options);
                                                                                assertNull(result);
                                                                            }

    @Test
                                                                            public void testResolveOptionWithEmptyString() throws Exception {
                                                                                // Create CommandLine instance using reflection since constructor isn't public
                                                                                CommandLine commandLine = CommandLine.class.newInstance();
                                                                                List<Option> options = new ArrayList<>();
                                                                                
                                                                                // Create test method via reflection
                                                                                Method method = CommandLine.class.getDeclaredMethod("resolveOption", String.class);
                                                                                method.setAccessible(true);
                                                                                
                                                                                Option result = (Option) method.invoke(commandLine, "");
                                                                                assertNull(result);
                                                                            }

    @Test
                                                                            public void testGetOptionValuesWithCharOptionExists() throws Exception {
                                                                                // Setup
                                                                                CommandLine commandLine = CommandLine.class.newInstance();
                                                                                Option mockOption = mock(Option.class);
                                                                                char opt = 'a';
                                                                                String[] expectedValues = {"value1", "value2"};
                                                                                when(mockOption.getOpt()).thenReturn("a");
                                                                                when(mockOption.getValues()).thenReturn(expectedValues);
                                                                                
                                                                                // Use reflection to call addOption
                                                                                Method addOptionMethod = CommandLine.class.getDeclaredMethod("addOption", Option.class);
                                                                                addOptionMethod.setAccessible(true);
                                                                                addOptionMethod.invoke(commandLine, mockOption);
                                                                        
                                                                                // Test
                                                                                String[] result = commandLine.getOptionValues(opt);
                                                                        
                                                                                // Verify
                                                                                assertArrayEquals(expectedValues, result);
                                                                                verify(mockOption).getOpt();
                                                                                verify(mockOption).getValues();
                                                                            }

    @Test
                                                                        public void testHasOption_WhenOptionExists() throws Exception {
                                                                            // Use reflection to create CommandLine instance
                                                                            Constructor<CommandLine> constructor = CommandLine.class.getDeclaredConstructor();
                                                                            constructor.setAccessible(true);
                                                                            CommandLine commandLine = constructor.newInstance();
                                                                    
                                                                            Option mockOption = mock(Option.class);
                                                                            
                                                                            when(mockOption.getOpt()).thenReturn("a");
                                                                            
                                                                            // Use reflection to call addOption
                                                                            Method addOptionMethod = CommandLine.class.getDeclaredMethod("addOption", Option.class);
                                                                            addOptionMethod.setAccessible(true);
                                                                            addOptionMethod.invoke(commandLine, mockOption);
                                                                            
                                                                            assertTrue(commandLine.hasOption('a'));
                                                                        }

    @Test
                                                                        public void testHasOption_WithNumericCharacter() throws Exception {
                                                                            // Get CommandLine constructor and make it accessible
                                                                            Constructor<?> constructor = Class.forName("org.apache.commons.cli.CommandLine")
                                                                                .getDeclaredConstructor();
                                                                            constructor.setAccessible(true);
                                                                            Object commandLine = constructor.newInstance();
                                                                            
                                                                            // Get addOption method and make it accessible
                                                                            Method addOption = commandLine.getClass().getDeclaredMethod("addOption", Option.class);
                                                                            addOption.setAccessible(true);
                                                                            
                                                                            // Get hasOption method and make it accessible
                                                                            Method hasOption = commandLine.getClass().getDeclaredMethod("hasOption", char.class);
                                                                            hasOption.setAccessible(true);
                                                                            
                                                                            Option mockOption = mock(Option.class);
                                                                            when(mockOption.getOpt()).thenReturn("1");
                                                                            
                                                                            // Invoke addOption using reflection
                                                                            addOption.invoke(commandLine, mockOption);
                                                                            
                                                                            // Invoke hasOption using reflection and assert
                                                                            assertTrue((Boolean)hasOption.invoke(commandLine, '1'));
                                                                        }

    @Test
                                                                        public void testHasOption_WithLongOption() throws Exception {
                                                                            // Use reflection to create CommandLine instance since constructor is not public
                                                                            CommandLine commandLine = CommandLine.class.newInstance();
                                                                            
                                                                            // Use reflection to test private resolveOption method
                                                                            Method resolveOption = CommandLine.class.getDeclaredMethod("resolveOption", String.class);
                                                                            resolveOption.setAccessible(true);
                                                                            
                                                                            Option mockOption = mock(Option.class);
                                                                            when(mockOption.getLongOpt()).thenReturn("longopt");
                                                                            
                                                                            // Use reflection to call addOption since it's not public
                                                                            Method addOption = CommandLine.class.getDeclaredMethod("addOption", Option.class);
                                                                            addOption.setAccessible(true);
                                                                            addOption.invoke(commandLine, mockOption);
                                                                            
                                                                            // The method should still return false for char option since it only checks short option
                                                                            assertFalse(commandLine.hasOption('l'));
                                                                        }

    @Test
                                                                        public void testGetOptionObjectWhenOptionExistsButNoValue() {
                                                                            // Create required objects
                                                                            CommandLine commandLine;
                                                                            try {
                                                                                commandLine = CommandLine.class.getDeclaredConstructor().newInstance();
                                                                            } catch (Exception e) {
                                                                                throw new RuntimeException(e);
                                                                            }
                                                                            List<Option> options = new ArrayList<>();
                                                                            Option mockOption = mock(Option.class);
                                                                            
                                                                            // Set up mock behavior
                                                                            when(mockOption.getOpt()).thenReturn("test");
                                                                            when(mockOption.getLongOpt()).thenReturn("test");
                                                                            options.add(mockOption);
                                                                            
                                                                            // Use reflection to set the options field
                                                                            try {
                                                                                java.lang.reflect.Field optionsField = CommandLine.class.getDeclaredField("options");
                                                                                optionsField.setAccessible(true);
                                                                                optionsField.set(commandLine, options);
                                                                            } catch (Exception e) {
                                                                                throw new RuntimeException(e);
                                                                            }
                                                                        
                                                                            // Mock getOptionValue to return null
                                                                            CommandLine spyCommandLine = spy(commandLine);
                                                                            doReturn(null).when(spyCommandLine).getOptionValue("test");
                                                                        
                                                                            Object result = spyCommandLine.getOptionObject("test");
                                                                            assertNull(result);
                                                                        }

    @Test
                                                                        public void testGetOptionObjectWhenOptionExistsWithValue() throws Exception {
                                                                            // Setup test objects
                                                                            Options options = new Options();
                                                                            CommandLine commandLine = mock(CommandLine.class);
                                                                            Option mockOption = mock(Option.class);
                                                                            
                                                                            when(mockOption.getOpt()).thenReturn("test");
                                                                            when(mockOption.getLongOpt()).thenReturn("test");
                                                                            when(mockOption.getType()).thenReturn(Integer.class);
                                                                            options.addOption(mockOption);
                                                                        
                                                                            // Mock getOptionValue to return a value
                                                                            CommandLine spyCommandLine = spy(commandLine);
                                                                            doReturn("123").when(spyCommandLine).getOptionValue("test");
                                                                        
                                                                            // Mock TypeHandler.createValue
                                                                            try {
                                                                                Method createValueMethod = TypeHandler.class.getDeclaredMethod("createValue", String.class, Object.class);
                                                                                createValueMethod.setAccessible(true);
                                                                                when(createValueMethod.invoke(null, "123", Integer.class)).thenReturn(123);
                                                                            } catch (Exception e) {
                                                                                fail("Failed to mock TypeHandler.createValue: " + e.getMessage());
                                                                            }
                                                                        
                                                                            Object result = spyCommandLine.getOptionObject("test");
                                                                            assertEquals(123, result);
                                                                        }

    @Test
                                                                        public void testGetOptionObjectWithCharOptionDoesNotExist() {
                                                                            Options options = new Options();
                                                                            
                                                                            // Create CommandLine instance using reflection since constructor is not public
                                                                            CommandLine commandLine = null;
                                                                            try {
                                                                                Constructor<CommandLine> constructor = CommandLine.class.getDeclaredConstructor();
                                                                                constructor.setAccessible(true);
                                                                                commandLine = constructor.newInstance();
                                                                            } catch (Exception e) {
                                                                                fail("Failed to create CommandLine instance via reflection");
                                                                            }
                                                                            
                                                                            // Use reflection to set private options field
                                                                            try {
                                                                                Field optionsField = CommandLine.class.getDeclaredField("options");
                                                                                optionsField.setAccessible(true);
                                                                                optionsField.set(commandLine, options);
                                                                            } catch (Exception e) {
                                                                                fail("Failed to set options field via reflection");
                                                                            }
                                                                            
                                                                            Object result = commandLine.getOptionObject('z');
                                                                            assertNull(result);
                                                                        }

    @Test
                                                                        public void testHasOption_WithHyphenPrefix_WorksCorrectly() throws Exception {
                                                                            // Setup
                                                                            Set<Option> options = new HashSet<Option>();
                                                                            // Use reflection to create CommandLine instance since constructor is not public
                                                                            CommandLine commandLine = CommandLine.class.getDeclaredConstructor().newInstance();
                                                                            
                                                                            // Use reflection to set the private options field
                                                                            java.lang.reflect.Field optionsField = CommandLine.class.getDeclaredField("options");
                                                                            optionsField.setAccessible(true);
                                                                            optionsField.set(commandLine, options);
                                                                            
                                                                            Option mockOption = mock(Option.class);
                                                                            when(mockOption.getOpt()).thenReturn("test");
                                                                            when(mockOption.getLongOpt()).thenReturn("testLong");
                                                                            options.add(mockOption);
                                                                            
                                                                            // Test
                                                                            assertTrue(commandLine.hasOption("-test"));
                                                                            assertTrue(commandLine.hasOption("--testLong"));
                                                                        }

    @Test
                                                                        public void testGetOptionValuesWhenOptionDoesNotExist() {
                                                                            // Setup
                                                                            Set<Option> options = new HashSet<>();
                                                                            
                                                                            // Create CommandLine instance using reflection since constructor is not public
                                                                            CommandLine commandLine;
                                                                            try {
                                                                                commandLine = CommandLine.class.newInstance();
                                                                            } catch (Exception e) {
                                                                                fail("Failed to create CommandLine instance");
                                                                                return;
                                                                            }
                                                                            
                                                                            // Use reflection to set private field
                                                                            try {
                                                                                Field optionsField = CommandLine.class.getDeclaredField("options");
                                                                                optionsField.setAccessible(true);
                                                                                optionsField.set(commandLine, options);
                                                                            } catch (Exception e) {
                                                                                fail("Failed to set options field via reflection");
                                                                            }
                                                                            
                                                                            // Test with non-existent option
                                                                            String[] result = commandLine.getOptionValues("nonexistent");
                                                                            assertNull(result);
                                                                        }

    @Test
                                                                        public void testResolveOptionWithShortOption() throws Exception {
                                                                            Option option1 = mock(Option.class);
                                                                            List<Option> options = new ArrayList<>();
                                                                            
                                                                            when(option1.getOpt()).thenReturn("a");
                                                                            when(option1.getLongOpt()).thenReturn("alpha");
                                                                            options.add(option1);
                                                                            
                                                                            // Using reflection to create CommandLine instance
                                                                            Constructor<CommandLine> constructor = CommandLine.class.getDeclaredConstructor();
                                                                            constructor.setAccessible(true);
                                                                            CommandLine commandLine = constructor.newInstance();
                                                                            
                                                                            // Using reflection to access private resolveOption method
                                                                            java.lang.reflect.Method method = CommandLine.class.getDeclaredMethod("resolveOption", String.class, List.class);
                                                                            method.setAccessible(true);
                                                                            Option result = (Option) method.invoke(commandLine, "-a", options);
                                                                            
                                                                            assertEquals(option1, result);
                                                                        }

    @Test
                                                                        public void testResolveOptionWithLongOption() throws Exception {
                                                                            Option option2 = mock(Option.class);
                                                                            List<Option> options = new ArrayList<>();
                                                                            
                                                                            when(option2.getOpt()).thenReturn("b");
                                                                            when(option2.getLongOpt()).thenReturn("beta");
                                                                            options.add(option2);
                                                                            
                                                                            // Using reflection to access the private constructor
                                                                            CommandLine commandLine = CommandLine.class.getDeclaredConstructor().newInstance();
                                                                            Method method = CommandLine.class.getDeclaredMethod(
                                                                                "resolveOption", String.class, List.class);
                                                                            method.setAccessible(true);
                                                                            Option result = (Option) method.invoke(commandLine, "--beta", options);
                                                                            
                                                                            assertEquals(option2, result);
                                                                        }

    @Test
                                                                        public void testGetOptionValuesWithCharOptionMultipleOptions() throws Exception {
                                                                            // Use reflection to create CommandLine instance
                                                                            Constructor<CommandLine> constructor = CommandLine.class.getDeclaredConstructor();
                                                                            constructor.setAccessible(true);
                                                                            CommandLine commandLine = constructor.newInstance();
                                                                    
                                                                            char opt = 'd';
                                                                            String[] expectedValues = {"val1", "val2"};
                                                                            
                                                                            Option mockOption1 = mock(Option.class);
                                                                            when(mockOption1.getOpt()).thenReturn("x");
                                                                            
                                                                            Option mockOption2 = mock(Option.class);
                                                                            when(mockOption2.getOpt()).thenReturn("d");
                                                                            when(mockOption2.getValues()).thenReturn(expectedValues);
                                                                            
                                                                            // Use reflection to call addOption
                                                                            Method addOptionMethod = CommandLine.class.getDeclaredMethod("addOption", Option.class);
                                                                            addOptionMethod.setAccessible(true);
                                                                            addOptionMethod.invoke(commandLine, mockOption1);
                                                                            addOptionMethod.invoke(commandLine, mockOption2);
                                                                        
                                                                            // Test
                                                                            String[] result = commandLine.getOptionValues(opt);
                                                                        
                                                                            // Verify
                                                                            assertArrayEquals(expectedValues, result);
                                                                            verify(mockOption1).getOpt();
                                                                            verify(mockOption2).getOpt();
                                                                            verify(mockOption2).getValues();
                                                                        }

    @Test
                                                                        public void testGetOptionValuesWithCharOptionUsingLongOpt() throws Exception {
                                                                            // Setup
                                                                            Constructor<CommandLine> constructor = CommandLine.class.getDeclaredConstructor();
                                                                            constructor.setAccessible(true);
                                                                            CommandLine commandLine = constructor.newInstance();
                                                                            
                                                                            char opt = 'e';
                                                                            String[] expectedValues = {"longValue"};
                                                                            
                                                                            Option mockOption = mock(Option.class);
                                                                            when(mockOption.getOpt()).thenReturn(null);
                                                                            when(mockOption.getLongOpt()).thenReturn("e");
                                                                            when(mockOption.getValues()).thenReturn(expectedValues);
                                                                            
                                                                            Method addOptionMethod = CommandLine.class.getDeclaredMethod("addOption", Option.class);
                                                                            addOptionMethod.setAccessible(true);
                                                                            addOptionMethod.invoke(commandLine, mockOption);
                                                                        
                                                                            // Test
                                                                            String[] result = commandLine.getOptionValues(opt);
                                                                        
                                                                            // Verify
                                                                            assertArrayEquals(expectedValues, result);
                                                                            verify(mockOption).getOpt();
                                                                            verify(mockOption).getLongOpt();
                                                                            verify(mockOption).getValues();
                                                                        }

    @Test
                                                                        public void testAddOption() throws Exception {
                                                                            // Setup test objects using reflection to access private constructor
                                                                            Class<?> commandLineClass = Class.forName("org.apache.commons.cli.CommandLine");
                                                                            Object commandLine = commandLineClass.getDeclaredConstructor().newInstance();
                                                                            
                                                                            Option mockOption = mock(Option.class);
                                                                            
                                                                            // Get the private addOption method using reflection
                                                                            Method addOptionMethod = commandLineClass.getDeclaredMethod("addOption", Option.class);
                                                                            addOptionMethod.setAccessible(true);
                                                                            
                                                                            // Invoke the method
                                                                            addOptionMethod.invoke(commandLine, mockOption);
                                                                        
                                                                            // Use reflection to access private field
                                                                            Field optionsField = commandLineClass.getDeclaredField("options");
                                                                            optionsField.setAccessible(true);
                                                                            Set<Option> options = (Set<Option>) optionsField.get(commandLine);
                                                                        
                                                                            // Verify the option was added
                                                                            assertTrue(options.contains(mockOption));
                                                                            assertEquals(1, options.size());
                                                                        }

    @Test
                                                                        public void testAddOptionWithNull() throws Exception {
                                                                            // Create new CommandLine instance using reflection
                                                                            Class<?> commandLineClass = Class.forName("org.apache.commons.cli.CommandLine");
                                                                            Object commandLine = commandLineClass.getDeclaredConstructor().newInstance();
                                                                            
                                                                            // Get the addOption method using reflection
                                                                            Method addOptionMethod = commandLineClass.getDeclaredMethod("addOption", Class.forName("org.apache.commons.cli.Option"));
                                                                            addOptionMethod.setAccessible(true);
                                                                            
                                                                            // Invoke the method with null
                                                                            addOptionMethod.invoke(commandLine, (Object) null);
                                                                            
                                                                            // Use reflection to access private field
                                                                            Field optionsField = commandLineClass.getDeclaredField("options");
                                                                            optionsField.setAccessible(true);
                                                                            Set<?> options = (Set<?>) optionsField.get(commandLine);
                                                                            
                                                                            // Verify null was added to the set
                                                                            assertTrue(options.contains(null));
                                                                            assertEquals(1, options.size());
                                                                        }

    @Test
                                                                        public void testAddMultipleOptions() throws Exception {
                                                                            // Get constructor and create instance using reflection
                                                                            Class<?> commandLineClass = Class.forName("org.apache.commons.cli.CommandLine");
                                                                            Object commandLine = commandLineClass.getDeclaredConstructor().newInstance();
                                                                            
                                                                            Option option1 = mock(Option.class);
                                                                            Option option2 = mock(Option.class);
                                                                            
                                                                            // Get addOption method using reflection
                                                                            Method addOptionMethod = commandLineClass.getDeclaredMethod("addOption", Option.class);
                                                                            addOptionMethod.setAccessible(true);
                                                                            
                                                                            // Invoke the method multiple times
                                                                            addOptionMethod.invoke(commandLine, option1);
                                                                            addOptionMethod.invoke(commandLine, option2);
                                                                            
                                                                            // Use reflection to access private field
                                                                            Field optionsField = commandLineClass.getDeclaredField("options");
                                                                            optionsField.setAccessible(true);
                                                                            Set<Option> options = (Set<Option>) optionsField.get(commandLine);
                                                                            
                                                                            // Verify all options were added
                                                                            assertTrue(options.contains(option1));
                                                                            assertTrue(options.contains(option2));
                                                                            assertEquals(2, options.size());
                                                                        }

    @Test
                                                                        public void testAddDuplicateOption() throws Exception {
                                                                            // Create mock objects
                                                                            Class<?> optionClass = Class.forName("org.apache.commons.cli.Option");
                                                                            Object mockOption = mock(optionClass);
                                                                            
                                                                            // Get CommandLine class and create instance
                                                                            Class<?> commandLineClass = Class.forName("org.apache.commons.cli.CommandLine");
                                                                            Object commandLine = commandLineClass.getDeclaredConstructor().newInstance();
                                                                            
                                                                            // Get addOption method and invoke it twice
                                                                            Method addOptionMethod = commandLineClass.getDeclaredMethod("addOption", optionClass);
                                                                            addOptionMethod.setAccessible(true);
                                                                            addOptionMethod.invoke(commandLine, mockOption);
                                                                            addOptionMethod.invoke(commandLine, mockOption);
                                                                        
                                                                            // Use reflection to access private field
                                                                            Field optionsField = commandLineClass.getDeclaredField("options");
                                                                            optionsField.setAccessible(true);
                                                                            Set<?> options = (Set<?>) optionsField.get(commandLine);
                                                                        
                                                                            // Verify only one instance exists (Set behavior)
                                                                            assertEquals(1, options.size());
                                                                            assertTrue(options.contains(mockOption));
                                                                        }

    @Test
                                                                        public void testIteratorWithOneOption() {
                                                                            List<Option> options = new ArrayList<>();
                                                                            Option option1 = new Option("test", "description");
                                                                            
                                                                            // Create CommandLine instance using reflection since constructor is not public
                                                                            CommandLine commandLine;
                                                                            try {
                                                                                commandLine = CommandLine.class.newInstance();
                                                                            } catch (Exception e) {
                                                                                fail("Failed to create CommandLine instance");
                                                                                return;
                                                                            }
                                                                            
                                                                            // Using reflection to access private field 'options' in CommandLine
                                                                            try {
                                                                                java.lang.reflect.Field optionsField = CommandLine.class.getDeclaredField("options");
                                                                                optionsField.setAccessible(true);
                                                                                optionsField.set(commandLine, options);
                                                                            } catch (Exception e) {
                                                                                fail("Failed to set options field via reflection");
                                                                            }
                                                                            
                                                                            options.add(option1);
                                                                            Iterator<Option> iterator = commandLine.iterator();
                                                                            assertNotNull(iterator);
                                                                            assertTrue(iterator.hasNext());
                                                                            assertEquals(option1, iterator.next());
                                                                            assertFalse(iterator.hasNext());
                                                                        }

    @Test
                                                                        public void testIteratorIsIndependentInstance() {
                                                                            List<Option> options = new ArrayList<>();
                                                                            Option option1 = new Option("a", "option a");
                                                                            options.add(option1);
                                                                            
                                                                            // Create CommandLine instance using reflection since constructor is not public
                                                                            CommandLine commandLine;
                                                                            try {
                                                                                commandLine = CommandLine.class.getDeclaredConstructor().newInstance();
                                                                            } catch (Exception e) {
                                                                                fail("Failed to create CommandLine instance");
                                                                                return;
                                                                            }
                                                                            
                                                                            // Use reflection to set the private options field
                                                                            try {
                                                                                java.lang.reflect.Field optionsField = CommandLine.class.getDeclaredField("options");
                                                                                optionsField.setAccessible(true);
                                                                                optionsField.set(commandLine, options);
                                                                            } catch (Exception e) {
                                                                                fail("Failed to set options field via reflection");
                                                                            }
                                                                            
                                                                            Iterator<Option> iterator1 = commandLine.iterator();
                                                                            Iterator<Option> iterator2 = commandLine.iterator();
                                                                            
                                                                            assertNotSame(iterator1, iterator2);
                                                                            assertTrue(iterator1.hasNext());
                                                                            assertTrue(iterator2.hasNext());
                                                                        }

    @Test
                                                                        public void testGetOptionsWhenEmpty() {
                                                                            try {
                                                                                // Use reflection to create CommandLine instance since constructor is not public
                                                                                CommandLine commandLine = CommandLine.class.getDeclaredConstructor().newInstance();
                                                                                
                                                                                // Use reflection to set the processed options collection
                                                                                try {
                                                                                    java.lang.reflect.Field processedField = CommandLine.class.getDeclaredField("processedOptions");
                                                                                    processedField.setAccessible(true);
                                                                                    processedField.set(commandLine, new ArrayList<Option>());
                                                                                } catch (Exception e) {
                                                                                    fail("Failed to set processedOptions field via reflection");
                                                                                }
                                                                                
                                                                                Option[] result = commandLine.getOptions();
                                                                                assertNotNull(result);
                                                                                assertEquals(0, result.length);
                                                                            } catch (Exception e) {
                                                                                fail("Failed to create CommandLine instance via reflection");
                                                                            }
                                                                        }

    @Test
                                                                        public void testGetOptionsWithSingleOption() {
                                                                            CommandLine commandLine = null;
                                                                            try {
                                                                                Constructor<CommandLine> constructor = CommandLine.class.getDeclaredConstructor();
                                                                                constructor.setAccessible(true);
                                                                                commandLine = constructor.newInstance();
                                                                            } catch (Exception e) {
                                                                                fail("Failed to create CommandLine instance via reflection");
                                                                            }
                                                                            
                                                                            Option option1 = new Option("test", "test option");
                                                                            
                                                                            Set<Option> optionsSet = new HashSet<>();
                                                                            optionsSet.add(option1);
                                                                            
                                                                            // Use reflection to set the private field
                                                                            try {
                                                                                Field field = CommandLine.class.getDeclaredField("options");
                                                                                field.setAccessible(true);
                                                                                field.set(commandLine, optionsSet);
                                                                            } catch (Exception e) {
                                                                                fail("Failed to set private field via reflection");
                                                                            }
                                                                        
                                                                            Option[] result = commandLine.getOptions();
                                                                            assertNotNull(result);
                                                                            assertEquals(1, result.length);
                                                                            assertEquals(option1, result[0]);
                                                                        }

    @Test
                                                                        public void testGetOptionObjectWithCharOptionExistsWithNullType() throws Exception {
                                                                            // Setup
                                                                            Option mockOption = mock(Option.class);
                                                                            // Use reflection to access private constructor
                                                                            Constructor<CommandLine> constructor = CommandLine.class.getDeclaredConstructor();
                                                                            constructor.setAccessible(true);
                                                                            CommandLine commandLine = constructor.newInstance();
                                                                            
                                                                            when(mockOption.getOpt()).thenReturn("d");
                                                                            when(mockOption.getType()).thenReturn(null);
                                                                            when(mockOption.getValues()).thenReturn(new String[]{"value"});
                                                                            
                                                                            // Use reflection to access private addOption method
                                                                            Method addOptionMethod = CommandLine.class.getDeclaredMethod("addOption", Option.class);
                                                                            addOptionMethod.setAccessible(true);
                                                                            addOptionMethod.invoke(commandLine, mockOption);
                                                                            
                                                                            // Test
                                                                            Object result = commandLine.getOptionObject('d');
                                                                            
                                                                            // Verify
                                                                            assertNull(result);
                                                                        }

    @Test
                                                                        public void testGetOptionValuesWithEmptyValues() throws Exception {
                                                                            // Setup
                                                                            Option mockOption = mock(Option.class);
                                                                            // Use reflection to access private constructor
                                                                            Constructor<CommandLine> constructor = CommandLine.class.getDeclaredConstructor();
                                                                            constructor.setAccessible(true);
                                                                            CommandLine commandLine = constructor.newInstance();
                                                                            
                                                                            when(mockOption.getOpt()).thenReturn("t");
                                                                            when(mockOption.getLongOpt()).thenReturn("test");
                                                                            when(mockOption.getValues()).thenReturn(new String[0]);
                                                                            
                                                                            // Use reflection to access private addOption method
                                                                            Method addOptionMethod = CommandLine.class.getDeclaredMethod("addOption", Option.class);
                                                                            addOptionMethod.setAccessible(true);
                                                                            addOptionMethod.invoke(commandLine, mockOption);
                                                                        
                                                                            // Test
                                                                            String[] result = commandLine.getOptionValues("t");
                                                                            assertNotNull(result);
                                                                            assertEquals(0, result.length);
                                                                        }

    @Test
                                                                    public void testResolveOptionNotFound() throws Exception {
                                                                        Option option1 = mock(Option.class);
                                                                        List<Option> options = new ArrayList<>();
                                                                        
                                                                        when(option1.getOpt()).thenReturn("g");
                                                                        when(option1.getLongOpt()).thenReturn("gamma");
                                                                        options.add(option1);
                                                                    
                                                                        Constructor<CommandLine> constructor = CommandLine.class.getDeclaredConstructor();
                                                                        constructor.setAccessible(true);
                                                                        CommandLine commandLine = constructor.newInstance();
                                                                        
                                                                        java.lang.reflect.Field optionsField = CommandLine.class.getDeclaredField("options");
                                                                        optionsField.setAccessible(true);
                                                                        optionsField.set(commandLine, options);
                                                                        
                                                                        java.lang.reflect.Method method = CommandLine.class.getDeclaredMethod("resolveOption", String.class);
                                                                        method.setAccessible(true);
                                                                        Option result = (Option) method.invoke(commandLine, "x");
                                                                        
                                                                        assertNull(result);
                                                                    }

    @Test
                                                                public void testResolveOption_PrivateMethod() throws Exception {
                                                                    Option mockOption = mock(Option.class);
                                                                    Collection<Option> options = new HashSet<>();
                                                                    Collection<String> args = new HashSet<>();
                                                                    Collection<Option> requiredOptions = new HashSet<>();
                                                                    Collection<String> processedArgs = new HashSet<>();
                                                                    
                                                                    // Create CommandLine instance using reflection since constructor might be private
                                                                    Class<?> clazz = Class.forName("org.apache.commons.cli.CommandLine");
                                                                    Object commandLine = clazz.getDeclaredConstructor().newInstance();
                                                                    
                                                                    // Set fields using reflection
                                                                    Field argsField = clazz.getDeclaredField("args");
                                                                    argsField.setAccessible(true);
                                                                    argsField.set(commandLine, args);
                                                                    
                                                                    Field requiredOptionsField = clazz.getDeclaredField("requiredOptions");
                                                                    requiredOptionsField.setAccessible(true);
                                                                    requiredOptionsField.set(commandLine, requiredOptions);
                                                                    
                                                                    Field processedArgsField = clazz.getDeclaredField("processedArgs");
                                                                    processedArgsField.setAccessible(true);
                                                                    processedArgsField.set(commandLine, processedArgs);
                                                            
                                                                    when(mockOption.getOpt()).thenReturn("opt");
                                                                    when(mockOption.getLongOpt()).thenReturn("longOpt");
                                                                    options.add(mockOption);
                                                                
                                                                    // Use reflection to set the options field
                                                                    Field optionsField = clazz.getDeclaredField("options");
                                                                    optionsField.setAccessible(true);
                                                                    optionsField.set(commandLine, options);
                                                                
                                                                    Method resolveOption = clazz.getDeclaredMethod("resolveOption", String.class);
                                                                    resolveOption.setAccessible(true);
                                                                
                                                                    Option result = (Option) resolveOption.invoke(commandLine, "opt");
                                                                    assertEquals(mockOption, result);
                                                                
                                                                    result = (Option) resolveOption.invoke(commandLine, "longOpt");
                                                                    assertEquals(mockOption, result);
                                                                
                                                                    result = (Option) resolveOption.invoke(commandLine, "nonexistent");
                                                                    assertNull(result);
                                                                }

    @Test
                                                                public void testGetOptionValuesWhenOptionExists() throws Exception {
                                                                    // Setup
                                                                    CommandLine commandLine = (CommandLine) CommandLine.class.getDeclaredConstructor().newInstance();
                                                                    Option mockOption = mock(Option.class);
                                                                    
                                                                    when(mockOption.getOpt()).thenReturn("test");
                                                                    when(mockOption.getLongOpt()).thenReturn("testLong");
                                                                    when(mockOption.getValues()).thenReturn(new String[]{"value1", "value2"});
                                                                    
                                                                    // Use reflection to access private addOption method
                                                                    Method addOptionMethod = CommandLine.class.getDeclaredMethod("addOption", Option.class);
                                                                    addOptionMethod.setAccessible(true);
                                                                    addOptionMethod.invoke(commandLine, mockOption);
                                                                    
                                                                    // Test
                                                                    String[] result = commandLine.getOptionValues("test");
                                                                    
                                                                    // Verify
                                                                    assertNotNull(result);
                                                                    assertEquals(2, result.length);
                                                                    assertEquals("value1", result[0]);
                                                                    assertEquals("value2", result[1]);
                                                                }

    @Test
                                                                public void testGetOptionValuesWithLongOptionName() throws Exception {
                                                                    // Setup
                                                                    Option mockOption = mock(Option.class);
                                                                    // Use reflection to access private constructor
                                                                    CommandLine commandLine = CommandLine.class.getDeclaredConstructor().newInstance();
                                                                    
                                                                    when(mockOption.getOpt()).thenReturn("t");
                                                                    when(mockOption.getLongOpt()).thenReturn("test");
                                                                    when(mockOption.getValues()).thenReturn(new String[]{"value"});
                                                                    
                                                                    // Use reflection to access private addOption method
                                                                    Method addOptionMethod = CommandLine.class.getDeclaredMethod("addOption", Option.class);
                                                                    addOptionMethod.setAccessible(true);
                                                                    addOptionMethod.invoke(commandLine, mockOption);
                                                                    
                                                                    // Test with long option name
                                                                    String[] result = commandLine.getOptionValues("test");
                                                                    assertNotNull(result);
                                                                    assertEquals(1, result.length);
                                                                    assertEquals("value", result[0]);
                                                                }

    @Test
                                                                public void testResolveOptionWithOnlyHyphens() throws Exception {
                                                                    List<Option> emptyOptions = new ArrayList<Option>();
                                                                    List<String> emptyArgs = new ArrayList<String>();
                                                                    CommandLine commandLine = CommandLine.class.getDeclaredConstructor(List.class, List.class)
                                                                                                              .newInstance(emptyOptions, emptyArgs);
                                                                    
                                                                    List<Option> options = new ArrayList<Option>();
                                                                    
                                                                    Method method = CommandLine.class.getDeclaredMethod("resolveOption", String.class, List.class);
                                                                    method.setAccessible(true);
                                                                    Option result = (Option) method.invoke(commandLine, "---", options);
                                                                    
                                                                    assertNull(result);
                                                                }

    @Test
                                                            public void testGetOptionValuesWithHyphenatedOptionName() throws Exception {
                                                                // Setup
                                                                Option mockOption = mock(Option.class);
                                                                // Create CommandLine instance using reflection since constructor is not public
                                                                CommandLine commandLine = CommandLine.class.newInstance();
                                                                
                                                                when(mockOption.getOpt()).thenReturn("t");
                                                                when(mockOption.getLongOpt()).thenReturn("test");
                                                                when(mockOption.getValues()).thenReturn(new String[]{"value"});
                                                                
                                                                // Use reflection to access private addOption method
                                                                Method addOptionMethod = CommandLine.class.getDeclaredMethod("addOption", Option.class);
                                                                addOptionMethod.setAccessible(true);
                                                                addOptionMethod.invoke(commandLine, mockOption);
                                                                
                                                                // Test with hyphenated option name
                                                                String[] result = commandLine.getOptionValues("--test");
                                                                assertNotNull(result);
                                                                assertEquals(1, result.length);
                                                                assertEquals("value", result[0]);
                                                            }

    @Test
                                                            public void testHasOption_WithDifferentCase() {
                                                                // Create required objects
                                                                Options options = new Options();
                                                                options.addOption("A", false, "test option");
                                                                
                                                                // Use reflection to create CommandLine instance since constructor is not public
                                                                CommandLine commandLine = null;
                                                                try {
                                                                    commandLine = CommandLine.class.newInstance();
                                                                } catch (Exception e) {
                                                                    fail("Failed to create CommandLine instance");
                                                                }
                                                                
                                                                // Use reflection to access private addOption method
                                                                try {
                                                                    java.lang.reflect.Method addOptionMethod = CommandLine.class.getDeclaredMethod("addOption", Option.class);
                                                                    addOptionMethod.setAccessible(true);
                                                                    
                                                                    // Get the option from Options
                                                                    Option option = options.getOption("A");
                                                                    addOptionMethod.invoke(commandLine, option);
                                                                } catch (Exception e) {
                                                                    fail("Failed to invoke private addOption method");
                                                                }
                                                                
                                                                assertFalse(commandLine.hasOption('a'));
                                                            }

    @Test
                                                        public void testResolveOptionWithMultipleOptions() throws Exception {
                                                            List<Option> options = new ArrayList<>();
                                                            Option option1 = mock(Option.class);
                                                            Option option2 = mock(Option.class);
                                                            
                                                            when(option1.getOpt()).thenReturn("e");
                                                            when(option1.getLongOpt()).thenReturn("epsilon");
                                                            when(option2.getOpt()).thenReturn("f");
                                                            when(option2.getLongOpt()).thenReturn("phi");
                                                            options.add(option1);
                                                            options.add(option2);
                                                        
                                                            // Create CommandLine instance using reflection since constructor isn't public
                                                            CommandLine commandLine = CommandLine.class.getDeclaredConstructor().newInstance();
                                                            
                                                            // Set the options field using reflection
                                                            Field optionsField = CommandLine.class.getDeclaredField("options");
                                                            optionsField.setAccessible(true);
                                                            optionsField.set(commandLine, options);
                                                            
                                                            Method resolveOptionMethod = CommandLine.class.getDeclaredMethod("resolveOption", String.class);
                                                            resolveOptionMethod.setAccessible(true);
                                                            Option result = (Option) resolveOptionMethod.invoke(commandLine, "f");
                                                            
                                                            assertEquals(option2, result);
                                                        }

    @Test
                                                public void testGetOptionObjectWithLongOptionName() {
                                                    // Create mock objects
                                                    Option mockOption = mock(Option.class);
                                                    ArrayList<Option> optionsList = new ArrayList<Option>();
                                                    ArrayList<String> argsList = new ArrayList<String>();
                                                    ArrayList<String> unrecognizedList = new ArrayList<String>();
                                                    
                                                    // Create command line instance using reflection since constructor is not public
                                                    CommandLine commandLine;
                                                    try {
                                                        Constructor<CommandLine> constructor = CommandLine.class.getDeclaredConstructor();
                                                        constructor.setAccessible(true);
                                                        commandLine = constructor.newInstance();
                                                    } catch (Exception e) {
                                                        fail("Failed to create CommandLine instance: " + e.getMessage());
                                                        return;
                                                    }
                                                    
                                                    // Setup mock behavior
                                                    when(mockOption.getOpt()).thenReturn("t");
                                                    when(mockOption.getLongOpt()).thenReturn("test");
                                                    when(mockOption.getType()).thenReturn(String.class);
                                                    
                                                    // Add option to command line
                                                    optionsList.add(mockOption);
                                                    
                                                    // Use reflection to set private fields
                                                    try {
                                                        java.lang.reflect.Field optionsField = CommandLine.class.getDeclaredField("options");
                                                        optionsField.setAccessible(true);
                                                        optionsField.set(commandLine, optionsList);
                                                        
                                                        java.lang.reflect.Field argsField = CommandLine.class.getDeclaredField("args");
                                                        argsField.setAccessible(true);
                                                        argsField.set(commandLine, argsList);
                                                        
                                                        java.lang.reflect.Field unrecognizedField = CommandLine.class.getDeclaredField("unrecognized");
                                                        unrecognizedField.setAccessible(true);
                                                        unrecognizedField.set(commandLine, unrecognizedList);
                                                    } catch (Exception e) {
                                                        fail("Reflection failed: " + e.getMessage());
                                                    }
                                                    
                                                    // Create spy and setup behavior
                                                    CommandLine spyCommandLine = spy(commandLine);
                                                    doReturn("value").when(spyCommandLine).getOptionValue("test");
                                                    
                                                    // Test the method
                                                    Object result = spyCommandLine.getOptionObject("test");
                                                    assertNotNull(result);
                                                }

    @Test
                                                public void testGetOptionValuesWithShortOptionName() throws Exception {
                                                    // Setup
                                                    CommandLine commandLine = (CommandLine) CommandLine.class.getDeclaredConstructor().newInstance();
                                                    Option mockOption = mock(Option.class);
                                                    
                                                    when(mockOption.getOpt()).thenReturn("t");
                                                    when(mockOption.getLongOpt()).thenReturn("test");
                                                    when(mockOption.getValues()).thenReturn(new String[]{"value"});
                                                    
                                                    // Use reflection to access private addOption method
                                                    Method addOptionMethod = CommandLine.class.getDeclaredMethod("addOption", Option.class);
                                                    addOptionMethod.setAccessible(true);
                                                    addOptionMethod.invoke(commandLine, mockOption);
                                                    
                                                    // Test with short option name
                                                    String[] result = commandLine.getOptionValues("t");
                                                    assertNotNull(result);
                                                    assertEquals(1, result.length);
                                                    assertEquals("value", result[0]);
                                                }

    @Test
                                            public void testGetOptionsWithMultipleOptions() {
                                                CommandLine commandLine;
                                                try {
                                                    commandLine = CommandLine.class.newInstance();
                                                } catch (Exception e) {
                                                    fail("Failed to create CommandLine instance");
                                                    return;
                                                }
                                                
                                                // Create test options
                                                Option option1 = new Option("a", "option a");
                                                Option option2 = new Option("b", "option b");
                                                
                                                Set<Option> optionsSet = new HashSet<Option>();
                                                optionsSet.add(option1);
                                                optionsSet.add(option2);
                                                
                                                // Use reflection to set the private field
                                                try {
                                                    Field field = CommandLine.class.getDeclaredField("options");
                                                    field.setAccessible(true);
                                                    field.set(commandLine, optionsSet);
                                                } catch (Exception e) {
                                                    fail("Failed to set private field via reflection");
                                                }
                                            
                                                Option[] result = commandLine.getOptions();
                                                assertNotNull(result);
                                                assertEquals(2, result.length);
                                                
                                                // Helper method to check if option exists in array
                                                boolean containsOption1 = false;
                                                boolean containsOption2 = false;
                                                for (Option opt : result) {
                                                    if (opt.getOpt().equals("a")) {
                                                        containsOption1 = true;
                                                    }
                                                    if (opt.getOpt().equals("b")) {
                                                        containsOption2 = true;
                                                    }
                                                }
                                                assertTrue(containsOption1);
                                                assertTrue(containsOption2);
                                            }

    @Test
                                        public void testGetOptionObjectWithCharOptionExistsWithDifferentType() throws Exception {
                                            // Setup
                                            CommandLine commandLine = (CommandLine) CommandLine.class.getDeclaredConstructor().newInstance();
                                            Option mockOption = mock(Option.class);
                                            
                                            when(mockOption.getOpt()).thenReturn("c");
                                            when(mockOption.getType()).thenReturn(Integer.class);
                                            when(mockOption.getValues()).thenReturn(new String[]{"123"});
                                            
                                            // Use reflection to access private addOption method
                                            Method addOptionMethod = CommandLine.class.getDeclaredMethod("addOption", Option.class);
                                            addOptionMethod.setAccessible(true);
                                            addOptionMethod.invoke(commandLine, mockOption);
                                        
                                            // Test
                                            Object result = commandLine.getOptionObject('c');
                                            
                                            // Verify
                                            assertNotNull(result);
                                            assertEquals(123, result);
                                        }

    @Test
                                        public void testResolveOptionWithNoHyphen() throws Exception {
                                            CommandLine commandLine = mock(CommandLine.class);
                                            Option option1 = mock(Option.class);
                                            List<Option> options = new ArrayList<>();
                                            
                                            when(option1.getOpt()).thenReturn("d");
                                            when(option1.getLongOpt()).thenReturn("delta");
                                            options.add(option1);
                                            
                                            Method resolveOptionMethod = CommandLine.class.getDeclaredMethod("resolveOption", String.class, List.class);
                                            resolveOptionMethod.setAccessible(true);
                                            Option result = (Option) resolveOptionMethod.invoke(commandLine, "d", options);
                                            
                                            assertEquals(option1, result);
                                        }

    @Test
                                        public void testGetOptionValuesWithCharOptionDoesNotExist() throws Exception {
                                            // Setup
                                            CommandLine commandLine = (CommandLine) CommandLine.class.getDeclaredConstructor().newInstance();
                                            char opt = 'b';
                                            Option mockOption = mock(Option.class);
                                            
                                            // Use reflection to access private addOption method
                                            Method addOptionMethod = CommandLine.class.getDeclaredMethod("addOption", Option.class);
                                            addOptionMethod.setAccessible(true);
                                            addOptionMethod.invoke(commandLine, mockOption);
                                            
                                            when(mockOption.getOpt()).thenReturn("a");
                                        
                                            // Test
                                            String[] result = commandLine.getOptionValues(opt);
                                        
                                            // Verify
                                            assertNull(result);
                                            verify(mockOption).getOpt();
                                        }

    @Test
                                        public void testGetOptionObjectWithHyphenatedOptionName() {
                                            // Create required mocks and objects
                                            CommandLine commandLine = mock(CommandLine.class);
                                            Options options = new Options();
                                            Option mockOption = mock(Option.class);
                                            
                                            // Set up mock behavior
                                            when(mockOption.getOpt()).thenReturn("t");
                                            when(mockOption.getLongOpt()).thenReturn("test");
                                            when(mockOption.getType()).thenReturn(String.class);
                                            options.addOption(mockOption);
                                            
                                            // Create spy and set up behavior
                                            CommandLine spyCommandLine = spy(commandLine);
                                            doReturn("value").when(spyCommandLine).getOptionValue("--test");
                                            doReturn(options).when(spyCommandLine).getOptions();
                                            
                                            // Test the method
                                            Object result = spyCommandLine.getOptionObject("--test");
                                            assertNotNull(result);
                                        }

    @Test
                                public void testIteratorWithMultipleOptions() {
                                    // Create test options
                                    Option option1 = new Option("a", "a option");
                                    Option option2 = new Option("b", "b option");
                                    
                                    // Create command line and add options
                                    CommandLine commandLine;
                                    try {
                                        commandLine = CommandLine.class.newInstance();
                                    } catch (Exception e) {
                                        fail("Failed to create CommandLine instance");
                                        return;
                                    }
                                    
                                    Set<Option> options = new HashSet<>();
                                    options.add(option1);
                                    options.add(option2);
                                    
                                    // Use reflection to set the options field
                                    try {
                                        java.lang.reflect.Field optionsField = CommandLine.class.getDeclaredField("options");
                                        optionsField.setAccessible(true);
                                        optionsField.set(commandLine, options);
                                    } catch (Exception e) {
                                        fail("Failed to set options field via reflection");
                                    }
                                    
                                    Iterator<Option> iterator = commandLine.iterator();
                                    assertNotNull(iterator);
                                    
                                    // Since we're using HashSet, order is not guaranteed
                                    Set<Option> returnedOptions = new HashSet<>();
                                    while (iterator.hasNext()) {
                                        returnedOptions.add(iterator.next());
                                    }
                                    
                                    assertEquals(2, returnedOptions.size());
                                    assertTrue(returnedOptions.contains(option1));
                                    assertTrue(returnedOptions.contains(option2));
                                }

    @Test
            public void testGetOptionObjectWhenOptionDoesNotExist() {
                CommandLine commandLine = mock(CommandLine.class);
                when(commandLine.getOptionObject(anyString())).thenReturn(null);
                Object result = commandLine.getOptionObject("nonexistent");
                assertNull(result);
            }

    @Test
        public void testHasOption_WithEmptyString_ReturnsFalse() {
            Option testOption = new Option("test", "test description");
            Options options = new Options();
            options.addOption(testOption);
        }

    @Test
        public void testHasOption_WhenOptionDoesNotExist() {
            Options options = new Options();
            Option option = new Option("a", "a option");
            options.addOption(option);
            
                
        }

    @Test
        public void testHasOption_WithEmptyOption() {
            Options options = new Options();
        }

    @Test
        public void testGetOptionValuesWithCharOptionNoOptionsAdded() {
            // Setup
            char opt = 'c';
            
            // Test
            
            // Verify
        }

    @Test
        public void testIteratorWhenNoOptions() {
            ArrayList<Option> options = new ArrayList<Option>();
            ArrayList<String> args = new ArrayList<String>();
            
            // Use reflection to set private fields if needed
            try {
                java.lang.reflect.Field optionsField = CommandLine.class.getDeclaredField("options");
                optionsField.setAccessible(true);
                
                java.lang.reflect.Field argsField = CommandLine.class.getDeclaredField("args");
                argsField.setAccessible(true);
            } catch (Exception e) {
                fail("Failed to set fields via reflection: " + e.getMessage());
            }
            
        }

    @Test
        public void testHasOption_WhenOptionDoesNotExist_ReturnsFalse() {
            Options options = new Options();
            Option existingOption = new Option("existing", "existing option");
            options.addOption(existingOption);
            
                
        }

    @Test
        public void testHasOption_WithNullInput_ReturnsFalse() {
            Option testOption = new Option("test", "test option");
            Options options = new Options();
            options.addOption(testOption);
        }

    @Test
        public void testGetOptionObjectWithShortOptionName() {
            // Create real Options object with no options
            Options realOptions = new Options();
            // Create CommandLine with empty options
            
            // Create mock objects
            Option mockOption = mock(Option.class);
            Options mockOptions = mock(Options.class);
            
            // Setup mock behavior
            when(mockOption.getOpt()).thenReturn("t");
            when(mockOption.getLongOpt()).thenReturn("test");
            when(mockOption.getType()).thenReturn(String.class);
            when(mockOptions.getOption("t")).thenReturn(mockOption);
            
            // Spy on the real commandLine
            
            // Test the method
        }

    @Test
        public void testGetOptionObjectWithCharOptionExistsButNoValue() throws Exception {
            // Setup
            CommandLine commandLine = (CommandLine) CommandLine.class.getDeclaredConstructor().newInstance();
            Option mockOption = mock(Option.class);
            when(mockOption.getOpt()).thenReturn("b");
            when(mockOption.getType()).thenReturn(String.class);
            when(mockOption.getValues()).thenReturn(null);
            
            // Use reflection to access private addOption method
            Method addOptionMethod = CommandLine.class.getDeclaredMethod("addOption", Option.class);
            addOptionMethod.setAccessible(true);
            addOptionMethod.invoke(commandLine, mockOption);
        
            // Test
            Object result = commandLine.getOptionObject('b');
            
            // Verify
            assertNull(result);
        }


}
