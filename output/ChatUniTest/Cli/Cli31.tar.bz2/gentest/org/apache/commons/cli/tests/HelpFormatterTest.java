package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
 
public class HelpFormatterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
        public void testAppendOptionWithShortOptNotRequired() throws Exception {
            StringBuffer buff = new StringBuffer();
            Option option = mock(Option.class);
            when(option.getOpt()).thenReturn("f");
            when(option.getLongOpt()).thenReturn(null);
            when(option.hasArg()).thenReturn(false);
            when(option.getArgName()).thenReturn(null);
            
            HelpFormatter formatter = new HelpFormatter();
            Method method = HelpFormatter.class.getDeclaredMethod("appendOption", StringBuffer.class, Option.class, boolean.class);
            method.setAccessible(true);
            String result = (String) method.invoke(formatter, buff, option, false);
            
            assertEquals("[-f]", result);
        }

    @Test
        public void testAppendOptionWithShortOptRequired() throws Exception {
            StringBuffer buff = new StringBuffer();
            Option option = mock(Option.class);
            when(option.getOpt()).thenReturn("f");
            when(option.getLongOpt()).thenReturn(null);
            when(option.hasArg()).thenReturn(false);
            when(option.getArgName()).thenReturn(null);
            
            HelpFormatter formatter = new HelpFormatter();
            Method method = HelpFormatter.class.getDeclaredMethod("appendOption", StringBuffer.class, Option.class, boolean.class);
            method.setAccessible(true);
            String result = (String) method.invoke(formatter, buff, option, true);
            
            assertEquals("-f", result);
        }

    @Test
        public void testAppendOptionWithLongOptNotRequired() throws Exception {
            StringBuffer buff = new StringBuffer();
            Option option = mock(Option.class);
            when(option.getOpt()).thenReturn(null);
            when(option.getLongOpt()).thenReturn("file");
            when(option.hasArg()).thenReturn(false);
            when(option.getArgName()).thenReturn(null);
            
            HelpFormatter formatter = new HelpFormatter();
            Method method = HelpFormatter.class.getDeclaredMethod("appendOption", StringBuffer.class, Option.class, boolean.class);
            method.setAccessible(true);
            method.invoke(formatter, buff, option, false);
            
            assertEquals("[--file]", buff.toString());
        }

    @Test
        public void testAppendOptionWithLongOptRequired() throws Exception {
            StringBuffer buff = new StringBuffer();
            Option option = mock(Option.class);
            when(option.getOpt()).thenReturn(null);
            when(option.getLongOpt()).thenReturn("file");
            when(option.hasArg()).thenReturn(false);
            when(option.getArgName()).thenReturn(null);
    
            HelpFormatter formatter = new HelpFormatter();
            Method method = HelpFormatter.class.getDeclaredMethod(
                "appendOption", StringBuffer.class, Option.class, boolean.class);
            method.setAccessible(true);
            String result = (String) method.invoke(formatter, buff, option, true);
            
            assertEquals("--file", result);
        }

    @Test
        public void testAppendOptionWithShortOptAndArgNotRequired() throws Exception {
            StringBuffer buff = new StringBuffer();
            Option option = mock(Option.class);
            when(option.getOpt()).thenReturn("f");
            when(option.getLongOpt()).thenReturn(null);
            when(option.hasArg()).thenReturn(true);
            when(option.getArgName()).thenReturn("filename");
            
            HelpFormatter formatter = new HelpFormatter();
            Method method = HelpFormatter.class.getDeclaredMethod(
                "appendOption", StringBuffer.class, Option.class, boolean.class);
            method.setAccessible(true);
            method.invoke(formatter, buff, option, false);
            
            assertEquals("[-f <filename>]", buff.toString());
        }

    @Test
        public void testAppendOptionWithShortOptAndArgRequired() throws Exception {
            StringBuffer buff = new StringBuffer();
            Option option = mock(Option.class);
            when(option.getOpt()).thenReturn("f");
            when(option.getLongOpt()).thenReturn(null);
            when(option.hasArg()).thenReturn(true);
            when(option.getArgName()).thenReturn("filename");
            
            HelpFormatter formatter = new HelpFormatter();
            Method method = HelpFormatter.class.getDeclaredMethod(
                "appendOption", StringBuffer.class, Option.class, boolean.class);
            method.setAccessible(true);
            method.invoke(formatter, buff, option, true);
            
            assertEquals("-f <filename>", buff.toString());
        }

    @Test
        public void testAppendOptionWithLongOptAndArgNotRequired() throws Exception {
            HelpFormatter helpFormatter = new HelpFormatter();
            Option option = mock(Option.class);
            StringBuffer buff = new StringBuffer();
            
            when(option.getOpt()).thenReturn(null);
            when(option.getLongOpt()).thenReturn("file");
            when(option.hasArg()).thenReturn(true);
            when(option.getArgName()).thenReturn("filename");
            helpFormatter.setLongOptSeparator("=");
            
            Method method = HelpFormatter.class.getDeclaredMethod(
                "appendOption", StringBuffer.class, Option.class, boolean.class);
            method.setAccessible(true);
            String result = (String) method.invoke(helpFormatter, buff, option, false);
            
            assertEquals("[--file=<filename>]", result);
        }

    @Test
        public void testAppendOptionWithLongOptAndArgRequired() throws Exception {
            HelpFormatter helpFormatter = new HelpFormatter();
            Option option = mock(Option.class);
            StringBuffer buff = new StringBuffer();
            
            when(option.getOpt()).thenReturn(null);
            when(option.getLongOpt()).thenReturn("file");
            when(option.hasArg()).thenReturn(true);
            when(option.getArgName()).thenReturn("filename");
            helpFormatter.setLongOptSeparator("=");
            
            Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                "appendOption", StringBuffer.class, Option.class, boolean.class);
            appendOptionMethod.setAccessible(true);
            appendOptionMethod.invoke(helpFormatter, buff, option, true);
            
            assertEquals("--file=<filename>", buff.toString());
        }

    @Test
        public void testAppendOptionWithShortOptAndBlankArgName() throws Exception {
            StringBuffer buff = new StringBuffer();
            Option option = mock(Option.class);
            when(option.getOpt()).thenReturn("f");
            when(option.getLongOpt()).thenReturn(null);
            when(option.hasArg()).thenReturn(true);
            when(option.getArgName()).thenReturn("");
            
            HelpFormatter formatter = new HelpFormatter();
            Method method = HelpFormatter.class.getDeclaredMethod(
                "appendOption", StringBuffer.class, Option.class, boolean.class);
            method.setAccessible(true);
            method.invoke(formatter, buff, option, true);
            
            assertEquals("-f ", buff.toString());
        }

    @Test
        public void testAppendOptionWithLongOptAndNullArgName() throws Exception {
            HelpFormatter helpFormatter = new HelpFormatter();
            Option option = mock(Option.class);
            StringBuffer buff = new StringBuffer();
            
            when(option.getOpt()).thenReturn(null);
            when(option.getLongOpt()).thenReturn("file");
            when(option.hasArg()).thenReturn(true);
            when(option.getArgName()).thenReturn(null);
            helpFormatter.setArgName("argument");
            
            Method method = HelpFormatter.class.getDeclaredMethod(
                "appendOption", StringBuffer.class, Option.class, boolean.class);
            method.setAccessible(true);
            String result = (String) method.invoke(helpFormatter, buff, option, true);
            
            assertEquals("--file=<argument>", result);
        }


}
