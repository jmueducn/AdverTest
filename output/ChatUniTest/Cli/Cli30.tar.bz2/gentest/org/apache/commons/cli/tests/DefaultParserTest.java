package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
 
public class DefaultParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                    public void testHandlePropertiesWithNullProperties() throws Exception {
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        Options options = new Options();
                                                                                        Method handlePropertiesMethod = DefaultParser.class.getDeclaredMethod("handleProperties", Properties.class);
                                                                                        handlePropertiesMethod.setAccessible(true);
                                                                                        handlePropertiesMethod.invoke(parser, (Properties) null);
                                                                                        // No exception should be thrown
                                                                                    }

    @Test(expected = UnrecognizedOptionException.class)
                                                                                    public void testHandlePropertiesWithUndefinedOption() throws Exception {
                                                                                        // Create test objects
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        Options options = mock(Options.class);
                                                                                        CommandLine cmd = mock(CommandLine.class);
                                                                                        
                                                                                        // Set up parser's private fields using reflection
                                                                                        Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                        optionsField.setAccessible(true);
                                                                                        optionsField.set(parser, options);
                                                                                        
                                                                                        Field cmdField = DefaultParser.class.getDeclaredField("cmd");
                                                                                        cmdField.setAccessible(true);
                                                                                        cmdField.set(parser, cmd);
                                                                                        
                                                                                        // Get private method to test
                                                                                        Method handlePropertiesMethod = DefaultParser.class.getDeclaredMethod("handleProperties", Properties.class);
                                                                                        handlePropertiesMethod.setAccessible(true);
                                                                                        
                                                                                        // Test data
                                                                                        Properties props = new Properties();
                                                                                        props.setProperty("undefinedOption", "value");
                                                                                        
                                                                                        // Mock behavior
                                                                                        when(options.getOption("undefinedOption")).thenReturn(null);
                                                                                        
                                                                                        // Invoke method
                                                                                        handlePropertiesMethod.invoke(parser, props);
                                                                                    }

    @Test
                                                                                    public void testIsArgument_WhenTokenIsNotOption() throws Exception {
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        Options options = mock(Options.class);
                                                                                        
                                                                                        // Set up the test
                                                                                        when(options.hasShortOption("a")).thenReturn(false);
                                                                                        
                                                                                        // Use reflection to access private method if needed
                                                                                        java.lang.reflect.Method method = DefaultParser.class.getDeclaredMethod("isArgument", String.class, Options.class);
                                                                                        method.setAccessible(true);
                                                                                        boolean result = (boolean) method.invoke(parser, "token", options);
                                                                                        
                                                                                        assertTrue(result);
                                                                                    }

    @Test
                                                                                    public void testIsArgument_WhenTokenIsOption() throws Exception {
                                                                                        // Create mock objects
                                                                                        Options options = mock(Options.class);
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        
                                                                                        // Use reflection to set private field
                                                                                        Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                        optionsField.setAccessible(true);
                                                                                        optionsField.set(parser, options);
                                                                                
                                                                                        // Mock behavior
                                                                                        when(options.hasShortOption("a")).thenReturn(true);
                                                                                        
                                                                                        // Use reflection to invoke private method
                                                                                        Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                        isArgumentMethod.setAccessible(true);
                                                                                        boolean result = (boolean) isArgumentMethod.invoke(parser, "-a");
                                                                                        
                                                                                        assertFalse(result);
                                                                                    }

    @Test
                                                                                    public void testIsArgument_WhenTokenIsNegativeNumber() throws Exception {
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                        isArgumentMethod.setAccessible(true);
                                                                                        boolean result = (boolean) isArgumentMethod.invoke(parser, "-123");
                                                                                        assertTrue(result);
                                                                                    }

    @Test
                                                                                    public void testIsArgument_WhenTokenIsNegativeDecimalNumber() throws Exception {
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                        isArgumentMethod.setAccessible(true);
                                                                                        boolean result = (boolean) isArgumentMethod.invoke(parser, "-123.45");
                                                                                        assertTrue(result);
                                                                                    }

    @Test
                                                                                    public void testIsArgument_WhenTokenIsNegativeNumberWithPlusSign() throws Exception {
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        Method method = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                        method.setAccessible(true);
                                                                                        boolean result = (boolean) method.invoke(parser, "+123");
                                                                                        assertFalse(result);
                                                                                    }

    @Test
                                                                                    public void testIsArgument_WhenTokenIsNotANumber() throws Exception {
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        Options options = mock(Options.class);
                                                                                        
                                                                                        // Set up the mock behavior
                                                                                        when(options.hasShortOption("a")).thenReturn(true);
                                                                                        
                                                                                        // Use reflection to set the private field
                                                                                        Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                        optionsField.setAccessible(true);
                                                                                        optionsField.set(parser, options);
                                                                                        
                                                                                        // Use reflection to invoke private method
                                                                                        Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                        isArgumentMethod.setAccessible(true);
                                                                                        boolean result = (boolean) isArgumentMethod.invoke(parser, "-abc");
                                                                                        
                                                                                        assertFalse(result);
                                                                                    }

    @Test
                                                                                    public void testIsArgument_WhenTokenIsEmptyString() throws Exception {
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                        isArgumentMethod.setAccessible(true);
                                                                                        boolean result = (boolean) isArgumentMethod.invoke(parser, "");
                                                                                        assertTrue(result);
                                                                                    }

    @Test
                                                                                    public void testIsArgument_WhenTokenIsSingleDash() throws Exception {
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                        isArgumentMethod.setAccessible(true);
                                                                                        boolean result = (boolean) isArgumentMethod.invoke(parser, "-");
                                                                                        assertTrue(result);
                                                                                    }

    @Test
                                                                                    public void testIsArgument_WhenTokenIsDoubleDash() throws Exception {
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                        isArgumentMethod.setAccessible(true);
                                                                                        boolean result = (boolean) isArgumentMethod.invoke(parser, "--");
                                                                                        assertTrue(result);
                                                                                    }

    @Test
                                                                                    public void testIsNegativeNumberWithPositiveNumber() throws Exception {
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                        isNegativeNumberMethod.setAccessible(true);
                                                                                        
                                                                                        boolean result = (boolean) isNegativeNumberMethod.invoke(parser, "123.45");
                                                                                        assertFalse(result);
                                                                                    }

    @Test
                                                                                    public void testIsNegativeNumberWithNonNumber() throws Exception {
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                        isNegativeNumberMethod.setAccessible(true);
                                                                                        boolean result = (boolean) isNegativeNumberMethod.invoke(parser, "abc");
                                                                                        assertFalse(result);
                                                                                    }

    @Test
                                                                                    public void testIsNegativeNumberWithPositive() throws Exception {
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                        isNegativeNumberMethod.setAccessible(true);
                                                                                        boolean result = (boolean) isNegativeNumberMethod.invoke(parser, "123");
                                                                                        assertFalse(result);
                                                                                    }

    @Test
                                                                                    public void testIsNegativeNumberWithNegative() throws Exception {
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                        isNegativeNumberMethod.setAccessible(true);
                                                                                        boolean result = (boolean) isNegativeNumberMethod.invoke(parser, "-123");
                                                                                        assertTrue(result);
                                                                                    }

    @Test
                                                                                    public void testIsNegativeNumberWithNonNumber1() throws Exception {
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                        isNegativeNumberMethod.setAccessible(true);
                                                                                        boolean result = (boolean) isNegativeNumberMethod.invoke(parser, "abc");
                                                                                        assertFalse(result);
                                                                                    }

    @Test
                                                                                    public void testIsNegativeNumberWithScientificNotation() throws Exception {
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                        isNegativeNumberMethod.setAccessible(true);
                                                                                        boolean result = (boolean) isNegativeNumberMethod.invoke(parser, "1.23e-4");
                                                                                        assertTrue(result);
                                                                                    }

    @Test
                                                                                    public void testIsNegativeNumberWithNonNumberString() throws Exception {
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                        isNegativeNumberMethod.setAccessible(true);
                                                                                        
                                                                                        boolean result = (boolean) isNegativeNumberMethod.invoke(parser, "abc");
                                                                                        assertFalse(result);
                                                                                    }

    @Test
                                                                                    public void testIsNegativeNumberWithEmptyString() throws Exception {
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                        isNegativeNumberMethod.setAccessible(true);
                                                                                        
                                                                                        boolean result = (boolean) isNegativeNumberMethod.invoke(parser, "");
                                                                                        assertFalse(result);
                                                                                    }

    @Test
                                                                                    public void testIsNegativeNumberWithNull() throws Exception {
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                        isNegativeNumberMethod.setAccessible(true);
                                                                                        
                                                                                        boolean result = (boolean) isNegativeNumberMethod.invoke(parser, (String) null);
                                                                                        assertFalse(result);
                                                                                    }

    @Test
                                                                                    public void testIsNegativeNumberWithNumberWithComma() throws Exception {
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                        isNegativeNumberMethod.setAccessible(true);
                                                                                        
                                                                                        boolean result = (boolean) isNegativeNumberMethod.invoke(parser, "123,45");
                                                                                        assertFalse(result);
                                                                                    }

    @Test
                                                                                    public void testIsNegativeNumberWithHexNumber() throws Exception {
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                        isNegativeNumberMethod.setAccessible(true);
                                                                                        
                                                                                        boolean result = (boolean) isNegativeNumberMethod.invoke(parser, "0x1A");
                                                                                        assertFalse(result);
                                                                                    }

    @Test
                                                                                    public void testIsNegativeNumberWithNumberWithSpaces() throws Exception {
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                        isNegativeNumberMethod.setAccessible(true);
                                                                                        
                                                                                        boolean result = (boolean) isNegativeNumberMethod.invoke(parser, " 123 ");
                                                                                        assertFalse(result);
                                                                                    }

    @Test
                                                                                public void testIsNegativeNumberWithNonNumber2() throws Exception {
                                                                                    org.apache.commons.cli.DefaultParser parser = new org.apache.commons.cli.DefaultParser();
                                                                                    Method isNegativeNumberMethod = org.apache.commons.cli.DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                    isNegativeNumberMethod.setAccessible(true);
                                                                                    boolean result = (boolean) isNegativeNumberMethod.invoke(parser, "abc");
                                                                                    assertFalse(result);
                                                                                }

    @Test
                                                                                public void testHandlePropertiesWithOptionAlreadyInCommandLine() throws Exception {
                                                                                    // Create test objects
                                                                                    DefaultParser parser = new DefaultParser();
                                                                                    Options options = mock(Options.class);
                                                                                    CommandLine cmd = mock(CommandLine.class);
                                                                                    Option option = mock(Option.class);
                                                                                    
                                                                                    // Set up reflection to access private method
                                                                                    Method handlePropertiesMethod = DefaultParser.class.getDeclaredMethod("handleProperties", Properties.class);
                                                                                    handlePropertiesMethod.setAccessible(true);
                                                                                    
                                                                                    // Set field values using reflection
                                                                                    Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                    optionsField.setAccessible(true);
                                                                                    optionsField.set(parser, options);
                                                                                    
                                                                                    Field cmdField = DefaultParser.class.getDeclaredField("cmd");
                                                                                    cmdField.setAccessible(true);
                                                                                    cmdField.set(parser, cmd);
                                                                                    
                                                                                    // Test execution
                                                                                    Properties props = new Properties();
                                                                                    props.setProperty("definedOption", "value");
                                                                                    
                                                                                    when(options.getOption("definedOption")).thenReturn(option);
                                                                                    when(cmd.hasOption("definedOption")).thenReturn(true);
                                                                                    
                                                                                    handlePropertiesMethod.invoke(parser, props);
                                                                                    
                                                                                    // Changed verification to not check addOption since it's not accessible
                                                                                    verify(cmd, never()).hasOption(anyString());
                                                                                }

    @Test
                                                                                public void testHandlePropertiesWithOptionInSelectedGroup() throws Exception {
                                                                                    // Create mocks
                                                                                    DefaultParser parser = spy(new DefaultParser());
                                                                                    Options options = mock(Options.class);
                                                                                    CommandLine cmd = mock(CommandLine.class);
                                                                                    Option option = mock(Option.class);
                                                                                    OptionGroup group = mock(OptionGroup.class);
                                                                            
                                                                                    // Set up parser fields using reflection
                                                                                    Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                    optionsField.setAccessible(true);
                                                                                    optionsField.set(parser, options);
                                                                            
                                                                                    Field cmdField = DefaultParser.class.getDeclaredField("cmd");
                                                                                    cmdField.setAccessible(true);
                                                                                    cmdField.set(parser, cmd);
                                                                            
                                                                                    Field currentOptionField = DefaultParser.class.getDeclaredField("currentOption");
                                                                                    currentOptionField.setAccessible(true);
                                                                                    currentOptionField.set(parser, null);
                                                                            
                                                                                    // Get handleProperties method
                                                                                    Method handlePropertiesMethod = DefaultParser.class.getDeclaredMethod("handleProperties", Properties.class);
                                                                                    handlePropertiesMethod.setAccessible(true);
                                                                            
                                                                                    // Test setup
                                                                                    Properties props = new Properties();
                                                                                    props.setProperty("groupOption", "value");
                                                                            
                                                                                    when(options.getOption("groupOption")).thenReturn(option);
                                                                                    when(options.getOptionGroup(option)).thenReturn(group);
                                                                                    when(group.getSelected()).thenReturn("selectedOption");
                                                                                    when(cmd.hasOption("groupOption")).thenReturn(false);
                                                                            
                                                                                    // Use reflection to access addOption method
                                                                                    Method addOptionMethod = cmd.getClass().getDeclaredMethod("addOption", Option.class);
                                                                                    addOptionMethod.setAccessible(true);
                                                                            
                                                                                    handlePropertiesMethod.invoke(parser, props);
                                                                            
                                                                                    verify(cmd, never()).getClass().getDeclaredMethod("addOption", Option.class);
                                                                                }

    @Test
                                                                                public void testHandlePropertiesWithOptionWithoutArgAndInvalidValue() throws Exception {
                                                                                    // Create mocks
                                                                                    DefaultParser parser = spy(new DefaultParser());
                                                                                    Options options = mock(Options.class);
                                                                                    CommandLine cmd = mock(CommandLine.class);
                                                                                    Option option = mock(Option.class);
                                                                                    
                                                                                    // Set up parser fields using reflection
                                                                                    Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                    optionsField.setAccessible(true);
                                                                                    optionsField.set(parser, options);
                                                                                    
                                                                                    Field cmdField = DefaultParser.class.getDeclaredField("cmd");
                                                                                    cmdField.setAccessible(true);
                                                                                    cmdField.set(parser, cmd);
                                                                                    
                                                                                    // Get handleProperties method via reflection
                                                                                    Method handlePropertiesMethod = DefaultParser.class.getDeclaredMethod("handleProperties", Properties.class);
                                                                                    handlePropertiesMethod.setAccessible(true);
                                                                                    
                                                                                    // Test setup
                                                                                    Properties props = new Properties();
                                                                                    props.setProperty("optionWithoutArg", "invalid");
                                                                                    
                                                                                    when(options.getOption("optionWithoutArg")).thenReturn(option);
                                                                                    when(options.getOptionGroup(option)).thenReturn(null);
                                                                                    when(cmd.hasOption("optionWithoutArg")).thenReturn(false);
                                                                                    when(option.hasArg()).thenReturn(false);
                                                                                    
                                                                                    // Invoke method
                                                                                    handlePropertiesMethod.invoke(parser, props);
                                                                                    
                                                                                    // Verify - using reflection to check internal state instead of verifying addOption
                                                                                    Field processedPropertiesField = DefaultParser.class.getDeclaredField("processedProperties");
                                                                                    processedPropertiesField.setAccessible(true);
                                                                                    assertFalse((boolean) processedPropertiesField.get(parser));
                                                                                }

    @Test
                                                                                public void testHandlePropertiesWithMultipleProperties() throws Exception {
                                                                                    // Create mocks
                                                                                    DefaultParser parser = spy(new DefaultParser());
                                                                                    Properties props = new Properties();
                                                                                    Enumeration<?> propertyNames = mock(Enumeration.class);
                                                                                    Options options = mock(Options.class);
                                                                                    CommandLine cmd = mock(CommandLine.class);
                                                                                    Option option = mock(Option.class);
                                                                                    
                                                                                    // Setup test data
                                                                                    props.setProperty("option1", "value1");
                                                                                    props.setProperty("option2", "value2");
                                                                                    
                                                                                    // Mock behavior
                                                                                    when(propertyNames.hasMoreElements()).thenReturn(true, true, false);
                                                                                    when(propertyNames.nextElement()).thenReturn("option1", "option2");
                                                                                    
                                                                                    when(options.getOption("option1")).thenReturn(option);
                                                                                    when(options.getOption("option2")).thenReturn(option);
                                                                                    when(options.getOptionGroup(option)).thenReturn(null);
                                                                                    when(cmd.hasOption(anyString())).thenReturn(false);
                                                                                    when(option.hasArg()).thenReturn(true);
                                                                                    when(option.getValues()).thenReturn(null);
                                                                                    
                                                                                    // Use reflection to set private fields
                                                                                    Method setOptionsMethod = DefaultParser.class.getDeclaredMethod("setOptions", Options.class);
                                                                                    setOptionsMethod.setAccessible(true);
                                                                                    setOptionsMethod.invoke(parser, options);
                                                                                    
                                                                                    Method setCommandLineMethod = DefaultParser.class.getDeclaredMethod("setCommandLine", CommandLine.class);
                                                                                    setCommandLineMethod.setAccessible(true);
                                                                                    setCommandLineMethod.invoke(parser, cmd);
                                                                                    
                                                                                    // Use reflection to set the properties enumeration
                                                                                    Method setPropertiesMethod = Properties.class.getDeclaredMethod("propertyNames");
                                                                                    setPropertiesMethod.setAccessible(true);
                                                                                    Field propertiesField = Properties.class.getDeclaredField("propertyNames");
                                                                                    propertiesField.setAccessible(true);
                                                                                    propertiesField.set(props, propertyNames);
                                                                                    
                                                                                    // Get handleProperties method via reflection
                                                                                    Method handlePropertiesMethod = DefaultParser.class.getDeclaredMethod("handleProperties", Properties.class);
                                                                                    handlePropertiesMethod.setAccessible(true);
                                                                                    handlePropertiesMethod.invoke(parser, props);
                                                                                    
                                                                                    // Verify using reflection
                                                                                    Method addOptionMethod = cmd.getClass().getDeclaredMethod("addOption", Option.class);
                                                                                    addOptionMethod.setAccessible(true);
                                                                                    verify(cmd, times(2)).getClass();
                                                                                }

    @Test
                                                                            public void testHandlePropertiesWithOptionWithoutArgAndValidValue() throws Exception {
                                                                                // Create test objects
                                                                                DefaultParser parser = new DefaultParser();
                                                                                Options options = mock(Options.class);
                                                                                CommandLine cmd = mock(CommandLine.class);
                                                                                Option option = mock(Option.class);
                                                                        
                                                                                // Set up parser's internal state using reflection
                                                                                Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                optionsField.setAccessible(true);
                                                                                optionsField.set(parser, options);
                                                                        
                                                                                Field cmdField = DefaultParser.class.getDeclaredField("cmd");
                                                                                cmdField.setAccessible(true);
                                                                                cmdField.set(parser, cmd);
                                                                        
                                                                                Field currentOptionField = DefaultParser.class.getDeclaredField("currentOption");
                                                                                currentOptionField.setAccessible(true);
                                                                                currentOptionField.set(parser, null);
                                                                        
                                                                                // Get handleProperties method via reflection
                                                                                Method handlePropertiesMethod = DefaultParser.class.getDeclaredMethod("handleProperties", Properties.class);
                                                                                handlePropertiesMethod.setAccessible(true);
                                                                        
                                                                                // Test data
                                                                                Properties props = new Properties();
                                                                                props.setProperty("optionWithoutArg", "true");
                                                                                
                                                                                // Mock behavior
                                                                                when(options.getOption("optionWithoutArg")).thenReturn(option);
                                                                                when(options.getOptionGroup(option)).thenReturn(null);
                                                                                when(cmd.hasOption("optionWithoutArg")).thenReturn(false);
                                                                                when(option.hasArg()).thenReturn(false);
                                                                                
                                                                                // Use reflection to verify the addOption call
                                                                                handlePropertiesMethod.invoke(parser, props);
                                                                                
                                                                                // Verify the option was added by checking the command line state through reflection
                                                                                Field optionsFieldAfter = DefaultParser.class.getDeclaredField("options");
                                                                                optionsFieldAfter.setAccessible(true);
                                                                                Options updatedOptions = (Options) optionsFieldAfter.get(parser);
                                                                                
                                                                                Field cmdFieldAfter = DefaultParser.class.getDeclaredField("cmd");
                                                                                cmdFieldAfter.setAccessible(true);
                                                                                CommandLine updatedCmd = (CommandLine) cmdFieldAfter.get(parser);
                                                                                
                                                                                // Verify the option was processed by checking the command line state
                                                                                Field argsField = CommandLine.class.getDeclaredField("args");
                                                                                argsField.setAccessible(true);
                                                                                Object args = argsField.get(updatedCmd);
                                                                                assertNotNull(args);
                                                                            }

    @Test
                                                                        public void testHandlePropertiesWithOptionWithArg() throws Exception {
                                                                            // Create mocks
                                                                            DefaultParser parser = mock(DefaultParser.class);
                                                                            Options options = mock(Options.class);
                                                                            CommandLine cmd = mock(CommandLine.class);
                                                                            Option option = mock(Option.class);
                                                                            OptionGroup group = null;
                                                                    
                                                                            // Setup reflection to access private method
                                                                            Method handlePropertiesMethod = DefaultParser.class.getDeclaredMethod("handleProperties", Properties.class);
                                                                            handlePropertiesMethod.setAccessible(true);
                                                                    
                                                                            // Set field values using reflection
                                                                            Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                            optionsField.setAccessible(true);
                                                                            optionsField.set(parser, options);
                                                                    
                                                                            Field cmdField = DefaultParser.class.getDeclaredField("cmd");
                                                                            cmdField.setAccessible(true);
                                                                            cmdField.set(parser, cmd);
                                                                    
                                                                            Properties props = new Properties();
                                                                            props.setProperty("optionWithArg", "argValue");
                                                                            
                                                                            when(options.getOption("optionWithArg")).thenReturn(option);
                                                                            when(options.getOptionGroup(option)).thenReturn(group);
                                                                            when(cmd.hasOption("optionWithArg")).thenReturn(false);
                                                                            when(option.hasArg()).thenReturn(true);
                                                                            when(option.getValues()).thenReturn(null);
                                                                            
                                                                            handlePropertiesMethod.invoke(parser, props);
                                                                            
                                                                            // Verify interactions using reflection
                                                                            Method addValueMethod = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                            addValueMethod.setAccessible(true);
                                                                            verify(option, times(1));
                                                                            addValueMethod.invoke(option, "argValue");
                                                                    
                                                                            Method addOptionMethod = CommandLine.class.getDeclaredMethod("addOption", Option.class);
                                                                            addOptionMethod.setAccessible(true);
                                                                            verify(cmd, times(1));
                                                                            addOptionMethod.invoke(cmd, option);
                                                                        }

    @Test
                public void testHandlePropertiesWithEmptyProperties() throws Exception {
                    DefaultParser parser = new DefaultParser();
                    Properties props = new Properties();
                    Options options = new Options();
                    
                    // Get private method using reflection
                    Method handlePropertiesMethod = DefaultParser.class.getDeclaredMethod("handleProperties", Properties.class);
                    handlePropertiesMethod.setAccessible(true);
                    
                    // Set required fields using reflection
                    Field optionsField = DefaultParser.class.getDeclaredField("options");
                    optionsField.setAccessible(true);
                    optionsField.set(parser, options);
                    
                    Field cmdField = DefaultParser.class.getDeclaredField("cmd");
                    cmdField.setAccessible(true);
                    
                    handlePropertiesMethod.invoke(parser, props);
                    // No exception should be thrown
                }


}
