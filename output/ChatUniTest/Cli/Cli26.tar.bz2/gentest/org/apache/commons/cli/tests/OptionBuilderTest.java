package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
 
public class OptionBuilderTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testCreateWithChar() throws Exception {
            OptionBuilder.withDescription("test description")
                         .withLongOpt("longopt")
                         .hasArg()
                         .isRequired()
                         .withType(String.class)
                         .withValueSeparator('=')
                         .withArgName("argname");
    
            Option option = OptionBuilder.create('t');
            
            assertEquals("t", option.getOpt());
            assertEquals("test description", option.getDescription());
            assertEquals("longopt", option.getLongOpt());
            assertTrue(option.isRequired());
            assertEquals(1, option.getArgs());
            assertEquals(String.class, option.getType());
            assertEquals('=', option.getValueSeparator());
            assertEquals("argname", option.getArgName());
        }

    @Test
        public void testCreateWithCharAndDefaultValues() throws Exception {
            Option option = OptionBuilder.create('x');
            
            assertEquals("x", option.getOpt());
            assertNull(option.getDescription());
            assertNull(option.getLongOpt());
            assertFalse(option.isRequired());
            assertEquals(Option.UNINITIALIZED, option.getArgs());
            assertNull(option.getType());
            assertEquals(0, option.getValueSeparator());
            assertEquals("arg", option.getArgName());
        }

    @Test(expected = IllegalArgumentException.class)
        public void testCreateWithInvalidChar() throws Exception {
            // This will throw IllegalArgumentException when trying to create option with null
            OptionBuilder.create((char) 0);
        }

    @Test
        public void testCreateWithCharAfterSettingOptionalArg() throws Exception {
            OptionBuilder.hasOptionalArg();
            Option option = OptionBuilder.create('o');
            
            assertTrue(option.hasOptionalArg());
            assertEquals(1, option.getArgs());
        }

    @Test
        public void testCreateWithCharAfterSettingMultipleArgs() throws Exception {
            OptionBuilder.hasArgs(3);
            Option option = OptionBuilder.create('m');
            
            assertEquals(3, option.getArgs());
        }

    @Test
        public void testCreateWithCharAfterSettingUnlimitedArgs() throws Exception {
            OptionBuilder.hasArgs();
            Option option = OptionBuilder.create('u');
            
            assertEquals(Option.UNLIMITED_VALUES, option.getArgs());
        }

    @Test
        public void testCreateWithCharAfterSettingOptionalArgs() throws Exception {
            OptionBuilder.hasOptionalArgs(2);
            Option option = OptionBuilder.create('p');
            
            assertTrue(option.hasOptionalArg());
            assertEquals(2, option.getArgs());
        }

    @Test
        public void testCreateWithCharAfterSettingValueSeparator() throws Exception {
            OptionBuilder.withValueSeparator(':');
            Option option = OptionBuilder.create('s');
            
            assertEquals(':', option.getValueSeparator());
        }

    @Test
        public void testCreateWithCharAfterSettingArgName() throws Exception {
            OptionBuilder.withArgName("customArg");
            Option option = OptionBuilder.create('a');
            
            assertEquals("customArg", option.getArgName());
        }

    @Test(expected = IllegalArgumentException.class)
        public void testCreateWhenLongoptIsNull() {
            OptionBuilder.create();
        }

    @Test
        public void testCreateWhenLongoptIsSet() throws Exception {
            String expectedLongOpt = "testLongOpt";
            String expectedDescription = "test description";
            boolean expectedRequired = true;
            int expectedNumberOfArgs = 2;
            char expectedValueSep = ':';
    
            // Set up the OptionBuilder
            OptionBuilder.withLongOpt(expectedLongOpt)
                        .withDescription(expectedDescription)
                        .isRequired(expectedRequired)
                        .hasArgs(expectedNumberOfArgs)
                        .withValueSeparator(expectedValueSep);
    
            // Create the option
            Option option = OptionBuilder.create();
    
            // Verify the option properties
            assertEquals(expectedLongOpt, option.getLongOpt());
            assertEquals(expectedDescription, option.getDescription());
            assertEquals(expectedRequired, option.isRequired());
            assertEquals(expectedNumberOfArgs, option.getArgs());
            assertEquals(expectedValueSep, option.getValueSeparator());
            assertFalse(option.hasOptionalArg());
        }

    @Test
        public void testCreateResetsFieldsAfterCreation() throws Exception {
            // Set some values
            OptionBuilder.withLongOpt("test").withDescription("desc").hasArg();
    
            // Create option
            OptionBuilder.create();
    
            // Verify fields are reset
            Field longoptField = OptionBuilder.class.getDeclaredField("longopt");
            longoptField.setAccessible(true);
            assertNull(longoptField.get(null));
    
            Field descriptionField = OptionBuilder.class.getDeclaredField("description");
            descriptionField.setAccessible(true);
            assertNull(descriptionField.get(null));
    
            Field numberOfArgsField = OptionBuilder.class.getDeclaredField("numberOfArgs");
            numberOfArgsField.setAccessible(true);
            assertEquals(Option.UNINITIALIZED, numberOfArgsField.get(null));
        }

    @Test
        public void testCreateWithOptionalArgs() throws Exception {
            String expectedLongOpt = "optionalTest";
            boolean expectedOptionalArg = true;
    
            OptionBuilder.withLongOpt(expectedLongOpt).hasOptionalArg();
            Option option = OptionBuilder.create();
    
            assertEquals(expectedLongOpt, option.getLongOpt());
            assertEquals(expectedOptionalArg, option.hasOptionalArg());
            assertEquals(1, option.getArgs());
        }

    @Test
        public void testCreateWithAllProperties() throws Exception {
            OptionBuilder.withLongOpt("longopt")
                .withDescription("description")
                .withArgName("argname")
                .isRequired(true)
                .hasArgs(2)
                .withType(String.class)
                .hasOptionalArg()
                .withValueSeparator('=');
    
            Option option = OptionBuilder.create("opt");
            
            assertEquals("opt", option.getOpt());
            assertEquals("longopt", option.getLongOpt());
            assertEquals("description", option.getDescription());
            assertEquals("argname", option.getArgName());
            assertTrue(option.isRequired());
            assertEquals(2, option.getArgs());
            assertEquals(String.class, option.getType());
            assertTrue(option.hasOptionalArg());
            assertEquals('=', option.getValueSeparator());
        }

    @Test
        public void testCreateWithMinimumProperties() throws Exception {
            OptionBuilder.withDescription("description");
            Option option = OptionBuilder.create("opt");
            
            assertEquals("opt", option.getOpt());
            assertEquals("description", option.getDescription());
            assertNull(option.getLongOpt());
            assertEquals("arg", option.getArgName());
            assertFalse(option.isRequired());
            assertEquals(Option.UNINITIALIZED, option.getArgs());
            assertNull(option.getType());
            assertFalse(option.hasOptionalArg());
            assertEquals(0, option.getValueSeparator());
        }

    @Test
        public void testCreateWithNullOpt() throws Exception {
            OptionBuilder.withLongOpt("longopt");
            Option option = OptionBuilder.create(null);
            
            assertNull(option.getOpt());
            assertEquals("longopt", option.getLongOpt());
        }

    @Test
        public void testCreateResetsProperties() throws Exception {
            OptionBuilder.withLongOpt("longopt")
                .withDescription("description")
                .isRequired(true);
    
            Option option = OptionBuilder.create("opt");
            
            // Verify properties are reset after create
            Field longoptField = OptionBuilder.class.getDeclaredField("longopt");
            longoptField.setAccessible(true);
            assertNull(longoptField.get(null));
    
            Field descriptionField = OptionBuilder.class.getDeclaredField("description");
            descriptionField.setAccessible(true);
            assertNull(descriptionField.get(null));
    
            Field requiredField = OptionBuilder.class.getDeclaredField("required");
            requiredField.setAccessible(true);
            assertFalse(requiredField.getBoolean(null));
        }

    @Test
        public void testCreateWithValueSeparator() throws Exception {
            OptionBuilder.withValueSeparator(':');
            Option option = OptionBuilder.create("opt");
            
            assertEquals(':', option.getValueSeparator());
        }

    @Test
        public void testCreateWithOptionalArgs1() throws Exception {
            OptionBuilder.hasOptionalArgs(3);
            Option option = OptionBuilder.create("opt");
            
            assertEquals(3, option.getArgs());
            assertTrue(option.hasOptionalArg());
        }

    @Test
        public void testCreateWithUnlimitedArgs() throws Exception {
            OptionBuilder.hasArgs();
            Option option = OptionBuilder.create("opt");
            
            assertEquals(Option.UNLIMITED_VALUES, option.getArgs());
        }

    @Test
        public void testCreateWithType() throws Exception {
            OptionBuilder.withType(Integer.class);
            Option option = OptionBuilder.create("opt");
            
            assertEquals(Integer.class, option.getType());
        }

}
