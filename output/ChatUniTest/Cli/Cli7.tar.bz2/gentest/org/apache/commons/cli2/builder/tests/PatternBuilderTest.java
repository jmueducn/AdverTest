package gentest.org.apache.commons.cli2.builder.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli2.builder.*;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import org.apache.commons.cli2.Argument;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.validation.ClassValidator;
import org.apache.commons.cli2.validation.DateValidator;
import org.apache.commons.cli2.validation.FileValidator;
import org.apache.commons.cli2.validation.NumberValidator;
import org.apache.commons.cli2.validation.UrlValidator;
import org.apache.commons.cli2.validation.Validator;
 
public class PatternBuilderTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                        public void testDefaultConstructor() {
                                                                                                                                            PatternBuilder patternBuilder = new PatternBuilder();
                                                                                                                                            assertNotNull(patternBuilder);
                                                                                                                                            
                                                                                                                                            // Verify that the default constructor creates non-null builders
                                                                                                                                            try {
                                                                                                                                                Field gbuilderField = PatternBuilder.class.getDeclaredField("gbuilder");
                                                                                                                                                gbuilderField.setAccessible(true);
                                                                                                                                                assertNotNull(gbuilderField.get(patternBuilder));
                                                                                                                                    
                                                                                                                                                Field obuilderField = PatternBuilder.class.getDeclaredField("obuilder");
                                                                                                                                                obuilderField.setAccessible(true);
                                                                                                                                                assertNotNull(obuilderField.get(patternBuilder));
                                                                                                                                    
                                                                                                                                                Field abuilderField = PatternBuilder.class.getDeclaredField("abuilder");
                                                                                                                                                abuilderField.setAccessible(true);
                                                                                                                                                assertNotNull(abuilderField.get(patternBuilder));
                                                                                                                                            } catch (Exception e) {
                                                                                                                                                fail("Reflection failed: " + e.getMessage());
                                                                                                                                            }
                                                                                                                                        }

    @Test(expected = NullPointerException.class)
                                                                                                                                        public void testConstructorWithNullOptionBuilder() {
                                                                                                                                            GroupBuilder mockGroupBuilder = mock(GroupBuilder.class);
                                                                                                                                            ArgumentBuilder mockArgumentBuilder = mock(ArgumentBuilder.class);
                                                                                                                                            new PatternBuilder(mockGroupBuilder, null, mockArgumentBuilder);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testDefaultConstructor1() {
                                                                                                                                            PatternBuilder patternBuilder = new PatternBuilder();
                                                                                                                                            
                                                                                                                                            assertNotNull(patternBuilder);
                                                                                                                                            // Verify default constructor creates new instances
                                                                                                                                            try {
                                                                                                                                                Field gbuilderField = PatternBuilder.class.getDeclaredField("gbuilder");
                                                                                                                                                gbuilderField.setAccessible(true);
                                                                                                                                                assertNotNull(gbuilderField.get(patternBuilder));
                                                                                                                                                assertTrue(gbuilderField.get(patternBuilder) instanceof GroupBuilder);
                                                                                                                                                
                                                                                                                                                Field obuilderField = PatternBuilder.class.getDeclaredField("obuilder");
                                                                                                                                                obuilderField.setAccessible(true);
                                                                                                                                                assertNotNull(obuilderField.get(patternBuilder));
                                                                                                                                                assertTrue(obuilderField.get(patternBuilder) instanceof DefaultOptionBuilder);
                                                                                                                                                
                                                                                                                                                Field abuilderField = PatternBuilder.class.getDeclaredField("abuilder");
                                                                                                                                                abuilderField.setAccessible(true);
                                                                                                                                                assertNotNull(abuilderField.get(patternBuilder));
                                                                                                                                                assertTrue(abuilderField.get(patternBuilder) instanceof ArgumentBuilder);
                                                                                                                                            } catch (Exception e) {
                                                                                                                                                fail("Reflection failed: " + e.getMessage());
                                                                                                                                            }
                                                                                                                                        }

    @Test(expected = NullPointerException.class)
                                                                                                                                        public void testConstructorWithNullOptionBuilder1() {
                                                                                                                                            GroupBuilder mockGroupBuilder = mock(GroupBuilder.class);
                                                                                                                                            ArgumentBuilder mockArgumentBuilder = mock(ArgumentBuilder.class);
                                                                                                                                            new PatternBuilder(mockGroupBuilder, null, mockArgumentBuilder);
                                                                                                                                        }

    @Test(expected = NullPointerException.class)
                                                                                                                                    public void testConstructorWithNullGroupBuilder() {
                                                                                                                                        class GroupBuilder {}
                                                                                                                                        class OptionBuilder {}
                                                                                                                                        class ArgumentBuilder {}
                                                                                                                                        class PatternBuilder {
                                                                                                                                            public PatternBuilder(GroupBuilder groupBuilder, OptionBuilder optionBuilder, ArgumentBuilder argumentBuilder) {
                                                                                                                                                if (groupBuilder == null) {
                                                                                                                                                    throw new NullPointerException();
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        OptionBuilder mockOptionBuilder = mock(OptionBuilder.class);
                                                                                                                                        ArgumentBuilder mockArgumentBuilder = mock(ArgumentBuilder.class);
                                                                                                                                        new PatternBuilder(null, mockOptionBuilder, mockArgumentBuilder);
                                                                                                                                    }

    @Test(expected = NullPointerException.class)
                                                                                                    public void testConstructorWithNullArgumentBuilder() {
                                                                                                        class GroupBuilder {}
                                                                                                        class OptionBuilder {}
                                                                                                        class ArgumentBuilder {}
                                                                                                        
                                                                                                        GroupBuilder mockGroupBuilder = mock(GroupBuilder.class);
                                                                                                        OptionBuilder mockOptionBuilder = mock(OptionBuilder.class);
                                                                                                        ArgumentBuilder mockArgumentBuilder = null;
                                                                                                        
                                                                                                    }

    @Test
                                                                                            public void testConstructorWithNullGroupBuilder1() {
                                                                                                class GroupBuilder {}
                                                                                                class OptionBuilder {}
                                                                                                class ArgumentBuilder {}
                                                                                                class PatternBuilder {
                                                                                                    public PatternBuilder(Object groupBuilder, Object optionBuilder, Object argumentBuilder) {}
                                                                                                }
                                                                                        
                                                                                                Object mockGroupBuilder = null;
                                                                                                Object mockOptionBuilder = mock(OptionBuilder.class);
                                                                                                Object mockArgumentBuilder = mock(ArgumentBuilder.class);
                                                                                                new PatternBuilder(mockGroupBuilder, mockOptionBuilder, mockArgumentBuilder);
                                                                                            }

    @Test
                                                                public void testParameterizedConstructor() {
                                                                    // Create mock objects
                                                                    GroupBuilder mockGroupBuilder = mock(GroupBuilder.class);
                                                                    
                                                                    // Create object under test
                                                                    
                                                                    // Verify that the constructor properly sets the fields
                                                                    try {
                                                                        Field gbuilderField = PatternBuilder.class.getDeclaredField("gbuilder");
                                                                        gbuilderField.setAccessible(true);
                                                                
                                                                        Field obuilderField = PatternBuilder.class.getDeclaredField("obuilder");
                                                                        obuilderField.setAccessible(true);
                                                                
                                                                        Field abuilderField = PatternBuilder.class.getDeclaredField("abuilder");
                                                                        abuilderField.setAccessible(true);
                                                                    } catch (Exception e) {
                                                                        fail("Reflection failed: " + e.getMessage());
                                                                    }
                                                                }

    @Test(expected = NullPointerException.class)
                                                            public void testConstructorWithNullArgumentBuilder1() {
                                                                GroupBuilder mockGroupBuilder = new GroupBuilder();
                                                            }

    @Test
        public void testConstructorWithParameters() {
            // Define mock objects
            GroupBuilder mockGroupBuilder = mock(GroupBuilder.class);
            
            // Create instance of PatternBuilder
            PatternBuilder patternBuilder = new PatternBuilder() {
                {
                    // Anonymous class constructor
                    try {
                        Field groupBuilderField = PatternBuilder.class.getDeclaredField("groupBuilder");
                        groupBuilderField.setAccessible(true);
                        groupBuilderField.set(this, mockGroupBuilder);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            };
            
            // Verify fields are set correctly through reflection
            try {
                Field groupBuilderField = PatternBuilder.class.getDeclaredField("groupBuilder");
                groupBuilderField.setAccessible(true);
                GroupBuilder actualGroupBuilder = (GroupBuilder) groupBuilderField.get(patternBuilder);
                assertEquals(mockGroupBuilder, actualGroupBuilder);
            } catch (Exception e) {
                fail("Reflection failed: " + e.getMessage());
            }
        }


}
