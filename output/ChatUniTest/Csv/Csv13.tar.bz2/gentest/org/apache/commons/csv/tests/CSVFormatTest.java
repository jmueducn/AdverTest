package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringWriter;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
 
public class CSVFormatTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                        public void testIsLineBreakWithNull() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            boolean result = (boolean) method.invoke(null, (Character) null);
                                                                                                                                                                            assertFalse(result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreakWithLF() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            boolean result = (boolean) method.invoke(null, '\n');
                                                                                                                                                                            assertTrue(result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreakWithCR() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            boolean result = (boolean) method.invoke(null, '\r');
                                                                                                                                                                            assertTrue(result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreakWithOtherCharacter() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            boolean result = (boolean) method.invoke(null, 'a');
                                                                                                                                                                            assertFalse(result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreakWithTab() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            boolean result = (boolean) method.invoke(null, '\t');
                                                                                                                                                                            assertFalse(result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testNewFormatWithValidDelimiter() {
                                                                                                                                                                            char delimiter = ',';
                                                                                                                                                                            CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                                                                                                            assertEquals(delimiter, format.getDelimiter());
                                                                                                                                                                            assertNull(format.getQuoteCharacter());
                                                                                                                                                                            assertNull(format.getQuoteMode());
                                                                                                                                                                            assertNull(format.getCommentMarker());
                                                                                                                                                                            assertNull(format.getEscapeCharacter());
                                                                                                                                                                            assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                                                                                                            assertFalse(format.getIgnoreEmptyLines());
                                                                                                                                                                            assertNull(format.getRecordSeparator());
                                                                                                                                                                            assertNull(format.getNullString());
                                                                                                                                                                            assertNull(format.getHeaderComments());
                                                                                                                                                                            assertNull(format.getHeader());
                                                                                                                                                                            assertFalse(format.getSkipHeaderRecord());
                                                                                                                                                                            assertFalse(format.getAllowMissingColumnNames());
                                                                                                                                                                            assertFalse(format.getIgnoreHeaderCase());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testNewFormatWithDifferentDelimiters() {
                                                                                                                                                                            char[] delimiters = {';', '\t', '|', '#'};
                                                                                                                                                                            for (char delimiter : delimiters) {
                                                                                                                                                                                CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                                                                                                                assertEquals(delimiter, format.getDelimiter());
                                                                                                                                                                            }
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testEqualsAndHashCodeConsistency() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.newFormat(',');
                                                                                                                                                                            CSVFormat format2 = CSVFormat.newFormat(',');
                                                                                                                                                                            assertEquals(format1, format2);
                                                                                                                                                                            assertEquals(format1.hashCode(), format2.hashCode());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testNotEqualsWithDifferentDelimiter() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.newFormat(',');
                                                                                                                                                                            CSVFormat format2 = CSVFormat.newFormat(';');
                                                                                                                                                                            assertNotEquals(format1, format2);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testValueOfWithDefault() {
                                                                                                                                                                            CSVFormat format = CSVFormat.valueOf("Default");
                                                                                                                                                                            assertEquals(CSVFormat.DEFAULT, format);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testValueOfWithExcel() {
                                                                                                                                                                            CSVFormat format = CSVFormat.valueOf("Excel");
                                                                                                                                                                            assertEquals(CSVFormat.EXCEL, format);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testValueOfWithMySQL() {
                                                                                                                                                                            CSVFormat format = CSVFormat.valueOf("MySQL");
                                                                                                                                                                            assertEquals(CSVFormat.MYSQL, format);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testValueOfWithRFC() {
                                                                                                                                                                            CSVFormat format = CSVFormat.valueOf("RFC4180");
                                                                                                                                                                            assertEquals(CSVFormat.RFC4180, format);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testValueOfWithTDF() {
                                                                                                                                                                            CSVFormat format = CSVFormat.valueOf("TDF");
                                                                                                                                                                            assertEquals(CSVFormat.TDF, format);
                                                                                                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                        public void testValueOfWithInvalidFormat() {
                                                                                                                                                                            CSVFormat.valueOf("InvalidFormat");
                                                                                                                                                                        }

    @Test(expected = NullPointerException.class)
                                                                                                                                                                        public void testValueOfWithNull() {
                                                                                                                                                                            CSVFormat.valueOf(null);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToStringArrayWithNullInput() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("toStringArray", Object[].class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            Object[] input = null;
                                                                                                                                                                            String[] result = (String[]) method.invoke(CSVFormat.DEFAULT, new Object[]{input});
                                                                                                                                                                            
                                                                                                                                                                            assertNull(result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToStringArrayWithEmptyArray() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("toStringArray", Object[].class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            Object[] input = new Object[0];
                                                                                                                                                                            String[] result = (String[]) method.invoke(CSVFormat.DEFAULT, new Object[]{input});
                                                                                                                                                                            
                                                                                                                                                                            assertNotNull(result);
                                                                                                                                                                            assertEquals(0, result.length);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToStringArrayWithNonNullValues() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("toStringArray", Object[].class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            Object[] input = {"test", 123, true};
                                                                                                                                                                            String[] result = (String[]) method.invoke(CSVFormat.DEFAULT, new Object[]{input});
                                                                                                                                                                            
                                                                                                                                                                            assertNotNull(result);
                                                                                                                                                                            assertEquals(3, result.length);
                                                                                                                                                                            assertEquals("test", result[0]);
                                                                                                                                                                            assertEquals("123", result[1]);
                                                                                                                                                                            assertEquals("true", result[2]);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToStringArrayWithNullValues() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("toStringArray", Object[].class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            Object[] input = {null, "test", null};
                                                                                                                                                                            String[] result = (String[]) method.invoke(CSVFormat.DEFAULT, new Object[]{input});
                                                                                                                                                                            
                                                                                                                                                                            assertNotNull(result);
                                                                                                                                                                            assertEquals(3, result.length);
                                                                                                                                                                            assertNull(result[0]);
                                                                                                                                                                            assertEquals("test", result[1]);
                                                                                                                                                                            assertNull(result[2]);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToStringArrayWithMixedValues() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("toStringArray", Object[].class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            Object[] input = {null, "hello", 42, null, false};
                                                                                                                                                                            String[] result = (String[]) method.invoke(CSVFormat.DEFAULT, new Object[]{input});
                                                                                                                                                                            
                                                                                                                                                                            assertNotNull(result);
                                                                                                                                                                            assertEquals(5, result.length);
                                                                                                                                                                            assertNull(result[0]);
                                                                                                                                                                            assertEquals("hello", result[1]);
                                                                                                                                                                            assertEquals("42", result[2]);
                                                                                                                                                                            assertNull(result[3]);
                                                                                                                                                                            assertEquals("false", result[4]);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testEqualsSameObject() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            assertTrue(format.equals(format));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testEqualsNull() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            assertFalse(format.equals(null));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testEqualsDifferentClass() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            assertFalse(format.equals("string"));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testEqualsDifferentDelimiter() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT;
                                                                                                                                                                            CSVFormat format2 = format1.withDelimiter(';');
                                                                                                                                                                            assertFalse(format1.equals(format2));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testEqualsDifferentQuoteMode() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT;
                                                                                                                                                                            CSVFormat format2 = format1.withQuoteMode(QuoteMode.ALL);
                                                                                                                                                                            assertFalse(format1.equals(format2));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testEqualsDifferentQuoteCharacter() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT;
                                                                                                                                                                            CSVFormat format2 = format1.withQuote('\'');
                                                                                                                                                                            assertFalse(format1.equals(format2));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testEqualsNullQuoteCharacter() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withQuote(null);
                                                                                                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withQuote('"');
                                                                                                                                                                            assertFalse(format1.equals(format2));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testEqualsDifferentCommentMarker() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withCommentMarker('#');
                                                                                                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withCommentMarker('!');
                                                                                                                                                                            assertFalse(format1.equals(format2));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testEqualsNullCommentMarker() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withCommentMarker(null);
                                                                                                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withCommentMarker('#');
                                                                                                                                                                            assertFalse(format1.equals(format2));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testEqualsDifferentEscapeCharacter() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withEscape('\\');
                                                                                                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withEscape('/');
                                                                                                                                                                            assertFalse(format1.equals(format2));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testEqualsNullEscapeCharacter() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withEscape(null);
                                                                                                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withEscape('\\');
                                                                                                                                                                            assertFalse(format1.equals(format2));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testEqualsDifferentNullString() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withNullString("N/A");
                                                                                                                                                                            assertFalse(format1.equals(format2));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testEqualsNullNullString() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withNullString(null);
                                                                                                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                                                                                                            assertFalse(format1.equals(format2));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testEqualsDifferentHeader() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withHeader("A", "B");
                                                                                                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withHeader("X", "Y");
                                                                                                                                                                            assertFalse(format1.equals(format2));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testEqualsNullHeader() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withHeader((String[]) null);
                                                                                                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withHeader("A", "B");
                                                                                                                                                                            assertFalse(format1.equals(format2));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testEqualsDifferentIgnoreSurroundingSpaces() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true);
                                                                                                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(false);
                                                                                                                                                                            assertFalse(format1.equals(format2));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testEqualsDifferentIgnoreEmptyLines() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withIgnoreEmptyLines(true);
                                                                                                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);
                                                                                                                                                                            assertFalse(format1.equals(format2));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testEqualsDifferentSkipHeaderRecord() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withSkipHeaderRecord(false);
                                                                                                                                                                            assertFalse(format1.equals(format2));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testEqualsDifferentRecordSeparator() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withRecordSeparator("\n");
                                                                                                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
                                                                                                                                                                            assertFalse(format1.equals(format2));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testEqualsNullRecordSeparator() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withRecordSeparator(null);
                                                                                                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withRecordSeparator("\n");
                                                                                                                                                                            assertFalse(format1.equals(format2));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testEqualsIdenticalFormats() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT
                                                                                                                                                                                .withDelimiter(',')
                                                                                                                                                                                .withQuote('"')
                                                                                                                                                                                .withCommentMarker('#')
                                                                                                                                                                                .withEscape('\\')
                                                                                                                                                                                .withNullString("NULL")
                                                                                                                                                                                .withHeader("A", "B")
                                                                                                                                                                                .withIgnoreSurroundingSpaces(true)
                                                                                                                                                                                .withIgnoreEmptyLines(true)
                                                                                                                                                                                .withSkipHeaderRecord(true)
                                                                                                                                                                                .withRecordSeparator("\n");
                                                                                                                                                                    
                                                                                                                                                                            CSVFormat format2 = CSVFormat.DEFAULT
                                                                                                                                                                                .withDelimiter(',')
                                                                                                                                                                                .withQuote('"')
                                                                                                                                                                                .withCommentMarker('#')
                                                                                                                                                                                .withEscape('\\')
                                                                                                                                                                                .withNullString("NULL")
                                                                                                                                                                                .withHeader("A", "B")
                                                                                                                                                                                .withIgnoreSurroundingSpaces(true)
                                                                                                                                                                                .withIgnoreEmptyLines(true)
                                                                                                                                                                                .withSkipHeaderRecord(true)
                                                                                                                                                                                .withRecordSeparator("\n");
                                                                                                                                                                    
                                                                                                                                                                            assertTrue(format1.equals(format2));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testEqualsDifferentButEqualHeaders() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withHeader("A", "B");
                                                                                                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withHeader(new String[]{"A", "B"});
                                                                                                                                                                            assertTrue(format1.equals(format2));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testFormatWithSingleValue() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            String result = format.format("test");
                                                                                                                                                                            assertEquals("test", result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testFormatWithMultipleValues() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            String result = format.format("one", "two", "three");
                                                                                                                                                                            assertEquals("one,two,three", result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testFormatWithNullValues() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                                                                                                            String result = format.format(null, "value", null);
                                                                                                                                                                            assertEquals("NULL,value,NULL", result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testFormatWithDifferentDelimiter() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
                                                                                                                                                                            String result = format.format("a", "b", "c");
                                                                                                                                                                            assertEquals("a;b;c", result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testFormatWithQuotes() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withQuote('"');
                                                                                                                                                                            String result = format.format("a", "b", "c");
                                                                                                                                                                            assertEquals("\"a\",\"b\",\"c\"", result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testFormatWithQuoteMode() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
                                                                                                                                                                            String result = format.format("a", "b", "c");
                                                                                                                                                                            assertEquals("\"a\",\"b\",\"c\"", result);
                                                                                                                                                                        }

    @Test(expected = IllegalStateException.class)
                                                                                                                                                                        public void testFormatThrowsIllegalStateExceptionOnIOException() throws IOException {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            StringWriter mockWriter = mock(StringWriter.class);
                                                                                                                                                                            when(mockWriter.toString()).thenThrow(new IOException("Test exception"));
                                                                                                                                                                            
                                                                                                                                                                            try {
                                                                                                                                                                                new CSVPrinter(mockWriter, format).printRecord("test");
                                                                                                                                                                            } catch (IOException e) {
                                                                                                                                                                                throw new IllegalStateException(e);
                                                                                                                                                                            }
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testFormatWithEmptyValues() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            String result = format.format("", "", "");
                                                                                                                                                                            assertEquals(",", result); // Two commas for three empty values
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testFormatWithSpecialCharacters() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            String result = format.format("a,b", "c\nd", "e\"f");
                                                                                                                                                                            assertEquals("\"a,b\",\"c\nd\",\"e\"\"f\"", result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testFormatWithRecordSeparator() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n");
                                                                                                                                                                            String result = format.format("line1", "line2");
                                                                                                                                                                            assertEquals("line1,line2", result); // separator only appears at end
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetCommentMarkerWhenSet() throws Exception {
                                                                                                                                                                            Character expectedComment = '#';
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withCommentMarker(expectedComment);
                                                                                                                                                                            assertEquals(expectedComment, format.getCommentMarker());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetCommentMarkerWhenNotSet() throws Exception {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withCommentMarker(null);
                                                                                                                                                                            assertNull(format.getCommentMarker());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetCommentMarkerWithReflection() throws Exception {
                                                                                                                                                                            Character expectedComment = '@';
                                                                                                                                                                            Field commentMarkerField = CSVFormat.class.getDeclaredField("commentMarker");
                                                                                                                                                                            commentMarkerField.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            commentMarkerField.set(format, expectedComment);
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(expectedComment, format.getCommentMarker());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetDelimiterWithDefaultFormat() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            assertEquals(',', format.getDelimiter());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetDelimiterWithExcelFormat() {
                                                                                                                                                                            CSVFormat format = CSVFormat.EXCEL;
                                                                                                                                                                            assertEquals(',', format.getDelimiter());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetDelimiterWithTDFFormat() {
                                                                                                                                                                            CSVFormat format = CSVFormat.TDF;
                                                                                                                                                                            assertEquals('\t', format.getDelimiter());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetDelimiterWithMySQLFormat() {
                                                                                                                                                                            CSVFormat format = CSVFormat.MYSQL;
                                                                                                                                                                            assertEquals('\t', format.getDelimiter());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetDelimiterWithCustomFormat() {
                                                                                                                                                                            CSVFormat format = CSVFormat.newFormat('|');
                                                                                                                                                                            assertEquals('|', format.getDelimiter());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetDelimiterAfterWithDelimiter() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
                                                                                                                                                                            assertEquals(';', format.getDelimiter());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetDelimiterWithRFC4180Format() {
                                                                                                                                                                            CSVFormat format = CSVFormat.RFC4180;
                                                                                                                                                                            assertEquals(',', format.getDelimiter());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetEscapeCharacterWhenSet() {
                                                                                                                                                                            Character escapeChar = '\\';
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withEscape(escapeChar);
                                                                                                                                                                            assertEquals(escapeChar, format.getEscapeCharacter());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetEscapeCharacterWhenNull() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withEscape(null);
                                                                                                                                                                            assertNull(format.getEscapeCharacter());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetEscapeCharacterInPredefinedFormats() {
                                                                                                                                                                            assertNull(CSVFormat.DEFAULT.getEscapeCharacter());
                                                                                                                                                                            assertNull(CSVFormat.RFC4180.getEscapeCharacter());
                                                                                                                                                                            assertEquals(Character.valueOf('\\'), CSVFormat.MYSQL.getEscapeCharacter());
                                                                                                                                                                            assertNull(CSVFormat.EXCEL.getEscapeCharacter());
                                                                                                                                                                            assertNull(CSVFormat.TDF.getEscapeCharacter());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetEscapeCharacterAfterMultipleWithOperations() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                                                                    .withDelimiter(';')
                                                                                                                                                                                    .withQuote('"')
                                                                                                                                                                                    .withEscape('\\')
                                                                                                                                                                                    .withRecordSeparator("\r\n");
                                                                                                                                                                            assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetEscapeCharacterInNewFormat() {
                                                                                                                                                                            CSVFormat format = CSVFormat.newFormat('|').withEscape('!');
                                                                                                                                                                            assertEquals(Character.valueOf('!'), format.getEscapeCharacter());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetHeaderWhenHeaderIsNull() throws Exception {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeader((String[]) null);
                                                                                                                                                                            assertNull(format.getHeader());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetHeaderWhenHeaderIsEmpty() throws Exception {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeader(new String[0]);
                                                                                                                                                                            assertNotNull(format.getHeader());
                                                                                                                                                                            assertEquals(0, format.getHeader().length);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetHeaderReturnsClone() throws Exception {
                                                                                                                                                                            String[] originalHeader = {"col1", "col2", "col3"};
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeader(originalHeader);
                                                                                                                                                                            
                                                                                                                                                                            String[] headerCopy = format.getHeader();
                                                                                                                                                                            assertNotSame(originalHeader, headerCopy);
                                                                                                                                                                            assertArrayEquals(originalHeader, headerCopy);
                                                                                                                                                                            
                                                                                                                                                                            // Verify modifying the copy doesn't affect the original
                                                                                                                                                                            headerCopy[0] = "modified";
                                                                                                                                                                            assertNotEquals(originalHeader[0], format.getHeader()[0]);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetHeaderWithSingleColumn() throws Exception {
                                                                                                                                                                            String[] header = {"column1"};
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeader(header);
                                                                                                                                                                            assertArrayEquals(header, format.getHeader());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetHeaderWithMultipleColumns() throws Exception {
                                                                                                                                                                            String[] header = {"col1", "col2", "col3"};
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeader(header);
                                                                                                                                                                            assertArrayEquals(header, format.getHeader());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetHeaderAfterModificationThroughReflection() throws Exception {
                                                                                                                                                                            String[] originalHeader = {"a", "b", "c"};
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeader(originalHeader);
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to modify the internal header array
                                                                                                                                                                            Field headerField = CSVFormat.class.getDeclaredField("header");
                                                                                                                                                                            headerField.setAccessible(true);
                                                                                                                                                                            String[] newHeader = {"x", "y", "z"};
                                                                                                                                                                            headerField.set(format, newHeader);
                                                                                                                                                                            
                                                                                                                                                                            assertArrayEquals(newHeader, format.getHeader());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetAllowMissingColumnNamesWithExcelFormat() {
                                                                                                                                                                            assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetAllowMissingColumnNamesWithDefaultFormat() {
                                                                                                                                                                            assertFalse(CSVFormat.DEFAULT.getAllowMissingColumnNames());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetIgnoreEmptyLines() throws Exception {
                                                                                                                                                                            // Test with ignoreEmptyLines = true
                                                                                                                                                                            CSVFormat formatTrue = CSVFormat.DEFAULT.withIgnoreEmptyLines(true);
                                                                                                                                                                            assertTrue(formatTrue.getIgnoreEmptyLines());
                                                                                                                                                                    
                                                                                                                                                                            // Test with ignoreEmptyLines = false
                                                                                                                                                                            CSVFormat formatFalse = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);
                                                                                                                                                                            assertFalse(formatFalse.getIgnoreEmptyLines());
                                                                                                                                                                    
                                                                                                                                                                            // Test default value (should be true for DEFAULT format)
                                                                                                                                                                            assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
                                                                                                                                                                    
                                                                                                                                                                            // Test RFC4180 format (should be false)
                                                                                                                                                                            assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
                                                                                                                                                                    
                                                                                                                                                                            // Test EXCEL format (should be false)
                                                                                                                                                                            assertFalse(CSVFormat.EXCEL.getIgnoreEmptyLines());
                                                                                                                                                                    
                                                                                                                                                                            // Test TDF format (should be true)
                                                                                                                                                                            assertTrue(CSVFormat.TDF.getIgnoreEmptyLines());
                                                                                                                                                                    
                                                                                                                                                                            // Test MYSQL format (should be false)
                                                                                                                                                                            assertFalse(CSVFormat.MYSQL.getIgnoreEmptyLines());
                                                                                                                                                                    
                                                                                                                                                                            // Test with reflection to ensure field is properly set
                                                                                                                                                                            Field ignoreEmptyLinesField = CSVFormat.class.getDeclaredField("ignoreEmptyLines");
                                                                                                                                                                            ignoreEmptyLinesField.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            boolean value = (boolean) ignoreEmptyLinesField.get(CSVFormat.DEFAULT);
                                                                                                                                                                            assertTrue(value);
                                                                                                                                                                            
                                                                                                                                                                            value = (boolean) ignoreEmptyLinesField.get(CSVFormat.RFC4180);
                                                                                                                                                                            assertFalse(value);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetIgnoreSurroundingSpacesWhenTrue() throws Exception {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true);
                                                                                                                                                                            assertTrue(format.getIgnoreSurroundingSpaces());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetIgnoreSurroundingSpacesWhenFalse() throws Exception {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(false);
                                                                                                                                                                            assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetIgnoreSurroundingSpacesDefaultValue() throws Exception {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetIgnoreSurroundingSpacesWithReflection() throws Exception {
                                                                                                                                                                            // Create a format with ignoreSurroundingSpaces set to true using reflection
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            Field field = CSVFormat.class.getDeclaredField("ignoreSurroundingSpaces");
                                                                                                                                                                            field.setAccessible(true);
                                                                                                                                                                            field.set(format, true);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(format.getIgnoreSurroundingSpaces());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetIgnoreHeaderCaseWhenTrue() throws Exception {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withIgnoreHeaderCase(true);
                                                                                                                                                                            assertTrue(format.getIgnoreHeaderCase());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetIgnoreHeaderCaseWhenFalse() throws Exception {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withIgnoreHeaderCase(false);
                                                                                                                                                                            assertFalse(format.getIgnoreHeaderCase());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetIgnoreHeaderCaseUsingReflection() throws Exception {
                                                                                                                                                                            // Create format with ignoreHeaderCase set to true
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withIgnoreHeaderCase(true);
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to get the ignoreHeaderCase field
                                                                                                                                                                            Field field = CSVFormat.class.getDeclaredField("ignoreHeaderCase");
                                                                                                                                                                            field.setAccessible(true);
                                                                                                                                                                            boolean value = field.getBoolean(format);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(value);
                                                                                                                                                                            assertEquals(value, format.getIgnoreHeaderCase());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetIgnoreHeaderCaseAfterModification() throws Exception {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withIgnoreHeaderCase(true);
                                                                                                                                                                            CSVFormat format2 = format1.withIgnoreHeaderCase(false);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(format1.getIgnoreHeaderCase());
                                                                                                                                                                            assertFalse(format2.getIgnoreHeaderCase());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetIgnoreHeaderCaseDefaultValue() throws Exception {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            assertFalse(format.getIgnoreHeaderCase());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetNullStringWhenNullStringIsSet() throws Exception {
                                                                                                                                                                            // Create a CSVFormat with a non-null nullString
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                                                                                                            
                                                                                                                                                                            // Verify the method returns the expected value
                                                                                                                                                                            assertEquals("NULL", format.getNullString());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetNullStringWhenNullStringIsNotSet() throws Exception {
                                                                                                                                                                            // Create a CSVFormat with null nullString
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            
                                                                                                                                                                            // Verify the method returns null
                                                                                                                                                                            assertNull(format.getNullString());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetNullStringAfterModification() throws Exception {
                                                                                                                                                                            // Create a CSVFormat with initial nullString
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withNullString("initial");
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to modify the private field
                                                                                                                                                                            Field nullStringField = CSVFormat.class.getDeclaredField("nullString");
                                                                                                                                                                            nullStringField.setAccessible(true);
                                                                                                                                                                            nullStringField.set(format, "modified");
                                                                                                                                                                            
                                                                                                                                                                            // Verify the method returns the modified value
                                                                                                                                                                            assertEquals("modified", format.getNullString());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetNullStringWithEmptyString() throws Exception {
                                                                                                                                                                            // Create a CSVFormat with empty string as nullString
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withNullString("");
                                                                                                                                                                            
                                                                                                                                                                            // Verify the method returns empty string
                                                                                                                                                                            assertEquals("", format.getNullString());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetNullStringWithWhitespace() throws Exception {
                                                                                                                                                                            // Create a CSVFormat with whitespace as nullString
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withNullString("   ");
                                                                                                                                                                            
                                                                                                                                                                            // Verify the method returns whitespace string
                                                                                                                                                                            assertEquals("   ", format.getNullString());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetQuoteCharacterWhenSet() {
                                                                                                                                                                            Character expectedQuote = '"';
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withQuote(expectedQuote);
                                                                                                                                                                            assertEquals(expectedQuote, format.getQuoteCharacter());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetQuoteCharacterWhenNull() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withQuote(null);
                                                                                                                                                                            assertNull(format.getQuoteCharacter());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetQuoteCharacterFromPredefinedFormats() {
                                                                                                                                                                            assertEquals(Character.valueOf('"'), CSVFormat.DEFAULT.getQuoteCharacter());
                                                                                                                                                                            assertEquals(Character.valueOf('"'), CSVFormat.EXCEL.getQuoteCharacter());
                                                                                                                                                                            assertEquals(Character.valueOf('"'), CSVFormat.RFC4180.getQuoteCharacter());
                                                                                                                                                                            assertEquals(Character.valueOf('"'), CSVFormat.TDF.getQuoteCharacter());
                                                                                                                                                                            assertNull(CSVFormat.MYSQL.getQuoteCharacter());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetQuoteCharacterAfterModification() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withQuote('"');
                                                                                                                                                                            assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
                                                                                                                                                                            
                                                                                                                                                                            format = format.withQuote('\'');
                                                                                                                                                                            assertEquals(Character.valueOf('\''), format.getQuoteCharacter());
                                                                                                                                                                            
                                                                                                                                                                            format = format.withQuote(null);
                                                                                                                                                                            assertNull(format.getQuoteCharacter());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetQuoteCharacterWithReflection() throws Exception {
                                                                                                                                                                            // Create a format with private constructor
                                                                                                                                                                            CSVFormat format = CSVFormat.newFormat(',');
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to set private quoteCharacter field
                                                                                                                                                                            Field quoteField = CSVFormat.class.getDeclaredField("quoteCharacter");
                                                                                                                                                                            quoteField.setAccessible(true);
                                                                                                                                                                            quoteField.set(format, '|');
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(Character.valueOf('|'), format.getQuoteCharacter());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetQuoteMode() {
                                                                                                                                                                            // Test with null quote mode
                                                                                                                                                                            CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                                                                .withQuoteMode(null);
                                                                                                                                                                            assertNull(format.getQuoteMode());
                                                                                                                                                                    
                                                                                                                                                                            // Test with MINIMAL quote mode
                                                                                                                                                                            format = CSVFormat.newFormat(',')
                                                                                                                                                                                .withQuoteMode(QuoteMode.MINIMAL);
                                                                                                                                                                            assertEquals(QuoteMode.MINIMAL, format.getQuoteMode());
                                                                                                                                                                    
                                                                                                                                                                            // Test with ALL quote mode
                                                                                                                                                                            format = CSVFormat.newFormat(',')
                                                                                                                                                                                .withQuoteMode(QuoteMode.ALL);
                                                                                                                                                                            assertEquals(QuoteMode.ALL, format.getQuoteMode());
                                                                                                                                                                    
                                                                                                                                                                            // Test with NON_NUMERIC quote mode
                                                                                                                                                                            format = CSVFormat.newFormat(',')
                                                                                                                                                                                .withQuoteMode(QuoteMode.NON_NUMERIC);
                                                                                                                                                                            assertEquals(QuoteMode.NON_NUMERIC, format.getQuoteMode());
                                                                                                                                                                    
                                                                                                                                                                            // Test with NONE quote mode
                                                                                                                                                                            format = CSVFormat.newFormat(',')
                                                                                                                                                                                .withQuoteMode(QuoteMode.NONE);
                                                                                                                                                                            assertEquals(QuoteMode.NONE, format.getQuoteMode());
                                                                                                                                                                    
                                                                                                                                                                            // Test with default format (should be null)
                                                                                                                                                                            assertEquals(null, CSVFormat.DEFAULT.getQuoteMode());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetSkipHeaderRecordWhenTrue() throws Exception {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                                                                                                            assertTrue(format.getSkipHeaderRecord());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetSkipHeaderRecordWhenFalse() throws Exception {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withSkipHeaderRecord(false);
                                                                                                                                                                            assertFalse(format.getSkipHeaderRecord());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetSkipHeaderRecordUsingReflection() throws Exception {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to set the private field
                                                                                                                                                                            Field skipHeaderRecordField = CSVFormat.class.getDeclaredField("skipHeaderRecord");
                                                                                                                                                                            skipHeaderRecordField.setAccessible(true);
                                                                                                                                                                            skipHeaderRecordField.set(format, true);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(format.getSkipHeaderRecord());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetSkipHeaderRecordDefaultValue() {
                                                                                                                                                                            assertFalse(CSVFormat.DEFAULT.getSkipHeaderRecord());
                                                                                                                                                                            assertFalse(CSVFormat.EXCEL.getSkipHeaderRecord());
                                                                                                                                                                            assertFalse(CSVFormat.MYSQL.getSkipHeaderRecord());
                                                                                                                                                                            assertFalse(CSVFormat.RFC4180.getSkipHeaderRecord());
                                                                                                                                                                            assertFalse(CSVFormat.TDF.getSkipHeaderRecord());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testHashCode() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT;
                                                                                                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withDelimiter(';');
                                                                                                                                                                            CSVFormat format3 = CSVFormat.DEFAULT.withQuote('"');
                                                                                                                                                                            CSVFormat format4 = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
                                                                                                                                                                            CSVFormat format5 = CSVFormat.DEFAULT.withCommentMarker('#');
                                                                                                                                                                            CSVFormat format6 = CSVFormat.DEFAULT.withEscape('\\');
                                                                                                                                                                            CSVFormat format7 = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                                                                                                            CSVFormat format8 = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true);
                                                                                                                                                                            CSVFormat format9 = CSVFormat.DEFAULT.withIgnoreHeaderCase(true);
                                                                                                                                                                            CSVFormat format10 = CSVFormat.DEFAULT.withIgnoreEmptyLines(true);
                                                                                                                                                                            CSVFormat format11 = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                                                                                                            CSVFormat format12 = CSVFormat.DEFAULT.withRecordSeparator("\n");
                                                                                                                                                                            CSVFormat format13 = CSVFormat.DEFAULT.withHeader("col1", "col2");
                                                                                                                                                                    
                                                                                                                                                                            assertNotEquals(0, format1.hashCode());
                                                                                                                                                                            assertNotEquals(format1.hashCode(), format2.hashCode());
                                                                                                                                                                            assertNotEquals(format1.hashCode(), format3.hashCode());
                                                                                                                                                                            assertNotEquals(format1.hashCode(), format4.hashCode());
                                                                                                                                                                            assertNotEquals(format1.hashCode(), format5.hashCode());
                                                                                                                                                                            assertNotEquals(format1.hashCode(), format6.hashCode());
                                                                                                                                                                            assertNotEquals(format1.hashCode(), format7.hashCode());
                                                                                                                                                                            assertNotEquals(format1.hashCode(), format8.hashCode());
                                                                                                                                                                            assertNotEquals(format1.hashCode(), format9.hashCode());
                                                                                                                                                                            assertNotEquals(format1.hashCode(), format10.hashCode());
                                                                                                                                                                            assertNotEquals(format1.hashCode(), format11.hashCode());
                                                                                                                                                                            assertNotEquals(format1.hashCode(), format12.hashCode());
                                                                                                                                                                            assertNotEquals(format1.hashCode(), format13.hashCode());
                                                                                                                                                                    
                                                                                                                                                                            // Test with null values
                                                                                                                                                                            CSVFormat formatWithNulls = CSVFormat.newFormat(',')
                                                                                                                                                                                .withQuote(null)
                                                                                                                                                                                .withQuoteMode(null)
                                                                                                                                                                                .withCommentMarker(null)
                                                                                                                                                                                .withEscape(null)
                                                                                                                                                                                .withNullString(null)
                                                                                                                                                                                .withRecordSeparator(null)
                                                                                                                                                                                .withHeader((String[])null);
                                                                                                                                                                            
                                                                                                                                                                            assertNotEquals(0, formatWithNulls.hashCode());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testHashCodeConsistency() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            int hashCode1 = format.hashCode();
                                                                                                                                                                            int hashCode2 = format.hashCode();
                                                                                                                                                                            assertEquals(hashCode1, hashCode2);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testHashCodeWithSameValues() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withDelimiter(';').withQuote('"');
                                                                                                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withDelimiter(';').withQuote('"');
                                                                                                                                                                            assertEquals(format1.hashCode(), format2.hashCode());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testHashCodeWithDifferentHeaderOrder() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withHeader("col1", "col2");
                                                                                                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withHeader("col2", "col1");
                                                                                                                                                                            assertNotEquals(format1.hashCode(), format2.hashCode());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testHashCodeWithEmptyHeader() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withHeader();
                                                                                                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withHeader(new String[0]);
                                                                                                                                                                            assertEquals(format1.hashCode(), format2.hashCode());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsCommentMarkerSetWhenCommentMarkerIsNull() throws Exception {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withCommentMarker(null);
                                                                                                                                                                            assertFalse(format.isCommentMarkerSet());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsCommentMarkerSetWhenCommentMarkerIsNotNull() throws Exception {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#');
                                                                                                                                                                            assertTrue(format.isCommentMarkerSet());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsCommentMarkerSetWithPrivateFieldAccess() throws Exception {
                                                                                                                                                                            // Create format with null comment marker
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withCommentMarker(null);
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to verify private field
                                                                                                                                                                            Field commentMarkerField = CSVFormat.class.getDeclaredField("commentMarker");
                                                                                                                                                                            commentMarkerField.setAccessible(true);
                                                                                                                                                                            assertNull(commentMarkerField.get(format));
                                                                                                                                                                            
                                                                                                                                                                            // Create format with non-null comment marker
                                                                                                                                                                            format = CSVFormat.DEFAULT.withCommentMarker('!');
                                                                                                                                                                            assertNotNull(commentMarkerField.get(format));
                                                                                                                                                                            assertTrue(format.isCommentMarkerSet());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsEscapeCharacterSetWhenEscapeCharacterIsNull() throws Exception {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withEscape(null);
                                                                                                                                                                            assertFalse(format.isEscapeCharacterSet());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsEscapeCharacterSetWhenEscapeCharacterIsNotNull() throws Exception {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withEscape('\\');
                                                                                                                                                                            assertTrue(format.isEscapeCharacterSet());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsEscapeCharacterSetWithReflection() throws Exception {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            
                                                                                                                                                                            // Set escapeCharacter to null using reflection
                                                                                                                                                                            Field escapeField = CSVFormat.class.getDeclaredField("escapeCharacter");
                                                                                                                                                                            escapeField.setAccessible(true);
                                                                                                                                                                            escapeField.set(format, null);
                                                                                                                                                                            assertFalse(format.isEscapeCharacterSet());
                                                                                                                                                                            
                                                                                                                                                                            // Set escapeCharacter to a value using reflection
                                                                                                                                                                            escapeField.set(format, '\\');
                                                                                                                                                                            assertTrue(format.isEscapeCharacterSet());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsNullStringSetWhenNullStringIsNull() throws Exception {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withNullString(null);
                                                                                                                                                                            assertFalse(format.isNullStringSet());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsNullStringSetWhenNullStringIsNotNull() throws Exception {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                                                                                                            assertTrue(format.isNullStringSet());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsNullStringSetWhenNullStringIsEmpty() throws Exception {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withNullString("");
                                                                                                                                                                            assertTrue(format.isNullStringSet());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsNullStringSetWhenNullStringIsWhitespace() throws Exception {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withNullString(" ");
                                                                                                                                                                            assertTrue(format.isNullStringSet());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsNullStringSetUsingReflection() throws Exception {
                                                                                                                                                                            // Create a format with null string set
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withNullString("NA");
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to access the private field
                                                                                                                                                                            java.lang.reflect.Field field = CSVFormat.class.getDeclaredField("nullString");
                                                                                                                                                                            field.setAccessible(true);
                                                                                                                                                                            String nullStringValue = (String) field.get(format);
                                                                                                                                                                            
                                                                                                                                                                            // Verify the method returns the expected result
                                                                                                                                                                            assertEquals(nullStringValue != null, format.isNullStringSet());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsQuoteCharacterSetWhenQuoteCharacterIsNull() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withQuote(null);
                                                                                                                                                                            assertFalse(format.isQuoteCharacterSet());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsQuoteCharacterSetWhenQuoteCharacterIsNotNull() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withQuote('"');
                                                                                                                                                                            assertTrue(format.isQuoteCharacterSet());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsQuoteCharacterSetWithDifferentQuoteCharacters() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withQuote('\'');
                                                                                                                                                                            assertTrue(format1.isQuoteCharacterSet());
                                                                                                                                                                    
                                                                                                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withQuote('|');
                                                                                                                                                                            assertTrue(format2.isQuoteCharacterSet());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsQuoteCharacterSetWithDefaultFormat() {
                                                                                                                                                                            assertTrue(CSVFormat.DEFAULT.isQuoteCharacterSet());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsQuoteCharacterSetWithMySQLFormat() {
                                                                                                                                                                            assertFalse(CSVFormat.MYSQL.isQuoteCharacterSet());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsQuoteCharacterSetWithExcelFormat() {
                                                                                                                                                                            assertTrue(CSVFormat.EXCEL.isQuoteCharacterSet());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsQuoteCharacterSetWithTDFFormat() {
                                                                                                                                                                            assertTrue(CSVFormat.TDF.isQuoteCharacterSet());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsQuoteCharacterSetWithRFC4180Format() {
                                                                                                                                                                            assertTrue(CSVFormat.RFC4180.isQuoteCharacterSet());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreakChar() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, ','));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreakCharacter() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, ','));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, (Character) null));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToStringWithMinimumFields() {
                                                                                                                                                                            CSVFormat format = CSVFormat.newFormat('\t');
                                                                                                                                                                            String expected = "Delimiter=<	>";
                                                                                                                                                                            assertEquals(expected, format.toString());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToStringWithEscapeCharacter() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withEscape('\\');
                                                                                                                                                                            String expected = "Delimiter=<,> Escape=<\\>";
                                                                                                                                                                            assertEquals(expected, format.toString());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToStringWithQuoteCharacter() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withQuote('"');
                                                                                                                                                                            String expected = "Delimiter=<,> QuoteChar=<\">";
                                                                                                                                                                            assertEquals(expected, format.toString());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToStringWithCommentMarker() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#');
                                                                                                                                                                            String expected = "Delimiter=<,> CommentStart=<#>";
                                                                                                                                                                            assertEquals(expected, format.toString());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToStringWithNullString() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                                                                                                            String expected = "Delimiter=<,> NullString=<NULL>";
                                                                                                                                                                            assertEquals(expected, format.toString());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToStringWithRecordSeparator() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n");
                                                                                                                                                                            String expected = "Delimiter=<,> RecordSeparator=<\n>";
                                                                                                                                                                            assertEquals(expected, format.toString());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToStringWithIgnoreEmptyLines() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withIgnoreEmptyLines(true);
                                                                                                                                                                            String expected = "Delimiter=<,> EmptyLines:ignored";
                                                                                                                                                                            assertEquals(expected, format.toString());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToStringWithIgnoreSurroundingSpaces() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true);
                                                                                                                                                                            String expected = "Delimiter=<,> SurroundingSpaces:ignored";
                                                                                                                                                                            assertEquals(expected, format.toString());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToStringWithIgnoreHeaderCase() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withIgnoreHeaderCase(true);
                                                                                                                                                                            String expected = "Delimiter=<,> IgnoreHeaderCase:ignored";
                                                                                                                                                                            assertEquals(expected, format.toString());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToStringWithSkipHeaderRecord() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                                                                                                            String expected = "Delimiter=<,> SkipHeaderRecord:true";
                                                                                                                                                                            assertEquals(expected, format.toString());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToStringWithHeaderComments() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeaderComments("Comment1", "Comment2");
                                                                                                                                                                            String expected = "Delimiter=<,> HeaderComments:[Comment1, Comment2]";
                                                                                                                                                                            assertEquals(expected, format.toString());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToStringWithHeader() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeader("Col1", "Col2");
                                                                                                                                                                            String expected = "Delimiter=<,> Header:[Col1, Col2]";
                                                                                                                                                                            assertEquals(expected, format.toString());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToStringWithQuoteMode() throws Exception {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
                                                                                                                                                                            // Quote mode doesn't appear in toString() output
                                                                                                                                                                            String expected = "Delimiter=<,>";
                                                                                                                                                                            assertEquals(expected, format.toString());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithCommentMarkerCharacter() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            Character commentMarker = '#';
                                                                                                                                                                            CSVFormat newFormat = format.withCommentMarker(commentMarker);
                                                                                                                                                                            
                                                                                                                                                                            assertNotNull(newFormat);
                                                                                                                                                                            assertEquals(commentMarker, newFormat.getCommentMarker());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithCommentMarkerNull() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            CSVFormat newFormat = format.withCommentMarker(null);
                                                                                                                                                                            
                                                                                                                                                                            assertNotNull(newFormat);
                                                                                                                                                                            assertNull(newFormat.getCommentMarker());
                                                                                                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                        public void testWithCommentMarkerLineBreak() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            format.withCommentMarker('\n');
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithCommentMarkerChar() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            char commentMarker = '#';
                                                                                                                                                                            CSVFormat newFormat = format.withCommentMarker(commentMarker);
                                                                                                                                                                            
                                                                                                                                                                            assertNotNull(newFormat);
                                                                                                                                                                            assertEquals(Character.valueOf(commentMarker), newFormat.getCommentMarker());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreakChar1() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreakCharacter1() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, (Character) null));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithCommentMarker_ValidCharacter() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#');
                                                                                                                                                                            assertEquals(Character.valueOf('#'), format.getCommentMarker());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithCommentMarker_Null() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withCommentMarker(null);
                                                                                                                                                                            assertNull(format.getCommentMarker());
                                                                                                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                        public void testWithCommentMarker_LineBreakCR() {
                                                                                                                                                                            CSVFormat.DEFAULT.withCommentMarker('\r');
                                                                                                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                        public void testWithCommentMarker_LineBreakLF() {
                                                                                                                                                                            CSVFormat.DEFAULT.withCommentMarker('\n');
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithCommentMarker_CharacterObject() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withCommentMarker(Character.valueOf('*'));
                                                                                                                                                                            assertEquals(Character.valueOf('*'), format.getCommentMarker());
                                                                                                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                        public void testWithCommentMarker_LineBreakCharacterObject() {
                                                                                                                                                                            CSVFormat.DEFAULT.withCommentMarker(Character.valueOf('\r'));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreak_PrivateMethod() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, '#'));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, null));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithCommentMarker_PreservesOtherSettings() {
                                                                                                                                                                            CSVFormat original = CSVFormat.DEFAULT
                                                                                                                                                                                .withDelimiter(';')
                                                                                                                                                                                .withQuote('"')
                                                                                                                                                                                .withEscape('\\')
                                                                                                                                                                                .withIgnoreSurroundingSpaces(true)
                                                                                                                                                                                .withIgnoreEmptyLines(false);
                                                                                                                                                                            
                                                                                                                                                                            CSVFormat modified = original.withCommentMarker('#');
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(';', modified.getDelimiter());
                                                                                                                                                                            assertEquals(Character.valueOf('"'), modified.getQuoteCharacter());
                                                                                                                                                                            assertEquals(Character.valueOf('\\'), modified.getEscapeCharacter());
                                                                                                                                                                            assertTrue(modified.getIgnoreSurroundingSpaces());
                                                                                                                                                                            assertFalse(modified.getIgnoreEmptyLines());
                                                                                                                                                                            assertEquals(Character.valueOf('#'), modified.getCommentMarker());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithDelimiterValidCharacter() {
                                                                                                                                                                            char delimiter = ',';
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withDelimiter(delimiter);
                                                                                                                                                                            assertEquals(delimiter, format.getDelimiter());
                                                                                                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                        public void testWithDelimiterLineBreakLF() {
                                                                                                                                                                            CSVFormat.DEFAULT.withDelimiter('\n');
                                                                                                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                        public void testWithDelimiterLineBreakCR() {
                                                                                                                                                                            CSVFormat.DEFAULT.withDelimiter('\r');
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithDelimiterPreservesOtherSettings() {
                                                                                                                                                                            CSVFormat original = CSVFormat.DEFAULT
                                                                                                                                                                                .withQuote('"')
                                                                                                                                                                                .withCommentMarker('#')
                                                                                                                                                                                .withEscape('\\')
                                                                                                                                                                                .withIgnoreSurroundingSpaces(true)
                                                                                                                                                                                .withIgnoreEmptyLines(true)
                                                                                                                                                                                .withRecordSeparator("\r\n")
                                                                                                                                                                                .withNullString("NULL")
                                                                                                                                                                                .withHeader("Header1", "Header2")
                                                                                                                                                                                .withSkipHeaderRecord(true)
                                                                                                                                                                                .withIgnoreHeaderCase(true);
                                                                                                                                                                    
                                                                                                                                                                            CSVFormat modified = original.withDelimiter(';');
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(';', modified.getDelimiter());
                                                                                                                                                                            assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                                                                                                            assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                                                                                                            assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                                                                                                            assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                                                                                                            assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                                                                                                            assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                                                                                                            assertEquals(original.getNullString(), modified.getNullString());
                                                                                                                                                                            assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                                                                                                            assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                                                                                                            assertEquals(original.getIgnoreHeaderCase(), modified.getIgnoreHeaderCase());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreakChar2() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, ','));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, ' '));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreakCharacter2() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, ','));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, ' '));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, (Character) null));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithEscape() {
                                                                                                                                                                            // Test with null escape character
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withEscape(null);
                                                                                                                                                                            assertNull(format.getEscapeCharacter());
                                                                                                                                                                    
                                                                                                                                                                            // Test with valid escape character
                                                                                                                                                                            Character escapeChar = '\\';
                                                                                                                                                                            format = CSVFormat.DEFAULT.withEscape(escapeChar);
                                                                                                                                                                            assertEquals(escapeChar, format.getEscapeCharacter());
                                                                                                                                                                    
                                                                                                                                                                            // Test that other properties remain unchanged
                                                                                                                                                                            assertEquals(CSVFormat.DEFAULT.getDelimiter(), format.getDelimiter());
                                                                                                                                                                            assertEquals(CSVFormat.DEFAULT.getQuoteCharacter(), format.getQuoteCharacter());
                                                                                                                                                                            assertEquals(CSVFormat.DEFAULT.getQuoteMode(), format.getQuoteMode());
                                                                                                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                        public void testWithEscapeLineBreak() {
                                                                                                                                                                            // Test with line break character (should throw exception)
                                                                                                                                                                            CSVFormat.DEFAULT.withEscape('\n');
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithEscapeSameAsDelimiter() throws Exception {
                                                                                                                                                                            // Use reflection to test private isLineBreak method
                                                                                                                                                                            Method isLineBreak = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                                                                            isLineBreak.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            // Test that escape same as delimiter is allowed (validation happens in constructor)
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withDelimiter('|').withEscape('|');
                                                                                                                                                                            assertEquals(Character.valueOf('|'), format.getEscapeCharacter());
                                                                                                                                                                            assertEquals('|', format.getDelimiter());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithEscapeCreatesNewInstance() {
                                                                                                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                                                            CSVFormat modified = original.withEscape('\\');
                                                                                                                                                                            assertNotSame(original, modified);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithEscape_ValidCharacter() {
                                                                                                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                                                            Character escape = '\\';
                                                                                                                                                                            CSVFormat newFormat = original.withEscape(escape);
                                                                                                                                                                            assertEquals(escape, newFormat.getEscapeCharacter());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithEscape_Null() {
                                                                                                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                                                            CSVFormat newFormat = original.withEscape(null);
                                                                                                                                                                            assertNull(newFormat.getEscapeCharacter());
                                                                                                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                        public void testWithEscape_LineBreakCR() {
                                                                                                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                                                            original.withEscape('\r');
                                                                                                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                        public void testWithEscape_LineBreakLF() {
                                                                                                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                                                            original.withEscape('\n');
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreak_Char_CR() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            boolean result = (boolean) method.invoke(null, '\r');
                                                                                                                                                                            assertTrue(result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreak_Char_LF() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            boolean result = (boolean) method.invoke(null, '\n');
                                                                                                                                                                            assertTrue(result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreak_Char_Other() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            boolean result = (boolean) method.invoke(null, 'a');
                                                                                                                                                                            assertFalse(result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreak_Character_CR() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            boolean result = (boolean) method.invoke(null, '\r');
                                                                                                                                                                            assertTrue(result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreak_Character_LF() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            boolean result = (boolean) method.invoke(null, '\n');
                                                                                                                                                                            assertTrue(result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreak_Character_Null() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            boolean result = (boolean) method.invoke(null, (Character) null);
                                                                                                                                                                            assertFalse(result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreak_Character_Other() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            boolean result = (boolean) method.invoke(null, 'a');
                                                                                                                                                                            assertFalse(result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithHeaderResultSet_NullResultSet() throws SQLException {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            CSVFormat newFormat = format.withHeader((ResultSet) null);
                                                                                                                                                                            assertNull(newFormat.getHeader());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithHeaderFromResultSet() throws SQLException {
                                                                                                                                                                            ResultSet resultSet = mock(ResultSet.class);
                                                                                                                                                                            ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                                                            when(resultSet.getMetaData()).thenReturn(metaData);
                                                                                                                                                                            when(metaData.getColumnCount()).thenReturn(2);
                                                                                                                                                                            when(metaData.getColumnLabel(1)).thenReturn("Column1");
                                                                                                                                                                            when(metaData.getColumnLabel(2)).thenReturn("Column2");
                                                                                                                                                                    
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeader(resultSet);
                                                                                                                                                                            assertArrayEquals(new String[]{"Column1", "Column2"}, format.getHeader());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithHeaderFromResultSetMetaData() throws SQLException {
                                                                                                                                                                            ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                                                            when(metaData.getColumnCount()).thenReturn(2);
                                                                                                                                                                            when(metaData.getColumnLabel(1)).thenReturn("Column1");
                                                                                                                                                                            when(metaData.getColumnLabel(2)).thenReturn("Column2");
                                                                                                                                                                    
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeader(metaData);
                                                                                                                                                                            assertArrayEquals(new String[]{"Column1", "Column2"}, format.getHeader());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToStringArrayWithNullInput1() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("toStringArray", Object[].class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            assertNull(method.invoke(CSVFormat.DEFAULT, new Object[]{null}));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToStringArrayWithNonNullInput() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("toStringArray", Object[].class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            Object[] input = {"test", 123, null};
                                                                                                                                                                            String[] result = (String[]) method.invoke(CSVFormat.DEFAULT, new Object[]{input});
                                                                                                                                                                            
                                                                                                                                                                            assertArrayEquals(new String[]{"test", "123", null}, result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreakChar3() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue((Boolean) method.invoke(null, '\n'));
                                                                                                                                                                            assertTrue((Boolean) method.invoke(null, '\r'));
                                                                                                                                                                            assertFalse((Boolean) method.invoke(null, 'a'));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreakCharacter3() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue((Boolean) method.invoke(null, '\n'));
                                                                                                                                                                            assertTrue((Boolean) method.invoke(null, '\r'));
                                                                                                                                                                            assertFalse((Boolean) method.invoke(null, 'a'));
                                                                                                                                                                            assertFalse((Boolean) method.invoke(null, null));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithAllowMissingColumnNames() {
                                                                                                                                                                            // Test default value is false
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            assertFalse(format.getAllowMissingColumnNames());
                                                                                                                                                                    
                                                                                                                                                                            // Test setting to true
                                                                                                                                                                            CSVFormat newFormat = format.withAllowMissingColumnNames();
                                                                                                                                                                            assertTrue(newFormat.getAllowMissingColumnNames());
                                                                                                                                                                            assertNotSame(format, newFormat);
                                                                                                                                                                    
                                                                                                                                                                            // Test setting to false after being true
                                                                                                                                                                            CSVFormat resetFormat = newFormat.withAllowMissingColumnNames(false);
                                                                                                                                                                            assertFalse(resetFormat.getAllowMissingColumnNames());
                                                                                                                                                                            assertNotSame(newFormat, resetFormat);
                                                                                                                                                                    
                                                                                                                                                                            // Verify other properties remain unchanged
                                                                                                                                                                            assertEquals(format.getDelimiter(), newFormat.getDelimiter());
                                                                                                                                                                            assertEquals(format.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                                                                            assertEquals(format.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithAllowMissingColumnNamesWithHeader() throws SQLException {
                                                                                                                                                                            // Setup mock ResultSet and MetaData
                                                                                                                                                                            ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                                                            when(metaData.getColumnCount()).thenReturn(2);
                                                                                                                                                                            when(metaData.getColumnLabel(1)).thenReturn("Column1");
                                                                                                                                                                            when(metaData.getColumnLabel(2)).thenReturn("Column2");
                                                                                                                                                                    
                                                                                                                                                                            ResultSet resultSet = mock(ResultSet.class);
                                                                                                                                                                            when(resultSet.getMetaData()).thenReturn(metaData);
                                                                                                                                                                    
                                                                                                                                                                            // Test with header from ResultSet
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeader(resultSet).withAllowMissingColumnNames();
                                                                                                                                                                            assertTrue(format.getAllowMissingColumnNames());
                                                                                                                                                                            assertArrayEquals(new String[]{"Column1", "Column2"}, format.getHeader());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithAllowMissingColumnNamesEqualsAndHashCode() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withAllowMissingColumnNames();
                                                                                                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withAllowMissingColumnNames();
                                                                                                                                                                            CSVFormat format3 = CSVFormat.DEFAULT.withAllowMissingColumnNames(false);
                                                                                                                                                                    
                                                                                                                                                                            assertEquals(format1, format2);
                                                                                                                                                                            assertEquals(format1.hashCode(), format2.hashCode());
                                                                                                                                                                            assertNotEquals(format1, format3);
                                                                                                                                                                            assertNotEquals(format1.hashCode(), format3.hashCode());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithAllowMissingColumnNamesToString() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withAllowMissingColumnNames();
                                                                                                                                                                            assertTrue(format.toString().contains("Delimiter=<,>"));
                                                                                                                                                                            assertTrue(format.toString().contains("QuoteChar=<\">"));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPrivateIsLineBreakMethod() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithIgnoreEmptyLinesTrue() {
                                                                                                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                                                            CSVFormat modified = original.withIgnoreEmptyLines(true);
                                                                                                                                                                            assertTrue(modified.getIgnoreEmptyLines());
                                                                                                                                                                            assertNotSame(original, modified);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithIgnoreEmptyLinesFalse() {
                                                                                                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                                                            CSVFormat modified = original.withIgnoreEmptyLines(false);
                                                                                                                                                                            assertFalse(modified.getIgnoreEmptyLines());
                                                                                                                                                                            assertNotSame(original, modified);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithIgnoreEmptyLinesNoArg() {
                                                                                                                                                                            CSVFormat original = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);
                                                                                                                                                                            CSVFormat modified = original.withIgnoreEmptyLines();
                                                                                                                                                                            assertTrue(modified.getIgnoreEmptyLines());
                                                                                                                                                                            assertNotSame(original, modified);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithIgnoreEmptyLinesMaintainsOtherProperties() {
                                                                                                                                                                            CSVFormat original = CSVFormat.DEFAULT
                                                                                                                                                                                .withDelimiter(';')
                                                                                                                                                                                .withQuote('"')
                                                                                                                                                                                .withCommentMarker('#')
                                                                                                                                                                                .withEscape('\\')
                                                                                                                                                                                .withNullString("NULL")
                                                                                                                                                                                .withHeader("Col1", "Col2");
                                                                                                                                                                            
                                                                                                                                                                            CSVFormat modified = original.withIgnoreEmptyLines(true);
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(';', modified.getDelimiter());
                                                                                                                                                                            assertEquals(Character.valueOf('"'), modified.getQuoteCharacter());
                                                                                                                                                                            assertEquals(Character.valueOf('#'), modified.getCommentMarker());
                                                                                                                                                                            assertEquals(Character.valueOf('\\'), modified.getEscapeCharacter());
                                                                                                                                                                            assertEquals("NULL", modified.getNullString());
                                                                                                                                                                            assertArrayEquals(new String[]{"Col1", "Col2"}, modified.getHeader());
                                                                                                                                                                            assertTrue(modified.getIgnoreEmptyLines());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithIgnoreEmptyLinesReturnsNewInstance() {
                                                                                                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                                                            CSVFormat modified = original.withIgnoreEmptyLines(true);
                                                                                                                                                                            assertNotSame(original, modified);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithIgnoreEmptyLinesOriginalUnchanged() {
                                                                                                                                                                            CSVFormat original = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);
                                                                                                                                                                            CSVFormat modified = original.withIgnoreEmptyLines(true);
                                                                                                                                                                            assertFalse(original.getIgnoreEmptyLines());
                                                                                                                                                                            assertTrue(modified.getIgnoreEmptyLines());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithHeaderResultSet() throws SQLException {
                                                                                                                                                                            ResultSet resultSet = mock(ResultSet.class);
                                                                                                                                                                            ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                                                            when(resultSet.getMetaData()).thenReturn(metaData);
                                                                                                                                                                            when(metaData.getColumnCount()).thenReturn(2);
                                                                                                                                                                            when(metaData.getColumnLabel(1)).thenReturn("Column1");
                                                                                                                                                                            when(metaData.getColumnLabel(2)).thenReturn("Column2");
                                                                                                                                                                    
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeader(resultSet);
                                                                                                                                                                            assertArrayEquals(new String[]{"Column1", "Column2"}, format.getHeader());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithHeaderResultSetMetaData() throws SQLException {
                                                                                                                                                                            ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                                                            when(metaData.getColumnCount()).thenReturn(3);
                                                                                                                                                                            when(metaData.getColumnLabel(1)).thenReturn("Col1");
                                                                                                                                                                            when(metaData.getColumnLabel(2)).thenReturn("Col2");
                                                                                                                                                                            when(metaData.getColumnLabel(3)).thenReturn("Col3");
                                                                                                                                                                    
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeader(metaData);
                                                                                                                                                                            assertArrayEquals(new String[]{"Col1", "Col2", "Col3"}, format.getHeader());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPrivateIsLineBreakCharMethod() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPrivateIsLineBreakCharacterMethod() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, (Character) null));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPrivateToStringArrayMethod() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("toStringArray", Object[].class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            Object[] input = {"test", 123, null};
                                                                                                                                                                            String[] result = (String[]) method.invoke(CSVFormat.DEFAULT, new Object[]{input});
                                                                                                                                                                            
                                                                                                                                                                            assertArrayEquals(new String[]{"test", "123", null}, result);
                                                                                                                                                                            assertNull(method.invoke(CSVFormat.DEFAULT, new Object[]{null}));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithIgnoreSurroundingSpaces() {
                                                                                                                                                                            // Create a default CSVFormat
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            
                                                                                                                                                                            // Verify initial state is false
                                                                                                                                                                            assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                                                                                                            
                                                                                                                                                                            // Call the method
                                                                                                                                                                            CSVFormat newFormat = format.withIgnoreSurroundingSpaces();
                                                                                                                                                                            
                                                                                                                                                                            // Verify it's a new instance
                                                                                                                                                                            assertNotSame(format, newFormat);
                                                                                                                                                                            
                                                                                                                                                                            // Verify the new format has ignoreSurroundingSpaces set to true
                                                                                                                                                                            assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                                                                                                            
                                                                                                                                                                            // Verify other properties remain unchanged
                                                                                                                                                                            assertEquals(format.getDelimiter(), newFormat.getDelimiter());
                                                                                                                                                                            assertEquals(format.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                                                                            assertEquals(format.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                                                                                            assertEquals(format.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                                                                                            assertEquals(format.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                                                                                            assertEquals(format.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                                                                                            assertEquals(format.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                                                                                            assertEquals(format.getNullString(), newFormat.getNullString());
                                                                                                                                                                            assertArrayEquals(format.getHeaderComments(), newFormat.getHeaderComments());
                                                                                                                                                                            assertArrayEquals(format.getHeader(), newFormat.getHeader());
                                                                                                                                                                            assertEquals(format.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                                                                                            assertEquals(format.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                                                                                                            assertEquals(format.getIgnoreHeaderCase(), newFormat.getIgnoreHeaderCase());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithIgnoreSurroundingSpacesParameterized() {
                                                                                                                                                                            // Test with true
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true);
                                                                                                                                                                            assertTrue(format.getIgnoreSurroundingSpaces());
                                                                                                                                                                            
                                                                                                                                                                            // Test with false
                                                                                                                                                                            format = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(false);
                                                                                                                                                                            assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithIgnoreSurroundingSpacesChaining() {
                                                                                                                                                                            // Test method chaining
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                                                                .withIgnoreSurroundingSpaces()
                                                                                                                                                                                .withDelimiter(';')
                                                                                                                                                                                .withQuote('"');
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(format.getIgnoreSurroundingSpaces());
                                                                                                                                                                            assertEquals(';', format.getDelimiter());
                                                                                                                                                                            assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToStringArrayMethod() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("toStringArray", Object[].class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            Object[] input = {"test", 123, null};
                                                                                                                                                                            String[] result = (String[]) method.invoke(CSVFormat.DEFAULT, new Object[]{input});
                                                                                                                                                                            
                                                                                                                                                                            assertArrayEquals(new String[]{"test", "123", null}, result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreakMethod() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue((Boolean) method.invoke(null, '\n'));
                                                                                                                                                                            assertTrue((Boolean) method.invoke(null, '\r'));
                                                                                                                                                                            assertFalse((Boolean) method.invoke(null, 'a'));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testValidateMethod() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("validate");
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            // Should not throw exception for valid format
                                                                                                                                                                            method.invoke(CSVFormat.DEFAULT);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithIgnoreHeaderCase() {
                                                                                                                                                                            // Create a default CSVFormat instance
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            
                                                                                                                                                                            // Verify initial state is false
                                                                                                                                                                            assertFalse(format.getIgnoreHeaderCase());
                                                                                                                                                                            
                                                                                                                                                                            // Call the method
                                                                                                                                                                            CSVFormat newFormat = format.withIgnoreHeaderCase();
                                                                                                                                                                            
                                                                                                                                                                            // Verify new format has ignoreHeaderCase set to true
                                                                                                                                                                            assertTrue(newFormat.getIgnoreHeaderCase());
                                                                                                                                                                            
                                                                                                                                                                            // Verify other properties remain unchanged
                                                                                                                                                                            assertEquals(format.getDelimiter(), newFormat.getDelimiter());
                                                                                                                                                                            assertEquals(format.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                                                                            assertEquals(format.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                                                                                            assertEquals(format.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                                                                                            assertEquals(format.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                                                                                            assertEquals(format.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                                                                                            assertEquals(format.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                                                                                            assertEquals(format.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                                                                                            assertEquals(format.getNullString(), newFormat.getNullString());
                                                                                                                                                                            assertArrayEquals(format.getHeaderComments(), newFormat.getHeaderComments());
                                                                                                                                                                            assertArrayEquals(format.getHeader(), newFormat.getHeader());
                                                                                                                                                                            assertEquals(format.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                                                                                            assertEquals(format.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithIgnoreHeaderCaseBoolean() {
                                                                                                                                                                            // Create a default CSVFormat instance
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            
                                                                                                                                                                            // Test setting to true
                                                                                                                                                                            CSVFormat trueFormat = format.withIgnoreHeaderCase(true);
                                                                                                                                                                            assertTrue(trueFormat.getIgnoreHeaderCase());
                                                                                                                                                                            
                                                                                                                                                                            // Test setting to false
                                                                                                                                                                            CSVFormat falseFormat = format.withIgnoreHeaderCase(false);
                                                                                                                                                                            assertFalse(falseFormat.getIgnoreHeaderCase());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithIgnoreHeaderCaseReturnsNewInstance() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            CSVFormat newFormat = format.withIgnoreHeaderCase();
                                                                                                                                                                            
                                                                                                                                                                            // Verify it returns a new instance rather than modifying the existing one
                                                                                                                                                                            assertNotSame(format, newFormat);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToStringArrayWithNullInput2() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("toStringArray", Object[].class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            assertNull(method.invoke(null, new Object[]{null}));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToStringArrayWithNonNullInput1() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("toStringArray", Object[].class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            Object[] input = {"test", 123, null};
                                                                                                                                                                            String[] result = (String[]) method.invoke(null, new Object[]{input});
                                                                                                                                                                            
                                                                                                                                                                            assertArrayEquals(new String[]{"test", "123", null}, result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithHeaderFromResultSet1() throws SQLException {
                                                                                                                                                                            ResultSet resultSet = mock(ResultSet.class);
                                                                                                                                                                            ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                                                            when(resultSet.getMetaData()).thenReturn(metaData);
                                                                                                                                                                            when(metaData.getColumnCount()).thenReturn(2);
                                                                                                                                                                            when(metaData.getColumnLabel(1)).thenReturn("Col1");
                                                                                                                                                                            when(metaData.getColumnLabel(2)).thenReturn("Col2");
                                                                                                                                                                    
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeader(resultSet);
                                                                                                                                                                            assertArrayEquals(new String[]{"Col1", "Col2"}, format.getHeader());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithHeaderFromResultSetMetaData1() throws SQLException {
                                                                                                                                                                            ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                                                            when(metaData.getColumnCount()).thenReturn(2);
                                                                                                                                                                            when(metaData.getColumnLabel(1)).thenReturn("Col1");
                                                                                                                                                                            when(metaData.getColumnLabel(2)).thenReturn("Col2");
                                                                                                                                                                    
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeader(metaData);
                                                                                                                                                                            assertArrayEquals(new String[]{"Col1", "Col2"}, format.getHeader());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithHeaderFromResultSet2() throws SQLException {
                                                                                                                                                                            ResultSet resultSet = mock(ResultSet.class);
                                                                                                                                                                            ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                                                            when(resultSet.getMetaData()).thenReturn(metaData);
                                                                                                                                                                            when(metaData.getColumnCount()).thenReturn(2);
                                                                                                                                                                            when(metaData.getColumnLabel(1)).thenReturn("Column1");
                                                                                                                                                                            when(metaData.getColumnLabel(2)).thenReturn("Column2");
                                                                                                                                                                    
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeader(resultSet);
                                                                                                                                                                            assertArrayEquals(new String[]{"Column1", "Column2"}, format.getHeader());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithHeaderFromResultSetMetaData2() throws SQLException {
                                                                                                                                                                            ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                                                            when(metaData.getColumnCount()).thenReturn(3);
                                                                                                                                                                            when(metaData.getColumnLabel(1)).thenReturn("Col1");
                                                                                                                                                                            when(metaData.getColumnLabel(2)).thenReturn("Col2");
                                                                                                                                                                            when(metaData.getColumnLabel(3)).thenReturn("Col3");
                                                                                                                                                                    
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeader(metaData);
                                                                                                                                                                            assertArrayEquals(new String[]{"Col1", "Col2", "Col3"}, format.getHeader());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToStringArray() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("toStringArray", Object[].class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            Object[] input = {"test", 123, null};
                                                                                                                                                                            String[] result = (String[]) method.invoke(CSVFormat.DEFAULT, new Object[]{input});
                                                                                                                                                                            
                                                                                                                                                                            assertArrayEquals(new String[]{"test", "123", null}, result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreakChar4() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreakCharacter4() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, (Character) null));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithQuoteChar() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            char quoteChar = '\'';
                                                                                                                                                                            
                                                                                                                                                                            CSVFormat newFormat = format.withQuote(quoteChar);
                                                                                                                                                                            
                                                                                                                                                                            assertNotNull(newFormat);
                                                                                                                                                                            assertEquals(Character.valueOf(quoteChar), newFormat.getQuoteCharacter());
                                                                                                                                                                            assertNotSame(format, newFormat);
                                                                                                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                        public void testWithQuoteCharLineBreak() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            format.withQuote('\n');
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithQuoteNull() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withQuote('"');
                                                                                                                                                                            CSVFormat newFormat = format.withQuote(null);
                                                                                                                                                                            
                                                                                                                                                                            assertNotNull(newFormat);
                                                                                                                                                                            assertNull(newFormat.getQuoteCharacter());
                                                                                                                                                                            assertNotSame(format, newFormat);
                                                                                                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                        public void testWithQuoteNullLineBreak() throws Exception {
                                                                                                                                                                            // Use reflection to test private isLineBreak method
                                                                                                                                                                            Method isLineBreak = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                                                                            isLineBreak.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            boolean result = (boolean) isLineBreak.invoke(null, '\n');
                                                                                                                                                                            assertTrue(result);
                                                                                                                                                                            
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                            format.withQuote('\n');
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithQuoteSameAsOriginal() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withQuote('"');
                                                                                                                                                                            CSVFormat newFormat = format.withQuote('"');
                                                                                                                                                                            
                                                                                                                                                                            assertNotNull(newFormat);
                                                                                                                                                                            assertEquals(format.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                                                                            assertNotSame(format, newFormat);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithQuoteOtherPropertiesPreserved() {
                                                                                                                                                                            CSVFormat original = CSVFormat.DEFAULT
                                                                                                                                                                                .withDelimiter(';')
                                                                                                                                                                                .withEscape('\\')
                                                                                                                                                                                .withCommentMarker('#')
                                                                                                                                                                                .withIgnoreSurroundingSpaces(true)
                                                                                                                                                                                .withIgnoreEmptyLines(false);
                                                                                                                                                                            
                                                                                                                                                                            CSVFormat modified = original.withQuote('\'');
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                                                                                                            assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                                                                                                            assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                                                                                                            assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                                                                                                            assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                                                                                                            assertEquals(Character.valueOf('\''), modified.getQuoteCharacter());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithQuoteWithValidCharacter() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withQuote('"');
                                                                                                                                                                            assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithQuoteWithNull() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withQuote(null);
                                                                                                                                                                            assertNull(format.getQuoteCharacter());
                                                                                                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                        public void testWithQuoteWithLineFeed() {
                                                                                                                                                                            CSVFormat.DEFAULT.withQuote('\n');
                                                                                                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                        public void testWithQuoteWithCarriageReturn() {
                                                                                                                                                                            CSVFormat.DEFAULT.withQuote('\r');
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithQuotePreservesOtherSettings() {
                                                                                                                                                                            CSVFormat original = CSVFormat.DEFAULT
                                                                                                                                                                                .withDelimiter(';')
                                                                                                                                                                                .withQuoteMode(QuoteMode.ALL)
                                                                                                                                                                                .withCommentMarker('#')
                                                                                                                                                                                .withEscape('\\')
                                                                                                                                                                                .withIgnoreSurroundingSpaces(true)
                                                                                                                                                                                .withIgnoreEmptyLines(true)
                                                                                                                                                                                .withRecordSeparator("\n")
                                                                                                                                                                                .withNullString("NULL")
                                                                                                                                                                                .withHeader("col1", "col2")
                                                                                                                                                                                .withSkipHeaderRecord(true)
                                                                                                                                                                                .withAllowMissingColumnNames(true)
                                                                                                                                                                                .withIgnoreHeaderCase(true);
                                                                                                                                                                    
                                                                                                                                                                            CSVFormat modified = original.withQuote('"');
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(';', modified.getDelimiter());
                                                                                                                                                                            assertEquals(QuoteMode.ALL, modified.getQuoteMode());
                                                                                                                                                                            assertEquals(Character.valueOf('#'), modified.getCommentMarker());
                                                                                                                                                                            assertEquals(Character.valueOf('\\'), modified.getEscapeCharacter());
                                                                                                                                                                            assertTrue(modified.getIgnoreSurroundingSpaces());
                                                                                                                                                                            assertTrue(modified.getIgnoreEmptyLines());
                                                                                                                                                                            assertEquals("\n", modified.getRecordSeparator());
                                                                                                                                                                            assertEquals("NULL", modified.getNullString());
                                                                                                                                                                            assertArrayEquals(new String[]{"col1", "col2"}, modified.getHeader());
                                                                                                                                                                            assertTrue(modified.getSkipHeaderRecord());
                                                                                                                                                                            assertTrue(modified.getAllowMissingColumnNames());
                                                                                                                                                                            assertTrue(modified.getIgnoreHeaderCase());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreakChar5() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, '"'));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreakCharacter5() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, Character.valueOf('\n')));
                                                                                                                                                                            assertTrue((boolean) method.invoke(null, Character.valueOf('\r')));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, Character.valueOf('a')));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, Character.valueOf('"')));
                                                                                                                                                                            assertFalse((boolean) method.invoke(null, (Character) null));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPrivateToStringArray() throws NoSuchMethodException, IllegalAccessException, 
                                                                                                                                                                                InvocationTargetException {
                                                                                                                                                                            Object[] input = {"test1", "test2", null};
                                                                                                                                                                            String[] expected = {"test1", "test2", null};
                                                                                                                                                                            
                                                                                                                                                                            Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                                                                                                                    char.class, Character.class, QuoteMode.class, Character.class, Character.class, 
                                                                                                                                                                                    boolean.class, boolean.class, String.class, String.class, Object[].class, 
                                                                                                                                                                                    String[].class, boolean.class, boolean.class, boolean.class);
                                                                                                                                                                            constructor.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            CSVFormat format = constructor.newInstance(
                                                                                                                                                                                    ',', null, null, null, null, false, false, null, null, input, null, false, false, false);
                                                                                                                                                                            
                                                                                                                                                                            assertArrayEquals(expected, format.getHeaderComments());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithRecordSeparator() {
                                                                                                                                                                            // Test with CR
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withRecordSeparator("\r");
                                                                                                                                                                            assertEquals("\r", format1.getRecordSeparator());
                                                                                                                                                                    
                                                                                                                                                                            // Test with LF
                                                                                                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withRecordSeparator("\n");
                                                                                                                                                                            assertEquals("\n", format2.getRecordSeparator());
                                                                                                                                                                    
                                                                                                                                                                            // Test with CRLF
                                                                                                                                                                            CSVFormat format3 = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
                                                                                                                                                                            assertEquals("\r\n", format3.getRecordSeparator());
                                                                                                                                                                    
                                                                                                                                                                            // Test with empty string
                                                                                                                                                                            CSVFormat format4 = CSVFormat.DEFAULT.withRecordSeparator("");
                                                                                                                                                                            assertEquals("", format4.getRecordSeparator());
                                                                                                                                                                    
                                                                                                                                                                            // Test with custom string
                                                                                                                                                                            CSVFormat format5 = CSVFormat.DEFAULT.withRecordSeparator("custom");
                                                                                                                                                                            assertEquals("custom", format5.getRecordSeparator());
                                                                                                                                                                    
                                                                                                                                                                            // Test that other properties remain unchanged
                                                                                                                                                                            assertEquals(CSVFormat.DEFAULT.getDelimiter(), format5.getDelimiter());
                                                                                                                                                                            assertEquals(CSVFormat.DEFAULT.getQuoteCharacter(), format5.getQuoteCharacter());
                                                                                                                                                                            assertEquals(CSVFormat.DEFAULT.getQuoteMode(), format5.getQuoteMode());
                                                                                                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                        public void testWithRecordSeparatorNull() {
                                                                                                                                                                            CSVFormat.DEFAULT.withRecordSeparator(null);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithRecordSeparatorChar() throws Exception {
                                                                                                                                                                            // Use reflection to test private method
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("withRecordSeparator", char.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            CSVFormat result = (CSVFormat) method.invoke(CSVFormat.DEFAULT, '\n');
                                                                                                                                                                            assertEquals("\n", result.getRecordSeparator());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testEqualsAndHashCode() {
                                                                                                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
                                                                                                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
                                                                                                                                                                            CSVFormat format3 = CSVFormat.DEFAULT.withRecordSeparator("\n");
                                                                                                                                                                    
                                                                                                                                                                            assertEquals(format1, format2);
                                                                                                                                                                            assertEquals(format1.hashCode(), format2.hashCode());
                                                                                                                                                                            assertNotEquals(format1, format3);
                                                                                                                                                                            assertNotEquals(format1.hashCode(), format3.hashCode());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToString() {
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("|");
                                                                                                                                                                            assertTrue(format.toString().contains("RecordSeparator=<|>"));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToStringArrayMethod1() throws Exception {
                                                                                                                                                                            Method toStringArray = CSVFormat.class.getDeclaredMethod("toStringArray", Object[].class);
                                                                                                                                                                            toStringArray.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            Object[] input = {"test", 123, null};
                                                                                                                                                                            String[] result = (String[]) toStringArray.invoke(null, (Object) input);
                                                                                                                                                                            
                                                                                                                                                                            assertArrayEquals(new String[]{"test", "123", null}, result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreakMethod1() throws Exception {
                                                                                                                                                                            Method isLineBreakChar = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                                                            isLineBreakChar.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue((Boolean) isLineBreakChar.invoke(null, '\n'));
                                                                                                                                                                            assertTrue((Boolean) isLineBreakChar.invoke(null, '\r'));
                                                                                                                                                                            assertFalse((Boolean) isLineBreakChar.invoke(null, 'a'));
                                                                                                                                                                    
                                                                                                                                                                            Method isLineBreakCharacter = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                                                                            isLineBreakCharacter.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue((Boolean) isLineBreakCharacter.invoke(null, '\n'));
                                                                                                                                                                            assertTrue((Boolean) isLineBreakCharacter.invoke(null, '\r'));
                                                                                                                                                                            assertFalse((Boolean) isLineBreakCharacter.invoke(null, 'a'));
                                                                                                                                                                            assertFalse((Boolean) isLineBreakCharacter.invoke(null, (Character) null));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithSkipHeaderRecordTrue() {
                                                                                                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                                                            CSVFormat modified = original.withSkipHeaderRecord(true);
                                                                                                                                                                            
                                                                                                                                                                            assertNotSame(original, modified);
                                                                                                                                                                            assertTrue(modified.getSkipHeaderRecord());
                                                                                                                                                                            assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                                                                                                            assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                                                                                                            assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                                                                                                            assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                                                                                                            assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                                                                                                            assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                                                                                                            assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                                                                                                            assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                                                                                                            assertEquals(original.getNullString(), modified.getNullString());
                                                                                                                                                                            assertArrayEquals(original.getHeaderComments(), modified.getHeaderComments());
                                                                                                                                                                            assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                                                                                                            assertEquals(original.getAllowMissingColumnNames(), modified.getAllowMissingColumnNames());
                                                                                                                                                                            assertEquals(original.getIgnoreHeaderCase(), modified.getIgnoreHeaderCase());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithSkipHeaderRecordFalse() {
                                                                                                                                                                            CSVFormat original = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                                                                                                            CSVFormat modified = original.withSkipHeaderRecord(false);
                                                                                                                                                                            
                                                                                                                                                                            assertNotSame(original, modified);
                                                                                                                                                                            assertFalse(modified.getSkipHeaderRecord());
                                                                                                                                                                            assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                                                                                                            assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                                                                                                            assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                                                                                                            assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                                                                                                            assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                                                                                                            assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                                                                                                            assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                                                                                                            assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                                                                                                            assertEquals(original.getNullString(), modified.getNullString());
                                                                                                                                                                            assertArrayEquals(original.getHeaderComments(), modified.getHeaderComments());
                                                                                                                                                                            assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                                                                                                            assertEquals(original.getAllowMissingColumnNames(), modified.getAllowMissingColumnNames());
                                                                                                                                                                            assertEquals(original.getIgnoreHeaderCase(), modified.getIgnoreHeaderCase());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithSkipHeaderRecordNoArg() {
                                                                                                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                                                            CSVFormat modified = original.withSkipHeaderRecord();
                                                                                                                                                                            
                                                                                                                                                                            assertNotSame(original, modified);
                                                                                                                                                                            assertTrue(modified.getSkipHeaderRecord());
                                                                                                                                                                            assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                                                                                                            assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                                                                                                            assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                                                                                                            assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                                                                                                            assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                                                                                                            assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                                                                                                            assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                                                                                                            assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                                                                                                            assertEquals(original.getNullString(), modified.getNullString());
                                                                                                                                                                            assertArrayEquals(original.getHeaderComments(), modified.getHeaderComments());
                                                                                                                                                                            assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                                                                                                            assertEquals(original.getAllowMissingColumnNames(), modified.getAllowMissingColumnNames());
                                                                                                                                                                            assertEquals(original.getIgnoreHeaderCase(), modified.getIgnoreHeaderCase());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithSkipHeaderRecordImmutable() {
                                                                                                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                                                            CSVFormat modified1 = original.withSkipHeaderRecord(true);
                                                                                                                                                                            CSVFormat modified2 = modified1.withSkipHeaderRecord(false);
                                                                                                                                                                            
                                                                                                                                                                            assertNotSame(original, modified1);
                                                                                                                                                                            assertNotSame(modified1, modified2);
                                                                                                                                                                            assertTrue(modified1.getSkipHeaderRecord());
                                                                                                                                                                            assertFalse(modified2.getSkipHeaderRecord());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithHeaderFromResultSet3() throws SQLException {
                                                                                                                                                                            ResultSet resultSet = mock(ResultSet.class);
                                                                                                                                                                            ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                                                            when(resultSet.getMetaData()).thenReturn(metaData);
                                                                                                                                                                            when(metaData.getColumnCount()).thenReturn(2);
                                                                                                                                                                            when(metaData.getColumnLabel(1)).thenReturn("Column1");
                                                                                                                                                                            when(metaData.getColumnLabel(2)).thenReturn("Column2");
                                                                                                                                                                    
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeader(resultSet);
                                                                                                                                                                            assertArrayEquals(new String[]{"Column1", "Column2"}, format.getHeader());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testWithHeaderFromResultSetMetaData3() throws SQLException {
                                                                                                                                                                            ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                                                            when(metaData.getColumnCount()).thenReturn(2);
                                                                                                                                                                            when(metaData.getColumnLabel(1)).thenReturn("Column1");
                                                                                                                                                                            when(metaData.getColumnLabel(2)).thenReturn("Column2");
                                                                                                                                                                    
                                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeader(metaData);
                                                                                                                                                                            assertArrayEquals(new String[]{"Column1", "Column2"}, format.getHeader());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testToStringArray1() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("toStringArray", Object[].class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            Object[] input = {"test", 123, null};
                                                                                                                                                                            String[] result = (String[]) method.invoke(CSVFormat.DEFAULT, new Object[]{input});
                                                                                                                                                                            
                                                                                                                                                                            assertArrayEquals(new String[]{"test", "123", null}, result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreakChar6() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue((Boolean) method.invoke(null, '\n'));
                                                                                                                                                                            assertTrue((Boolean) method.invoke(null, '\r'));
                                                                                                                                                                            assertFalse((Boolean) method.invoke(null, 'a'));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testIsLineBreakCharacter6() throws Exception {
                                                                                                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue((Boolean) method.invoke(null, '\n'));
                                                                                                                                                                            assertTrue((Boolean) method.invoke(null, '\r'));
                                                                                                                                                                            assertFalse((Boolean) method.invoke(null, 'a'));
                                                                                                                                                                            assertFalse((Boolean) method.invoke(null, (Character) null));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                    public void testIsLineBreakWithLF1() throws Exception {
                                                                                                                                                                        final char LF = '\n';
                                                                                                                                                                        final char CR = '\r';
                                                                                                                                                                        
                                                                                                                                                                        Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                                                        isLineBreakMethod.setAccessible(true);
                                                                                                                                                                        
                                                                                                                                                                        boolean result = (boolean) isLineBreakMethod.invoke(null, LF);
                                                                                                                                                                        assertTrue(result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testIsLineBreakWithCR1() throws Exception {
                                                                                                                                                                        final char CR = '\r';
                                                                                                                                                                        final char LF = '\n';
                                                                                                                                                                        
                                                                                                                                                                        Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                                                        isLineBreakMethod.setAccessible(true);
                                                                                                                                                                        
                                                                                                                                                                        boolean result = (boolean) isLineBreakMethod.invoke(null, CR);
                                                                                                                                                                        assertTrue(result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testIsLineBreakWithNonLineBreakChar() throws Exception {
                                                                                                                                                                        Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                                                        isLineBreakMethod.setAccessible(true);
                                                                                                                                                                        
                                                                                                                                                                        boolean result = (boolean) isLineBreakMethod.invoke(null, 'A');
                                                                                                                                                                        assertFalse(result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testIsLineBreakWithSpace() throws Exception {
                                                                                                                                                                        Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                                                        isLineBreakMethod.setAccessible(true);
                                                                                                                                                                        boolean result = (boolean) isLineBreakMethod.invoke(null, ' ');
                                                                                                                                                                        assertFalse(result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testIsLineBreakWithTab1() throws Exception {
                                                                                                                                                                        Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                                                        isLineBreakMethod.setAccessible(true);
                                                                                                                                                                        boolean result = (boolean) isLineBreakMethod.invoke(null, '\t');
                                                                                                                                                                        assertFalse(result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testIsLineBreakWithZero() throws Exception {
                                                                                                                                                                        Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                                                        isLineBreakMethod.setAccessible(true);
                                                                                                                                                                        boolean result = (boolean) isLineBreakMethod.invoke(null, '\0');
                                                                                                                                                                        assertFalse(result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testNewFormatWithLineBreakDelimiterCR() {
                                                                                                                                                                        char CR = '\r';
                                                                                                                                                                        CSVFormat.newFormat(CR);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testNewFormatWithLineBreakDelimiterLF() {
                                                                                                                                                                        char LF = '\n';
                                                                                                                                                                        CSVFormat.newFormat(LF);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testPrivateIsLineBreakCharMethod1() throws Exception {
                                                                                                                                                                        Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                                        
                                                                                                                                                                        assertTrue((boolean) method.invoke(null, '\r'));  // Replaced Constants.CR with '\r'
                                                                                                                                                                        assertTrue((boolean) method.invoke(null, '\n'));  // Replaced Constants.LF with '\n'
                                                                                                                                                                        assertFalse((boolean) method.invoke(null, ','));
                                                                                                                                                                        assertFalse((boolean) method.invoke(null, ';'));
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testPrivateIsLineBreakCharacterMethod1() throws Exception {
                                                                                                                                                                        Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                                        
                                                                                                                                                                        assertTrue((boolean) method.invoke(null, '\r'));  // Replaced Constants.CR with '\r'
                                                                                                                                                                        assertTrue((boolean) method.invoke(null, '\n'));  // Replaced Constants.LF with '\n'
                                                                                                                                                                        assertFalse((boolean) method.invoke(null, ','));
                                                                                                                                                                        assertFalse((boolean) method.invoke(null, ';'));
                                                                                                                                                                        assertFalse((boolean) method.invoke(null, (Character) null));
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetCommentMarkerAfterConstruction() throws Exception {
                                                                                                                                                                        Character expectedComment = '!';
                                                                                                                                                                        Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                                                                                                            char.class, Character.class, QuoteMode.class, Character.class, Character.class,
                                                                                                                                                                            boolean.class, boolean.class, String.class, String.class, Object[].class,
                                                                                                                                                                            String[].class, boolean.class, boolean.class, boolean.class);
                                                                                                                                                                        constructor.setAccessible(true);
                                                                                                                                                                        CSVFormat format = constructor.newInstance(
                                                                                                                                                                            ',', null, null, expectedComment, null,
                                                                                                                                                                            false, false, null, null, null,
                                                                                                                                                                            null, false, false, false);
                                                                                                                                                                        assertEquals(expectedComment, format.getCommentMarker());
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetHeaderCommentsWhenNotNull() {
                                                                                                                                                                        String[] comments = {"Comment1", "Comment2"};
                                                                                                                                                                        CSVFormat format = CSVFormat.DEFAULT.withHeaderComments(comments);
                                                                                                                                                                        String[] result = format.getHeaderComments();
                                                                                                                                                                        assertNotNull(result);
                                                                                                                                                                        assertArrayEquals(comments, result);
                                                                                                                                                                        assertNotSame(comments, result); // Verify it's a clone
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetHeaderCommentsReturnsClone() {
                                                                                                                                                                        String[] comments = {"Comment1", "Comment2"};
                                                                                                                                                                        CSVFormat format = CSVFormat.DEFAULT.withHeaderComments(comments);
                                                                                                                                                                        String[] result1 = format.getHeaderComments();
                                                                                                                                                                        String[] result2 = format.getHeaderComments();
                                                                                                                                                                        assertNotSame(result1, result2); // Verify each call returns new clone
                                                                                                                                                                        assertArrayEquals(result1, result2);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetHeaderCommentsWithNullElement() {
                                                                                                                                                                        String[] comments = {"Comment1", null, "Comment3"};
                                                                                                                                                                        CSVFormat format = CSVFormat.DEFAULT.withHeaderComments(comments);
                                                                                                                                                                        String[] result = format.getHeaderComments();
                                                                                                                                                                        assertNotNull(result);
                                                                                                                                                                        assertArrayEquals(comments, result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetAllowMissingColumnNamesWhenFalse() {
                                                                                                                                                                        CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                                                                                                        assertFalse(csvFormat.getAllowMissingColumnNames());
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetAllowMissingColumnNamesWhenTrue() throws Exception {
                                                                                                                                                                        CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to modify the private field for testing
                                                                                                                                                                        Field field = CSVFormat.class.getDeclaredField("allowMissingColumnNames");
                                                                                                                                                                        field.setAccessible(true);
                                                                                                                                                                        field.set(csvFormat, true);
                                                                                                                                                                        
                                                                                                                                                                        assertTrue(csvFormat.getAllowMissingColumnNames());
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetAllowMissingColumnNamesAfterWithAllowMissingColumnNames() {
                                                                                                                                                                        CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                                                                                                        CSVFormat newFormat = csvFormat.withAllowMissingColumnNames(true);
                                                                                                                                                                        assertTrue(newFormat.getAllowMissingColumnNames());
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetAllowMissingColumnNamesAfterWithAllowMissingColumnNamesFalse() {
                                                                                                                                                                        CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                                                                                                        CSVFormat newFormat = csvFormat.withAllowMissingColumnNames(false);
                                                                                                                                                                        assertFalse(newFormat.getAllowMissingColumnNames());
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetAllowMissingColumnNamesAfterWithAllowMissingColumnNamesDefault() {
                                                                                                                                                                        CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                                                                                                        CSVFormat newFormat = csvFormat.withAllowMissingColumnNames();
                                                                                                                                                                        assertTrue(newFormat.getAllowMissingColumnNames());
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetRecordSeparator() throws Exception {
                                                                                                                                                                        // Test with default record separator
                                                                                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                        assertEquals("\r\n", format.getRecordSeparator());
                                                                                                                                                                    
                                                                                                                                                                        // Test with custom record separator
                                                                                                                                                                        String customSeparator = "|";
                                                                                                                                                                        format = format.withRecordSeparator(customSeparator);
                                                                                                                                                                        assertEquals(customSeparator, format.getRecordSeparator());
                                                                                                                                                                    
                                                                                                                                                                        // Test with null record separator
                                                                                                                                                                        format = CSVFormat.DEFAULT.withRecordSeparator(null);
                                                                                                                                                                        assertNull(format.getRecordSeparator());
                                                                                                                                                                    
                                                                                                                                                                        // Test with empty record separator
                                                                                                                                                                        format = format.withRecordSeparator("");
                                                                                                                                                                        assertEquals("", format.getRecordSeparator());
                                                                                                                                                                    }

    @Test(expected = NullPointerException.class)
                                                                                                                                                                    public void testParseWithNullReader() throws IOException {
                                                                                                                                                                        CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                                                                                                        csvFormat.parse(null);
                                                                                                                                                                    }

    @Test(expected = IOException.class)
                                                                                                                                                                    public void testPrintWithInvalidDelimiter() throws IOException {
                                                                                                                                                                        StringWriter out = new StringWriter();
                                                                                                                                                                        CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                                                                                                        csvFormat.withDelimiter('\n').print(out);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testToStringWithAllFieldsSet() {
                                                                                                                                                                        final String CRLF = "\r\n";
                                                                                                                                                                        CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                                                            .withDelimiter(',')
                                                                                                                                                                            .withEscape('\\')
                                                                                                                                                                            .withQuote('"')
                                                                                                                                                                            .withCommentMarker('#')
                                                                                                                                                                            .withNullString("NULL")
                                                                                                                                                                            .withRecordSeparator(CRLF)
                                                                                                                                                                            .withIgnoreEmptyLines(true)
                                                                                                                                                                            .withIgnoreSurroundingSpaces(true)
                                                                                                                                                                            .withIgnoreHeaderCase(true)
                                                                                                                                                                            .withSkipHeaderRecord(true)
                                                                                                                                                                            .withHeaderComments("HeaderComment1", "HeaderComment2")
                                                                                                                                                                            .withHeader("Col1", "Col2");
                                                                                                                                                                
                                                                                                                                                                        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> CommentStart=<#> NullString=<NULL> " +
                                                                                                                                                                                         "RecordSeparator=<" + CRLF + "> EmptyLines:ignored SurroundingSpaces:ignored " +
                                                                                                                                                                                         "IgnoreHeaderCase:ignored SkipHeaderRecord:true " +
                                                                                                                                                                                         "HeaderComments:[HeaderComment1, HeaderComment2] " +
                                                                                                                                                                                         "Header:[Col1, Col2]";
                                                                                                                                                                        
                                                                                                                                                                        assertEquals(expected, format.toString());
                                                                                                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                    public void testValidateWithDelimiterSameAsEscape() throws Exception {
                                                                                                                                                                        CSVFormat badFormat = CSVFormat.DEFAULT.withDelimiter(',').withEscape(',');
                                                                                                                                                                        Method validateMethod = CSVFormat.class.getDeclaredMethod("validate");
                                                                                                                                                                        validateMethod.setAccessible(true);
                                                                                                                                                                        validateMethod.invoke(badFormat);
                                                                                                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                    public void testValidateWithDelimiterSameAsComment() throws Exception {
                                                                                                                                                                        Method validateMethod = CSVFormat.class.getDeclaredMethod("validate");
                                                                                                                                                                        validateMethod.setAccessible(true);
                                                                                                                                                                        
                                                                                                                                                                        CSVFormat badFormat = CSVFormat.newFormat(',')
                                                                                                                                                                            .withCommentMarker(',')
                                                                                                                                                                            .withQuoteMode(QuoteMode.MINIMAL);
                                                                                                                                                                            
                                                                                                                                                                        validateMethod.invoke(badFormat);
                                                                                                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                    public void testValidateWithQuoteSameAsComment() throws Exception {
                                                                                                                                                                        Method validateMethod = CSVFormat.class.getDeclaredMethod("validate");
                                                                                                                                                                        validateMethod.setAccessible(true);
                                                                                                                                                                        
                                                                                                                                                                        CSVFormat badFormat = CSVFormat.newFormat(',')
                                                                                                                                                                            .withQuote('a')
                                                                                                                                                                            .withCommentMarker('a')
                                                                                                                                                                            .withQuoteMode(QuoteMode.NONE)
                                                                                                                                                                            .withIgnoreEmptyLines(false)
                                                                                                                                                                            .withIgnoreSurroundingSpaces(false);
                                                                                                                                                                            
                                                                                                                                                                        validateMethod.invoke(badFormat);
                                                                                                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                    public void testValidateWithNoEscapeAndQuoteModeNone() throws Exception {
                                                                                                                                                                        // Create format using builder pattern since constructor is private
                                                                                                                                                                        CSVFormat badFormat = CSVFormat.newFormat(',')
                                                                                                                                                                            .withQuoteMode(QuoteMode.NONE)
                                                                                                                                                                            .withAllowMissingColumnNames(false)
                                                                                                                                                                            .withIgnoreEmptyLines(false)
                                                                                                                                                                            .withIgnoreSurroundingSpaces(false);
                                                                                                                                                                        
                                                                                                                                                                        // Get private validate method via reflection
                                                                                                                                                                        Method validateMethod = CSVFormat.class.getDeclaredMethod("validate");
                                                                                                                                                                        validateMethod.setAccessible(true);
                                                                                                                                                                        validateMethod.invoke(badFormat);
                                                                                                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                    public void testValidateWithDuplicateHeader() throws Exception {
                                                                                                                                                                        String[] header = {"name", "age", "name"};
                                                                                                                                                                        Method validateMethod = CSVFormat.class.getDeclaredMethod("validate");
                                                                                                                                                                        validateMethod.setAccessible(true);
                                                                                                                                                                        
                                                                                                                                                                        CSVFormat badFormat = CSVFormat.newFormat(',')
                                                                                                                                                                            .withHeader(header)
                                                                                                                                                                            .withQuoteMode(QuoteMode.NONE)
                                                                                                                                                                            .withEscape('\\');
                                                                                                                                                                        
                                                                                                                                                                        validateMethod.invoke(badFormat);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                public void testConstructorWithLineBreakDelimiter() throws Exception {
                                                                                                                                                                    CSVFormat format = CSVFormat.DEFAULT.withDelimiter('\n')
                                                                                                                                                                        .withQuote(null)
                                                                                                                                                                        .withQuoteMode(null)
                                                                                                                                                                        .withCommentMarker(null)
                                                                                                                                                                        .withEscape(null)
                                                                                                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                                                                                                        .withIgnoreEmptyLines(false)
                                                                                                                                                                        .withRecordSeparator(null)
                                                                                                                                                                        .withNullString(null)
                                                                                                                                                                        .withHeaderComments((Object[]) null)
                                                                                                                                                                        .withHeader((String[]) null)
                                                                                                                                                                        .withSkipHeaderRecord(false)
                                                                                                                                                                        .withAllowMissingColumnNames(false)
                                                                                                                                                                        .withIgnoreHeaderCase(false);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testWithHeader() throws Exception {
                                                                                                                                                                    CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                                                                                    String[] headers = {"Header1", "Header2"};
                                                                                                                                                                    
                                                                                                                                                                    CSVFormat newFormat = baseFormat.withHeader(headers);
                                                                                                                                                                    
                                                                                                                                                                    assertArrayEquals(headers, newFormat.getHeader());
                                                                                                                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                public void testConstructorWithSameDelimiterAndEscape() throws Exception {
                                                                                                                                                                    CSVFormat.class.getDeclaredConstructor(
                                                                                                                                                                        char.class, 
                                                                                                                                                                        Character.class, 
                                                                                                                                                                        QuoteMode.class, 
                                                                                                                                                                        Character.class, 
                                                                                                                                                                        Character.class, 
                                                                                                                                                                        boolean.class, 
                                                                                                                                                                        boolean.class, 
                                                                                                                                                                        String.class, 
                                                                                                                                                                        String.class, 
                                                                                                                                                                        Object[].class, 
                                                                                                                                                                        String[].class, 
                                                                                                                                                                        boolean.class, 
                                                                                                                                                                        boolean.class, 
                                                                                                                                                                        boolean.class)
                                                                                                                                                                    .newInstance(
                                                                                                                                                                        ',', 
                                                                                                                                                                        null, 
                                                                                                                                                                        null, 
                                                                                                                                                                        null, 
                                                                                                                                                                        ',', 
                                                                                                                                                                        false, 
                                                                                                                                                                        false, 
                                                                                                                                                                        null, 
                                                                                                                                                                        null, 
                                                                                                                                                                        null, 
                                                                                                                                                                        null, 
                                                                                                                                                                        false, 
                                                                                                                                                                        false, 
                                                                                                                                                                        false);
                                                                                                                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                public void testConstructorWithSameDelimiterAndComment() throws Exception {
                                                                                                                                                                    CSVFormat.class.getDeclaredConstructor(
                                                                                                                                                                        char.class, Character.class, QuoteMode.class, Character.class, Character.class,
                                                                                                                                                                        boolean.class, boolean.class, String.class, String.class, Object[].class,
                                                                                                                                                                        String[].class, boolean.class, boolean.class, boolean.class)
                                                                                                                                                                        .newInstance(
                                                                                                                                                                            ',', null, null, ',', null,
                                                                                                                                                                            false, false, null, null, null,
                                                                                                                                                                            null, false, false, false);
                                                                                                                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                public void testConstructorWithSameEscapeAndComment() throws Exception {
                                                                                                                                                                    CSVFormat.class.getDeclaredConstructor(
                                                                                                                                                                            char.class, Character.class, QuoteMode.class, Character.class, Character.class,
                                                                                                                                                                            boolean.class, boolean.class, String.class, String.class, Object[].class,
                                                                                                                                                                            String[].class, boolean.class, boolean.class, boolean.class)
                                                                                                                                                                        .newInstance(
                                                                                                                                                                            ',', null, null, '\\', '\\', false, false, null, null, null, null, false, false, false);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testConstructorWithQuoteModeNoneAndNoEscape() throws Exception {
                                                                                                                                                                    CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                                                        .withDelimiter(',')
                                                                                                                                                                        .withQuote(null)
                                                                                                                                                                        .withQuoteMode(QuoteMode.NONE)
                                                                                                                                                                        .withCommentMarker(null)
                                                                                                                                                                        .withEscape(null)
                                                                                                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                                                                                                        .withIgnoreEmptyLines(false)
                                                                                                                                                                        .withRecordSeparator(null)
                                                                                                                                                                        .withNullString(null)
                                                                                                                                                                        .withHeaderComments((Object[]) null)
                                                                                                                                                                        .withHeader((String[]) null)
                                                                                                                                                                        .withSkipHeaderRecord(false)
                                                                                                                                                                        .withAllowMissingColumnNames(false)
                                                                                                                                                                        .withIgnoreHeaderCase(false);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testConstructorWithNullValues() throws Exception {
                                                                                                                                                                    CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                                                        .withQuote(null)
                                                                                                                                                                        .withQuoteMode(null)
                                                                                                                                                                        .withCommentMarker(null)
                                                                                                                                                                        .withEscape(null)
                                                                                                                                                                        .withRecordSeparator(null)
                                                                                                                                                                        .withNullString(null)
                                                                                                                                                                        .withHeaderComments((Object[]) null)
                                                                                                                                                                        .withHeader((String[]) null)
                                                                                                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                                                                                                        .withIgnoreEmptyLines(false)
                                                                                                                                                                        .withSkipHeaderRecord(false)
                                                                                                                                                                        .withAllowMissingColumnNames(false)
                                                                                                                                                                        .withIgnoreHeaderCase(false);
                                                                                                                                                            
                                                                                                                                                                    assertNull(format.getQuoteCharacter());
                                                                                                                                                                    assertNull(format.getQuoteMode());
                                                                                                                                                                    assertNull(format.getCommentMarker());
                                                                                                                                                                    assertNull(format.getEscapeCharacter());
                                                                                                                                                                    assertNull(format.getRecordSeparator());
                                                                                                                                                                    assertNull(format.getNullString());
                                                                                                                                                                    assertNull(format.getHeaderComments());
                                                                                                                                                                    assertNull(format.getHeader());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testWithHeaderResultSet_WithValidResultSet() throws SQLException {
                                                                                                                                                                    ResultSet resultSet = mock(ResultSet.class);
                                                                                                                                                                    ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                                                    
                                                                                                                                                                    when(resultSet.getMetaData()).thenReturn(metaData);
                                                                                                                                                                    when(metaData.getColumnCount()).thenReturn(2);
                                                                                                                                                                    when(metaData.getColumnLabel(1)).thenReturn("Column1");
                                                                                                                                                                    when(metaData.getColumnLabel(2)).thenReturn("Column2");
                                                                                                                                                                    
                                                                                                                                                                    CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                    CSVFormat newFormat = format.withHeader(resultSet);
                                                                                                                                                                    
                                                                                                                                                                    assertArrayEquals(new String[]{"Column1", "Column2"}, newFormat.getHeader());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testWithHeaderResultSet_EmptyResultSet() throws SQLException {
                                                                                                                                                                    ResultSet resultSet = mock(ResultSet.class);
                                                                                                                                                                    java.sql.ResultSetMetaData metaData = mock(java.sql.ResultSetMetaData.class);
                                                                                                                                                                    
                                                                                                                                                                    when(resultSet.getMetaData()).thenReturn(metaData);
                                                                                                                                                                    when(metaData.getColumnCount()).thenReturn(0);
                                                                                                                                                            
                                                                                                                                                                    CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                    CSVFormat newFormat = format.withHeader(resultSet);
                                                                                                                                                            
                                                                                                                                                                    assertArrayEquals(new String[0], newFormat.getHeader());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testWithHeaderResultSetMetaData1() throws SQLException {
                                                                                                                                                                    // Setup mock behavior
                                                                                                                                                                    ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                                                    when(metaData.getColumnCount()).thenReturn(3);
                                                                                                                                                                    when(metaData.getColumnLabel(1)).thenReturn("Column1");
                                                                                                                                                                    when(metaData.getColumnLabel(2)).thenReturn("Column2");
                                                                                                                                                                    when(metaData.getColumnLabel(3)).thenReturn("Column3");
                                                                                                                                                                    
                                                                                                                                                                    // Test with non-null metadata
                                                                                                                                                                    CSVFormat format = CSVFormat.DEFAULT.withHeader(metaData);
                                                                                                                                                                    assertArrayEquals(new String[]{"Column1", "Column2", "Column3"}, format.getHeader());
                                                                                                                                                                    
                                                                                                                                                                    // Test with null metadata
                                                                                                                                                                    CSVFormat nullFormat = CSVFormat.DEFAULT.withHeader((ResultSetMetaData) null);
                                                                                                                                                                    assertNull(nullFormat.getHeader());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testWithHeaderResultSetMetaDataEmptyColumns() throws SQLException {
                                                                                                                                                                    ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                                                    when(metaData.getColumnCount()).thenReturn(0);
                                                                                                                                                                    CSVFormat format = CSVFormat.DEFAULT.withHeader(metaData);
                                                                                                                                                                    assertArrayEquals(new String[0], format.getHeader());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testWithHeaderResultSetMetaDataPreservesOtherSettings() throws SQLException {
                                                                                                                                                                    ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                                                    when(metaData.getColumnCount()).thenReturn(1);
                                                                                                                                                                    when(metaData.getColumnLabel(1)).thenReturn("Test");
                                                                                                                                                            
                                                                                                                                                                    CSVFormat original = CSVFormat.DEFAULT
                                                                                                                                                                        .withDelimiter(';')
                                                                                                                                                                        .withQuote('\'')
                                                                                                                                                                        .withCommentMarker('#')
                                                                                                                                                                        .withEscape('\\')
                                                                                                                                                                        .withIgnoreSurroundingSpaces(true)
                                                                                                                                                                        .withIgnoreEmptyLines(true)
                                                                                                                                                                        .withRecordSeparator("\n")
                                                                                                                                                                        .withNullString("NULL")
                                                                                                                                                                        .withSkipHeaderRecord(true)
                                                                                                                                                                        .withAllowMissingColumnNames(true)
                                                                                                                                                                        .withIgnoreHeaderCase(true);
                                                                                                                                                            
                                                                                                                                                                    CSVFormat newFormat = original.withHeader(metaData);
                                                                                                                                                            
                                                                                                                                                                    assertEquals(';', newFormat.getDelimiter());
                                                                                                                                                                    assertEquals(Character.valueOf('\''), newFormat.getQuoteCharacter());
                                                                                                                                                                    assertEquals(Character.valueOf('#'), newFormat.getCommentMarker());
                                                                                                                                                                    assertEquals(Character.valueOf('\\'), newFormat.getEscapeCharacter());
                                                                                                                                                                    assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                                                                                                    assertTrue(newFormat.getIgnoreEmptyLines());
                                                                                                                                                                    assertEquals("\n", newFormat.getRecordSeparator());
                                                                                                                                                                    assertEquals("NULL", newFormat.getNullString());
                                                                                                                                                                    assertTrue(newFormat.getSkipHeaderRecord());
                                                                                                                                                                    assertTrue(newFormat.getAllowMissingColumnNames());
                                                                                                                                                                    assertTrue(newFormat.getIgnoreHeaderCase());
                                                                                                                                                                    assertArrayEquals(new String[]{"Test"}, newFormat.getHeader());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testConstructorWithAllParameters() throws Exception {
                                                                                                                                                                    char delimiter = ',';
                                                                                                                                                                    Character quoteChar = '"';
                                                                                                                                                                    QuoteMode quoteMode = QuoteMode.ALL;
                                                                                                                                                                    Character commentMarker = '#';
                                                                                                                                                                    Character escape = '\\';
                                                                                                                                                                    boolean ignoreSurroundingSpaces = true;
                                                                                                                                                                    boolean ignoreEmptyLines = true;
                                                                                                                                                                    String recordSeparator = "\n";
                                                                                                                                                                    String nullString = "NULL";
                                                                                                                                                                    Object[] headerComments = new Object[]{"Comment1", "Comment2"};
                                                                                                                                                                    String[] header = new String[]{"Header1", "Header2"};
                                                                                                                                                                    boolean skipHeaderRecord = true;
                                                                                                                                                                    boolean allowMissingColumnNames = true;
                                                                                                                                                                    boolean ignoreHeaderCase = true;
                                                                                                                                                            
                                                                                                                                                                    Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                                                                                                            char.class, Character.class, QuoteMode.class, Character.class, Character.class,
                                                                                                                                                                            boolean.class, boolean.class, String.class, String.class, Object[].class,
                                                                                                                                                                            String[].class, boolean.class, boolean.class, boolean.class);
                                                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    CSVFormat format = constructor.newInstance(delimiter, quoteChar, quoteMode, commentMarker, escape,
                                                                                                                                                                            ignoreSurroundingSpaces, ignoreEmptyLines, recordSeparator, nullString, headerComments, header,
                                                                                                                                                                            skipHeaderRecord, allowMissingColumnNames, ignoreHeaderCase);
                                                                                                                                                            
                                                                                                                                                                    assertEquals(delimiter, format.getDelimiter());
                                                                                                                                                                    assertEquals(quoteChar, format.getQuoteCharacter());
                                                                                                                                                                    assertEquals(quoteMode, format.getQuoteMode());
                                                                                                                                                                    assertEquals(commentMarker, format.getCommentMarker());
                                                                                                                                                                    assertEquals(escape, format.getEscapeCharacter());
                                                                                                                                                                    assertTrue(format.getIgnoreSurroundingSpaces());
                                                                                                                                                                    assertTrue(format.getIgnoreEmptyLines());
                                                                                                                                                                    assertEquals(recordSeparator, format.getRecordSeparator());
                                                                                                                                                                    assertEquals(nullString, format.getNullString());
                                                                                                                                                                    assertArrayEquals(new String[]{"Comment1", "Comment2"}, format.getHeaderComments());
                                                                                                                                                                    assertArrayEquals(header, format.getHeader());
                                                                                                                                                                    assertTrue(format.getSkipHeaderRecord());
                                                                                                                                                                    assertTrue(format.getAllowMissingColumnNames());
                                                                                                                                                                    assertTrue(format.getIgnoreHeaderCase());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testConstructorWithNullParameters() {
                                                                                                                                                                    CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                                                        .withQuote(null)
                                                                                                                                                                        .withQuoteMode(null)
                                                                                                                                                                        .withCommentMarker(null)
                                                                                                                                                                        .withEscape(null)
                                                                                                                                                                        .withRecordSeparator(null)
                                                                                                                                                                        .withNullString(null)
                                                                                                                                                                        .withHeaderComments(null)
                                                                                                                                                                        .withHeader((String[]) null)
                                                                                                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                                                                                                        .withIgnoreEmptyLines(false)
                                                                                                                                                                        .withSkipHeaderRecord(false)
                                                                                                                                                                        .withAllowMissingColumnNames(false)
                                                                                                                                                                        .withIgnoreHeaderCase(false);
                                                                                                                                                            
                                                                                                                                                                    assertNull(format.getQuoteCharacter());
                                                                                                                                                                    assertNull(format.getQuoteMode());
                                                                                                                                                                    assertNull(format.getCommentMarker());
                                                                                                                                                                    assertNull(format.getEscapeCharacter());
                                                                                                                                                                    assertNull(format.getRecordSeparator());
                                                                                                                                                                    assertNull(format.getNullString());
                                                                                                                                                                    assertNull(format.getHeaderComments());
                                                                                                                                                                    assertNull(format.getHeader());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testConstructor() throws Exception {
                                                                                                                                                                    // Get the private constructor
                                                                                                                                                                    Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                                                                                                        char.class, Character.class, QuoteMode.class, Character.class, Character.class,
                                                                                                                                                                        boolean.class, boolean.class, String.class, String.class, Object[].class,
                                                                                                                                                                        String[].class, boolean.class, boolean.class, boolean.class);
                                                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                                    // Create instance using reflection
                                                                                                                                                                    CSVFormat format = constructor.newInstance(
                                                                                                                                                                        ',', '"', QuoteMode.ALL, '#', '\\',
                                                                                                                                                                        true, true, "\r\n", "null", new Object[]{"comment"},
                                                                                                                                                                        new String[]{"header"}, true, true, true);
                                                                                                                                                                    
                                                                                                                                                                    assertEquals(',', format.getDelimiter());
                                                                                                                                                                    assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
                                                                                                                                                                    assertEquals(QuoteMode.ALL, format.getQuoteMode());
                                                                                                                                                                    assertEquals(Character.valueOf('#'), format.getCommentMarker());
                                                                                                                                                                    assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
                                                                                                                                                                    assertTrue(format.getIgnoreSurroundingSpaces());
                                                                                                                                                                    assertTrue(format.getIgnoreEmptyLines());
                                                                                                                                                                    assertEquals("\r\n", format.getRecordSeparator());
                                                                                                                                                                    assertEquals("null", format.getNullString());
                                                                                                                                                                    assertArrayEquals(new String[]{"comment"}, format.getHeaderComments());
                                                                                                                                                                    assertArrayEquals(new String[]{"header"}, format.getHeader());
                                                                                                                                                                    assertTrue(format.getSkipHeaderRecord());
                                                                                                                                                                    assertTrue(format.getAllowMissingColumnNames());
                                                                                                                                                                    assertTrue(format.getIgnoreHeaderCase());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testConstructorWithLineBreakDelimiter1() throws Exception {
                                                                                                                                                                    Character quoteCharacter = '"';
                                                                                                                                                                    QuoteMode quoteMode = QuoteMode.ALL;
                                                                                                                                                                    Character commentMarker = '#';
                                                                                                                                                                    Character escapeCharacter = '\\';
                                                                                                                                                                    String recordSeparator = "\r\n";
                                                                                                                                                                    String nullString = "null";
                                                                                                                                                                    Object[] headerComments = new Object[]{"comment"};
                                                                                                                                                                    String[] header = new String[]{"header"};
                                                                                                                                                                    
                                                                                                                                                                    CSVFormat format = CSVFormat.DEFAULT.withDelimiter('\n')
                                                                                                                                                                        .withQuote(quoteCharacter)
                                                                                                                                                                        .withQuoteMode(quoteMode)
                                                                                                                                                                        .withCommentMarker(commentMarker)
                                                                                                                                                                        .withEscape(escapeCharacter)
                                                                                                                                                                        .withIgnoreSurroundingSpaces(true)
                                                                                                                                                                        .withIgnoreEmptyLines(true)
                                                                                                                                                                        .withRecordSeparator(recordSeparator)
                                                                                                                                                                        .withNullString(nullString)
                                                                                                                                                                        .withHeaderComments(headerComments)
                                                                                                                                                                        .withHeader(header)
                                                                                                                                                                        .withSkipHeaderRecord(true)
                                                                                                                                                                        .withAllowMissingColumnNames(true)
                                                                                                                                                                        .withIgnoreHeaderCase(true);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testConstructorWithNullValues1() throws Exception {
                                                                                                                                                                    CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                                                        .withDelimiter(',')
                                                                                                                                                                        .withQuote((Character) null)
                                                                                                                                                                        .withQuoteMode(null)
                                                                                                                                                                        .withCommentMarker(null)
                                                                                                                                                                        .withEscape(null)
                                                                                                                                                                        .withRecordSeparator(null)
                                                                                                                                                                        .withNullString(null)
                                                                                                                                                                        .withHeaderComments(null)
                                                                                                                                                                        .withHeader((String[]) null)
                                                                                                                                                                        .withSkipHeaderRecord(false)
                                                                                                                                                                        .withAllowMissingColumnNames(false)
                                                                                                                                                                        .withIgnoreHeaderCase(false);
                                                                                                                                                                    
                                                                                                                                                                    assertNull(format.getQuoteCharacter());
                                                                                                                                                                    assertNull(format.getQuoteMode());
                                                                                                                                                                    assertNull(format.getCommentMarker());
                                                                                                                                                                    assertNull(format.getEscapeCharacter());
                                                                                                                                                                    assertNull(format.getRecordSeparator());
                                                                                                                                                                    assertNull(format.getNullString());
                                                                                                                                                                    assertNull(format.getHeaderComments());
                                                                                                                                                                    assertNull(format.getHeader());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testConstructorWithResultSetNullMetaData() throws Exception {
                                                                                                                                                                    CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                                                        .withDelimiter(',')
                                                                                                                                                                        .withQuote('"')
                                                                                                                                                                        .withQuoteMode(QuoteMode.ALL)
                                                                                                                                                                        .withCommentMarker('#')
                                                                                                                                                                        .withEscape('\\')
                                                                                                                                                                        .withIgnoreSurroundingSpaces(true)
                                                                                                                                                                        .withIgnoreEmptyLines(true)
                                                                                                                                                                        .withRecordSeparator("\r\n")
                                                                                                                                                                        .withNullString("null")
                                                                                                                                                                        .withHeaderComments(new Object[]{"comment"})
                                                                                                                                                                        .withSkipHeaderRecord(true)
                                                                                                                                                                        .withAllowMissingColumnNames(true)
                                                                                                                                                                        .withIgnoreHeaderCase(true)
                                                                                                                                                                        .withHeader((ResultSetMetaData) null);
                                                                                                                                                                    
                                                                                                                                                                    assertNull(format.getHeader());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testConstructorWithHeaderComments() throws Exception {
                                                                                                                                                                    CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                                                        .withDelimiter(',')
                                                                                                                                                                        .withQuote('"')
                                                                                                                                                                        .withQuoteMode(QuoteMode.ALL)
                                                                                                                                                                        .withCommentMarker('#')
                                                                                                                                                                        .withEscape('\\')
                                                                                                                                                                        .withIgnoreSurroundingSpaces(true)
                                                                                                                                                                        .withIgnoreEmptyLines(true)
                                                                                                                                                                        .withRecordSeparator("\r\n")
                                                                                                                                                                        .withNullString("null")
                                                                                                                                                                        .withHeaderComments("comment1", "comment2")
                                                                                                                                                                        .withHeader("header")
                                                                                                                                                                        .withSkipHeaderRecord(true)
                                                                                                                                                                        .withAllowMissingColumnNames(true)
                                                                                                                                                                        .withIgnoreHeaderCase(true);
                                                                                                                                                                    
                                                                                                                                                                    assertArrayEquals(new String[]{"comment1", "comment2"}, format.getHeaderComments());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testConstructorWithEmptyHeader() throws Exception {
                                                                                                                                                                    Character delimiter = ',';
                                                                                                                                                                    Character quoteCharacter = '"';
                                                                                                                                                                    QuoteMode quoteMode = QuoteMode.ALL;
                                                                                                                                                                    Character commentMarker = '#';
                                                                                                                                                                    Character escapeCharacter = '\\';
                                                                                                                                                                    boolean ignoreSurroundingSpaces = true;
                                                                                                                                                                    boolean ignoreEmptyLines = true;
                                                                                                                                                                    String recordSeparator = "\r\n";
                                                                                                                                                                    String nullString = "null";
                                                                                                                                                                    Object[] headerComments = new Object[]{"comment"};
                                                                                                                                                                    String[] header = new String[]{};
                                                                                                                                                                    boolean skipHeaderRecord = true;
                                                                                                                                                                    boolean allowMissingColumnNames = true;
                                                                                                                                                                    boolean ignoreHeaderCase = true;
                                                                                                                                                                    
                                                                                                                                                                    CSVFormat format = CSVFormat.newFormat(delimiter)
                                                                                                                                                                        .withQuote(quoteCharacter)
                                                                                                                                                                        .withQuoteMode(quoteMode)
                                                                                                                                                                        .withCommentMarker(commentMarker)
                                                                                                                                                                        .withEscape(escapeCharacter)
                                                                                                                                                                        .withIgnoreSurroundingSpaces(ignoreSurroundingSpaces)
                                                                                                                                                                        .withIgnoreEmptyLines(ignoreEmptyLines)
                                                                                                                                                                        .withRecordSeparator(recordSeparator)
                                                                                                                                                                        .withNullString(nullString)
                                                                                                                                                                        .withHeaderComments(headerComments)
                                                                                                                                                                        .withHeader(header)
                                                                                                                                                                        .withSkipHeaderRecord(skipHeaderRecord)
                                                                                                                                                                        .withAllowMissingColumnNames(allowMissingColumnNames)
                                                                                                                                                                        .withIgnoreHeaderCase(ignoreHeaderCase);
                                                                                                                                                                    
                                                                                                                                                                    assertArrayEquals(new String[]{}, format.getHeader());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testConstructorWithEmptyHeaderComments() throws Exception {
                                                                                                                                                                    CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                                                        .withQuote('"')
                                                                                                                                                                        .withQuoteMode(QuoteMode.ALL)
                                                                                                                                                                        .withCommentMarker('#')
                                                                                                                                                                        .withEscape('\\')
                                                                                                                                                                        .withIgnoreSurroundingSpaces(true)
                                                                                                                                                                        .withIgnoreEmptyLines(true)
                                                                                                                                                                        .withRecordSeparator("\r\n")
                                                                                                                                                                        .withNullString("null")
                                                                                                                                                                        .withHeaderComments(new Object[]{})
                                                                                                                                                                        .withHeader("header")
                                                                                                                                                                        .withSkipHeaderRecord(true)
                                                                                                                                                                        .withAllowMissingColumnNames(true)
                                                                                                                                                                        .withIgnoreHeaderCase(true);
                                                                                                                                                                    
                                                                                                                                                                    assertArrayEquals(new String[]{}, format.getHeaderComments());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testConstructorWithNullHeaderComments() throws Exception {
                                                                                                                                                                    CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                                                        .withQuote('"')
                                                                                                                                                                        .withQuoteMode(QuoteMode.ALL)
                                                                                                                                                                        .withCommentMarker('#')
                                                                                                                                                                        .withEscape('\\')
                                                                                                                                                                        .withIgnoreSurroundingSpaces(true)
                                                                                                                                                                        .withIgnoreEmptyLines(true)
                                                                                                                                                                        .withRecordSeparator("\r\n")
                                                                                                                                                                        .withNullString("null")
                                                                                                                                                                        .withHeaderComments((Object[]) null)
                                                                                                                                                                        .withHeader("header")
                                                                                                                                                                        .withSkipHeaderRecord(true)
                                                                                                                                                                        .withAllowMissingColumnNames(true)
                                                                                                                                                                        .withIgnoreHeaderCase(true);
                                                                                                                                                                    
                                                                                                                                                                    assertNull(format.getHeaderComments());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testConstructorWithNullHeader() throws Exception {
                                                                                                                                                                    Character delimiter = ',';
                                                                                                                                                                    Character quoteCharacter = '"';
                                                                                                                                                                    QuoteMode quoteMode = QuoteMode.ALL;
                                                                                                                                                                    Character commentMarker = '#';
                                                                                                                                                                    Character escapeCharacter = '\\';
                                                                                                                                                                    boolean ignoreSurroundingSpaces = true;
                                                                                                                                                                    boolean ignoreEmptyLines = true;
                                                                                                                                                                    String recordSeparator = "\r\n";
                                                                                                                                                                    String nullString = "null";
                                                                                                                                                                    Object[] headerComments = new Object[]{"comment"};
                                                                                                                                                                    String[] header = null;
                                                                                                                                                                    boolean skipHeaderRecord = true;
                                                                                                                                                                    boolean allowMissingColumnNames = true;
                                                                                                                                                                    boolean ignoreHeaderCase = true;
                                                                                                                                                                    
                                                                                                                                                                    CSVFormat format = CSVFormat.newFormat(delimiter)
                                                                                                                                                                        .withQuote(quoteCharacter)
                                                                                                                                                                        .withQuoteMode(quoteMode)
                                                                                                                                                                        .withCommentMarker(commentMarker)
                                                                                                                                                                        .withEscape(escapeCharacter)
                                                                                                                                                                        .withIgnoreSurroundingSpaces(ignoreSurroundingSpaces)
                                                                                                                                                                        .withIgnoreEmptyLines(ignoreEmptyLines)
                                                                                                                                                                        .withRecordSeparator(recordSeparator)
                                                                                                                                                                        .withNullString(nullString)
                                                                                                                                                                        .withHeaderComments(headerComments)
                                                                                                                                                                        .withHeader(header)
                                                                                                                                                                        .withSkipHeaderRecord(skipHeaderRecord)
                                                                                                                                                                        .withAllowMissingColumnNames(allowMissingColumnNames)
                                                                                                                                                                        .withIgnoreHeaderCase(ignoreHeaderCase);
                                                                                                                                                                        
                                                                                                                                                                    assertNull(format.getHeader());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testConstructorWithDifferentQuoteModes() throws Exception {
                                                                                                                                                                    for (QuoteMode mode : QuoteMode.values()) {
                                                                                                                                                                        CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                                                            .withQuote('"')
                                                                                                                                                                            .withQuoteMode(mode)
                                                                                                                                                                            .withCommentMarker('#')
                                                                                                                                                                            .withEscape('\\')
                                                                                                                                                                            .withIgnoreSurroundingSpaces(true)
                                                                                                                                                                            .withIgnoreEmptyLines(true)
                                                                                                                                                                            .withRecordSeparator("\r\n")
                                                                                                                                                                            .withNullString("null")
                                                                                                                                                                            .withHeaderComments(new Object[]{"comment"})
                                                                                                                                                                            .withHeader("header")
                                                                                                                                                                            .withSkipHeaderRecord(true)
                                                                                                                                                                            .withAllowMissingColumnNames(true)
                                                                                                                                                                            .withIgnoreHeaderCase(true);
                                                                                                                                                                        assertEquals(mode, format.getQuoteMode());
                                                                                                                                                                    }
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testConstructorWithDifferentRecordSeparators() throws Exception {
                                                                                                                                                                    String[] separators = {"\r", "\n", "\r\n", "|"};
                                                                                                                                                                    for (String separator : separators) {
                                                                                                                                                                        CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                                                            .withQuote('"')
                                                                                                                                                                            .withQuoteMode(QuoteMode.ALL)
                                                                                                                                                                            .withCommentMarker('#')
                                                                                                                                                                            .withEscape('\\')
                                                                                                                                                                            .withIgnoreSurroundingSpaces(true)
                                                                                                                                                                            .withIgnoreEmptyLines(true)
                                                                                                                                                                            .withRecordSeparator(separator)
                                                                                                                                                                            .withNullString("null")
                                                                                                                                                                            .withHeaderComments(new Object[]{"comment"})
                                                                                                                                                                            .withHeader("header")
                                                                                                                                                                            .withSkipHeaderRecord(true)
                                                                                                                                                                            .withAllowMissingColumnNames(true)
                                                                                                                                                                            .withIgnoreHeaderCase(true);
                                                                                                                                                                        assertEquals(separator, format.getRecordSeparator());
                                                                                                                                                                    }
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testConstructorWithAllParameters1() throws Exception {
                                                                                                                                                                    char delimiter = ',';
                                                                                                                                                                    Character quoteChar = '"';
                                                                                                                                                                    QuoteMode quoteMode = QuoteMode.ALL;
                                                                                                                                                                    Character commentMarker = '#';
                                                                                                                                                                    Character escape = '\\';
                                                                                                                                                                    boolean ignoreSurroundingSpaces = true;
                                                                                                                                                                    boolean ignoreEmptyLines = true;
                                                                                                                                                                    String recordSeparator = "\n";
                                                                                                                                                                    String nullString = "NULL";
                                                                                                                                                                    Object[] headerComments = new Object[]{"Comment1", "Comment2"};
                                                                                                                                                                    String[] header = new String[]{"Header1", "Header2"};
                                                                                                                                                                    boolean skipHeaderRecord = true;
                                                                                                                                                                    boolean allowMissingColumnNames = true;
                                                                                                                                                                    boolean ignoreHeaderCase = true;
                                                                                                                                                            
                                                                                                                                                                    Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                                                                                                        char.class, Character.class, QuoteMode.class, Character.class, Character.class,
                                                                                                                                                                        boolean.class, boolean.class, String.class, String.class, Object[].class,
                                                                                                                                                                        String[].class, boolean.class, boolean.class, boolean.class
                                                                                                                                                                    );
                                                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    CSVFormat format = constructor.newInstance(
                                                                                                                                                                        delimiter, quoteChar, quoteMode, commentMarker, escape,
                                                                                                                                                                        ignoreSurroundingSpaces, ignoreEmptyLines, recordSeparator, nullString, 
                                                                                                                                                                        headerComments, header, skipHeaderRecord, allowMissingColumnNames, ignoreHeaderCase
                                                                                                                                                                    );
                                                                                                                                                            
                                                                                                                                                                    assertEquals(delimiter, format.getDelimiter());
                                                                                                                                                                    assertEquals(quoteChar, format.getQuoteCharacter());
                                                                                                                                                                    assertEquals(quoteMode, format.getQuoteMode());
                                                                                                                                                                    assertEquals(commentMarker, format.getCommentMarker());
                                                                                                                                                                    assertEquals(escape, format.getEscapeCharacter());
                                                                                                                                                                    assertTrue(format.getIgnoreSurroundingSpaces());
                                                                                                                                                                    assertTrue(format.getIgnoreEmptyLines());
                                                                                                                                                                    assertEquals(recordSeparator, format.getRecordSeparator());
                                                                                                                                                                    assertEquals(nullString, format.getNullString());
                                                                                                                                                                    assertArrayEquals(new String[]{"Comment1", "Comment2"}, format.getHeaderComments());
                                                                                                                                                                    assertArrayEquals(header, format.getHeader());
                                                                                                                                                                    assertTrue(format.getSkipHeaderRecord());
                                                                                                                                                                    assertTrue(format.getAllowMissingColumnNames());
                                                                                                                                                                    assertTrue(format.getIgnoreHeaderCase());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testConstructorWithNullParameters1() throws Exception {
                                                                                                                                                                    Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                                                                                                            char.class, Character.class, QuoteMode.class, Character.class, Character.class,
                                                                                                                                                                            boolean.class, boolean.class, String.class, String.class, Object[].class,
                                                                                                                                                                            String[].class, boolean.class, boolean.class, boolean.class);
                                                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    CSVFormat format = constructor.newInstance(
                                                                                                                                                                            ',', null, null, null, null, 
                                                                                                                                                                            false, false, null, null, null, 
                                                                                                                                                                            null, false, false, false);
                                                                                                                                                            
                                                                                                                                                                    assertNull(format.getQuoteCharacter());
                                                                                                                                                                    assertNull(format.getQuoteMode());
                                                                                                                                                                    assertNull(format.getCommentMarker());
                                                                                                                                                                    assertNull(format.getEscapeCharacter());
                                                                                                                                                                    assertNull(format.getRecordSeparator());
                                                                                                                                                                    assertNull(format.getNullString());
                                                                                                                                                                    assertNull(format.getHeaderComments());
                                                                                                                                                                    assertNull(format.getHeader());
                                                                                                                                                                    assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                                                                                                    assertFalse(format.getIgnoreEmptyLines());
                                                                                                                                                                    assertFalse(format.getSkipHeaderRecord());
                                                                                                                                                                    assertFalse(format.getAllowMissingColumnNames());
                                                                                                                                                                    assertFalse(format.getIgnoreHeaderCase());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testConstructorWithAllParameters2() throws Exception {
                                                                                                                                                                    char delimiter = ',';
                                                                                                                                                                    Character quoteChar = '"';
                                                                                                                                                                    QuoteMode quoteMode = QuoteMode.ALL;
                                                                                                                                                                    Character commentMarker = '#';
                                                                                                                                                                    Character escape = '\\';
                                                                                                                                                                    boolean ignoreSurroundingSpaces = true;
                                                                                                                                                                    boolean ignoreEmptyLines = true;
                                                                                                                                                                    String recordSeparator = "\n";
                                                                                                                                                                    String nullString = "NULL";
                                                                                                                                                                    Object[] headerComments = new Object[]{"Comment1", "Comment2"};
                                                                                                                                                                    String[] header = new String[]{"Header1", "Header2"};
                                                                                                                                                                    boolean skipHeaderRecord = true;
                                                                                                                                                                    boolean allowMissingColumnNames = true;
                                                                                                                                                                    boolean ignoreHeaderCase = true;
                                                                                                                                                            
                                                                                                                                                                    Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                                                                                                            char.class, Character.class, QuoteMode.class, Character.class, Character.class,
                                                                                                                                                                            boolean.class, boolean.class, String.class, String.class, Object[].class,
                                                                                                                                                                            String[].class, boolean.class, boolean.class, boolean.class);
                                                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                                                    CSVFormat format = constructor.newInstance(delimiter, quoteChar, quoteMode, commentMarker, escape,
                                                                                                                                                                            ignoreSurroundingSpaces, ignoreEmptyLines, recordSeparator, nullString, headerComments, header,
                                                                                                                                                                            skipHeaderRecord, allowMissingColumnNames, ignoreHeaderCase);
                                                                                                                                                            
                                                                                                                                                                    assertEquals(delimiter, format.getDelimiter());
                                                                                                                                                                    assertEquals(quoteChar, format.getQuoteCharacter());
                                                                                                                                                                    assertEquals(quoteMode, format.getQuoteMode());
                                                                                                                                                                    assertEquals(commentMarker, format.getCommentMarker());
                                                                                                                                                                    assertEquals(escape, format.getEscapeCharacter());
                                                                                                                                                                    assertEquals(ignoreSurroundingSpaces, format.getIgnoreSurroundingSpaces());
                                                                                                                                                                    assertEquals(ignoreEmptyLines, format.getIgnoreEmptyLines());
                                                                                                                                                                    assertEquals(recordSeparator, format.getRecordSeparator());
                                                                                                                                                                    assertEquals(nullString, format.getNullString());
                                                                                                                                                                    assertArrayEquals(new String[]{"Comment1", "Comment2"}, format.getHeaderComments());
                                                                                                                                                                    assertArrayEquals(header, format.getHeader());
                                                                                                                                                                    assertEquals(skipHeaderRecord, format.getSkipHeaderRecord());
                                                                                                                                                                    assertEquals(allowMissingColumnNames, format.getAllowMissingColumnNames());
                                                                                                                                                                    assertEquals(ignoreHeaderCase, format.getIgnoreHeaderCase());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testConstructorWithLineBreakDelimiter2() {
                                                                                                                                                                    CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                                                        .withDelimiter('\n')
                                                                                                                                                                        .withQuote('"')
                                                                                                                                                                        .withQuoteMode(QuoteMode.ALL)
                                                                                                                                                                        .withCommentMarker('#')
                                                                                                                                                                        .withEscape('\\')
                                                                                                                                                                        .withIgnoreSurroundingSpaces(true)
                                                                                                                                                                        .withIgnoreEmptyLines(true)
                                                                                                                                                                        .withRecordSeparator("\n")
                                                                                                                                                                        .withSkipHeaderRecord(false)
                                                                                                                                                                        .withAllowMissingColumnNames(false)
                                                                                                                                                                        .withIgnoreHeaderCase(false);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testConstructorWithCommentMarkerSameAsDelimiter() {
                                                                                                                                                                    CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                                                        .withDelimiter(',')
                                                                                                                                                                        .withCommentMarker(',')
                                                                                                                                                                        .withIgnoreHeaderCase(false)
                                                                                                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                                                                                                        .withSkipHeaderRecord(false)
                                                                                                                                                                        .withAllowMissingColumnNames(false)
                                                                                                                                                                        .withIgnoreEmptyLines(false);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testConstructorWithQuoteModeNoneAndNoEscape1() {
                                                                                                                                                                    CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                                                        .withDelimiter(',')
                                                                                                                                                                        .withQuote('"')
                                                                                                                                                                        .withQuoteMode(QuoteMode.NONE)
                                                                                                                                                                        .withCommentMarker(null)
                                                                                                                                                                        .withEscape(null)
                                                                                                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                                                                                                        .withIgnoreEmptyLines(false)
                                                                                                                                                                        .withRecordSeparator(null)
                                                                                                                                                                        .withNullString(null)
                                                                                                                                                                        .withHeaderComments(null)
                                                                                                                                                                        .withHeader((String[]) null)
                                                                                                                                                                        .withSkipHeaderRecord(false)
                                                                                                                                                                        .withAllowMissingColumnNames(false)
                                                                                                                                                                        .withIgnoreHeaderCase(false);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testConstructor1() throws Exception {
                                                                                                                                                                    char delimiter = ',';
                                                                                                                                                                    Character quoteCharacter = '"';
                                                                                                                                                                    QuoteMode quoteMode = QuoteMode.ALL;
                                                                                                                                                                    Character commentMarker = '#';
                                                                                                                                                                    Character escapeCharacter = '\\';
                                                                                                                                                                    boolean ignoreSurroundingSpaces = true;
                                                                                                                                                                    boolean ignoreEmptyLines = true;
                                                                                                                                                                    String recordSeparator = "\r\n";
                                                                                                                                                                    String nullString = "NULL";
                                                                                                                                                                    Object[] headerComments = new Object[]{"Comment1", "Comment2"};
                                                                                                                                                                    String[] header = new String[]{"Header1", "Header2"};
                                                                                                                                                                    boolean skipHeaderRecord = true;
                                                                                                                                                                    boolean allowMissingColumnNames = true;
                                                                                                                                                                    boolean ignoreHeaderCase = true;
                                                                                                                                                            
                                                                                                                                                                    // Use reflection to access private constructor
                                                                                                                                                                    CSVFormat format = CSVFormat.class
                                                                                                                                                                        .getDeclaredConstructor(
                                                                                                                                                                            char.class,
                                                                                                                                                                            Character.class,
                                                                                                                                                                            QuoteMode.class,
                                                                                                                                                                            Character.class,
                                                                                                                                                                            Character.class,
                                                                                                                                                                            boolean.class,
                                                                                                                                                                            boolean.class,
                                                                                                                                                                            String.class,
                                                                                                                                                                            String.class,
                                                                                                                                                                            Object[].class,
                                                                                                                                                                            String[].class,
                                                                                                                                                                            boolean.class,
                                                                                                                                                                            boolean.class,
                                                                                                                                                                            boolean.class)
                                                                                                                                                                        .newInstance(
                                                                                                                                                                            delimiter,
                                                                                                                                                                            quoteCharacter,
                                                                                                                                                                            quoteMode,
                                                                                                                                                                            commentMarker,
                                                                                                                                                                            escapeCharacter,
                                                                                                                                                                            ignoreSurroundingSpaces,
                                                                                                                                                                            ignoreEmptyLines,
                                                                                                                                                                            recordSeparator,
                                                                                                                                                                            nullString,
                                                                                                                                                                            headerComments,
                                                                                                                                                                            header,
                                                                                                                                                                            skipHeaderRecord,
                                                                                                                                                                            allowMissingColumnNames,
                                                                                                                                                                            ignoreHeaderCase);
                                                                                                                                                            
                                                                                                                                                                    assertEquals(delimiter, format.getDelimiter());
                                                                                                                                                                    assertEquals(quoteCharacter, format.getQuoteCharacter());
                                                                                                                                                                    assertEquals(quoteMode, format.getQuoteMode());
                                                                                                                                                                    assertEquals(commentMarker, format.getCommentMarker());
                                                                                                                                                                    assertEquals(escapeCharacter, format.getEscapeCharacter());
                                                                                                                                                                    assertEquals(ignoreSurroundingSpaces, format.getIgnoreSurroundingSpaces());
                                                                                                                                                                    assertEquals(ignoreEmptyLines, format.getIgnoreEmptyLines());
                                                                                                                                                                    assertEquals(recordSeparator, format.getRecordSeparator());
                                                                                                                                                                    assertEquals(nullString, format.getNullString());
                                                                                                                                                                    assertArrayEquals(new String[]{"Comment1", "Comment2"}, format.getHeaderComments());
                                                                                                                                                                    assertArrayEquals(header, format.getHeader());
                                                                                                                                                                    assertEquals(skipHeaderRecord, format.getSkipHeaderRecord());
                                                                                                                                                                    assertEquals(allowMissingColumnNames, format.getAllowMissingColumnNames());
                                                                                                                                                                    assertEquals(ignoreHeaderCase, format.getIgnoreHeaderCase());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testConstructorWithSameDelimiterAndEscape1() throws Exception {
                                                                                                                                                                    // Use reflection to access private constructor
                                                                                                                                                                    java.lang.reflect.Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                                                                                                        char.class, Character.class, QuoteMode.class, Character.class, Character.class,
                                                                                                                                                                        boolean.class, boolean.class, String.class, String.class, Object[].class,
                                                                                                                                                                        String[].class, boolean.class, boolean.class, boolean.class);
                                                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    constructor.newInstance(
                                                                                                                                                                        ',', null, null, null, ',', 
                                                                                                                                                                        false, false, null, null, null, 
                                                                                                                                                                        null, false, false, false);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testConstructorWithSameEscapeAndComment1() {
                                                                                                                                                                    CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                                                        .withDelimiter(',')
                                                                                                                                                                        .withQuote(null)
                                                                                                                                                                        .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                                                        .withEscape('\\')
                                                                                                                                                                        .withCommentMarker('\\')
                                                                                                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                                                                                                        .withIgnoreEmptyLines(false)
                                                                                                                                                                        .withRecordSeparator(null)
                                                                                                                                                                        .withNullString(null)
                                                                                                                                                                        .withHeaderComments(null)
                                                                                                                                                                        .withHeader((String[]) null)
                                                                                                                                                                        .withSkipHeaderRecord(false)
                                                                                                                                                                        .withAllowMissingColumnNames(false)
                                                                                                                                                                        .withIgnoreHeaderCase(false);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testConstructorWithQuoteModeNoneAndNoEscape2() {
                                                                                                                                                                    CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NONE);
                                                                                                                                                                    // Verify the quote mode was set correctly
                                                                                                                                                                    assert format.getQuoteMode() == QuoteMode.NONE;
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testWithHeaderResultSet1() throws SQLException {
                                                                                                                                                                    ResultSet resultSet = mock(ResultSet.class);
                                                                                                                                                                    ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                                                    
                                                                                                                                                                    when(resultSet.getMetaData()).thenReturn(metaData);
                                                                                                                                                                    when(metaData.getColumnCount()).thenReturn(2);
                                                                                                                                                                    when(metaData.getColumnLabel(1)).thenReturn("Col1");
                                                                                                                                                                    when(metaData.getColumnLabel(2)).thenReturn("Col2");
                                                                                                                                                                
                                                                                                                                                                    CSVFormat format = CSVFormat.DEFAULT.withHeader(resultSet);
                                                                                                                                                                    assertArrayEquals(new String[]{"Col1", "Col2"}, format.getHeader());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testWithHeaderResultSetMetaData2() throws SQLException {
                                                                                                                                                                    ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                                                    when(metaData.getColumnCount()).thenReturn(2);
                                                                                                                                                                    when(metaData.getColumnLabel(1)).thenReturn("Col1");
                                                                                                                                                                    when(metaData.getColumnLabel(2)).thenReturn("Col2");
                                                                                                                                                                    
                                                                                                                                                                    CSVFormat format = CSVFormat.DEFAULT.withHeader(metaData);
                                                                                                                                                                    assertArrayEquals(new String[]{"Col1", "Col2"}, format.getHeader());
                                                                                                                                                                }

    @Test
                                                                                                                                                            public void testConstructor2() throws Exception {
                                                                                                                                                                // Get the private constructor
                                                                                                                                                                Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                                                                                                        char.class, Character.class, QuoteMode.class, Character.class, Character.class,
                                                                                                                                                                        boolean.class, boolean.class, String.class, String.class, Object[].class,
                                                                                                                                                                        String[].class, boolean.class, boolean.class, boolean.class);
                                                                                                                                                                constructor.setAccessible(true);
                                                                                                                                                        
                                                                                                                                                                // Create instance using reflection
                                                                                                                                                                CSVFormat format = constructor.newInstance(
                                                                                                                                                                        ',', '"', QuoteMode.ALL, '#', '\\',
                                                                                                                                                                        true, true, "\r\n", "null", new Object[]{"comment"},
                                                                                                                                                                        new String[]{"header"}, true, true, true);
                                                                                                                                                        
                                                                                                                                                                assertEquals(',', format.getDelimiter());
                                                                                                                                                                assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
                                                                                                                                                                assertEquals(QuoteMode.ALL, format.getQuoteMode());
                                                                                                                                                                assertEquals(Character.valueOf('#'), format.getCommentMarker());
                                                                                                                                                                assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
                                                                                                                                                                assertTrue(format.getIgnoreSurroundingSpaces());
                                                                                                                                                                assertTrue(format.getIgnoreEmptyLines());
                                                                                                                                                                assertEquals("\r\n", format.getRecordSeparator());
                                                                                                                                                                assertEquals("null", format.getNullString());
                                                                                                                                                                assertArrayEquals(new String[]{"comment"}, format.getHeaderComments());
                                                                                                                                                                assertArrayEquals(new String[]{"header"}, format.getHeader());
                                                                                                                                                                assertTrue(format.getSkipHeaderRecord());
                                                                                                                                                                assertTrue(format.getAllowMissingColumnNames());
                                                                                                                                                                assertTrue(format.getIgnoreHeaderCase());
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testConstructorWithAllParameters3() throws Exception {
                                                                                                                                                                char delimiter = ',';
                                                                                                                                                                Character quoteChar = '"';
                                                                                                                                                                QuoteMode quoteMode = QuoteMode.ALL;
                                                                                                                                                                Character commentMarker = '#';
                                                                                                                                                                Character escapeChar = '\\';
                                                                                                                                                                boolean ignoreSurroundingSpaces = true;
                                                                                                                                                                boolean ignoreEmptyLines = true;
                                                                                                                                                                String recordSeparator = "\n";
                                                                                                                                                                String nullString = "NULL";
                                                                                                                                                                Object[] headerComments = new Object[]{"Comment1", "Comment2"};
                                                                                                                                                                String[] header = new String[]{"Header1", "Header2"};
                                                                                                                                                                boolean skipHeaderRecord = true;
                                                                                                                                                                boolean allowMissingColumnNames = true;
                                                                                                                                                                boolean ignoreHeaderCase = true;
                                                                                                                                                        
                                                                                                                                                                Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                                                                                                        char.class, Character.class, QuoteMode.class, Character.class, Character.class,
                                                                                                                                                                        boolean.class, boolean.class, String.class, String.class, Object[].class,
                                                                                                                                                                        String[].class, boolean.class, boolean.class, boolean.class);
                                                                                                                                                                constructor.setAccessible(true);
                                                                                                                                                                CSVFormat format = constructor.newInstance(
                                                                                                                                                                        delimiter, quoteChar, quoteMode, commentMarker, escapeChar,
                                                                                                                                                                        ignoreSurroundingSpaces, ignoreEmptyLines, recordSeparator, nullString, headerComments, header,
                                                                                                                                                                        skipHeaderRecord, allowMissingColumnNames, ignoreHeaderCase);
                                                                                                                                                        
                                                                                                                                                                assertEquals(delimiter, format.getDelimiter());
                                                                                                                                                                assertEquals(quoteChar, format.getQuoteCharacter());
                                                                                                                                                                assertEquals(quoteMode, format.getQuoteMode());
                                                                                                                                                                assertEquals(commentMarker, format.getCommentMarker());
                                                                                                                                                                assertEquals(escapeChar, format.getEscapeCharacter());
                                                                                                                                                                assertTrue(format.getIgnoreSurroundingSpaces());
                                                                                                                                                                assertTrue(format.getIgnoreEmptyLines());
                                                                                                                                                                assertEquals(recordSeparator, format.getRecordSeparator());
                                                                                                                                                                assertEquals(nullString, format.getNullString());
                                                                                                                                                                assertArrayEquals(new String[]{"Comment1", "Comment2"}, format.getHeaderComments());
                                                                                                                                                                assertArrayEquals(header, format.getHeader());
                                                                                                                                                                assertTrue(format.getSkipHeaderRecord());
                                                                                                                                                                assertTrue(format.getAllowMissingColumnNames());
                                                                                                                                                                assertTrue(format.getIgnoreHeaderCase());
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testConstructorWithNullParameters2() {
                                                                                                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                                                    .withQuote(null)
                                                                                                                                                                    .withQuoteMode(null)
                                                                                                                                                                    .withCommentMarker(null)
                                                                                                                                                                    .withEscape(null)
                                                                                                                                                                    .withRecordSeparator(null)
                                                                                                                                                                    .withNullString(null)
                                                                                                                                                                    .withHeaderComments((Object[])null)
                                                                                                                                                                    .withHeader((String[])null)
                                                                                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                                                                        
                                                                                                                                                                assertNull(format.getQuoteCharacter());
                                                                                                                                                                assertNull(format.getQuoteMode());
                                                                                                                                                                assertNull(format.getCommentMarker());
                                                                                                                                                                assertNull(format.getEscapeCharacter());
                                                                                                                                                                assertNull(format.getRecordSeparator());
                                                                                                                                                                assertNull(format.getNullString());
                                                                                                                                                                assertNull(format.getHeaderComments());
                                                                                                                                                                assertNull(format.getHeader());
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testValidateMethod1() throws Exception {
                                                                                                                                                                Method validate = CSVFormat.class.getDeclaredMethod("validate");
                                                                                                                                                                validate.setAccessible(true);
                                                                                                                                                                
                                                                                                                                                                CSVFormat validFormat = CSVFormat.DEFAULT;
                                                                                                                                                                validate.invoke(validFormat); // Should not throw
                                                                                                                                                                
                                                                                                                                                                CSVFormat invalidFormat = CSVFormat.newFormat(',')
                                                                                                                                                                    .withQuote(',')
                                                                                                                                                                    .withQuoteMode(null)
                                                                                                                                                                    .withCommentMarker(null)
                                                                                                                                                                    .withEscape(null)
                                                                                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                                                                                    .withNullString(null)
                                                                                                                                                                    .withHeaderComments(null)
                                                                                                                                                                    .withHeader((String[]) null)
                                                                                                                                                                    .withSkipHeaderRecord(false)
                                                                                                                                                                    .withAllowMissingColumnNames(false)
                                                                                                                                                                    .withIgnoreHeaderCase(false);
                                                                                                                                                                    
                                                                                                                                                                try {
                                                                                                                                                                    validate.invoke(invalidFormat);
                                                                                                                                                                    fail("Expected IllegalArgumentException");
                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                    assertTrue(e.getCause() instanceof IllegalArgumentException);
                                                                                                                                                                }
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testConstructorWithAllParameters4() {
                                                                                                                                                                char delimiter = ',';
                                                                                                                                                                Character quoteChar = '"';
                                                                                                                                                                QuoteMode quoteMode = QuoteMode.ALL;
                                                                                                                                                                Character commentStart = '#';
                                                                                                                                                                Character escape = '\\';
                                                                                                                                                                boolean ignoreSurroundingSpaces = true;
                                                                                                                                                                boolean ignoreEmptyLines = true;
                                                                                                                                                                String recordSeparator = "\n";
                                                                                                                                                                String nullString = "NULL";
                                                                                                                                                                Object[] headerComments = new Object[]{"Comment1", "Comment2"};
                                                                                                                                                                String[] header = new String[]{"Header1", "Header2"};
                                                                                                                                                                boolean skipHeaderRecord = true;
                                                                                                                                                                boolean allowMissingColumnNames = true;
                                                                                                                                                                boolean ignoreHeaderCase = true;
                                                                                                                                                            
                                                                                                                                                                CSVFormat format = CSVFormat.newFormat(delimiter)
                                                                                                                                                                    .withQuote(quoteChar)
                                                                                                                                                                    .withQuoteMode(quoteMode)
                                                                                                                                                                    .withCommentMarker(commentStart)
                                                                                                                                                                    .withEscape(escape)
                                                                                                                                                                    .withIgnoreSurroundingSpaces(ignoreSurroundingSpaces)
                                                                                                                                                                    .withIgnoreEmptyLines(ignoreEmptyLines)
                                                                                                                                                                    .withRecordSeparator(recordSeparator)
                                                                                                                                                                    .withNullString(nullString)
                                                                                                                                                                    .withHeaderComments(headerComments)
                                                                                                                                                                    .withHeader(header)
                                                                                                                                                                    .withSkipHeaderRecord(skipHeaderRecord)
                                                                                                                                                                    .withAllowMissingColumnNames(allowMissingColumnNames)
                                                                                                                                                                    .withIgnoreHeaderCase(ignoreHeaderCase);
                                                                                                                                                            
                                                                                                                                                                assertEquals(delimiter, format.getDelimiter());
                                                                                                                                                                assertEquals(quoteChar, format.getQuoteCharacter());
                                                                                                                                                                assertEquals(quoteMode, format.getQuoteMode());
                                                                                                                                                                assertEquals(commentStart, format.getCommentMarker());
                                                                                                                                                                assertEquals(escape, format.getEscapeCharacter());
                                                                                                                                                                assertEquals(ignoreSurroundingSpaces, format.getIgnoreSurroundingSpaces());
                                                                                                                                                                assertEquals(ignoreEmptyLines, format.getIgnoreEmptyLines());
                                                                                                                                                                assertEquals(recordSeparator, format.getRecordSeparator());
                                                                                                                                                                assertEquals(nullString, format.getNullString());
                                                                                                                                                                assertArrayEquals(new String[]{"Comment1", "Comment2"}, format.getHeaderComments());
                                                                                                                                                                assertArrayEquals(new String[]{"Header1", "Header2"}, format.getHeader());
                                                                                                                                                                assertEquals(skipHeaderRecord, format.getSkipHeaderRecord());
                                                                                                                                                                assertEquals(allowMissingColumnNames, format.getAllowMissingColumnNames());
                                                                                                                                                                assertEquals(ignoreHeaderCase, format.getIgnoreHeaderCase());
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testConstructorWithNullParameters3() throws Exception {
                                                                                                                                                                char delimiter = ',';
                                                                                                                                                                
                                                                                                                                                                // Get the private constructor
                                                                                                                                                                Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                                                                                                    char.class, Character.class, QuoteMode.class, Character.class, Character.class,
                                                                                                                                                                    boolean.class, boolean.class, String.class, String.class, Object[].class,
                                                                                                                                                                    String[].class, boolean.class, boolean.class, boolean.class);
                                                                                                                                                                constructor.setAccessible(true);
                                                                                                                                                                
                                                                                                                                                                // Create instance using reflection
                                                                                                                                                                CSVFormat format = constructor.newInstance(
                                                                                                                                                                    delimiter, null, null, null, null, 
                                                                                                                                                                    false, false, null, null, null,
                                                                                                                                                                    null, false, false, false);
                                                                                                                                                                
                                                                                                                                                                assertEquals(delimiter, format.getDelimiter());
                                                                                                                                                                assertNull(format.getQuoteCharacter());
                                                                                                                                                                assertNull(format.getQuoteMode());
                                                                                                                                                                assertNull(format.getCommentMarker());
                                                                                                                                                                assertNull(format.getEscapeCharacter());
                                                                                                                                                                assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                                                                                                assertFalse(format.getIgnoreEmptyLines());
                                                                                                                                                                assertNull(format.getRecordSeparator());
                                                                                                                                                                assertNull(format.getNullString());
                                                                                                                                                                assertNull(format.getHeaderComments());
                                                                                                                                                                assertNull(format.getHeader());
                                                                                                                                                                assertFalse(format.getSkipHeaderRecord());
                                                                                                                                                                assertFalse(format.getAllowMissingColumnNames());
                                                                                                                                                                assertFalse(format.getIgnoreHeaderCase());
                                                                                                                                                            }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                            public void testConstructorWithDuplicateHeaders() throws Exception {
                                                                                                                                                                CSVFormat format = CSVFormat.DEFAULT.withHeader("dup", "dup");
                                                                                                                                                            }

    @Test(expected = SQLException.class)
                                                                                                                                                            public void testWithHeaderResultSet_ThrowsSQLException() throws SQLException {
                                                                                                                                                                ResultSet resultSet = mock(ResultSet.class);
                                                                                                                                                                when(resultSet.getMetaData()).thenThrow(new SQLException("Test exception"));
                                                                                                                                                                
                                                                                                                                                                CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                                                format.withHeader(resultSet);
                                                                                                                                                            }

    @Test(expected = SQLException.class)
                                                                                                                                                            public void testWithHeaderResultSetMetaDataThrowsSQLException() throws SQLException {
                                                                                                                                                                ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                                                when(metaData.getColumnCount()).thenThrow(new SQLException());
                                                                                                                                                                CSVFormat.DEFAULT.withHeader(metaData);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testConstructorWithDuplicateHeader() throws Exception {
                                                                                                                                                                CSVFormat format = CSVFormat.DEFAULT.withAllowMissingColumnNames(true);
                                                                                                                                                                format = CSVFormat.newFormat(',')
                                                                                                                                                                        .withQuote('"')
                                                                                                                                                                        .withQuoteMode(QuoteMode.ALL)
                                                                                                                                                                        .withCommentMarker('#')
                                                                                                                                                                        .withEscape('\\')
                                                                                                                                                                        .withIgnoreEmptyLines(true)
                                                                                                                                                                        .withIgnoreSurroundingSpaces(true)
                                                                                                                                                                        .withRecordSeparator("\r\n")
                                                                                                                                                                        .withNullString("null")
                                                                                                                                                                        .withHeaderComments(new Object[]{"comment"})
                                                                                                                                                                        .withHeader("header", "header")
                                                                                                                                                                        .withAllowMissingColumnNames(true)
                                                                                                                                                                        .withIgnoreEmptyLines(true)
                                                                                                                                                                        .withIgnoreSurroundingSpaces(true);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testConstructorWithDuplicateHeader1() throws Exception {
                                                                                                                                                                Character delimiter = ',';
                                                                                                                                                                Character quoteCharacter = '"';
                                                                                                                                                                QuoteMode quoteMode = QuoteMode.ALL;
                                                                                                                                                                Character commentMarker = '#';
                                                                                                                                                                Character escapeCharacter = '\\';
                                                                                                                                                                boolean ignoreSurroundingSpaces = true;
                                                                                                                                                                boolean ignoreEmptyLines = true;
                                                                                                                                                                String recordSeparator = "\n";
                                                                                                                                                                String nullString = null;
                                                                                                                                                                String[] headerComments = null;
                                                                                                                                                                String[] header = new String[]{"dup", "dup"};
                                                                                                                                                                boolean skipHeaderRecord = false;
                                                                                                                                                                boolean allowMissingColumnNames = false;
                                                                                                                                                                boolean ignoreHeaderCase = false;
                                                                                                                                                        
                                                                                                                                                                Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                                                                                                    char.class, Character.class, QuoteMode.class, Character.class, Character.class,
                                                                                                                                                                    boolean.class, boolean.class, String.class, String.class, Object[].class,
                                                                                                                                                                    String[].class, boolean.class, boolean.class, boolean.class);
                                                                                                                                                                constructor.setAccessible(true);
                                                                                                                                                                
                                                                                                                                                                constructor.newInstance(
                                                                                                                                                                    delimiter, quoteCharacter, quoteMode, commentMarker, escapeCharacter,
                                                                                                                                                                    ignoreSurroundingSpaces, ignoreEmptyLines, recordSeparator, nullString,
                                                                                                                                                                    headerComments, header, skipHeaderRecord, allowMissingColumnNames, ignoreHeaderCase);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testConstructorWithLineBreakDelimiter3() {
                                                                                                                                                                Character quoteCharacter = null;
                                                                                                                                                                QuoteMode quoteMode = null;
                                                                                                                                                                Character commentMarker = null;
                                                                                                                                                                Character escapeCharacter = null;
                                                                                                                                                                String recordSeparator = null;
                                                                                                                                                                String nullString = null;
                                                                                                                                                                Object[] headerComments = null;
                                                                                                                                                                String[] header = null;
                                                                                                                                                                
                                                                                                                                                                // Use reflection to access private constructor
                                                                                                                                                                try {
                                                                                                                                                                    java.lang.reflect.Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                                                                                                        char.class, Character.class, QuoteMode.class, Character.class, Character.class,
                                                                                                                                                                        boolean.class, boolean.class, String.class, String.class, Object[].class,
                                                                                                                                                                        String[].class, boolean.class, boolean.class, boolean.class);
                                                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                                                    constructor.newInstance(
                                                                                                                                                                        '\n', quoteCharacter, quoteMode, commentMarker, escapeCharacter,
                                                                                                                                                                        false, false, recordSeparator, nullString, headerComments, header,
                                                                                                                                                                        false, false, false);
                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                    throw new RuntimeException(e);
                                                                                                                                                                }
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testConstructorWithEscapeSameAsDelimiter() throws Exception {
                                                                                                                                                                Character delimiter = ',';
                                                                                                                                                                Character quoteCharacter = null;
                                                                                                                                                                QuoteMode quoteMode = null;
                                                                                                                                                                Character commentMarker = null;
                                                                                                                                                                Character escapeCharacter = ',';
                                                                                                                                                                boolean ignoreSurroundingSpaces = false;
                                                                                                                                                                boolean ignoreEmptyLines = false;
                                                                                                                                                                String recordSeparator = null;
                                                                                                                                                                String nullString = null;
                                                                                                                                                                Object[] headerComments = null;
                                                                                                                                                                String[] header = null;
                                                                                                                                                                boolean skipHeaderRecord = false;
                                                                                                                                                                boolean allowMissingColumnNames = false;
                                                                                                                                                                boolean ignoreHeaderCase = false;
                                                                                                                                                                
                                                                                                                                                                Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                                                                                                    char.class, Character.class, QuoteMode.class, Character.class, Character.class,
                                                                                                                                                                    boolean.class, boolean.class, String.class, String.class, Object[].class,
                                                                                                                                                                    String[].class, boolean.class, boolean.class, boolean.class);
                                                                                                                                                                constructor.setAccessible(true);
                                                                                                                                                                constructor.newInstance(
                                                                                                                                                                    delimiter, quoteCharacter, quoteMode, commentMarker, escapeCharacter,
                                                                                                                                                                    ignoreSurroundingSpaces, ignoreEmptyLines, recordSeparator, nullString,
                                                                                                                                                                    headerComments, header, skipHeaderRecord, allowMissingColumnNames, ignoreHeaderCase);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testConstructorWithEscapeSameAsCommentMarker() throws Exception {
                                                                                                                                                                Character delimiter = ',';
                                                                                                                                                                Character quoteCharacter = null;
                                                                                                                                                                QuoteMode quoteMode = null;
                                                                                                                                                                Character escapeCharacter = '\\';
                                                                                                                                                                Character commentMarker = '\\';
                                                                                                                                                                boolean ignoreSurroundingSpaces = false;
                                                                                                                                                                boolean ignoreEmptyLines = false;
                                                                                                                                                                String recordSeparator = null;
                                                                                                                                                                String nullString = null;
                                                                                                                                                                Object[] headerComments = null;
                                                                                                                                                                String[] header = null;
                                                                                                                                                                boolean skipHeaderRecord = false;
                                                                                                                                                                boolean allowMissingColumnNames = false;
                                                                                                                                                                boolean ignoreHeaderCase = false;
                                                                                                                                                                
                                                                                                                                                                Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                                                                                                    char.class, Character.class, QuoteMode.class, Character.class, Character.class,
                                                                                                                                                                    boolean.class, boolean.class, String.class, String.class, Object[].class,
                                                                                                                                                                    String[].class, boolean.class, boolean.class, boolean.class);
                                                                                                                                                                constructor.setAccessible(true);
                                                                                                                                                                
                                                                                                                                                                CSVFormat format = constructor.newInstance(
                                                                                                                                                                    delimiter, quoteCharacter, quoteMode, commentMarker, 
                                                                                                                                                                    escapeCharacter, ignoreSurroundingSpaces, ignoreEmptyLines, recordSeparator, 
                                                                                                                                                                    nullString, headerComments, header, skipHeaderRecord, allowMissingColumnNames, 
                                                                                                                                                                    ignoreHeaderCase);
                                                                                                                                                            }

    @Test
                                                                                                                                                        public void testConstructorWithAllParameters5() throws Exception {
                                                                                                                                                            char delimiter = ',';
                                                                                                                                                            Character quoteChar = '"';
                                                                                                                                                            QuoteMode quoteMode = QuoteMode.ALL;
                                                                                                                                                            Character commentMarker = '#';
                                                                                                                                                            Character escapeChar = '\\';
                                                                                                                                                            boolean ignoreSurroundingSpaces = true;
                                                                                                                                                            boolean ignoreEmptyLines = true;
                                                                                                                                                            String recordSeparator = "\n";
                                                                                                                                                            String nullString = "NULL";
                                                                                                                                                            Object[] headerComments = new Object[]{"Comment1", "Comment2"};
                                                                                                                                                            String[] header = new String[]{"Header1", "Header2"};
                                                                                                                                                            boolean skipHeaderRecord = true;
                                                                                                                                                            boolean allowMissingColumnNames = true;
                                                                                                                                                            boolean ignoreHeaderCase = true;
                                                                                                                                                    
                                                                                                                                                            // Use reflection to access private constructor
                                                                                                                                                            Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                                                                                                char.class, Character.class, QuoteMode.class, Character.class, Character.class,
                                                                                                                                                                boolean.class, boolean.class, String.class, String.class, Object[].class,
                                                                                                                                                                String[].class, boolean.class, boolean.class, boolean.class
                                                                                                                                                            );
                                                                                                                                                            constructor.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            CSVFormat format = constructor.newInstance(
                                                                                                                                                                delimiter, quoteChar, quoteMode, commentMarker, escapeChar,
                                                                                                                                                                ignoreSurroundingSpaces, ignoreEmptyLines, recordSeparator, nullString,
                                                                                                                                                                headerComments, header, skipHeaderRecord, allowMissingColumnNames, ignoreHeaderCase
                                                                                                                                                            );
                                                                                                                                                    
                                                                                                                                                            assertEquals(delimiter, format.getDelimiter());
                                                                                                                                                            assertEquals(quoteChar, format.getQuoteCharacter());
                                                                                                                                                            assertEquals(quoteMode, format.getQuoteMode());
                                                                                                                                                            assertEquals(commentMarker, format.getCommentMarker());
                                                                                                                                                            assertEquals(escapeChar, format.getEscapeCharacter());
                                                                                                                                                            assertTrue(format.getIgnoreSurroundingSpaces());
                                                                                                                                                            assertTrue(format.getIgnoreEmptyLines());
                                                                                                                                                            assertEquals(recordSeparator, format.getRecordSeparator());
                                                                                                                                                            assertEquals(nullString, format.getNullString());
                                                                                                                                                            assertArrayEquals(new String[]{"Comment1", "Comment2"}, format.getHeaderComments());
                                                                                                                                                            assertArrayEquals(header, format.getHeader());
                                                                                                                                                            assertTrue(format.getSkipHeaderRecord());
                                                                                                                                                            assertTrue(format.getAllowMissingColumnNames());
                                                                                                                                                            assertTrue(format.getIgnoreHeaderCase());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testConstructorWithNullParameters4() {
                                                                                                                                                            CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                                                .withQuote((Character) null)
                                                                                                                                                                .withQuoteMode(null)
                                                                                                                                                                .withCommentMarker(null)
                                                                                                                                                                .withEscape(null)
                                                                                                                                                                .withRecordSeparator(null)
                                                                                                                                                                .withNullString(null)
                                                                                                                                                                .withHeaderComments((Object[]) null)
                                                                                                                                                                .withHeader((String[]) null)
                                                                                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                                                                                .withIgnoreEmptyLines(false)
                                                                                                                                                                .withSkipHeaderRecord(false)
                                                                                                                                                                .withAllowMissingColumnNames(false)
                                                                                                                                                                .withIgnoreHeaderCase(false);
                                                                                                                                                    
                                                                                                                                                            assertNull(format.getQuoteCharacter());
                                                                                                                                                            assertNull(format.getQuoteMode());
                                                                                                                                                            assertNull(format.getCommentMarker());
                                                                                                                                                            assertNull(format.getEscapeCharacter());
                                                                                                                                                            assertNull(format.getRecordSeparator());
                                                                                                                                                            assertNull(format.getNullString());
                                                                                                                                                            assertNull(format.getHeaderComments());
                                                                                                                                                            assertNull(format.getHeader());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testConstructorWithResultSetMetaData() throws Exception {
                                                                                                                                                            ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                                            when(metaData.getColumnCount()).thenReturn(2);
                                                                                                                                                            when(metaData.getColumnLabel(1)).thenReturn("Column1");
                                                                                                                                                            when(metaData.getColumnLabel(2)).thenReturn("Column2");
                                                                                                                                                            
                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                                                .withDelimiter(',')
                                                                                                                                                                .withQuote('"')
                                                                                                                                                                .withQuoteMode(QuoteMode.ALL)
                                                                                                                                                                .withCommentMarker('#')
                                                                                                                                                                .withEscape('\\')
                                                                                                                                                                .withIgnoreSurroundingSpaces(true)
                                                                                                                                                                .withIgnoreEmptyLines(true)
                                                                                                                                                                .withRecordSeparator("\n")
                                                                                                                                                                .withNullString("NULL")
                                                                                                                                                                .withSkipHeaderRecord(false)
                                                                                                                                                                .withAllowMissingColumnNames(false)
                                                                                                                                                                .withIgnoreHeaderCase(false)
                                                                                                                                                                .withHeader(metaData);
                                                                                                                                                            
                                                                                                                                                            assertArrayEquals(new String[]{"Column1", "Column2"}, format.getHeader());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testConstructorWithAllParameters6() {
                                                                                                                                                            char delimiter = ',';
                                                                                                                                                            Character quoteChar = '"';
                                                                                                                                                            QuoteMode quoteMode = QuoteMode.ALL;
                                                                                                                                                            Character commentStart = '#';
                                                                                                                                                            Character escape = '\\';
                                                                                                                                                            boolean ignoreSurroundingSpaces = true;
                                                                                                                                                            boolean ignoreEmptyLines = true;
                                                                                                                                                            String recordSeparator = "\n";
                                                                                                                                                            String nullString = "NULL";
                                                                                                                                                            Object[] headerComments = new Object[]{"Comment1", "Comment2"};
                                                                                                                                                            String[] header = new String[]{"Header1", "Header2"};
                                                                                                                                                            boolean skipHeaderRecord = true;
                                                                                                                                                            boolean allowMissingColumnNames = true;
                                                                                                                                                            boolean ignoreHeaderCase = true;
                                                                                                                                                    
                                                                                                                                                            CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                                                .withDelimiter(delimiter)
                                                                                                                                                                .withQuote(quoteChar)
                                                                                                                                                                .withQuoteMode(quoteMode)
                                                                                                                                                                .withCommentMarker(commentStart)
                                                                                                                                                                .withEscape(escape)
                                                                                                                                                                .withIgnoreSurroundingSpaces(ignoreSurroundingSpaces)
                                                                                                                                                                .withIgnoreEmptyLines(ignoreEmptyLines)
                                                                                                                                                                .withRecordSeparator(recordSeparator)
                                                                                                                                                                .withNullString(nullString)
                                                                                                                                                                .withHeaderComments(headerComments)
                                                                                                                                                                .withHeader(header)
                                                                                                                                                                .withSkipHeaderRecord(skipHeaderRecord)
                                                                                                                                                                .withAllowMissingColumnNames(allowMissingColumnNames)
                                                                                                                                                                .withIgnoreHeaderCase(ignoreHeaderCase);
                                                                                                                                                    
                                                                                                                                                            assertEquals(delimiter, format.getDelimiter());
                                                                                                                                                            assertEquals(quoteChar, format.getQuoteCharacter());
                                                                                                                                                            assertEquals(quoteMode, format.getQuoteMode());
                                                                                                                                                            assertEquals(commentStart, format.getCommentMarker());
                                                                                                                                                            assertEquals(escape, format.getEscapeCharacter());
                                                                                                                                                            assertEquals(ignoreSurroundingSpaces, format.getIgnoreSurroundingSpaces());
                                                                                                                                                            assertEquals(ignoreEmptyLines, format.getIgnoreEmptyLines());
                                                                                                                                                            assertEquals(recordSeparator, format.getRecordSeparator());
                                                                                                                                                            assertEquals(nullString, format.getNullString());
                                                                                                                                                            assertArrayEquals(new String[]{"Comment1", "Comment2"}, format.getHeaderComments());
                                                                                                                                                            assertArrayEquals(new String[]{"Header1", "Header2"}, format.getHeader());
                                                                                                                                                            assertEquals(skipHeaderRecord, format.getSkipHeaderRecord());
                                                                                                                                                            assertEquals(allowMissingColumnNames, format.getAllowMissingColumnNames());
                                                                                                                                                            assertEquals(ignoreHeaderCase, format.getIgnoreHeaderCase());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testConstructorWithNullParameters5() {
                                                                                                                                                            char delimiter = ',';
                                                                                                                                                            Character quoteCharacter = null;
                                                                                                                                                            QuoteMode quoteMode = null;
                                                                                                                                                            Character commentMarker = null;
                                                                                                                                                            Character escapeCharacter = null;
                                                                                                                                                            boolean ignoreSurroundingSpaces = false;
                                                                                                                                                            boolean ignoreEmptyLines = false;
                                                                                                                                                            String recordSeparator = null;
                                                                                                                                                            String nullString = null;
                                                                                                                                                            Object[] headerComments = null;
                                                                                                                                                            String[] header = null;
                                                                                                                                                            boolean skipHeaderRecord = false;
                                                                                                                                                            boolean allowMissingColumnNames = false;
                                                                                                                                                            boolean ignoreHeaderCase = false;
                                                                                                                                                            
                                                                                                                                                            CSVFormat format = CSVFormat.newFormat(delimiter)
                                                                                                                                                                .withQuote(quoteCharacter)
                                                                                                                                                                .withQuoteMode(quoteMode)
                                                                                                                                                                .withCommentMarker(commentMarker)
                                                                                                                                                                .withEscape(escapeCharacter)
                                                                                                                                                                .withIgnoreSurroundingSpaces(ignoreSurroundingSpaces)
                                                                                                                                                                .withIgnoreEmptyLines(ignoreEmptyLines)
                                                                                                                                                                .withRecordSeparator(recordSeparator)
                                                                                                                                                                .withNullString(nullString)
                                                                                                                                                                .withHeaderComments(headerComments)
                                                                                                                                                                .withHeader(header)
                                                                                                                                                                .withSkipHeaderRecord(skipHeaderRecord)
                                                                                                                                                                .withAllowMissingColumnNames(allowMissingColumnNames)
                                                                                                                                                                .withIgnoreHeaderCase(ignoreHeaderCase);
                                                                                                                                                            
                                                                                                                                                            assertEquals(delimiter, format.getDelimiter());
                                                                                                                                                            assertNull(format.getQuoteCharacter());
                                                                                                                                                            assertNull(format.getQuoteMode());
                                                                                                                                                            assertNull(format.getCommentMarker());
                                                                                                                                                            assertNull(format.getEscapeCharacter());
                                                                                                                                                            assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                                                                                            assertFalse(format.getIgnoreEmptyLines());
                                                                                                                                                            assertNull(format.getRecordSeparator());
                                                                                                                                                            assertNull(format.getNullString());
                                                                                                                                                            assertNull(format.getHeaderComments());
                                                                                                                                                            assertNull(format.getHeader());
                                                                                                                                                            assertFalse(format.getSkipHeaderRecord());
                                                                                                                                                            assertFalse(format.getAllowMissingColumnNames());
                                                                                                                                                            assertFalse(format.getIgnoreHeaderCase());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testConstructorWithResultSet() throws Exception {
                                                                                                                                                            ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                                            ResultSet resultSet = mock(ResultSet.class);
                                                                                                                                                            
                                                                                                                                                            when(resultSet.getMetaData()).thenReturn(metaData);
                                                                                                                                                            when(metaData.getColumnCount()).thenReturn(2);
                                                                                                                                                            when(metaData.getColumnLabel(1)).thenReturn("Col1");
                                                                                                                                                            when(metaData.getColumnLabel(2)).thenReturn("Col2");
                                                                                                                                                            
                                                                                                                                                            Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                                                                                                char.class, Character.class, QuoteMode.class, Character.class, 
                                                                                                                                                                Character.class, boolean.class, boolean.class, String.class, 
                                                                                                                                                                String.class, Object[].class, String[].class, boolean.class, 
                                                                                                                                                                boolean.class, boolean.class);
                                                                                                                                                            constructor.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            CSVFormat result = constructor.newInstance(
                                                                                                                                                                ',', '"', QuoteMode.ALL, '#', '\\', true, true, "\r\n", "NULL", 
                                                                                                                                                                new Object[]{"Comment"}, new String[]{"Col1", "Col2"}, true, true, true);
                                                                                                                                                            
                                                                                                                                                            assertNotNull(result);
                                                                                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                        public void testConstructorWithSameDelimiterAndQuote() {
                                                                                                                                                            CSVFormat.newFormat(',').withQuote(',').withQuoteMode(QuoteMode.MINIMAL);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testConstructorWithQuoteCharSameAsCommentMarker() {
                                                                                                                                                            char delimiter = ',';
                                                                                                                                                            Character quoteCharacter = '"';
                                                                                                                                                            QuoteMode quoteMode = null;
                                                                                                                                                            Character commentMarker = '"';
                                                                                                                                                            Character escapeCharacter = null;
                                                                                                                                                            boolean ignoreSurroundingSpaces = false;
                                                                                                                                                            boolean ignoreEmptyLines = false;
                                                                                                                                                            String recordSeparator = null;
                                                                                                                                                            String nullString = null;
                                                                                                                                                            Object[] headerComments = null;
                                                                                                                                                            String[] header = null;
                                                                                                                                                            boolean skipHeaderRecord = false;
                                                                                                                                                            boolean allowMissingColumnNames = false;
                                                                                                                                                            boolean ignoreHeaderCase = false;
                                                                                                                                                            
                                                                                                                                                            // Using reflection to access private constructor
                                                                                                                                                            try {
                                                                                                                                                                java.lang.reflect.Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                                                                                                    char.class, Character.class, QuoteMode.class, Character.class, Character.class,
                                                                                                                                                                    boolean.class, boolean.class, String.class, String.class, Object[].class,
                                                                                                                                                                    String[].class, boolean.class, boolean.class, boolean.class);
                                                                                                                                                                constructor.setAccessible(true);
                                                                                                                                                                constructor.newInstance(delimiter, quoteCharacter, quoteMode, commentMarker, escapeCharacter,
                                                                                                                                                                    ignoreSurroundingSpaces, ignoreEmptyLines, recordSeparator, nullString, 
                                                                                                                                                                    headerComments, header, skipHeaderRecord, allowMissingColumnNames, ignoreHeaderCase);
                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                throw new RuntimeException(e);
                                                                                                                                                            }
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testConstructorWithSameDelimiterAndComment1() {
                                                                                                                                                            CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                                                .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                                                .withCommentMarker(',')
                                                                                                                                                                .withIgnoreEmptyLines(false)
                                                                                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                                                                                .withAllowMissingColumnNames(false);
                                                                                                                                                        }

    @Test
                                                                                                                                                public void testConstructorWithResultSet1() throws Exception {
                                                                                                                                                    ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                                    ResultSet resultSet = mock(ResultSet.class);
                                                                                                                                                    
                                                                                                                                                    when(resultSet.getMetaData()).thenReturn(metaData);
                                                                                                                                                    when(metaData.getColumnCount()).thenReturn(2);
                                                                                                                                                    when(metaData.getColumnLabel(1)).thenReturn("Col1");
                                                                                                                                                    when(metaData.getColumnLabel(2)).thenReturn("Col2");
                                                                                                                                                    
                                                                                                                                                    Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                                                                                        char.class, Character.class, QuoteMode.class, Character.class, 
                                                                                                                                                        Character.class, boolean.class, boolean.class, String.class, 
                                                                                                                                                        String.class, Object[].class, String[].class, boolean.class, 
                                                                                                                                                        boolean.class, boolean.class);
                                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    CSVFormat result = constructor.newInstance(
                                                                                                                                                        ',', '"', QuoteMode.ALL, '#', '\\', true, true, "\r\n", "NULL", 
                                                                                                                                                        new Object[]{"Comment"}, new String[]{"Col1", "Col2"}, true, true, true);
                                                                                                                                                    
                                                                                                                                                    assertNotNull(result);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testConstructorWithLineBreakDelimiter4() throws Exception {
                                                                                                                                                    Character quoteCharacter = null;
                                                                                                                                                    QuoteMode quoteMode = null;
                                                                                                                                                    Character commentMarker = null;
                                                                                                                                                    Character escapeCharacter = null;
                                                                                                                                                    String recordSeparator = null;
                                                                                                                                                    String nullString = null;
                                                                                                                                                    Object[] headerComments = null;
                                                                                                                                                    String[] header = null;
                                                                                                                                                    
                                                                                                                                                    Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                                                                                        char.class, Character.class, QuoteMode.class, Character.class, Character.class,
                                                                                                                                                        boolean.class, boolean.class, String.class, String.class, Object[].class,
                                                                                                                                                        String[].class, boolean.class, boolean.class, boolean.class);
                                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                                    constructor.newInstance('\n', quoteCharacter, quoteMode, commentMarker, escapeCharacter, 
                                                                                                                                                        false, false, recordSeparator, nullString, headerComments, header, 
                                                                                                                                                        false, false, false);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testValidateWithValidFormat() throws Exception {
                                                                                                                                                    String[] header = {"name", "age", "city"};
                                                                                                                                                    Method validateMethod = CSVFormat.class.getDeclaredMethod("validate");
                                                                                                                                                    validateMethod.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    CSVFormat goodFormat = CSVFormat.newFormat(',')
                                                                                                                                                        .withQuote('"')
                                                                                                                                                        .withQuoteMode(QuoteMode.ALL)
                                                                                                                                                        .withCommentMarker('#')
                                                                                                                                                        .withEscape('\\')
                                                                                                                                                        .withIgnoreEmptyLines(false)
                                                                                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                                                                                        .withRecordSeparator("\n")
                                                                                                                                                        .withNullString(null)
                                                                                                                                                        .withHeader(header)
                                                                                                                                                        .withSkipHeaderRecord(false)
                                                                                                                                                        .withAllowMissingColumnNames(false);
                                                                                                                                                        
                                                                                                                                                    validateMethod.invoke(goodFormat); // Should not throw exception
                                                                                                                                                }

    @Test
                                                                                                                                    public void testConstructorWithSameDelimiterAndQuote1() {
                                                                                                                                        try {
                                                                                                                                            java.lang.reflect.Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                                                                                char.class, Character.class, QuoteMode.class, Character.class, Character.class, 
                                                                                                                                                boolean.class, boolean.class, String.class, String.class, Object[].class, 
                                                                                                                                                String[].class, boolean.class, boolean.class, boolean.class);
                                                                                                                                            constructor.setAccessible(true);
                                                                                                                                            constructor.newInstance(',', ',', QuoteMode.MINIMAL, null, null, false, false, null, null, null, null, false, false, false);
                                                                                                                                        } catch (Exception e) {
                                                                                                                                            throw new RuntimeException(e);
                                                                                                                                        }
                                                                                                                                    }

    @Test
                                                                                                            public void testValidateWithEmptyHeader() throws Exception {
                                                                                                                String[] header = {};
                                                                                                                Method validateMethod = CSVFormat.class.getDeclaredMethod("validate");
                                                                                                                validateMethod.setAccessible(true);
                                                                                                                
                                                                                                                QuoteMode quoteMode = QuoteMode.ALL;
                                                                                                                
                                                                                                                CSVFormat goodFormat = CSVFormat.newFormat(',')
                                                                                                                    .withQuote('"')
                                                                                                                    .withQuoteMode(quoteMode)
                                                                                                                    .withCommentMarker('#')
                                                                                                                    .withEscape('\\')
                                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                                    .withRecordSeparator("\n")
                                                                                                                    .withNullString(null)
                                                                                                                    .withHeader(header)
                                                                                                                    .withSkipHeaderRecord(false)
                                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                                    
                                                                                                                validateMethod.invoke(goodFormat); // Should not throw exception
                                                                                                            }

    @Test
                                                                                            public void testConstructorWithDuplicateHeaders1() {
                                                                                                CSVFormat.newFormat(',')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withIgnoreHeaderCase(false)
                                                                                                    .withRecordSeparator("\n")
                                                                                                    .withHeader("Col1", "Col1")
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                            }

    @Test
                                                                                            public void testConstructorWithDuplicateHeaders2() {
                                                                                                CSVFormat.newFormat(',')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withIgnoreHeaderCase(false)
                                                                                                    .withRecordSeparator("\n")
                                                                                                    .withHeader("Col1", "Col1")
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                            }

    @Test
                                                                                        public void testConstructorWithLineBreakDelimiter5() {
                                                                                            Character quoteCharacter = null;
                                                                                            QuoteMode quoteMode = QuoteMode.MINIMAL;
                                                                                            Character commentMarker = null;
                                                                                            Character escapeCharacter = null;
                                                                                            String recordSeparator = "\n";
                                                                                            String nullString = null;
                                                                                            Object[] headerComments = new Object[0];
                                                                                            String[] header = new String[0];
                                                                                            
                                                                                            CSVFormat.newFormat('\n')
                                                                                                .withQuote(quoteCharacter)
                                                                                                .withQuoteMode(quoteMode)
                                                                                                .withCommentMarker(commentMarker)
                                                                                                .withEscape(escapeCharacter)
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withRecordSeparator(recordSeparator)
                                                                                                .withNullString(nullString)
                                                                                                .withHeaderComments(headerComments)
                                                                                                .withHeader(header)
                                                                                                .withSkipHeaderRecord(false)
                                                                                                .withAllowMissingColumnNames(false);
                                                                                        }

    @Test
                                                                                        public void testConstructorWithSameQuoteAndComment() throws Exception {
                                                                                        }

    @Test
                                                                                        public void testGetHeaderCommentsWithEmptyArray() {
                                                                                            String[] comments = {};
                                                                                            Character delimiter = ',';
                                                                                            Character commentMarker = null;
                                                                                            Character quote = null;
                                                                                            Character escape = null;
                                                                                            
                                                                                            CSVFormat format = CSVFormat.newFormat(delimiter)
                                                                                                .withCommentMarker(commentMarker);
                                                                                            
                                                                                            String[] result = format.getHeaderComments();
                                                                                            assertNotNull(result);
                                                                                            assertEquals(0, result.length);
                                                                                        }

    @Test
                                                                                        public void testPrint() throws IOException {
                                                                                            StringWriter out = new StringWriter();
                                                                                            CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                            CSVPrinter printer = csvFormat.print(out);
                                                                                            assertNotNull(printer);
                                                                                        }

    @Test
                                                                                        public void testPrintWithNullString() throws IOException {
                                                                                            StringWriter out = new StringWriter();
                                                                                            CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                            CSVFormat formatWithNullString = csvFormat.withNullString("NULL");
                                                                                            CSVPrinter printer = formatWithNullString.print(out);
                                                                                            assertNotNull(printer);
                                                                                        }

    @Test
                                                                                        public void testPrintWithQuote() throws IOException {
                                                                                            StringWriter out = new StringWriter();
                                                                                            CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                            CSVFormat formatWithQuote = csvFormat.withQuote('\'');
                                                                                            CSVPrinter printer = formatWithQuote.print(out);
                                                                                            assertNotNull(printer);
                                                                                        }

    @Test
                                                                                        public void testPrintWithDifferentDelimiter() throws IOException {
                                                                                            StringWriter out = new StringWriter();
                                                                                            CSVFormat csvFormat = CSVFormat.newFormat(',');
                                                                                            CSVFormat formatWithDelimiter = csvFormat.withDelimiter(';');
                                                                                            CSVPrinter printer = formatWithDelimiter.print(out);
                                                                                            assertNotNull(printer);
                                                                                        }

    @Test
                                                                                        public void testPrintWithHeader() throws IOException {
                                                                                            StringWriter out = new StringWriter();
                                                                                            CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                            String[] headers = {"Name", "Age", "City"};
                                                                                            CSVFormat formatWithHeader = csvFormat.withHeader(headers);
                                                                                            CSVPrinter printer = new CSVPrinter(out, formatWithHeader);
                                                                                            assertNotNull(printer);
                                                                                        }

    @Test
                                                                                        public void testPrintWithEmptyFormat() throws IOException {
                                                                                            StringWriter out = new StringWriter();
                                                                                            CSVFormat emptyFormat = CSVFormat.newFormat(',');
                                                                                            CSVPrinter printer = emptyFormat.print(out);
                                                                                            assertNotNull(printer);
                                                                                        }

    @Test
                                                                                        public void testPrintWithRecordSeparator() throws IOException {
                                                                                            StringWriter out = new StringWriter();
                                                                                            CSVFormat csvFormat = CSVFormat.newFormat(',');
                                                                                            CSVFormat formatWithSeparator = csvFormat.withRecordSeparator("\n");
                                                                                            CSVPrinter printer = formatWithSeparator.print(out);
                                                                                            assertNotNull(printer);
                                                                                        }

    @Test
                                                                                        public void testPrintWithCommentMarker() throws IOException {
                                                                                            StringWriter out = new StringWriter();
                                                                                            CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                            CSVFormat formatWithComment = csvFormat.withCommentMarker('#');
                                                                                            CSVPrinter printer = new CSVPrinter(out, formatWithComment);
                                                                                            assertNotNull(printer);
                                                                                        }

    @Test
                                                                                        public void testPrintWithEscape() throws IOException {
                                                                                            CSVFormat csvFormat = CSVFormat.newFormat(',').withQuote('"')
                                                                                                .withRecordSeparator("\n").withIgnoreEmptyLines();
                                                                                            StringWriter out = new StringWriter();
                                                                                            CSVFormat formatWithEscape = csvFormat.withEscape('\\');
                                                                                            CSVPrinter printer = new CSVPrinter(out, formatWithEscape);
                                                                                            assertNotNull(printer);
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testValidateWithLineBreakDelimiter() throws Exception {
                                                                                            Method validateMethod = CSVFormat.class.getDeclaredMethod("validate");
                                                                                            validateMethod.setAccessible(true);
                                                                                            
                                                                                            CSVFormat badFormat = CSVFormat.newFormat('\n')
                                                                                                .withQuote(null)
                                                                                                .withQuoteMode(null)
                                                                                                .withEscape(null)
                                                                                                .withCommentMarker(null)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withNullString(null)
                                                                                                .withRecordSeparator(null)
                                                                                                .withHeader((String[]) null)
                                                                                                .withSkipHeaderRecord(false)
                                                                                                .withAllowMissingColumnNames(false);
                                                                                                
                                                                                            validateMethod.invoke(badFormat);
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testValidateWithEscapeSameAsComment() throws Exception {
                                                                                            Method validateMethod = CSVFormat.class.getDeclaredMethod("validate");
                                                                                            validateMethod.setAccessible(true);
                                                                                            
                                                                                            CSVFormat badFormat = CSVFormat.newFormat(',')
                                                                                                .withQuote('a')
                                                                                                .withEscape('a')
                                                                                                .withCommentMarker('a')
                                                                                                .withQuoteMode(QuoteMode.ALL)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withNullString(null)
                                                                                                .withRecordSeparator(null)
                                                                                                .withHeader((String[]) null)
                                                                                                .withSkipHeaderRecord(false)
                                                                                                .withAllowMissingColumnNames(false);
                                                                                                
                                                                                            validateMethod.invoke(badFormat);
                                                                                        }

    @Test
                                                                                        public void testConstructorWithSameQuoteAndComment1() throws Exception {
                                                                                        }

    @Test
                                                public void testConstructorWithLineBreakDelimiter6() {
                                                    CSVFormat format = CSVFormat.newFormat('\n')
                                                        .withQuote('"')
                                                        .withQuoteMode(QuoteMode.ALL)
                                                        .withEscape('\\')
                                                        .withIgnoreSurroundingSpaces(true)
                                                        .withIgnoreEmptyLines(true)
                                                        .withRecordSeparator("\n")
                                                        .withNullString("NULL")
                                                        .withSkipHeaderRecord(false)
                                                        .withAllowMissingColumnNames(false);
                                                }

    @Test
                                                public void testConstructorWithLineBreakDelimiter7() {
                                                    CSVFormat format = CSVFormat.newFormat('\n')
                                                        .withQuote('"')
                                                        .withQuoteMode(QuoteMode.ALL)
                                                        .withEscape('\\')
                                                        .withIgnoreSurroundingSpaces(true)
                                                        .withIgnoreEmptyLines(true)
                                                        .withRecordSeparator("\n")
                                                        .withNullString("NULL")
                                                        .withSkipHeaderRecord(false)
                                                        .withAllowMissingColumnNames(false);
                                                }

    @Test
                                                public void testConstructorWithLineBreakDelimiter8() {
                                                    CSVFormat format = CSVFormat.newFormat('\n')
                                                        .withQuote('"')
                                                        .withQuoteMode(QuoteMode.ALL)
                                                        .withEscape('\\')
                                                        .withIgnoreSurroundingSpaces(true)
                                                        .withIgnoreEmptyLines(true)
                                                        .withRecordSeparator("\n")
                                                        .withNullString("NULL")
                                                        .withSkipHeaderRecord(false)
                                                        .withAllowMissingColumnNames(false);
                                                }

    @Test
                                                public void testConstructorWithLineBreakDelimiter9() {
                                                    CSVFormat format = CSVFormat.newFormat('\n')
                                                        .withQuote('"')
                                                        .withQuoteMode(QuoteMode.ALL)
                                                        .withEscape('\\')
                                                        .withIgnoreSurroundingSpaces(true)
                                                        .withIgnoreEmptyLines(true)
                                                        .withRecordSeparator("\n")
                                                        .withNullString("NULL")
                                                        .withSkipHeaderRecord(false)
                                                        .withAllowMissingColumnNames(false);
                                                }

    @Test
                                                public void testConstructorWithResultSetMetaData1() throws Exception {
                                                    ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                    when(metaData.getColumnCount()).thenReturn(2);
                                                    when(metaData.getColumnLabel(1)).thenReturn("Column1");
                                                    when(metaData.getColumnLabel(2)).thenReturn("Column2");
                                                    
                                                    CSVFormat format = CSVFormat.DEFAULT
                                                            .withDelimiter(',')
                                                            .withQuote('"')
                                                            .withEscape('\\')
                                                            .withIgnoreEmptyLines(true)
                                                            .withIgnoreSurroundingSpaces(true)
                                                            .withRecordSeparator("\n")
                                                            .withNullString("NULL")
                                                            .withHeader(metaData);
                                                    
                                                    assertArrayEquals(new String[]{"Column1", "Column2"}, format.getHeader());
                                                }

    @Test
                                                public void testGetHeaderCommentsWhenNull() {
                                                    CSVFormat format = CSVFormat.newFormat(',')
                                                        .withQuote(null)
                                                        .withQuoteMode(null)
                                                        .withCommentMarker(null)
                                                        .withEscape(null)
                                                        .withIgnoreSurroundingSpaces(false)
                                                        .withIgnoreEmptyLines(false)
                                                        .withRecordSeparator(null)
                                                        .withNullString(null)
                                                        .withHeaderComments((Object[])null)
                                                        .withHeader((String[])null)
                                                        .withSkipHeaderRecord(false);
                                                    assertNull(format.getHeaderComments());
                                                }

    @Test
                                                public void testValidateWithNullHeader() throws Exception {
                                                    CSVFormat goodFormat = CSVFormat.newFormat(',')
                                                        .withSkipHeaderRecord(false)
                                                        .withAllowMissingColumnNames(false);
                                                        
                                                    Method validateMethod = CSVFormat.class.getDeclaredMethod("validate");
                                                    validateMethod.setAccessible(true);
                                                    validateMethod.invoke(goodFormat); // Should not throw exception
                                                }

    @Test
                                        public void testParse() throws IOException {
                                            CSVFormat csvFormat = CSVFormat.newFormat(',')
                                                .withQuote('"')
                                                .withRecordSeparator("\r\n")
                                                .withIgnoreEmptyLines(true);
                                            assertNotNull(csvFormat);
                                        }

    @Test
                                        public void testParseWithCustomFormat() throws IOException {
                                            CSVFormat customFormat = CSVFormat.DEFAULT.withDelimiter(';');
                                            assertNotNull(customFormat);
                                        }

    @Test
        public void testConstructorWithResultSet2() throws Exception {
            ResultSet resultSet = mock(ResultSet.class);
            ResultSetMetaData metaData = mock(ResultSetMetaData.class);
            when(resultSet.getMetaData()).thenReturn(metaData);
            when(metaData.getColumnCount()).thenReturn(2);
            when(metaData.getColumnLabel(1)).thenReturn("Column1");
            when(metaData.getColumnLabel(2)).thenReturn("Column2");
            
            CSVFormat format = CSVFormat.DEFAULT
                .withDelimiter(',')
                .withQuote('"')
                .withQuoteMode(QuoteMode.ALL)
                .withEscape('\\')
                .withIgnoreSurroundingSpaces(true)
                .withIgnoreEmptyLines(true)
                .withRecordSeparator("\n")
                .withNullString("NULL")
                .withSkipHeaderRecord(false)
                .withHeader(resultSet);
            
            assertArrayEquals(new String[]{"Column1", "Column2"}, format.getHeader());
        }

    @Test
        public void testParseWithDifferentFormats() throws IOException {
            String input = "header1,header2\nvalue1,value2";
            CSVFormat excelFormat = CSVFormat.EXCEL;
            CSVParser excelParser = excelFormat.parse(reader);
            
            // Reset reader for next test
            
            CSVFormat rfc4180Format = CSVFormat.RFC4180;
            CSVParser rfc4180Parser = rfc4180Format.parse(reader);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testValidateWithDelimiterSameAsQuote() throws Exception {
            Method validateMethod = CSVFormat.class.getDeclaredMethod("validate");
            validateMethod.setAccessible(true);
            
            CSVFormat badFormat = CSVFormat.newFormat(',')
                .withQuote(',')  // Changed to make delimiter same as quote
                
            validateMethod.invoke(badFormat);
        }

    @Test
        public void testConstructorWithQuoteCharSameAsDelimiter() {
            builder.build();
        }


}
