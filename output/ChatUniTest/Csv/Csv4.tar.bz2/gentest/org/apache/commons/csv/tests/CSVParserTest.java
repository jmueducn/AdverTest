package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.Closeable;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
 
public class CSVParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                            public void testGetHeaderMapReturnsEmptyMapWhenHeaderMapIsEmpty() throws IOException {
                                                                                StringReader reader = new StringReader("");
                                                                                CSVFormat format = CSVFormat.DEFAULT;
                                                                                Map<String, Integer> emptyHeaderMap = new LinkedHashMap<>();
                                                                                
                                                                                CSVParser csvParser = mock(CSVParser.class);
                                                                                when(csvParser.getHeaderMap()).thenReturn(emptyHeaderMap);
                                                                                
                                                                                Map<String, Integer> headerMapCopy = csvParser.getHeaderMap();
                                                                                assertNotNull(headerMapCopy);
                                                                                assertTrue(headerMapCopy.isEmpty());
                                                                            }

    @Test
                                                                        public void testGetHeaderMapReturnsCopyOfHeaderMap() throws IOException {
                                                                            Map<String, Integer> originalHeaderMap = new LinkedHashMap<>();
                                                                            originalHeaderMap.put("Header1", 0);
                                                                            originalHeaderMap.put("Header2", 1);
                                                                            
                                                                            StringReader reader = new StringReader("");
                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                            
                                                                            CSVParser csvParser = mock(CSVParser.class);
                                                                            when(csvParser.getHeaderMap()).thenReturn(new LinkedHashMap<>(originalHeaderMap));
                                                                            
                                                                            Map<String, Integer> headerMapCopy = csvParser.getHeaderMap();
                                                                            assertNotNull(headerMapCopy);
                                                                            assertEquals(originalHeaderMap, headerMapCopy);
                                                                            assertNotSame(originalHeaderMap, headerMapCopy);
                                                                            
                                                                            // Verify modifying the copy doesn't affect the original
                                                                            headerMapCopy.put("Header3", 2);
                                                                            assertFalse(originalHeaderMap.containsKey("Header3"));
                                                                        }

    @Test
        public void testGetHeaderMapReturnsNullWhenHeaderMapIsNull() throws IOException {
            StringReader reader = new StringReader("");
            CSVFormat format = mock(CSVFormat.class);
            
            CSVParser csvParser = new CSVParser(reader, format);
            assertNull(csvParser.getHeaderMap());
            
            csvParser.close();
        }


}
