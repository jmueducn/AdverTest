package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.nio.file.Path;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
 
public class CSVFormatTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                    public void testPrintAndQuoteWithQuoteModeAll() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                        CSVFormat testFormat = format.withQuoteMode(QuoteMode.ALL);
                                                                                        StringWriter out = new StringWriter();
                                                                                        
                                                                                        Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                                                            "printAndQuote", 
                                                                                            Object.class, 
                                                                                            String.class, 
                                                                                            int.class, 
                                                                                            int.class, 
                                                                                            Appendable.class, 
                                                                                            boolean.class
                                                                                        );
                                                                                        printAndQuoteMethod.setAccessible(true);
                                                                                        
                                                                                        printAndQuoteMethod.invoke(testFormat, "test", "test", 0, 4, out, true);
                                                                                        assertEquals("\"test\"", out.toString());
                                                                                    }

    @Test
                                                                                    public void testPrintAndQuoteWithQuoteModeNonNumericForNumber() throws Exception {
                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                        Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod("printAndQuote", 
                                                                                            Object.class, String.class, int.class, int.class, Appendable.class, boolean.class);
                                                                                        printAndQuoteMethod.setAccessible(true);
                                                                                        
                                                                                        CSVFormat testFormat = format.withQuoteMode(QuoteMode.NON_NUMERIC);
                                                                                        StringWriter out = new StringWriter();
                                                                                        printAndQuoteMethod.invoke(testFormat, 123, "123", 0, 3, out, true);
                                                                                        assertEquals("123", out.toString());
                                                                                    }

    @Test
                                                                                    public void testPrintAndQuoteWithQuoteModeNonNumericForString() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                        CSVFormat testFormat = format.withQuoteMode(QuoteMode.NON_NUMERIC);
                                                                                        
                                                                                        Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod("printAndQuote", 
                                                                                            Object.class, CharSequence.class, int.class, int.class, Appendable.class, boolean.class);
                                                                                        printAndQuoteMethod.setAccessible(true);
                                                                                        
                                                                                        StringWriter out = new StringWriter();
                                                                                        printAndQuoteMethod.invoke(testFormat, "test", "test", 0, 4, out, true);
                                                                                        assertEquals("\"test\"", out.toString());
                                                                                    }

    @Test
                                                                                    public void testPrintAndQuoteWithQuoteModeNone() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                        Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod("printAndQuote", 
                                                                                            Object.class, CharSequence.class, int.class, int.class, Appendable.class, boolean.class);
                                                                                        printAndQuoteMethod.setAccessible(true);
                                                                                        
                                                                                        CSVFormat testFormat = format.withQuoteMode(QuoteMode.NONE).withEscape('\\');
                                                                                        StringWriter out = new StringWriter();
                                                                                        printAndQuoteMethod.invoke(testFormat, "test", "test", 0, 4, out, true);
                                                                                        assertEquals("test", out.toString());
                                                                                    }

    @Test
                                                                                    public void testPrintAndQuoteWithQuoteModeMinimalEmptyStringNewRecord() throws Exception {
                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                        CSVFormat testFormat = format.withQuoteMode(QuoteMode.MINIMAL);
                                                                                        
                                                                                        Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                                                            "printAndQuote", 
                                                                                            Object.class, 
                                                                                            String.class, 
                                                                                            Integer.TYPE, 
                                                                                            Integer.TYPE, 
                                                                                            Appendable.class, 
                                                                                            Boolean.TYPE
                                                                                        );
                                                                                        printAndQuoteMethod.setAccessible(true);
                                                                                        
                                                                                        StringWriter out = new StringWriter();
                                                                                        printAndQuoteMethod.invoke(testFormat, "", "", 0, 0, out, true);
                                                                                        assertEquals("\"\"", out.toString());
                                                                                    }

    @Test
                                                                                    public void testPrintAndQuoteWithQuoteModeMinimalEmptyStringNotNewRecord() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                        Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod("printAndQuote", 
                                                                                            CharSequence.class, String.class, int.class, int.class, Appendable.class, boolean.class);
                                                                                        printAndQuoteMethod.setAccessible(true);
                                                                                        
                                                                                        CSVFormat testFormat = format.withQuoteMode(QuoteMode.MINIMAL);
                                                                                        StringWriter out = new StringWriter();
                                                                                        printAndQuoteMethod.invoke(testFormat, "", "", 0, 0, out, false);
                                                                                        assertEquals("", out.toString());
                                                                                    }

    @Test
                                                                                    public void testPrintAndQuoteWithQuoteModeMinimalSpecialCharAtStart() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                        Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod("printAndQuote", 
                                                                                            CharSequence.class, CharSequence.class, int.class, int.class, Appendable.class, boolean.class);
                                                                                        printAndQuoteMethod.setAccessible(true);
                                                                                        
                                                                                        CSVFormat testFormat = format.withQuoteMode(QuoteMode.MINIMAL);
                                                                                        StringWriter out = new StringWriter();
                                                                                        printAndQuoteMethod.invoke(testFormat, "\u001Ftest", "\u001Ftest", 0, 5, out, true);
                                                                                        assertEquals("\"\u001Ftest\"", out.toString());
                                                                                    }

    @Test
                                                                                    public void testPrintAndQuoteWithQuoteModeMinimalCommentCharAtStart() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                        CSVFormat testFormat = format.withQuoteMode(QuoteMode.MINIMAL);
                                                                                        
                                                                                        Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                                                            "printAndQuote", 
                                                                                            Object.class, 
                                                                                            String.class, 
                                                                                            int.class, 
                                                                                            int.class, 
                                                                                            Appendable.class, 
                                                                                            boolean.class
                                                                                        );
                                                                                        printAndQuoteMethod.setAccessible(true);
                                                                                        
                                                                                        StringWriter out = new StringWriter();
                                                                                        printAndQuoteMethod.invoke(testFormat, "#test", "#test", 0, 5, out, true);
                                                                                        assertEquals("\"#test\"", out.toString());
                                                                                    }

    @Test
                                                                                    public void testPrintAndQuoteWithQuoteModeMinimalContainsDelimiter() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                        CSVFormat testFormat = format.withQuoteMode(QuoteMode.MINIMAL);
                                                                                        
                                                                                        Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                                                            "printAndQuote", 
                                                                                            Object.class, 
                                                                                            CharSequence.class, 
                                                                                            int.class, 
                                                                                            int.class, 
                                                                                            Appendable.class, 
                                                                                            boolean.class
                                                                                        );
                                                                                        printAndQuoteMethod.setAccessible(true);
                                                                                        
                                                                                        StringWriter out = new StringWriter();
                                                                                        printAndQuoteMethod.invoke(testFormat, "te,st", "te,st", 0, 5, out, true);
                                                                                        assertEquals("\"te,st\"", out.toString());
                                                                                    }

    @Test
                                                                                    public void testPrintAndQuoteWithQuoteModeMinimalContainsQuote() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                        Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod("printAndQuote", 
                                                                                            Object.class, String.class, int.class, int.class, Appendable.class, boolean.class);
                                                                                        printAndQuoteMethod.setAccessible(true);
                                                                                        
                                                                                        CSVFormat testFormat = format.withQuoteMode(QuoteMode.MINIMAL);
                                                                                        StringWriter out = new StringWriter();
                                                                                        printAndQuoteMethod.invoke(testFormat, "te\"st", "te\"st", 0, 5, out, true);
                                                                                        assertEquals("\"te\"\"st\"", out.toString());
                                                                                    }

    @Test
                                                                                    public void testPrintAndQuoteWithQuoteModeMinimalContainsLineBreak() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                        CSVFormat testFormat = format.withQuoteMode(QuoteMode.MINIMAL);
                                                                                        
                                                                                        Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                                                            "printAndQuote", 
                                                                                            Object.class, 
                                                                                            CharSequence.class, 
                                                                                            int.class, 
                                                                                            int.class, 
                                                                                            Appendable.class, 
                                                                                            boolean.class
                                                                                        );
                                                                                        printAndQuoteMethod.setAccessible(true);
                                                                                        
                                                                                        StringWriter out = new StringWriter();
                                                                                        printAndQuoteMethod.invoke(testFormat, "te\nst", "te\nst", 0, 5, out, true);
                                                                                        assertEquals("\"te\nst\"", out.toString());
                                                                                    }

    @Test
                                                                                    public void testPrintAndQuoteWithQuoteModeMinimalSpaceAtEnd() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                        CSVFormat testFormat = format.withQuoteMode(QuoteMode.MINIMAL);
                                                                                        StringWriter out = new StringWriter();
                                                                                        
                                                                                        Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                                                            "printAndQuote", 
                                                                                            Object.class, 
                                                                                            String.class, 
                                                                                            int.class, 
                                                                                            int.class, 
                                                                                            Appendable.class, 
                                                                                            boolean.class
                                                                                        );
                                                                                        printAndQuoteMethod.setAccessible(true);
                                                                                        
                                                                                        printAndQuoteMethod.invoke(testFormat, "test ", "test ", 0, 5, out, true);
                                                                                        assertEquals("\"test \"", out.toString());
                                                                                    }

    @Test
                                                                                    public void testPrintAndQuoteWithQuoteModeMinimalNoSpecialChars() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                        CSVFormat testFormat = format.withQuoteMode(QuoteMode.MINIMAL);
                                                                                        StringWriter out = new StringWriter();
                                                                                        
                                                                                        Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                                                            "printAndQuote", 
                                                                                            Object.class, 
                                                                                            String.class, 
                                                                                            int.class, 
                                                                                            int.class, 
                                                                                            Appendable.class, 
                                                                                            boolean.class
                                                                                        );
                                                                                        printAndQuoteMethod.setAccessible(true);
                                                                                        
                                                                                        printAndQuoteMethod.invoke(testFormat, "test", "test", 0, 4, out, true);
                                                                                        assertEquals("test", out.toString());
                                                                                    }

    @Test(expected = IllegalStateException.class)
                                                                                    public void testPrintAndQuoteWithInvalidQuoteMode() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                        CSVFormat testFormat = format.withQuoteMode(null);
                                                                                        StringWriter out = new StringWriter();
                                                                                        
                                                                                        Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod("printAndQuote", 
                                                                                            Object.class, String.class, int.class, int.class, Appendable.class, boolean.class);
                                                                                        printAndQuoteMethod.setAccessible(true);
                                                                                        
                                                                                        printAndQuoteMethod.invoke(testFormat, "test", "test", 0, 4, out, true);
                                                                                    }

    @Test
                                            public void testPrintAndQuoteWithQuoteModeMinimalSpecialCharAtEnd() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
                                                CSVFormat format = CSVFormat.DEFAULT;
                                                CSVFormat testFormat = format.withQuoteMode(QuoteMode.MINIMAL);
                                                StringWriter out = new StringWriter();
                                                
                                                try {
                                                    Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod("printAndQuote",
                                                        Object.class, String.class, int.class, int.class, Appendable.class, boolean.class);
                                                    printAndQuoteMethod.setAccessible(true);
                                                    
                                                    printAndQuoteMethod.invoke(testFormat, "test\u001F", "test\u001F", 0, 5, out, true);
                                                    assertEquals("\"test\u001F\"", out.toString());
                                                } catch (NoSuchMethodException e) {
                                                    fail("Method printAndQuote not found");
                                                }
                                            }


}
