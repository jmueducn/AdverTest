package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
 
public class CSVFormatTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                        public void testIsLineBreakWithNull() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                            method.setAccessible(true);
                                                                                            boolean result = (boolean) method.invoke(null, (Character) null);
                                                                                            assertFalse(result);
                                                                                        }

    @Test
                                                                                        public void testIsLineBreakWithLF() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                            method.setAccessible(true);
                                                                                            boolean result = (boolean) method.invoke(null, '\n');
                                                                                            assertTrue(result);
                                                                                        }

    @Test
                                                                                        public void testIsLineBreakWithCR() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                            method.setAccessible(true);
                                                                                            boolean result = (boolean) method.invoke(null, '\r');
                                                                                            assertTrue(result);
                                                                                        }

    @Test
                                                                                        public void testIsLineBreakWithOtherCharacter() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                            method.setAccessible(true);
                                                                                            boolean result = (boolean) method.invoke(null, 'a');
                                                                                            assertFalse(result);
                                                                                        }

    @Test
                                                                                        public void testIsLineBreakWithSpace() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                            method.setAccessible(true);
                                                                                            boolean result = (boolean) method.invoke(null, ' ');
                                                                                            assertFalse(result);
                                                                                        }

    @Test
                                                                                        public void testNewFormatWithValidDelimiter() {
                                                                                            char delimiter = ',';
                                                                                            CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                            
                                                                                            assertEquals(delimiter, format.getDelimiter());
                                                                                            assertNull(format.getQuoteCharacter());
                                                                                            assertNull(format.getQuoteMode());
                                                                                            assertNull(format.getCommentMarker());
                                                                                            assertNull(format.getEscapeCharacter());
                                                                                            assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                            assertFalse(format.getIgnoreEmptyLines());
                                                                                            assertNull(format.getRecordSeparator());
                                                                                            assertNull(format.getNullString());
                                                                                            assertNull(format.getHeader());
                                                                                            assertFalse(format.getSkipHeaderRecord());
                                                                                            assertFalse(format.getAllowMissingColumnNames());
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testNewFormatWithLineBreakDelimiter() {
                                                                                            char lineBreak = '\n';
                                                                                            CSVFormat.newFormat(lineBreak);
                                                                                        }

    @Test
                                                                                        public void testIsLineBreakWithValidCharacters() throws Exception {
                                                                                            Method isLineBreakChar = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                            isLineBreakChar.setAccessible(true);
                                                                                            
                                                                                            assertTrue((boolean) isLineBreakChar.invoke(null, '\n'));
                                                                                            assertTrue((boolean) isLineBreakChar.invoke(null, '\r'));
                                                                                            assertFalse((boolean) isLineBreakChar.invoke(null, ','));
                                                                                            assertFalse((boolean) isLineBreakChar.invoke(null, 'a'));
                                                                                        }

    @Test
                                                                                        public void testIsLineBreakWithCharacterObject() throws Exception {
                                                                                            Method isLineBreakChar = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                            isLineBreakChar.setAccessible(true);
                                                                                            
                                                                                            assertTrue((boolean) isLineBreakChar.invoke(null, Character.valueOf('\n')));
                                                                                            assertTrue((boolean) isLineBreakChar.invoke(null, Character.valueOf('\r')));
                                                                                            assertFalse((boolean) isLineBreakChar.invoke(null, Character.valueOf(',')));
                                                                                            assertFalse((boolean) isLineBreakChar.invoke(null, Character.valueOf('a')));
                                                                                            assertFalse((boolean) isLineBreakChar.invoke(null, (Character) null));
                                                                                        }

    @Test
                                                                                        public void testEqualsAndHashCode() {
                                                                                            CSVFormat format1 = CSVFormat.newFormat(',');
                                                                                            CSVFormat format2 = CSVFormat.newFormat(',');
                                                                                            CSVFormat format3 = CSVFormat.newFormat(';');
                                                                                            
                                                                                            assertEquals(format1, format2);
                                                                                            assertEquals(format1.hashCode(), format2.hashCode());
                                                                                            assertNotEquals(format1, format3);
                                                                                            assertNotEquals(format1.hashCode(), format3.hashCode());
                                                                                            assertNotEquals(format1, null);
                                                                                            assertNotEquals(format1, new Object());
                                                                                        }

    @Test
                                                                                        public void testToString() {
                                                                                            CSVFormat format = CSVFormat.newFormat(',');
                                                                                            String str = format.toString();
                                                                                            assertTrue(str.contains("Delimiter=<,>"));
                                                                                        }

    @Test
                                                                                        public void testEqualsSameObject() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            assertTrue(format.equals(format));
                                                                                        }

    @Test
                                                                                        public void testEqualsNull() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            assertFalse(format.equals(null));
                                                                                        }

    @Test
                                                                                        public void testEqualsDifferentClass() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            assertFalse(format.equals("string"));
                                                                                        }

    @Test
                                                                                        public void testEqualsDifferentDelimiter() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT;
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withDelimiter(';');
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEqualsDifferentQuoteMode() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT;
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEqualsDifferentQuoteCharacter() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withQuote('"');
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withQuote('\'');
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEqualsNullQuoteCharacter() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withQuote(null);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withQuote('"');
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEqualsDifferentCommentMarker() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withCommentMarker('#');
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withCommentMarker('!');
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEqualsNullCommentMarker() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withCommentMarker(null);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withCommentMarker('#');
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEqualsDifferentEscapeCharacter() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withEscape('\\');
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withEscape('/');
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEqualsNullEscapeCharacter() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withEscape(null);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withEscape('\\');
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEqualsDifferentNullString() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withNullString("null");
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEqualsNullNullString() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withNullString(null);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEqualsDifferentHeader() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withHeader("A", "B");
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withHeader("X", "Y");
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEqualsDifferentIgnoreSurroundingSpaces() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(false);
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEqualsDifferentIgnoreEmptyLines() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withIgnoreEmptyLines(true);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEqualsDifferentSkipHeaderRecord() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withSkipHeaderRecord(false);
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEqualsDifferentRecordSeparator() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withRecordSeparator("\n");
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEqualsNullRecordSeparator() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withRecordSeparator(null);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withRecordSeparator("\n");
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEqualsIdenticalFormats() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT
                                                                                                .withDelimiter(',')
                                                                                                .withQuote('"')
                                                                                                .withRecordSeparator("\r\n")
                                                                                                .withIgnoreEmptyLines(true)
                                                                                                .withHeader("A", "B", "C");
                                                                                            
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT
                                                                                                .withDelimiter(',')
                                                                                                .withQuote('"')
                                                                                                .withRecordSeparator("\r\n")
                                                                                                .withIgnoreEmptyLines(true)
                                                                                                .withHeader("A", "B", "C");
                                                                                            
                                                                                            assertTrue(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEqualsWithNullHeader() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withHeader((String[]) null);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withHeader("A", "B");
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testFormatWithValues() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            String result = format.format("value1", "value2", "value3");
                                                                                            assertEquals("value1,value2,value3", result);
                                                                                        }

    @Test
                                                                                        public void testFormatWithEmptyValues() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            String result = format.format();
                                                                                            assertEquals("", result);
                                                                                        }

    @Test
                                                                                        public void testFormatWithNullValues() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                            String result = format.format(null, "value", null);
                                                                                            assertEquals("NULL,value,NULL", result);
                                                                                        }

    @Test
                                                                                        public void testFormatWithDifferentDelimiter() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
                                                                                            String result = format.format("val1", "val2");
                                                                                            assertEquals("val1;val2", result);
                                                                                        }

    @Test
                                                                                        public void testFormatWithQuoteCharacter() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withQuote('"');
                                                                                            String result = format.format("value1", "value2");
                                                                                            assertEquals("\"value1\",\"value2\"", result);
                                                                                        }

    @Test(expected = IllegalStateException.class)
                                                                                        public void testFormatThrowsIllegalStateExceptionOnIOException() throws IOException {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            StringWriter mockWriter = mock(StringWriter.class);
                                                                                            when(mockWriter.toString()).thenThrow(new IOException("Test exception"));
                                                                                            
                                                                                            CSVPrinter mockPrinter = mock(CSVPrinter.class);
                                                                                            doThrow(new IOException("Test exception")).when(mockPrinter).printRecord(any(Object[].class));
                                                                                            
                                                                                            // Use reflection to test private behavior
                                                                                            try {
                                                                                                CSVPrinter printer = new CSVPrinter(mockWriter, format);
                                                                                                format.format("value");
                                                                                            } catch (IllegalStateException e) {
                                                                                                assertEquals("java.io.IOException: Test exception", e.getMessage());
                                                                                                throw e;
                                                                                            }
                                                                                        }

    @Test
                                                                                        public void testFormatWithRecordSeparator() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n");
                                                                                            String result = format.format("a", "b", "c");
                                                                                            assertEquals("a,b,c", result); // Note: trim() removes the record separator
                                                                                        }

    @Test
                                                                                        public void testFormatWithMultipleValues() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            String result = format.format("1", "2", "3", "4", "5");
                                                                                            assertEquals("1,2,3,4,5", result);
                                                                                        }

    @Test
                                                                                        public void testFormatWithSpecialCharacters() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            String result = format.format("a,b", "c\"d", "e\nf");
                                                                                            assertEquals("\"a,b\",\"c\"\"d\",\"e\nf\"", result);
                                                                                        }

    @Test
                                                                                        public void testGetCommentMarkerWhenSet() throws Exception {
                                                                                            Character expectedCommentMarker = '#';
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withCommentMarker(expectedCommentMarker);
                                                                                            assertEquals(expectedCommentMarker, format.getCommentMarker());
                                                                                        }

    @Test
                                                                                        public void testGetCommentMarkerWhenNotSet() throws Exception {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withCommentMarker(null);
                                                                                            assertNull(format.getCommentMarker());
                                                                                        }

    @Test
                                                                                        public void testGetCommentMarkerWithDifferentValues() throws Exception {
                                                                                            Character comment1 = '!';
                                                                                            Character comment2 = '@';
                                                                                            
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withCommentMarker(comment1);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withCommentMarker(comment2);
                                                                                            
                                                                                            assertEquals(comment1, format1.getCommentMarker());
                                                                                            assertEquals(comment2, format2.getCommentMarker());
                                                                                        }

    @Test
                                                                                        public void testGetCommentMarkerAfterMultipleModifications() throws Exception {
                                                                                            Character initialComment = '#';
                                                                                            Character modifiedComment = '*';
                                                                                            Character finalComment = null;
                                                                                            
                                                                                            CSVFormat format = CSVFormat.DEFAULT
                                                                                                .withCommentMarker(initialComment)
                                                                                                .withCommentMarker(modifiedComment)
                                                                                                .withCommentMarker(finalComment);
                                                                                                
                                                                                            assertNull(format.getCommentMarker());
                                                                                        }

    @Test
                                                                                        public void testGetCommentMarkerWithDefaultFormat() throws Exception {
                                                                                            assertNull(CSVFormat.DEFAULT.getCommentMarker());
                                                                                        }

    @Test
                                                                                        public void testGetCommentMarkerWithRFC4180Format() throws Exception {
                                                                                            assertNull(CSVFormat.RFC4180.getCommentMarker());
                                                                                        }

    @Test
                                                                                        public void testGetCommentMarkerWithExcelFormat() throws Exception {
                                                                                            assertNull(CSVFormat.EXCEL.getCommentMarker());
                                                                                        }

    @Test
                                                                                        public void testGetCommentMarkerWithTDFFormat() throws Exception {
                                                                                            assertNull(CSVFormat.TDF.getCommentMarker());
                                                                                        }

    @Test
                                                                                        public void testGetCommentMarkerWithMySQLFormat() throws Exception {
                                                                                            assertNull(CSVFormat.MYSQL.getCommentMarker());
                                                                                        }

    @Test
                                                                                        public void testGetDelimiterWithDefaultFormat() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            assertEquals(',', format.getDelimiter());
                                                                                        }

    @Test
                                                                                        public void testGetDelimiterWithExcelFormat() {
                                                                                            CSVFormat format = CSVFormat.EXCEL;
                                                                                            assertEquals(',', format.getDelimiter());
                                                                                        }

    @Test
                                                                                        public void testGetDelimiterWithTDFFormat() {
                                                                                            CSVFormat format = CSVFormat.TDF;
                                                                                            assertEquals('\t', format.getDelimiter());
                                                                                        }

    @Test
                                                                                        public void testGetDelimiterWithMySQLFormat() {
                                                                                            CSVFormat format = CSVFormat.MYSQL;
                                                                                            assertEquals('\t', format.getDelimiter());
                                                                                        }

    @Test
                                                                                        public void testGetDelimiterWithCustomFormat() {
                                                                                            CSVFormat format = CSVFormat.newFormat('|');
                                                                                            assertEquals('|', format.getDelimiter());
                                                                                        }

    @Test
                                                                                        public void testGetDelimiterAfterWithDelimiter() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
                                                                                            assertEquals(';', format.getDelimiter());
                                                                                        }

    @Test
                                                                                        public void testGetDelimiterWithRFC4180Format() {
                                                                                            CSVFormat format = CSVFormat.RFC4180;
                                                                                            assertEquals(',', format.getDelimiter());
                                                                                        }

    @Test
                                                                                        public void testGetEscapeCharacterWhenSet() throws Exception {
                                                                                            Character expectedEscape = '\\';
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withEscape(expectedEscape);
                                                                                            assertEquals(expectedEscape, format.getEscapeCharacter());
                                                                                        }

    @Test
                                                                                        public void testGetEscapeCharacterWhenNotSet() throws Exception {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withEscape(null);
                                                                                            assertNull(format.getEscapeCharacter());
                                                                                        }

    @Test
                                                                                        public void testGetEscapeCharacterWithDifferentValues() throws Exception {
                                                                                            Character[] testValues = {'\\', '"', '\'', '\t', 'n'};
                                                                                            
                                                                                            for (Character testValue : testValues) {
                                                                                                CSVFormat format = CSVFormat.DEFAULT.withEscape(testValue);
                                                                                                assertEquals(testValue, format.getEscapeCharacter());
                                                                                            }
                                                                                        }

    @Test
                                                                                        public void testGetEscapeCharacterAfterModification() throws Exception {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withEscape('a');
                                                                                            assertEquals(Character.valueOf('a'), format.getEscapeCharacter());
                                                                                            
                                                                                            format = format.withEscape('b');
                                                                                            assertEquals(Character.valueOf('b'), format.getEscapeCharacter());
                                                                                        }

    @Test
                                                                                        public void testGetEscapeCharacterWithPrivateField() throws Exception {
                                                                                            // Create format with null escape
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withEscape(null);
                                                                                            
                                                                                            // Use reflection to set private field
                                                                                            Field escapeField = CSVFormat.class.getDeclaredField("escapeCharacter");
                                                                                            escapeField.setAccessible(true);
                                                                                            escapeField.set(format, 'x');
                                                                                            
                                                                                            assertEquals(Character.valueOf('x'), format.getEscapeCharacter());
                                                                                        }

    @Test
                                                                                        public void testGetEscapeCharacterConsistency() throws Exception {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withEscape('\\');
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withEscape('\\');
                                                                                            
                                                                                            assertEquals(format1.getEscapeCharacter(), format2.getEscapeCharacter());
                                                                                        }

    @Test
                                                                                        public void testGetHeaderWhenHeaderIsNull() throws Exception {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeader((String[]) null);
                                                                                            assertNull(format.getHeader());
                                                                                        }

    @Test
                                                                                        public void testGetHeaderWhenHeaderIsEmpty() throws Exception {
                                                                                            String[] headers = new String[0];
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeader(headers);
                                                                                            String[] result = format.getHeader();
                                                                                            assertNotNull(result);
                                                                                            assertEquals(0, result.length);
                                                                                            assertNotSame(headers, result); // Verify it's a copy
                                                                                        }

    @Test
                                                                                        public void testGetHeaderWhenHeaderHasValues() throws Exception {
                                                                                            String[] headers = {"col1", "col2", "col3"};
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeader(headers);
                                                                                            String[] result = format.getHeader();
                                                                                            assertNotNull(result);
                                                                                            assertEquals(3, result.length);
                                                                                            assertArrayEquals(headers, result);
                                                                                            assertNotSame(headers, result); // Verify it's a copy
                                                                                            
                                                                                            // Verify modifying the returned array doesn't affect the original
                                                                                            result[0] = "modified";
                                                                                            assertNotEquals(headers[0], format.getHeader()[0]);
                                                                                        }

    @Test
                                                                                        public void testGetHeaderReturnsDeepCopy() throws Exception {
                                                                                            String[] headers = {"a", "b", "c"};
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeader(headers);
                                                                                            
                                                                                            // Get header and modify it
                                                                                            String[] firstCopy = format.getHeader();
                                                                                            firstCopy[0] = "x";
                                                                                            
                                                                                            // Get header again and verify it's unchanged
                                                                                            String[] secondCopy = format.getHeader();
                                                                                            assertEquals("a", secondCopy[0]);
                                                                                        }

    @Test
                                                                                        public void testGetHeaderWithPrivateFieldAccess() throws Exception {
                                                                                            String[] headers = {"private", "field", "test"};
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeader(headers);
                                                                                            
                                                                                            // Use reflection to verify private field
                                                                                            Field headerField = CSVFormat.class.getDeclaredField("header");
                                                                                            headerField.setAccessible(true);
                                                                                            String[] privateHeader = (String[]) headerField.get(format);
                                                                                            
                                                                                            assertArrayEquals(headers, privateHeader);
                                                                                            assertNotSame(privateHeader, format.getHeader());
                                                                                        }

    @Test
                                                                                        public void testGetAllowMissingColumnNamesWhenTrue() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withAllowMissingColumnNames(true);
                                                                                            assertTrue(format.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testGetAllowMissingColumnNamesWhenFalse() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withAllowMissingColumnNames(false);
                                                                                            assertFalse(format.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testGetAllowMissingColumnNamesDefaultValue() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            assertFalse(format.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testGetAllowMissingColumnNamesExcelFormat() {
                                                                                            CSVFormat format = CSVFormat.EXCEL;
                                                                                            assertTrue(format.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testGetAllowMissingColumnNamesAfterModification() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT
                                                                                                .withAllowMissingColumnNames(true)
                                                                                                .withAllowMissingColumnNames(false);
                                                                                            assertFalse(format.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testGetIgnoreEmptyLinesWhenTrue() throws Exception {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            Field ignoreEmptyLinesField = CSVFormat.class.getDeclaredField("ignoreEmptyLines");
                                                                                            ignoreEmptyLinesField.setAccessible(true);
                                                                                            ignoreEmptyLinesField.set(format, true);
                                                                                            
                                                                                            assertTrue(format.getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testGetIgnoreEmptyLinesWhenFalse() throws Exception {
                                                                                            CSVFormat format = CSVFormat.RFC4180;
                                                                                            Field ignoreEmptyLinesField = CSVFormat.class.getDeclaredField("ignoreEmptyLines");
                                                                                            ignoreEmptyLinesField.setAccessible(true);
                                                                                            ignoreEmptyLinesField.set(format, false);
                                                                                            
                                                                                            assertFalse(format.getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testDefaultFormatIgnoreEmptyLines() {
                                                                                            assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testRFC4180FormatIgnoreEmptyLines() {
                                                                                            assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testExcelFormatIgnoreEmptyLines() {
                                                                                            assertFalse(CSVFormat.EXCEL.getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testTDFFormatIgnoreEmptyLines() {
                                                                                            assertTrue(CSVFormat.TDF.getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testMySQLFormatIgnoreEmptyLines() {
                                                                                            assertFalse(CSVFormat.MYSQL.getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreEmptyLinesTrue() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withIgnoreEmptyLines(true);
                                                                                            assertTrue(format.getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreEmptyLinesFalse() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);
                                                                                            assertFalse(format.getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testGetIgnoreSurroundingSpacesWhenTrue() throws Exception {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true);
                                                                                            assertTrue(format.getIgnoreSurroundingSpaces());
                                                                                        }

    @Test
                                                                                        public void testGetIgnoreSurroundingSpacesWhenFalse() throws Exception {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(false);
                                                                                            assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                        }

    @Test
                                                                                        public void testGetIgnoreSurroundingSpacesUsingReflection() throws Exception {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Use reflection to set the private field
                                                                                            Field field = CSVFormat.class.getDeclaredField("ignoreSurroundingSpaces");
                                                                                            field.setAccessible(true);
                                                                                            field.set(format, true);
                                                                                            
                                                                                            assertTrue(format.getIgnoreSurroundingSpaces());
                                                                                            
                                                                                            field.set(format, false);
                                                                                            assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                        }

    @Test
                                                                                        public void testGetIgnoreSurroundingSpacesWithMock() throws Exception {
                                                                                            CSVFormat mockFormat = mock(CSVFormat.class);
                                                                                            when(mockFormat.getIgnoreSurroundingSpaces()).thenReturn(true);
                                                                                            assertTrue(mockFormat.getIgnoreSurroundingSpaces());
                                                                                            
                                                                                            when(mockFormat.getIgnoreSurroundingSpaces()).thenReturn(false);
                                                                                            assertFalse(mockFormat.getIgnoreSurroundingSpaces());
                                                                                        }

    @Test
                                                                                        public void testGetNullStringWhenNullStringIsNull() throws Exception {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            Field nullStringField = CSVFormat.class.getDeclaredField("nullString");
                                                                                            nullStringField.setAccessible(true);
                                                                                            nullStringField.set(format, null);
                                                                                            
                                                                                            assertNull(format.getNullString());
                                                                                        }

    @Test
                                                                                        public void testGetNullStringWhenNullStringIsSet() throws Exception {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            Field nullStringField = CSVFormat.class.getDeclaredField("nullString");
                                                                                            nullStringField.setAccessible(true);
                                                                                            nullStringField.set(format, "NULL");
                                                                                            
                                                                                            assertEquals("NULL", format.getNullString());
                                                                                        }

    @Test
                                                                                        public void testGetNullStringWithDifferentFormats() {
                                                                                            assertEquals(null, CSVFormat.DEFAULT.getNullString());
                                                                                            assertEquals(null, CSVFormat.EXCEL.getNullString());
                                                                                            assertEquals(null, CSVFormat.MYSQL.getNullString());
                                                                                            assertEquals(null, CSVFormat.RFC4180.getNullString());
                                                                                            assertEquals(null, CSVFormat.TDF.getNullString());
                                                                                        }

    @Test
                                                                                        public void testGetNullStringAfterWithNullString() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withNullString("NA");
                                                                                            assertEquals("NA", format.getNullString());
                                                                                        }

    @Test
                                                                                        public void testGetNullStringAfterMultipleWithNullString() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT
                                                                                                .withNullString("NA")
                                                                                                .withNullString("NULL")
                                                                                                .withNullString("N/A");
                                                                                            assertEquals("N/A", format.getNullString());
                                                                                        }

    @Test
                                                                                        public void testGetNullStringAfterWithNullStringNull() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withNullString(null);
                                                                                            assertNull(format.getNullString());
                                                                                        }

    @Test
                                                                                        public void testGetQuoteCharacterWhenSet() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withQuote('"');
                                                                                            assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
                                                                                        }

    @Test
                                                                                        public void testGetQuoteCharacterWhenNotSet() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withQuote(null);
                                                                                            assertNull(format.getQuoteCharacter());
                                                                                        }

    @Test
                                                                                        public void testGetQuoteCharacterWithDifferentCharacters() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withQuote('\'');
                                                                                            assertEquals(Character.valueOf('\''), format1.getQuoteCharacter());
                                                                                    
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withQuote('|');
                                                                                            assertEquals(Character.valueOf('|'), format2.getQuoteCharacter());
                                                                                        }

    @Test
                                                                                        public void testGetQuoteCharacterAfterMultipleWithOperations() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT
                                                                                                    .withDelimiter(';')
                                                                                                    .withQuote('"')
                                                                                                    .withRecordSeparator("\n");
                                                                                            assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
                                                                                        }

    @Test
                                                                                        public void testGetQuoteCharacterWithDefaultFormat() {
                                                                                            assertEquals(Character.valueOf('"'), CSVFormat.DEFAULT.getQuoteCharacter());
                                                                                        }

    @Test
                                                                                        public void testGetQuoteCharacterWithExcelFormat() {
                                                                                            assertEquals(Character.valueOf('"'), CSVFormat.EXCEL.getQuoteCharacter());
                                                                                        }

    @Test
                                                                                        public void testGetQuoteCharacterWithMySQLFormat() {
                                                                                            assertNull(CSVFormat.MYSQL.getQuoteCharacter());
                                                                                        }

    @Test
                                                                                        public void testGetQuoteCharacterWithTDFFormat() {
                                                                                            assertEquals(Character.valueOf('"'), CSVFormat.TDF.getQuoteCharacter());
                                                                                        }

    @Test
                                                                                        public void testGetQuoteCharacterWithRFC4180Format() {
                                                                                            assertEquals(Character.valueOf('"'), CSVFormat.RFC4180.getQuoteCharacter());
                                                                                        }

    @Test
                                                                                        public void testGetQuoteMode() {
                                                                                            // Test with null quote mode
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(null);
                                                                                            assertNull(format.getQuoteMode());
                                                                                    
                                                                                            // Test with MINIMAL quote mode
                                                                                            format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                                                            assertEquals(QuoteMode.MINIMAL, format.getQuoteMode());
                                                                                    
                                                                                            // Test with ALL quote mode
                                                                                            format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
                                                                                            assertEquals(QuoteMode.ALL, format.getQuoteMode());
                                                                                    
                                                                                            // Test with NON_NUMERIC quote mode
                                                                                            format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC);
                                                                                            assertEquals(QuoteMode.NON_NUMERIC, format.getQuoteMode());
                                                                                    
                                                                                            // Test with NONE quote mode
                                                                                            format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NONE);
                                                                                            assertEquals(QuoteMode.NONE, format.getQuoteMode());
                                                                                        }

    @Test
                                                                                        public void testGetQuoteModeWithDefaultFormat() {
                                                                                            // Test default format's quote mode (should be null)
                                                                                            assertNull(CSVFormat.DEFAULT.getQuoteMode());
                                                                                        }

    @Test
                                                                                        public void testGetQuoteModeWithRFC4180Format() {
                                                                                            // Test RFC4180 format's quote mode (should be null)
                                                                                            assertNull(CSVFormat.RFC4180.getQuoteMode());
                                                                                        }

    @Test
                                                                                        public void testGetQuoteModeWithExcelFormat() {
                                                                                            // Test Excel format's quote mode (should be null)
                                                                                            assertNull(CSVFormat.EXCEL.getQuoteMode());
                                                                                        }

    @Test
                                                                                        public void testGetQuoteModeWithMySQLFormat() {
                                                                                            // Test MySQL format's quote mode (should be null)
                                                                                            assertNull(CSVFormat.MYSQL.getQuoteMode());
                                                                                        }

    @Test
                                                                                        public void testGetQuoteModeWithTDFFormat() {
                                                                                            // Test TDF format's quote mode (should be null)
                                                                                            assertNull(CSVFormat.TDF.getQuoteMode());
                                                                                        }

    @Test
                                                                                        public void testGetSkipHeaderRecordWhenTrue() throws Exception {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                            assertTrue(format.getSkipHeaderRecord());
                                                                                        }

    @Test
                                                                                        public void testGetSkipHeaderRecordWhenFalse() throws Exception {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withSkipHeaderRecord(false);
                                                                                            assertFalse(format.getSkipHeaderRecord());
                                                                                        }

    @Test
                                                                                        public void testGetSkipHeaderRecordDefaultValue() throws Exception {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            assertFalse(format.getSkipHeaderRecord());
                                                                                        }

    @Test
                                                                                        public void testGetSkipHeaderRecordWithReflection() throws Exception {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Use reflection to set the private field
                                                                                            Field skipHeaderRecordField = CSVFormat.class.getDeclaredField("skipHeaderRecord");
                                                                                            skipHeaderRecordField.setAccessible(true);
                                                                                            skipHeaderRecordField.set(format, true);
                                                                                            
                                                                                            assertTrue(format.getSkipHeaderRecord());
                                                                                        }

    @Test
                                                                                        public void testIsCommentMarkerSetWhenCommentMarkerIsNull() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withCommentMarker(null);
                                                                                            assertFalse(format.isCommentMarkerSet());
                                                                                        }

    @Test
                                                                                        public void testIsCommentMarkerSetWhenCommentMarkerIsNotNull() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#');
                                                                                            assertTrue(format.isCommentMarkerSet());
                                                                                        }

    @Test
                                                                                        public void testIsCommentMarkerSetWithDifferentCommentMarkers() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withCommentMarker('!');
                                                                                            assertTrue(format1.isCommentMarkerSet());
                                                                                    
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withCommentMarker('@');
                                                                                            assertTrue(format2.isCommentMarkerSet());
                                                                                        }

    @Test
                                                                                        public void testIsCommentMarkerSetAfterMultipleWithOperations() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT
                                                                                                .withDelimiter(';')
                                                                                                .withCommentMarker('#')
                                                                                                .withQuote('"');
                                                                                            assertTrue(format.isCommentMarkerSet());
                                                                                        }

    @Test
                                                                                        public void testIsCommentMarkerSetWithDefaultFormat() {
                                                                                            assertFalse(CSVFormat.DEFAULT.isCommentMarkerSet());
                                                                                        }

    @Test
                                                                                        public void testIsCommentMarkerSetWithExcelFormat() {
                                                                                            assertFalse(CSVFormat.EXCEL.isCommentMarkerSet());
                                                                                        }

    @Test
                                                                                        public void testIsCommentMarkerSetWithMySQLFormat() {
                                                                                            assertFalse(CSVFormat.MYSQL.isCommentMarkerSet());
                                                                                        }

    @Test
                                                                                        public void testIsCommentMarkerSetWithTDFFormat() {
                                                                                            assertFalse(CSVFormat.TDF.isCommentMarkerSet());
                                                                                        }

    @Test
                                                                                        public void testIsCommentMarkerSetWithRFC4180Format() {
                                                                                            assertFalse(CSVFormat.RFC4180.isCommentMarkerSet());
                                                                                        }

    @Test
                                                                                        public void testIsEscapeCharacterSetWhenEscapeCharacterIsNull() {
                                                                                            CSVFormat format = CSVFormat.newFormat(',')
                                                                                                    .withEscape(null);
                                                                                            assertFalse(format.isEscapeCharacterSet());
                                                                                        }

    @Test
                                                                                        public void testIsEscapeCharacterSetWhenEscapeCharacterIsSet() {
                                                                                            CSVFormat format = CSVFormat.newFormat(',')
                                                                                                    .withEscape('\\');
                                                                                            assertTrue(format.isEscapeCharacterSet());
                                                                                        }

    @Test
                                                                                        public void testIsEscapeCharacterSetWithDefaultFormat() {
                                                                                            assertFalse(CSVFormat.DEFAULT.isEscapeCharacterSet());
                                                                                        }

    @Test
                                                                                        public void testIsEscapeCharacterSetWithMySQLFormat() {
                                                                                            assertTrue(CSVFormat.MYSQL.isEscapeCharacterSet());
                                                                                        }

    @Test
                                                                                        public void testIsEscapeCharacterSetAfterChangingEscapeCharacter() {
                                                                                            CSVFormat format = CSVFormat.newFormat(',')
                                                                                                    .withEscape('\\');
                                                                                            assertTrue(format.isEscapeCharacterSet());
                                                                                            
                                                                                            format = format.withEscape(null);
                                                                                            assertFalse(format.isEscapeCharacterSet());
                                                                                        }

    @Test
                                                                                        public void testIsNullStringSetWhenNullStringIsNull() throws Exception {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withNullString(null);
                                                                                            assertFalse(format.isNullStringSet());
                                                                                        }

    @Test
                                                                                        public void testIsNullStringSetWhenNullStringIsNotNull() throws Exception {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                            assertTrue(format.isNullStringSet());
                                                                                        }

    @Test
                                                                                        public void testIsNullStringSetWhenNullStringIsEmpty() throws Exception {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withNullString("");
                                                                                            assertTrue(format.isNullStringSet());
                                                                                        }

    @Test
                                                                                        public void testIsNullStringSetWhenNullStringIsBlank() throws Exception {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withNullString("   ");
                                                                                            assertTrue(format.isNullStringSet());
                                                                                        }

    @Test
                                                                                        public void testIsNullStringSetUsingReflection() throws Exception {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Set nullString to null via reflection
                                                                                            Field nullStringField = CSVFormat.class.getDeclaredField("nullString");
                                                                                            nullStringField.setAccessible(true);
                                                                                            nullStringField.set(format, null);
                                                                                            
                                                                                            assertFalse(format.isNullStringSet());
                                                                                            
                                                                                            // Set nullString to a value via reflection
                                                                                            nullStringField.set(format, "NULL");
                                                                                            assertTrue(format.isNullStringSet());
                                                                                        }

    @Test
                                                                                        public void testIsQuoteCharacterSetWhenQuoteCharacterIsNull() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withQuote(null);
                                                                                            assertFalse(format.isQuoteCharacterSet());
                                                                                        }

    @Test
                                                                                        public void testIsQuoteCharacterSetWhenQuoteCharacterIsNotNull() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withQuote('"');
                                                                                            assertTrue(format.isQuoteCharacterSet());
                                                                                        }

    @Test
                                                                                        public void testIsQuoteCharacterSetWithDifferentQuoteCharacters() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withQuote('\'');
                                                                                            assertTrue(format1.isQuoteCharacterSet());
                                                                                    
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withQuote('|');
                                                                                            assertTrue(format2.isQuoteCharacterSet());
                                                                                        }

    @Test
                                                                                        public void testIsQuoteCharacterSetAfterModification() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            assertTrue(format.isQuoteCharacterSet()); // DEFAULT has quote char
                                                                                            
                                                                                            format = format.withQuote(null);
                                                                                            assertFalse(format.isQuoteCharacterSet());
                                                                                            
                                                                                            format = format.withQuote('a');
                                                                                            assertTrue(format.isQuoteCharacterSet());
                                                                                        }

    @Test
                                                                                        public void testIsQuoteCharacterSetWithPredefinedFormats() {
                                                                                            assertTrue(CSVFormat.DEFAULT.isQuoteCharacterSet());
                                                                                            assertTrue(CSVFormat.RFC4180.isQuoteCharacterSet());
                                                                                            assertTrue(CSVFormat.EXCEL.isQuoteCharacterSet());
                                                                                            assertFalse(CSVFormat.MYSQL.isQuoteCharacterSet());
                                                                                            assertTrue(CSVFormat.TDF.isQuoteCharacterSet());
                                                                                        }

    @Test
                                                                                        public void testIsLineBreakChar() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                        }

    @Test
                                                                                        public void testIsLineBreakCharacter() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                            assertFalse((boolean) method.invoke(null, (Character) null));
                                                                                        }

    @Test
                                                                                        public void testToStringWithAllFieldsSet() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT
                                                                                                .withEscape('\\')
                                                                                                .withQuote('"')
                                                                                                .withCommentMarker('#')
                                                                                                .withNullString("NULL")
                                                                                                .withRecordSeparator("\r\n")
                                                                                                .withIgnoreEmptyLines(true)
                                                                                                .withIgnoreSurroundingSpaces(true)
                                                                                                .withSkipHeaderRecord(true)
                                                                                                .withHeader("col1", "col2", "col3");
                                                                                            
                                                                                            String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> CommentStart=<#> " +
                                                                                                             "NullString=<NULL> RecordSeparator=<\r\n> EmptyLines:ignored " +
                                                                                                             "SurroundingSpaces:ignored SkipHeaderRecord:true " +
                                                                                                             "Header:[col1, col2, col3]";
                                                                                            
                                                                                            assertEquals(expected, format.toString());
                                                                                        }

    @Test
                                                                                        public void testToStringWithMinimalFields() {
                                                                                            CSVFormat format = CSVFormat.newFormat(';');
                                                                                            
                                                                                            String expected = "Delimiter=<;> SkipHeaderRecord:false";
                                                                                            
                                                                                            assertEquals(expected, format.toString());
                                                                                        }

    @Test
                                                                                        public void testToStringWithSomeFieldsSet() {
                                                                                            CSVFormat format = CSVFormat.newFormat('\t')
                                                                                                .withEscape('\\')
                                                                                                .withQuote('"')
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withSkipHeaderRecord(false);
                                                                                            
                                                                                            String expected = "Delimiter=<\t> Escape=<\\> QuoteChar=<\"> SkipHeaderRecord:false";
                                                                                            
                                                                                            assertEquals(expected, format.toString());
                                                                                        }

    @Test
                                                                                        public void testToStringWithNullString() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT
                                                                                                .withNullString("NULL");
                                                                                            
                                                                                            String expected = "Delimiter=<,> NullString=<NULL> SkipHeaderRecord:false";
                                                                                            
                                                                                            assertEquals(expected, format.toString());
                                                                                        }

    @Test
                                                                                        public void testToStringWithRecordSeparator() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT
                                                                                                .withRecordSeparator("\n");
                                                                                            
                                                                                            String expected = "Delimiter=<,> RecordSeparator=<\n> SkipHeaderRecord:false";
                                                                                            
                                                                                            assertEquals(expected, format.toString());
                                                                                        }

    @Test
                                                                                        public void testToStringWithHeader() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT
                                                                                                .withHeader("name", "age", "city");
                                                                                            
                                                                                            String expected = "Delimiter=<,> SkipHeaderRecord:false Header:[name, age, city]";
                                                                                            
                                                                                            assertEquals(expected, format.toString());
                                                                                        }

    @Test
                                                                                        public void testToStringWithIgnoreFlags() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT
                                                                                                .withIgnoreEmptyLines(true)
                                                                                                .withIgnoreSurroundingSpaces(true);
                                                                                            
                                                                                            String expected = "Delimiter=<,> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:false";
                                                                                            
                                                                                            assertEquals(expected, format.toString());
                                                                                        }

    @Test
                                                                                        public void testToStringWithSkipHeaderRecord() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT
                                                                                                .withSkipHeaderRecord(true);
                                                                                            
                                                                                            String expected = "Delimiter=<,> SkipHeaderRecord:true";
                                                                                            
                                                                                            assertEquals(expected, format.toString());
                                                                                        }

    @Test
                                                                                        public void testIsEscapeCharacterSet() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isEscapeCharacterSet");
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            CSVFormat formatWithEscape = CSVFormat.DEFAULT.withEscape('\\');
                                                                                            assertTrue((boolean) method.invoke(formatWithEscape));
                                                                                            
                                                                                            CSVFormat formatWithoutEscape = CSVFormat.DEFAULT.withEscape(null);
                                                                                            assertFalse((boolean) method.invoke(formatWithoutEscape));
                                                                                        }

    @Test
                                                                                        public void testIsQuoteCharacterSet() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isQuoteCharacterSet");
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            CSVFormat formatWithQuote = CSVFormat.DEFAULT.withQuote('"');
                                                                                            assertTrue((boolean) method.invoke(formatWithQuote));
                                                                                            
                                                                                            CSVFormat formatWithoutQuote = CSVFormat.DEFAULT.withQuote(null);
                                                                                            assertFalse((boolean) method.invoke(formatWithoutQuote));
                                                                                        }

    @Test
                                                                                        public void testIsCommentMarkerSet() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isCommentMarkerSet");
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            CSVFormat formatWithComment = CSVFormat.DEFAULT.withCommentMarker('#');
                                                                                            assertTrue((boolean) method.invoke(formatWithComment));
                                                                                            
                                                                                            CSVFormat formatWithoutComment = CSVFormat.DEFAULT.withCommentMarker(null);
                                                                                            assertFalse((boolean) method.invoke(formatWithoutComment));
                                                                                        }

    @Test
                                                                                        public void testIsNullStringSet() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isNullStringSet");
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            CSVFormat formatWithNullString = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                            assertTrue((boolean) method.invoke(formatWithNullString));
                                                                                            
                                                                                            CSVFormat formatWithoutNullString = CSVFormat.DEFAULT.withNullString(null);
                                                                                            assertFalse((boolean) method.invoke(formatWithoutNullString));
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarkerChar() throws Exception {
                                                                                            // Setup
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            char commentMarker = '#';
                                                                                            
                                                                                            // Invoke private isLineBreak method using reflection
                                                                                            Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                            isLineBreakMethod.setAccessible(true);
                                                                                            
                                                                                            // Test with valid comment marker
                                                                                            CSVFormat result = format.withCommentMarker(commentMarker);
                                                                                            assertNotNull(result);
                                                                                            assertEquals(Character.valueOf(commentMarker), result.getCommentMarker());
                                                                                            
                                                                                            // Test with line break character (should throw exception)
                                                                                            try {
                                                                                                format.withCommentMarker('\n');
                                                                                                fail("Expected IllegalArgumentException");
                                                                                            } catch (IllegalArgumentException e) {
                                                                                                assertEquals("The comment start marker character cannot be a line break", e.getMessage());
                                                                                            }
                                                                                            
                                                                                            try {
                                                                                                format.withCommentMarker('\r');
                                                                                                fail("Expected IllegalArgumentException");
                                                                                            } catch (IllegalArgumentException e) {
                                                                                                assertEquals("The comment start marker character cannot be a line break", e.getMessage());
                                                                                            }
                                                                                            
                                                                                            // Verify isLineBreak method works correctly
                                                                                            assertTrue((Boolean) isLineBreakMethod.invoke(null, '\n'));
                                                                                            assertTrue((Boolean) isLineBreakMethod.invoke(null, '\r'));
                                                                                            assertFalse((Boolean) isLineBreakMethod.invoke(null, '#'));
                                                                                            assertFalse((Boolean) isLineBreakMethod.invoke(null, ','));
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarkerCharEquals() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withCommentMarker('#');
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withCommentMarker('#');
                                                                                            assertEquals(format1, format2);
                                                                                            assertEquals(format1.hashCode(), format2.hashCode());
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarkerCharNotEquals() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withCommentMarker('#');
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withCommentMarker(';');
                                                                                            assertNotEquals(format1, format2);
                                                                                            assertNotEquals(format1.hashCode(), format2.hashCode());
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarker_ValidCharacter() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#');
                                                                                            assertNotNull(format);
                                                                                            assertEquals(Character.valueOf('#'), format.getCommentMarker());
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarker_Null() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withCommentMarker(null);
                                                                                            assertNotNull(format);
                                                                                            assertNull(format.getCommentMarker());
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithCommentMarker_LineBreakCR() {
                                                                                            CSVFormat.DEFAULT.withCommentMarker('\r');
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithCommentMarker_LineBreakLF() {
                                                                                            CSVFormat.DEFAULT.withCommentMarker('\n');
                                                                                        }

    @Test
                                                                                        public void testIsLineBreak_PrivateMethod() throws Exception {
                                                                                            Method isLineBreakChar = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                            isLineBreakChar.setAccessible(true);
                                                                                            
                                                                                            assertTrue((boolean) isLineBreakChar.invoke(null, '\n'));
                                                                                            assertTrue((boolean) isLineBreakChar.invoke(null, '\r'));
                                                                                            assertFalse((boolean) isLineBreakChar.invoke(null, 'a'));
                                                                                            assertFalse((boolean) isLineBreakChar.invoke(null, '#'));
                                                                                        }

    @Test
                                                                                        public void testIsLineBreak_Character_PrivateMethod() throws Exception {
                                                                                            Method isLineBreakCharacter = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                            isLineBreakCharacter.setAccessible(true);
                                                                                            
                                                                                            assertTrue((boolean) isLineBreakCharacter.invoke(null, Character.valueOf('\n')));
                                                                                            assertTrue((boolean) isLineBreakCharacter.invoke(null, Character.valueOf('\r')));
                                                                                            assertFalse((boolean) isLineBreakCharacter.invoke(null, Character.valueOf('a')));
                                                                                            assertFalse((boolean) isLineBreakCharacter.invoke(null, Character.valueOf('#')));
                                                                                            assertFalse((boolean) isLineBreakCharacter.invoke(null, (Character) null));
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarker_OtherFieldsPreserved() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT
                                                                                                .withDelimiter(';')
                                                                                                .withQuote('"')
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreSurroundingSpaces(true)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withNullString("NULL");
                                                                                            
                                                                                            CSVFormat modified = original.withCommentMarker('#');
                                                                                            
                                                                                            assertEquals(';', modified.getDelimiter());
                                                                                            assertEquals(Character.valueOf('"'), modified.getQuoteCharacter());
                                                                                            assertEquals(Character.valueOf('\\'), modified.getEscapeCharacter());
                                                                                            assertTrue(modified.getIgnoreSurroundingSpaces());
                                                                                            assertFalse(modified.getIgnoreEmptyLines());
                                                                                            assertEquals("NULL", modified.getNullString());
                                                                                            assertEquals(Character.valueOf('#'), modified.getCommentMarker());
                                                                                        }

    @Test
                                                                                        public void testWithDelimiterWithValidCharacter() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
                                                                                            assertEquals(';', format.getDelimiter());
                                                                                        }

    @Test
                                                                                        public void testWithDelimiterReturnsNewInstance() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            CSVFormat modified = original.withDelimiter('|');
                                                                                            assertNotSame(original, modified);
                                                                                            assertEquals('|', modified.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                            assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                            assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                            assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                            assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                            assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                            assertEquals(original.getNullString(), modified.getNullString());
                                                                                            assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                            assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                            assertEquals(original.getAllowMissingColumnNames(), modified.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testWithEscapeChar() throws Exception {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            char escape = '\\';
                                                                                            
                                                                                            CSVFormat newFormat = format.withEscape(escape);
                                                                                            
                                                                                            assertEquals(Character.valueOf(escape), newFormat.getEscapeCharacter());
                                                                                            assertNotSame(format, newFormat);
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithEscapeCharLineBreak() {
                                                                                            CSVFormat.DEFAULT.withEscape('\n');
                                                                                        }

    @Test
                                                                                        public void testWithEscapeCharCallsWithEscapeCharacter() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("withEscape", Character.class);
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            char escape = '\\';
                                                                                            CSVFormat result = (CSVFormat) method.invoke(CSVFormat.DEFAULT, Character.valueOf(escape));
                                                                                            
                                                                                            assertEquals(Character.valueOf(escape), result.getEscapeCharacter());
                                                                                        }

    @Test
                                                                                        public void testWithEscapeCharPreservesOtherProperties() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT
                                                                                                .withDelimiter(';')
                                                                                                .withQuote('"')
                                                                                                .withCommentMarker('#')
                                                                                                .withIgnoreSurroundingSpaces(true)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withRecordSeparator("\r\n")
                                                                                                .withNullString("NULL")
                                                                                                .withHeader("Header1", "Header2")
                                                                                                .withSkipHeaderRecord(true)
                                                                                                .withAllowMissingColumnNames(true);
                                                                                            
                                                                                            CSVFormat newFormat = original.withEscape('\\');
                                                                                            
                                                                                            assertEquals(';', newFormat.getDelimiter());
                                                                                            assertEquals(Character.valueOf('"'), newFormat.getQuoteCharacter());
                                                                                            assertEquals(Character.valueOf('#'), newFormat.getCommentMarker());
                                                                                            assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertFalse(newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals("\r\n", newFormat.getRecordSeparator());
                                                                                            assertEquals("NULL", newFormat.getNullString());
                                                                                            assertArrayEquals(new String[]{"Header1", "Header2"}, newFormat.getHeader());
                                                                                            assertTrue(newFormat.getSkipHeaderRecord());
                                                                                            assertTrue(newFormat.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testWithEscape_ValidCharacter() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            char escape = '\\';
                                                                                            CSVFormat newFormat = original.withEscape(escape);
                                                                                            assertEquals(Character.valueOf(escape), newFormat.getEscapeCharacter());
                                                                                        }

    @Test
                                                                                        public void testWithEscape_NullCharacter() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            CSVFormat newFormat = original.withEscape((Character) null);
                                                                                            assertNull(newFormat.getEscapeCharacter());
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithEscape_LineBreakCharacter() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            original.withEscape('\n');
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithEscape_CarriageReturnCharacter() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            original.withEscape('\r');
                                                                                        }

    @Test
                                                                                        public void testIsLineBreak_Char() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                            assertFalse((boolean) method.invoke(null, '\\'));
                                                                                        }

    @Test
                                                                                        public void testIsLineBreak_Character() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            assertTrue((boolean) method.invoke(null, Character.valueOf('\n')));
                                                                                            assertTrue((boolean) method.invoke(null, Character.valueOf('\r')));
                                                                                            assertFalse((boolean) method.invoke(null, Character.valueOf('a')));
                                                                                            assertFalse((boolean) method.invoke(null, Character.valueOf('\\')));
                                                                                            assertFalse((boolean) method.invoke(null, (Character) null));
                                                                                        }

    @Test
                                                                                        public void testWithEscape_PreservesOtherSettings() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT
                                                                                                .withDelimiter(';')
                                                                                                .withQuote('"')
                                                                                                .withCommentMarker('#')
                                                                                                .withIgnoreSurroundingSpaces(true)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withRecordSeparator("\r\n")
                                                                                                .withNullString("NULL")
                                                                                                .withHeader("col1", "col2")
                                                                                                .withSkipHeaderRecord(true)
                                                                                                .withAllowMissingColumnNames(true);
                                                                                            
                                                                                            CSVFormat newFormat = original.withEscape('\\');
                                                                                            
                                                                                            assertEquals(';', newFormat.getDelimiter());
                                                                                            assertEquals(Character.valueOf('"'), newFormat.getQuoteCharacter());
                                                                                            assertEquals(Character.valueOf('#'), newFormat.getCommentMarker());
                                                                                            assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertFalse(newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals("\r\n", newFormat.getRecordSeparator());
                                                                                            assertEquals("NULL", newFormat.getNullString());
                                                                                            assertArrayEquals(new String[]{"col1", "col2"}, newFormat.getHeader());
                                                                                            assertTrue(newFormat.getSkipHeaderRecord());
                                                                                            assertTrue(newFormat.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarker() throws Exception {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            Character commentMarker = '#';
                                                                                            
                                                                                            CSVFormat modified = original.withCommentMarker(commentMarker);
                                                                                            
                                                                                            assertEquals(commentMarker, modified.getCommentMarker());
                                                                                            assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithCommentMarkerLineBreak() {
                                                                                            CSVFormat.DEFAULT.withCommentMarker('\n');
                                                                                        }

    @Test
                                                                                        public void testWithDelimiter() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            char delimiter = ';';
                                                                                            
                                                                                            CSVFormat modified = original.withDelimiter(delimiter);
                                                                                            
                                                                                            assertEquals(delimiter, modified.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithDelimiterLineBreak() {
                                                                                            CSVFormat.DEFAULT.withDelimiter('\n');
                                                                                        }

    @Test
                                                                                        public void testWithEscape() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            Character escape = '\\';
                                                                                            
                                                                                            CSVFormat modified = original.withEscape(escape);
                                                                                            
                                                                                            assertEquals(escape, modified.getEscapeCharacter());
                                                                                            assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithEscapeLineBreak() {
                                                                                            CSVFormat.DEFAULT.withEscape('\n');
                                                                                        }

    @Test
                                                                                        public void testWithHeader() {
                                                                                            String[] header = {"col1", "col2"};
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeader(header);
                                                                                            assertArrayEquals(header, format.getHeader());
                                                                                        }

    @Test
                                                                                        public void testWithNullString() {
                                                                                            String nullString = "NULL";
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withNullString(nullString);
                                                                                            assertEquals(nullString, format.getNullString());
                                                                                        }

    @Test
                                                                                        public void testWithQuote() {
                                                                                            Character quote = '\'';
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withQuote(quote);
                                                                                            assertEquals(quote, format.getQuoteCharacter());
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithQuoteLineBreak() {
                                                                                            CSVFormat.DEFAULT.withQuote('\n');
                                                                                        }

    @Test
                                                                                        public void testWithQuoteMode() {
                                                                                            QuoteMode mode = QuoteMode.MINIMAL;
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(mode);
                                                                                            assertEquals(mode, format.getQuoteMode());
                                                                                        }

    @Test
                                                                                        public void testWithRecordSeparator() {
                                                                                            String separator = "\n";
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator(separator);
                                                                                            assertEquals(separator, format.getRecordSeparator());
                                                                                        }

    @Test
                                                                                        public void testWithSkipHeaderRecord() {
                                                                                            boolean skip = true;
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withSkipHeaderRecord(skip);
                                                                                            assertEquals(skip, format.getSkipHeaderRecord());
                                                                                        }

    @Test
                                                                                        public void testWithAllowMissingColumnNames() {
                                                                                            boolean allow = true;
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withAllowMissingColumnNames(allow);
                                                                                            assertEquals(allow, format.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreEmptyLines() {
                                                                                            boolean ignore = true;
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withIgnoreEmptyLines(ignore);
                                                                                            assertEquals(ignore, format.getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreSurroundingSpaces() {
                                                                                            boolean ignore = true;
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(ignore);
                                                                                            assertEquals(ignore, format.getIgnoreSurroundingSpaces());
                                                                                        }

    @Test
                                                                                        public void testIsLineBreakChar1() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                        }

    @Test
                                                                                        public void testIsLineBreakCharacter1() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                            assertFalse((boolean) method.invoke(null, (Character) null));
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarker1() throws Exception {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            CSVFormat newFormat = format.withCommentMarker('#');
                                                                                            
                                                                                            assertEquals(Character.valueOf('#'), newFormat.getCommentMarker());
                                                                                            assertEquals(format.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(format.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(format.getQuoteMode(), newFormat.getQuoteMode());
                                                                                            assertEquals(format.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                            assertEquals(format.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(format.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals(format.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                            assertEquals(format.getNullString(), newFormat.getNullString());
                                                                                            assertArrayEquals(format.getHeader(), newFormat.getHeader());
                                                                                            assertEquals(format.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                            assertEquals(format.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithCommentMarkerLineBreak1() {
                                                                                            CSVFormat.DEFAULT.withCommentMarker('\n');
                                                                                        }

    @Test
                                                                                        public void testWithDelimiter1() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            CSVFormat newFormat = format.withDelimiter(';');
                                                                                            
                                                                                            assertEquals(';', newFormat.getDelimiter());
                                                                                            assertEquals(format.getCommentMarker(), newFormat.getCommentMarker());
                                                                                            assertEquals(format.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(format.getQuoteMode(), newFormat.getQuoteMode());
                                                                                            assertEquals(format.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                            assertEquals(format.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(format.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals(format.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                            assertEquals(format.getNullString(), newFormat.getNullString());
                                                                                            assertArrayEquals(format.getHeader(), newFormat.getHeader());
                                                                                            assertEquals(format.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                            assertEquals(format.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithDelimiterLineBreak1() {
                                                                                            CSVFormat.DEFAULT.withDelimiter('\n');
                                                                                        }

    @Test
                                                                                        public void testWithEscape1() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            CSVFormat newFormat = format.withEscape('\\');
                                                                                            
                                                                                            assertEquals(Character.valueOf('\\'), newFormat.getEscapeCharacter());
                                                                                            assertEquals(format.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(format.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(format.getQuoteMode(), newFormat.getQuoteMode());
                                                                                            assertEquals(format.getCommentMarker(), newFormat.getCommentMarker());
                                                                                            assertEquals(format.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(format.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals(format.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                            assertEquals(format.getNullString(), newFormat.getNullString());
                                                                                            assertArrayEquals(format.getHeader(), newFormat.getHeader());
                                                                                            assertEquals(format.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                            assertEquals(format.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithEscapeLineBreak1() {
                                                                                            CSVFormat.DEFAULT.withEscape('\n');
                                                                                        }

    @Test
                                                                                        public void testWithHeader1() {
                                                                                            String[] header = {"col1", "col2", "col3"};
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            CSVFormat newFormat = format.withHeader(header);
                                                                                            
                                                                                            assertArrayEquals(header, newFormat.getHeader());
                                                                                            assertEquals(format.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(format.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(format.getQuoteMode(), newFormat.getQuoteMode());
                                                                                            assertEquals(format.getCommentMarker(), newFormat.getCommentMarker());
                                                                                            assertEquals(format.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                            assertEquals(format.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(format.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals(format.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                            assertEquals(format.getNullString(), newFormat.getNullString());
                                                                                            assertEquals(format.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                            assertEquals(format.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testWithAllowMissingColumnNames1() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            CSVFormat newFormat = format.withAllowMissingColumnNames(true);
                                                                                            
                                                                                            assertTrue(newFormat.getAllowMissingColumnNames());
                                                                                            assertEquals(format.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(format.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(format.getQuoteMode(), newFormat.getQuoteMode());
                                                                                            assertEquals(format.getCommentMarker(), newFormat.getCommentMarker());
                                                                                            assertEquals(format.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                            assertEquals(format.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(format.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals(format.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                            assertEquals(format.getNullString(), newFormat.getNullString());
                                                                                            assertArrayEquals(format.getHeader(), newFormat.getHeader());
                                                                                            assertEquals(format.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreEmptyLines1() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            CSVFormat newFormat = format.withIgnoreEmptyLines(false);
                                                                                            
                                                                                            assertFalse(newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals(format.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(format.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(format.getQuoteMode(), newFormat.getQuoteMode());
                                                                                            assertEquals(format.getCommentMarker(), newFormat.getCommentMarker());
                                                                                            assertEquals(format.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                            assertEquals(format.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(format.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                            assertEquals(format.getNullString(), newFormat.getNullString());
                                                                                            assertArrayEquals(format.getHeader(), newFormat.getHeader());
                                                                                            assertEquals(format.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                            assertEquals(format.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreSurroundingSpaces1() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            CSVFormat newFormat = format.withIgnoreSurroundingSpaces(true);
                                                                                            
                                                                                            assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(format.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(format.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(format.getQuoteMode(), newFormat.getQuoteMode());
                                                                                            assertEquals(format.getCommentMarker(), newFormat.getCommentMarker());
                                                                                            assertEquals(format.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                            assertEquals(format.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals(format.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                            assertEquals(format.getNullString(), newFormat.getNullString());
                                                                                            assertArrayEquals(format.getHeader(), newFormat.getHeader());
                                                                                            assertEquals(format.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                            assertEquals(format.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testWithNullString1() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            CSVFormat newFormat = format.withNullString("NULL");
                                                                                            
                                                                                            assertEquals("NULL", newFormat.getNullString());
                                                                                            assertEquals(format.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(format.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(format.getQuoteMode(), newFormat.getQuoteMode());
                                                                                            assertEquals(format.getCommentMarker(), newFormat.getCommentMarker());
                                                                                            assertEquals(format.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                            assertEquals(format.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(format.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals(format.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                            assertArrayEquals(format.getHeader(), newFormat.getHeader());
                                                                                            assertEquals(format.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                            assertEquals(format.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testWithQuote1() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            CSVFormat newFormat = format.withQuote('\'');
                                                                                            
                                                                                            assertEquals(Character.valueOf('\''), newFormat.getQuoteCharacter());
                                                                                            assertEquals(format.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(format.getQuoteMode(), newFormat.getQuoteMode());
                                                                                            assertEquals(format.getCommentMarker(), newFormat.getCommentMarker());
                                                                                            assertEquals(format.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                            assertEquals(format.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(format.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals(format.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                            assertEquals(format.getNullString(), newFormat.getNullString());
                                                                                            assertArrayEquals(format.getHeader(), newFormat.getHeader());
                                                                                            assertEquals(format.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                            assertEquals(format.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithQuoteLineBreak1() {
                                                                                            CSVFormat.DEFAULT.withQuote('\n');
                                                                                        }

    @Test
                                                                                        public void testWithQuoteMode1() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            CSVFormat newFormat = format.withQuoteMode(QuoteMode.ALL);
                                                                                            
                                                                                            assertEquals(QuoteMode.ALL, newFormat.getQuoteMode());
                                                                                            assertEquals(format.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(format.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(format.getCommentMarker(), newFormat.getCommentMarker());
                                                                                            assertEquals(format.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                            assertEquals(format.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(format.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals(format.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                            assertEquals(format.getNullString(), newFormat.getNullString());
                                                                                            assertArrayEquals(format.getHeader(), newFormat.getHeader());
                                                                                            assertEquals(format.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                            assertEquals(format.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testWithRecordSeparator1() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            CSVFormat newFormat = format.withRecordSeparator("|");
                                                                                            
                                                                                            assertEquals("|", newFormat.getRecordSeparator());
                                                                                            assertEquals(format.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(format.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(format.getQuoteMode(), newFormat.getQuoteMode());
                                                                                            assertEquals(format.getCommentMarker(), newFormat.getCommentMarker());
                                                                                            assertEquals(format.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                            assertEquals(format.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(format.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals(format.getNullString(), newFormat.getNullString());
                                                                                            assertArrayEquals(format.getHeader(), newFormat.getHeader());
                                                                                            assertEquals(format.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                            assertEquals(format.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testWithSkipHeaderRecord1() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            CSVFormat newFormat = format.withSkipHeaderRecord(true);
                                                                                            
                                                                                            assertTrue(newFormat.getSkipHeaderRecord());
                                                                                            assertEquals(format.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(format.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(format.getQuoteMode(), newFormat.getQuoteMode());
                                                                                            assertEquals(format.getCommentMarker(), newFormat.getCommentMarker());
                                                                                            assertEquals(format.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                            assertEquals(format.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(format.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals(format.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                            assertEquals(format.getNullString(), newFormat.getNullString());
                                                                                            assertArrayEquals(format.getHeader(), newFormat.getHeader());
                                                                                            assertEquals(format.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testIsLineBreakChar2() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                            assertFalse((boolean) method.invoke(null, ' '));
                                                                                        }

    @Test
                                                                                        public void testIsLineBreakCharacter2() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                            assertFalse((boolean) method.invoke(null, ' '));
                                                                                            assertFalse((boolean) method.invoke(null, (Character) null));
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarker2() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            Character commentMarker = '#';
                                                                                            
                                                                                            CSVFormat newFormat = original.withCommentMarker(commentMarker);
                                                                                            
                                                                                            assertEquals(commentMarker, newFormat.getCommentMarker());
                                                                                            assertEquals(original.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithCommentMarkerLineBreak2() {
                                                                                            CSVFormat.DEFAULT.withCommentMarker('\n');
                                                                                        }

    @Test
                                                                                        public void testWithDelimiter2() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            char delimiter = ';';
                                                                                            
                                                                                            CSVFormat newFormat = original.withDelimiter(delimiter);
                                                                                            
                                                                                            assertEquals(delimiter, newFormat.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithDelimiterLineBreak2() {
                                                                                            CSVFormat.DEFAULT.withDelimiter('\n');
                                                                                        }

    @Test
                                                                                        public void testWithEscape2() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            Character escape = '\\';
                                                                                            
                                                                                            CSVFormat newFormat = original.withEscape(escape);
                                                                                            
                                                                                            assertEquals(escape, newFormat.getEscapeCharacter());
                                                                                            assertEquals(original.getDelimiter(), newFormat.getDelimiter());
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithEscapeLineBreak2() {
                                                                                            CSVFormat.DEFAULT.withEscape('\n');
                                                                                        }

    @Test
                                                                                        public void testWithHeader2() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            String[] header = {"col1", "col2"};
                                                                                            
                                                                                            CSVFormat newFormat = original.withHeader(header);
                                                                                            
                                                                                            assertArrayEquals(header, newFormat.getHeader());
                                                                                            assertEquals(original.getDelimiter(), newFormat.getDelimiter());
                                                                                        }

    @Test
                                                                                        public void testWithNullString2() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            String nullString = "NULL";
                                                                                            
                                                                                            CSVFormat newFormat = original.withNullString(nullString);
                                                                                            
                                                                                            assertEquals(nullString, newFormat.getNullString());
                                                                                            assertEquals(original.getDelimiter(), newFormat.getDelimiter());
                                                                                        }

    @Test
                                                                                        public void testWithQuote2() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            Character quote = '\'';
                                                                                            
                                                                                            CSVFormat newFormat = original.withQuote(quote);
                                                                                            
                                                                                            assertEquals(quote, newFormat.getQuoteCharacter());
                                                                                            assertEquals(original.getDelimiter(), newFormat.getDelimiter());
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithQuoteLineBreak2() {
                                                                                            CSVFormat.DEFAULT.withQuote('\n');
                                                                                        }

    @Test
                                                                                        public void testWithRecordSeparator2() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            String recordSeparator = "\n";
                                                                                            
                                                                                            CSVFormat newFormat = original.withRecordSeparator(recordSeparator);
                                                                                            
                                                                                            assertEquals(recordSeparator, newFormat.getRecordSeparator());
                                                                                            assertEquals(original.getDelimiter(), newFormat.getDelimiter());
                                                                                        }

    @Test
                                                                                        public void testIsLineBreakChar3() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                        }

    @Test
                                                                                        public void testIsLineBreakCharacter3() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                            assertFalse((boolean) method.invoke(null, (Character) null));
                                                                                        }

    @Test
                                                                                        public void testValidate() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("validate");
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            // Should not throw exception for valid format
                                                                                            method.invoke(CSVFormat.DEFAULT);
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarker3() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            Character commentMarker = '#';
                                                                                            
                                                                                            CSVFormat newFormat = original.withCommentMarker(commentMarker);
                                                                                            
                                                                                            assertEquals(commentMarker, newFormat.getCommentMarker());
                                                                                            assertNotSame(original, newFormat);
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithCommentMarkerLineBreak3() {
                                                                                            CSVFormat.DEFAULT.withCommentMarker('\n');
                                                                                        }

    @Test
                                                                                        public void testWithDelimiter3() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            char delimiter = ';';
                                                                                            
                                                                                            CSVFormat newFormat = original.withDelimiter(delimiter);
                                                                                            
                                                                                            assertEquals(delimiter, newFormat.getDelimiter());
                                                                                            assertNotSame(original, newFormat);
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithDelimiterLineBreak3() {
                                                                                            CSVFormat.DEFAULT.withDelimiter('\n');
                                                                                        }

    @Test
                                                                                        public void testWithEscape3() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            Character escape = '\\';
                                                                                            
                                                                                            CSVFormat newFormat = original.withEscape(escape);
                                                                                            
                                                                                            assertEquals(escape, newFormat.getEscapeCharacter());
                                                                                            assertNotSame(original, newFormat);
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithEscapeLineBreak3() {
                                                                                            CSVFormat.DEFAULT.withEscape('\n');
                                                                                        }

    @Test
                                                                                        public void testWithHeader3() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            String[] header = {"col1", "col2"};
                                                                                            
                                                                                            CSVFormat newFormat = original.withHeader(header);
                                                                                            
                                                                                            assertArrayEquals(header, newFormat.getHeader());
                                                                                            assertNotSame(original, newFormat);
                                                                                        }

    @Test
                                                                                        public void testWithNullString3() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            String nullString = "NULL";
                                                                                            
                                                                                            CSVFormat newFormat = original.withNullString(nullString);
                                                                                            
                                                                                            assertEquals(nullString, newFormat.getNullString());
                                                                                            assertNotSame(original, newFormat);
                                                                                        }

    @Test
                                                                                        public void testWithQuote3() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            Character quote = '\'';
                                                                                            
                                                                                            CSVFormat newFormat = original.withQuote(quote);
                                                                                            
                                                                                            assertEquals(quote, newFormat.getQuoteCharacter());
                                                                                            assertNotSame(original, newFormat);
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithQuoteLineBreak3() {
                                                                                            CSVFormat.DEFAULT.withQuote('\n');
                                                                                        }

    @Test
                                                                                        public void testWithQuoteMode2() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            QuoteMode quoteMode = QuoteMode.MINIMAL;
                                                                                            
                                                                                            CSVFormat newFormat = original.withQuoteMode(quoteMode);
                                                                                            
                                                                                            assertEquals(quoteMode, newFormat.getQuoteMode());
                                                                                            assertNotSame(original, newFormat);
                                                                                        }

    @Test
                                                                                        public void testWithRecordSeparator3() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            String recordSeparator = "\n";
                                                                                            
                                                                                            CSVFormat newFormat = original.withRecordSeparator(recordSeparator);
                                                                                            
                                                                                            assertEquals(recordSeparator, newFormat.getRecordSeparator());
                                                                                            assertNotSame(original, newFormat);
                                                                                        }

    @Test
                                                                                        public void testWithSkipHeaderRecord2() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            boolean skipHeaderRecord = true;
                                                                                            
                                                                                            CSVFormat newFormat = original.withSkipHeaderRecord(skipHeaderRecord);
                                                                                            
                                                                                            assertEquals(skipHeaderRecord, newFormat.getSkipHeaderRecord());
                                                                                            assertNotSame(original, newFormat);
                                                                                        }

    @Test
                                                                                        public void testWithAllowMissingColumnNames2() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            boolean allowMissingColumnNames = true;
                                                                                            
                                                                                            CSVFormat newFormat = original.withAllowMissingColumnNames(allowMissingColumnNames);
                                                                                            
                                                                                            assertEquals(allowMissingColumnNames, newFormat.getAllowMissingColumnNames());
                                                                                            assertNotSame(original, newFormat);
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreEmptyLines2() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            boolean ignoreEmptyLines = false;
                                                                                            
                                                                                            CSVFormat newFormat = original.withIgnoreEmptyLines(ignoreEmptyLines);
                                                                                            
                                                                                            assertEquals(ignoreEmptyLines, newFormat.getIgnoreEmptyLines());
                                                                                            assertNotSame(original, newFormat);
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreSurroundingSpaces2() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            boolean ignoreSurroundingSpaces = true;
                                                                                            
                                                                                            CSVFormat newFormat = original.withIgnoreSurroundingSpaces(ignoreSurroundingSpaces);
                                                                                            
                                                                                            assertEquals(ignoreSurroundingSpaces, newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertNotSame(original, newFormat);
                                                                                        }

    @Test
                                                                                        public void testIsLineBreakChar4() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                        }

    @Test
                                                                                        public void testIsLineBreakCharacter4() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                            assertFalse((boolean) method.invoke(null, (Character) null));
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarker4() throws Exception {
                                                                                            // Test with valid comment marker
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#');
                                                                                            assertEquals(Character.valueOf('#'), format.getCommentMarker());
                                                                                            
                                                                                            // Test with null comment marker
                                                                                            format = CSVFormat.DEFAULT.withCommentMarker((Character) null);
                                                                                            assertNull(format.getCommentMarker());
                                                                                            
                                                                                            // Test with line break (should throw exception)
                                                                                            try {
                                                                                                CSVFormat.DEFAULT.withCommentMarker('\n');
                                                                                                fail("Expected IllegalArgumentException");
                                                                                            } catch (IllegalArgumentException e) {
                                                                                                assertEquals("The comment start marker character cannot be a line break", e.getMessage());
                                                                                            }
                                                                                        }

    @Test
                                                                                        public void testWithDelimiter4() throws Exception {
                                                                                            // Test with valid delimiter
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
                                                                                            assertEquals(';', format.getDelimiter());
                                                                                            
                                                                                            // Test with line break (should throw exception)
                                                                                            try {
                                                                                                CSVFormat.DEFAULT.withDelimiter('\n');
                                                                                                fail("Expected IllegalArgumentException");
                                                                                            } catch (IllegalArgumentException e) {
                                                                                                assertEquals("The delimiter cannot be a line break", e.getMessage());
                                                                                            }
                                                                                        }

    @Test
                                                                                        public void testWithEscape4() throws Exception {
                                                                                            // Test with valid escape character
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withEscape('\\');
                                                                                            assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
                                                                                            
                                                                                            // Test with null escape character
                                                                                            format = CSVFormat.DEFAULT.withEscape((Character) null);
                                                                                            assertNull(format.getEscapeCharacter());
                                                                                            
                                                                                            // Test with line break (should throw exception)
                                                                                            try {
                                                                                                CSVFormat.DEFAULT.withEscape('\n');
                                                                                                fail("Expected IllegalArgumentException");
                                                                                            } catch (IllegalArgumentException e) {
                                                                                                assertEquals("The escape character cannot be a line break", e.getMessage());
                                                                                            }
                                                                                        }

    @Test
                                                                                        public void testWithHeader4() throws Exception {
                                                                                            // Test with header array
                                                                                            String[] headers = {"col1", "col2", "col3"};
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeader(headers);
                                                                                            assertArrayEquals(headers, format.getHeader());
                                                                                            
                                                                                            // Test with null header
                                                                                            format = CSVFormat.DEFAULT.withHeader((String[]) null);
                                                                                            assertNull(format.getHeader());
                                                                                            
                                                                                            // Test with duplicate headers (should throw exception)
                                                                                            try {
                                                                                                CSVFormat.DEFAULT.withHeader("col1", "col1");
                                                                                                fail("Expected IllegalArgumentException");
                                                                                            } catch (IllegalArgumentException e) {
                                                                                                assertTrue(e.getMessage().contains("The header contains a duplicate entry"));
                                                                                            }
                                                                                        }

    @Test
                                                                                        public void testWithNullString4() throws Exception {
                                                                                            // Test with null string
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                            assertEquals("NULL", format.getNullString());
                                                                                            
                                                                                            // Test with null
                                                                                            format = CSVFormat.DEFAULT.withNullString(null);
                                                                                            assertNull(format.getNullString());
                                                                                        }

    @Test
                                                                                        public void testWithQuote4() throws Exception {
                                                                                            // Test with valid quote character
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withQuote('"');
                                                                                            assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
                                                                                            
                                                                                            // Test with null quote character
                                                                                            format = CSVFormat.DEFAULT.withQuote((Character) null);
                                                                                            assertNull(format.getQuoteCharacter());
                                                                                            
                                                                                            // Test with line break (should throw exception)
                                                                                            try {
                                                                                                CSVFormat.DEFAULT.withQuote('\n');
                                                                                                fail("Expected IllegalArgumentException");
                                                                                            } catch (IllegalArgumentException e) {
                                                                                                assertEquals("The quoteChar cannot be a line break", e.getMessage());
                                                                                            }
                                                                                        }

    @Test
                                                                                        public void testWithQuoteMode3() throws Exception {
                                                                                            // Test with valid quote mode
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
                                                                                            assertEquals(QuoteMode.ALL, format.getQuoteMode());
                                                                                        }

    @Test
                                                                                        public void testWithRecordSeparator4() throws Exception {
                                                                                            // Test with valid record separator
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
                                                                                            assertEquals("\r\n", format.getRecordSeparator());
                                                                                            
                                                                                            // Test with single character
                                                                                            format = CSVFormat.DEFAULT.withRecordSeparator('\n');
                                                                                            assertEquals("\n", format.getRecordSeparator());
                                                                                        }

    @Test
                                                                                        public void testWithSkipHeaderRecord3() throws Exception {
                                                                                            // Test with true
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                            assertTrue(format.getSkipHeaderRecord());
                                                                                            
                                                                                            // Test with false
                                                                                            format = CSVFormat.DEFAULT.withSkipHeaderRecord(false);
                                                                                            assertFalse(format.getSkipHeaderRecord());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreSurroundingSpaces3() throws Exception {
                                                                                            // Test with true
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true);
                                                                                            assertTrue(format.getIgnoreSurroundingSpaces());
                                                                                            
                                                                                            // Test with false
                                                                                            format = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(false);
                                                                                            assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreEmptyLines3() throws Exception {
                                                                                            // Test with true
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withIgnoreEmptyLines(true);
                                                                                            assertTrue(format.getIgnoreEmptyLines());
                                                                                            
                                                                                            // Test with false
                                                                                            format = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);
                                                                                            assertFalse(format.getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testWithAllowMissingColumnNames3() throws Exception {
                                                                                            // Test with true
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withAllowMissingColumnNames(true);
                                                                                            assertTrue(format.getAllowMissingColumnNames());
                                                                                            
                                                                                            // Test with false
                                                                                            format = CSVFormat.DEFAULT.withAllowMissingColumnNames(false);
                                                                                            assertFalse(format.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testIsLineBreak() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                            
                                                                                            Method method2 = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                            method2.setAccessible(true);
                                                                                            
                                                                                            assertTrue((boolean) method2.invoke(null, Character.valueOf('\n')));
                                                                                            assertTrue((boolean) method2.invoke(null, Character.valueOf('\r')));
                                                                                            assertFalse((boolean) method2.invoke(null, Character.valueOf('a')));
                                                                                            assertFalse((boolean) method2.invoke(null, (Character) null));
                                                                                        }

    @Test
                                                                                        public void testValidate1() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("validate");
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            // Test valid format
                                                                                            method.invoke(CSVFormat.DEFAULT);
                                                                                            
                                                                                            // Test invalid formats
                                                                                            try {
                                                                                                method.invoke(CSVFormat.DEFAULT.withDelimiter('"').withQuote('"'));
                                                                                                fail("Expected IllegalArgumentException");
                                                                                            } catch (Exception e) {
                                                                                                assertTrue(e.getCause().getMessage().contains("The quoteChar character and the delimiter cannot be the same"));
                                                                                            }
                                                                                        }

    @Test
                                                                                        public void testWithQuoteChar() {
                                                                                            // Test with valid quote character
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withQuote('"');
                                                                                            assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
                                                                                            
                                                                                            // Test with different quote character
                                                                                            format = CSVFormat.DEFAULT.withQuote('\'');
                                                                                            assertEquals(Character.valueOf('\''), format.getQuoteCharacter());
                                                                                            
                                                                                            // Test that original format remains unchanged
                                                                                            assertNull(CSVFormat.DEFAULT.getQuoteCharacter());
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithQuoteCharLineBreakCR() {
                                                                                            CSVFormat.DEFAULT.withQuote('\r');
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithQuoteCharLineBreakLF() {
                                                                                            CSVFormat.DEFAULT.withQuote('\n');
                                                                                        }

    @Test
                                                                                        public void testWithQuoteCharCallsWithQuoteCharacter() throws Exception {
                                                                                            // Use reflection to test private method call
                                                                                            Method withQuoteCharMethod = CSVFormat.class.getDeclaredMethod("withQuote", Character.class);
                                                                                            withQuoteCharMethod.setAccessible(true);
                                                                                            
                                                                                            CSVFormat result = (CSVFormat) withQuoteCharMethod.invoke(CSVFormat.DEFAULT, Character.valueOf('"'));
                                                                                            assertEquals(Character.valueOf('"'), result.getQuoteCharacter());
                                                                                        }

    @Test
                                                                                        public void testWithQuoteCharCreatesNewInstance() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            CSVFormat modified = original.withQuote('"');
                                                                                            assertNotSame(original, modified);
                                                                                            assertFalse(original.equals(modified));
                                                                                        }

    @Test
                                                                                        public void testWithQuoteCharPreservesOtherSettings() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT.withDelimiter(';')
                                                                                                .withEscape('\\')
                                                                                                .withCommentMarker('#')
                                                                                                .withIgnoreSurroundingSpaces(true)
                                                                                                .withIgnoreEmptyLines(false);
                                                                                            
                                                                                            CSVFormat modified = original.withQuote('"');
                                                                                            
                                                                                            assertEquals(';', modified.getDelimiter());
                                                                                            assertEquals(Character.valueOf('\\'), modified.getEscapeCharacter());
                                                                                            assertEquals(Character.valueOf('#'), modified.getCommentMarker());
                                                                                            assertTrue(modified.getIgnoreSurroundingSpaces());
                                                                                            assertFalse(modified.getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testWithQuote_ValidCharacter() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            CSVFormat newFormat = original.withQuote('"');
                                                                                            assertNotNull(newFormat);
                                                                                            assertEquals(Character.valueOf('"'), newFormat.getQuoteCharacter());
                                                                                        }

    @Test
                                                                                        public void testWithQuote_NullCharacter() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            CSVFormat newFormat = original.withQuote((Character) null);
                                                                                            assertNotNull(newFormat);
                                                                                            assertNull(newFormat.getQuoteCharacter());
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithQuote_LineBreakCharacter() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            original.withQuote('\n');
                                                                                        }

    @Test
                                                                                        public void testIsLineBreak_PrivateMethod1() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                            assertFalse((boolean) method.invoke(null, '"'));
                                                                                        }

    @Test
                                                                                        public void testWithQuote_PreservesOtherSettings() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT
                                                                                                .withDelimiter(';')
                                                                                                .withQuoteMode(QuoteMode.ALL)
                                                                                                .withCommentMarker('#')
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreSurroundingSpaces(true)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withRecordSeparator("\n")
                                                                                                .withNullString("NULL")
                                                                                                .withHeader("col1", "col2")
                                                                                                .withSkipHeaderRecord(true)
                                                                                                .withAllowMissingColumnNames(true);
                                                                                            
                                                                                            CSVFormat newFormat = original.withQuote('\'');
                                                                                            
                                                                                            assertEquals(';', newFormat.getDelimiter());
                                                                                            assertEquals(QuoteMode.ALL, newFormat.getQuoteMode());
                                                                                            assertEquals(Character.valueOf('#'), newFormat.getCommentMarker());
                                                                                            assertEquals(Character.valueOf('\\'), newFormat.getEscapeCharacter());
                                                                                            assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertFalse(newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals("\n", newFormat.getRecordSeparator());
                                                                                            assertEquals("NULL", newFormat.getNullString());
                                                                                            assertArrayEquals(new String[]{"col1", "col2"}, newFormat.getHeader());
                                                                                            assertTrue(newFormat.getSkipHeaderRecord());
                                                                                            assertTrue(newFormat.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testWithQuoteMode4() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            QuoteMode newQuoteMode = QuoteMode.MINIMAL;
                                                                                            
                                                                                            CSVFormat modified = original.withQuoteMode(newQuoteMode);
                                                                                            
                                                                                            assertEquals(newQuoteMode, modified.getQuoteMode());
                                                                                            assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                            assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                            assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                            assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                            assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                            assertEquals(original.getNullString(), modified.getNullString());
                                                                                            assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                            assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                            assertEquals(original.getAllowMissingColumnNames(), modified.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testWithNullString5() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            String newNullString = "NA";
                                                                                            
                                                                                            CSVFormat modified = original.withNullString(newNullString);
                                                                                            
                                                                                            assertEquals(newNullString, modified.getNullString());
                                                                                            assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                            assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                            assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                            assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                            assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                            assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                            assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                            assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                            assertEquals(original.getAllowMissingColumnNames(), modified.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testWithHeader5() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            String[] newHeader = {"h1", "h2"};
                                                                                            
                                                                                            CSVFormat modified = original.withHeader(newHeader);
                                                                                            
                                                                                            assertArrayEquals(newHeader, modified.getHeader());
                                                                                            assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                            assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                            assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                            assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                            assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                            assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                            assertEquals(original.getNullString(), modified.getNullString());
                                                                                            assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                            assertEquals(original.getAllowMissingColumnNames(), modified.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testWithAllowMissingColumnNames4() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            boolean newAllowMissingColumnNames = true;
                                                                                            
                                                                                            CSVFormat modified = original.withAllowMissingColumnNames(newAllowMissingColumnNames);
                                                                                            
                                                                                            assertEquals(newAllowMissingColumnNames, modified.getAllowMissingColumnNames());
                                                                                            assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                            assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                            assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                            assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                            assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                            assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                            assertEquals(original.getNullString(), modified.getNullString());
                                                                                            assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                            assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                        }

    @Test
                                                                                        public void testWithSkipHeaderRecord4() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            boolean newSkipHeaderRecord = true;
                                                                                            
                                                                                            CSVFormat modified = original.withSkipHeaderRecord(newSkipHeaderRecord);
                                                                                            
                                                                                            assertEquals(newSkipHeaderRecord, modified.getSkipHeaderRecord());
                                                                                            assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                            assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                            assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                            assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                            assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                            assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                            assertEquals(original.getNullString(), modified.getNullString());
                                                                                            assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                            assertEquals(original.getAllowMissingColumnNames(), modified.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testIsLineBreakChar5() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                            assertFalse((boolean) method.invoke(null, ','));
                                                                                        }

    @Test
                                                                                        public void testIsLineBreakCharacter5() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                            assertFalse((boolean) method.invoke(null, ','));
                                                                                            assertFalse((boolean) method.invoke(null, (Character) null));
                                                                                        }

    @Test
                                                                                        public void testWithRecordSeparatorChar() {
                                                                                            // Test with valid record separator
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator('\n');
                                                                                            assertEquals("\n", format.getRecordSeparator());
                                                                                    
                                                                                            // Test with CR
                                                                                            format = CSVFormat.DEFAULT.withRecordSeparator('\r');
                                                                                            assertEquals("\r", format.getRecordSeparator());
                                                                                    
                                                                                            // Test with TAB (should work even though it's not a standard record separator)
                                                                                            format = CSVFormat.DEFAULT.withRecordSeparator('\t');
                                                                                            assertEquals("\t", format.getRecordSeparator());
                                                                                    
                                                                                            // Test that the method delegates to withRecordSeparator(String)
                                                                                            try {
                                                                                                Method method = CSVFormat.class.getDeclaredMethod("withRecordSeparator", char.class);
                                                                                                CSVFormat spy = spy(CSVFormat.DEFAULT);
                                                                                                method.invoke(spy, ';');
                                                                                                verify(spy).withRecordSeparator(";");
                                                                                            } catch (Exception e) {
                                                                                                fail("Reflection failed: " + e.getMessage());
                                                                                            }
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithRecordSeparatorCharInvalid() {
                                                                                            // This should throw IllegalArgumentException because LF is a line break character
                                                                                            CSVFormat.DEFAULT.withRecordSeparator('\n');
                                                                                        }

    @Test
                                                                                        public void testWithRecordSeparatorCharEquals() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withRecordSeparator(';');
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withRecordSeparator(';');
                                                                                            assertEquals(format1, format2);
                                                                                            assertEquals(format1.hashCode(), format2.hashCode());
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarkerCharacter() throws Exception {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            char commentMarker = '#';
                                                                                            
                                                                                            CSVFormat result = format.withCommentMarker(commentMarker);
                                                                                            
                                                                                            assertNotNull(result);
                                                                                            assertEquals(Character.valueOf(commentMarker), result.getCommentMarker());
                                                                                            assertEquals(format.getDelimiter(), result.getDelimiter());
                                                                                            assertEquals(format.getQuoteCharacter(), result.getQuoteCharacter());
                                                                                            assertEquals(format.getQuoteMode(), result.getQuoteMode());
                                                                                            assertEquals(format.getEscapeCharacter(), result.getEscapeCharacter());
                                                                                            assertEquals(format.getIgnoreSurroundingSpaces(), result.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(format.getIgnoreEmptyLines(), result.getIgnoreEmptyLines());
                                                                                            assertEquals(format.getRecordSeparator(), result.getRecordSeparator());
                                                                                            assertEquals(format.getNullString(), result.getNullString());
                                                                                            assertArrayEquals(format.getHeader(), result.getHeader());
                                                                                            assertEquals(format.getSkipHeaderRecord(), result.getSkipHeaderRecord());
                                                                                            assertEquals(format.getAllowMissingColumnNames(), result.getAllowMissingColumnNames());
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithCommentMarkerLineBreak4() {
                                                                                            CSVFormat.DEFAULT.withCommentMarker('\n');
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarkerNull() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#');
                                                                                            CSVFormat result = format.withCommentMarker(null);
                                                                                            
                                                                                            assertNull(result.getCommentMarker());
                                                                                        }

    @Test
                                                                                        public void testPrivateIsLineBreakChar() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                            assertFalse((boolean) method.invoke(null, ','));
                                                                                        }

    @Test
                                                                                        public void testPrivateIsLineBreakCharacter() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                            assertFalse((boolean) method.invoke(null, ','));
                                                                                            assertFalse((boolean) method.invoke(null, (Character) null));
                                                                                        }

    @Test
                                                                                        public void testWithDelimiter5() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            char delimiter = ';';
                                                                                            
                                                                                            CSVFormat result = format.withDelimiter(delimiter);
                                                                                            
                                                                                            assertEquals(delimiter, result.getDelimiter());
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithDelimiterLineBreak4() {
                                                                                            CSVFormat.DEFAULT.withDelimiter('\n');
                                                                                        }

    @Test
                                                                                        public void testWithEscape5() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            char escape = '\\';
                                                                                            
                                                                                            CSVFormat result = format.withEscape(escape);
                                                                                            
                                                                                            assertEquals(Character.valueOf(escape), result.getEscapeCharacter());
                                                                                        }

    @Test
                                                                                        public void testWithEscapeNull() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withEscape('\\');
                                                                                            CSVFormat result = format.withEscape(null);
                                                                                            
                                                                                            assertNull(result.getEscapeCharacter());
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithEscapeLineBreak4() {
                                                                                            CSVFormat.DEFAULT.withEscape('\n');
                                                                                        }

    @Test
                                                                                        public void testWithHeader6() {
                                                                                            String[] header = {"col1", "col2", "col3"};
                                                                                            CSVFormat result = CSVFormat.DEFAULT.withHeader(header);
                                                                                            
                                                                                            assertArrayEquals(header, result.getHeader());
                                                                                        }

    @Test
                                                                                        public void testWithHeaderNull() {
                                                                                            CSVFormat result = CSVFormat.DEFAULT.withHeader((String[]) null);
                                                                                            
                                                                                            assertNull(result.getHeader());
                                                                                        }

    @Test
                                                                                        public void testWithAllowMissingColumnNames5() {
                                                                                            CSVFormat result = CSVFormat.DEFAULT.withAllowMissingColumnNames(true);
                                                                                            
                                                                                            assertTrue(result.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreEmptyLines4() {
                                                                                            CSVFormat result = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);
                                                                                            
                                                                                            assertFalse(result.getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreSurroundingSpaces4() {
                                                                                            CSVFormat result = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true);
                                                                                            
                                                                                            assertTrue(result.getIgnoreSurroundingSpaces());
                                                                                        }

    @Test
                                                                                        public void testWithNullString6() {
                                                                                            String nullString = "NULL";
                                                                                            CSVFormat result = CSVFormat.DEFAULT.withNullString(nullString);
                                                                                            
                                                                                            assertEquals(nullString, result.getNullString());
                                                                                        }

    @Test
                                                                                        public void testWithNullStringNull() {
                                                                                            CSVFormat result = CSVFormat.DEFAULT.withNullString(null);
                                                                                            
                                                                                            assertNull(result.getNullString());
                                                                                        }

    @Test
                                                                                        public void testWithQuote5() {
                                                                                            char quote = '\'';
                                                                                            CSVFormat result = CSVFormat.DEFAULT.withQuote(quote);
                                                                                            
                                                                                            assertEquals(Character.valueOf(quote), result.getQuoteCharacter());
                                                                                        }

    @Test
                                                                                        public void testWithQuoteNull() {
                                                                                            CSVFormat result = CSVFormat.DEFAULT.withQuote(null);
                                                                                            
                                                                                            assertNull(result.getQuoteCharacter());
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithQuoteLineBreak4() {
                                                                                            CSVFormat.DEFAULT.withQuote('\n');
                                                                                        }

    @Test
                                                                                        public void testWithQuoteMode5() {
                                                                                            QuoteMode mode = QuoteMode.NON_NUMERIC;
                                                                                            CSVFormat result = CSVFormat.DEFAULT.withQuoteMode(mode);
                                                                                            
                                                                                            assertEquals(mode, result.getQuoteMode());
                                                                                        }

    @Test
                                                                                        public void testWithRecordSeparatorString() {
                                                                                            String separator = "|";
                                                                                            CSVFormat result = CSVFormat.DEFAULT.withRecordSeparator(separator);
                                                                                            
                                                                                            assertEquals(separator, result.getRecordSeparator());
                                                                                        }

    @Test
                                                                                        public void testWithRecordSeparatorChar1() {
                                                                                            char separator = '|';
                                                                                            CSVFormat result = CSVFormat.DEFAULT.withRecordSeparator(separator);
                                                                                            
                                                                                            assertEquals(String.valueOf(separator), result.getRecordSeparator());
                                                                                        }

    @Test
                                                                                        public void testWithSkipHeaderRecord5() {
                                                                                            CSVFormat result = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                            
                                                                                            assertTrue(result.getSkipHeaderRecord());
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarker5() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            Character commentMarker = '#';
                                                                                            
                                                                                            CSVFormat newFormat = original.withCommentMarker(commentMarker);
                                                                                            
                                                                                            assertEquals(commentMarker, newFormat.getCommentMarker());
                                                                                            assertEquals(original.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithCommentMarkerLineBreak5() {
                                                                                            CSVFormat.DEFAULT.withCommentMarker('\n');
                                                                                        }

    @Test
                                                                                        public void testWithDelimiter6() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            char delimiter = ';';
                                                                                            
                                                                                            CSVFormat newFormat = original.withDelimiter(delimiter);
                                                                                            
                                                                                            assertEquals(delimiter, newFormat.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithDelimiterLineBreak5() {
                                                                                            CSVFormat.DEFAULT.withDelimiter('\n');
                                                                                        }

    @Test
                                                                                        public void testWithEscape6() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            Character escape = '\\';
                                                                                            
                                                                                            CSVFormat newFormat = original.withEscape(escape);
                                                                                            
                                                                                            assertEquals(escape, newFormat.getEscapeCharacter());
                                                                                            assertEquals(original.getDelimiter(), newFormat.getDelimiter());
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithEscapeLineBreak5() {
                                                                                            CSVFormat.DEFAULT.withEscape('\n');
                                                                                        }

    @Test
                                                                                        public void testWithHeader7() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            String[] header = {"col1", "col2"};
                                                                                            
                                                                                            CSVFormat newFormat = original.withHeader(header);
                                                                                            
                                                                                            assertArrayEquals(header, newFormat.getHeader());
                                                                                            assertEquals(original.getDelimiter(), newFormat.getDelimiter());
                                                                                        }

    @Test
                                                                                        public void testWithNullString7() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            String nullString = "NULL";
                                                                                            
                                                                                            CSVFormat newFormat = original.withNullString(nullString);
                                                                                            
                                                                                            assertEquals(nullString, newFormat.getNullString());
                                                                                            assertEquals(original.getDelimiter(), newFormat.getDelimiter());
                                                                                        }

    @Test
                                                                                        public void testWithQuote6() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            Character quote = '\'';
                                                                                            
                                                                                            CSVFormat newFormat = original.withQuote(quote);
                                                                                            
                                                                                            assertEquals(quote, newFormat.getQuoteCharacter());
                                                                                            assertEquals(original.getDelimiter(), newFormat.getDelimiter());
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testWithQuoteLineBreak5() {
                                                                                            CSVFormat.DEFAULT.withQuote('\n');
                                                                                        }

    @Test
                                                                                        public void testWithRecordSeparator5() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            String recordSeparator = "\n";
                                                                                            
                                                                                            CSVFormat newFormat = original.withRecordSeparator(recordSeparator);
                                                                                            
                                                                                            assertEquals(recordSeparator, newFormat.getRecordSeparator());
                                                                                            assertEquals(original.getDelimiter(), newFormat.getDelimiter());
                                                                                        }

    @Test
                                                                                        public void testWithSkipHeaderRecord6() {
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            boolean skipHeaderRecord = true;
                                                                                            
                                                                                            CSVFormat newFormat = original.withSkipHeaderRecord(skipHeaderRecord);
                                                                                            
                                                                                            assertEquals(skipHeaderRecord, newFormat.getSkipHeaderRecord());
                                                                                            assertEquals(original.getDelimiter(), newFormat.getDelimiter());
                                                                                        }

    @Test
                                                                                        public void testIsLineBreakChar6() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                        }

    @Test
                                                                                        public void testIsLineBreakCharacter6() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            assertTrue((boolean) method.invoke(null, '\n'));
                                                                                            assertTrue((boolean) method.invoke(null, '\r'));
                                                                                            assertFalse((boolean) method.invoke(null, 'a'));
                                                                                            assertFalse((boolean) method.invoke(null, (Character) null));
                                                                                        }

    @Test
                                                                                        public void testValidate2() throws Exception {
                                                                                            Method method = CSVFormat.class.getDeclaredMethod("validate");
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            // Should not throw exception for valid format
                                                                                            method.invoke(CSVFormat.DEFAULT);
                                                                                        }

    @Test
                                                                                    public void testIsLineBreakWithLF1() throws Exception {
                                                                                        final char LF = '\n';
                                                                                        final char CR = '\r';
                                                                                        
                                                                                        Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                        isLineBreakMethod.setAccessible(true);
                                                                                        
                                                                                        boolean result = (boolean) isLineBreakMethod.invoke(null, LF);
                                                                                        assertTrue(result);
                                                                                    }

    @Test
                                                                                    public void testIsLineBreakWithCR1() throws Exception {
                                                                                        final char CR = '\r';
                                                                                        final char LF = '\n';
                                                                                        
                                                                                        Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                        isLineBreakMethod.setAccessible(true);
                                                                                        
                                                                                        boolean result = (boolean) isLineBreakMethod.invoke(null, CR);
                                                                                        assertTrue(result);
                                                                                    }

    @Test
                                                                                    public void testIsLineBreakWithNonLineBreakChar() throws Exception {
                                                                                        Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                        isLineBreakMethod.setAccessible(true);
                                                                                        
                                                                                        boolean result = (boolean) isLineBreakMethod.invoke(null, 'A');
                                                                                        assertFalse(result);
                                                                                    }

    @Test
                                                                                    public void testIsLineBreakWithSpace1() throws Exception {
                                                                                        Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                        isLineBreakMethod.setAccessible(true);
                                                                                        
                                                                                        boolean result = (boolean) isLineBreakMethod.invoke(null, ' ');
                                                                                        assertFalse(result);
                                                                                    }

    @Test
                                                                                    public void testIsLineBreakWithTab() throws Exception {
                                                                                        Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                        isLineBreakMethod.setAccessible(true);
                                                                                        boolean result = (boolean) isLineBreakMethod.invoke(null, '\t');
                                                                                        assertFalse(result);
                                                                                    }

    @Test
                                                                                    public void testIsLineBreakWithZero() throws Exception {
                                                                                        Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                        isLineBreakMethod.setAccessible(true);
                                                                                        boolean result = (boolean) isLineBreakMethod.invoke(null, '\0');
                                                                                        assertFalse(result);
                                                                                    }

    @Test
                                                                                    public void testGetRecordSeparatorWithDefaultFormat() {
                                                                                        final String CRLF = "\r\n";
                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                        assertEquals(CRLF, format.getRecordSeparator());
                                                                                    }

    @Test
                                                                                    public void testGetRecordSeparatorWithExcelFormat() {
                                                                                        CSVFormat format = CSVFormat.EXCEL;
                                                                                        String crlf = "\r\n";
                                                                                        assertEquals(crlf, format.getRecordSeparator());
                                                                                    }

    @Test
                                                                                    public void testGetRecordSeparatorWithMySQLFormat() {
                                                                                        final String LF = "\n";
                                                                                        CSVFormat format = CSVFormat.MYSQL;
                                                                                        assertEquals(LF, format.getRecordSeparator());
                                                                                    }

    @Test
                                                                                    public void testGetRecordSeparatorWithTDFFormat() {
                                                                                        CSVFormat format = CSVFormat.TDF;
                                                                                        String crlf = "\r\n";
                                                                                        assertEquals(crlf, format.getRecordSeparator());
                                                                                    }

    @Test
                                                                                    public void testGetRecordSeparatorWithRFC4180Format() {
                                                                                        CSVFormat format = CSVFormat.RFC4180;
                                                                                        String crlf = "\r\n";
                                                                                        assertEquals(crlf, format.getRecordSeparator());
                                                                                    }

    @Test
                                                                                    public void testHashCodeWithAllFieldsSet() {
                                                                                        CSVFormat format = CSVFormat.newFormat(',')
                                                                                            .withQuote('"')
                                                                                            .withQuoteMode(QuoteMode.ALL)
                                                                                            .withCommentMarker('#')
                                                                                            .withEscape('\\')
                                                                                            .withIgnoreSurroundingSpaces(true)
                                                                                            .withIgnoreEmptyLines(true)
                                                                                            .withRecordSeparator("\r\n")
                                                                                            .withNullString("NULL")
                                                                                            .withHeader("header1", "header2")
                                                                                            .withSkipHeaderRecord(true);
                                                                                        
                                                                                        int expected = 31 * ',' + QuoteMode.ALL.hashCode();
                                                                                        expected = 31 * expected + '"';
                                                                                        expected = 31 * expected + '#';
                                                                                        expected = 31 * expected + '\\';
                                                                                        expected = 31 * expected + "NULL".hashCode();
                                                                                        expected = 31 * expected + 1231; // ignoreSurroundingSpaces
                                                                                        expected = 31 * expected + 1231; // ignoreEmptyLines
                                                                                        expected = 31 * expected + 1231; // skipHeaderRecord
                                                                                        expected = 31 * expected + "\r\n".hashCode();
                                                                                        expected = 31 * expected + Arrays.hashCode(new String[]{"header1", "header2"});
                                                                                        
                                                                                        assertEquals(expected, format.hashCode());
                                                                                    }

    @Test
                                                                                    public void testHashCodeWithSomeFieldsSet() {
                                                                                        CSVFormat format = CSVFormat.newFormat('\t')
                                                                                            .withQuote('\'')
                                                                                            .withQuoteMode(QuoteMode.MINIMAL)
                                                                                            .withNullString("NA")
                                                                                            .withIgnoreSurroundingSpaces(true)
                                                                                            .withIgnoreEmptyLines(false)
                                                                                            .withRecordSeparator("\n")
                                                                                            .withHeader("col1")
                                                                                            .withSkipHeaderRecord(true);
                                                                                        
                                                                                        int expected = 31 * '\t' + QuoteMode.MINIMAL.hashCode();
                                                                                        expected = 31 * expected + '\'';
                                                                                        expected = 31 * expected + 0; // commentMarker
                                                                                        expected = 31 * expected + 0; // escapeCharacter
                                                                                        expected = 31 * expected + "NA".hashCode();
                                                                                        expected = 31 * expected + 1231; // ignoreSurroundingSpaces
                                                                                        expected = 31 * expected + 1237; // ignoreEmptyLines
                                                                                        expected = 31 * expected + 1231; // skipHeaderRecord
                                                                                        expected = 31 * expected + "\n".hashCode();
                                                                                        expected = 31 * expected + Arrays.hashCode(new String[]{"col1"});
                                                                                        
                                                                                        assertEquals(expected, format.hashCode());
                                                                                    }

    @Test
                                                                                    public void testParse() throws IOException {
                                                                                        CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                        Reader mockReader = mock(Reader.class);
                                                                                        CSVParser parser = csvFormat.parse(mockReader);
                                                                                        assertNotNull(parser);
                                                                                        verify(mockReader, never()).close();
                                                                                    }

    @Test
                                                                                    public void testParseWithNullReader() throws IOException {
                                                                                        CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                        thrown.expect(NullPointerException.class);
                                                                                        csvFormat.parse(null);
                                                                                    }

    @Test
                                                                                    public void testParseWithDifferentFormats() throws IOException {
                                                                                        Reader mockReader = mock(Reader.class);
                                                                                        CSVFormat excelFormat = CSVFormat.EXCEL;
                                                                                        CSVParser parser = excelFormat.parse(mockReader);
                                                                                        assertNotNull(parser);
                                                                                        
                                                                                        CSVFormat rfc4180Format = CSVFormat.RFC4180;
                                                                                        parser = rfc4180Format.parse(mockReader);
                                                                                        assertNotNull(parser);
                                                                                    }

    @Test
                                                                                    public void testParseWithCustomFormat() throws IOException {
                                                                                        Reader mockReader = mock(Reader.class);
                                                                                        CSVFormat customFormat = CSVFormat.newFormat('|')
                                                                                            .withQuote('"')
                                                                                            .withRecordSeparator("\n");
                                                                                        
                                                                                        CSVParser parser = customFormat.parse(mockReader);
                                                                                        assertNotNull(parser);
                                                                                    }

    @Test(expected = NullPointerException.class)
                                                                                    public void testPrintWithNullAppendable() throws IOException {
                                                                                        CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                        csvFormat.print(null);
                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                    public void testValidateQuoteCharSameAsDelimiter() throws Exception {
                                                                                        CSVFormat invalidFormat = CSVFormat.newFormat('"').withQuote('"');
                                                                                        Method validateMethod = CSVFormat.class.getDeclaredMethod("validate");
                                                                                        validateMethod.setAccessible(true);
                                                                                        validateMethod.invoke(invalidFormat);
                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                    public void testValidateEscapeCharSameAsDelimiter() throws Exception {
                                                                                        CSVFormat invalidFormat = CSVFormat.newFormat('\\').withEscape('\\');
                                                                                        Method validateMethod = CSVFormat.class.getDeclaredMethod("validate");
                                                                                        validateMethod.setAccessible(true);
                                                                                        validateMethod.invoke(invalidFormat);
                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                    public void testValidateCommentMarkerSameAsDelimiter() throws Exception {
                                                                                        CSVFormat invalidFormat = CSVFormat.newFormat('#').withCommentMarker('#');
                                                                                        Method validateMethod = CSVFormat.class.getDeclaredMethod("validate");
                                                                                        validateMethod.setAccessible(true);
                                                                                        validateMethod.invoke(invalidFormat);
                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                    public void testValidateQuoteCharSameAsCommentMarker() throws Exception {
                                                                                        CSVFormat invalidFormat = CSVFormat.newFormat(',')
                                                                                            .withQuote('"')
                                                                                            .withCommentMarker('"');
                                                                                        Method validateMethod = CSVFormat.class.getDeclaredMethod("validate");
                                                                                        validateMethod.setAccessible(true);
                                                                                        validateMethod.invoke(invalidFormat);
                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                    public void testValidateEscapeCharSameAsCommentMarker() throws Exception {
                                                                                        CSVFormat invalidFormat = CSVFormat.newFormat(',')
                                                                                            .withEscape('\\')
                                                                                            .withCommentMarker('\\');
                                                                                        
                                                                                        Method validateMethod = CSVFormat.class.getDeclaredMethod("validate");
                                                                                        validateMethod.setAccessible(true);
                                                                                        validateMethod.invoke(invalidFormat);
                                                                                    }

    @Test
                                                                                    public void testValidateNoEscapeCharWithQuoteModeNone() throws Exception {
                                                                                        Method validateMethod = CSVFormat.class.getDeclaredMethod("validate");
                                                                                        validateMethod.setAccessible(true);
                                                                                        
                                                                                        CSVFormat invalidFormat = CSVFormat.newFormat(',')
                                                                                            .withQuoteMode(QuoteMode.NONE)
                                                                                            .withEscape(null);
                                                                                        validateMethod.invoke(invalidFormat);
                                                                                    }

    @Test
                                                                                    public void testValidateValidFormat() throws Exception {
                                                                                        CSVFormat validFormat = CSVFormat.newFormat(',')
                                                                                            .withQuote('"')
                                                                                            .withEscape('\\')
                                                                                            .withCommentMarker('#')
                                                                                            .withQuoteMode(QuoteMode.ALL);
                                                                                        
                                                                                        Method validateMethod = CSVFormat.class.getDeclaredMethod("validate");
                                                                                        validateMethod.setAccessible(true);
                                                                                        validateMethod.invoke(validFormat); // Should not throw exception
                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                    public void testWithDelimiterWithLineFeed() {
                                                                                        final char LF = '\n';
                                                                                        CSVFormat.DEFAULT.withDelimiter(LF);
                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                    public void testWithDelimiterWithLineBreak() {
                                                                                        final char LF = '\n';
                                                                                        CSVFormat.DEFAULT.withDelimiter(LF);
                                                                                    }

    @Test
                                                                                    public void testConstructorWithAllParameters() throws Exception {
                                                                                        char delimiter = ',';
                                                                                        Character quoteCharacter = '"';
                                                                                        QuoteMode quoteMode = QuoteMode.ALL;
                                                                                        Character commentMarker = '#';
                                                                                        Character escapeCharacter = '\\';
                                                                                        boolean ignoreSurroundingSpaces = true;
                                                                                        boolean ignoreEmptyLines = true;
                                                                                        String recordSeparator = "\r\n";
                                                                                        String nullString = "NULL";
                                                                                        String[] header = {"col1", "col2"};
                                                                                        boolean skipHeaderRecord = true;
                                                                                        boolean allowMissingColumnNames = true;
                                                                                        
                                                                                        Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                            char.class, Character.class, QuoteMode.class, Character.class, 
                                                                                            Character.class, boolean.class, boolean.class, String.class, 
                                                                                            String.class, String[].class, boolean.class, boolean.class);
                                                                                        constructor.setAccessible(true);
                                                                                        
                                                                                        CSVFormat format = constructor.newInstance(delimiter, quoteCharacter, quoteMode, commentMarker, 
                                                                                            escapeCharacter, ignoreSurroundingSpaces, ignoreEmptyLines, recordSeparator, 
                                                                                            nullString, header, skipHeaderRecord, allowMissingColumnNames);
                                                                                
                                                                                        assertEquals(delimiter, format.getDelimiter());
                                                                                        assertEquals(quoteCharacter, format.getQuoteCharacter());
                                                                                        assertEquals(quoteMode, format.getQuoteMode());
                                                                                        assertEquals(commentMarker, format.getCommentMarker());
                                                                                        assertEquals(escapeCharacter, format.getEscapeCharacter());
                                                                                        assertEquals(ignoreSurroundingSpaces, format.getIgnoreSurroundingSpaces());
                                                                                        assertEquals(ignoreEmptyLines, format.getIgnoreEmptyLines());
                                                                                        assertEquals(recordSeparator, format.getRecordSeparator());
                                                                                        assertEquals(nullString, format.getNullString());
                                                                                        assertArrayEquals(header, format.getHeader());
                                                                                        assertEquals(skipHeaderRecord, format.getSkipHeaderRecord());
                                                                                        assertEquals(allowMissingColumnNames, format.getAllowMissingColumnNames());
                                                                                    }

    @Test
                                                                                    public void testConstructorWithLineBreakDelimiter() {
                                                                                        CSVFormat format = CSVFormat.DEFAULT.withDelimiter('\n')
                                                                                            .withQuote('"')
                                                                                            .withQuoteMode(QuoteMode.ALL)
                                                                                            .withCommentMarker('#')
                                                                                            .withEscape('\\')
                                                                                            .withIgnoreSurroundingSpaces(true)
                                                                                            .withIgnoreEmptyLines(true)
                                                                                            .withRecordSeparator("\r\n")
                                                                                            .withNullString("NULL")
                                                                                            .withHeader("col1")
                                                                                            .withSkipHeaderRecord(true)
                                                                                            .withAllowMissingColumnNames(true);
                                                                                    }

    @Test
                                                                                    public void testConstructorWithAllParameters1() throws Exception {
                                                                                        char delimiter = ',';
                                                                                        Character quoteCharacter = '"';
                                                                                        QuoteMode quoteMode = QuoteMode.ALL;
                                                                                        Character commentMarker = '#';
                                                                                        Character escapeCharacter = '\\';
                                                                                        boolean ignoreSurroundingSpaces = true;
                                                                                        boolean ignoreEmptyLines = true;
                                                                                        String recordSeparator = "\r\n";
                                                                                        String nullString = "NULL";
                                                                                        String[] header = {"col1", "col2"};
                                                                                        boolean skipHeaderRecord = true;
                                                                                        boolean allowMissingColumnNames = true;
                                                                                
                                                                                        Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                            char.class, Character.class, QuoteMode.class, Character.class, 
                                                                                            Character.class, boolean.class, boolean.class, String.class, 
                                                                                            String.class, String[].class, boolean.class, boolean.class);
                                                                                        constructor.setAccessible(true);
                                                                                        
                                                                                        CSVFormat format = constructor.newInstance(delimiter, quoteCharacter, quoteMode, commentMarker, 
                                                                                            escapeCharacter, ignoreSurroundingSpaces, ignoreEmptyLines, recordSeparator, 
                                                                                            nullString, header, skipHeaderRecord, allowMissingColumnNames);
                                                                                
                                                                                        assertEquals(delimiter, format.getDelimiter());
                                                                                        assertEquals(quoteCharacter, format.getQuoteCharacter());
                                                                                        assertEquals(quoteMode, format.getQuoteMode());
                                                                                        assertEquals(commentMarker, format.getCommentMarker());
                                                                                        assertEquals(escapeCharacter, format.getEscapeCharacter());
                                                                                        assertEquals(ignoreSurroundingSpaces, format.getIgnoreSurroundingSpaces());
                                                                                        assertEquals(ignoreEmptyLines, format.getIgnoreEmptyLines());
                                                                                        assertEquals(recordSeparator, format.getRecordSeparator());
                                                                                        assertEquals(nullString, format.getNullString());
                                                                                        assertArrayEquals(header, format.getHeader());
                                                                                        assertEquals(skipHeaderRecord, format.getSkipHeaderRecord());
                                                                                        assertEquals(allowMissingColumnNames, format.getAllowMissingColumnNames());
                                                                                    }

    @Test
                                                                                    public void testConstructorWithLineBreakDelimiter1() {
                                                                                        CSVFormat format = CSVFormat.DEFAULT
                                                                                            .withDelimiter('\n')
                                                                                            .withQuote('"')
                                                                                            .withQuoteMode(QuoteMode.ALL)
                                                                                            .withCommentMarker('#')
                                                                                            .withEscape('\\')
                                                                                            .withIgnoreSurroundingSpaces(true)
                                                                                            .withIgnoreEmptyLines(true)
                                                                                            .withRecordSeparator("\r\n")
                                                                                            .withNullString("NULL")
                                                                                            .withHeader("col1")
                                                                                            .withSkipHeaderRecord(true)
                                                                                            .withAllowMissingColumnNames(true);
                                                                                    }

    @Test
                                                                                    public void testConstructorWithAllParameters2() throws Exception {
                                                                                        char delimiter = ',';
                                                                                        Character quoteCharacter = '"';
                                                                                        QuoteMode quoteMode = QuoteMode.ALL;
                                                                                        Character commentMarker = '#';
                                                                                        Character escapeCharacter = '\\';
                                                                                        boolean ignoreSurroundingSpaces = true;
                                                                                        boolean ignoreEmptyLines = true;
                                                                                        String recordSeparator = "\r\n";
                                                                                        String nullString = "NULL";
                                                                                        String[] header = {"col1", "col2"};
                                                                                        boolean skipHeaderRecord = true;
                                                                                        boolean allowMissingColumnNames = true;
                                                                                
                                                                                        Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                            char.class, Character.class, QuoteMode.class, Character.class, 
                                                                                            Character.class, boolean.class, boolean.class, String.class, 
                                                                                            String.class, String[].class, boolean.class, boolean.class);
                                                                                        constructor.setAccessible(true);
                                                                                        
                                                                                        CSVFormat format = constructor.newInstance(delimiter, quoteCharacter, quoteMode, commentMarker, 
                                                                                            escapeCharacter, ignoreSurroundingSpaces, ignoreEmptyLines, recordSeparator, 
                                                                                            nullString, header, skipHeaderRecord, allowMissingColumnNames);
                                                                                
                                                                                        assertEquals(delimiter, format.getDelimiter());
                                                                                        assertEquals(quoteCharacter, format.getQuoteCharacter());
                                                                                        assertEquals(quoteMode, format.getQuoteMode());
                                                                                        assertEquals(commentMarker, format.getCommentMarker());
                                                                                        assertEquals(escapeCharacter, format.getEscapeCharacter());
                                                                                        assertEquals(ignoreSurroundingSpaces, format.getIgnoreSurroundingSpaces());
                                                                                        assertEquals(ignoreEmptyLines, format.getIgnoreEmptyLines());
                                                                                        assertEquals(recordSeparator, format.getRecordSeparator());
                                                                                        assertEquals(nullString, format.getNullString());
                                                                                        assertArrayEquals(header, format.getHeader());
                                                                                        assertEquals(skipHeaderRecord, format.getSkipHeaderRecord());
                                                                                        assertEquals(allowMissingColumnNames, format.getAllowMissingColumnNames());
                                                                                    }

    @Test
                                                                                    public void testConstructorWithLineBreakDelimiter2() {
                                                                                        Character quoteCharacter = '"';
                                                                                        QuoteMode quoteMode = QuoteMode.ALL;
                                                                                        Character commentMarker = '#';
                                                                                        Character escapeCharacter = '\\';
                                                                                        String recordSeparator = "\r\n";
                                                                                        String[] header = null;
                                                                                        
                                                                                        CSVFormat format = CSVFormat.newFormat('\n')
                                                                                            .withQuote(quoteCharacter)
                                                                                            .withQuoteMode(quoteMode)
                                                                                            .withCommentMarker(commentMarker)
                                                                                            .withEscape(escapeCharacter)
                                                                                            .withIgnoreSurroundingSpaces(false)
                                                                                            .withIgnoreEmptyLines(false)
                                                                                            .withRecordSeparator(recordSeparator)
                                                                                            .withHeader(header)
                                                                                            .withSkipHeaderRecord(false)
                                                                                            .withAllowMissingColumnNames(false);
                                                                                    }

    @Test
                                                                                    public void testConstructorWithAllParameters3() throws Exception {
                                                                                        char delimiter = ',';
                                                                                        Character quoteCharacter = '"';
                                                                                        QuoteMode quoteMode = QuoteMode.ALL;
                                                                                        Character commentMarker = '#';
                                                                                        Character escapeCharacter = '\\';
                                                                                        boolean ignoreSurroundingSpaces = true;
                                                                                        boolean ignoreEmptyLines = true;
                                                                                        String recordSeparator = "\r\n";
                                                                                        String nullString = "NULL";
                                                                                        String[] header = {"col1", "col2"};
                                                                                        boolean skipHeaderRecord = true;
                                                                                        boolean allowMissingColumnNames = true;
                                                                                
                                                                                        Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                            char.class, Character.class, QuoteMode.class, Character.class, 
                                                                                            Character.class, boolean.class, boolean.class, String.class, 
                                                                                            String.class, String[].class, boolean.class, boolean.class);
                                                                                        constructor.setAccessible(true);
                                                                                        
                                                                                        CSVFormat format = constructor.newInstance(delimiter, quoteCharacter, quoteMode, commentMarker, 
                                                                                            escapeCharacter, ignoreSurroundingSpaces, ignoreEmptyLines, recordSeparator, 
                                                                                            nullString, header, skipHeaderRecord, allowMissingColumnNames);
                                                                                
                                                                                        assertEquals(delimiter, format.getDelimiter());
                                                                                        assertEquals(quoteCharacter, format.getQuoteCharacter());
                                                                                        assertEquals(quoteMode, format.getQuoteMode());
                                                                                        assertEquals(commentMarker, format.getCommentMarker());
                                                                                        assertEquals(escapeCharacter, format.getEscapeCharacter());
                                                                                        assertEquals(ignoreSurroundingSpaces, format.getIgnoreSurroundingSpaces());
                                                                                        assertEquals(ignoreEmptyLines, format.getIgnoreEmptyLines());
                                                                                        assertEquals(recordSeparator, format.getRecordSeparator());
                                                                                        assertEquals(nullString, format.getNullString());
                                                                                        assertArrayEquals(header, format.getHeader());
                                                                                        assertEquals(skipHeaderRecord, format.getSkipHeaderRecord());
                                                                                        assertEquals(allowMissingColumnNames, format.getAllowMissingColumnNames());
                                                                                    }

    @Test
                                                                                    public void testConstructorWithLineBreakDelimiter3() throws Exception {
                                                                                        Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                            char.class, Character.class, QuoteMode.class, Character.class, Character.class,
                                                                                            boolean.class, boolean.class, String.class, String.class, String[].class,
                                                                                            boolean.class, boolean.class);
                                                                                        constructor.setAccessible(true);
                                                                                        constructor.newInstance(
                                                                                            '\n', '"', QuoteMode.ALL, '#', '\\',
                                                                                            true, true, "\r\n", "NULL", new String[]{"col1"},
                                                                                            true, true);
                                                                                    }

    @Test
                                                                                    public void testConstructorWithAllParameters4() throws Exception {
                                                                                        char delimiter = ',';
                                                                                        Character quoteChar = '"';
                                                                                        QuoteMode quoteMode = QuoteMode.ALL;
                                                                                        Character commentMarker = '#';
                                                                                        Character escapeCharacter = '\\';
                                                                                        boolean ignoreSurroundingSpaces = true;
                                                                                        boolean ignoreEmptyLines = true;
                                                                                        String recordSeparator = "\r\n";
                                                                                        String nullString = "NULL";
                                                                                        String[] header = {"col1", "col2"};
                                                                                        boolean skipHeaderRecord = true;
                                                                                        boolean allowMissingColumnNames = true;
                                                                                
                                                                                        Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                            char.class, Character.class, QuoteMode.class, Character.class, 
                                                                                            Character.class, boolean.class, boolean.class, String.class, 
                                                                                            String.class, String[].class, boolean.class, boolean.class);
                                                                                        constructor.setAccessible(true);
                                                                                        
                                                                                        CSVFormat format = constructor.newInstance(delimiter, quoteChar, quoteMode, commentMarker, 
                                                                                            escapeCharacter, ignoreSurroundingSpaces, ignoreEmptyLines, recordSeparator, 
                                                                                            nullString, header, skipHeaderRecord, allowMissingColumnNames);
                                                                                
                                                                                        assertEquals(delimiter, format.getDelimiter());
                                                                                        assertEquals(quoteChar, format.getQuoteCharacter());
                                                                                        assertEquals(quoteMode, format.getQuoteMode());
                                                                                        assertEquals(commentMarker, format.getCommentMarker());
                                                                                        assertEquals(escapeCharacter, format.getEscapeCharacter());
                                                                                        assertEquals(ignoreSurroundingSpaces, format.getIgnoreSurroundingSpaces());
                                                                                        assertEquals(ignoreEmptyLines, format.getIgnoreEmptyLines());
                                                                                        assertEquals(recordSeparator, format.getRecordSeparator());
                                                                                        assertEquals(nullString, format.getNullString());
                                                                                        assertArrayEquals(header, format.getHeader());
                                                                                        assertEquals(skipHeaderRecord, format.getSkipHeaderRecord());
                                                                                        assertEquals(allowMissingColumnNames, format.getAllowMissingColumnNames());
                                                                                    }

    @Test
                                                                                    public void testConstructorWithLineBreakDelimiter4() {
                                                                                        Character quoteCharacter = '"';
                                                                                        Character commentMarker = '#';
                                                                                        Character escapeCharacter = '\\';
                                                                                        String[] header = new String[]{"col1"};
                                                                                        CSVFormat format = CSVFormat.DEFAULT.withDelimiter('\n')
                                                                                            .withQuote(quoteCharacter)
                                                                                            .withQuoteMode(QuoteMode.ALL)
                                                                                            .withCommentMarker(commentMarker)
                                                                                            .withEscape(escapeCharacter)
                                                                                            .withIgnoreSurroundingSpaces(true)
                                                                                            .withIgnoreEmptyLines(true)
                                                                                            .withRecordSeparator("\r\n")
                                                                                            .withNullString("NULL")
                                                                                            .withHeader(header)
                                                                                            .withSkipHeaderRecord(true)
                                                                                            .withAllowMissingColumnNames(true);
                                                                                    }

    @Test
                                                                                public void testValidateWithEscapeEqualsDelimiter() {
                                                                                    CSVFormat format = CSVFormat.newFormat(',')
                                                                                        .withQuoteMode(QuoteMode.MINIMAL)
                                                                                        .withEscape(',')
                                                                                        .withRecordSeparator("\n")
                                                                                        .withIgnoreEmptyLines(false)
                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                        .withAllowMissingColumnNames(false)
                                                                                        .withSkipHeaderRecord(false);
                                                                                }

    @Test
                                                                                public void testValidateWithQuoteEqualsComment() {
                                                                                    Character delimiter = ',';
                                                                                    Character quoteCharacter = '#';
                                                                                    QuoteMode quoteMode = null;
                                                                                    Character commentMarker = '#';
                                                                                    Character escapeCharacter = null;
                                                                                    boolean ignoreSurroundingSpaces = false;
                                                                                    boolean ignoreEmptyLines = false;
                                                                                    String recordSeparator = null;
                                                                                    String nullString = null;
                                                                                    String[] header = null;
                                                                                    boolean skipHeaderRecord = false;
                                                                                    boolean allowMissingColumnNames = false;
                                                                                    
                                                                                    CSVFormat format = CSVFormat.newFormat(delimiter)
                                                                                        .withQuote(quoteCharacter)
                                                                                        .withQuoteMode(quoteMode)
                                                                                        .withCommentMarker(commentMarker)
                                                                                        .withEscape(escapeCharacter)
                                                                                        .withIgnoreSurroundingSpaces(ignoreSurroundingSpaces)
                                                                                        .withIgnoreEmptyLines(ignoreEmptyLines)
                                                                                        .withRecordSeparator(recordSeparator)
                                                                                        .withNullString(nullString)
                                                                                        .withHeader(header)
                                                                                        .withSkipHeaderRecord(skipHeaderRecord)
                                                                                        .withAllowMissingColumnNames(allowMissingColumnNames);
                                                                                }

    @Test
                                                                                public void testValidateWithNoEscapeAndQuoteModeNone() throws Exception {
                                                                                    Character delimiter = ',';
                                                                                    Character quoteCharacter = null;
                                                                                    QuoteMode quoteMode = QuoteMode.NONE;
                                                                                    Character commentMarker = null;
                                                                                    Character escapeCharacter = null;
                                                                                    boolean ignoreSurroundingSpaces = false;
                                                                                    boolean ignoreEmptyLines = false;
                                                                                    String recordSeparator = null;
                                                                                    String nullString = null;
                                                                                    String[] header = null;
                                                                                    boolean skipHeaderRecord = false;
                                                                                    boolean allowMissingColumnNames = false;
                                                                                    
                                                                                    Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                        char.class, Character.class, QuoteMode.class, Character.class, Character.class,
                                                                                        boolean.class, boolean.class, String.class, String.class, String[].class,
                                                                                        boolean.class, boolean.class);
                                                                                    constructor.setAccessible(true);
                                                                                    constructor.newInstance(
                                                                                        delimiter, quoteCharacter, quoteMode, commentMarker, escapeCharacter,
                                                                                        ignoreSurroundingSpaces, ignoreEmptyLines, recordSeparator, nullString, header,
                                                                                        skipHeaderRecord, allowMissingColumnNames);
                                                                                }

    @Test
                                                                            public void testGetRecordSeparatorWithCustomFormat() {
                                                                                String customSeparator = "|";
                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                    .withQuote('"')
                                                                                    .withRecordSeparator(customSeparator)
                                                                                    .withIgnoreEmptyLines(false)
                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                    .withAllowMissingColumnNames(false);
                                                                                assertEquals(customSeparator, format.getRecordSeparator());
                                                                            }

    @Test
                                                                    public void testValidateWithEscapeEqualsComment() {
                                                                        CSVFormat format = CSVFormat.newFormat(',')
                                                                            .withQuoteMode(QuoteMode.MINIMAL)
                                                                            .withCommentMarker('#')
                                                                            .withEscape('#')
                                                                            .withIgnoreEmptyLines(false)
                                                                            .withIgnoreSurroundingSpaces(false)
                                                                            .withSkipHeaderRecord(false);
                                                                        
                                                                        assertNotNull(format);
                                                                    }

    @Test
                                                                public void testValidateWithCommentEqualsDelimiter() {
                                                                    CSVFormat format = CSVFormat.newFormat(',')
                                                                            .withQuoteMode(QuoteMode.MINIMAL)
                                                                            .withCommentMarker(',')
                                                                            .withRecordSeparator("\n")
                                                                            .withSkipHeaderRecord(false)
                                                                            .withIgnoreEmptyLines(false);
                                                                }

    @Test
                                                public void testGetRecordSeparatorWithNullSeparator() {
                                                    CSVFormat format = CSVFormat.newFormat(',')
                                                        .withQuote('"')
                                                        .withRecordSeparator(null)
                                                        .withIgnoreEmptyLines(false)
                                                        .withIgnoreSurroundingSpaces(false)
                                                        .withAllowMissingColumnNames(false);
                                                    assertNull(format.getRecordSeparator());
                                                }

    @Test
                                                public void testHashCodeWithNullFields() throws Exception {
                                                    // Create format using reflection since constructor is private
                                                    CSVFormat format = CSVFormat.DEFAULT.withDelimiter(',')
                                                        .withQuote(null)
                                                        .withQuoteMode(null)
                                                        .withCommentMarker(null)
                                                        .withEscape(null)
                                                        .withNullString(null)
                                                        .withIgnoreSurroundingSpaces(false)
                                                        .withIgnoreEmptyLines(false)
                                                        .withSkipHeaderRecord(false)
                                                        .withRecordSeparator(null)
                                                        .withHeader((String[]) null);
                                                
                                                    int expected = 31 * (int)',';
                                                    expected = 31 * expected + 0; // quoteMode
                                                    expected = 31 * expected + 0; // quoteCharacter
                                                    expected = 31 * expected + 0; // commentMarker
                                                    expected = 31 * expected + 0; // escapeCharacter
                                                    expected = 31 * expected + 0; // nullString
                                                    expected = 31 * expected + (false ? 1231 : 1237); // ignoreSurroundingSpaces
                                                    expected = 31 * expected + (false ? 1231 : 1237); // ignoreEmptyLines
                                                    expected = 31 * expected + (false ? 1231 : 1237); // skipHeaderRecord
                                                    expected = 31 * expected + 0; // recordSeparator
                                                    
                                                    assertEquals(expected, format.hashCode());
                                                }

    @Test
                                                public void testPrint() throws IOException {
                                                    StringWriter out = new StringWriter();
                                                    CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                    CSVPrinter printer = csvFormat.print(out);
                                                    assertNotNull(printer);
                                                }

    @Test
                                                public void testPrintWithDifferentFormats() throws IOException {
                                                    StringWriter out = new StringWriter();
                                                    CSVFormat excelFormat = CSVFormat.EXCEL;
                                                    CSVPrinter printer = excelFormat.print(out);
                                                    assertNotNull(printer);
                                                }

    @Test
                                                public void testPrintWithCustomFormat() throws IOException {
                                                    StringWriter out = new StringWriter();
                                                    CSVFormat customFormat = CSVFormat.DEFAULT
                                                        .withDelimiter(';')
                                                        .withQuote('"')
                                                        .withRecordSeparator("\n");
                                                    CSVPrinter printer = customFormat.print(out);
                                                    assertNotNull(printer);
                                                }

    @Test
                                                public void testPrintWithNoQuoteCharacter() throws IOException {
                                                    StringWriter out = new StringWriter();
                                                    CSVFormat noQuoteFormat = CSVFormat.DEFAULT.withQuote(null);
                                                    CSVPrinter printer = noQuoteFormat.print(out);
                                                    assertNotNull(printer);
                                                }

    @Test
                                                public void testPrintWithHeader() throws IOException {
                                                    StringWriter out = new StringWriter();
                                                    CSVFormat withHeaderFormat = CSVFormat.DEFAULT.withHeader("Col1", "Col2", "Col3");
                                                    CSVPrinter printer = withHeaderFormat.print(out);
                                                    assertNotNull(printer);
                                                }

    @Test
                                                public void testHashCodeConsistency() {
                                                    QuoteMode quoteMode = QuoteMode.NON_NUMERIC;
                                                    
                                                    CSVFormat format1 = CSVFormat.newFormat(';')
                                                        .withQuote('"')
                                                        .withQuoteMode(quoteMode)
                                                        .withCommentMarker('!')
                                                        .withEscape('\\')
                                                        .withIgnoreSurroundingSpaces(false)
                                                        .withIgnoreEmptyLines(true)
                                                        .withRecordSeparator("\r\n")
                                                        .withNullString("null")
                                                        .withHeader("a", "b")
                                                        .withSkipHeaderRecord(true);
                                                        
                                                    CSVFormat format2 = CSVFormat.newFormat(';')
                                                        .withQuote('"')
                                                        .withQuoteMode(quoteMode)
                                                        .withCommentMarker('!')
                                                        .withEscape('\\')
                                                        .withIgnoreSurroundingSpaces(false)
                                                        .withIgnoreEmptyLines(true)
                                                        .withRecordSeparator("\r\n")
                                                        .withNullString("null")
                                                        .withHeader("a", "b")
                                                        .withSkipHeaderRecord(true);
                                                        
                                                    assertEquals(format1.hashCode(), format2.hashCode());
                                                }

    @Test
                public void testHashCodeDifferentObjects() {
                    char doubleQuote = '\"';
                    char singleQuote = '\'';
                    
                    CSVFormat format1 = CSVFormat.newFormat(',')
                            .withQuote(doubleQuote)
                            .withQuoteMode(QuoteMode.ALL)
                            .withCommentMarker('#')
                            .withEscape('\\')
                            .withIgnoreSurroundingSpaces(true)
                            .withIgnoreEmptyLines(true)
                            .withRecordSeparator("\r\n")
                            .withNullString("NULL")
                            .withHeader("header1", "header2")
                            .withSkipHeaderRecord(true)
                            .withAllowMissingColumnNames(false);
                    
                    CSVFormat format2 = CSVFormat.newFormat(';')
                            .withQuote(singleQuote)
                            .withQuoteMode(QuoteMode.MINIMAL)
                            .withCommentMarker('!')
                            .withEscape('/')
                            .withIgnoreSurroundingSpaces(false)
                            .withIgnoreEmptyLines(false)
                            .withRecordSeparator("\n")
                            .withNullString("NA")
                            .withHeader("col1")
                            .withSkipHeaderRecord(false)
                            .withAllowMissingColumnNames(true);
                    
                    assertNotEquals(format1.hashCode(), format2.hashCode());
                }

    @Test
            public void testValidateWithQuoteEqualsDelimiter() {
                CSVFormat format = CSVFormat.newFormat(',')
                    .withQuote(',')
                    .withQuoteMode(null)
                    .withEscape(null)
                    .withIgnoreEmptyLines(false)
                    .withIgnoreSurroundingSpaces(false)
                    .withNullString(null)
                    .withRecordSeparator(null)
                    .withHeader((String[]) null)
                    .withSkipHeaderRecord(false);
                
                assertEquals(',', format.getQuoteCharacter().charValue());
                assertEquals(',', format.getDelimiter());
                assertNull(format.getQuoteMode());
                assertFalse(format.getSkipHeaderRecord());
            }


}
