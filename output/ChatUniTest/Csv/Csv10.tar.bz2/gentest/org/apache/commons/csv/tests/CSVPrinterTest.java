package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
 
public class CSVPrinterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test(expected = IllegalArgumentException.class)
                                                public void testConstructorWithNullOut() throws IOException {
                                                    new CSVPrinter(null, CSVFormat.DEFAULT);
                                                }

    @Test(expected = NullPointerException.class)
                                            public void testConstructorWithNullFormat() throws IOException {
                                                Appendable mockAppendable = mock(Appendable.class);
                                                new CSVPrinter(mockAppendable, null);
                                            }

    @Test
                                            public void testConstructorWithValidParameters() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                Appendable mockAppendable = mock(Appendable.class);
                                                CSVFormat format = CSVFormat.DEFAULT;
                                                CSVPrinter printer = new CSVPrinter(mockAppendable, format);
                                            
                                                Field outField = CSVPrinter.class.getDeclaredField("out");
                                                outField.setAccessible(true);
                                                assertEquals(mockAppendable, outField.get(printer));
                                            
                                                Field formatField = CSVPrinter.class.getDeclaredField("format");
                                                formatField.setAccessible(true);
                                                assertEquals(format, formatField.get(printer));
                                            }

    @Test
                                            public void testConstructorWithHeader() throws IOException {
                                                Appendable mockAppendable = mock(Appendable.class);
                                                String[] headers = {"Header1", "Header2"};
                                                CSVFormat formatWithHeader = CSVFormat.DEFAULT.withHeader(headers);
                                                
                                                CSVPrinter printer = new CSVPrinter(mockAppendable, formatWithHeader);
                                                
                                                verify(mockAppendable).append("Header1");
                                                verify(mockAppendable).append(formatWithHeader.getDelimiter());
                                                verify(mockAppendable).append("Header2");
                                                verify(mockAppendable).append(formatWithHeader.getRecordSeparator());
                                            }

    @Test
                                            public void testConstructorWithoutHeader() throws IOException {
                                                Appendable mockAppendable = mock(Appendable.class);
                                                CSVFormat formatWithoutHeader = CSVFormat.DEFAULT;
                                                new CSVPrinter(mockAppendable, formatWithoutHeader);
                                                
                                                verify(mockAppendable, never()).append(anyString());
                                            }

    @Test(expected = IOException.class)
                                            public void testConstructorThrowsIOException() throws IOException {
                                                Appendable mockAppendable = mock(Appendable.class);
                                                when(mockAppendable.append(any(CharSequence.class))).thenThrow(new IOException());
                                                String[] headers = {"Header"};
                                                CSVFormat format = CSVFormat.DEFAULT.withHeader(headers);
                                                
                                                new CSVPrinter(mockAppendable, format);
                                            }


}
