package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
 
public class CSVFormatTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                            public void testPrintAndQuoteWithNullQuoteMode() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod("printAndQuote", 
                                                    Object.class, CharSequence.class, int.class, int.class, Appendable.class, boolean.class);
                                                printAndQuoteMethod.setAccessible(true);
                                                
                                                CSVFormat formatWithNullQuoteMode = CSVFormat.DEFAULT.withQuoteMode(null);
                                                StringWriter out = new StringWriter();
                                                printAndQuoteMethod.invoke(formatWithNullQuoteMode, "value", "value", 0, 5, out, true);
                                                assertEquals("value", out.toString());
                                            }

    @Test
                                            public void testPrintAndQuoteModeAll() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                CSVFormat formatAll = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
                                                Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod("printAndQuote", 
                                                    CharSequence.class, CharSequence.class, int.class, int.class, Appendable.class, boolean.class);
                                                printAndQuoteMethod.setAccessible(true);
                                                
                                                StringWriter out = new StringWriter();
                                                printAndQuoteMethod.invoke(formatAll, "value", "value", 0, 5, out, true);
                                                assertEquals("\"value\"", out.toString());
                                            }

    @Test
                                            public void testPrintAndQuoteModeAllNonNull() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                CSVFormat formatAllNonNull = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL_NON_NULL);
                                                Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod("printAndQuote", 
                                                    Object.class, CharSequence.class, int.class, int.class, Appendable.class, boolean.class);
                                                printAndQuoteMethod.setAccessible(true);
                                                
                                                StringWriter out = new StringWriter();
                                                printAndQuoteMethod.invoke(formatAllNonNull, "value", "value", 0, 5, out, true);
                                                assertEquals("\"value\"", out.toString());
                                            }

    @Test
                                            public void testPrintAndQuoteModeNonNumericWithNumber() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod("printAndQuote", Object.class, CharSequence.class, int.class, int.class, Appendable.class, boolean.class);
                                                printAndQuoteMethod.setAccessible(true);
                                                
                                                CSVFormat formatNonNumeric = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC);
                                                StringWriter out = new StringWriter();
                                                printAndQuoteMethod.invoke(formatNonNumeric, 123, "123", 0, 3, out, true);
                                                assertEquals("123", out.toString());
                                            }

    @Test
                                            public void testPrintAndQuoteModeNonNumericWithString() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                CSVFormat formatNonNumeric = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC);
                                                Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod("printAndQuote", Object.class, CharSequence.class, int.class, int.class, Appendable.class, boolean.class);
                                                printAndQuoteMethod.setAccessible(true);
                                                
                                                StringWriter out = new StringWriter();
                                                printAndQuoteMethod.invoke(formatNonNumeric, "value", "value", 0, 5, out, true);
                                                assertEquals("\"value\"", out.toString());
                                            }

    @Test
                                            public void testPrintAndQuoteModeNone() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod("printAndQuote", 
                                                    CharSequence.class, String.class, int.class, int.class, Appendable.class, boolean.class);
                                                printAndQuoteMethod.setAccessible(true);
                                                
                                                CSVFormat formatNone = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NONE).withEscape('\\');
                                                StringWriter out = new StringWriter();
                                                printAndQuoteMethod.invoke(formatNone, "value", "value", 0, 5, out, true);
                                                assertEquals("value", out.toString());
                                            }

    @Test
                                            public void testPrintAndQuoteModeMinimalEmptyStringNewRecord() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                CSVFormat format = CSVFormat.DEFAULT;
                                                Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod("printAndQuote", 
                                                    Object.class, String.class, int.class, int.class, Appendable.class, boolean.class);
                                                printAndQuoteMethod.setAccessible(true);
                                                
                                                StringWriter out = new StringWriter();
                                                printAndQuoteMethod.invoke(format, "", "", 0, 0, out, true);
                                                assertEquals("\"\"", out.toString());
                                            }

    @Test
                                            public void testPrintAndQuoteModeMinimalEmptyStringNotNewRecord() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                    "printAndQuote", 
                                                    Object.class, 
                                                    String.class, 
                                                    int.class, 
                                                    int.class, 
                                                    Appendable.class, 
                                                    boolean.class
                                                );
                                                printAndQuoteMethod.setAccessible(true);
                                                
                                                StringWriter out = new StringWriter();
                                                printAndQuoteMethod.invoke(format, "", "", 0, 0, out, false);
                                                assertEquals("", out.toString());
                                            }

    @Test
                                            public void testPrintAndQuoteModeMinimalWithSpecialChars() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                // Define constants used in the test
                                                final char COMMENT = '#';
                                                final char LF = '\n';
                                                final char CR = '\r';
                                                final char SP = ' ';
                                                
                                                // Create test objects
                                                CSVFormat format = CSVFormat.DEFAULT;
                                                Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod("printAndQuote", 
                                                    Object.class, CharSequence.class, int.class, int.class, Appendable.class, boolean.class);
                                                printAndQuoteMethod.setAccessible(true);
                                                
                                                StringWriter out = new StringWriter();
                                                String value = "va" + (char)(COMMENT - 1) + "lue";
                                                printAndQuoteMethod.invoke(format, value, value, 0, value.length(), out, true);
                                                assertEquals("\"" + value + "\"", out.toString());
                                            }

    @Test
                                            public void testPrintAndQuoteModeMinimalWithCarriageReturn() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                // Define required constants
                                                final char CR = '\r';
                                                final char LF = '\n';
                                                final char SP = ' ';
                                                final char COMMENT = '#';
                                                
                                                // Create test objects
                                                CSVFormat format = CSVFormat.DEFAULT;
                                                Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod("printAndQuote", 
                                                    Object.class, CharSequence.class, int.class, int.class, Appendable.class, boolean.class);
                                                printAndQuoteMethod.setAccessible(true);
                                                
                                                StringWriter out = new StringWriter();
                                                String value = "va" + CR + "lue";
                                                printAndQuoteMethod.invoke(format, value, value, 0, value.length(), out, true);
                                                assertEquals("\"" + value + "\"", out.toString());
                                            }

    @Test
                                            public void testPrintAndQuoteModeMinimalWithQuoteChar() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                CSVFormat format = CSVFormat.DEFAULT;
                                                Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod("printAndQuote", 
                                                    Object.class, String.class, int.class, int.class, Appendable.class, boolean.class);
                                                printAndQuoteMethod.setAccessible(true);
                                                
                                                StringWriter out = new StringWriter();
                                                String value = "va\"lue";
                                                printAndQuoteMethod.invoke(format, value, value, 0, value.length(), out, true);
                                                assertEquals("\"va\"\"lue\"", out.toString());
                                            }

    @Test
                                            public void testPrintAndQuoteModeMinimalWithDelimiter() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                CSVFormat format = CSVFormat.DEFAULT;
                                                Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod("printAndQuote", 
                                                    Object.class, CharSequence.class, int.class, int.class, Appendable.class, boolean.class);
                                                printAndQuoteMethod.setAccessible(true);
                                                
                                                StringWriter out = new StringWriter();
                                                String value = "va" + format.getDelimiter() + "lue";
                                                printAndQuoteMethod.invoke(format, value, value, 0, value.length(), out, true);
                                                assertEquals("\"" + value + "\"", out.toString());
                                            }

    @Test
                                            public void testPrintAndQuoteModeMinimalWithSpaceAtEnd() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                // Define constants
                                                final int SP = ' ';
                                                final int COMMENT = '#';
                                                final char LF = '\n';
                                                final char CR = '\r';
                                                
                                                // Create test objects
                                                CSVFormat format = CSVFormat.DEFAULT;
                                                Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod("printAndQuote", 
                                                    Object.class, CharSequence.class, int.class, int.class, Appendable.class, boolean.class);
                                                printAndQuoteMethod.setAccessible(true);
                                                
                                                StringWriter out = new StringWriter();
                                                String value = "value" + (char)(SP - 1);
                                                printAndQuoteMethod.invoke(format, value, value, 0, value.length(), out, true);
                                                assertEquals("\"" + value + "\"", out.toString());
                                            }

    @Test
                                            public void testPrintAndQuoteModeMinimalWithNoSpecialChars() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                CSVFormat format = CSVFormat.DEFAULT;
                                                Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod("printAndQuote", 
                                                    Object.class, String.class, int.class, int.class, Appendable.class, boolean.class);
                                                printAndQuoteMethod.setAccessible(true);
                                                
                                                StringWriter out = new StringWriter();
                                                String value = "normalvalue";
                                                printAndQuoteMethod.invoke(format, value, value, 0, value.length(), out, true);
                                                assertEquals(value, out.toString());
                                            }

    @Test(expected = IllegalStateException.class)
                                            public void testPrintAndQuoteWithInvalidQuoteMode() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                                Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod("printAndQuote", 
                                                    Object.class, String.class, int.class, int.class, Appendable.class, boolean.class);
                                                printAndQuoteMethod.setAccessible(true);
                                        
                                                CSVFormat invalidFormat = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.valueOf("INVALID"));
                                                StringWriter out = new StringWriter();
                                                printAndQuoteMethod.invoke(invalidFormat, "value", "value", 0, 5, out, true);
                                            }

    @Test
                                        public void testPrintAndQuoteModeMinimalWithLineBreak() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
                                            CSVFormat format = CSVFormat.DEFAULT;
                                            Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod("printAndQuote", Object.class, CharSequence.class, int.class, int.class, Appendable.class, boolean.class);
                                            printAndQuoteMethod.setAccessible(true);
                                            
                                            StringWriter out = new StringWriter();
                                            final String LF = "\n";
                                            String value = "va" + LF + "lue";
                                            printAndQuoteMethod.invoke(format, value, value, 0, value.length(), out, true);
                                            assertEquals("\"" + value + "\"", out.toString());
                                        }


}
