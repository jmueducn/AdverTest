package gentest.org.jfree.data.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import org.jfree.chart.util.PublicCloneable;
import org.jfree.chart.util.SortOrder;
 
public class DefaultKeyedValuesTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                public void testRemoveValueWithSingleItem() {
                    // Create a new instance with single item
                    DefaultKeyedValues singleItem = new DefaultKeyedValues();
                    singleItem.addValue("SingleKey", 100);
                    
                    // Remove the only item
                    singleItem.removeValue("SingleKey");
                    
                    // Verify collection is empty
                    assertEquals(0, singleItem.getItemCount());
                    assertEquals(-1, singleItem.getIndex("SingleKey"));
                }

    @Test
                public void testCloneWithNullValues() throws CloneNotSupportedException {
                    DefaultKeyedValues original = new DefaultKeyedValues();
                    original.addValue("Key1", null);
                    original.addValue("Key2", null);
            
                    DefaultKeyedValues clone = (DefaultKeyedValues) original.clone();
            
                    assertNotSame(original, clone);
                    assertEquals(2, clone.getItemCount());
                    assertNull(clone.getValue("Key1"));
                    assertNull(clone.getValue("Key2"));
                }

    @Test
                public void testCloneIndependence() throws CloneNotSupportedException {
                    DefaultKeyedValues original = new DefaultKeyedValues();
                    original.addValue("A", 1.0);
                    original.addValue("B", 2.0);
            
                    DefaultKeyedValues clone = (DefaultKeyedValues) original.clone();
            
                    // Modify original and verify clone is unaffected
                    original.addValue("C", 3.0);
                    assertEquals(3, original.getItemCount());
                    assertEquals(2, clone.getItemCount());
            
                    // Modify clone and verify original is unaffected
                    clone.removeValue("A");
                    assertEquals(3, original.getItemCount());
                    assertEquals(1, clone.getItemCount());
                }

    @Test
            public void testRemoveValueValidIndex() {
                DefaultKeyedValues dkv = new DefaultKeyedValues();
                dkv.addValue("Key1", 1.0);
                dkv.addValue("Key2", 2.0);
                dkv.addValue("Key3", 3.0);
                
                dkv.removeValue(1);
                assertEquals(2, dkv.getItemCount());
                assertEquals(1.0, dkv.getValue(0).doubleValue(), 0.0001);
                assertEquals(3.0, dkv.getValue(1).doubleValue(), 0.0001);
                assertEquals("Key1", dkv.getKey(0));
                assertEquals("Key3", dkv.getKey(1));
                assertEquals(0, dkv.getIndex("Key1"));
                assertEquals(1, dkv.getIndex("Key3"));
                assertEquals(-1, dkv.getIndex("Key2"));
            }

    @Test(expected = IndexOutOfBoundsException.class)
            public void testRemoveValueNegativeIndex() {
                DefaultKeyedValues dkv = new DefaultKeyedValues();
                dkv.addValue("Key1", 1.0);
                dkv.removeValue(-1);
            }

    @Test(expected = IndexOutOfBoundsException.class)
            public void testRemoveValueIndexOutOfBounds() {
                DefaultKeyedValues dkv = new DefaultKeyedValues();
                dkv.addValue("A", 1);
                dkv.addValue("B", 2);
                dkv.removeValue(3); // This should throw IndexOutOfBoundsException
            }

    @Test
            public void testRemoveValueFirstIndex() {
                DefaultKeyedValues dkv = new DefaultKeyedValues();
                dkv.addValue("Key1", 1.0);
                dkv.addValue("Key2", 2.0);
                dkv.addValue("Key3", 3.0);
                
                dkv.removeValue(0);
                assertEquals(2, dkv.getItemCount());
                assertEquals(2.0, dkv.getValue(0).doubleValue(), 0.0001);
                assertEquals(3.0, dkv.getValue(1).doubleValue(), 0.0001);
                assertEquals("Key2", dkv.getKey(0));
                assertEquals("Key3", dkv.getKey(1));
                assertEquals(0, dkv.getIndex("Key2"));
                assertEquals(1, dkv.getIndex("Key3"));
                assertEquals(-1, dkv.getIndex("Key1"));
            }

    @Test
            public void testRemoveValueLastIndex() {
                DefaultKeyedValues dkv = new DefaultKeyedValues();
                dkv.addValue("Key1", 1.0);
                dkv.addValue("Key2", 2.0);
                dkv.addValue("Key3", 3.0);
                
                dkv.removeValue(2);
                assertEquals(2, dkv.getItemCount());
                assertEquals(1.0, dkv.getValue(0).doubleValue(), 0.0001);
                assertEquals(2.0, dkv.getValue(1).doubleValue(), 0.0001);
                assertEquals("Key1", dkv.getKey(0));
                assertEquals("Key2", dkv.getKey(1));
                assertEquals(0, dkv.getIndex("Key1"));
                assertEquals(1, dkv.getIndex("Key2"));
                assertEquals(-1, dkv.getIndex("Key3"));
            }

    @Test
            public void testRebuildIndexAfterRemove() throws Exception {
                // Create test data
                DefaultKeyedValues dkv = new DefaultKeyedValues();
                dkv.addValue("Key1", 1.0);
                dkv.addValue("Key2", 2.0);
                dkv.addValue("Key3", 3.0);
        
                // Use reflection to test private rebuildIndex method
                Method rebuildIndex = DefaultKeyedValues.class.getDeclaredMethod("rebuildIndex");
                rebuildIndex.setAccessible(true);
                
                dkv.removeValue(1);
                rebuildIndex.invoke(dkv);
                
                assertEquals(2, dkv.getItemCount());
                assertEquals(0, dkv.getIndex("Key1"));
                assertEquals(1, dkv.getIndex("Key3"));
                assertEquals(-1, dkv.getIndex("Key2"));
            }

    @Test
            public void testRemoveValueUpdatesKeysAndValuesLists() {
                DefaultKeyedValues dkv = new DefaultKeyedValues();
                dkv.addValue("Key1", 1.0);
                dkv.addValue("Key2", 2.0);
                dkv.addValue("Key3", 3.0);
                
                ArrayList keysBefore = new ArrayList(dkv.getKeys());
                dkv.removeValue(1);
                ArrayList keysAfter = new ArrayList(dkv.getKeys());
                
                assertEquals(3, keysBefore.size());
                assertEquals(2, keysAfter.size());
                assertFalse(keysAfter.contains("Key2"));
                assertTrue(keysAfter.contains("Key1"));
                assertTrue(keysAfter.contains("Key3"));
                
                try {
                    dkv.getValue("Key2");
                    fail("Expected UnknownKeyException");
                } catch (Exception e) {
                    // Expected
                }
            }

    @Test
            public void testRemovedKeyNoLongerAccessible() {
                DefaultKeyedValues dkv = new DefaultKeyedValues();
                dkv.addValue("Key1", 1.0);
                dkv.addValue("Key2", 2.0);
                dkv.removeValue(0);
                dkv.getValue("Key2");
            }

    @Test(expected = UnknownKeyException.class)
            public void testRemoveValueWithNonExistingKey1() {
                // Test removing a non-existing key should throw UnknownKeyException
                DefaultKeyedValues keyedValues = new DefaultKeyedValues();
                keyedValues.removeValue("NonExistingKey");
            }

    @Test(expected = IllegalArgumentException.class)
            public void testRemoveValueWithNullKey() {
                // Test removing with null key should throw IllegalArgumentException
                DefaultKeyedValues keyedValues = new DefaultKeyedValues();
                keyedValues.removeValue(null);
            }

    @Test
            public void testRemoveValueUpdatesIndexMap() {
                // Setup test data
                DefaultKeyedValues keyedValues = new DefaultKeyedValues();
                keyedValues.addValue("Key1", 10);
                keyedValues.addValue("Key2", 20);
                keyedValues.addValue("Key3", 30);
                
                // Verify initial state
                assertEquals(1, keyedValues.getIndex("Key2"));
                
                // Remove a key
                keyedValues.removeValue("Key1");
                
                // Verify index map was updated correctly
                try {
                    keyedValues.getIndex("Key1");
                    fail("Expected UnknownKeyException");
                } catch (UnknownKeyException e) {
                    // Expected behavior
                }
                assertEquals(0, keyedValues.getIndex("Key2"));
                assertEquals(1, keyedValues.getIndex("Key3"));
            }

    @Test
            public void testRemoveValueMaintainsOrder() {
                DefaultKeyedValues keyedValues = new DefaultKeyedValues();
                keyedValues.addValue("Key1", 10);
                keyedValues.addValue("Key2", 20);
                keyedValues.addValue("Key3", 30);
                
                // Add more items to test order maintenance
                keyedValues.addValue("Key4", 40);
                keyedValues.addValue("Key5", 50);
                
                // Remove middle item
                keyedValues.removeValue("Key3");
                
                // Verify order is maintained
                assertEquals(0, keyedValues.getIndex("Key1"));
                assertEquals(1, keyedValues.getIndex("Key2"));
                assertEquals(2, keyedValues.getIndex("Key4"));
                assertEquals(3, keyedValues.getIndex("Key5"));
            }

    @Test
            public void testClone() throws Exception {
                // Create original object with some data
                DefaultKeyedValues original = new DefaultKeyedValues();
                original.addValue("Key1", 10.0);
                original.addValue("Key2", 20.0);
                original.addValue("Key3", 30.0);
        
                // Clone the object
                DefaultKeyedValues clone = (DefaultKeyedValues) original.clone();
        
                // Verify clone is not the same object
                assertNotSame(original, clone);
        
                // Get private fields using reflection
                Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                keysField.setAccessible(true);
                Field valuesField = DefaultKeyedValues.class.getDeclaredField("values");
                valuesField.setAccessible(true);
                Field indexMapField = DefaultKeyedValues.class.getDeclaredField("indexMap");
                indexMapField.setAccessible(true);
        
                // Get field values
                Object originalKeys = keysField.get(original);
                Object cloneKeys = keysField.get(clone);
                Object originalValues = valuesField.get(original);
                Object cloneValues = valuesField.get(clone);
                Object originalIndexMap = indexMapField.get(original);
                Object cloneIndexMap = indexMapField.get(clone);
        
                // Verify keys ArrayList is cloned properly
                assertNotSame(originalKeys, cloneKeys);
                assertEquals(originalKeys, cloneKeys);
        
                // Verify values ArrayList is cloned properly
                assertNotSame(originalValues, cloneValues);
                assertEquals(originalValues, cloneValues);
        
                // Verify indexMap HashMap is cloned properly
                assertNotSame(originalIndexMap, cloneIndexMap);
                assertEquals(originalIndexMap, cloneIndexMap);
        
                // Verify data integrity
                assertEquals(original.getItemCount(), clone.getItemCount());
                assertEquals(original.getValue("Key1"), clone.getValue("Key1"));
                assertEquals(original.getValue("Key2"), clone.getValue("Key2"));
                assertEquals(original.getValue("Key3"), clone.getValue("Key3"));
        
                // Verify modifying clone doesn't affect original
                clone.addValue("Key4", 40.0);
                assertEquals(3, original.getItemCount());
                assertEquals(4, clone.getItemCount());
            }

    @Test
            public void testCloneWithEmptyData() throws Exception {
                DefaultKeyedValues original = new DefaultKeyedValues();
                DefaultKeyedValues clone = (DefaultKeyedValues) original.clone();
        
                assertNotSame(original, clone);
                assertEquals(0, clone.getItemCount());
        
                Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                keysField.setAccessible(true);
                Field valuesField = DefaultKeyedValues.class.getDeclaredField("values");
                valuesField.setAccessible(true);
                Field indexMapField = DefaultKeyedValues.class.getDeclaredField("indexMap");
                indexMapField.setAccessible(true);
        
                assertNotSame(keysField.get(original), keysField.get(clone));
                assertNotSame(valuesField.get(original), valuesField.get(clone));
                assertNotSame(indexMapField.get(original), indexMapField.get(clone));
            }

    @Test(expected = UnknownKeyException.class)
        public void testRemoveValueWithNonExistingKey() {
            // Test removing a non-existing key should throw UnknownKeyException
            DefaultKeyedValues keyedValues = new DefaultKeyedValues();
            keyedValues.removeValue("NonExistingKey");
        }


}
