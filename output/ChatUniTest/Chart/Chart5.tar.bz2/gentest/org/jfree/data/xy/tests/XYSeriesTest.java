package gentest.org.jfree.data.xy.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.xy.*;
import java.io.Serializable;
import java.util.Collections;
import java.util.List;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.data.general.Series;
import org.jfree.data.general.SeriesChangeEvent;
import org.jfree.data.general.SeriesException;
 
public class XYSeriesTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
        public void testAddOrUpdateWithNewItem() {
            XYSeries series = new XYSeries("Test Series");
            XYDataItem result = series.addOrUpdate(1.0, 2.0);
            assertNull(result);
            assertEquals(1, series.getItemCount());
            assertEquals(1.0, series.getX(0).doubleValue(), 0.0001);
            assertEquals(2.0, series.getY(0).doubleValue(), 0.0001);
        }

    @Test
        public void testAddOrUpdateWithExistingItem() {
            XYSeries series = new XYSeries("Test Series");
            series.add(1.0, 2.0);
            XYDataItem result = series.addOrUpdate(1.0, 3.0);
            assertNotNull(result);
            assertEquals(2.0, result.getY().doubleValue(), 0.0001);
            assertEquals(1, series.getItemCount());
            assertEquals(3.0, series.getY(0).doubleValue(), 0.0001);
        }

    @Test
        public void testAddOrUpdateWithDuplicateXValuesAllowed() {
            XYSeries series = new XYSeries("Test Series", true, true);
            series.addOrUpdate(1.0, 2.0);
            XYDataItem result = series.addOrUpdate(1.0, 3.0);
            assertNull(result);
            assertEquals(2, series.getItemCount());
        }

    @Test
        public void testAddOrUpdateWithAutoSort() {
            XYSeries series = new XYSeries("Test Series", true, false);
            series.addOrUpdate(2.0, 2.0);
            series.addOrUpdate(1.0, 1.0);
            assertEquals(1.0, series.getX(0).doubleValue(), 0.0001);
            assertEquals(2.0, series.getX(1).doubleValue(), 0.0001);
        }

    @Test
        public void testAddOrUpdateWithoutAutoSort() {
            XYSeries series = new XYSeries("Test Series", false, false);
            series.addOrUpdate(2.0, 2.0);
            series.addOrUpdate(1.0, 1.0);
            assertEquals(2.0, series.getX(0).doubleValue(), 0.0001);
            assertEquals(1.0, series.getX(1).doubleValue(), 0.0001);
        }

    @Test
        public void testAddOrUpdateExceedingMaximumItemCount() {
            XYSeries series = new XYSeries("Test Series");
            series.setMaximumItemCount(2);
            series.addOrUpdate(1.0, 1.0);
            series.addOrUpdate(2.0, 2.0);
            series.addOrUpdate(3.0, 3.0);
            assertEquals(2, series.getItemCount());
            assertEquals(2.0, series.getX(0).doubleValue(), 0.0001);
            assertEquals(3.0, series.getX(1).doubleValue(), 0.0001);
        }

    @Test
        public void testAddOrUpdateWithNullYValue() {
            XYSeries series = new XYSeries("Test Series");
            XYDataItem result = series.addOrUpdate(1.0, Double.NaN);
            assertNull(result);
            assertEquals(1, series.getItemCount());
            assertTrue(Double.isNaN(series.getY(0).doubleValue()));
        }

    @Test(expected = IllegalArgumentException.class)
        public void testAddOrUpdateWithNullX() {
            XYSeries series = new XYSeries("Test Series");
            series.addOrUpdate(null, 5);
        }

    @Test
        public void testAddOrUpdateWithDuplicateXAllowed() {
            XYSeries duplicateAllowedSeries = new XYSeries("Test Series", true, false);
            XYDataItem result = duplicateAllowedSeries.addOrUpdate(1, 10);
            assertNull(result); // First add should return null
            result = duplicateAllowedSeries.addOrUpdate(1, 20);
            assertNull(result); // Second add with same x should return null
            assertEquals(2, duplicateAllowedSeries.getItemCount());
        }

    @Test
        public void testAddOrUpdateNewItemInNonAutoSortSeries() {
            XYSeries series = new XYSeries("Test Series", false, false);
            XYDataItem result = series.addOrUpdate(1.0, 10.0);
            assertNull(result);
            assertEquals(1, series.getItemCount());
            assertEquals(10.0, series.getY(0).doubleValue(), 0.0001);
        }

    @Test
        public void testAddOrUpdateExistingItemInNonAutoSortSeries() {
            XYSeries series = new XYSeries("Test Series", false, false);
            series.addOrUpdate(1, 10);
            XYDataItem result = series.addOrUpdate(1, 20);
            assertNotNull(result);
            assertEquals(10, result.getY().intValue());
            assertEquals(20, series.getY(0).intValue());
        }

    @Test
        public void testAddOrUpdateNewItemInAutoSortSeries() {
            XYSeries autoSortSeries = new XYSeries("Test Series", true, true);
            autoSortSeries.addOrUpdate(2, 20);
            XYDataItem result = autoSortSeries.addOrUpdate(1, 10);
            assertNull(result);
            assertEquals(2, autoSortSeries.getItemCount());
            assertEquals(10, autoSortSeries.getY(0).intValue());
        }

    @Test
        public void testAddOrUpdateExistingItemInAutoSortSeries() {
            XYSeries autoSortSeries = new XYSeries("Test Series", true, true);
            autoSortSeries.addOrUpdate(1, 10);
            XYDataItem result = autoSortSeries.addOrUpdate(1, 20);
            assertNotNull(result);
            assertEquals(10, result.getY().intValue());
            assertEquals(20, autoSortSeries.getY(0).intValue());
        }

    @Test
        public void testAddOrUpdateTriggersMaximumItemCount() {
            XYSeries series = new XYSeries("Test Series");
            series.setMaximumItemCount(2);
            series.addOrUpdate(1, 10);
            series.addOrUpdate(2, 20);
            series.addOrUpdate(3, 30);
            assertEquals(2, series.getItemCount());
            assertEquals(20, series.getY(0).intValue());
            assertEquals(30, series.getY(1).intValue());
        }

    @Test(expected = SeriesException.class)
        public void testAddOrUpdateCloneFailure() throws CloneNotSupportedException {
            XYSeries series = new XYSeries("Test Series");
            XYDataItem mockItem = mock(XYDataItem.class);
            when(mockItem.getX()).thenReturn(1.0);
            when(mockItem.clone()).thenThrow(new CloneNotSupportedException());
            
            // Use reflection to add the mock item directly to the data list
            try {
                java.lang.reflect.Field dataField = XYSeries.class.getDeclaredField("data");
                dataField.setAccessible(true);
                java.util.List data = (java.util.List) dataField.get(series);
                data.add(mockItem);
            } catch (Exception e) {
                fail("Failed to access data field via reflection");
            }
            
            series.addOrUpdate(1.0, 20.0);
        }

    @Test
        public void testAddOrUpdateReturnsCorrectOverwrittenItem() {
            XYSeries series = new XYSeries("Test Series");
            series.addOrUpdate(1, 10);
            XYDataItem result = series.addOrUpdate(1, 20);
            assertEquals(10, result.getY().intValue());
        }

    @Test
        public void testAddOrUpdateWithNegativeIndexInAutoSort() {
            XYSeries autoSortSeries = new XYSeries("Test Series", true, true);
            autoSortSeries.addOrUpdate(10, 100);
            autoSortSeries.addOrUpdate(5, 50);
            assertEquals(2, autoSortSeries.getItemCount());
            assertEquals(5, autoSortSeries.getX(0).intValue());
            assertEquals(10, autoSortSeries.getX(1).intValue());
        }


}
