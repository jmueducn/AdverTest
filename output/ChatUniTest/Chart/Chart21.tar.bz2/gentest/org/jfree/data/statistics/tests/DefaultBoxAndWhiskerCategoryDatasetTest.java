package gentest.org.jfree.data.statistics.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.statistics.*;
import java.util.List;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.chart.util.PublicCloneable;
import org.jfree.data.KeyedObjects2D;
import org.jfree.data.Range;
import org.jfree.data.RangeInfo;
import org.jfree.data.general.AbstractDataset;
 
public class DefaultBoxAndWhiskerCategoryDatasetTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                        public void testAddWithValidListAndKeys() {
                                                            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                            List<Double> testList = new ArrayList<>();
                                                            testList.add(1.0);
                                                            testList.add(2.0);
                                                            testList.add(3.0);
                                                            testList.add(4.0);
                                                            testList.add(5.0);
                                                            Comparable<?> rowKey = "Row";
                                                            Comparable<?> columnKey = "Column";
                                                            
                                                            dataset.add(testList, rowKey, columnKey);
                                                            
                                                            assertEquals(1, dataset.getRowCount());
                                                            assertEquals(1, dataset.getColumnCount());
                                                            assertEquals(rowKey, dataset.getRowKey(0));
                                                            assertEquals(columnKey, dataset.getColumnKey(0));
                                                            
                                                            BoxAndWhiskerItem item = dataset.getItem(0, 0);
                                                            assertNotNull(item);
                                                            assertEquals(3.0, item.getMedian().doubleValue(), 0.001);
                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                        public void testAddWithNullRowKey() {
                                                            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                            List<Double> testList = new ArrayList<>();
                                                            testList.add(1.0);
                                                            testList.add(2.0);
                                                            testList.add(3.0);
                                                            Comparable columnKey = "Column";
                                                            dataset.add(testList, null, columnKey);
                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                        public void testAddWithNullColumnKey() {
                                                            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                            List<Double> testList = new ArrayList<>();
                                                            testList.add(1.0);
                                                            testList.add(2.0);
                                                            testList.add(3.0);
                                                            Comparable<String> rowKey = "Row1";
                                                            dataset.add(testList, rowKey, null);
                                                        }

    @Test
                                                        public void testAddWithEmptyList() {
                                                            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                            List<Double> emptyList = new ArrayList<>();
                                                            Comparable<String> rowKey = "Row";
                                                            Comparable<String> columnKey = "Column";
                                                            
                                                            dataset.add(emptyList, rowKey, columnKey);
                                                            
                                                            assertEquals(1, dataset.getRowCount());
                                                            assertEquals(1, dataset.getColumnCount());
                                                            
                                                            BoxAndWhiskerItem item = dataset.getItem(0, 0);
                                                            assertNotNull(item);
                                                            assertTrue(Double.isNaN(item.getMedian().doubleValue()));
                                                        }

    @Test
                                                        public void testAddMultipleItems() {
                                                            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                            List<Double> testList = new ArrayList<>();
                                                            testList.add(1.0);
                                                            testList.add(2.0);
                                                            testList.add(3.0);
                                                            
                                                            Comparable<String> rowKey = "Row1";
                                                            Comparable<String> columnKey = "Column1";
                                                            Comparable<String> rowKey2 = "Row2";
                                                            Comparable<String> columnKey2 = "Column2";
                                                            
                                                            dataset.add(testList, rowKey, columnKey);
                                                            dataset.add(testList, rowKey2, columnKey2);
                                                            
                                                            assertEquals(2, dataset.getRowCount());
                                                            assertEquals(2, dataset.getColumnCount());
                                                            assertEquals(rowKey, dataset.getRowKey(0));
                                                            assertEquals(rowKey2, dataset.getRowKey(1));
                                                            assertEquals(columnKey, dataset.getColumnKey(0));
                                                            assertEquals(columnKey2, dataset.getColumnKey(1));
                                                        }

    @Test
                                                        public void testAddCallsCalculateBoxAndWhiskerStatistics() {
                                                            // Create test data
                                                            List<Double> testList = new ArrayList<>();
                                                            testList.add(1.0);
                                                            testList.add(2.0);
                                                            testList.add(3.0);
                                                            Comparable<String> rowKey = "Row";
                                                            Comparable<String> columnKey = "Column";
                                                            
                                                            // Create a spy to verify the interaction with BoxAndWhiskerCalculator
                                                            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                            DefaultBoxAndWhiskerCategoryDataset spyDataset = spy(dataset);
                                                            
                                                            spyDataset.add(testList, rowKey, columnKey);
                                                            
                                                            // Verify that add was called with a BoxAndWhiskerItem and our keys
                                                            verify(spyDataset, times(1)).add(any(BoxAndWhiskerItem.class), eq(rowKey), eq(columnKey));
                                                        }

    @Test
                                                        public void testAddUpdatesRangeBounds() {
                                                            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                            List<Double> testList = new ArrayList<>();
                                                            testList.add(1.0);
                                                            testList.add(2.0);
                                                            testList.add(3.0);
                                                            testList.add(4.0);
                                                            testList.add(5.0);
                                                            Comparable rowKey = "Row";
                                                            Comparable columnKey = "Column";
                                                            
                                                            dataset.add(testList, rowKey, columnKey);
                                                            
                                                            // The test list has min=1.0 and max=5.0
                                                            assertEquals(1.0, dataset.getRangeLowerBound(true), 0.001);
                                                            assertEquals(5.0, dataset.getRangeUpperBound(true), 0.001);
                                                            assertEquals(1.0, dataset.getRangeBounds(true).getLowerBound(), 0.001);
                                                            assertEquals(5.0, dataset.getRangeBounds(true).getUpperBound(), 0.001);
                                                        }

    @Test
                                                        public void testAddWithOutliers() {
                                                            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                            Comparable<String> rowKey = "Row";
                                                            Comparable<String> columnKey = "Column";
                                                            
                                                            List<Double> listWithOutliers = new ArrayList<>();
                                                            listWithOutliers.add(1.0);
                                                            listWithOutliers.add(2.0);
                                                            listWithOutliers.add(3.0);
                                                            listWithOutliers.add(4.0);
                                                            listWithOutliers.add(5.0);
                                                            listWithOutliers.add(100.0); // outlier
                                                            listWithOutliers.add(-100.0); // outlier
                                                            
                                                            dataset.add(listWithOutliers, rowKey, columnKey);
                                                            
                                                            BoxAndWhiskerItem item = dataset.getItem(0, 0);
                                                            assertNotNull(item);
                                                            assertEquals(-100.0, item.getMinOutlier().doubleValue(), 0.001);
                                                            assertEquals(100.0, item.getMaxOutlier().doubleValue(), 0.001);
                                                        }

    @Test
                                                        public void testAddItemUpdatesExistingMinMax() {
                                                            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                            KeyedObjects2D mockData = mock(KeyedObjects2D.class);
                                                            
                                                            // Use reflection to set the private data field
                                                            try {
                                                                java.lang.reflect.Field dataField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("data");
                                                                dataField.setAccessible(true);
                                                                dataField.set(dataset, mockData);
                                                            } catch (Exception e) {
                                                                fail("Failed to set mock data field");
                                                            }
                                                    
                                                            // First add an item to set initial min/max
                                                            BoxAndWhiskerItem item1 = mock(BoxAndWhiskerItem.class);
                                                            when(item1.getMinOutlier()).thenReturn(5.0);
                                                            when(item1.getMaxOutlier()).thenReturn(15.0);
                                                            
                                                            when(mockData.getRowIndex("Row1")).thenReturn(0);
                                                            when(mockData.getColumnIndex("Col1")).thenReturn(0);
                                                    
                                                            dataset.add(item1, "Row1", "Col1");
                                                    
                                                            // Add a new item with lower min and higher max
                                                            BoxAndWhiskerItem item2 = mock(BoxAndWhiskerItem.class);
                                                            when(item2.getMinOutlier()).thenReturn(3.0);
                                                            when(item2.getMaxOutlier()).thenReturn(20.0);
                                                            
                                                            when(mockData.getRowIndex("Row2")).thenReturn(1);
                                                            when(mockData.getColumnIndex("Col2")).thenReturn(1);
                                                    
                                                            dataset.add(item2, "Row2", "Col2");
                                                    
                                                            // Use reflection to access private fields for assertions
                                                            try {
                                                                java.lang.reflect.Field minValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
                                                                minValueField.setAccessible(true);
                                                                double minimumRangeValue = minValueField.getDouble(dataset);
                                                    
                                                                java.lang.reflect.Field maxValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValue");
                                                                maxValueField.setAccessible(true);
                                                                double maximumRangeValue = maxValueField.getDouble(dataset);
                                                    
                                                                java.lang.reflect.Field minRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                                                                minRowField.setAccessible(true);
                                                                int minimumRangeValueRow = minRowField.getInt(dataset);
                                                    
                                                                java.lang.reflect.Field minColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                                                                minColField.setAccessible(true);
                                                                int minimumRangeValueColumn = minColField.getInt(dataset);
                                                    
                                                                java.lang.reflect.Field maxRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueRow");
                                                                maxRowField.setAccessible(true);
                                                                int maximumRangeValueRow = maxRowField.getInt(dataset);
                                                    
                                                                java.lang.reflect.Field maxColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueColumn");
                                                                maxColField.setAccessible(true);
                                                                int maximumRangeValueColumn = maxColField.getInt(dataset);
                                                    
                                                                assertEquals(3.0, minimumRangeValue, 0.0001);
                                                                assertEquals(20.0, maximumRangeValue, 0.0001);
                                                                assertEquals(1, minimumRangeValueRow);
                                                                assertEquals(1, minimumRangeValueColumn);
                                                                assertEquals(1, maximumRangeValueRow);
                                                                assertEquals(1, maximumRangeValueColumn);
                                                            } catch (Exception e) {
                                                                fail("Failed to access private fields for assertions");
                                                            }
                                                        }

    @Test
                                                        public void testAddItemWhenCurrentMinMaxCellIsUpdated() throws Exception {
                                                            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                            
                                                            // First add an item to set initial min/max
                                                            BoxAndWhiskerItem item1 = mock(BoxAndWhiskerItem.class);
                                                            when(item1.getMinOutlier()).thenReturn(5.0);
                                                            when(item1.getMaxOutlier()).thenReturn(15.0);
                                                            
                                                            dataset.add(item1, "Row1", "Col1");
                                                    
                                                            // Now update the same cell
                                                            BoxAndWhiskerItem item2 = mock(BoxAndWhiskerItem.class);
                                                            when(item2.getMinOutlier()).thenReturn(3.0);
                                                            when(item2.getMaxOutlier()).thenReturn(20.0);
                                                            
                                                            dataset.add(item2, "Row1", "Col1");
                                                    
                                                            // Verify updateBounds was called (indirectly by checking the range)
                                                            assertNotNull(dataset.getRangeBounds(false));
                                                        }

    @Test
                                                        public void testAddItemUpdatesRangeBounds() {
                                                            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                            BoxAndWhiskerItem item = mock(BoxAndWhiskerItem.class);
                                                            when(item.getMinOutlier()).thenReturn(5.0);
                                                            when(item.getMaxOutlier()).thenReturn(15.0);
                                                            
                                                            // Mock the internal data structure
                                                            DefaultBoxAndWhiskerCategoryDataset spyDataset = spy(dataset);
                                                            doReturn(0).when(spyDataset).getRowIndex("Row1");
                                                            doReturn(0).when(spyDataset).getColumnIndex("Col1");
                                                            
                                                            spyDataset.add(item, "Row1", "Col1");
                                                            
                                                            Range range = spyDataset.getRangeBounds(false);
                                                            assertEquals(5.0, range.getLowerBound(), 0.0001);
                                                            assertEquals(15.0, range.getUpperBound(), 0.0001);
                                                        }

    @Test
                                                    public void testUpdateBoundsWithEmptyDataset() throws Exception {
                                                        DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                        Method updateBoundsMethod = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredMethod("updateBounds");
                                                        updateBoundsMethod.setAccessible(true);
                                                        
                                                        updateBoundsMethod.invoke(dataset);
                                                        
                                                        assertTrue(Double.isNaN(dataset.getRangeLowerBound(false)));
                                                        assertTrue(Double.isNaN(dataset.getRangeUpperBound(false)));
                                                        
                                                        // Access private fields using reflection
                                                        java.lang.reflect.Field minRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                                                        minRowField.setAccessible(true);
                                                        assertEquals(-1, minRowField.getInt(dataset));
                                                        
                                                        java.lang.reflect.Field minColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                                                        minColField.setAccessible(true);
                                                        assertEquals(-1, minColField.getInt(dataset));
                                                        
                                                        java.lang.reflect.Field maxRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueRow");
                                                        maxRowField.setAccessible(true);
                                                        assertEquals(-1, maxRowField.getInt(dataset));
                                                        
                                                        java.lang.reflect.Field maxColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueColumn");
                                                        maxColField.setAccessible(true);
                                                        assertEquals(-1, maxColField.getInt(dataset));
                                                    }

    @Test
                                                    public void testUpdateBoundsWithSingleItem() throws Exception {
                                                        DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                        Method updateBoundsMethod = DefaultBoxAndWhiskerCategoryDataset.class
                                                                .getDeclaredMethod("updateBounds");
                                                        updateBoundsMethod.setAccessible(true);
                                                        
                                                        BoxAndWhiskerItem item = mock(BoxAndWhiskerItem.class);
                                                        when(item.getMinOutlier()).thenReturn(5.0);
                                                        when(item.getMaxOutlier()).thenReturn(10.0);
                                                        
                                                        dataset.add(item, "Row1", "Column1");
                                                        updateBoundsMethod.invoke(dataset);
                                                        
                                                        assertEquals(5.0, dataset.getRangeLowerBound(false), 0.0001);
                                                        assertEquals(10.0, dataset.getRangeUpperBound(false), 0.0001);
                                                        
                                                        // Access private fields using reflection
                                                        java.lang.reflect.Field minRowField = DefaultBoxAndWhiskerCategoryDataset.class
                                                                .getDeclaredField("minimumRangeValueRow");
                                                        minRowField.setAccessible(true);
                                                        assertEquals(0, minRowField.getInt(dataset));
                                                        
                                                        java.lang.reflect.Field minColField = DefaultBoxAndWhiskerCategoryDataset.class
                                                                .getDeclaredField("minimumRangeValueColumn");
                                                        minColField.setAccessible(true);
                                                        assertEquals(0, minColField.getInt(dataset));
                                                        
                                                        java.lang.reflect.Field maxRowField = DefaultBoxAndWhiskerCategoryDataset.class
                                                                .getDeclaredField("maximumRangeValueRow");
                                                        maxRowField.setAccessible(true);
                                                        assertEquals(0, maxRowField.getInt(dataset));
                                                        
                                                        java.lang.reflect.Field maxColField = DefaultBoxAndWhiskerCategoryDataset.class
                                                                .getDeclaredField("maximumRangeValueColumn");
                                                        maxColField.setAccessible(true);
                                                        assertEquals(0, maxColField.getInt(dataset));
                                                    }

    @Test
                                                    public void testUpdateBoundsWithMultipleItems() throws Exception {
                                                        DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                        
                                                        // Get private method via reflection
                                                        Method updateBoundsMethod = DefaultBoxAndWhiskerCategoryDataset.class
                                                            .getDeclaredMethod("updateBounds");
                                                        updateBoundsMethod.setAccessible(true);
                                                
                                                        BoxAndWhiskerItem item1 = mock(BoxAndWhiskerItem.class);
                                                        when(item1.getMinOutlier()).thenReturn(2.0);
                                                        when(item1.getMaxOutlier()).thenReturn(8.0);
                                                        
                                                        BoxAndWhiskerItem item2 = mock(BoxAndWhiskerItem.class);
                                                        when(item2.getMinOutlier()).thenReturn(1.0);
                                                        when(item2.getMaxOutlier()).thenReturn(10.0);
                                                        
                                                        dataset.add(item1, "Row1", "Column1");
                                                        dataset.add(item2, "Row2", "Column2");
                                                        updateBoundsMethod.invoke(dataset);
                                                        
                                                        // Access private fields via reflection
                                                        java.lang.reflect.Field minRowField = DefaultBoxAndWhiskerCategoryDataset.class
                                                            .getDeclaredField("minimumRangeValueRow");
                                                        minRowField.setAccessible(true);
                                                        java.lang.reflect.Field minColField = DefaultBoxAndWhiskerCategoryDataset.class
                                                            .getDeclaredField("minimumRangeValueColumn");
                                                        minColField.setAccessible(true);
                                                        java.lang.reflect.Field maxRowField = DefaultBoxAndWhiskerCategoryDataset.class
                                                            .getDeclaredField("maximumRangeValueRow");
                                                        maxRowField.setAccessible(true);
                                                        java.lang.reflect.Field maxColField = DefaultBoxAndWhiskerCategoryDataset.class
                                                            .getDeclaredField("maximumRangeValueColumn");
                                                        maxColField.setAccessible(true);
                                                
                                                        assertEquals(1.0, dataset.getRangeLowerBound(false), 0.0001);
                                                        assertEquals(10.0, dataset.getRangeUpperBound(false), 0.0001);
                                                        assertEquals(1, minRowField.get(dataset));
                                                        assertEquals(1, minColField.get(dataset));
                                                        assertEquals(1, maxRowField.get(dataset));
                                                        assertEquals(1, maxColField.get(dataset));
                                                    }

    @Test
                                                    public void testUpdateBoundsWithNullMinMaxOutliers() throws Exception {
                                                        DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                        Method updateBoundsMethod = DefaultBoxAndWhiskerCategoryDataset.class
                                                            .getDeclaredMethod("updateBounds");
                                                        updateBoundsMethod.setAccessible(true);
                                                        
                                                        BoxAndWhiskerItem item = mock(BoxAndWhiskerItem.class);
                                                        when(item.getMinOutlier()).thenReturn(null);
                                                        when(item.getMaxOutlier()).thenReturn(null);
                                                        
                                                        dataset.add(item, "Row1", "Column1");
                                                        updateBoundsMethod.invoke(dataset);
                                                        
                                                        assertTrue(Double.isNaN(dataset.getRangeLowerBound(false)));
                                                        assertTrue(Double.isNaN(dataset.getRangeUpperBound(false)));
                                                        
                                                        // Access private fields using reflection
                                                        java.lang.reflect.Field minRowField = DefaultBoxAndWhiskerCategoryDataset.class
                                                            .getDeclaredField("minimumRangeValueRow");
                                                        minRowField.setAccessible(true);
                                                        java.lang.reflect.Field minColField = DefaultBoxAndWhiskerCategoryDataset.class
                                                            .getDeclaredField("minimumRangeValueColumn");
                                                        minColField.setAccessible(true);
                                                        java.lang.reflect.Field maxRowField = DefaultBoxAndWhiskerCategoryDataset.class
                                                            .getDeclaredField("maximumRangeValueRow");
                                                        maxRowField.setAccessible(true);
                                                        java.lang.reflect.Field maxColField = DefaultBoxAndWhiskerCategoryDataset.class
                                                            .getDeclaredField("maximumRangeValueColumn");
                                                        maxColField.setAccessible(true);
                                                        
                                                        assertEquals(-1, minRowField.getInt(dataset));
                                                        assertEquals(-1, minColField.getInt(dataset));
                                                        assertEquals(-1, maxRowField.getInt(dataset));
                                                        assertEquals(-1, maxColField.getInt(dataset));
                                                    }

    @Test
                                                    public void testUpdateBoundsWithNaNValues() throws Exception {
                                                        DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                        Method updateBoundsMethod = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredMethod("updateBounds");
                                                        updateBoundsMethod.setAccessible(true);
                                                        
                                                        BoxAndWhiskerItem item = mock(BoxAndWhiskerItem.class);
                                                        when(item.getMinOutlier()).thenReturn(Double.NaN);
                                                        when(item.getMaxOutlier()).thenReturn(Double.NaN);
                                                        
                                                        dataset.add(item, "Row1", "Column1");
                                                        updateBoundsMethod.invoke(dataset);
                                                        
                                                        assertTrue(Double.isNaN(dataset.getRangeLowerBound(false)));
                                                        assertTrue(Double.isNaN(dataset.getRangeUpperBound(false)));
                                                        
                                                        // Access private fields using reflection
                                                        Field minRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                                                        minRowField.setAccessible(true);
                                                        Field minColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                                                        minColField.setAccessible(true);
                                                        Field maxRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueRow");
                                                        maxRowField.setAccessible(true);
                                                        Field maxColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueColumn");
                                                        maxColField.setAccessible(true);
                                                        
                                                        assertEquals(-1, minRowField.getInt(dataset));
                                                        assertEquals(-1, minColField.getInt(dataset));
                                                        assertEquals(-1, maxRowField.getInt(dataset));
                                                        assertEquals(-1, maxColField.getInt(dataset));
                                                    }

    @Test
                                                    public void testUpdateBoundsWithMixedValidAndInvalidValues() throws Exception {
                                                        DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                        Method updateBoundsMethod = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredMethod("updateBounds");
                                                        updateBoundsMethod.setAccessible(true);
                                                
                                                        BoxAndWhiskerItem item1 = mock(BoxAndWhiskerItem.class);
                                                        when(item1.getMinOutlier()).thenReturn(null);
                                                        when(item1.getMaxOutlier()).thenReturn(15.0);
                                                        
                                                        BoxAndWhiskerItem item2 = mock(BoxAndWhiskerItem.class);
                                                        when(item2.getMinOutlier()).thenReturn(3.0);
                                                        when(item2.getMaxOutlier()).thenReturn(Double.NaN);
                                                        
                                                        dataset.add(item1, "Row1", "Column1");
                                                        dataset.add(item2, "Row2", "Column2");
                                                        updateBoundsMethod.invoke(dataset);
                                                        
                                                        assertEquals(3.0, dataset.getRangeLowerBound(false), 0.0001);
                                                        assertEquals(15.0, dataset.getRangeUpperBound(false), 0.0001);
                                                        
                                                        // Access private fields using reflection
                                                        java.lang.reflect.Field minRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                                                        minRowField.setAccessible(true);
                                                        java.lang.reflect.Field minColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                                                        minColField.setAccessible(true);
                                                        java.lang.reflect.Field maxRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueRow");
                                                        maxRowField.setAccessible(true);
                                                        java.lang.reflect.Field maxColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueColumn");
                                                        maxColField.setAccessible(true);
                                                        
                                                        assertEquals(1, minRowField.getInt(dataset));
                                                        assertEquals(1, minColField.getInt(dataset));
                                                        assertEquals(0, maxRowField.getInt(dataset));
                                                        assertEquals(0, maxColField.getInt(dataset));
                                                    }

    @Test(expected = IllegalArgumentException.class)
                                public void testAddWithNullList() {
                                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                    String rowKey = "Row";
                                    String columnKey = "Column";
                                    dataset.add((List<Double>) null, rowKey, columnKey);
                                }

    @Test
                    public void testUpdateBounds() throws Exception {
                        // Create mock dataset and data structure
                        DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                        DefaultBoxAndWhiskerCategoryDataset data = mock(DefaultBoxAndWhiskerCategoryDataset.class);
                        
                        // Set up test data
                        BoxAndWhiskerItem item1 = mock(BoxAndWhiskerItem.class);
                        when(item1.getMinOutlier()).thenReturn(5.0);
                        when(item1.getMaxOutlier()).thenReturn(15.0);
                        
                        BoxAndWhiskerItem item2 = mock(BoxAndWhiskerItem.class);
                        when(item2.getMinOutlier()).thenReturn(3.0);
                        when(item2.getMaxOutlier()).thenReturn(20.0);
                        
                        // Mock the data structure
                        when(data.getRowCount()).thenReturn(2);
                        when(data.getColumnCount()).thenReturn(2);
                        
                        // Set the mock data to dataset using reflection
                        Field dataField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("data");
                        dataField.setAccessible(true);
                        dataField.set(dataset, data);
                        
                        // Initialize bounds fields
                        Field minValField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
                        minValField.setAccessible(true);
                        minValField.set(dataset, Double.NaN);
                        
                        Field maxValField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValue");
                        maxValField.setAccessible(true);
                        maxValField.set(dataset, Double.NaN);
                        
                        // Initialize index fields
                        Field minRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                        minRowField.setAccessible(true);
                        minRowField.set(dataset, -1);
                        
                        Field minColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                        minColField.setAccessible(true);
                        minColField.set(dataset, -1);
                        
                        Field maxRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueRow");
                        maxRowField.setAccessible(true);
                        maxRowField.set(dataset, -1);
                        
                        Field maxColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueColumn");
                        maxColField.setAccessible(true);
                        maxColField.set(dataset, -1);
                        
                        // Use reflection to call private updateBounds method
                        Method method = DefaultBoxAndWhiskerCategoryDataset.class
                                .getDeclaredMethod("updateBounds");
                        method.setAccessible(true);
                        method.invoke(dataset);
                        
                        // Verify results using reflection
                        assertEquals(3.0, minValField.getDouble(dataset), 0.0001);
                        assertEquals(20.0, maxValField.getDouble(dataset), 0.0001);
                        
                        assertEquals(1, minRowField.getInt(dataset));
                        assertEquals(1, minColField.getInt(dataset));
                        assertEquals(1, maxRowField.getInt(dataset));
                        assertEquals(1, maxColField.getInt(dataset));
                    }

    @Test
                    public void testAddItemFiresDatasetChanged() {
                        DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                        DefaultBoxAndWhiskerCategoryDataset spyDataset = spy(dataset);
                        
                        BoxAndWhiskerItem item = mock(BoxAndWhiskerItem.class);
                        when(item.getMinOutlier()).thenReturn(5.0);
                        when(item.getMaxOutlier()).thenReturn(15.0);
                        when(item.getMedian()).thenReturn(10.0);
                        when(item.getQ1()).thenReturn(7.0);
                        when(item.getQ3()).thenReturn(13.0);
                        when(item.getMinRegularValue()).thenReturn(6.0);
                        when(item.getMaxRegularValue()).thenReturn(14.0);
                        
                        org.jfree.data.KeyedValues2D data = mock(org.jfree.data.KeyedValues2D.class);
                        when(data.getRowIndex("Row1")).thenReturn(0);
                        when(data.getColumnIndex("Col1")).thenReturn(0);
                        
                        // Use reflection to set the private data field
                        try {
                            Field dataField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("data");
                            dataField.setAccessible(true);
                            dataField.set(spyDataset, data);
                        } catch (Exception e) {
                            fail("Failed to set data field via reflection");
                        }
                        
                        // Verify dataset change notification by checking if underlying data was modified
                        spyDataset.add(item, "Row1", "Col1");
                    }

    @Test
                public void testAddItemWithNullMinMaxOutliers() {
                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                    BoxAndWhiskerItem item = mock(BoxAndWhiskerItem.class);
                    when(item.getMinOutlier()).thenReturn(null);
                    when(item.getMaxOutlier()).thenReturn(null);
                    
                    DefaultBoxAndWhiskerCategoryDataset mockData = mock(DefaultBoxAndWhiskerCategoryDataset.class);
                    when(mockData.getColumnIndex("Col1")).thenReturn(0);
                    
                    // Use reflection to set the private data field
                    try {
                        Field dataField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("data");
                        dataField.setAccessible(true);
                        dataField.set(dataset, mockData);
                    } catch (Exception e) {
                        fail("Failed to set data field via reflection");
                    }
                    
                    dataset.add(item, "Row1", "Col1");
                
                    // Use reflection to access private fields for assertions
                    try {
                        Field minRangeValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
                        minRangeValueField.setAccessible(true);
                        Field maxRangeValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValue");
                        maxRangeValueField.setAccessible(true);
                        Field minRangeValueRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                        minRangeValueRowField.setAccessible(true);
                        Field minRangeValueColumnField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                        minRangeValueColumnField.setAccessible(true);
                        Field maxRangeValueRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueRow");
                        maxRangeValueRowField.setAccessible(true);
                        Field maxRangeValueColumnField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueColumn");
                        maxRangeValueColumnField.setAccessible(true);
                
                        assertEquals(Double.NaN, minRangeValueField.getDouble(dataset), 0.0001);
                        assertEquals(Double.NaN, maxRangeValueField.getDouble(dataset), 0.0001);
                        assertEquals(-1, minRangeValueRowField.getInt(dataset));
                        assertEquals(-1, minRangeValueColumnField.getInt(dataset));
                        assertEquals(-1, maxRangeValueRowField.getInt(dataset));
                        assertEquals(-1, maxRangeValueColumnField.getInt(dataset));
                    } catch (Exception e) {
                        fail("Failed to access private fields via reflection");
                    }
                }

    @Test
        public void testAddItemWithValidMinMaxOutliers() {
            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
            BoxAndWhiskerItem item = mock(BoxAndWhiskerItem.class);
            when(item.getMinOutlier()).thenReturn(5.0);
            when(item.getMaxOutlier()).thenReturn(15.0);
            
            // Mock the internal data structure
            Object data = mock(Object.class);
            try {
                when(data.getClass().getMethod("getRowIndex", String.class).invoke(data, "Row1")).thenReturn(0);
                when(data.getClass().getMethod("getColumnIndex", String.class).invoke(data, "Col1")).thenReturn(0);
            } catch (NoSuchMethodException | IllegalAccessException | java.lang.reflect.InvocationTargetException e) {
                fail("Failed to mock method calls via reflection");
            }
            
            // Use reflection to set the private data field
            try {
                java.lang.reflect.Field dataField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("data");
                dataField.setAccessible(true);
                dataField.set(dataset, data);
            } catch (Exception e) {
                fail("Failed to set data field via reflection");
            }
            
            dataset.add(item, "Row1", "Col1");
        
            // Use reflection to access private fields for assertions
            try {
                java.lang.reflect.Field minRangeValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
                minRangeValueField.setAccessible(true);
                double minimumRangeValue = minRangeValueField.getDouble(dataset);
                
                java.lang.reflect.Field maxRangeValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValue");
                maxRangeValueField.setAccessible(true);
                double maximumRangeValue = maxRangeValueField.getDouble(dataset);
                
                java.lang.reflect.Field minRangeValueRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                minRangeValueRowField.setAccessible(true);
                int minimumRangeValueRow = minRangeValueRowField.getInt(dataset);
                
                java.lang.reflect.Field minRangeValueColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                minRangeValueColField.setAccessible(true);
                int minimumRangeValueColumn = minRangeValueColField.getInt(dataset);
                
                java.lang.reflect.Field maxRangeValueRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueRow");
                maxRangeValueRowField.setAccessible(true);
                int maximumRangeValueRow = maxRangeValueRowField.getInt(dataset);
                
                java.lang.reflect.Field maxRangeValueColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueColumn");
                maxRangeValueColField.setAccessible(true);
                int maximumRangeValueColumn = maxRangeValueColField.getInt(dataset);
                
                assertEquals(5.0, minimumRangeValue, 0.0001);
                assertEquals(15.0, maximumRangeValue, 0.0001);
                assertEquals(0, minimumRangeValueRow);
                assertEquals(0, minimumRangeValueColumn);
                assertEquals(0, maximumRangeValueRow);
                assertEquals(0, maximumRangeValueColumn);
            } catch (Exception e) {
                fail("Failed to access private fields via reflection");
            }
        }


}
