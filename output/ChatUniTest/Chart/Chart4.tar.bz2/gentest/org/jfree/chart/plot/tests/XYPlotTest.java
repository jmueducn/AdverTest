package gentest.org.jfree.chart.plot.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.plot.*;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.TreeMap;
import org.jfree.chart.LegendItem;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.RenderingSource;
import org.jfree.chart.annotations.XYAnnotation;
import org.jfree.chart.annotations.XYAnnotationBoundsInfo;
import org.jfree.chart.axis.Axis;
import org.jfree.chart.axis.AxisCollection;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.AxisSpace;
import org.jfree.chart.axis.AxisState;
import org.jfree.chart.axis.TickType;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.axis.ValueTick;
import org.jfree.chart.event.ChartChangeEventType;
import org.jfree.chart.event.PlotChangeEvent;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.event.RendererChangeListener;
import org.jfree.chart.renderer.RendererUtilities;
import org.jfree.chart.renderer.xy.AbstractXYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.util.Layer;
import org.jfree.chart.util.ObjectList;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.chart.util.PaintUtilities;
import org.jfree.chart.util.PublicCloneable;
import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.RectangleInsets;
import org.jfree.chart.util.ResourceBundleWrapper;
import org.jfree.chart.util.SerialUtilities;
import org.jfree.data.Range;
import org.jfree.data.general.Dataset;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.xy.AbstractXYDataset;
import org.jfree.data.xy.SelectableXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYDatasetSelectionState;
 
public class XYPlotTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                            public void testGetDataRangeWithNullAxis() {
                                                XYPlot plot = new XYPlot();
                                                Range result = plot.getDataRange(null);
                                                assertNull(result);
                                            }

    @Test
                                            public void testGetDataRangeWithDomainAxis() {
                                                // Create mocks
                                                XYPlot plot = mock(XYPlot.class);
                                                ValueAxis mockAxis = mock(ValueAxis.class);
                                                XYDataset mockDataset = mock(XYDataset.class);
                                                XYItemRenderer mockRenderer = mock(XYItemRenderer.class);
                                        
                                                // Setup domain axis
                                                plot.setDomainAxis(0, mockAxis);
                                                plot.setDataset(0, mockDataset);
                                                plot.setRenderer(0, mockRenderer);
                                        
                                                // Mock behavior
                                                when(plot.getDomainAxisIndex(mockAxis)).thenReturn(0);
                                                when(mockRenderer.findDomainBounds(mockDataset)).thenReturn(new Range(1.0, 10.0));
                                                when(plot.getRendererForDataset(mockDataset)).thenReturn(mockRenderer);
                                        
                                                // Call real method
                                                Range result = plot.getDataRange(mockAxis);
                                                
                                                // Verify
                                                assertEquals(new Range(1.0, 10.0), result);
                                            }

    @Test
                                            public void testGetDataRangeWithRangeAxis() {
                                                // Create mocks
                                                XYPlot plot = mock(XYPlot.class);
                                                XYDataset mockDataset = mock(XYDataset.class);
                                                XYItemRenderer mockRenderer = mock(XYItemRenderer.class);
                                                ValueAxis mockAxis = mock(ValueAxis.class);
                                                
                                                // Setup range axis
                                                plot.setRangeAxis(0, mockAxis);
                                                plot.setDataset(0, mockDataset);
                                                plot.setRenderer(0, mockRenderer);
                                        
                                                // Mock behavior
                                                when(plot.getRangeAxisIndex(mockAxis)).thenReturn(0);
                                                when(mockRenderer.findRangeBounds(mockDataset)).thenReturn(new Range(5.0, 15.0));
                                                when(plot.getDataRange(mockAxis)).thenCallRealMethod();
                                        
                                                Range result = plot.getDataRange(mockAxis);
                                                assertEquals(new Range(5.0, 15.0), result);
                                            }

    @Test
                                            public void testGetDataRangeWithNullRenderer() {
                                                // Create mocks
                                                XYPlot plot = mock(XYPlot.class);
                                                ValueAxis mockAxis = mock(ValueAxis.class);
                                                XYDataset mockDataset = mock(XYDataset.class);
                                                
                                                // Setup domain axis with null renderer
                                                when(plot.getDomainAxis(0)).thenReturn(mockAxis);
                                                when(plot.getDataset(0)).thenReturn(mockDataset);
                                                
                                                // Mock behavior
                                                when(plot.getDomainAxisIndex(mockAxis)).thenReturn(0);
                                                when(DatasetUtilities.findDomainBounds(mockDataset)).thenReturn(new Range(2.0, 8.0));
                                                
                                                // Call real method
                                                when(plot.getDataRange(mockAxis)).thenCallRealMethod();
                                                
                                                Range result = plot.getDataRange(mockAxis);
                                                assertEquals(new Range(2.0, 8.0), result);
                                            }

    @Test
                                            public void testGetDataRangeWithMultipleDatasets() {
                                                // Create all mocks and objects needed
                                                XYPlot plot = new XYPlot();
                                                ValueAxis mockAxis = mock(ValueAxis.class);
                                                XYDataset mockDataset = mock(XYDataset.class);
                                                XYItemRenderer mockRenderer = mock(XYItemRenderer.class);
                                                XYDataset mockDataset2 = mock(XYDataset.class);
                                                XYItemRenderer mockRenderer2 = mock(XYItemRenderer.class);
                                                
                                                // Setup domain axis with multiple datasets
                                                plot.setDomainAxis(0, mockAxis);
                                                
                                                plot.setDataset(0, mockDataset);
                                                plot.setRenderer(0, mockRenderer);
                                                plot.setDataset(1, mockDataset2);
                                                plot.setRenderer(1, mockRenderer2);
                                            
                                                // Mock behavior
                                                when(plot.getDomainAxisIndex(mockAxis)).thenReturn(0);
                                                when(mockRenderer.findDomainBounds(mockDataset)).thenReturn(new Range(1.0, 5.0));
                                                when(mockRenderer2.findDomainBounds(mockDataset2)).thenReturn(new Range(3.0, 8.0));
                                            
                                                Range result = plot.getDataRange(mockAxis);
                                                assertEquals(new Range(1.0, 8.0), result);
                                            }

    @Test
                                            public void testGetDataRangeWithNonBoundsAnnotation() {
                                                // Create mocks
                                                XYPlot plot = mock(XYPlot.class);
                                                ValueAxis mockAxis = mock(ValueAxis.class);
                                                XYDataset mockDataset = mock(XYDataset.class);
                                                XYItemRenderer mockRenderer = mock(XYItemRenderer.class);
                                                
                                                // Setup with annotation that doesn't implement XYAnnotationBoundsInfo
                                                when(plot.getDomainAxis(0)).thenReturn(mockAxis);
                                                when(plot.getDataset(0)).thenReturn(mockDataset);
                                                when(plot.getRenderer(0)).thenReturn(mockRenderer);
                                                
                                                // Add regular annotation
                                                XYAnnotation regularAnnotation = mock(XYAnnotation.class);
                                                List<XYAnnotation> annotations = new ArrayList<>();
                                                annotations.add(regularAnnotation);
                                                when(plot.getAnnotations()).thenReturn(annotations);
                                                
                                                // Mock behavior
                                                when(plot.getDomainAxisIndex(mockAxis)).thenReturn(0);
                                                when(mockRenderer.findDomainBounds(mockDataset)).thenReturn(new Range(3.0, 7.0));
                                                
                                                // Call real method
                                                when(plot.getDataRange(mockAxis)).thenCallRealMethod();
                                                
                                                Range result = plot.getDataRange(mockAxis);
                                                assertEquals(new Range(3.0, 7.0), result);
                                            }

    @Test
                                        public void testGetDataRangeWithExcludedBoundsAnnotation() {
                                            // Create mock objects
                                            XYPlot plot = mock(XYPlot.class);
                                            ValueAxis mockAxis = mock(ValueAxis.class);
                                            XYDataset mockDataset = mock(XYDataset.class);
                                            XYItemRenderer mockRenderer = mock(XYItemRenderer.class);
                                            XYAnnotationBoundsInfo mockAnnotation = mock(XYAnnotationBoundsInfo.class);
                                    
                                            // Setup with annotation that doesn't include in bounds
                                            when(plot.getDomainAxis(0)).thenReturn(mockAxis);
                                            when(plot.getDataset(0)).thenReturn(mockDataset);
                                            when(plot.getRenderer(0)).thenReturn(mockRenderer);
                                            
                                            // Add annotation
                                            List<XYAnnotation> annotations = new ArrayList<>();
                                            annotations.add((XYAnnotation) mockAnnotation);
                                            when(plot.getAnnotations()).thenReturn(annotations);
                                    
                                            // Mock behavior
                                            when(plot.getDomainAxisIndex(mockAxis)).thenReturn(0);
                                            when(mockRenderer.findDomainBounds(mockDataset)).thenReturn(new Range(4.0, 6.0));
                                            when(mockAnnotation.getIncludeInDataBounds()).thenReturn(false);
                                            when(mockAnnotation.getXRange()).thenReturn(new Range(2.0, 8.0));
                                    
                                            Range result = plot.getDataRange(mockAxis);
                                            assertEquals(new Range(4.0, 6.0), result);
                                        }

    @Test
        public void testGetDataRangeWithAnnotations() {
            // Create mock objects
            XYPlot plot = mock(XYPlot.class);
            ValueAxis mockAxis = mock(ValueAxis.class);
            XYDataset mockDataset = mock(XYDataset.class);
            XYItemRenderer mockRenderer = mock(XYItemRenderer.class);
            XYAnnotation mockAnnotation = mock(XYAnnotation.class);
            
            // Setup domain axis with annotations
            when(plot.getDomainAxis(0)).thenReturn(mockAxis);
            when(plot.getDataset(0)).thenReturn(mockDataset);
            when(plot.getRenderer(0)).thenReturn(mockRenderer);
            
            // Add annotation
            List<XYAnnotation> annotations = new ArrayList<>();
            annotations.add(mockAnnotation);
            
            // Use reflection to set private field
            try {
                java.lang.reflect.Field field = XYPlot.class.getDeclaredField("annotations");
                field.setAccessible(true);
                field.set(plot, annotations);
            } catch (Exception e) {
                fail("Failed to set annotations field via reflection");
            }
        
            // Mock behavior
            when(plot.getDomainAxisIndex(mockAxis)).thenReturn(0);
            when(mockRenderer.findDomainBounds(mockDataset)).thenReturn(new Range(1.0, 5.0));
            
            // Use reflection to call getXRange since it's not in XYAnnotation interface
            try {
                java.lang.reflect.Method method = mockAnnotation.getClass().getMethod("getXRange");
                when(method.invoke(mockAnnotation)).thenReturn(new Range(0.5, 6.0));
            } catch (Exception e) {
                fail("Failed to mock getXRange method");
            }
        
            // Call real method
            Range result = plot.getDataRange(mockAxis);
            assertEquals(new Range(0.5, 6.0), result);
        }

    @Test
        public void testGetDataRangeWithRendererAnnotations() {
            // Create mock objects
            XYPlot plot = mock(XYPlot.class);
            ValueAxis mockAxis = mock(ValueAxis.class);
            XYDataset mockDataset = mock(XYDataset.class);
            XYItemRenderer mockRenderer = mock(XYItemRenderer.class);
            XYAnnotation mockAnnotation = mock(XYAnnotation.class);
            
            // Setup domain axis with renderer annotations
            when(plot.getDomainAxis(0)).thenReturn(mockAxis);
            when(plot.getDataset(0)).thenReturn(mockDataset);
            when(plot.getRenderer(0)).thenReturn(mockRenderer);
            
            // Mock renderer annotations
            List<XYAnnotation> rendererAnnotations = new ArrayList<>();
            rendererAnnotations.add(mockAnnotation);
            when(mockRenderer.getAnnotations()).thenReturn(rendererAnnotations);
        
            // Mock behavior
            when(plot.getDomainAxisIndex(mockAxis)).thenReturn(0);
            when(mockRenderer.findDomainBounds(mockDataset)).thenReturn(new Range(2.0, 6.0));
            
            // Create mock annotation behavior using Mockito's Answer
        
            Range result = plot.getDataRange(mockAxis);
            assertEquals(new Range(1.5, 7.0), result);
        }


}
