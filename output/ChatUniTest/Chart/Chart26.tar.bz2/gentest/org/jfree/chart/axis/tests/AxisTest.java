package gentest.org.jfree.chart.axis.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.axis.*;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.AffineTransform;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Arrays;
import java.util.EventListener;
import java.util.List;
import javax.swing.event.EventListenerList;
import org.jfree.chart.ChartRenderingInfo;
import org.jfree.chart.entity.AxisLabelEntity;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.event.AxisChangeEvent;
import org.jfree.chart.event.AxisChangeListener;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.text.TextAnchor;
import org.jfree.chart.text.TextUtilities;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.chart.util.PaintUtilities;
import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.RectangleInsets;
import org.jfree.chart.util.SerialUtilities;
 
public class AxisTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                        public void testDrawLabelWithNullOrEmptyLabel() throws Exception {
                                                                            // Create mock objects
                                                                            Axis axis = mock(Axis.class);
                                                                            Graphics2D g2 = mock(Graphics2D.class);
                                                                            Rectangle2D plotArea = mock(Rectangle2D.class);
                                                                            Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                            AxisState state = mock(AxisState.class);
                                                                            PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                                            
                                                                            // Get the protected method via reflection
                                                                            Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                "drawLabel", 
                                                                                String.class, 
                                                                                Graphics2D.class, 
                                                                                Rectangle2D.class, 
                                                                                Rectangle2D.class, 
                                                                                RectangleEdge.class, 
                                                                                AxisState.class, 
                                                                                PlotRenderingInfo.class
                                                                            );
                                                                            drawLabelMethod.setAccessible(true);
                                                                            
                                                                            // Stub the method call
                                                                            when(drawLabelMethod.invoke(
                                                                                axis, 
                                                                                anyString(), 
                                                                                any(Graphics2D.class), 
                                                                                any(Rectangle2D.class),
                                                                                any(Rectangle2D.class), 
                                                                                any(RectangleEdge.class), 
                                                                                any(AxisState.class),
                                                                                any(PlotRenderingInfo.class))
                                                                            ).thenReturn(state);
                                                                            
                                                                            // Test with null label
                                                                            AxisState result1 = (AxisState) drawLabelMethod.invoke(
                                                                                axis, 
                                                                                null, 
                                                                                g2, 
                                                                                plotArea, 
                                                                                dataArea, 
                                                                                RectangleEdge.TOP, 
                                                                                state, 
                                                                                plotState
                                                                            );
                                                                            assertSame(state, result1);
                                                                            
                                                                            // Test with empty label
                                                                            AxisState result2 = (AxisState) drawLabelMethod.invoke(
                                                                                axis, 
                                                                                "", 
                                                                                g2, 
                                                                                plotArea, 
                                                                                dataArea, 
                                                                                RectangleEdge.TOP, 
                                                                                state, 
                                                                                plotState
                                                                            );
                                                                            assertSame(state, result2);
                                                                        }

    @Test
                                                                    public void testDrawLabelWithPlotStateAndHotspot() throws Exception {
                                                                        // Create all necessary mocks and objects
                                                                        Axis axis = mock(Axis.class, CALLS_REAL_METHODS);
                                                                        Graphics2D g2 = mock(Graphics2D.class);
                                                                        Rectangle2D plotArea = mock(Rectangle2D.class);
                                                                        Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                        AxisState state = new AxisState();
                                                                        PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                                        ChartRenderingInfo owner = mock(ChartRenderingInfo.class);
                                                                        EntityCollection entities = mock(EntityCollection.class);
                                                                
                                                                        // Setup mock behavior
                                                                        when(plotState.getOwner()).thenReturn(owner);
                                                                        when(owner.getEntityCollection()).thenReturn(entities);
                                                                        
                                                                        // Set up test conditions
                                                                        state.setCursor(150);
                                                                        
                                                                        // Use reflection to access protected method
                                                                        Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                            "drawLabel", 
                                                                            String.class, 
                                                                            Graphics2D.class, 
                                                                            Rectangle2D.class, 
                                                                            Rectangle2D.class, 
                                                                            RectangleEdge.class, 
                                                                            AxisState.class, 
                                                                            PlotRenderingInfo.class
                                                                        );
                                                                        drawLabelMethod.setAccessible(true);
                                                                        
                                                                        // Execute test
                                                                        AxisState result = (AxisState) drawLabelMethod.invoke(
                                                                            axis, 
                                                                            "Test", 
                                                                            g2, 
                                                                            plotArea, 
                                                                            dataArea, 
                                                                            RectangleEdge.TOP, 
                                                                            state, 
                                                                            plotState
                                                                        );
                                                                        
                                                                        // Verify results
                                                                        assertNotNull(result);
                                                                        verify(entities).add(any(AxisLabelEntity.class));
                                                                    }

    @Test
        public void testDrawLabelBottomEdge() throws Exception {
            // Setup mocks and test objects
            Axis axis = mock(Axis.class);
            Graphics2D g2 = mock(Graphics2D.class);
            Rectangle2D plotArea = new Rectangle2D.Float(0, 0, 500, 200);
            Rectangle2D dataArea = new Rectangle2D.Float(100, 100, 300, 100);
            AxisState state = new AxisState();
            PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
            
            // Define captors
            when(axis.getLabelFont()).thenReturn(new Font("Arial", Font.PLAIN, 12));
            when(axis.getLabelPaint()).thenReturn(java.awt.Color.BLACK);
            when(axis.getLabelInsets()).thenReturn(new RectangleInsets(10, 10, 10, 10));
            when(axis.getLabelAngle()).thenReturn(0.0);
            
            state.setCursor(150);
            
            // Use reflection to access protected method
            java.lang.reflect.Method method = Axis.class.getDeclaredMethod(
                "drawLabel", 
                String.class, 
                Graphics2D.class, 
                Rectangle2D.class, 
                Rectangle2D.class, 
                RectangleEdge.class, 
                AxisState.class, 
                PlotRenderingInfo.class
            );
            method.setAccessible(true);
            AxisState result = (AxisState) method.invoke(
                axis, 
                "Test", 
                g2, 
                plotArea, 
                dataArea, 
                RectangleEdge.BOTTOM, 
                state, 
                plotState
            );
            
            assertNotNull(result);
            verify(g2).setFont(axis.getLabelFont());
            verify(g2).setPaint(axis.getLabelPaint());
            
            // Verify text drawing position
        }

    @Test
        public void testDrawLabelLeftEdge() throws Exception {
            // Create mocks and test objects
            Axis axis = mock(Axis.class);
            Graphics2D g2 = mock(Graphics2D.class);
            Rectangle2D plotArea = mock(Rectangle2D.class);
            Rectangle2D dataArea = mock(Rectangle2D.class);
            AxisState state = new AxisState();
            PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
            
            // Create captors
            when(axis.getLabelFont()).thenReturn(new Font("Arial", Font.PLAIN, 12));
            when(axis.getLabelPaint()).thenReturn(java.awt.Color.BLACK);
            when(axis.getLabelInsets()).thenReturn(new RectangleInsets(10, 10, 10, 10));
            when(axis.getLabelAngle()).thenReturn(0.0);
            when(dataArea.getCenterY()).thenReturn(250.0);
            when(dataArea.getY()).thenReturn(200.0);
            when(dataArea.getHeight()).thenReturn(100.0);
            when(plotArea.getX()).thenReturn(0.0);
            when(plotArea.getWidth()).thenReturn(500.0);
            
            // Set up state
            state.setCursor(150);
            
            // Use reflection to access protected method
            Method drawLabelMethod = Axis.class.getDeclaredMethod(
                "drawLabel", 
                String.class, 
                Graphics2D.class, 
                Rectangle2D.class, 
                Rectangle2D.class, 
                RectangleEdge.class, 
                AxisState.class, 
                PlotRenderingInfo.class
            );
            drawLabelMethod.setAccessible(true);
            
            // Call method under test
            AxisState result = (AxisState) drawLabelMethod.invoke(
                axis, 
                "Test", 
                g2, 
                plotArea, 
                dataArea, 
                RectangleEdge.LEFT, 
                state, 
                plotState
            );
            
            // Verify results
            assertNotNull(result);
            verify(g2).setFont(any(Font.class));
            verify(g2).setPaint(any(java.awt.Paint.class));
            
            // Verify text position
        }

    @Test
        public void testDrawLabelRightEdge() throws Exception {
            // Create mock objects
            java.awt.Graphics2D g2 = mock(java.awt.Graphics2D.class);
            Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 500, 500);
            Rectangle2D dataArea = new Rectangle2D.Double(100, 100, 300, 300);
            AxisState state = new AxisState();
            PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
            
            // Create argument captors for x and y coordinates
            Axis axis = mock(Axis.class);
            when(axis.getLabelFont()).thenReturn(new Font("Arial", Font.PLAIN, 12));
            when(axis.getLabelPaint()).thenReturn(Color.BLACK);
            when(axis.getLabelInsets()).thenReturn(new RectangleInsets(10, 10, 10, 10));
            when(axis.getLabelAngle()).thenReturn(0.0);
            
            // Set up state
            state.setCursor(150);
            
            // Use reflection to access protected method
            Method drawLabelMethod = Axis.class.getDeclaredMethod(
                "drawLabel", 
                String.class, 
                java.awt.Graphics2D.class, 
                Rectangle2D.class, 
                Rectangle2D.class, 
                RectangleEdge.class, 
                AxisState.class, 
                PlotRenderingInfo.class
            );
            drawLabelMethod.setAccessible(true);
            
            // Call method under test
            AxisState result = (AxisState) drawLabelMethod.invoke(
                axis, 
                "Test", 
                g2, 
                plotArea, 
                dataArea, 
                RectangleEdge.RIGHT, 
                state, 
                plotState
            );
            
            // Verify results
            assertNotNull(result);
            verify(g2).setFont(any(Font.class));
            verify(g2).setPaint(any(Color.class));
            
            // Verify text position
        }

    @Test
        public void testDrawLabelTopEdge() throws Exception {
            // Setup test objects
            Axis axis = mock(Axis.class);
            when(axis.getLabelFont()).thenReturn(new Font("Arial", Font.PLAIN, 12));
            when(axis.getLabelPaint()).thenReturn(java.awt.Color.BLACK);
            when(axis.getLabelInsets()).thenReturn(new RectangleInsets(10, 10, 10, 10));
            when(axis.getLabelAngle()).thenReturn(0.0);
            
            // Use reflection to access protected method
            Method drawLabelMethod = Axis.class.getDeclaredMethod(
                "drawLabel", 
                String.class, 
                Graphics2D.class, 
                Rectangle2D.class, 
                Rectangle2D.class, 
                RectangleEdge.class, 
                AxisState.class, 
                PlotRenderingInfo.class
            );
            drawLabelMethod.setAccessible(true);
            
            Graphics2D g2 = mock(Graphics2D.class);
            FontMetrics fm = mock(FontMetrics.class);
            when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
            when(fm.stringWidth(anyString())).thenReturn(100);
            when(fm.getHeight()).thenReturn(12);
            
            Rectangle2D plotArea = new Rectangle2D.Float(0, 0, 500, 500);
            Rectangle2D dataArea = new Rectangle2D.Float(100, 100, 300, 300);
            AxisState state = new AxisState();
            state.setCursor(150);
            
            PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
            ChartRenderingInfo owner = mock(ChartRenderingInfo.class);
            EntityCollection entities = mock(EntityCollection.class);
            when(plotState.getOwner()).thenReturn(owner);
            when(owner.getEntityCollection()).thenReturn(entities);
        
            // Define argument captors
            AxisState result = (AxisState) drawLabelMethod.invoke(
                axis, 
                "Test", 
                g2, 
                plotArea, 
                dataArea, 
                RectangleEdge.TOP, 
                state, 
                plotState
            );
            
            // Verify results
            assertNotNull(result);
            Font expectedFont = new Font("Arial", Font.PLAIN, 12);
            verify(g2).setFont(expectedFont);
            verify(g2).setPaint(java.awt.Color.BLACK);
            verify(g2).getFontMetrics(expectedFont);
            
            // Verify text position
        }

    @Test
        public void testDrawLabelWithNullState() {
            Graphics2D g2 = mock(Graphics2D.class);
            Axis axis = new Axis("Test Axis") {
                @Override
                public void configure() {
                    // Empty implementation
                }
                
                @Override
                public AxisSpace reserveSpace(Graphics2D g2, Plot plot, 
                        Rectangle2D area, RectangleEdge edge, AxisSpace space) {
                    return new AxisSpace();
                }
                
                public double valueToJava2D(double value, Rectangle2D area, RectangleEdge edge) {
                    return 0;
                }
        
                public AxisState drawTickMarksAndLabels(Graphics2D g2, double cursor,
                        Rectangle2D plotArea, Rectangle2D dataArea, RectangleEdge edge) {
                    return new AxisState(0);
                }
        
                @Override
                public AxisState draw(Graphics2D g2, double cursor, Rectangle2D plotArea,
                        Rectangle2D dataArea, RectangleEdge edge, PlotRenderingInfo plotState) {
                    return new AxisState(0);
                }
        
                @Override
                public java.util.List refreshTicks(Graphics2D g2, AxisState state,
                        Rectangle2D dataArea, RectangleEdge edge) {
                    return new java.util.ArrayList();
                }
            };
        
            Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
            Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
            PlotRenderingInfo plotState = new PlotRenderingInfo(null);
        
            try {
                java.lang.reflect.Method method = Axis.class.getDeclaredMethod(
                    "drawLabel", String.class, Graphics2D.class, Rectangle2D.class, 
                    Rectangle2D.class, RectangleEdge.class, AxisState.class, 
                    PlotRenderingInfo.class);
                method.setAccessible(true);
                method.invoke(axis, "Label", g2, plotArea, dataArea, 
                    RectangleEdge.TOP, null, plotState);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }


}
