package gentest.org.jfree.chart.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.util.*;
import java.awt.Shape;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
 
public class ShapeListTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                        public void testEqualsWithSameObject() {
                                                                                            ShapeList list = new ShapeList();
                                                                                            assertTrue(list.equals(list));
                                                                                        }

    @Test
                                                                                        public void testEqualsWithNull() {
                                                                                            ShapeList list = new ShapeList();
                                                                                            assertFalse(list.equals(null));
                                                                                        }

    @Test
                                                                                        public void testEqualsWithDifferentClass() {
                                                                                            ShapeList list = new ShapeList();
                                                                                            assertFalse(list.equals("Not a ShapeList"));
                                                                                        }

    @Test
                                                                                        public void testEqualsWithEmptyLists() {
                                                                                            ShapeList list1 = new ShapeList();
                                                                                            ShapeList list2 = new ShapeList();
                                                                                            assertTrue(list1.equals(list2));
                                                                                        }

    @Test
                                                                                        public void testEqualsWithBothNullShapes() {
                                                                                            ShapeList list1 = new ShapeList();
                                                                                            ShapeList list2 = new ShapeList();
                                                                                            
                                                                                            list1.setShape(0, null);
                                                                                            list2.setShape(0, null);
                                                                                            
                                                                                            assertTrue(list1.equals(list2));
                                                                                        }

    @Test
                                                public void testEqualsWithDifferentSizedLists() {
                                                    ShapeList list1 = new ShapeList();
                                                    ShapeList list2 = new ShapeList();
                                                    
                                                    
                                                    assertFalse(list1.equals(list2));
                                                }

    @Test
        public void testEqualsWithEqualShapes() {
            ShapeList list1 = new ShapeList();
            ShapeList list2 = new ShapeList();
            
            
            assertTrue(list1.equals(list2));
        }

    @Test
        public void testEqualsWithDifferentShapes() {
            ShapeList list1 = new ShapeList();
            ShapeList list2 = new ShapeList();
            
            
            assertFalse(list1.equals(list2));
        }

    @Test
        public void testEqualsWithMultipleShapes() {
            ShapeList list1 = new ShapeList();
            ShapeList list2 = new ShapeList();
            
            
            assertTrue(list1.equals(list2));
        }

    @Test
        public void testEqualsWithOneNullShape() {
            ShapeList list1 = new ShapeList();
            ShapeList list2 = new ShapeList();
            
            list2.setShape(0, null);
            
            assertFalse(list1.equals(list2));
        }


}
