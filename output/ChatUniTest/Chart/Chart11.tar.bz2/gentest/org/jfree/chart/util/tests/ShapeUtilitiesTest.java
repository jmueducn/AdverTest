package gentest.org.jfree.chart.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.util.*;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.Arrays;
 
public class ShapeUtilitiesTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                    public void testEqual_OneNullShape() {
                                                        Line2D line = new Line2D.Double(1, 2, 3, 4);
                                                        assertFalse(ShapeUtilities.equal(line, null));
                                                        assertFalse(ShapeUtilities.equal(null, line));
                                                    }

    @Test
                                                    public void testEqual_Line2DShapes() {
                                                        Line2D line1 = new Line2D.Double(1, 2, 3, 4);
                                                        Line2D line2 = new Line2D.Double(1, 2, 3, 4);
                                                        Line2D line3 = new Line2D.Double(1, 2, 3, 5);
                                                        
                                                        assertTrue(ShapeUtilities.equal(line1, line2));
                                                        assertFalse(ShapeUtilities.equal(line1, line3));
                                                    }

    @Test
                                                    public void testEqual_Ellipse2DShapes() {
                                                        Ellipse2D ellipse1 = new Ellipse2D.Double(1, 2, 3, 4);
                                                        Ellipse2D ellipse2 = new Ellipse2D.Double(1, 2, 3, 4);
                                                        Ellipse2D ellipse3 = new Ellipse2D.Double(1, 2, 3, 5);
                                                        
                                                        assertTrue(ShapeUtilities.equal(ellipse1, ellipse2));
                                                        assertFalse(ShapeUtilities.equal(ellipse1, ellipse3));
                                                    }

    @Test
                                                    public void testEqual_Arc2DShapes() {
                                                        Arc2D arc1 = new Arc2D.Double(1, 2, 3, 4, 5, 6, Arc2D.PIE);
                                                        Arc2D arc2 = new Arc2D.Double(1, 2, 3, 4, 5, 6, Arc2D.PIE);
                                                        Arc2D arc3 = new Arc2D.Double(1, 2, 3, 4, 5, 7, Arc2D.PIE);
                                                        Arc2D arc4 = new Arc2D.Double(1, 2, 3, 4, 5, 6, Arc2D.CHORD);
                                                        
                                                        assertTrue(ShapeUtilities.equal(arc1, arc2));
                                                        assertFalse(ShapeUtilities.equal(arc1, arc3));
                                                        assertFalse(ShapeUtilities.equal(arc1, arc4));
                                                    }

    @Test
                                                    public void testEqual_PolygonShapes() {
                                                        Polygon poly1 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                                        Polygon poly2 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                                        Polygon poly3 = new Polygon(new int[]{1, 2, 4}, new int[]{4, 5, 6}, 3);
                                                        Polygon poly4 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 7}, 3);
                                                        
                                                        assertTrue(ShapeUtilities.equal(poly1, poly2));
                                                        assertFalse(ShapeUtilities.equal(poly1, poly3));
                                                        assertFalse(ShapeUtilities.equal(poly1, poly4));
                                                    }

    @Test
                                                    public void testEqual_GeneralPathShapes() {
                                                        GeneralPath path1 = new GeneralPath();
                                                        path1.moveTo(1, 2);
                                                        path1.lineTo(3, 4);
                                                        
                                                        GeneralPath path2 = new GeneralPath();
                                                        path2.moveTo(1, 2);
                                                        path2.lineTo(3, 4);
                                                        
                                                        GeneralPath path3 = new GeneralPath();
                                                        path3.moveTo(1, 2);
                                                        path3.lineTo(3, 5);
                                                        
                                                        assertTrue(ShapeUtilities.equal(path1, path2));
                                                        assertFalse(ShapeUtilities.equal(path1, path3));
                                                    }

    @Test
                                                    public void testEqual_Rectangle2DShapes() {
                                                        Rectangle2D rect1 = new Rectangle2D.Double(1, 2, 3, 4);
                                                        Rectangle2D rect2 = new Rectangle2D.Double(1, 2, 3, 4);
                                                        Rectangle2D rect3 = new Rectangle2D.Double(1, 2, 3, 5);
                                                        
                                                        assertTrue(ShapeUtilities.equal(rect1, rect2));
                                                        assertFalse(ShapeUtilities.equal(rect1, rect3));
                                                    }

    @Test
                                                    public void testEqual_DifferentShapeTypes() {
                                                        Line2D line = new Line2D.Double(1, 2, 3, 4);
                                                        Ellipse2D ellipse = new Ellipse2D.Double(1, 2, 3, 4);
                                                        
                                                        assertFalse(ShapeUtilities.equal(line, ellipse));
                                                    }

    @Test
                                                    public void testEqualFirstNullSecondNotNull() {
                                                        Line2D line = new Line2D.Double(1, 2, 3, 4);
                                                        assertFalse(ShapeUtilities.equal(null, line));
                                                    }

    @Test
                                                    public void testEqualFirstNotNullSecondNull() {
                                                        Line2D line = new Line2D.Double(1, 2, 3, 4);
                                                        assertFalse(ShapeUtilities.equal(line, null));
                                                    }

    @Test
                                                    public void testEqualSameInstance() {
                                                        Line2D line = new Line2D.Double(1, 2, 3, 4);
                                                        assertTrue(ShapeUtilities.equal(line, line));
                                                    }

    @Test
                                                    public void testEqualDifferentInstancesSameCoordinates() {
                                                        Line2D line1 = new Line2D.Double(1, 2, 3, 4);
                                                        Line2D line2 = new Line2D.Double(1, 2, 3, 4);
                                                        assertTrue(ShapeUtilities.equal(line1, line2));
                                                    }

    @Test
                                                    public void testEqualDifferentP() {
                                                        Line2D line1 = new Line2D.Double(1, 2, 3, 4);
                                                        Line2D line2 = new Line2D.Double(5, 6, 3, 4);
                                                        assertFalse(ShapeUtilities.equal(line1, line2));
                                                    }

    @Test
                                                    public void testEqualDifferentP1() {
                                                        Line2D line1 = new Line2D.Double(1, 2, 3, 4);
                                                        Line2D line2 = new Line2D.Double(1, 2, 5, 6);
                                                        assertFalse(ShapeUtilities.equal(line1, line2));
                                                    }

    @Test
                                                    public void testEqualDifferentP1AndP() {
                                                        Line2D line1 = new Line2D.Double(1, 2, 3, 4);
                                                        Line2D line2 = new Line2D.Double(5, 6, 7, 8);
                                                        assertFalse(ShapeUtilities.equal(line1, line2));
                                                    }

    @Test
                                                    public void testEqualWithSamePointsDifferentOrder() {
                                                        Line2D line1 = new Line2D.Double(1, 2, 3, 4);
                                                        Line2D line2 = new Line2D.Double(3, 4, 1, 2);
                                                        assertFalse(ShapeUtilities.equal(line1, line2));
                                                    }

    @Test
                                                    public void testEqualWithFloatingPointPrecision() {
                                                        Line2D line1 = new Line2D.Double(1.0000001, 2.0000001, 3.0000001, 4.0000001);
                                                        Line2D line2 = new Line2D.Double(1.0000002, 2.0000002, 3.0000002, 4.0000002);
                                                        assertTrue(ShapeUtilities.equal(line1, line2));
                                                    }

    @Test
                                                    public void testEqualEllipse2D_FirstNullSecondNotNull() {
                                                        Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                                                        assertFalse(ShapeUtilities.equal(null, e2));
                                                    }

    @Test
                                                    public void testEqualEllipse2D_FirstNotNullSecondNull() {
                                                        Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                        assertFalse(ShapeUtilities.equal(e1, null));
                                                    }

    @Test
                                                    public void testEqualEllipse2D_EqualFrames() {
                                                        Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                        Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                                                        assertTrue(ShapeUtilities.equal(e1, e2));
                                                    }

    @Test
                                                    public void testEqualEllipse2D_DifferentFrames() {
                                                        Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                        Ellipse2D e2 = new Ellipse2D.Double(1, 1, 10, 10);
                                                        assertFalse(ShapeUtilities.equal(e1, e2));
                                                    }

    @Test
                                                    public void testEqualEllipse2D_DifferentWidth() {
                                                        Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                        Ellipse2D e2 = new Ellipse2D.Double(0, 0, 20, 10);
                                                        assertFalse(ShapeUtilities.equal(e1, e2));
                                                    }

    @Test
                                                    public void testEqualEllipse2D_DifferentHeight() {
                                                        Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                        Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 20);
                                                        assertFalse(ShapeUtilities.equal(e1, e2));
                                                    }

    @Test
                                                    public void testEqualEllipse2D_DifferentPosition() {
                                                        Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                        Ellipse2D e2 = new Ellipse2D.Double(5, 5, 10, 10);
                                                        assertFalse(ShapeUtilities.equal(e1, e2));
                                                    }

    @Test
                                                    public void testEqualEllipse2D_SubclassComparison() {
                                                        Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                        Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10) {};
                                                        assertTrue(ShapeUtilities.equal(e1, e2));
                                                    }

    @Test
                                                    public void testEqualArc2D_FirstNullSecondNotNull() {
                                                        Arc2D arc = mock(Arc2D.class);
                                                        assertFalse(ShapeUtilities.equal(null, arc));
                                                    }

    @Test
                                                    public void testEqualArc2D_FirstNotNullSecondNull() {
                                                        Arc2D arc = mock(Arc2D.class);
                                                        assertFalse(ShapeUtilities.equal(arc, null));
                                                    }

    @Test
                                                    public void testEqualArc2D_DifferentFrames() {
                                                        Arc2D arc1 = mock(Arc2D.class);
                                                        Arc2D arc2 = mock(Arc2D.class);
                                                        Rectangle2D frame1 = mock(Rectangle2D.class);
                                                        Rectangle2D frame2 = mock(Rectangle2D.class);
                                                        
                                                        when(arc1.getFrame()).thenReturn(frame1);
                                                        when(arc2.getFrame()).thenReturn(frame2);
                                                        when(frame1.equals(frame2)).thenReturn(false);
                                                        
                                                        assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                    }

    @Test
                                                    public void testEqualArc2D_DifferentAngleStart() {
                                                        Arc2D arc1 = mock(Arc2D.class);
                                                        Arc2D arc2 = mock(Arc2D.class);
                                                        Rectangle2D frame = mock(Rectangle2D.class);
                                                        
                                                        when(arc1.getFrame()).thenReturn(frame);
                                                        when(arc2.getFrame()).thenReturn(frame);
                                                        when(frame.equals(frame)).thenReturn(true);
                                                        when(arc1.getAngleStart()).thenReturn(10.0);
                                                        when(arc2.getAngleStart()).thenReturn(20.0);
                                                        
                                                        assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                    }

    @Test
                                                    public void testEqualArc2D_DifferentAngleExtent() {
                                                        Arc2D arc1 = mock(Arc2D.class);
                                                        Arc2D arc2 = mock(Arc2D.class);
                                                        Rectangle2D frame = mock(Rectangle2D.class);
                                                        
                                                        when(arc1.getFrame()).thenReturn(frame);
                                                        when(arc2.getFrame()).thenReturn(frame);
                                                        when(frame.equals(frame)).thenReturn(true);
                                                        when(arc1.getAngleStart()).thenReturn(10.0);
                                                        when(arc2.getAngleStart()).thenReturn(10.0);
                                                        when(arc1.getAngleExtent()).thenReturn(30.0);
                                                        when(arc2.getAngleExtent()).thenReturn(40.0);
                                                        
                                                        assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                    }

    @Test
                                                    public void testEqualArc2D_DifferentArcType() {
                                                        Arc2D arc1 = mock(Arc2D.class);
                                                        Arc2D arc2 = mock(Arc2D.class);
                                                        Rectangle2D frame = mock(Rectangle2D.class);
                                                        
                                                        when(arc1.getFrame()).thenReturn(frame);
                                                        when(arc2.getFrame()).thenReturn(frame);
                                                        when(frame.equals(frame)).thenReturn(true);
                                                        when(arc1.getAngleStart()).thenReturn(10.0);
                                                        when(arc2.getAngleStart()).thenReturn(10.0);
                                                        when(arc1.getAngleExtent()).thenReturn(30.0);
                                                        when(arc2.getAngleExtent()).thenReturn(30.0);
                                                        when(arc1.getArcType()).thenReturn(Arc2D.OPEN);
                                                        when(arc2.getArcType()).thenReturn(Arc2D.CHORD);
                                                        
                                                        assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                    }

    @Test
                                                    public void testEqualArc2D_EqualArcs() {
                                                        Arc2D arc1 = mock(Arc2D.class);
                                                        Arc2D arc2 = mock(Arc2D.class);
                                                        Rectangle2D frame = mock(Rectangle2D.class);
                                                        
                                                        when(arc1.getFrame()).thenReturn(frame);
                                                        when(arc2.getFrame()).thenReturn(frame);
                                                        when(frame.equals(frame)).thenReturn(true);
                                                        when(arc1.getAngleStart()).thenReturn(10.0);
                                                        when(arc2.getAngleStart()).thenReturn(10.0);
                                                        when(arc1.getAngleExtent()).thenReturn(30.0);
                                                        when(arc2.getAngleExtent()).thenReturn(30.0);
                                                        when(arc1.getArcType()).thenReturn(Arc2D.OPEN);
                                                        when(arc2.getArcType()).thenReturn(Arc2D.OPEN);
                                                        
                                                        assertTrue(ShapeUtilities.equal(arc1, arc2));
                                                    }

    @Test
                                                    public void testEqualFirstNullSecondNotNull1() {
                                                        Polygon p2 = new Polygon(new int[]{1, 2}, new int[]{3, 4}, 2);
                                                        assertFalse(ShapeUtilities.equal(null, p2));
                                                    }

    @Test
                                                    public void testEqualFirstNotNullSecondNull1() {
                                                        Polygon p1 = new Polygon(new int[]{1, 2}, new int[]{3, 4}, 2);
                                                        assertFalse(ShapeUtilities.equal(p1, null));
                                                    }

    @Test
                                                    public void testEqualDifferentPointCounts() {
                                                        Polygon p1 = new Polygon(new int[]{1, 2}, new int[]{3, 4}, 2);
                                                        Polygon p2 = new Polygon(new int[]{1, 2, 3}, new int[]{3, 4, 5}, 3);
                                                        assertFalse(ShapeUtilities.equal(p1, p2));
                                                    }

    @Test
                                                    public void testEqualDifferentXPoints() {
                                                        Polygon p1 = new Polygon(new int[]{1, 2}, new int[]{3, 4}, 2);
                                                        Polygon p2 = new Polygon(new int[]{1, 3}, new int[]{3, 4}, 2);
                                                        assertFalse(ShapeUtilities.equal(p1, p2));
                                                    }

    @Test
                                                    public void testEqualDifferentYPoints() {
                                                        Polygon p1 = new Polygon(new int[]{1, 2}, new int[]{3, 4}, 2);
                                                        Polygon p2 = new Polygon(new int[]{1, 2}, new int[]{3, 5}, 2);
                                                        assertFalse(ShapeUtilities.equal(p1, p2));
                                                    }

    @Test
                                                    public void testEqualSamePolygons() {
                                                        Polygon p1 = new Polygon(new int[]{1, 2}, new int[]{3, 4}, 2);
                                                        Polygon p2 = new Polygon(new int[]{1, 2}, new int[]{3, 4}, 2);
                                                        assertTrue(ShapeUtilities.equal(p1, p2));
                                                    }

    @Test
                                                    public void testEqualSamePointsDifferentOrder() {
                                                        Polygon p1 = new Polygon(new int[]{1, 2}, new int[]{3, 4}, 2);
                                                        Polygon p2 = new Polygon(new int[]{2, 1}, new int[]{4, 3}, 2);
                                                        assertFalse(ShapeUtilities.equal(p1, p2));
                                                    }

    @Test
                                                    public void testEqualEmptyPolygons() {
                                                        Polygon p1 = new Polygon();
                                                        Polygon p2 = new Polygon();
                                                        assertTrue(ShapeUtilities.equal(p1, p2));
                                                    }

    @Test
                                                    public void testEqualDifferentLengthArraysSameCount() {
                                                        Polygon p1 = new Polygon(new int[]{1, 2}, new int[]{3, 4}, 2);
                                                        Polygon p2 = new Polygon(new int[10], new int[10], 2);
                                                        p2.xpoints[0] = 1;
                                                        p2.xpoints[1] = 2;
                                                        p2.ypoints[0] = 3;
                                                        p2.ypoints[1] = 4;
                                                        assertTrue(ShapeUtilities.equal(p1, p2));
                                                    }

    @Test
                                                    public void testEqualFirstNullSecondNotNull2() {
                                                        GeneralPath path = new GeneralPath();
                                                        assertFalse(ShapeUtilities.equal(null, path));
                                                    }

    @Test
                                                    public void testEqualFirstNotNullSecondNull2() {
                                                        GeneralPath path = new GeneralPath();
                                                        assertFalse(ShapeUtilities.equal(path, null));
                                                    }

    @Test
                                                    public void testEqualDifferentWindingRules() {
                                                        GeneralPath path1 = new GeneralPath(GeneralPath.WIND_NON_ZERO);
                                                        GeneralPath path2 = new GeneralPath(GeneralPath.WIND_EVEN_ODD);
                                                        assertFalse(ShapeUtilities.equal(path1, path2));
                                                    }

    @Test
                                                    public void testEqualDifferentSegmentTypes() throws Exception {
                                                        GeneralPath path1 = new GeneralPath();
                                                        path1.moveTo(0, 0);
                                                        path1.lineTo(10, 10);
                                                        
                                                        GeneralPath path2 = new GeneralPath();
                                                        path2.moveTo(0, 0);
                                                        path2.quadTo(5, 5, 10, 10);
                                                        
                                                        assertFalse(ShapeUtilities.equal(path1, path2));
                                                    }

    @Test
                                                    public void testEqualDifferentSegmentData() throws Exception {
                                                        GeneralPath path1 = new GeneralPath();
                                                        path1.moveTo(0, 0);
                                                        path1.lineTo(10, 10);
                                                        
                                                        GeneralPath path2 = new GeneralPath();
                                                        path2.moveTo(0, 0);
                                                        path2.lineTo(20, 20);
                                                        
                                                        assertFalse(ShapeUtilities.equal(path1, path2));
                                                    }

    @Test
                                                    public void testEqualDifferentDoneStates() throws Exception {
                                                        GeneralPath path1 = new GeneralPath();
                                                        path1.moveTo(0, 0);
                                                        path1.lineTo(10, 10);
                                                        
                                                        GeneralPath path2 = new GeneralPath();
                                                        path2.moveTo(0, 0);
                                                        
                                                        assertFalse(ShapeUtilities.equal(path1, path2));
                                                    }

    @Test
                                                    public void testEqualSamePaths() throws Exception {
                                                        GeneralPath path1 = new GeneralPath();
                                                        path1.moveTo(0, 0);
                                                        path1.lineTo(10, 10);
                                                        path1.quadTo(15, 15, 20, 20);
                                                        path1.closePath();
                                                        
                                                        GeneralPath path2 = new GeneralPath();
                                                        path2.moveTo(0, 0);
                                                        path2.lineTo(10, 10);
                                                        path2.quadTo(15, 15, 20, 20);
                                                        path2.closePath();
                                                        
                                                        assertTrue(ShapeUtilities.equal(path1, path2));
                                                    }

    @Test
                                                    public void testEqualWithMockedIterators() throws Exception {
                                                        GeneralPath path1 = mock(GeneralPath.class);
                                                        GeneralPath path2 = mock(GeneralPath.class);
                                                        
                                                        PathIterator iterator1 = mock(PathIterator.class);
                                                        PathIterator iterator2 = mock(PathIterator.class);
                                                        
                                                        when(path1.getWindingRule()).thenReturn(GeneralPath.WIND_NON_ZERO);
                                                        when(path2.getWindingRule()).thenReturn(GeneralPath.WIND_NON_ZERO);
                                                        
                                                        when(path1.getPathIterator(null)).thenReturn(iterator1);
                                                        when(path2.getPathIterator(null)).thenReturn(iterator2);
                                                        
                                                        when(iterator1.isDone()).thenReturn(false, true);
                                                        when(iterator2.isDone()).thenReturn(false, true);
                                                        
                                                        double[] coords1 = new double[]{0, 0, 10, 10};
                                                        double[] coords2 = new double[]{0, 0, 10, 10};
                                                        
                                                        when(iterator1.currentSegment(any(double[].class)))
                                                               .thenAnswer(invocation -> {
                                                                   double[] arr = invocation.getArgument(0);
                                                                   System.arraycopy(coords1, 0, arr, 0, coords1.length);
                                                                   return PathIterator.SEG_LINETO;
                                                               });
                                                        
                                                        when(iterator2.currentSegment(any(double[].class)))
                                                               .thenAnswer(invocation -> {
                                                                   double[] arr = invocation.getArgument(0);
                                                                   System.arraycopy(coords2, 0, arr, 0, coords2.length);
                                                                   return PathIterator.SEG_LINETO;
                                                               });
                                                        
                                                        assertTrue(ShapeUtilities.equal(path1, path2));
                                                    }

    @Test
                                                public void testEqualBothNull() {
                                                    Line2D l1 = null;
                                                    Line2D l2 = null;
                                                    assertTrue(ShapeUtilities.equal(l1, l2));
                                                }

    @Test
                                                public void testEqualEllipse2D_BothNull() {
                                                    Ellipse2D e1 = null;
                                                    Ellipse2D e2 = null;
                                                    assertTrue(org.jfree.chart.util.ShapeUtilities.equal(e1, e2));
                                                }

    @Test
                                                public void testEqualArc2D_BothNull() {
                                                    Arc2D a1 = null;
                                                    Arc2D a2 = null;
                                                    assertTrue(ShapeUtilities.equal(a1, a2));
                                                }

    @Test
                                                public void testEqualBothNull1() {
                                                    Polygon p1 = null;
                                                    Polygon p2 = null;
                                                    assertTrue(ShapeUtilities.equal(p1, p2));
                                                }

    @Test
            public void testEqual_NullShapes() {
            }

    @Test
        public void testEqualBothNull2() {
            java.awt.Shape p1 = null;
            java.awt.Shape p2 = null;
            assertTrue(org.jfree.chart.util.ShapeUtilities.equal(p1, p2));
        }


}
