package gentest.org.jfree.chart.renderer.category.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.renderer.category.*;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import javax.swing.Icon;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.util.PaintUtilities;
import org.jfree.chart.util.SerialUtilities;
import org.jfree.data.category.CategoryDataset;
 
public class MinMaxCategoryRendererTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testEqualsSameObject() {
            MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
            assertTrue(renderer.equals(renderer));
        }

    @Test
        public void testEqualsNull() {
            MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
            assertFalse(renderer.equals(null));
        }

    @Test
        public void testEqualsDifferentClass() {
            MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
            assertFalse(renderer.equals(new Object()));
        }

    @Test
        public void testEqualsDifferentPlotLines() {
            MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
            MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
            renderer1.setDrawLines(true);
            assertFalse(renderer1.equals(renderer2));
        }

    @Test
        public void testEqualsDifferentGroupPaint() {
            MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
            MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
            renderer1.setGroupPaint(Color.RED);
            assertFalse(renderer1.equals(renderer2));
        }

    @Test
        public void testEqualsDifferentGroupStroke() {
            MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
            MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
            renderer1.setGroupStroke(new BasicStroke(2.0f));
            assertFalse(renderer1.equals(renderer2));
        }

    @Test
        public void testEqualsSuperClassNotEqual() {
            MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
            MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
            renderer1.setBaseItemLabelGenerator(null);
            assertFalse(renderer1.equals(renderer2));
        }

    @Test
        public void testEqualsAllPropertiesEqual() {
            MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
            MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
            
            // Set all properties to be the same
            renderer1.setDrawLines(true);
            renderer2.setDrawLines(true);
            renderer1.setGroupPaint(Color.BLUE);
            renderer2.setGroupPaint(Color.BLUE);
            Stroke stroke = new BasicStroke(1.5f);
            renderer1.setGroupStroke(stroke);
            renderer2.setGroupStroke(stroke);
            
            assertTrue(renderer1.equals(renderer2));
        }

    @Test
        public void testEqualsWithPaintUtilitiesEqual() {
            MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
            MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
            
            // Different but equal paints
            Paint paint1 = new Color(10, 20, 30);
            Paint paint2 = new Color(10, 20, 30);
            renderer1.setGroupPaint(paint1);
            renderer2.setGroupPaint(paint2);
            
            assertTrue(PaintUtilities.equal(renderer1.getGroupPaint(), renderer2.getGroupPaint()));
            assertTrue(renderer1.equals(renderer2));
        }

}
