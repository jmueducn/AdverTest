package gentest.org.jfree.chart.renderer.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.renderer.*;
import java.awt.Color;
import java.awt.Paint;
import java.io.Serializable;
import org.jfree.chart.util.PublicCloneable;
 
public class GrayPaintScaleTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testGetPaintValueBelowLowerBound() {
            GrayPaintScale scale = new GrayPaintScale(10.0, 20.0);
            Paint result = scale.getPaint(5.0);
            Color expected = new Color(0, 0, 0); // Should be clamped to lower bound
            assertEquals(expected, result);
        }

    @Test
        public void testGetPaintValueAboveUpperBound() {
            GrayPaintScale scale = new GrayPaintScale(10.0, 20.0);
            Paint result = scale.getPaint(25.0);
            Color expected = new Color(255, 255, 255); // Should be clamped to upper bound
            assertEquals(expected, result);
        }

    @Test
        public void testGetPaintValueAtLowerBound() {
            GrayPaintScale scale = new GrayPaintScale(10.0, 20.0);
            Paint result = scale.getPaint(10.0);
            Color expected = new Color(0, 0, 0);
            assertEquals(expected, result);
        }

    @Test
        public void testGetPaintValueAtUpperBound() {
            GrayPaintScale scale = new GrayPaintScale(10.0, 20.0);
            Paint result = scale.getPaint(20.0);
            Color expected = new Color(255, 255, 255);
            assertEquals(expected, result);
        }

    @Test
        public void testGetPaintValueMidRange() {
            GrayPaintScale scale = new GrayPaintScale(0.0, 100.0);
            Paint result = scale.getPaint(50.0);
            Color expected = new Color(127, 127, 127); // 50/100 * 255 ≈ 127.5
            assertEquals(expected, result);
        }

    @Test
        public void testGetPaintPrecisionCheck() {
            GrayPaintScale scale = new GrayPaintScale(0.0, 1.0);
            Paint result = scale.getPaint(0.5);
            Color expected = new Color(127, 127, 127); // 0.5 * 255 ≈ 127.5
            assertEquals(expected, result);
        }

    @Test
        public void testGetPaintWithDefaultConstructor() {
            GrayPaintScale scale = new GrayPaintScale();
            Paint result = scale.getPaint(0.5);
            Color expected = new Color(127, 127, 127); // Default bounds are 0.0-1.0
            assertEquals(expected, result);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testConstructorWithInvalidBounds() {
            new GrayPaintScale(20.0, 10.0);
        }

    @Test
        public void testGetLowerBound() {
            GrayPaintScale scale = new GrayPaintScale(5.0, 15.0);
            assertEquals(5.0, scale.getLowerBound(), 0.0001);
        }

    @Test
        public void testGetUpperBound() {
            GrayPaintScale scale = new GrayPaintScale(5.0, 15.0);
            assertEquals(15.0, scale.getUpperBound(), 0.0001);
        }

    @Test
        public void testEquals() {
            GrayPaintScale scale1 = new GrayPaintScale(10.0, 20.0);
            GrayPaintScale scale2 = new GrayPaintScale(10.0, 20.0);
            assertTrue(scale1.equals(scale2));
        }

    @Test
        public void testNotEquals() {
            GrayPaintScale scale1 = new GrayPaintScale(10.0, 20.0);
            GrayPaintScale scale2 = new GrayPaintScale(15.0, 25.0);
            assertFalse(scale1.equals(scale2));
        }

    @Test
        public void testEqualsSameObject() {
            GrayPaintScale scale = new GrayPaintScale(10.0, 20.0);
            assertTrue(scale.equals(scale));
        }

    @Test
        public void testEqualsNull() {
            GrayPaintScale scale = new GrayPaintScale(10.0, 20.0);
            assertFalse(scale.equals(null));
        }

    @Test
        public void testEqualsDifferentClass() {
            GrayPaintScale scale = new GrayPaintScale(10.0, 20.0);
            assertFalse(scale.equals("Not a GrayPaintScale"));
        }

    @Test
        public void testClone() throws CloneNotSupportedException {
            GrayPaintScale scale = new GrayPaintScale(10.0, 20.0);
            GrayPaintScale clone = (GrayPaintScale) scale.clone();
            assertNotSame(scale, clone);
            assertEquals(scale.getLowerBound(), clone.getLowerBound(), 0.0001);
            assertEquals(scale.getUpperBound(), clone.getUpperBound(), 0.0001);
        }

}
