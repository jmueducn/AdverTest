package gentest.org.jfree.data.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.*;
import java.io.Serializable;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
 
public class KeyedObjects2DTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                public void testGetObjectWhenRowDataIsNull() {
                                                    KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                    ArrayList<KeyedObjects> rows = new ArrayList<>();
                                                    ArrayList<String> rowKeys = new ArrayList<>();
                                                    ArrayList<String> columnKeys = new ArrayList<>();
                                                    
                                                    // Use reflection to set private fields
                                                    try {
                                                        java.lang.reflect.Field rowsField = KeyedObjects2D.class.getDeclaredField("rows");
                                                        rowsField.setAccessible(true);
                                                        rowsField.set(keyedObjects2D, rows);
                                                        
                                                        java.lang.reflect.Field rowKeysField = KeyedObjects2D.class.getDeclaredField("rowKeys");
                                                        rowKeysField.setAccessible(true);
                                                        rowKeysField.set(keyedObjects2D, rowKeys);
                                                        
                                                        java.lang.reflect.Field columnKeysField = KeyedObjects2D.class.getDeclaredField("columnKeys");
                                                        columnKeysField.setAccessible(true);
                                                        columnKeysField.set(keyedObjects2D, columnKeys);
                                                    } catch (Exception e) {
                                                        fail("Failed to set private fields via reflection");
                                                    }
                                                    
                                                    rows.add(null); // Add null row data
                                                    rowKeys.add("Row1");
                                                    columnKeys.add("Column1");
                                                    
                                                    Object result = keyedObjects2D.getObject(0, 0);
                                                    assertNull(result);
                                                }

    @Test
                                                public void testGetObjectWhenColumnKeyIsNull() {
                                                    KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                    ArrayList<KeyedObjects> rows = new ArrayList<>();
                                                    ArrayList<String> rowKeys = new ArrayList<>();
                                                    ArrayList<String> columnKeys = new ArrayList<>();
                                                    
                                                    KeyedObjects mockRowData = mock(KeyedObjects.class);
                                                    rows.add(mockRowData);
                                                    rowKeys.add("Row1");
                                                    columnKeys.add(null); // Add null column key
                                                    
                                                    // Use reflection to set private fields
                                                    try {
                                                        java.lang.reflect.Field rowsField = KeyedObjects2D.class.getDeclaredField("rows");
                                                        rowsField.setAccessible(true);
                                                        rowsField.set(keyedObjects2D, rows);
                                                        
                                                        java.lang.reflect.Field rowKeysField = KeyedObjects2D.class.getDeclaredField("rowKeys");
                                                        rowKeysField.setAccessible(true);
                                                        rowKeysField.set(keyedObjects2D, rowKeys);
                                                        
                                                        java.lang.reflect.Field columnKeysField = KeyedObjects2D.class.getDeclaredField("columnKeys");
                                                        columnKeysField.setAccessible(true);
                                                        columnKeysField.set(keyedObjects2D, columnKeys);
                                                    } catch (Exception e) {
                                                        fail("Failed to set private fields via reflection");
                                                    }
                                                    
                                                    Object result = keyedObjects2D.getObject(0, 0);
                                                    assertNull(result);
                                                }

    @Test
                                                public void testGetObjectWhenIndexIsNegative() {
                                                    KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                    List<KeyedObjects> rows = new ArrayList<>();
                                                    List<Comparable> rowKeys = new ArrayList<>();
                                                    List<Comparable> columnKeys = new ArrayList<>();
                                                    
                                                    try {
                                                        java.lang.reflect.Field rowsField = KeyedObjects2D.class.getDeclaredField("rows");
                                                        rowsField.setAccessible(true);
                                                        rowsField.set(keyedObjects2D, rows);
                                                        
                                                        java.lang.reflect.Field rowKeysField = KeyedObjects2D.class.getDeclaredField("rowKeys");
                                                        rowKeysField.setAccessible(true);
                                                        rowKeysField.set(keyedObjects2D, rowKeys);
                                                        
                                                        java.lang.reflect.Field columnKeysField = KeyedObjects2D.class.getDeclaredField("columnKeys");
                                                        columnKeysField.setAccessible(true);
                                                        columnKeysField.set(keyedObjects2D, columnKeys);
                                                    } catch (Exception e) {
                                                        fail("Failed to set private fields via reflection");
                                                    }
                                                    
                                                    KeyedObjects mockRowData = mock(KeyedObjects.class);
                                                    rows.add(mockRowData);
                                                    rowKeys.add("Row1");
                                                    columnKeys.add("Column1");
                                            
                                                    when(mockRowData.getIndex("Column1")).thenReturn(-1);
                                                    Object result = keyedObjects2D.getObject(0, 0);
                                                    assertNull(result);
                                                }

    @Test
                                                public void testGetObjectWhenObjectExists() {
                                                    // Create test data
                                                    List<KeyedObjects> rows = new ArrayList<>();
                                                    List<String> rowKeys = new ArrayList<>();
                                                    List<String> columnKeys = new ArrayList<>();
                                                    
                                                    // Create mocks and test objects
                                                    KeyedObjects mockRowData = mock(KeyedObjects.class);
                                                    rows.add(mockRowData);
                                                    rowKeys.add("Row1");
                                                    columnKeys.add("Column1");
                                                    Object expectedObject = new Object();
                                            
                                                    // Create instance under test using reflection to set private fields
                                                    KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                    try {
                                                        java.lang.reflect.Field rowsField = KeyedObjects2D.class.getDeclaredField("rows");
                                                        rowsField.setAccessible(true);
                                                        rowsField.set(keyedObjects2D, rows);
                                                        
                                                        java.lang.reflect.Field rowKeysField = KeyedObjects2D.class.getDeclaredField("rowKeys");
                                                        rowKeysField.setAccessible(true);
                                                        rowKeysField.set(keyedObjects2D, rowKeys);
                                                        
                                                        java.lang.reflect.Field columnKeysField = KeyedObjects2D.class.getDeclaredField("columnKeys");
                                                        columnKeysField.setAccessible(true);
                                                        columnKeysField.set(keyedObjects2D, columnKeys);
                                                    } catch (Exception e) {
                                                        fail("Failed to set private fields via reflection");
                                                    }
                                            
                                                    // Set up mock behavior
                                                    when(mockRowData.getIndex("Column1")).thenReturn(0);
                                                    when(mockRowData.getObject("Column1")).thenReturn(expectedObject);
                                            
                                                    // Test and verify
                                                    Object result = keyedObjects2D.getObject(0, 0);
                                                    assertSame(expectedObject, result);
                                                }

    @Test
                                                public void testGetObjectWhenRowIndexOutOfBounds() {
                                                    KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                    try {
                                                        keyedObjects2D.getObject(0, 0);
                                                        fail("Expected IndexOutOfBoundsException");
                                                    } catch (IndexOutOfBoundsException e) {
                                                        // Expected exception
                                                    }
                                                }

    @Test
                                                public void testGetObjectWhenColumnIndexOutOfBounds() {
                                                    KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                    ArrayList<KeyedObjects> rows = new ArrayList<>();
                                                    ArrayList<String> rowKeys = new ArrayList<>();
                                                    KeyedObjects mockRowData = mock(KeyedObjects.class);
                                                    
                                                    rows.add(mockRowData);
                                                    rowKeys.add("Row1");
                                                    
                                                    try {
                                                        keyedObjects2D.getObject(0, 0);
                                                        fail("Expected IndexOutOfBoundsException");
                                                    } catch (IndexOutOfBoundsException e) {
                                                        // Expected exception
                                                    }
                                                }

    @Test
                                                public void testGetObjectWithMultipleRowsAndColumns() {
                                                    KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                    List<KeyedObjects> rows = new ArrayList<>();
                                                    List<Comparable> rowKeys = new ArrayList<>();
                                                    List<Comparable> columnKeys = new ArrayList<>();
                                                    
                                                    // Use reflection to set private fields
                                                    try {
                                                        java.lang.reflect.Field rowsField = KeyedObjects2D.class.getDeclaredField("rows");
                                                        rowsField.setAccessible(true);
                                                        rowsField.set(keyedObjects2D, rows);
                                                        
                                                        java.lang.reflect.Field rowKeysField = KeyedObjects2D.class.getDeclaredField("rowKeys");
                                                        rowKeysField.setAccessible(true);
                                                        rowKeysField.set(keyedObjects2D, rowKeys);
                                                        
                                                        java.lang.reflect.Field columnKeysField = KeyedObjects2D.class.getDeclaredField("columnKeys");
                                                        columnKeysField.setAccessible(true);
                                                        columnKeysField.set(keyedObjects2D, columnKeys);
                                                    } catch (Exception e) {
                                                        fail("Failed to set private fields via reflection");
                                                    }
                                            
                                                    KeyedObjects mockRowData1 = mock(KeyedObjects.class);
                                                    KeyedObjects mockRowData2 = mock(KeyedObjects.class);
                                                    rows.add(mockRowData1);
                                                    rows.add(mockRowData2);
                                                    rowKeys.add("Row1");
                                                    rowKeys.add("Row2");
                                                    columnKeys.add("Column1");
                                                    columnKeys.add("Column2");
                                            
                                                    Object expectedObject1 = new Object();
                                                    Object expectedObject2 = new Object();
                                            
                                                    when(mockRowData1.getIndex("Column1")).thenReturn(0);
                                                    when(mockRowData1.getObject("Column1")).thenReturn(expectedObject1);
                                                    when(mockRowData2.getIndex("Column2")).thenReturn(1);
                                                    when(mockRowData2.getObject("Column2")).thenReturn(expectedObject2);
                                            
                                                    assertSame(expectedObject1, keyedObjects2D.getObject(0, 0));
                                                    assertSame(expectedObject2, keyedObjects2D.getObject(1, 1));
                                                }

    @Test
                                                public void testGetObjectReturnsNullForMissingValue() {
                                                    KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                    keyedObjects2D.addObject(new Object(), "Row1", "Column1");
                                                    assertNull(keyedObjects2D.getObject("Row1", "Column2"));
                                                }

    @Test(expected = IllegalArgumentException.class)
                                                public void testGetObjectWithNullRowKey() {
                                                    KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                    Comparable<String> columnKey = "Column1";
                                                    keyedObjects2D.getObject(null, columnKey);
                                                }

    @Test(expected = IllegalArgumentException.class)
                                                public void testGetObjectWithNullColumnKey() {
                                                    KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                    Comparable<String> rowKey = "TestRow";
                                                    keyedObjects2D.getObject(rowKey, null);
                                                }

    @Test(expected = UnknownKeyException.class)
                                                public void testGetObjectWithUnknownRowKey() {
                                                    KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                    String columnKey = "Column1";
                                                    keyedObjects2D.getObject("UnknownRow", columnKey);
                                                }

    @Test(expected = UnknownKeyException.class)
                                                public void testGetObjectWithUnknownColumnKey() {
                                                    KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                    keyedObjects2D.addObject("Value", "Row1", "Column1");
                                                    String rowKey = "Row1";
                                                    keyedObjects2D.getObject(rowKey, "UnknownColumn");
                                                }

    @Test
                                                public void testGetObjectReturnsNullWhenIndexNotFound() {
                                                    // Create test objects
                                                    KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                    KeyedObjects rowData = mock(KeyedObjects.class);
                                                    Comparable<String> rowKey = "row1";
                                                    Comparable<String> columnKey = "col1";
                                            
                                                    // Setup a mock scenario where index is not found
                                                    when(rowData.getIndex(any(Comparable.class))).thenReturn(-1);
                                                    
                                                    // Use reflection to inject mock rowData
                                                    try {
                                                        java.lang.reflect.Field rowsField = KeyedObjects2D.class.getDeclaredField("rows");
                                                        rowsField.setAccessible(true);
                                                        List<KeyedObjects> rows = new ArrayList<>();
                                                        rows.add(rowData);
                                                        rowsField.set(keyedObjects2D, rows);
                                                        
                                                        java.lang.reflect.Field rowKeysField = KeyedObjects2D.class.getDeclaredField("rowKeys");
                                                        rowKeysField.setAccessible(true);
                                                        List<Comparable> rowKeys = new ArrayList<>();
                                                        rowKeys.add(rowKey);
                                                        rowKeysField.set(keyedObjects2D, rowKeys);
                                                        
                                                        java.lang.reflect.Field columnKeysField = KeyedObjects2D.class.getDeclaredField("columnKeys");
                                                        columnKeysField.setAccessible(true);
                                                        List<Comparable> columnKeys = new ArrayList<>();
                                                        columnKeys.add(columnKey);
                                                        columnKeysField.set(keyedObjects2D, columnKeys);
                                                    } catch (Exception e) {
                                                        fail("Reflection failed: " + e.getMessage());
                                                    }
                                                    
                                                    Object result = keyedObjects2D.getObject(rowKey, columnKey);
                                                    assertNull(result);
                                                }

    @Test
                                                public void testGetObjectReturnsObjectWhenIndexFound() {
                                                    // Create test objects and mocks
                                                    KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                    KeyedObjects rowData = mock(KeyedObjects.class);
                                                    Comparable<String> rowKey = "row1";
                                                    Comparable<String> columnKey = "col1";
                                                    Object testObject = new Object();
                                            
                                                    // Setup mock scenario where index is found
                                                    when(rowData.getIndex(any(Comparable.class))).thenReturn(0);
                                                    when(rowData.getObject(anyInt())).thenReturn(testObject);
                                            
                                                    // Use reflection to inject mock rowData
                                                    try {
                                                        java.lang.reflect.Field rowsField = KeyedObjects2D.class.getDeclaredField("rows");
                                                        rowsField.setAccessible(true);
                                                        List<KeyedObjects> rows = new ArrayList<>();
                                                        rows.add(rowData);
                                                        rowsField.set(keyedObjects2D, rows);
                                                        
                                                        java.lang.reflect.Field rowKeysField = KeyedObjects2D.class.getDeclaredField("rowKeys");
                                                        rowKeysField.setAccessible(true);
                                                        List<Comparable> rowKeys = new ArrayList<>();
                                                        rowKeys.add(rowKey);
                                                        rowKeysField.set(keyedObjects2D, rowKeys);
                                                        
                                                        java.lang.reflect.Field columnKeysField = KeyedObjects2D.class.getDeclaredField("columnKeys");
                                                        columnKeysField.setAccessible(true);
                                                        List<Comparable> columnKeys = new ArrayList<>();
                                                        columnKeys.add(columnKey);
                                                        columnKeysField.set(keyedObjects2D, columnKeys);
                                                    } catch (Exception e) {
                                                        fail("Reflection failed: " + e.getMessage());
                                                    }
                                                    
                                                    Object result = keyedObjects2D.getObject(rowKey, columnKey);
                                                    assertEquals(testObject, result);
                                                }

    @Test
                                                public void testRemoveObjectRemovesValue() {
                                                    KeyedObjects2D data = new KeyedObjects2D();
                                                    Comparable<String> rowKey1 = "Row1";
                                                    Comparable<String> rowKey2 = "Row2";
                                                    Comparable<String> columnKey1 = "Column1";
                                                    Comparable<String> columnKey2 = "Column2";
                                                    
                                                    data.setObject("Value1", rowKey1, columnKey1);
                                                    data.setObject("Value2", rowKey1, columnKey2);
                                                    data.setObject("Value3", rowKey2, columnKey1);
                                                    
                                                    data.removeObject(rowKey1, columnKey1);
                                                    assertNull(data.getObject(rowKey1, columnKey1));
                                                    assertNotNull(data.getObject(rowKey1, columnKey2));
                                                    assertNotNull(data.getObject(rowKey2, columnKey1));
                                                }

    @Test
                                                public void testRemoveObjectRemovesEmptyRow() {
                                                    KeyedObjects2D data = new KeyedObjects2D();
                                                    Comparable<String> rowKey1 = "Row1";
                                                    Comparable<String> rowKey2 = "Row2";
                                                    Comparable<String> columnKey1 = "Column1";
                                                    Comparable<String> columnKey2 = "Column2";
                                                    
                                                    // Add some data
                                                    data.addObject("Value1", rowKey1, columnKey1);
                                                    data.addObject("Value2", rowKey1, columnKey2);
                                                    data.addObject("Value3", rowKey2, columnKey1);
                                                    
                                                    // Remove objects to make row empty
                                                    data.removeObject(rowKey1, columnKey1);
                                                    data.removeObject(rowKey1, columnKey2);
                                                    
                                                    assertEquals(1, data.getRowCount());
                                                    assertEquals(rowKey2, data.getRowKey(0));
                                                }

    @Test
                                                public void testRemoveObjectRemovesEmptyColumn() {
                                                    KeyedObjects2D data = new KeyedObjects2D();
                                                    Comparable<String> rowKey1 = "Row1";
                                                    Comparable<String> rowKey2 = "Row2";
                                                    Comparable<String> columnKey1 = "Column1";
                                                    Comparable<String> columnKey2 = "Column2";
                                                    
                                                    // Add data to create the structure
                                                    data.addObject("Value1", rowKey1, columnKey1);
                                                    data.addObject("Value2", rowKey2, columnKey1);
                                                    data.addObject("Value3", rowKey1, columnKey2);
                                                    
                                                    data.removeObject(rowKey1, columnKey1);
                                                    data.removeObject(rowKey2, columnKey1);
                                                    assertEquals(1, data.getColumnCount());
                                                    assertEquals(columnKey2, data.getColumnKey(0));
                                                }

    @Test(expected = IllegalArgumentException.class)
                                            public void testGetObjectWithNullRowKey1() {
                                                KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                Comparable<String> columnKey = "Column1";
                                                keyedObjects2D.getObject(null, columnKey);
                                            }

    @Test(expected = IllegalArgumentException.class)
                                            public void testGetObjectWithNullColumnKey1() {
                                                KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                Comparable<String> rowKey = "TestRow";
                                                keyedObjects2D.getObject(rowKey, null);
                                            }

    @Test
                                            public void testGetObjectWithUnknownRowKey1() {
                                                KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                String columnKey = "Column1";
                                                keyedObjects2D.getObject("UnknownRow", columnKey);
                                            }

    @Test(expected = IllegalArgumentException.class)
                                            public void testGetObjectWithUnknownColumnKey1() {
                                                KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                keyedObjects2D.addObject("Value", "Row1", "Column1");
                                                keyedObjects2D.getObject("Row1", "UnknownColumn");
                                            }

    @Test
                                            public void testRemoveObjectDoesNotRemoveNonEmptyRow() {
                                                KeyedObjects2D data = new KeyedObjects2D();
                                                Comparable<String> rowKey1 = "Row1";
                                                Comparable<String> rowKey2 = "Row2";
                                                Comparable<String> columnKey1 = "Column1";
                                                Comparable<String> columnKey2 = "Column2";
                                                
                                                data.setObject("Value1", rowKey1, columnKey1);
                                                data.setObject("Value2", rowKey1, columnKey2);
                                                data.setObject("Value3", rowKey2, columnKey1);
                                                
                                                data.removeObject(rowKey1, columnKey1);
                                                assertEquals(2, data.getRowCount());
                                            }

    @Test
                                            public void testRemoveObjectDoesNotRemoveNonEmptyColumn() {
                                                KeyedObjects2D data = new KeyedObjects2D();
                                                Comparable<String> rowKey1 = "Row1";
                                                Comparable<String> columnKey1 = "Column1";
                                                Comparable<String> columnKey2 = "Column2";
                                                
                                                // Add data to create a non-empty column
                                                data.setObject("Value1", rowKey1, columnKey1);
                                                data.setObject("Value2", rowKey1, columnKey2);
                                                
                                                data.removeObject(rowKey1, columnKey1);
                                                assertEquals(2, data.getColumnCount());
                                            }

    @Test(expected = IllegalArgumentException.class)
                                            public void testRemoveObjectWithNullRowKey() {
                                                KeyedObjects2D data = new KeyedObjects2D();
                                                Comparable<String> columnKey1 = "Column1";
                                                data.removeObject(null, columnKey1);
                                            }

    @Test(expected = IllegalArgumentException.class)
                                            public void testRemoveObjectWithNullColumnKey() {
                                                KeyedObjects2D data = new KeyedObjects2D();
                                                Comparable<String> rowKey1 = "Row1";
                                                data.addObject("Value", rowKey1, "Column1");
                                                data.removeObject(rowKey1, null);
                                            }

    @Test
                                            public void testRemoveObjectWithInvalidRowKey() {
                                                KeyedObjects2D data = new KeyedObjects2D();
                                                String columnKey1 = "Column1";
                                                data.removeObject("InvalidRow", columnKey1);
                                            }

    @Test(expected = IllegalArgumentException.class)
                                            public void testRemoveObjectWithInvalidColumnKey() {
                                                KeyedObjects2D data = new KeyedObjects2D();
                                                Comparable<String> rowKey1 = "Row1";
                                                data.addObject("Value1", rowKey1, "Column1");
                                                data.removeObject(rowKey1, "InvalidColumn");
                                            }

    @Test
                                            public void testRemoveObjectFromEmptyTable() {
                                                KeyedObjects2D emptyData = new KeyedObjects2D();
                                                String rowKey1 = "Row1";
                                                String columnKey1 = "Column1";
                                                try {
                                                    emptyData.removeObject(rowKey1, columnKey1);
                                                    fail("Expected UnknownKeyException");
                                                } catch (Exception e) {
                                                    // expected
                                                }
                                            }

    @Test
                                            public void testRemoveObjectMaintainsOtherRowsAndColumns() {
                                                KeyedObjects2D data = new KeyedObjects2D();
                                                
                                                // Define test data
                                                Comparable<String> rowKey1 = "Row1";
                                                Comparable<String> rowKey2 = "Row2";
                                                Comparable<String> columnKey1 = "Column1";
                                                Comparable<String> columnKey2 = "Column2";
                                                
                                                // Add test data
                                                data.setObject("Value1", rowKey1, columnKey1);
                                                data.setObject("Value2", rowKey1, columnKey2);
                                                data.setObject("Value3", rowKey2, columnKey1);
                                                data.setObject("Value4", rowKey2, columnKey2);
                                                
                                                // Test the method
                                                data.removeObject(rowKey1, columnKey1);
                                                
                                                // Verify results
                                                assertEquals(2, data.getRowCount());
                                                assertEquals(2, data.getColumnCount());
                                                assertNotNull(data.getObject(rowKey1, columnKey2));
                                                assertNotNull(data.getObject(rowKey2, columnKey1));
                                            }

    @Test
                                            public void testRemoveObjectFromMultipleRows() {
                                                KeyedObjects2D data = new KeyedObjects2D();
                                                Comparable<String> rowKey1 = "Row1";
                                                Comparable<String> rowKey2 = "Row2";
                                                Comparable<String> columnKey1 = "Column1";
                                                Comparable<String> columnKey2 = "Column2";
                                                Object object1 = new Object();
                                                Object object2 = new Object();
                                        
                                                data.addObject(object1, rowKey1, columnKey1);
                                                data.addObject(object1, rowKey1, columnKey2);
                                                data.addObject(object2, rowKey2, columnKey2);
                                                data.removeObject(rowKey1, columnKey1);
                                                data.removeObject(rowKey2, columnKey1);
                                                assertEquals(2, data.getRowCount());
                                                assertEquals(1, data.getColumnCount());
                                                assertEquals(columnKey2, data.getColumnKey(0));
                                            }

    @Test
                                            public void testRemoveRowWithValidIndex() {
                                                // Create new instance
                                                KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                
                                                // Add some data
                                                keyedObjects2D.addObject("Value1", "Row1", "Column1");
                                                keyedObjects2D.addObject("Value2", "Row2", "Column1");
                                                
                                                // Verify initial state
                                                assertEquals(2, keyedObjects2D.getRowCount());
                                                assertEquals("Row1", keyedObjects2D.getRowKey(0));
                                                assertEquals("Row2", keyedObjects2D.getRowKey(1));
                                                
                                                // Remove first row
                                                keyedObjects2D.removeRow(0);
                                                
                                                // Verify after removal
                                                assertEquals(1, keyedObjects2D.getRowCount());
                                                assertEquals("Row2", keyedObjects2D.getRowKey(0));
                                            }

    @Test
                                            public void testRemoveRowWithLastIndex() {
                                                KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                
                                                // Add some data
                                                keyedObjects2D.addObject("Value1", "Row1", "Column1");
                                                keyedObjects2D.addObject("Value2", "Row2", "Column1");
                                                
                                                // Remove last row
                                                keyedObjects2D.removeRow(1);
                                                
                                                // Verify after removal
                                                assertEquals(1, keyedObjects2D.getRowCount());
                                                assertEquals("Row1", keyedObjects2D.getRowKey(0));
                                            }

    @Test
                                            public void testRemoveRowFromSingleRowTable() {
                                                // Create new instance
                                                KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                
                                                // Add single row
                                                keyedObjects2D.addObject("Value1", "Row1", "Column1");
                                                
                                                // Remove the row
                                                keyedObjects2D.removeRow(0);
                                                
                                                // Verify table is empty
                                                assertEquals(0, keyedObjects2D.getRowCount());
                                            }

    @Test(expected = IndexOutOfBoundsException.class)
                                            public void testRemoveRowWithNegativeIndex() {
                                                KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                List<Comparable<?>> rowKeys = new ArrayList<>();
                                                List<List<Object>> rows = new ArrayList<>();
                                                
                                                // Use reflection to set private fields if needed
                                                try {
                                                    java.lang.reflect.Field rowKeysField = KeyedObjects2D.class.getDeclaredField("rowKeys");
                                                    rowKeysField.setAccessible(true);
                                                    rowKeysField.set(keyedObjects2D, rowKeys);
                                                    
                                                    java.lang.reflect.Field rowsField = KeyedObjects2D.class.getDeclaredField("rows");
                                                    rowsField.setAccessible(true);
                                                    rowsField.set(keyedObjects2D, rows);
                                                } catch (Exception e) {
                                                    throw new RuntimeException(e);
                                                }
                                                
                                                keyedObjects2D.removeRow(-1);
                                            }

    @Test(expected = IndexOutOfBoundsException.class)
                                            public void testRemoveRowWithIndexEqualToRowCount() {
                                                KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                keyedObjects2D.addObject("Value1", "Row1", "Column1");
                                                keyedObjects2D.removeRow(1); // Only 1 row exists (index 0)
                                            }

    @Test
                                            public void testRemoveRowFromEmptyTable() {
                                                KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                keyedObjects2D.removeRow(0);
                                            }

    @Test
                                            public void testRemoveRowMaintainsColumnStructure() {
                                                KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                
                                                // Add data with multiple columns
                                                keyedObjects2D.addObject("Value1", "Row1", "Column1");
                                                keyedObjects2D.addObject("Value2", "Row1", "Column2");
                                                keyedObjects2D.addObject("Value3", "Row2", "Column1");
                                                keyedObjects2D.addObject("Value4", "Row2", "Column2");
                                                
                                                // Verify initial column count
                                                assertEquals(2, keyedObjects2D.getColumnCount());
                                                
                                                // Remove a row
                                                keyedObjects2D.removeRow(0);
                                                
                                                // Verify column count remains the same
                                                assertEquals(2, keyedObjects2D.getColumnCount());
                                            }

    @Test
                                            public void testRemoveRowUpdatesInternalLists() throws Exception {
                                                // Create test instance
                                                KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                
                                                // Add data
                                                keyedObjects2D.addObject("Value1", "Row1", "Column1");
                                                keyedObjects2D.addObject("Value2", "Row2", "Column1");
                                                
                                                // Get internal lists via reflection
                                                java.lang.reflect.Field rowKeysField = KeyedObjects2D.class.getDeclaredField("rowKeys");
                                                rowKeysField.setAccessible(true);
                                                List<?> rowKeys = (List<?>) rowKeysField.get(keyedObjects2D);
                                                
                                                java.lang.reflect.Field rowsField = KeyedObjects2D.class.getDeclaredField("rows");
                                                rowsField.setAccessible(true);
                                                List<?> rows = (List<?>) rowsField.get(keyedObjects2D);
                                                
                                                // Verify initial sizes
                                                assertEquals(2, rowKeys.size());
                                                assertEquals(2, rows.size());
                                                
                                                // Remove a row
                                                keyedObjects2D.removeRow(0);
                                                
                                                // Verify updated sizes
                                                assertEquals(1, rowKeys.size());
                                                assertEquals(1, rows.size());
                                            }

    @Test
                                            public void testRemoveRowWithExistingKey() {
                                                // Setup
                                                KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                Comparable rowKey = "Row1";
                                                Comparable columnKey = "Column1";
                                                keyedObjects2D.addObject("Value1", rowKey, columnKey);
                                                int initialRowCount = keyedObjects2D.getRowCount();
                                                int initialColumnCount = keyedObjects2D.getColumnCount();
                                                
                                                // Execute
                                                keyedObjects2D.removeRow(rowKey);
                                                
                                                // Verify
                                                assertEquals(initialRowCount - 1, keyedObjects2D.getRowCount());
                                                assertEquals(initialColumnCount, keyedObjects2D.getColumnCount());
                                                assertFalse(keyedObjects2D.getRowKeys().contains(rowKey));
                                            }

    @Test(expected = UnknownKeyException.class)
                                            public void testRemoveRowWithNonExistingKey() {
                                                // Setup
                                                KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                Comparable<String> nonExistingKey = "NonExistingKey";
                                                
                                                // Execute & Verify
                                                keyedObjects2D.removeRow(nonExistingKey);
                                            }

    @Test(expected = UnknownKeyException.class)
                                            public void testRemoveRowWithNullKey() {
                                                // Setup
                                                KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                
                                                // Execute & Verify
                                                keyedObjects2D.removeRow(null);
                                            }

    @Test
                                            public void testRemoveRowWithMultipleRows() {
                                                // Setup
                                                KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                Comparable rowKey1 = "Row1";
                                                Comparable rowKey2 = "Row2";
                                                Comparable columnKey = "Column1";
                                                keyedObjects2D.addObject("Value1", rowKey1, columnKey);
                                                keyedObjects2D.addObject("Value2", rowKey2, columnKey);
                                                int initialRowCount = keyedObjects2D.getRowCount();
                                                
                                                // Execute
                                                keyedObjects2D.removeRow(rowKey1);
                                                
                                                // Verify
                                                assertEquals(initialRowCount - 1, keyedObjects2D.getRowCount());
                                                assertFalse(keyedObjects2D.getRowKeys().contains(rowKey1));
                                                assertTrue(keyedObjects2D.getRowKeys().contains(rowKey2));
                                            }

    @Test
                                            public void testRemoveRowWithEmptyTable() {
                                                // Setup - empty table
                                                KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                Comparable rowKey = "Row1";
                                        
                                                // Execute & Verify
                                                try {
                                                    keyedObjects2D.removeRow(rowKey);
                                                    fail("Expected UnknownKeyException");
                                                } catch (UnknownKeyException e) {
                                                    assertEquals("Row key (" + rowKey + ") not recognised.", e.getMessage());
                                                }
                                            }

    @Test(expected = UnknownKeyException.class)
                                            public void testRemoveRowWithUnknownKey() {
                                                KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                keyedObjects2D.removeRow("UnknownKey");
                                            }

    @Test
                                        public void testRemoveColumnWithValidIndex() {
                                            // Setup
                                            KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                            keyedObjects2D.addObject("Value1", "Row1", "Column1");
                                            keyedObjects2D.addObject("Value2", "Row2", "Column2");
                                            int initialColumnCount = keyedObjects2D.getColumnCount();
                                            
                                            // Execute
                                            keyedObjects2D.removeColumn(0);
                                            
                                            // Verify
                                            assertEquals(initialColumnCount - 1, keyedObjects2D.getColumnCount());
                                            assertEquals(1, keyedObjects2D.getRowCount());
                                        }

    @Test(expected = IndexOutOfBoundsException.class)
                                        public void testRemoveColumnWithNegativeIndex() {
                                            KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                            keyedObjects2D.removeColumn(-1);
                                        }

    @Test(expected = IndexOutOfBoundsException.class)
                                        public void testRemoveColumnWithIndexOutOfBounds() {
                                            KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                            keyedObjects2D.addObject("Value1", "Row1", "Column1");
                                            keyedObjects2D.removeColumn(1); // Only 1 column exists (index 0)
                                        }

    @Test
                                        public void testRemoveColumnCallsRemoveColumnWithKey() {
                                            // Setup
                                            KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                            keyedObjects2D.addObject("Value1", "Row1", "Column1");
                                            Comparable expectedKey = keyedObjects2D.getColumnKey(0);
                                            
                                            // Create spy to verify method call
                                            KeyedObjects2D spy = spy(keyedObjects2D);
                                            
                                            // Execute
                                            spy.removeColumn(0);
                                            
                                            // Verify
                                            verify(spy).removeColumn(expectedKey);
                                        }

    @Test
                                        public void testRemoveColumnWithEmptyTable() {
                                            // Setup
                                            KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                            int initialColumnCount = keyedObjects2D.getColumnCount();
                                            assertEquals(0, initialColumnCount);
                                    
                                            // Execute and verify exception
                                            try {
                                                keyedObjects2D.removeColumn(0);
                                                fail("Expected IndexOutOfBoundsException");
                                            } catch (IndexOutOfBoundsException e) {
                                                // Expected
                                            }
                                        }

    @Test
                                        public void testRemoveColumnUpdatesRowData() {
                                            // Setup
                                            KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                            keyedObjects2D.addObject("Value1", "Row1", "Column1");
                                            keyedObjects2D.addObject("Value2", "Row1", "Column2");
                                            keyedObjects2D.addObject("Value3", "Row2", "Column1");
                                        
                                            // Execute
                                            keyedObjects2D.removeColumn(0); // Remove "Column1"
                                        
                                            // Verify
                                            assertEquals(1, keyedObjects2D.getColumnCount());
                                            assertEquals("Column2", keyedObjects2D.getColumnKey(0));
                                            assertEquals(2, keyedObjects2D.getRowCount());
                                        }

    @Test
                                        public void testRemoveColumnWithMultipleRows() {
                                            // Setup
                                            KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                            keyedObjects2D.addObject("Value1", "Row1", "Column1");
                                            keyedObjects2D.addObject("Value2", "Row2", "Column1");
                                            keyedObjects2D.addObject("Value3", "Row3", "Column1");
                                            int initialRowCount = keyedObjects2D.getRowCount();
                                    
                                            // Execute
                                            keyedObjects2D.removeColumn(0);
                                    
                                            // Verify
                                            assertEquals(0, keyedObjects2D.getColumnCount());
                                            assertEquals(initialRowCount, keyedObjects2D.getRowCount());
                                        }

    @Test
                                        public void testRemoveColumnWithNullValues() {
                                            // Setup
                                            KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                            keyedObjects2D.addObject(null, "Row1", "Column1");
                                            keyedObjects2D.addObject(null, "Row2", "Column1");
                                            keyedObjects2D.addObject("Value", "Row3", "Column2");
                                        
                                            // Execute
                                            keyedObjects2D.removeColumn(0);
                                        
                                            // Verify
                                            assertEquals(1, keyedObjects2D.getColumnCount());
                                            assertEquals("Column2", keyedObjects2D.getColumnKey(0));
                                            assertEquals(3, keyedObjects2D.getRowCount());
                                        }

    @Test
                                        public void testRemoveColumnValidKey() {
                                            // Setup test data
                                            KeyedObjects2D data = new KeyedObjects2D();
                                            Comparable<String> rowKey1 = "Row1";
                                            Comparable<String> rowKey2 = "Row2";
                                            Comparable<String> columnKey1 = "Column1";
                                            Comparable<String> columnKey2 = "Column2";
                                            
                                            // Add test data
                                            data.addObject("Value1", rowKey1, columnKey1);
                                            data.addObject("Value2", rowKey2, columnKey1);
                                            data.addObject("Value3", rowKey1, columnKey2);
                                            data.addObject("Value4", rowKey2, columnKey2);
                                    
                                            // Before removal
                                            assertEquals(2, data.getColumnCount());
                                            assertNotNull(data.getObject(rowKey1, columnKey1));
                                            assertNotNull(data.getObject(rowKey2, columnKey1));
                                    
                                            // Remove column
                                            data.removeColumn(columnKey1);
                                    
                                            // After removal
                                            assertEquals(1, data.getColumnCount());
                                            assertFalse(data.getColumnKeys().contains(columnKey1));
                                            assertTrue(data.getColumnKeys().contains(columnKey2));
                                            
                                            // Verify rows still exist
                                            assertEquals(2, data.getRowCount());
                                        }

    @Test(expected = UnknownKeyException.class)
                                        public void testRemoveColumnInvalidKey() {
                                            KeyedObjects2D data = new KeyedObjects2D();
                                            data.removeColumn("InvalidColumn");
                                        }

    @Test
                                        public void testRemoveColumnUpdatesColumnKeys() {
                                            KeyedObjects2D data = new KeyedObjects2D();
                                            Comparable<String> columnKey1 = "Column1";
                                            Comparable<String> columnKey2 = "Column2";
                                            
                                            // Add some test data
                                            data.addObject("Value1", "Row1", columnKey1);
                                            data.addObject("Value2", "Row1", columnKey2);
                                            
                                            List<Comparable> originalKeys = new ArrayList<>(data.getColumnKeys());
                                            assertTrue(originalKeys.contains(columnKey1));
                                    
                                            data.removeColumn(columnKey1);
                                    
                                            List<Comparable> updatedKeys = data.getColumnKeys();
                                            assertEquals(originalKeys.size() - 1, updatedKeys.size());
                                            assertFalse(updatedKeys.contains(columnKey1));
                                        }

    @Test
        public void testRemoveColumnRemovesFromAllRows() {
            // Setup test data
            KeyedObjects2D data = new KeyedObjects2D();
            String columnKey1 = "Column1";
            String rowKey1 = "Row1";
            String rowKey2 = "Row2";
            
            // Add test data
            data.addObject("Value1", rowKey1, columnKey1);
            data.addObject("Value2", rowKey2, columnKey1);
        
            // Verify column exists in all rows before removal
            for (int i = 0; i < data.getRowCount(); i++) {
                assertTrue(data.getRowKey(i) != null);
                assertTrue(data.getColumnIndex(columnKey1) >= 0);
            }
        
            data.removeColumn(columnKey1);
        
            // Verify column removed from all rows
            for (int i = 0; i < data.getRowCount(); i++) {
                assertEquals(-1, data.getColumnIndex(columnKey1));
            }
        }


}
