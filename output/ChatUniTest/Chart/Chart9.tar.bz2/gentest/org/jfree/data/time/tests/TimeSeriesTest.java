package gentest.org.jfree.data.time.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.time.*;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.data.general.Series;
import org.jfree.data.general.SeriesChangeEvent;
import org.jfree.data.general.SeriesException;
 
public class TimeSeriesTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                            public void testCreateCopyEmptySeries() throws CloneNotSupportedException {
                                TimeSeries emptySeries = new TimeSeries("Empty Series");
                                TimeSeries copy = emptySeries.createCopy(0, 0);
                                assertEquals(0, copy.getItemCount());
                            }

    @Test
                        public void testCreateCopyValidRange() throws CloneNotSupportedException {
                            TimeSeries series = new TimeSeries("Test Series");
                            TimeSeriesDataItem item1 = new TimeSeriesDataItem(new Day(1, 1, 2023), 10.0);
                            TimeSeriesDataItem item2 = new TimeSeriesDataItem(new Day(2, 1, 2023), 20.0);
                            series.add(item1);
                            series.add(item2);
                            
                            TimeSeries copy = series.createCopy(0, 1);
                            assertEquals(2, copy.getItemCount());
                            assertEquals(item1, copy.getDataItem(0));
                            assertEquals(item2, copy.getDataItem(1));
                        }

    @Test
                        public void testCreateCopySingleItem() throws CloneNotSupportedException {
                            TimeSeries series = new TimeSeries("Test Series");
                            Day day = new Day(1, 1, 2000);
                            TimeSeriesDataItem item = new TimeSeriesDataItem(day, 100.0);
                            series.add(item);
                            
                            TimeSeries copy = series.createCopy(0, 0);
                            assertEquals(1, copy.getItemCount());
                            assertEquals(item, copy.getDataItem(0));
                        }

    @Test
                        public void testCreateCopyFullRange() throws CloneNotSupportedException {
                            TimeSeries series = new TimeSeries("Test Series");
                            Day day1 = new Day(1, 1, 2000);
                            Day day2 = new Day(2, 1, 2000);
                            Day day3 = new Day(3, 1, 2000);
                            TimeSeriesDataItem item1 = new TimeSeriesDataItem(day1, 1.0);
                            TimeSeriesDataItem item2 = new TimeSeriesDataItem(day2, 2.0);
                            TimeSeriesDataItem item3 = new TimeSeriesDataItem(day3, 3.0);
                            
                            series.add(item1);
                            series.add(item2);
                            series.add(item3);
                    
                            TimeSeries copy = series.createCopy(0, 2);
                            assertEquals(3, copy.getItemCount());
                            assertEquals(item1, copy.getDataItem(0));
                            assertEquals(item2, copy.getDataItem(1));
                            assertEquals(item3, copy.getDataItem(2));
                        }

    @Test(expected = IllegalArgumentException.class)
                        public void testCreateCopyNegativeStart() throws CloneNotSupportedException {
                            TimeSeries series = new TimeSeries("Test Series");
                            series.add(new TimeSeriesDataItem(new org.jfree.data.time.Day(), 1.0));
                            series.createCopy(-1, 1);
                        }

    @Test(expected = IllegalArgumentException.class)
                        public void testCreateCopyEndBeforeStart() throws CloneNotSupportedException {
                            TimeSeries series = new TimeSeries("Test Series");
                            series.add(new TimeSeriesDataItem(new org.jfree.data.time.Day(), 1.0));
                            series.add(new TimeSeriesDataItem(new org.jfree.data.time.Day(), 2.0));
                            series.createCopy(2, 1);
                        }

    @Test
                        public void testCreateCopyEndIndexOutOfBounds() throws CloneNotSupportedException {
                            TimeSeries series = new TimeSeries("Test Series");
                            series.add(new TimeSeriesDataItem(new org.jfree.data.time.Day(), 1.0));
                            series.add(new TimeSeriesDataItem(new org.jfree.data.time.Day(), 2.0));
                            series.add(new TimeSeriesDataItem(new org.jfree.data.time.Day(), 3.0));
                            
                            try {
                                series.createCopy(0, 5);
                                fail("Expected IndexOutOfBoundsException");
                            } catch (IndexOutOfBoundsException e) {
                                // Expected behavior
                            }
                        }

    @Test
                        public void testCreateCopyStartIndexOutOfBounds() throws CloneNotSupportedException {
                            TimeSeries series = new TimeSeries("Test Series");
                            try {
                                series.createCopy(5, 5);
                                fail("Expected IndexOutOfBoundsException");
                            } catch (IndexOutOfBoundsException e) {
                                // Expected behavior
                            }
                        }

    @Test
                        public void testCreateCopyVerifyDeepCopy() throws CloneNotSupportedException {
                            TimeSeries series = new TimeSeries("Test Series");
                            series.add(new TimeSeriesDataItem(new org.jfree.data.time.Day(1, 1, 2000), 1.0));
                            series.add(new TimeSeriesDataItem(new org.jfree.data.time.Day(2, 1, 2000), 2.0));
                            series.add(new TimeSeriesDataItem(new org.jfree.data.time.Day(3, 1, 2000), 3.0));
                    
                            TimeSeries copy = series.createCopy(0, 2);
                            assertNotSame(series, copy);
                            for (int i = 0; i < series.getItemCount(); i++) {
                                assertNotSame(series.getDataItem(i), copy.getDataItem(i));
                            }
                        }

    @Test(expected = IllegalArgumentException.class)
                        public void testCreateCopyWithNullStart() throws CloneNotSupportedException {
                            TimeSeries timeSeries = new TimeSeries("Test Series");
                            Day day2 = new Day(2, 1, 2000);
                            timeSeries.createCopy(null, day2);
                        }

    @Test(expected = IllegalArgumentException.class)
                        public void testCreateCopyWithNullEnd() throws CloneNotSupportedException {
                            TimeSeries timeSeries = new TimeSeries("Test Series");
                            Day day1 = new Day(1, 1, 2000);
                            timeSeries.createCopy(day1, null);
                        }

    @Test(expected = IllegalArgumentException.class)
                        public void testCreateCopyWithStartAfterEnd() throws CloneNotSupportedException {
                            TimeSeries timeSeries = new TimeSeries("Test Series");
                            Day day1 = new Day(1, 1, 2000);
                            Day day2 = new Day(2, 1, 2000);
                            timeSeries.createCopy(day2, day1);
                        }

    @Test
                        public void testCreateCopyWithValidRange() throws CloneNotSupportedException {
                            TimeSeries timeSeries = new TimeSeries("Test Series");
                            Day day1 = new Day(1, 1, 2023);
                            Day day2 = new Day(2, 1, 2023);
                            
                            timeSeries.add(day1, 1.0);
                            timeSeries.add(day2, 2.0);
                            
                            TimeSeries copy = timeSeries.createCopy(day1, day2);
                            assertEquals(2, copy.getItemCount());
                            assertEquals(1.0, copy.getValue(0).doubleValue(), 0.0001);
                            assertEquals(2.0, copy.getValue(1).doubleValue(), 0.0001);
                        }

    @Test
                        public void testCreateCopyWithStartNotInSeries() throws CloneNotSupportedException {
                            TimeSeries timeSeries = new TimeSeries("Test Series");
                            Day day1 = new Day(1, 1, 2023);
                            Day day2 = new Day(2, 1, 2023);
                            timeSeries.add(day1, 1.0);
                            timeSeries.add(day2, 2.0);
                            
                            Day dayBefore = new Day(31, 12, 2022);
                            TimeSeries copy = timeSeries.createCopy(dayBefore, day2);
                            assertEquals(2, copy.getItemCount());
                            assertEquals(1.0, copy.getValue(0).doubleValue(), 0.0001);
                            assertEquals(2.0, copy.getValue(1).doubleValue(), 0.0001);
                        }

    @Test
                        public void testCreateCopyWithEndNotInSeries() throws CloneNotSupportedException {
                            TimeSeries timeSeries = new TimeSeries("Test Series");
                            Day day1 = new Day(1, 1, 2023);
                            Day day2 = new Day(2, 1, 2023);
                            Day day3 = new Day(3, 1, 2023);
                            
                            timeSeries.add(day1, 1.0);
                            timeSeries.add(day2, 2.0);
                            timeSeries.add(day3, 3.0);
                            
                            Day dayAfter = new Day(4, 1, 2023);
                            TimeSeries copy = timeSeries.createCopy(day1, dayAfter);
                            
                            assertEquals(3, copy.getItemCount());
                            assertEquals(1.0, copy.getValue(0).doubleValue(), 0.0001);
                            assertEquals(2.0, copy.getValue(1).doubleValue(), 0.0001);
                            assertEquals(3.0, copy.getValue(2).doubleValue(), 0.0001);
                        }

    @Test
                        public void testCreateCopyWithEmptyRange() throws CloneNotSupportedException {
                            TimeSeries timeSeries = new TimeSeries("Test Series");
                            Day dayBeforeAll = new Day(31, 12, 2022);
                            Day dayBeforeFirst = new Day(1, 1, 2022);
                            TimeSeries copy = timeSeries.createCopy(dayBeforeAll, dayBeforeFirst);
                            assertEquals(0, copy.getItemCount());
                        }

    @Test
                        public void testCreateCopyWithEndBeforeStart() throws CloneNotSupportedException {
                            TimeSeries timeSeries = new TimeSeries("Test Series");
                            timeSeries.add(new Day(1, 1, 2023), 100.0);
                            timeSeries.add(new Day(2, 1, 2023), 200.0);
                            timeSeries.add(new Day(3, 1, 2023), 300.0);
                            
                            Day dayAfterLast = new Day(4, 1, 2023);
                            Day dayAfterAfterLast = new Day(5, 1, 2023);
                            TimeSeries copy = timeSeries.createCopy(dayAfterLast, dayAfterAfterLast);
                            assertEquals(0, copy.getItemCount());
                        }

    @Test
                        public void testCreateCopyWithInvalidTimePeriodClass() throws CloneNotSupportedException {
                            TimeSeries timeSeries = new TimeSeries("Test Series");
                            Month month1 = new Month(1, 2000);
                            Month month2 = new Month(2, 2000);
                            timeSeries.add(new TimeSeriesDataItem(month1, 100.0));
                            timeSeries.add(new TimeSeriesDataItem(month2, 200.0));
                            
                            try {
                                timeSeries.createCopy(month1, month1);
                                fail("Expected SeriesException");
                            } catch (IllegalArgumentException e) {
                                // Expected exception
                            }
                        }

    @Test
                        public void testCreateCopyWithSingleItem() throws CloneNotSupportedException {
                            TimeSeries timeSeries = new TimeSeries("Test Series");
                            Day day2 = new Day(2, 1, 2000);
                            timeSeries.add(day2, 2.0);
                            
                            TimeSeries copy = timeSeries.createCopy(day2, day2);
                            assertEquals(1, copy.getItemCount());
                            assertEquals(2.0, copy.getValue(0).doubleValue(), 0.0001);
                        }

    @Test
                        public void testCreateCopyWithAllItems() throws CloneNotSupportedException {
                            TimeSeries timeSeries = new TimeSeries("Test Series");
                            Day day1 = new Day(1, 1, 2000);
                            Day day2 = new Day(2, 1, 2000);
                            Day day3 = new Day(3, 1, 2000);
                            
                            timeSeries.add(day1, 1.0);
                            timeSeries.add(day2, 2.0);
                            timeSeries.add(day3, 3.0);
                            
                            TimeSeries copy = timeSeries.createCopy(day1, day3);
                            assertEquals(3, copy.getItemCount());
                            assertEquals(1.0, copy.getValue(0).doubleValue(), 0.0001);
                            assertEquals(2.0, copy.getValue(1).doubleValue(), 0.0001);
                            assertEquals(3.0, copy.getValue(2).doubleValue(), 0.0001);
                        }

    @Test
                        public void testCreateCopyWithEmptySeries() throws CloneNotSupportedException {
                            Day day1 = new Day(1, 1, 2000);
                            Day day3 = new Day(3, 1, 2000);
                            TimeSeries emptySeries = new TimeSeries("Empty Series");
                            TimeSeries copy = emptySeries.createCopy(day1, day3);
                            assertEquals(0, copy.getItemCount());
                        }

    @Test
                        public void testCreateCopyWithStartAfterLastItem() throws CloneNotSupportedException {
                            TimeSeries timeSeries = new TimeSeries("Test Series");
                            timeSeries.add(new Day(1, 1, 2023), 100.0);
                            timeSeries.add(new Day(2, 1, 2023), 200.0);
                            timeSeries.add(new Day(3, 1, 2023), 300.0);
                            
                            Day dayAfterLast = new Day(4, 1, 2023);
                            TimeSeries copy = timeSeries.createCopy(dayAfterLast, dayAfterLast);
                            assertEquals(0, copy.getItemCount());
                        }

    @Test
                        public void testCreateCopyWithEndBeforeFirstItem() throws CloneNotSupportedException {
                            TimeSeries timeSeries = new TimeSeries("Test Series");
                            timeSeries.add(new Day(2, 1, 2022), 100.0); // Add at least one item to the series
                            
                            Day dayBeforeFirst = new Day(1, 1, 2022);
                            TimeSeries copy = timeSeries.createCopy(dayBeforeFirst, dayBeforeFirst);
                            assertEquals(0, copy.getItemCount());
                        }

    @Test
                        public void testCreateCopyWithSameStartAndEndNotInSeries() throws CloneNotSupportedException {
                            TimeSeries timeSeries = new TimeSeries("Test Series");
                            Day dayBetween = new Day(1, 1, 2023);
                            TimeSeries copy = timeSeries.createCopy(dayBetween, dayBetween);
                            assertEquals(0, copy.getItemCount());
                        }

    @Test
        public void testCreateCopyWithSeriesException() throws Exception {
            // Create a new series
            TimeSeries series = new TimeSeries("Test Series");
            
            // Add some normal items first
            series.add(new Day(1, 1, 2023), 10.0);
            series.add(new Day(2, 1, 2023), 20.0);
            series.add(new Day(3, 1, 2023), 30.0);
            
            // Create a mock item that throws CloneNotSupportedException when cloned
            TimeSeriesDataItem mockItem = new TimeSeriesDataItem(new Day(4, 1, 2023), 40.0);
            TimeSeriesDataItem spyItem = spy(mockItem);
            doThrow(new CloneNotSupportedException("Mock exception"))
                .when(spyItem).clone();
            
            // Add the mock item to the series
            Method addMethod = TimeSeries.class.getDeclaredMethod("add", TimeSeriesDataItem.class, boolean.class);
            addMethod.setAccessible(true);
            addMethod.invoke(series, spyItem, false);
            
            // Add some more normal items
            series.add(new Day(5, 1, 2023), 50.0);
            series.add(new Day(6, 1, 2023), 60.0);
            
            // Test that the method still works despite the exception
            TimeSeries copy = series.createCopy(0, 5);
            assertEquals(5, copy.getItemCount()); // Should still copy the valid items
        }


}
