package gentest.org.jfree.chart.plot.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.plot.*;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import org.jfree.chart.LegendItem;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.annotations.CategoryAnnotation;
import org.jfree.chart.axis.Axis;
import org.jfree.chart.axis.AxisCollection;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.AxisSpace;
import org.jfree.chart.axis.AxisState;
import org.jfree.chart.axis.CategoryAnchor;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.axis.ValueTick;
import org.jfree.chart.event.ChartChangeEventType;
import org.jfree.chart.event.PlotChangeEvent;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.event.RendererChangeListener;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.util.Layer;
import org.jfree.chart.util.ObjectList;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.chart.util.PaintUtilities;
import org.jfree.chart.util.PublicCloneable;
import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.RectangleInsets;
import org.jfree.chart.util.SerialUtilities;
import org.jfree.chart.util.SortOrder;
import org.jfree.data.Range;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.general.Dataset;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.general.DatasetUtilities;
 
public class CategoryPlotTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                    public void testRemoveDomainMarkerWithNullMarker() {
                                                                                        CategoryPlot plot = new CategoryPlot();
                                                                                        try {
                                                                                            plot.removeDomainMarker(null, Layer.FOREGROUND);
                                                                                            fail("Expected IllegalArgumentException");
                                                                                        } catch (IllegalArgumentException e) {
                                                                                            assertEquals("Null 'marker' argument.", e.getMessage());
                                                                                        }
                                                                                    }

    @Test
                                                                                    public void testRemoveDomainMarkerWithNullLayer() {
                                                                                        CategoryPlot plot = new CategoryPlot();
                                                                                        Marker marker = new ValueMarker(1.0);
                                                                                        try {
                                                                                            plot.removeDomainMarker(marker, null);
                                                                                            fail("Expected IllegalArgumentException");
                                                                                        } catch (IllegalArgumentException e) {
                                                                                            assertEquals("Null 'layer' not permitted.", e.getMessage());
                                                                                        }
                                                                                    }

    @Test
                                                                                    public void testRemoveDomainMarkerWhenNoMarkersExist() {
                                                                                        CategoryPlot plot = new CategoryPlot();
                                                                                        Marker marker = new ValueMarker(1.0);
                                                                                        assertFalse(plot.removeDomainMarker(marker, Layer.FOREGROUND));
                                                                                        assertFalse(plot.removeDomainMarker(marker, Layer.BACKGROUND));
                                                                                    }

    @Test
                                                                                    public void testRemoveDomainMarkerWithSpecificRendererIndex() {
                                                                                        CategoryPlot plot = new CategoryPlot();
                                                                                        CategoryMarker marker = new CategoryMarker(1.0);
                                                                                        
                                                                                        plot.addDomainMarker(0, marker, Layer.FOREGROUND);
                                                                                        assertTrue(plot.removeDomainMarker(0, marker, Layer.FOREGROUND));
                                                                                        assertFalse(plot.removeDomainMarker(0, marker, Layer.FOREGROUND));
                                                                                    }

    @Test
                                                                                    public void testRemoveDomainMarkerWithInvalidRendererIndex() {
                                                                                        CategoryPlot plot = new CategoryPlot();
                                                                                        CategoryMarker marker = new CategoryMarker(0.5);
                                                                                        plot.addDomainMarker(0, marker, Layer.FOREGROUND);
                                                                                        assertFalse(plot.removeDomainMarker(1, marker, Layer.FOREGROUND));
                                                                                    }

    @Test
                                                                                    public void testRemoveNonExistentMarker() {
                                                                                        // Setup
                                                                                        CategoryPlot plot = new CategoryPlot();
                                                                                        int index = 0;
                                                                                        org.jfree.chart.plot.Marker marker = new org.jfree.chart.plot.ValueMarker(1.0);
                                                                                        Layer layer = Layer.FOREGROUND;
                                                                                        
                                                                                        // Don't add any markers
                                                                                        
                                                                                        // Test
                                                                                        boolean result = plot.removeDomainMarker(index, marker, layer);
                                                                                        
                                                                                        // Verify
                                                                                        assertFalse("Should return false when marker doesn't exist", result);
                                                                                    }

    @Test
                                                                                    public void testRemoveMarkerFromEmptyLayer() {
                                                                                        // Setup
                                                                                        int index = 0;
                                                                                        Layer layer = Layer.FOREGROUND;
                                                                                        CategoryMarker marker = new CategoryMarker("Test");
                                                                                        CategoryPlot plot = new CategoryPlot();
                                                                                        
                                                                                        // Use reflection to access private field
                                                                                        try {
                                                                                            java.lang.reflect.Field foregroundMarkersField = CategoryPlot.class.getDeclaredField("foregroundDomainMarkers");
                                                                                            foregroundMarkersField.setAccessible(true);
                                                                                            Map<Integer, List<Marker>> foregroundMarkers = new HashMap<>();
                                                                                            foregroundMarkersField.set(plot, foregroundMarkers);
                                                                                            
                                                                                            // Create empty list for the index
                                                                                            foregroundMarkers.put(index, new ArrayList<>());
                                                                                            
                                                                                            // Test
                                                                                            boolean result = plot.removeDomainMarker(index, marker, layer);
                                                                                            
                                                                                            // Verify
                                                                                            assertFalse("Should return false when marker list is empty", result);
                                                                                        } catch (Exception e) {
                                                                                            fail("Reflection failed: " + e.getMessage());
                                                                                        }
                                                                                    }

    @Test
                                                                                    public void testRemoveMarkerWithNullMarker() {
                                                                                        // Setup
                                                                                        CategoryPlot plot = new CategoryPlot();
                                                                                        int index = 0;
                                                                                        Layer layer = Layer.FOREGROUND;
                                                                                        
                                                                                        try {
                                                                                            plot.removeDomainMarker(index, null, layer);
                                                                                            fail("Expected IllegalArgumentException");
                                                                                        } catch (IllegalArgumentException e) {
                                                                                            // Expected
                                                                                        }
                                                                                    }

    @Test
                                                                                    public void testRemoveMarkerWithNullLayer() {
                                                                                        // Setup
                                                                                        int index = 0;
                                                                                        Marker marker = new IntervalMarker(1.0, 2.0);
                                                                                        CategoryPlot plot = new CategoryPlot();
                                                                                        
                                                                                        try {
                                                                                            plot.removeDomainMarker(index, marker, null);
                                                                                            fail("Expected IllegalArgumentException");
                                                                                        } catch (IllegalArgumentException e) {
                                                                                            // Expected
                                                                                        }
                                                                                    }

    @Test
                                                                                    public void testRemoveMarkerWithInvalidIndex() {
                                                                                        // Setup
                                                                                        CategoryPlot plot = new CategoryPlot();
                                                                                        int invalidIndex = -1;
                                                                                        Marker marker = mock(Marker.class);
                                                                                        Layer layer = Layer.FOREGROUND;
                                                                                        
                                                                                        // Test
                                                                                        boolean result = plot.removeDomainMarker(invalidIndex, marker, layer);
                                                                                        
                                                                                        // Verify
                                                                                        assertFalse("Should return false for invalid index", result);
                                                                                    }

    @Test
                                                                                    public void testRemoveMarkerFromMultipleMarkers() {
                                                                                        // Setup
                                                                                        CategoryPlot plot = new CategoryPlot();
                                                                                        int index = 0;
                                                                                        Layer layer = Layer.FOREGROUND;
                                                                                        Marker marker = new ValueMarker(1.0);
                                                                                        Marker marker2 = new ValueMarker(2.0);
                                                                                        
                                                                                        // Use reflection to access private field
                                                                                        try {
                                                                                            java.lang.reflect.Field foregroundMarkersField = CategoryPlot.class.getDeclaredField("foregroundDomainMarkers");
                                                                                            foregroundMarkersField.setAccessible(true);
                                                                                            Map<Integer, ArrayList<Marker>> foregroundMarkers = new HashMap<>();
                                                                                            foregroundMarkersField.set(plot, foregroundMarkers);
                                                                                            
                                                                                            // Add multiple markers
                                                                                            ArrayList<Marker> markers = new ArrayList<>();
                                                                                            markers.add(marker);
                                                                                            markers.add(marker2);
                                                                                            foregroundMarkers.put(index, markers);
                                                                                            
                                                                                            // Test
                                                                                            boolean result = plot.removeDomainMarker(index, marker, layer);
                                                                                            
                                                                                            // Verify
                                                                                            assertTrue("Marker should be removed", result);
                                                                                            assertEquals("Should have one marker remaining", 1, foregroundMarkers.get(index).size());
                                                                                            assertEquals("Remaining marker should be marker2", marker2, foregroundMarkers.get(index).get(0));
                                                                                        } catch (Exception e) {
                                                                                            fail("Reflection failed: " + e.getMessage());
                                                                                        }
                                                                                    }

    @Test
                                                                                public void testRemoveNonExistentMarker1() {
                                                                                    // Setup
                                                                                    CategoryPlot plot = new CategoryPlot();
                                                                                    int index = 0;
                                                                                    Layer layer = Layer.FOREGROUND;
                                                                                    Marker marker = new org.jfree.chart.plot.IntervalMarker(1.0, 2.0);
                                                                                    HashMap<Integer, ArrayList<Marker>> foregroundMarkers = new HashMap<>();
                                                                                    ArrayList<Marker> markers = new ArrayList<>();
                                                                                    foregroundMarkers.put(index, markers);
                                                                                    
                                                                                    // Use reflection to set private field
                                                                                    try {
                                                                                        java.lang.reflect.Field field = CategoryPlot.class.getDeclaredField("foregroundDomainMarkers");
                                                                                        field.setAccessible(true);
                                                                                        field.set(plot, foregroundMarkers);
                                                                                    } catch (Exception e) {
                                                                                        fail("Failed to set foregroundDomainMarkers field");
                                                                                    }
                                                                                    
                                                                                    // Test
                                                                                    boolean result = plot.removeDomainMarker(index, marker, layer);
                                                                                    
                                                                                    // Verify
                                                                                    assertFalse(result);
                                                                                }

    @Test
                                                                                public void testRemoveMarkerFromEmptyMap() {
                                                                                    // Setup
                                                                                    CategoryPlot plot = new CategoryPlot();
                                                                                    Marker marker = new ValueMarker(1.0);
                                                                                    
                                                                                    // Test
                                                                                    boolean result = plot.removeDomainMarker(0, marker, Layer.FOREGROUND);
                                                                                    
                                                                                    // Verify
                                                                                    assertFalse(result);
                                                                                }

    @Test
                                                                                public void testRemoveMarkerWithNullMarker1() {
                                                                                    CategoryPlot plot = new CategoryPlot();
                                                                                    try {
                                                                                        plot.removeDomainMarker(0, null, Layer.FOREGROUND);
                                                                                        fail("Expected IllegalArgumentException");
                                                                                    } catch (IllegalArgumentException e) {
                                                                                        // Expected
                                                                                    }
                                                                                }

    @Test
                                                                                public void testRemoveMarkerWithNullLayer1() {
                                                                                    CategoryPlot plot = new CategoryPlot();
                                                                                    Marker marker = new ValueMarker(1.0);
                                                                                    try {
                                                                                        plot.removeDomainMarker(0, marker, null);
                                                                                        fail("Expected IllegalArgumentException");
                                                                                    } catch (IllegalArgumentException e) {
                                                                                        // Expected
                                                                                    }
                                                                                }

    @Test
                                                                                public void testRemoveDomainMarkerFromMultipleMarkers() {
                                                                                    // Setup
                                                                                    CategoryPlot plot = new CategoryPlot();
                                                                                    Map<Integer, ArrayList<Marker>> foregroundMarkers = new HashMap<>();
                                                                                    Marker marker = new CategoryMarker("TestMarker");
                                                                                    
                                                                                    int index = 0;
                                                                                    Layer layer = Layer.FOREGROUND;
                                                                                    ArrayList<Marker> markers = new ArrayList<>();
                                                                                    markers.add(new CategoryMarker("Marker1"));
                                                                                    markers.add(marker);
                                                                                    markers.add(new CategoryMarker("Marker2"));
                                                                                    foregroundMarkers.put(index, markers);
                                                                                    
                                                                                    // Test
                                                                                    boolean result = plot.removeDomainMarker(index, marker, layer);
                                                                                    
                                                                                    // Verify
                                                                                    assertTrue(result);
                                                                                    assertEquals(2, foregroundMarkers.get(index).size());
                                                                                }

    @Test
                                                                                public void testRemoveMarkerWithNullLayer2() {
                                                                                    // Setup
                                                                                    int index = 0;
                                                                                    Marker marker = new ValueMarker(1.0);
                                                                                    HashMap<Integer, ArrayList<Marker>> foregroundMarkers = new HashMap<>();
                                                                                    ArrayList<Marker> markers = new ArrayList<>();
                                                                                    markers.add(marker);
                                                                                    foregroundMarkers.put(index, markers);
                                                                                    
                                                                                    CategoryPlot plot = new CategoryPlot();
                                                                                    
                                                                                    try {
                                                                                        // Test
                                                                                        plot.removeDomainMarker(index, marker, null, true);
                                                                                        fail("Expected IllegalArgumentException");
                                                                                    } catch (IllegalArgumentException e) {
                                                                                        // Verify
                                                                                        assertEquals("Null 'layer' not permitted.", e.getMessage());
                                                                                    }
                                                                                }

    @Test
                                                                                public void testRemoveMarkerWithNotification() {
                                                                                    // Setup
                                                                                    int index = 0;
                                                                                    Layer layer = Layer.FOREGROUND;
                                                                                    Marker marker = mock(Marker.class);
                                                                                    Map<Integer, ArrayList<Marker>> foregroundMarkers = new HashMap<>();
                                                                                    ArrayList<Marker> markers = new ArrayList<>();
                                                                                    markers.add(marker);
                                                                                    foregroundMarkers.put(index, markers);
                                                                                    
                                                                                    // Create test plot and inject foreground markers
                                                                                    CategoryPlot plot = new CategoryPlot();
                                                                                    try {
                                                                                        java.lang.reflect.Field fgField = CategoryPlot.class.getDeclaredField("foregroundDomainMarkers");
                                                                                        fgField.setAccessible(true);
                                                                                        fgField.set(plot, foregroundMarkers);
                                                                                    } catch (Exception e) {
                                                                                        fail("Failed to set foreground markers via reflection");
                                                                                    }
                                                                                    
                                                                                    // Mock plot to verify notification is sent
                                                                                    CategoryPlot spyPlot = spy(plot);
                                                                                    
                                                                                    // Test
                                                                                    boolean result = spyPlot.removeDomainMarker(index, marker, layer, true);
                                                                                    
                                                                                    // Verify
                                                                                    assertTrue(result);
                                                                                    assertTrue(foregroundMarkers.get(index).isEmpty());
                                                                                    verify(spyPlot, times(1)).notifyListeners(any(org.jfree.chart.event.PlotChangeEvent.class));
                                                                                }

    @Test
                                                                                public void testClearRangeMarkersWithNullMaps() {
                                                                                    // Create a new CategoryPlot instance
                                                                                    CategoryPlot categoryPlot = new CategoryPlot();
                                                                                    
                                                                                    // Set maps to null
                                                                                    try {
                                                                                        java.lang.reflect.Field bgField = CategoryPlot.class.getDeclaredField("backgroundRangeMarkers");
                                                                                        bgField.setAccessible(true);
                                                                                        bgField.set(categoryPlot, null);
                                                                                        
                                                                                        java.lang.reflect.Field fgField = CategoryPlot.class.getDeclaredField("foregroundRangeMarkers");
                                                                                        fgField.setAccessible(true);
                                                                                        fgField.set(categoryPlot, null);
                                                                                    } catch (Exception e) {
                                                                                        fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                    }
                                                                                    
                                                                                    // Should not throw any exceptions
                                                                                    categoryPlot.clearRangeMarkers();
                                                                                }

    @Test
                                                                                public void testClearRangeMarkersWithEmptyMaps() {
                                                                                    // Create mock objects
                                                                                    java.util.Map<Integer, org.jfree.chart.plot.Marker> backgroundRangeMarkers = mock(java.util.Map.class);
                                                                                    java.util.Map<Integer, org.jfree.chart.plot.Marker> foregroundRangeMarkers = mock(java.util.Map.class);
                                                                                    
                                                                                    // Create test instance and inject mocks using reflection
                                                                                    org.jfree.chart.plot.CategoryPlot categoryPlot = new org.jfree.chart.plot.CategoryPlot();
                                                                                    try {
                                                                                        java.lang.reflect.Field bgField = org.jfree.chart.plot.CategoryPlot.class.getDeclaredField("backgroundRangeMarkers");
                                                                                        bgField.setAccessible(true);
                                                                                        bgField.set(categoryPlot, backgroundRangeMarkers);
                                                                                        
                                                                                        java.lang.reflect.Field fgField = org.jfree.chart.plot.CategoryPlot.class.getDeclaredField("foregroundRangeMarkers");
                                                                                        fgField.setAccessible(true);
                                                                                        fgField.set(categoryPlot, foregroundRangeMarkers);
                                                                                    } catch (Exception e) {
                                                                                        throw new RuntimeException(e);
                                                                                    }
                                                                            
                                                                                    // Configure mocks
                                                                                    when(backgroundRangeMarkers.keySet()).thenReturn(Collections.emptySet());
                                                                                    when(foregroundRangeMarkers.keySet()).thenReturn(Collections.emptySet());
                                                                                    
                                                                                    // Test method
                                                                                    categoryPlot.clearRangeMarkers();
                                                                                    
                                                                                    // Verify behavior
                                                                                    verify(backgroundRangeMarkers, never()).clear();
                                                                                    verify(foregroundRangeMarkers, never()).clear();
                                                                                }

    @Test
                                                                            public void testRemoveMarkerWithNullMarker2() {
                                                                                CategoryPlot plot = new CategoryPlot();
                                                                                try {
                                                                                    plot.removeDomainMarker(0, null, Layer.FOREGROUND);
                                                                                    fail("Expected IllegalArgumentException");
                                                                                } catch (IllegalArgumentException e) {
                                                                                    // Expected
                                                                                }
                                                                            }

    @Test
                                                                            public void testRemoveMarkerWithNullLayer3() {
                                                                                CategoryPlot plot = new CategoryPlot();
                                                                                Marker marker = new IntervalMarker(1.0, 2.0);
                                                                                try {
                                                                                    plot.removeDomainMarker(0, marker, null);
                                                                                    fail("Expected IllegalArgumentException");
                                                                                } catch (IllegalArgumentException e) {
                                                                                    // Expected
                                                                                }
                                                                            }

    @Test
                                                                            public void testClearRangeMarkersWithNonNullMarkers() {
                                                                                // Setup mocks and test objects
                                                                                CategoryPlot categoryPlot = spy(new CategoryPlot());
                                                                                Collection<Marker> mockMarkers = new ArrayList<>();
                                                                                Iterator<Marker> mockIterator = mock(Iterator.class);
                                                                                Marker mockMarker1 = mock(Marker.class);
                                                                                Marker mockMarker2 = mock(Marker.class);
                                                                        
                                                                                // Configure mock behavior
                                                                                when(mockIterator.hasNext()).thenReturn(true, true, false);
                                                                                when(mockIterator.next()).thenReturn(mockMarker1, mockMarker2);
                                                                                
                                                                                // Add markers to background and foreground
                                                                                categoryPlot.addRangeMarker(0, mockMarker1, Layer.BACKGROUND);
                                                                                categoryPlot.addRangeMarker(0, mockMarker2, Layer.FOREGROUND);
                                                                        
                                                                                // Call the method
                                                                                categoryPlot.clearRangeMarkers(0);
                                                                                
                                                                                // Verify interactions
                                                                                verify(mockMarker1).removeChangeListener(categoryPlot);
                                                                                verify(mockMarker2).removeChangeListener(categoryPlot);
                                                                                
                                                                                // Verify the markers collections are empty
                                                                                assertTrue(categoryPlot.getRangeMarkers(0, Layer.BACKGROUND).isEmpty());
                                                                                assertTrue(categoryPlot.getRangeMarkers(0, Layer.FOREGROUND).isEmpty());
                                                                            }

    @Test
                                                                            public void testClearRangeMarkersWithNullMarkerCollections() {
                                                                                // Create mock objects
                                                                                Marker mockMarker1 = mock(Marker.class);
                                                                                Marker mockMarker2 = mock(Marker.class);
                                                                                Collection<Marker> mockMarkers = mock(Collection.class);
                                                                                Iterator<Marker> mockIterator = mock(Iterator.class);
                                                                                
                                                                                // Create test instance
                                                                                CategoryPlot categoryPlot = new CategoryPlot();
                                                                                
                                                                                // Set up empty maps
                                                                                Map<Integer, Collection<Marker>> emptyMap = new HashMap<>();
                                                                                
                                                                                try {
                                                                                    java.lang.reflect.Field bgField = CategoryPlot.class.getDeclaredField("backgroundRangeMarkers");
                                                                                    bgField.setAccessible(true);
                                                                                    bgField.set(categoryPlot, emptyMap);
                                                                                    
                                                                                    java.lang.reflect.Field fgField = CategoryPlot.class.getDeclaredField("foregroundRangeMarkers");
                                                                                    fgField.setAccessible(true);
                                                                                    fgField.set(categoryPlot, emptyMap);
                                                                                } catch (Exception e) {
                                                                                    fail("Failed to set up test with empty maps: " + e.getMessage());
                                                                                }
                                                                                
                                                                                // Should not throw exception
                                                                                categoryPlot.clearRangeMarkers(0);
                                                                                
                                                                                // Verify no interactions with mock objects
                                                                                verifyNoInteractions(mockMarkers, mockIterator, mockMarker1, mockMarker2);
                                                                            }

    @Test
                                                                            public void testRemoveRangeMarker_NullMarker() {
                                                                                CategoryPlot plot = new CategoryPlot();
                                                                                try {
                                                                                    plot.removeRangeMarker(null);
                                                                                    fail("Expected IllegalArgumentException for null marker");
                                                                                } catch (IllegalArgumentException e) {
                                                                                    assertEquals("Null 'marker' argument.", e.getMessage());
                                                                                }
                                                                            }

    @Test
                                                                            public void testRemoveRangeMarker_NotPresent() {
                                                                                CategoryPlot plot = new CategoryPlot();
                                                                                Marker marker = new ValueMarker(1.0);
                                                                                boolean result = plot.removeRangeMarker(marker);
                                                                                assertFalse("Should return false when marker not present", result);
                                                                            }

    @Test
                                                                            public void testRemoveRangeMarker_PresentInForeground() throws Exception {
                                                                                // Setup
                                                                                CategoryPlot plot = new CategoryPlot();
                                                                                Marker marker = new ValueMarker(1.0);
                                                                                
                                                                                // Get foreground markers using reflection
                                                                                Field foregroundField = CategoryPlot.class.getDeclaredField("foregroundRangeMarkers");
                                                                                foregroundField.setAccessible(true);
                                                                                List foregroundRangeMarkers = (List) foregroundField.get(plot);
                                                                        
                                                                                // Add marker to foreground
                                                                                plot.addRangeMarker(marker, Layer.FOREGROUND);
                                                                                
                                                                                // Verify marker was added
                                                                                assertTrue("Marker should be in foreground", foregroundRangeMarkers.contains(marker));
                                                                                
                                                                                // Remove marker
                                                                                boolean result = plot.removeRangeMarker(marker);
                                                                                
                                                                                // Verify results
                                                                                assertTrue("Should return true when marker removed", result);
                                                                                assertFalse("Marker should no longer be in foreground", 
                                                                                    foregroundRangeMarkers.contains(marker));
                                                                            }

    @Test
                                                                        public void testRemoveRangeMarker_MultipleMarkers() {
                                                                            // Create plot instance
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            
                                                                            // Create markers
                                                                            Marker marker = new ValueMarker(1.0);
                                                                            Marker marker2 = new ValueMarker(2.0);
                                                                            
                                                                            // Add both markers to foreground
                                                                            plot.addRangeMarker(marker, Layer.FOREGROUND);
                                                                            plot.addRangeMarker(marker2, Layer.FOREGROUND);
                                                                            
                                                                            // Remove first marker
                                                                            boolean result = plot.removeRangeMarker(marker);
                                                                            
                                                                            // Get foreground markers using reflection to verify
                                                                            List<Marker> foregroundRangeMarkers;
                                                                            try {
                                                                                java.lang.reflect.Field field = CategoryPlot.class.getDeclaredField("foregroundRangeMarkers");
                                                                                field.setAccessible(true);
                                                                                foregroundRangeMarkers = (List<Marker>) field.get(plot);
                                                                            } catch (Exception e) {
                                                                                throw new RuntimeException(e);
                                                                            }
                                                                            
                                                                            // Verify results
                                                                            assertTrue("Should return true when marker removed", result);
                                                                            assertFalse("First marker should be removed", 
                                                                                foregroundRangeMarkers.contains(marker));
                                                                            assertTrue("Second marker should remain", 
                                                                                foregroundRangeMarkers.contains(marker2));
                                                                        }

    @Test
                                                                        public void testRemoveRangeMarker_WithDifferentRenderers() {
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            Marker marker = new ValueMarker(1.0);
                                                                            Marker marker2 = new ValueMarker(2.0);
                                                                            
                                                                            // Add markers to different renderer indices
                                                                            plot.addRangeMarker(0, marker, Layer.FOREGROUND);
                                                                            plot.addRangeMarker(1, marker2, Layer.FOREGROUND);
                                                                            
                                                                            // Remove first marker
                                                                            boolean result = plot.removeRangeMarker(marker);
                                                                            
                                                                            // Verify results
                                                                            assertTrue("Should return true when marker removed", result);
                                                                            
                                                                            // Use reflection to access private field for verification
                                                                            try {
                                                                                java.lang.reflect.Field foregroundField = CategoryPlot.class.getDeclaredField("foregroundRangeMarkers");
                                                                                foregroundField.setAccessible(true);
                                                                                List<List<Marker>> foregroundRangeMarkers = (List<List<Marker>>) foregroundField.get(plot);
                                                                                
                                                                                assertFalse("First marker should be removed from renderer 0", 
                                                                                    foregroundRangeMarkers.get(0).contains(marker));
                                                                                assertTrue("Second marker should remain in renderer 1", 
                                                                                    foregroundRangeMarkers.get(1).contains(marker2));
                                                                            } catch (Exception e) {
                                                                                fail("Reflection failed: " + e.getMessage());
                                                                            }
                                                                        }

    @Test
                                                                        public void testRemoveRangeMarker_AfterClear() {
                                                                            // Create test objects
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            Marker marker = new ValueMarker(1.0);
                                                                            
                                                                            // Add marker and then clear
                                                                            plot.addRangeMarker(marker, Layer.FOREGROUND);
                                                                            plot.clearRangeMarkers();
                                                                            
                                                                            // Try to remove
                                                                            boolean result = plot.removeRangeMarker(marker);
                                                                            
                                                                            // Verify
                                                                            assertFalse("Should return false when markers were cleared", result);
                                                                        }

    @Test
                                                                        public void testRemoveRangeMarker_ChangeListenerRemoved() {
                                                                            // Create test objects
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            Marker mockMarker = mock(ValueMarker.class);
                                                                            
                                                                            // Add and then remove marker
                                                                            plot.addRangeMarker(mockMarker, Layer.FOREGROUND);
                                                                            plot.removeRangeMarker(mockMarker);
                                                                            
                                                                            // Verify change listener was removed
                                                                            verify(mockMarker).removeChangeListener(plot);
                                                                        }

    @Test
                                                                        public void testRemoveRangeMarkerWithNullLayer() {
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            Marker marker = new org.jfree.chart.plot.IntervalMarker(1.0, 2.0);
                                                                            try {
                                                                                plot.removeRangeMarker(marker, null);
                                                                                fail("Expected IllegalArgumentException");
                                                                            } catch (IllegalArgumentException e) {
                                                                                assertEquals("Null 'layer' not permitted.", e.getMessage());
                                                                            }
                                                                        }

    @Test
                                                                        public void testRemoveRangeMarkerWhenNoMarkersExist() {
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            Marker marker = new ValueMarker(1.0);
                                                                            boolean result = plot.removeRangeMarker(marker, Layer.FOREGROUND);
                                                                            assertFalse(result);
                                                                        }

    @Test
                                                                        public void testRemoveRangeMarkerWhenMarkerExists() {
                                                                            // Create test objects
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            Marker marker = new ValueMarker(1.0);
                                                                            Layer layer = Layer.FOREGROUND;
                                                                            
                                                                            // Add marker first
                                                                            plot.addRangeMarker(marker, Layer.FOREGROUND);
                                                                            
                                                                            // Verify marker was added
                                                                            assertTrue(plot.getRangeMarkers(Layer.FOREGROUND).contains(marker));
                                                                            
                                                                            // Remove marker
                                                                            boolean result = plot.removeRangeMarker(marker, Layer.FOREGROUND);
                                                                            
                                                                            // Verify removal
                                                                            assertTrue(result);
                                                                            assertFalse(plot.getRangeMarkers(Layer.FOREGROUND).contains(marker));
                                                                        }

    @Test
                                                                        public void testRemoveRangeMarkerWhenMarkerDoesNotExist() {
                                                                            // Create test objects
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            Marker marker = new ValueMarker(1.0);
                                                                            Marker anotherMarker = new ValueMarker(2.0);
                                                                            
                                                                            // Add a different marker
                                                                            plot.addRangeMarker(anotherMarker, Layer.FOREGROUND);
                                                                            
                                                                            // Try to remove marker that wasn't added
                                                                            boolean result = plot.removeRangeMarker(marker, Layer.FOREGROUND);
                                                                            
                                                                            // Verify no removal occurred
                                                                            assertFalse(result);
                                                                            assertTrue(plot.getRangeMarkers(Layer.FOREGROUND).contains(anotherMarker));
                                                                        }

    @Test
                                                                        public void testRemoveRangeMarkerFromDifferentLayer() {
                                                                            // Create test objects
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            Marker marker = new ValueMarker(1.0);
                                                                            
                                                                            // Add marker to foreground
                                                                            plot.addRangeMarker(marker, Layer.FOREGROUND);
                                                                            
                                                                            // Try to remove from background (should fail)
                                                                            boolean result = plot.removeRangeMarker(marker, Layer.BACKGROUND);
                                                                            
                                                                            // Verify no removal occurred
                                                                            assertFalse(result);
                                                                            assertTrue(plot.getRangeMarkers(Layer.FOREGROUND).contains(marker));
                                                                        }

    @Test
                                                                        public void testRemoveRangeMarkerWithMultipleMarkers() {
                                                                            // Create test objects
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            Marker marker = new ValueMarker(1.0);
                                                                            Marker anotherMarker = new ValueMarker(2.0);
                                                                            
                                                                            // Add multiple markers
                                                                            plot.addRangeMarker(marker, Layer.FOREGROUND);
                                                                            plot.addRangeMarker(anotherMarker, Layer.FOREGROUND);
                                                                            
                                                                            // Remove one marker
                                                                            boolean result = plot.removeRangeMarker(marker, Layer.FOREGROUND);
                                                                            
                                                                            // Verify correct marker was removed
                                                                            assertTrue(result);
                                                                            assertFalse(plot.getRangeMarkers(Layer.FOREGROUND).contains(marker));
                                                                            assertTrue(plot.getRangeMarkers(Layer.FOREGROUND).contains(anotherMarker));
                                                                        }

    @Test
                                                                        public void testRemoveRangeMarkerWithSpecificRendererIndex() {
                                                                            // Create test objects
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            Marker marker = new org.jfree.chart.plot.IntervalMarker(1.0, 2.0);
                                                                            
                                                                            // Add marker with specific renderer index
                                                                            plot.addRangeMarker(1, marker, Layer.FOREGROUND);
                                                                            
                                                                            // Verify marker was added
                                                                            assertTrue(plot.getRangeMarkers(1, Layer.FOREGROUND).contains(marker));
                                                                            
                                                                            // Remove marker with same index
                                                                            boolean result = plot.removeRangeMarker(1, marker, Layer.FOREGROUND);
                                                                            
                                                                            // Verify removal
                                                                            assertTrue(result);
                                                                            assertFalse(plot.getRangeMarkers(1, Layer.FOREGROUND).contains(marker));
                                                                        }

    @Test
                                                                        public void testRemoveRangeMarkerWithDifferentRendererIndex() {
                                                                            // Create test objects
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            Marker marker = new ValueMarker(1.0);
                                                                            
                                                                            // Add marker with specific renderer index
                                                                            plot.addRangeMarker(1, marker, Layer.FOREGROUND);
                                                                            
                                                                            // Try to remove with different index (should fail)
                                                                            boolean result = plot.removeRangeMarker(2, marker, Layer.FOREGROUND);
                                                                            
                                                                            // Verify no removal occurred
                                                                            assertFalse(result);
                                                                            assertTrue(plot.getRangeMarkers(1, Layer.FOREGROUND).contains(marker));
                                                                        }

    @Test
                                                                    public void testRemoveRangeMarkerFromBackgroundLayer() {
                                                                        // Setup
                                                                        CategoryPlot plot = new CategoryPlot();
                                                                        int index = 0;
                                                                        Marker marker = new ValueMarker(1.0);
                                                                        Layer layer = Layer.BACKGROUND;
                                                                        
                                                                        // Use reflection to access private fields
                                                                        try {
                                                                            java.lang.reflect.Field backgroundMarkersField = CategoryPlot.class.getDeclaredField("backgroundRangeMarkers");
                                                                            backgroundMarkersField.setAccessible(true);
                                                                            HashMap backgroundMarkers = (HashMap) backgroundMarkersField.get(plot);
                                                                            
                                                                            // Initialize if null
                                                                            if (backgroundMarkers == null) {
                                                                                backgroundMarkers = new HashMap();
                                                                                backgroundMarkersField.set(plot, backgroundMarkers);
                                                                            }
                                                                            
                                                                            // Add marker to background
                                                                            plot.addRangeMarker(index, marker, layer, false);
                                                                            
                                                                            // Verify marker was added
                                                                            assertTrue(backgroundMarkers.containsKey(index));
                                                                            assertTrue(((ArrayList)backgroundMarkers.get(index)).contains(marker));
                                                                            
                                                                            // Test removal
                                                                            boolean result = plot.removeRangeMarker(index, marker, layer, true);
                                                                            
                                                                            // Verify
                                                                            assertTrue(result);
                                                                            assertFalse(((ArrayList)backgroundMarkers.get(index)).contains(marker));
                                                                        } catch (Exception e) {
                                                                            fail("Reflection failed: " + e.getMessage());
                                                                        }
                                                                    }

    @Test
                                                                    public void testRemoveRangeMarkerWithNullMarker() {
                                                                        CategoryPlot plot = new CategoryPlot();
                                                                        plot.removeRangeMarker(0, null, Layer.FOREGROUND, true);
                                                                    }

    @Test
                                                                    public void testRemoveRangeMarkerFromBackgroundLayer1() {
                                                                        // Create test objects
                                                                        CategoryPlot plot = new CategoryPlot();
                                                                        Marker marker = new ValueMarker(1.0);
                                                                        Map<Integer, ArrayList<Marker>> backgroundRangeMarkers = new HashMap<>();
                                                                        
                                                                        // Set up test scenario
                                                                        int index = 0;
                                                                        ArrayList<Marker> markers = new ArrayList<>();
                                                                        markers.add(marker);
                                                                        backgroundRangeMarkers.put(index, markers);
                                                                        
                                                                        // Use reflection to set private field
                                                                        try {
                                                                            java.lang.reflect.Field field = CategoryPlot.class.getDeclaredField("backgroundRangeMarkers");
                                                                            field.setAccessible(true);
                                                                            field.set(plot, backgroundRangeMarkers);
                                                                        } catch (Exception e) {
                                                                            fail("Failed to set backgroundRangeMarkers field via reflection");
                                                                        }
                                                                        
                                                                        // Execute test
                                                                        boolean result = plot.removeRangeMarker(index, marker, Layer.BACKGROUND, true);
                                                                        
                                                                        // Verify results
                                                                        assertTrue(result);
                                                                        assertFalse(backgroundRangeMarkers.get(index).contains(marker));
                                                                    }

    @Test
                                                                    public void testRemoveRangeMarkerWhenMarkerNotPresent() {
                                                                        CategoryPlot plot = new CategoryPlot();
                                                                        int index = 0;
                                                                        Marker marker = new ValueMarker(1.0);
                                                                        HashMap<Integer, ArrayList<Marker>> foregroundRangeMarkers = new HashMap<>();
                                                                        ArrayList<Marker> markers = new ArrayList<>();
                                                                        foregroundRangeMarkers.put(index, markers);
                                                                        
                                                                        // Use reflection to set the private field
                                                                        try {
                                                                            java.lang.reflect.Field field = CategoryPlot.class.getDeclaredField("foregroundRangeMarkers");
                                                                            field.setAccessible(true);
                                                                            field.set(plot, foregroundRangeMarkers);
                                                                        } catch (Exception e) {
                                                                            fail("Failed to set foregroundRangeMarkers field via reflection");
                                                                        }
                                                                        
                                                                        boolean result = plot.removeRangeMarker(index, marker, Layer.FOREGROUND, true);
                                                                        assertFalse(result);
                                                                    }

    @Test
                                                                    public void testRemoveRangeMarkerWithNoMarkersForIndex() {
                                                                        CategoryPlot plot = new CategoryPlot();
                                                                        int index = 0;
                                                                        Marker marker = new ValueMarker(1.0);
                                                                        boolean result = plot.removeRangeMarker(index, marker, Layer.FOREGROUND, true);
                                                                        assertFalse(result);
                                                                    }

    @Test
                                                                    public void testSetRangeCrosshairValue() {
                                                                        // Create a new CategoryPlot instance for testing
                                                                        CategoryPlot plot = new CategoryPlot();
                                                                        
                                                                        // Test default value
                                                                        assertEquals(0.0, plot.getRangeCrosshairValue(), 0.0001);
                                                                        
                                                                        // Test setting positive value
                                                                        plot.setRangeCrosshairValue(5.0);
                                                                        assertEquals(5.0, plot.getRangeCrosshairValue(), 0.0001);
                                                                        
                                                                        // Test setting negative value
                                                                        plot.setRangeCrosshairValue(-3.5);
                                                                        assertEquals(-3.5, plot.getRangeCrosshairValue(), 0.0001);
                                                                        
                                                                        // Test setting zero
                                                                        plot.setRangeCrosshairValue(0.0);
                                                                        assertEquals(0.0, plot.getRangeCrosshairValue(), 0.0001);
                                                                        
                                                                        // Test setting Double.MAX_VALUE
                                                                        plot.setRangeCrosshairValue(Double.MAX_VALUE);
                                                                        assertEquals(Double.MAX_VALUE, plot.getRangeCrosshairValue(), 0.0001);
                                                                        
                                                                        // Test setting Double.MIN_VALUE
                                                                        plot.setRangeCrosshairValue(Double.MIN_VALUE);
                                                                        assertEquals(Double.MIN_VALUE, plot.getRangeCrosshairValue(), 0.0001);
                                                                    }

    @Test
                                                                    public void testSetRangeCrosshairValueWithOtherProperties() {
                                                                        // Create plot instance
                                                                        CategoryPlot plot = new CategoryPlot();
                                                                        
                                                                        // Set up other crosshair properties
                                                                        Stroke stroke = new BasicStroke(2.0f);
                                                                        Paint paint = Color.RED;
                                                                        plot.setRangeCrosshairStroke(stroke);
                                                                        plot.setRangeCrosshairPaint(paint);
                                                                        
                                                                        // Test that setting value doesn't affect other properties
                                                                        plot.setRangeCrosshairValue(42.0);
                                                                        assertEquals(42.0, plot.getRangeCrosshairValue(), 0.0001);
                                                                        assertEquals(stroke, plot.getRangeCrosshairStroke());
                                                                        assertEquals(paint, plot.getRangeCrosshairPaint());
                                                                    }

    @Test
                                                                    public void testSetRangeCrosshairValueWithLockedOnData() {
                                                                        // Create a new CategoryPlot instance
                                                                        CategoryPlot plot = new CategoryPlot();
                                                                        
                                                                        // Set locked on data to true
                                                                        plot.setRangeCrosshairLockedOnData(true);
                                                                        
                                                                        // Test setting value
                                                                        plot.setRangeCrosshairValue(100.0);
                                                                        assertEquals(100.0, plot.getRangeCrosshairValue(), 0.0001);
                                                                        assertTrue(plot.isRangeCrosshairLockedOnData());
                                                                        
                                                                        // Set locked on data to false
                                                                        plot.setRangeCrosshairLockedOnData(false);
                                                                        
                                                                        // Test setting value
                                                                        plot.setRangeCrosshairValue(200.0);
                                                                        assertEquals(200.0, plot.getRangeCrosshairValue(), 0.0001);
                                                                        assertFalse(plot.isRangeCrosshairLockedOnData());
                                                                    }

    @Test
                                                                public void testRemoveRangeMarkerFromBackgroundLayer2() {
                                                                    // Setup
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    int index = 0;
                                                                    Marker marker = new ValueMarker(1.0);
                                                                    Layer layer = Layer.BACKGROUND;
                                                                    
                                                                    // Use reflection to access private field
                                                                    Map<Integer, List<Marker>> backgroundMarkers;
                                                                    try {
                                                                        Field field = CategoryPlot.class.getDeclaredField("backgroundRangeMarkers");
                                                                        field.setAccessible(true);
                                                                        backgroundMarkers = (Map<Integer, List<Marker>>) field.get(plot);
                                                                    } catch (Exception e) {
                                                                        throw new RuntimeException(e);
                                                                    }
                                                                    
                                                                    // Add marker to background
                                                                    plot.addRangeMarker(index, marker, layer, false);
                                                                    
                                                                    // Verify marker was added
                                                                    assertTrue(backgroundMarkers.containsKey(index));
                                                                    assertTrue(backgroundMarkers.get(index).contains(marker));
                                                                    
                                                                    // Test removal
                                                                    boolean result = plot.removeRangeMarker(index, marker, layer, true);
                                                                    
                                                                    // Verify
                                                                    assertTrue(result);
                                                                    assertFalse(backgroundMarkers.get(index).contains(marker));
                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                public void testRemoveRangeMarkerWithNullMarker1() {
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    plot.removeRangeMarker(0, null, Layer.FOREGROUND, true);
                                                                }

    @Test
                                                                public void testRemoveDomainMarkerFromWrongLayer() {
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    CategoryMarker marker = new CategoryMarker(1.0);
                                                                    plot.addDomainMarker(marker, Layer.FOREGROUND);
                                                                    assertFalse(plot.removeDomainMarker(marker, Layer.BACKGROUND));
                                                                }

    @Test
                                                                public void testRemoveDomainMarkerWithMultipleMarkers() {
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    CategoryMarker marker = new CategoryMarker(1.0);
                                                                    CategoryMarker anotherMarker = new CategoryMarker(2.0);
                                                                    
                                                                    plot.addDomainMarker(marker, Layer.FOREGROUND);
                                                                    plot.addDomainMarker(anotherMarker, Layer.FOREGROUND);
                                                                    
                                                                    assertTrue(plot.removeDomainMarker(marker, Layer.FOREGROUND));
                                                                    assertFalse(plot.removeDomainMarker(marker, Layer.FOREGROUND));
                                                                    assertTrue(plot.removeDomainMarker(anotherMarker, Layer.FOREGROUND));
                                                                }

    @Test
                                                                public void testRemoveDomainMarkerFromForegroundLayer() {
                                                                    // Setup
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    int index = 0;
                                                                    Layer layer = Layer.FOREGROUND;
                                                                    ValueMarker marker = new ValueMarker(1.0);
                                                                    HashMap<Integer, ArrayList<org.jfree.chart.plot.Marker>> foregroundMarkers = new HashMap<>();
                                                                    ArrayList<org.jfree.chart.plot.Marker> markers = new ArrayList<>();
                                                                    markers.add(marker);
                                                                    foregroundMarkers.put(index, markers);
                                                                    
                                                                    // Use reflection to set the private field
                                                                    try {
                                                                        java.lang.reflect.Field field = CategoryPlot.class.getDeclaredField("foregroundDomainMarkers");
                                                                        field.setAccessible(true);
                                                                        field.set(plot, foregroundMarkers);
                                                                    } catch (Exception e) {
                                                                        fail("Failed to set foregroundDomainMarkers field via reflection");
                                                                    }
                                                                    
                                                                    // Test
                                                                    boolean result = plot.removeDomainMarker(index, marker, layer);
                                                                    
                                                                    // Verify
                                                                    assertTrue(result);
                                                                    assertTrue(foregroundMarkers.get(index).isEmpty());
                                                                }

    @Test
                                                                public void testRemoveDomainMarkerFromBackgroundLayer() {
                                                                    // Setup
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    int index = 0;
                                                                    Layer layer = Layer.BACKGROUND;
                                                                    Marker marker = new ValueMarker(0.0); // Changed from abstract Marker to concrete ValueMarker
                                                                    Map<Integer, ArrayList<Marker>> backgroundMarkers = new HashMap<>();
                                                                    ArrayList<Marker> markers = new ArrayList<>();
                                                                    markers.add(marker);
                                                                    backgroundMarkers.put(index, markers);
                                                                    
                                                                    // Use reflection to set the backgroundMarkers field
                                                                    try {
                                                                        java.lang.reflect.Field field = CategoryPlot.class.getDeclaredField("backgroundDomainMarkers");
                                                                        field.setAccessible(true);
                                                                        field.set(plot, backgroundMarkers);
                                                                    } catch (Exception e) {
                                                                        fail("Failed to set backgroundMarkers field via reflection");
                                                                    }
                                                                    
                                                                    // Test
                                                                    boolean result = plot.removeDomainMarker(index, marker, layer);
                                                                    
                                                                    // Verify
                                                                    assertTrue(result);
                                                                    assertTrue(backgroundMarkers.get(index).isEmpty());
                                                                }

    @Test
                                                                public void testRemoveDomainMarkerFromBackgroundLayer1() {
                                                                    // Setup
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    int index = 0;
                                                                    Layer layer = Layer.BACKGROUND;
                                                                    Marker marker = new CategoryMarker(0); // Using concrete implementation
                                                                    Map<Integer, ArrayList<Marker>> backgroundMarkers = new HashMap<>();
                                                                    ArrayList<Marker> markers = new ArrayList<>();
                                                                    markers.add(marker);
                                                                    backgroundMarkers.put(index, markers);
                                                                    
                                                                    // Use reflection to set private field
                                                                    try {
                                                                        java.lang.reflect.Field field = CategoryPlot.class.getDeclaredField("backgroundDomainMarkers");
                                                                        field.setAccessible(true);
                                                                        field.set(plot, backgroundMarkers);
                                                                    } catch (Exception e) {
                                                                        fail("Failed to set backgroundDomainMarkers field via reflection");
                                                                    }
                                                                    
                                                                    // Test
                                                                    boolean result = plot.removeDomainMarker(index, marker, layer, true);
                                                                    
                                                                    // Verify
                                                                    assertTrue(result);
                                                                    assertTrue(backgroundMarkers.get(index).isEmpty());
                                                                }

    @Test
                                                                public void testRemoveNonExistentMarker2() {
                                                                    // Setup
                                                                    int index = 0;
                                                                    Layer layer = Layer.FOREGROUND;
                                                                    Marker marker = new ValueMarker(1.0);  // Changed from abstract Marker to concrete ValueMarker
                                                                    HashMap<Integer, ArrayList<Marker>> foregroundMarkers = new HashMap<>();
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    
                                                                    // Use reflection to set private field
                                                                    try {
                                                                        java.lang.reflect.Field field = CategoryPlot.class.getDeclaredField("foregroundRangeMarkers");
                                                                        field.setAccessible(true);
                                                                        field.set(plot, foregroundMarkers);
                                                                    } catch (Exception e) {
                                                                        fail("Failed to set foregroundMarkers field via reflection");
                                                                    }
                                                                    
                                                                    ArrayList<Marker> markers = new ArrayList<>();
                                                                    foregroundMarkers.put(index, markers);
                                                                    
                                                                    // Test
                                                                    boolean result = plot.removeRangeMarker(index, marker, layer, true);
                                                                    
                                                                    // Verify
                                                                    assertFalse(result);
                                                                }

    @Test
                                                                public void testRemoveMarkerFromEmptyMap1() {
                                                                    // Setup
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    int index = 0;
                                                                    Marker marker = new ValueMarker(0.0); // Changed from abstract Marker to concrete ValueMarker
                                                                    Layer layer = Layer.FOREGROUND;
                                                                    
                                                                    // Test
                                                                    boolean result = plot.removeDomainMarker(index, marker, layer, true);
                                                                    
                                                                    // Verify
                                                                    assertFalse(result);
                                                                }

    @Test
                                                                public void testRemoveMarkerWithNullMarker3() {
                                                                    // Setup
                                                                    int index = 0;
                                                                    Layer layer = Layer.FOREGROUND;
                                                                    Marker marker = new ValueMarker(1.0); // Changed from abstract Marker to concrete ValueMarker
                                                                    HashMap<Integer, ArrayList<Marker>> foregroundMarkers = new HashMap<>();
                                                                    ArrayList<Marker> markers = new ArrayList<>();
                                                                    markers.add(marker);
                                                                    foregroundMarkers.put(index, markers);
                                                                    
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    try {
                                                                        // Use reflection to set the foregroundMarkers field
                                                                        java.lang.reflect.Field field = CategoryPlot.class.getDeclaredField("foregroundMarkers");
                                                                        field.setAccessible(true);
                                                                        field.set(plot, foregroundMarkers);
                                                                        
                                                                        // Test
                                                                        plot.removeDomainMarker(index, null, layer, true);
                                                                        fail("Expected IllegalArgumentException");
                                                                    } catch (IllegalArgumentException e) {
                                                                        // Verify
                                                                        assertEquals("Null 'marker' argument.", e.getMessage());
                                                                    } catch (Exception e) {
                                                                        fail("Unexpected exception: " + e.getMessage());
                                                                    }
                                                                }

    @Test
                                                                public void testRemoveDomainMarkerFromBackgroundLayer2() {
                                                                    // Setup
                                                                    int index = 0;
                                                                    Layer layer = Layer.BACKGROUND;
                                                                    Marker marker = new ValueMarker(1.0); // Using concrete subclass instead of abstract Marker
                                                                    ArrayList<Marker> markers = new ArrayList<>();
                                                                    markers.add(marker);
                                                                    
                                                                    HashMap<Integer, ArrayList<Marker>> backgroundMarkers = new HashMap<>();
                                                                    backgroundMarkers.put(index, markers);
                                                                    
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    // Use reflection to set the backgroundMarkers field if needed
                                                                    try {
                                                                        java.lang.reflect.Field field = CategoryPlot.class.getDeclaredField("backgroundDomainMarkers");
                                                                        field.setAccessible(true);
                                                                        field.set(plot, backgroundMarkers);
                                                                    } catch (Exception e) {
                                                                        fail("Failed to set backgroundMarkers field via reflection");
                                                                    }
                                                                    
                                                                    // Test
                                                                    boolean result = plot.removeDomainMarker(index, marker, layer);
                                                                    
                                                                    // Verify
                                                                    assertTrue(result);
                                                                    assertTrue(backgroundMarkers.get(index).isEmpty());
                                                                }

    @Test
                                                                public void testRemoveNonExistentMarker3() {
                                                                    // Setup
                                                                    int index = 0;
                                                                    Layer layer = Layer.FOREGROUND;
                                                                    Marker marker = new ValueMarker(1.0);  // Using concrete ValueMarker instead of abstract Marker
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    HashMap<Integer, ArrayList<Marker>> foregroundMarkers = new HashMap<>();
                                                                    ArrayList<Marker> markers = new ArrayList<>();
                                                                    foregroundMarkers.put(index, markers);
                                                            
                                                                    // Use reflection to set the foregroundMarkers field
                                                                    try {
                                                                        java.lang.reflect.Field field = CategoryPlot.class.getDeclaredField("foregroundDomainMarkers");
                                                                        field.setAccessible(true);
                                                                        field.set(plot, foregroundMarkers);
                                                                    } catch (Exception e) {
                                                                        fail("Failed to set foregroundMarkers field via reflection");
                                                                    }
                                                                    
                                                                    // Test
                                                                    boolean result = plot.removeDomainMarker(index, marker, layer);
                                                                    
                                                                    // Verify
                                                                    assertFalse(result);
                                                                }

    @Test
                                                                public void testRemoveDomainMarkerFromBackgroundLayer3() {
                                                                    // Setup
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    Map<Integer, ArrayList<Marker>> backgroundMarkers = new HashMap<>();
                                                                    
                                                                    // Use reflection to set private field
                                                                    try {
                                                                        java.lang.reflect.Field field = CategoryPlot.class.getDeclaredField("backgroundDomainMarkers");
                                                                        field.setAccessible(true);
                                                                        field.set(plot, backgroundMarkers);
                                                                    } catch (Exception e) {
                                                                        fail("Failed to set backgroundDomainMarkers field");
                                                                    }
                                                                
                                                                    int index = 0;
                                                                    Layer layer = Layer.BACKGROUND;
                                                                    Marker marker = new ValueMarker(0.5); // Using concrete subclass instead of abstract Marker
                                                                    ArrayList<Marker> markers = new ArrayList<>();
                                                                    markers.add(marker);
                                                                    backgroundMarkers.put(index, markers);
                                                                    
                                                                    // Test
                                                                    boolean result = plot.removeDomainMarker(index, marker, layer, true);
                                                                    
                                                                    // Verify
                                                                    assertTrue(result);
                                                                    assertTrue(backgroundMarkers.get(index).isEmpty());
                                                                }

    @Test
                                                            public void testClearRangeMarkersWithNullForegroundMarkers() {
                                                                // Create mock objects and test instance
                                                                CategoryPlot categoryPlot = new CategoryPlot();
                                                                Collection mockCollection = mock(Collection.class);
                                                                Map<Integer, Collection> mockMarkers = new HashMap<>();
                                                                mockMarkers.put(0, mockCollection);
                                                                
                                                                // Set background markers
                                                                try {
                                                                    java.lang.reflect.Field bgField = CategoryPlot.class.getDeclaredField("backgroundRangeMarkers");
                                                                    bgField.setAccessible(true);
                                                                    bgField.set(categoryPlot, mockMarkers);
                                                                } catch (Exception e) {
                                                                    fail("Failed to set background markers: " + e.getMessage());
                                                                }
                                                                
                                                                // Set foreground markers to null
                                                                try {
                                                                    java.lang.reflect.Field fgField = CategoryPlot.class.getDeclaredField("foregroundRangeMarkers");
                                                                    fgField.setAccessible(true);
                                                                    fgField.set(categoryPlot, null);
                                                                } catch (Exception e) {
                                                                    fail("Failed to set foreground markers to null: " + e.getMessage());
                                                                }
                                                                
                                                                // Should not throw exception
                                                                categoryPlot.clearRangeMarkers(0);
                                                                
                                                                // Verify background markers were still cleared
                                                                verify(mockCollection).clear();
                                                            }

    @Test
                                                            public void testRemoveRangeMarker_PresentInBackground() throws Exception {
                                                                // Create test objects
                                                                CategoryPlot plot = new CategoryPlot();
                                                                Marker marker = new ValueMarker(1.0);
                                                                
                                                                // Get background markers field via reflection
                                                                Field backgroundField = CategoryPlot.class.getDeclaredField("backgroundRangeMarkers");
                                                                backgroundField.setAccessible(true);
                                                                List<?> backgroundRangeMarkers = (List<?>) backgroundField.get(plot);
                                                        
                                                                // Add marker to background
                                                                plot.addRangeMarker(marker, Layer.BACKGROUND);
                                                                
                                                                // Verify marker was added
                                                                assertTrue("Marker should be in background", backgroundRangeMarkers.contains(marker));
                                                                
                                                                // Remove marker
                                                                boolean result = plot.removeRangeMarker(marker);
                                                                
                                                                // Verify results
                                                                assertTrue("Should return true when marker removed", result);
                                                                assertFalse("Marker should no longer be in background", 
                                                                    backgroundRangeMarkers.contains(marker));
                                                            }

    @Test
                                                            public void testRemoveMarkerWithInvalidIndex1() {
                                                                // Create test objects
                                                                CategoryPlot plot = new CategoryPlot();
                                                                Marker marker = new ValueMarker(1.0);
                                                                List<Marker> foregroundMarkers = (List<Marker>) plot.getRangeMarkers(0, Layer.FOREGROUND);
                                                                
                                                                // Setup - add marker to index 0
                                                                plot.addRangeMarker(0, marker, Layer.FOREGROUND, false);
                                                                
                                                                // Try to remove from different index
                                                                boolean result = plot.removeRangeMarker(1, marker, Layer.FOREGROUND, true);
                                                                
                                                                // Verify
                                                                assertFalse(result);
                                                                assertTrue(foregroundMarkers.contains(marker)); // Original marker still there
                                                            }

    @Test
                                                        public void testRemoveRangeMarkerFromForegroundLayer() {
                                                            // Create test objects
                                                            CategoryPlot plot = new CategoryPlot();
                                                            Marker marker = new ValueMarker(0.0); // Changed from abstract Marker to concrete ValueMarker
                                                            int index = 0;
                                                            
                                                            // Create and populate foregroundRangeMarkers map
                                                            Map<Integer, ArrayList<Marker>> foregroundRangeMarkers = new HashMap<>();
                                                            ArrayList<Marker> markers = new ArrayList<>();
                                                            markers.add(marker);
                                                            foregroundRangeMarkers.put(index, markers);
                                                            
                                                            // Use reflection to set the private field
                                                            try {
                                                                java.lang.reflect.Field field = CategoryPlot.class.getDeclaredField("foregroundRangeMarkers");
                                                                field.setAccessible(true);
                                                                field.set(plot, foregroundRangeMarkers);
                                                            } catch (Exception e) {
                                                                fail("Failed to set foregroundRangeMarkers field via reflection");
                                                            }
                                                            
                                                            boolean result = plot.removeRangeMarker(index, marker, Layer.FOREGROUND, true);
                                                            
                                                            assertTrue(result);
                                                            assertFalse(foregroundRangeMarkers.get(index).contains(marker));
                                                        }

    @Test
                                                    public void testRemoveRangeMarkerFromForegroundLayer1() {
                                                        // Create test objects
                                                        CategoryPlot plot = new CategoryPlot();
                                                        Marker marker = new ValueMarker(0.0); // Changed from abstract Marker to concrete ValueMarker
                                                        int index = 0;
                                                        
                                                        // Create and populate foregroundRangeMarkers map
                                                        Map<Integer, ArrayList<Marker>> foregroundRangeMarkers = new HashMap<>();
                                                        ArrayList<Marker> markers = new ArrayList<>();
                                                        markers.add(marker);
                                                        foregroundRangeMarkers.put(index, markers);
                                                        
                                                        // Use reflection to set the private field
                                                        try {
                                                            java.lang.reflect.Field field = CategoryPlot.class.getDeclaredField("foregroundRangeMarkers");
                                                            field.setAccessible(true);
                                                            field.set(plot, foregroundRangeMarkers);
                                                        } catch (Exception e) {
                                                            fail("Failed to set foregroundRangeMarkers field via reflection");
                                                        }
                                                        
                                                        boolean result = plot.removeRangeMarker(index, marker, Layer.FOREGROUND, true);
                                                        
                                                        assertTrue(result);
                                                        assertFalse(foregroundRangeMarkers.get(index).contains(marker));
                                                    }

    @Test
                                                public void testRemoveRangeMarkerWithoutNotification() {
                                                    // Create test objects
                                                    CategoryPlot plot = new CategoryPlot();
                                                    Marker marker = new ValueMarker(1.0);
                                                    int index = 0;
                                                    
                                                    // Set up test data using reflection
                                                    try {
                                                        java.lang.reflect.Field fgField = CategoryPlot.class.getDeclaredField("foregroundRangeMarkers");
                                                        fgField.setAccessible(true);
                                                        HashMap<Integer, ArrayList<Marker>> foregroundRangeMarkers = new HashMap<>();
                                                        ArrayList<Marker> markers = new ArrayList<>();
                                                        markers.add(marker);
                                                        foregroundRangeMarkers.put(index, markers);
                                                        fgField.set(plot, foregroundRangeMarkers);
                                                    } catch (Exception e) {
                                                        fail("Failed to set up test using reflection");
                                                    }
                                                    
                                                    // Mock the plot to verify fireChangeEvent is not called
                                                    CategoryPlot spyPlot = spy(plot);
                                                    
                                                    boolean result = spyPlot.removeRangeMarker(index, marker, Layer.FOREGROUND, false);
                                                    
                                                    assertTrue(result);
                                                }

    @Test
                                                public void testClearRangeMarkersWithNullBackgroundMarkers() {
                                                    // Create mock objects
                                                    CategoryPlot categoryPlot = spy(new CategoryPlot());
                                                    Map<Integer, Collection<Marker>> foregroundMarkers = new HashMap<Integer, Collection<Marker>>();
                                                    Collection<Marker> markerCollection = new ArrayList<Marker>();
                                                    foregroundMarkers.put(0, markerCollection);
                                                    
                                                    // Set foreground markers
                                                    try {
                                                        Field fgField = CategoryPlot.class.getDeclaredField("foregroundRangeMarkers");
                                                        fgField.setAccessible(true);
                                                        fgField.set(categoryPlot, foregroundMarkers);
                                                        
                                                        // Set background markers to null
                                                        Field bgField = CategoryPlot.class.getDeclaredField("backgroundRangeMarkers");
                                                        bgField.setAccessible(true);
                                                        bgField.set(categoryPlot, null);
                                                    } catch (Exception e) {
                                                        fail("Failed to set up test: " + e.getMessage());
                                                    }
                                                    
                                                    // Should not throw exception
                                                    categoryPlot.clearRangeMarkers(0);
                                                    
                                                    // Verify foreground markers were still cleared
                                                    try {
                                                        Field fgField = CategoryPlot.class.getDeclaredField("foregroundRangeMarkers");
                                                        fgField.setAccessible(true);
                                                        Map<Integer, Collection<Marker>> fgMarkers = 
                                                            (Map<Integer, Collection<Marker>>) fgField.get(categoryPlot);
                                                        
                                                        if (fgMarkers != null) {
                                                            Collection<Marker> markers = fgMarkers.get(0);
                                                            if (markers != null) {
                                                                assertTrue(markers.isEmpty());
                                                            }
                                                        }
                                                    } catch (Exception e) {
                                                        fail("Failed to verify test: " + e.getMessage());
                                                    }
                                                }

    @Test
                                                public void testClearRangeMarkersWithNullMarkersInCollection() {
                                                    // Create mocks
                                                    CategoryPlot categoryPlot = mock(CategoryPlot.class);
                                                    Collection<Marker> mockMarkers = mock(Collection.class);
                                                    Iterator<Marker> mockIterator = mock(Iterator.class);
                                                    
                                                    // Set up mock behavior
                                                    when(mockMarkers.iterator()).thenReturn(mockIterator);
                                                    when(mockIterator.hasNext()).thenReturn(true, false);
                                                    when(mockIterator.next()).thenReturn(null);
                                                    
                                                    // Call the method
                                                    categoryPlot.clearRangeMarkers(0);
                                                    
                                                    // Verify interactions
                                                    verify(mockIterator).hasNext();
                                                    verify(mockIterator).next();
                                                    verify(mockMarkers).clear();
                                                    // Should not try to remove change listener from null marker
                                                    verify(mockMarkers, never()).remove(any());
                                                }

    @Test
                                                public void testRemoveRangeMarkerWithNotification() {
                                                    // Create test objects
                                                    CategoryPlot plot = new CategoryPlot();
                                                    Marker marker = new ValueMarker(1.0);
                                                    int index = 0;
                                                    
                                                    // Use reflection to access private field
                                                    try {
                                                        java.lang.reflect.Field fgField = CategoryPlot.class.getDeclaredField("foregroundRangeMarkers");
                                                        fgField.setAccessible(true);
                                                        HashMap<Integer, ArrayList<Marker>> foregroundRangeMarkers = new HashMap<>();
                                                        fgField.set(plot, foregroundRangeMarkers);
                                                        
                                                        ArrayList<Marker> markers = new ArrayList<>();
                                                        markers.add(marker);
                                                        foregroundRangeMarkers.put(index, markers);
                                                        
                                                        // Mock the plot to verify fireChangeEvent is called
                                                        CategoryPlot spyPlot = spy(plot);
                                                        
                                                        boolean result = spyPlot.removeRangeMarker(index, marker, Layer.FOREGROUND, true);
                                                        
                                                        assertTrue(result);
                                                    } catch (Exception e) {
                                                        fail("Reflection failed: " + e.getMessage());
                                                    }
                                                }

    @Test
                                                public void testRemoveRangeMarkerWithoutNotification1() {
                                                    // Create test objects
                                                    CategoryPlot plot = new CategoryPlot();
                                                    Marker marker = new ValueMarker(1.0);
                                                    int index = 0;
                                                    
                                                    // Set up test data using reflection
                                                    try {
                                                        java.lang.reflect.Field fgField = CategoryPlot.class.getDeclaredField("foregroundRangeMarkers");
                                                        fgField.setAccessible(true);
                                                        HashMap<Integer, ArrayList<Marker>> foregroundRangeMarkers = new HashMap<>();
                                                        ArrayList<Marker> markers = new ArrayList<>();
                                                        markers.add(marker);
                                                        foregroundRangeMarkers.put(index, markers);
                                                        fgField.set(plot, foregroundRangeMarkers);
                                                    } catch (Exception e) {
                                                        fail("Failed to set up test using reflection");
                                                    }
                                                    
                                                    // Mock the plot to verify fireChangeEvent is not called
                                                    CategoryPlot spyPlot = spy(plot);
                                                    
                                                    boolean result = spyPlot.removeRangeMarker(index, marker, Layer.FOREGROUND, false);
                                                    
                                                    assertTrue(result);
                                                }

    @Test
                                                public void testRemoveDomainMarkerWithDifferentTypes() {
                                                    CategoryPlot plot = new CategoryPlot();
                                                    CategoryMarker marker = new CategoryMarker("Category 1");
                                                    CategoryMarker anotherMarker = new CategoryMarker("Category 2");
                                                    
                                                    plot.addDomainMarker(marker, Layer.FOREGROUND);
                                                    assertFalse(plot.removeDomainMarker(anotherMarker, Layer.FOREGROUND));
                                                }

    @Test
                                                public void testClearRangeMarkersFiresChangeEvent() {
                                                    // Create mocks
                                                    CategoryPlot categoryPlot = mock(CategoryPlot.class);
                                                    Map<Integer, Object> backgroundRangeMarkers = mock(Map.class);
                                                    Map<Integer, Object> foregroundRangeMarkers = mock(Map.class);
                                                    Set<Integer> keys = mock(Set.class);
                                                    Iterator<Integer> iterator = mock(Iterator.class);
                                                    
                                                    // Setup mocks
                                                    when(backgroundRangeMarkers.keySet()).thenReturn(keys);
                                                    when(foregroundRangeMarkers.keySet()).thenReturn(keys);
                                                    when(keys.iterator()).thenReturn(iterator);
                                                    when(iterator.hasNext()).thenReturn(false);
                                                    
                                                    // Call the method under test
                                                    categoryPlot.clearRangeMarkers();
                                                    
                                                    // Verify behavior
                                                    verify(backgroundRangeMarkers).clear();
                                                    verify(foregroundRangeMarkers).clear();
                                                }

    @Test
                                        public void testRemoveDomainMarkerFromForegroundLayer1() {
                                            // Setup
                                            int index = 0;
                                            Marker marker = new ValueMarker(1.0); // Using concrete subclass instead of abstract Marker
                                            Layer layer = Layer.FOREGROUND;
                                            Map<Integer, ArrayList<Marker>> foregroundMarkers = new HashMap<>();
                                            CategoryPlot plot = new CategoryPlot();
                                            
                                            ArrayList<Marker> markers = new ArrayList<>();
                                            markers.add(marker);
                                            foregroundMarkers.put(index, markers);
                                            
                                            // Use reflection to set the foregroundMarkers field
                                            try {
                                                java.lang.reflect.Field field = CategoryPlot.class.getDeclaredField("foregroundDomainMarkers");
                                                field.setAccessible(true);
                                                field.set(plot, foregroundMarkers);
                                            } catch (Exception e) {
                                                fail("Failed to set foregroundMarkers field via reflection");
                                            }
                                            
                                            // Test
                                            boolean result = plot.removeDomainMarker(index, marker, layer, true);
                                            
                                            // Verify
                                            assertTrue(result);
                                            assertTrue(foregroundMarkers.get(index).isEmpty());
                                        }

    @Test
                                        public void testRemoveDomainMarkerFromForegroundLayer2() {
                                            // Setup
                                            int index = 0;
                                            Marker marker = new ValueMarker(1.0); // Using concrete subclass instead of abstract Marker
                                            Layer layer = Layer.FOREGROUND;
                                            Map<Integer, ArrayList<Marker>> foregroundMarkers = new HashMap<>();
                                            CategoryPlot plot = new CategoryPlot();
                                            
                                            ArrayList<Marker> markers = new ArrayList<>();
                                            markers.add(marker);
                                            foregroundMarkers.put(index, markers);
                                            
                                            // Use reflection to set the foregroundMarkers field
                                            try {
                                                java.lang.reflect.Field field = CategoryPlot.class.getDeclaredField("foregroundDomainMarkers");
                                                field.setAccessible(true);
                                                field.set(plot, foregroundMarkers);
                                            } catch (Exception e) {
                                                fail("Failed to set foregroundMarkers field via reflection");
                                            }
                                            
                                            // Test
                                            boolean result = plot.removeDomainMarker(index, marker, layer, true);
                                            
                                            // Verify
                                            assertTrue(result);
                                            assertTrue(foregroundMarkers.get(index).isEmpty());
                                        }

    @Test
                                    public void testRemoveDomainMarkerFromForegroundLayer3() {
                                        // Setup
                                        int index = 0;
                                        Marker marker = new ValueMarker(1.0); // Using concrete subclass instead of abstract Marker
                                        Layer layer = Layer.FOREGROUND;
                                        Map<Integer, ArrayList<Marker>> foregroundMarkers = new HashMap<>();
                                        CategoryPlot plot = new CategoryPlot();
                                        
                                        ArrayList<Marker> markers = new ArrayList<>();
                                        markers.add(marker);
                                        foregroundMarkers.put(index, markers);
                                        
                                        // Use reflection to set the foregroundMarkers field
                                        try {
                                            java.lang.reflect.Field field = CategoryPlot.class.getDeclaredField("foregroundDomainMarkers");
                                            field.setAccessible(true);
                                            field.set(plot, foregroundMarkers);
                                        } catch (Exception e) {
                                            fail("Failed to set foregroundMarkers field via reflection");
                                        }
                                        
                                        // Test
                                        boolean result = plot.removeDomainMarker(index, marker, layer, true);
                                        
                                        // Verify
                                        assertTrue(result);
                                        assertTrue(foregroundMarkers.get(index).isEmpty());
                                    }

    @Test
        public void testRemoveMarkerWithoutNotification1() {
            // Setup
            CategoryPlot plot = new CategoryPlot();
            
            int index = 0;
            Layer layer = Layer.FOREGROUND;
            Marker marker = mock(Marker.class);
            
            // Add marker
            Map<Integer, ArrayList<Marker>> foregroundMarkers = new HashMap<Integer, ArrayList<Marker>>();
            ArrayList<Marker> markers = new ArrayList<Marker>();
            markers.add(marker);
            foregroundMarkers.put(index, markers);
            
            // Use reflection to set the foregroundMarkers field
            try {
                java.lang.reflect.Field field = CategoryPlot.class.getDeclaredField("foregroundDomainMarkers");
                field.setAccessible(true);
                field.set(plot, foregroundMarkers);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            
            // Test
            plot.removeDomainMarker(index, marker, layer, false);
            
            // Verify listener was not notified
        }

    @Test
        public void testRemoveMarkerWithoutNotification2() {
            // Setup
            CategoryPlot plot = new CategoryPlot();
            
            int index = 0;
            Layer layer = Layer.FOREGROUND;
            Marker marker = mock(Marker.class);
            
            // Add marker
            Map<Integer, ArrayList<Marker>> foregroundMarkers = new HashMap<Integer, ArrayList<Marker>>();
            ArrayList<Marker> markers = new ArrayList<Marker>();
            markers.add(marker);
            foregroundMarkers.put(index, markers);
            
            // Use reflection to set the foregroundMarkers field
            try {
                java.lang.reflect.Field field = CategoryPlot.class.getDeclaredField("foregroundDomainMarkers");
                field.setAccessible(true);
                field.set(plot, foregroundMarkers);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            
            // Test
            plot.removeDomainMarker(index, marker, layer, false);
            
            // Verify listener was not notified
        }

    @Test
        public void testRemoveRangeMarkerTriggersChangeEvent() {
            // Create test objects
            CategoryPlot plot = new CategoryPlot();
            Marker marker = mock(Marker.class);
            
            // Mock a PlotChangeListener
            
            // Add then remove marker
            plot.addRangeMarker(marker, Layer.FOREGROUND);
            plot.removeRangeMarker(marker, Layer.FOREGROUND);
            
            // Verify change event was triggered
        }

    @Test
        public void testRemoveMarkerWithNotification1() {
            // Setup
            CategoryPlot plot = new CategoryPlot();
            
            int index = 0;
            Marker marker = new ValueMarker(1.0);
            Layer layer = Layer.FOREGROUND;
            
            // Add marker
            plot.addRangeMarker(index, marker, layer, false);
            
            // Test removal with notification
            boolean result = plot.removeRangeMarker(index, marker, layer, true);
            
            // Verify
            assertTrue(result);
        }

    @Test
        public void testSetRangeCrosshairValueWithNotification() {
            // Create a new CategoryPlot instance
            CategoryPlot plot = new CategoryPlot();
            
            // Create a mock PlotChangeListener
            
            // Test with notification (default behavior)
            plot.setRangeCrosshairValue(10.0, true);
            assertEquals(10.0, plot.getRangeCrosshairValue(), 0.0001);
            
            // Test without notification
            plot.setRangeCrosshairValue(20.0, false);
            assertEquals(20.0, plot.getRangeCrosshairValue(), 0.0001);
        }

    @Test
        public void testSetRangeCrosshairValueWhenVisible() {
            // Create a new CategoryPlot instance
            CategoryPlot plot = new CategoryPlot();
            
            // Make crosshair visible
            plot.setRangeCrosshairVisible(true);
            
            // Create a mock PlotChangeListener
            
            // Test setting value when visible
            plot.setRangeCrosshairValue(15.0);
            assertEquals(15.0, plot.getRangeCrosshairValue(), 0.0001);
        }

    @Test
        public void testSetRangeCrosshairValueWhenNotVisible() {
            // Create a new CategoryPlot instance
            CategoryPlot plot = new CategoryPlot();
            
            // Make crosshair not visible
            plot.setRangeCrosshairVisible(false);
            
            // Create a mock PlotChangeListener
            
            // Test setting value when not visible with notification
            plot.setRangeCrosshairValue(25.0, true);
            assertEquals(25.0, plot.getRangeCrosshairValue(), 0.0001);
            
            // Test setting value when not visible without notification
            plot.setRangeCrosshairValue(30.0, false);
            assertEquals(30.0, plot.getRangeCrosshairValue(), 0.0001);
        }

    @Test
        public void testSetRangeCrosshairValueWithNotify() {
            // Create test objects
            CategoryPlot plot = new CategoryPlot();
            
            // Test setting value with notify when crosshair is visible
            plot.setRangeCrosshairVisible(true);
            plot.setRangeCrosshairValue(5.0, true);
            
            assertEquals(5.0, plot.getRangeCrosshairValue(), 0.0001);
        }

    @Test
        public void testSetRangeCrosshairValueWithoutNotify() {
            // Create test objects
            CategoryPlot plot = new CategoryPlot();
            
            // Test setting value with notify=false when crosshair is visible
            plot.setRangeCrosshairVisible(true);
            plot.setRangeCrosshairValue(3.0, false);
            
            assertEquals(3.0, plot.getRangeCrosshairValue(), 0.0001);
        }

    @Test
        public void testSetRangeCrosshairValueWhenInvisible() {
            // Create test objects
            CategoryPlot plot = new CategoryPlot();
            
            // Test setting value when crosshair is not visible
            plot.setRangeCrosshairVisible(false);
            plot.setRangeCrosshairValue(7.0, true);
            
            assertEquals(7.0, plot.getRangeCrosshairValue(), 0.0001);
        }

    @Test
        public void testSetRangeCrosshairValueSameValue() {
            // Create test objects
            CategoryPlot plot = new CategoryPlot();
            
            // Test setting same value doesn't trigger change event
            plot.setRangeCrosshairVisible(true);
            plot.setRangeCrosshairValue(10.0, true);
            
            // Reset mock to clear previous interactions
            
            plot.setRangeCrosshairValue(10.0, true);
            
            assertEquals(10.0, plot.getRangeCrosshairValue(), 0.0001);
        }

    @Test
        public void testSetRangeCrosshairValueNegative() {
            // Create test objects
            CategoryPlot plot = new CategoryPlot();
            
            // Test setting negative value
            plot.setRangeCrosshairVisible(true);
            plot.setRangeCrosshairValue(-2.5, true);
            
            assertEquals(-2.5, plot.getRangeCrosshairValue(), 0.0001);
        }

    @Test
        public void testSetRangeCrosshairValueZero() {
            // Create test objects
            CategoryPlot plot = new CategoryPlot(null, null, null, null);
            
            // Test setting zero value
            plot.setRangeCrosshairVisible(true);
            plot.setRangeCrosshairValue(0.0, true);
            
            assertEquals(0.0, plot.getRangeCrosshairValue(), 0.0001);
        }

    @Test
        public void testSetRangeCrosshairValueLargeNumber() {
            // Create test objects
            CategoryPlot plot = new CategoryPlot();
            
            // Test setting very large value
            plot.setRangeCrosshairVisible(true);
            plot.setRangeCrosshairValue(Double.MAX_VALUE, true);
            
            assertEquals(Double.MAX_VALUE, plot.getRangeCrosshairValue(), 0.0001);
        }

    @Test
        public void testSetRangeCrosshairValueNaN() {
            // Create test objects
            CategoryPlot plot = new CategoryPlot();
            
            // Test setting NaN value
            plot.setRangeCrosshairVisible(true);
            plot.setRangeCrosshairValue(Double.NaN, true);
            
            assertTrue(Double.isNaN(plot.getRangeCrosshairValue()));
        }

    @Test
        public void testSetRangeCrosshairValueInfinity() {
            // Create test objects
            CategoryPlot plot = new CategoryPlot();
            
            // Test setting infinity value
            plot.setRangeCrosshairVisible(true);
            plot.setRangeCrosshairValue(Double.POSITIVE_INFINITY, true);
            
            assertEquals(Double.POSITIVE_INFINITY, plot.getRangeCrosshairValue(), 0.0001);
        }

    @Test
        public void testSetRangeCrosshairValueMultipleChanges() {
            // Create test objects
            CategoryPlot plot = new CategoryPlot();
            
            // Test multiple changes with different notify settings
            plot.setRangeCrosshairVisible(true);
            
            // First change with notify
            plot.setRangeCrosshairValue(1.0, true);
            assertEquals(1.0, plot.getRangeCrosshairValue(), 0.0001);
            
            // Second change without notify
            plot.setRangeCrosshairValue(2.0, false);
            assertEquals(2.0, plot.getRangeCrosshairValue(), 0.0001);
            
            // Third change with notify
            plot.setRangeCrosshairValue(3.0, true);
            assertEquals(3.0, plot.getRangeCrosshairValue(), 0.0001);
            
            // Verify total notifications (should be 2 - first and third changes)
        }

    @Test
        public void testRemoveMarkerNotifiesListeners() {
            // Setup
            CategoryPlot plot = new CategoryPlot();
            
            int index = 0;
            Layer layer = Layer.FOREGROUND;
            Marker marker = new ValueMarker(1.0);
            
            // Add marker
            Collection<Marker> markers = new ArrayList<Marker>();
            markers.add(marker);
            
            // Use reflection to access private field
            try {
                java.lang.reflect.Field field = CategoryPlot.class.getDeclaredField("foregroundDomainMarkers");
                field.setAccessible(true);
                Map<Integer, Collection<Marker>> foregroundMarkers = 
                    (Map<Integer, Collection<Marker>>) field.get(plot);
                if (foregroundMarkers == null) {
                    foregroundMarkers = new HashMap<Integer, Collection<Marker>>();
                    field.set(plot, foregroundMarkers);
                }
                foregroundMarkers.put(index, markers);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            
            // Test
            plot.removeDomainMarker(index, marker, layer);
            
            // Verify listener was notified
        }

    @Test
        public void testRemoveMarkerWithoutNotification() {
            // Setup
            CategoryPlot plot = new CategoryPlot();
            
            int index = 0;
            Layer layer = Layer.FOREGROUND;
            Marker marker = mock(Marker.class);
            
            // Add marker
            Map<Integer, ArrayList<Marker>> foregroundMarkers = new HashMap<Integer, ArrayList<Marker>>();
            ArrayList<Marker> markers = new ArrayList<Marker>();
            markers.add(marker);
            foregroundMarkers.put(index, markers);
            
            // Use reflection to set the foregroundMarkers field
            try {
                java.lang.reflect.Field field = CategoryPlot.class.getDeclaredField("foregroundDomainMarkers");
                field.setAccessible(true);
                field.set(plot, foregroundMarkers);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            
            // Test
            plot.removeDomainMarker(index, marker, layer, false);
            
            // Verify listener was not notified
        }

    @Test
        public void testRemoveDomainMarkerWithNotification() {
            // Setup
            int index = 0;
            Layer layer = Layer.FOREGROUND;
            Marker marker = new ValueMarker(1.0); // Using concrete implementation instead of mock
            ArrayList<Marker> markers = new ArrayList<>();
            markers.add(marker);
            
            // Create mock listener
            CategoryPlot plot = new CategoryPlot();
            
            try {
                java.lang.reflect.Field foregroundMarkersField = CategoryPlot.class.getDeclaredField("foregroundDomainMarkers");
                foregroundMarkersField.setAccessible(true);
                @SuppressWarnings("unchecked")
                java.util.Map<Integer, java.util.ArrayList<Marker>> foregroundMarkers = 
                    (java.util.Map<Integer, java.util.ArrayList<Marker>>) foregroundMarkersField.get(plot);
                if (foregroundMarkers == null) {
                    foregroundMarkers = new HashMap<>();
                    foregroundMarkersField.set(plot, foregroundMarkers);
                }
                foregroundMarkers.put(index, markers);
            } catch (Exception e) {
                fail("Failed to set up test due to reflection error: " + e.getMessage());
            }
            
            // Test
            boolean result = plot.removeDomainMarker(index, marker, layer, true);
            
            // Verify
            assertTrue(result);
        }

    @Test
        public void testRemoveDomainMarkerWithoutNotification() {
            // Setup
            int index = 0;
            Layer layer = Layer.FOREGROUND;
            Marker marker = mock(Marker.class);
            CategoryPlot plot = new CategoryPlot();
            
            // Use reflection to access private field
            try {
                java.lang.reflect.Field foregroundMarkersField = CategoryPlot.class.getDeclaredField("foregroundDomainMarkers");
                foregroundMarkersField.setAccessible(true);
                @SuppressWarnings("unchecked")
                java.util.Map<Integer, java.util.List<Marker>> foregroundMarkers = 
                    (java.util.Map<Integer, java.util.List<Marker>>) foregroundMarkersField.get(plot);
                
                if (foregroundMarkers == null) {
                    foregroundMarkers = new java.util.HashMap<Integer, java.util.List<Marker>>();
                    foregroundMarkersField.set(plot, foregroundMarkers);
                }
                
                java.util.List<Marker> markers = new java.util.ArrayList<Marker>();
                markers.add(marker);
                foregroundMarkers.put(index, markers);
                
                // Test
                boolean result = plot.removeDomainMarker(index, marker, layer, false);
                
                // Verify
                assertTrue(result);
            } catch (Exception e) {
                fail("Failed to access private field: " + e.getMessage());
            }
        }

    @Test
        public void testClearRangeMarkersWithNonEmptyMaps() {
            // Create mocks
            CategoryPlot categoryPlot = mock(CategoryPlot.class);
            Map<Integer, Collection<Marker>> backgroundRangeMarkers = new HashMap<>();
            Map<Integer, Collection<Marker>> foregroundRangeMarkers = new HashMap<>();
            Collection<Marker> markers = new ArrayList<>();
            
            // Add test data
            Marker mockMarker = mock(Marker.class);
            markers.add(mockMarker); // Add a mock marker to the collection
            backgroundRangeMarkers.put(0, markers);
            foregroundRangeMarkers.put(0, new ArrayList<>(markers)); // Create a new copy
            
            // Set up mock behavior
            
            // Call the method under test
            categoryPlot.clearRangeMarkers();
            
            // Verify interactions
            assertTrue(backgroundRangeMarkers.isEmpty());
            assertTrue(foregroundRangeMarkers.isEmpty());
        }

    @Test
        public void testClearRangeMarkersCallsClearRangeMarkersForEachKey() {
            // Create mocks and test data
            CategoryPlot categoryPlot = spy(new CategoryPlot());
            Set<Integer> backgroundRangeMarkers = mock(Set.class);
            Set<Integer> foregroundRangeMarkers = mock(Set.class);
            
            // Set up mock behavior
            
            // Simulate two keys in the map
            
            // Use reflection to set private fields
            try {
                Field bgField = CategoryPlot.class.getDeclaredField("backgroundRangeMarkers");
                bgField.setAccessible(true);
                bgField.set(categoryPlot, backgroundRangeMarkers);
                
                Field fgField = CategoryPlot.class.getDeclaredField("foregroundRangeMarkers");
                fgField.setAccessible(true);
                fgField.set(categoryPlot, foregroundRangeMarkers);
            } catch (Exception e) {
                org.junit.Assert.fail("Failed to set up test due to reflection error: " + e.getMessage());
            }
            
            categoryPlot.clearRangeMarkers();
            
            // Verify clearRangeMarkers was called for each key
            verify(categoryPlot, times(2)).clearRangeMarkers(anyInt());
            verify(backgroundRangeMarkers).clear();
            verify(foregroundRangeMarkers).clear();
        }

    @Test
        public void testRemoveDomainMarkerWithNotification1() {
            // Setup
            CategoryPlot plot = new CategoryPlot();
            int index = 0;
            Layer layer = Layer.FOREGROUND;
            Marker marker = mock(Marker.class);
            ArrayList<Marker> markers = new ArrayList<>();
            markers.add(marker);
            
            // Define and add mock listener
            
            // Use reflection to set foregroundMarkers
            try {
                java.lang.reflect.Field foregroundMarkersField = CategoryPlot.class.getDeclaredField("foregroundDomainMarkers");
                foregroundMarkersField.setAccessible(true);
                Map<Integer, ArrayList<Marker>> foregroundMarkers = new HashMap<>();
                foregroundMarkers.put(index, markers);
                foregroundMarkersField.set(plot, foregroundMarkers);
            } catch (Exception e) {
                fail("Failed to set foregroundMarkers via reflection");
            }
            
            // Test
            boolean result = plot.removeDomainMarker(index, marker, layer, true);
            
            // Verify
            assertTrue(result);
        }

    @Test
        public void testRemoveDomainMarkerWithoutNotification1() {
            // Setup
            int index = 0;
            Layer layer = Layer.FOREGROUND;
            Marker marker = mock(Marker.class);
            ArrayList<Marker> markers = new ArrayList<>();
            markers.add(marker);
            
            Map<Integer, Map<Layer, List<Marker>>> foregroundMarkers = new HashMap<>();
            Map<Layer, List<Marker>> layerMap = new HashMap<>();
            layerMap.put(layer, markers);
            foregroundMarkers.put(index, layerMap);
            
            CategoryPlot plot = new CategoryPlot();
            try {
                java.lang.reflect.Field field = CategoryPlot.class.getDeclaredField("foregroundDomainMarkers");
                field.setAccessible(true);
                field.set(plot, foregroundMarkers);
            } catch (Exception e) {
                fail("Failed to set foregroundDomainMarkers via reflection");
            }
            
            // Mock a listener to verify no notification
            
            // Test
            boolean result = plot.removeDomainMarker(index, marker, layer, false);
            
            // Verify
            assertTrue(result);
        }


}
