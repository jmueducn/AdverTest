package gentest.org.jfree.chart.plot.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.plot.*;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import org.jfree.chart.LegendItem;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.annotations.CategoryAnnotation;
import org.jfree.chart.axis.Axis;
import org.jfree.chart.axis.AxisCollection;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.AxisSpace;
import org.jfree.chart.axis.AxisState;
import org.jfree.chart.axis.CategoryAnchor;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.axis.ValueTick;
import org.jfree.chart.event.ChartChangeEventType;
import org.jfree.chart.event.PlotChangeEvent;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.event.RendererChangeListener;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.util.Layer;
import org.jfree.chart.util.ObjectList;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.chart.util.PaintUtilities;
import org.jfree.chart.util.PublicCloneable;
import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.RectangleInsets;
import org.jfree.chart.util.SerialUtilities;
import org.jfree.chart.util.SortOrder;
import org.jfree.data.Range;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.general.Dataset;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.general.DatasetUtilities;
 
public class CategoryPlotTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
            public void testGetDomainAxisIndexWithNonExistingAxis() {
                CategoryPlot plot = new CategoryPlot();
                CategoryAxis axis1 = new CategoryAxis("Axis 1");
                CategoryAxis axis2 = new CategoryAxis("Axis 2");
                CategoryAxis axis3 = new CategoryAxis("Axis 3");
                
                plot.setDomainAxis(0, axis1);
                plot.setDomainAxis(1, axis2);
                
                assertEquals(-1, plot.getDomainAxisIndex(axis3));
            }

    @Test(expected = IllegalArgumentException.class)
            public void testGetDomainAxisIndexWithNullAxis1() {
                CategoryPlot plot = new CategoryPlot();
                plot.getDomainAxisIndex(null);
            }

    @Test
            public void testGetDomainAxisIndexAfterAxisRemoval() {
                CategoryPlot plot = new CategoryPlot();
                CategoryAxis axis1 = new CategoryAxis("Axis 1");
                CategoryAxis axis2 = new CategoryAxis("Axis 2");
                
                plot.setDomainAxis(0, axis1);
                plot.setDomainAxis(1, axis2);
                plot.setDomainAxis(1, null);
                assertEquals(-1, plot.getDomainAxisIndex(axis2));
            }

    @Test
            public void testGetDomainAxisIndexWithMultipleAxes() {
                CategoryPlot plot = new CategoryPlot();
                CategoryAxis axis1 = mock(CategoryAxis.class);
                CategoryAxis axis2 = mock(CategoryAxis.class);
                CategoryAxis axis3 = mock(CategoryAxis.class);
                CategoryAxis axis4 = mock(CategoryAxis.class);
                
                plot.setDomainAxis(0, axis1);
                plot.setDomainAxis(1, axis2);
                plot.setDomainAxis(2, axis3);
                plot.setDomainAxis(3, axis4);
                
                assertEquals(3, plot.getDomainAxisIndex(axis4));
            }

    @Test
            public void testGetDomainAxisIndexConsistency() {
                // Create test objects
                CategoryPlot plot = new CategoryPlot();
                CategoryAxis axis1 = new CategoryAxis("Axis 1");
                CategoryAxis axis2 = new CategoryAxis("Axis 2");
                CategoryAxis axis3 = new CategoryAxis("Axis 3");
                
                // Add initial axes
                plot.setDomainAxis(0, axis1);
                plot.setDomainAxis(1, axis2);
                
                // Test that index remains consistent after modifications
                plot.setDomainAxis(2, axis3);
                assertEquals(2, plot.getDomainAxisIndex(axis3));
                
                plot.setDomainAxis(1, null);
                assertEquals(-1, plot.getDomainAxisIndex(axis2));
                assertEquals(2, plot.getDomainAxisIndex(axis3));
            }

    @Test(expected = IllegalArgumentException.class)
            public void testGetRangeAxisIndexWithNullAxis() {
                CategoryPlot categoryPlot = new CategoryPlot();
                categoryPlot.getRangeAxisIndex(null);
            }

    @Test
            public void testGetRangeAxisIndexWithExistingAxis() {
                CategoryPlot categoryPlot = new CategoryPlot();
                ValueAxis axis1 = mock(ValueAxis.class);
                categoryPlot.setRangeAxis(0, axis1);
                
                int index = categoryPlot.getRangeAxisIndex(axis1);
                assertEquals(0, index);
            }

    @Test
            public void testGetRangeAxisIndexWithNonExistingAxis() {
                CategoryPlot categoryPlot = new CategoryPlot();
                ValueAxis axis2 = mock(ValueAxis.class);
                int index = categoryPlot.getRangeAxisIndex(axis2);
                assertEquals(-1, index);
            }

    @Test
            public void testGetRangeAxisIndexWithParentPlot() {
                // Setup mocks and test objects
                CategoryPlot categoryPlot = mock(CategoryPlot.class);
                CategoryPlot parentPlot = mock(CategoryPlot.class);
                ValueAxis axis2 = mock(ValueAxis.class);
                
                // Setup parent plot scenario
                when(categoryPlot.getParent()).thenReturn(parentPlot);
                when(parentPlot.getRangeAxisIndex(axis2)).thenReturn(1);
                when(categoryPlot.getRangeAxisIndex(axis2)).thenCallRealMethod();
                
                int index = categoryPlot.getRangeAxisIndex(axis2);
                assertEquals(1, index);
            }

    @Test
            public void testGetRangeAxisIndexWithNonCategoryPlotParent() {
                CategoryPlot categoryPlot = mock(CategoryPlot.class);
                ValueAxis axis2 = mock(ValueAxis.class);
                Plot nonCategoryParent = mock(Plot.class);
                
                when(categoryPlot.getParent()).thenReturn(nonCategoryParent);
                when(categoryPlot.getRangeAxisIndex(axis2)).thenCallRealMethod();
                
                int index = categoryPlot.getRangeAxisIndex(axis2);
                assertEquals(-1, index);
            }

    @Test(expected = IllegalArgumentException.class)
        public void testGetDomainAxisIndexWithNullAxis() {
            CategoryPlot plot = new CategoryPlot();
            plot.getDomainAxisIndex(null);
        }

    @Test
        public void testGetRangeAxisIndexWithMultipleAxes() {
            // Create test objects
            CategoryPlot categoryPlot = new CategoryPlot();
            ValueAxis axis1 = new org.jfree.chart.axis.NumberAxis("Axis 1");
            ValueAxis axis2 = new org.jfree.chart.axis.NumberAxis("Axis 2");
            
            // Add axes
            categoryPlot.setRangeAxis(0, axis1);
            categoryPlot.setRangeAxis(1, axis2);
            
            // Verify indices
            assertEquals(0, categoryPlot.getRangeAxisIndex(axis1));
            assertEquals(1, categoryPlot.getRangeAxisIndex(axis2));
        }


}
