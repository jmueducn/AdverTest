package gentest.org.jfree.chart.renderer.category.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.renderer.category.*;
import java.awt.AlphaComposite;
import java.awt.Composite;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.jfree.chart.ChartRenderingInfo;
import org.jfree.chart.LegendItem;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.RenderingSource;
import org.jfree.chart.annotations.CategoryAnnotation;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.CategoryItemEntity;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.labels.CategorySeriesLabelGenerator;
import org.jfree.chart.labels.CategoryToolTipGenerator;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.labels.StandardCategorySeriesLabelGenerator;
import org.jfree.chart.plot.CategoryCrosshairState;
import org.jfree.chart.plot.CategoryMarker;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.DrawingSupplier;
import org.jfree.chart.plot.IntervalMarker;
import org.jfree.chart.plot.Marker;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.ValueMarker;
import org.jfree.chart.renderer.AbstractRenderer;
import org.jfree.chart.text.TextUtilities;
import org.jfree.chart.urls.CategoryURLGenerator;
import org.jfree.chart.util.GradientPaintTransformer;
import org.jfree.chart.util.Layer;
import org.jfree.chart.util.LengthAdjustmentType;
import org.jfree.chart.util.ObjectList;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.chart.util.PublicCloneable;
import org.jfree.chart.util.RectangleAnchor;
import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.RectangleInsets;
import org.jfree.chart.util.SortOrder;
import org.jfree.data.Range;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.CategoryDatasetSelectionState;
import org.jfree.data.category.SelectableCategoryDataset;
import org.jfree.data.general.DatasetUtilities;
 
public class AbstractCategoryItemRendererTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                            public void testGetLegendItemsWithNullPlot() {
                                                AbstractCategoryItemRenderer renderer = mock(AbstractCategoryItemRenderer.class);
                                                when(renderer.getPlot()).thenReturn(null);
                                                when(renderer.getLegendItems()).thenCallRealMethod();
                                                
                                                LegendItemCollection result = renderer.getLegendItems();
                                                assertNotNull(result);
                                                assertEquals(0, result.getItemCount());
                                            }

    @Test
                                            public void testGetLegendItemsWithNullDataset() {
                                                AbstractCategoryItemRenderer renderer = mock(AbstractCategoryItemRenderer.class);
                                                CategoryPlot plot = mock(CategoryPlot.class);
                                                
                                                // Set up the renderer's plot
                                                when(renderer.getPlot()).thenReturn(plot);
                                                when(plot.getIndexOf(renderer)).thenReturn(0);
                                                when(plot.getDataset(0)).thenReturn(null);
                                                
                                                // Mock the actual method call
                                                when(renderer.getLegendItems()).thenCallRealMethod();
                                                
                                                LegendItemCollection result = renderer.getLegendItems();
                                                assertNotNull(result);
                                                assertEquals(0, result.getItemCount());
                                            }

    @Test
                                            public void testGetLegendItemsWithAscendingOrder() throws Exception {
                                                AbstractCategoryItemRenderer renderer = mock(AbstractCategoryItemRenderer.class);
                                                CategoryPlot plot = mock(CategoryPlot.class);
                                                CategoryDataset dataset = mock(CategoryDataset.class);
                                                
                                                when(renderer.getPlot()).thenReturn(plot);
                                                when(plot.getIndexOf(renderer)).thenReturn(0);
                                                when(plot.getDataset(0)).thenReturn(dataset);
                                                when(dataset.getRowCount()).thenReturn(2);
                                                when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                when(renderer.isSeriesVisibleInLegend(0)).thenReturn(true);
                                                when(renderer.isSeriesVisibleInLegend(1)).thenReturn(true);
                                                
                                                LegendItem mockItem1 = new LegendItem("Series1");
                                                LegendItem mockItem2 = new LegendItem("Series2");
                                                
                                                when(renderer.getLegendItem(0, 0)).thenReturn(mockItem1);
                                                when(renderer.getLegendItem(0, 1)).thenReturn(mockItem2);
                                                
                                                when(renderer.getLegendItems()).thenCallRealMethod();
                                                
                                                LegendItemCollection result = renderer.getLegendItems();
                                                assertNotNull(result);
                                                assertEquals(2, result.getItemCount());
                                                assertEquals(mockItem1, result.get(0));
                                                assertEquals(mockItem2, result.get(1));
                                            }

    @Test
                                            public void testGetLegendItemsWithDescendingOrder() throws Exception {
                                                AbstractCategoryItemRenderer renderer = mock(AbstractCategoryItemRenderer.class);
                                                CategoryPlot plot = mock(CategoryPlot.class);
                                                CategoryDataset dataset = mock(CategoryDataset.class);
                                                
                                                when(renderer.getPlot()).thenReturn(plot);
                                                when(plot.getDataset(anyInt())).thenReturn(dataset);
                                                when(dataset.getRowCount()).thenReturn(2);
                                                when(plot.getRowRenderingOrder()).thenReturn(SortOrder.DESCENDING);
                                                when(renderer.isSeriesVisibleInLegend(0)).thenReturn(true);
                                                when(renderer.isSeriesVisibleInLegend(1)).thenReturn(true);
                                                
                                                LegendItem mockItem1 = new LegendItem("Series1");
                                                LegendItem mockItem2 = new LegendItem("Series2");
                                                
                                                when(renderer.getLegendItem(anyInt(), eq(0))).thenReturn(mockItem1);
                                                when(renderer.getLegendItem(anyInt(), eq(1))).thenReturn(mockItem2);
                                                
                                                when(renderer.getLegendItems()).thenCallRealMethod();
                                                
                                                LegendItemCollection result = renderer.getLegendItems();
                                                assertNotNull(result);
                                                assertEquals(2, result.getItemCount());
                                                assertEquals(mockItem2, result.get(0));
                                                assertEquals(mockItem1, result.get(1));
                                            }

    @Test
                                            public void testGetLegendItemsWithSomeSeriesNotVisible() throws Exception {
                                                AbstractCategoryItemRenderer renderer = mock(AbstractCategoryItemRenderer.class);
                                                CategoryPlot plot = mock(CategoryPlot.class);
                                                CategoryDataset dataset = mock(CategoryDataset.class);
                                                
                                                when(renderer.getPlot()).thenReturn(plot);
                                                when(plot.getIndexOf(renderer)).thenReturn(0);
                                                when(plot.getDataset(0)).thenReturn(dataset);
                                                when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                when(dataset.getRowCount()).thenReturn(2);
                                                
                                                when(renderer.isSeriesVisibleInLegend(0)).thenReturn(true);
                                                when(renderer.isSeriesVisibleInLegend(1)).thenReturn(false);
                                                
                                                LegendItem mockItem = new LegendItem("Series1");
                                                when(renderer.getLegendItem(0, 0)).thenReturn(mockItem);
                                                
                                                when(renderer.getLegendItems()).thenCallRealMethod();
                                                
                                                LegendItemCollection result = renderer.getLegendItems();
                                                assertNotNull(result);
                                                assertEquals(1, result.getItemCount());
                                                assertEquals(mockItem, result.get(0));
                                            }

    @Test
                                            public void testGetLegendItemsWithNullLegendItem() throws Exception {
                                                AbstractCategoryItemRenderer renderer = mock(AbstractCategoryItemRenderer.class);
                                                CategoryPlot plot = mock(CategoryPlot.class);
                                                CategoryDataset dataset = mock(CategoryDataset.class);
                                                
                                                when(renderer.getPlot()).thenReturn(plot);
                                                when(plot.getIndexOf(renderer)).thenReturn(0);
                                                when(plot.getDataset(0)).thenReturn(dataset);
                                                when(dataset.getRowCount()).thenReturn(2);
                                                when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                
                                                when(renderer.isSeriesVisibleInLegend(0)).thenReturn(true);
                                                when(renderer.isSeriesVisibleInLegend(1)).thenReturn(true);
                                                
                                                when(renderer.getLegendItem(0, 0)).thenReturn(null);
                                                when(renderer.getLegendItem(0, 1)).thenReturn(null);
                                                
                                                LegendItemCollection result = renderer.getLegendItems();
                                                assertNotNull(result);
                                                assertEquals(0, result.getItemCount());
                                            }

    @Test
                                            public void testGetLegendItemsWithMixedVisibleAndNullItems() throws Exception {
                                                AbstractCategoryItemRenderer renderer = mock(AbstractCategoryItemRenderer.class);
                                                CategoryPlot plot = mock(CategoryPlot.class);
                                                CategoryDataset dataset = mock(CategoryDataset.class);
                                                
                                                when(renderer.getPlot()).thenReturn(plot);
                                                when(plot.getIndexOf(renderer)).thenReturn(0);
                                                when(plot.getDataset(0)).thenReturn(dataset);
                                                when(dataset.getRowCount()).thenReturn(2);
                                                when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                
                                                when(renderer.isSeriesVisibleInLegend(0)).thenReturn(true);
                                                when(renderer.isSeriesVisibleInLegend(1)).thenReturn(true);
                                                
                                                LegendItem mockItem = new LegendItem("Series2");
                                                when(renderer.getLegendItem(0, 0)).thenReturn(null);
                                                when(renderer.getLegendItem(0, 1)).thenReturn(mockItem);
                                                
                                                LegendItemCollection result = renderer.getLegendItems();
                                                assertNotNull(result);
                                                assertEquals(1, result.getItemCount());
                                                assertEquals(mockItem, result.get(0));
                                            }

    @Test
                                    public void testIsSeriesVisibleInLegend() throws Exception {
                                        AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                            @Override
                                            public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                    Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                    ValueAxis rangeAxis, CategoryDataset dataset, int row,
                                                    int column, boolean selected, int pass) {
                                                // Empty implementation
                                            }
                                        };
                                        Method method = AbstractCategoryItemRenderer.class
                                                .getDeclaredMethod("isSeriesVisibleInLegend", int.class);
                                        method.setAccessible(true);
                                        
                                        // Default implementation should return true
                                        boolean result = (boolean) method.invoke(renderer, 0);
                                        assertTrue(result);
                                    }

    @Test
        public void testGetLegendItemsWithEmptyDataset() {
            // Create mock renderer and plot
            AbstractCategoryItemRenderer renderer = mock(AbstractCategoryItemRenderer.class);
            CategoryPlot plot = mock(CategoryPlot.class);
            
            // Set up the renderer's plot
            when(renderer.getPlot()).thenReturn(plot);
            when(plot.getIndexOf(renderer)).thenReturn(0);
            
            // Create empty dataset
            
            // Mock the actual method call
            when(renderer.getLegendItems()).thenCallRealMethod();
            
            LegendItemCollection result = renderer.getLegendItems();
            assertNotNull(result);
            assertEquals(0, result.getItemCount());
        }


}
