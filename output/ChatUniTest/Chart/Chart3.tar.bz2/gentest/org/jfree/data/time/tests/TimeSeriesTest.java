package gentest.org.jfree.data.time.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.time.*;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.data.general.Series;
import org.jfree.data.event.SeriesChangeEvent;
import org.jfree.data.general.SeriesException;
 
public class TimeSeriesTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                        public void testCreateCopyEmptySeries() throws CloneNotSupportedException {
                                            TimeSeries emptySeries = new TimeSeries("Empty Series");
                                            TimeSeries copy = emptySeries.createCopy(0, 0);
                                            
                                            assertEquals(0, copy.getItemCount());
                                        }

    @Test
                                    public void testCreateCopyValidRange() throws CloneNotSupportedException {
                                        TimeSeries series = new TimeSeries("Test Series");
                                        series.add(new Year(2000), 10.0);
                                        series.add(new Year(2001), 20.0);
                                        
                                        TimeSeries copy = series.createCopy(0, 1);
                                        
                                        assertEquals(2, copy.getItemCount());
                                        assertEquals(10.0, copy.getValue(0).doubleValue(), 0.001);
                                        assertEquals(20.0, copy.getValue(1).doubleValue(), 0.001);
                                        assertEquals(Double.NaN, copy.getMinY(), 0.001);
                                        assertEquals(Double.NaN, copy.getMaxY(), 0.001);
                                    }

    @Test
                                    public void testCreateCopySingleItem() throws CloneNotSupportedException {
                                        TimeSeries series = new TimeSeries("Test Series");
                                        series.add(new Day(1, 1, 2000), 20.0);
                                        
                                        TimeSeries copy = series.createCopy(0, 0);
                                        
                                        assertEquals(1, copy.getItemCount());
                                        assertEquals(20.0, copy.getValue(0).doubleValue(), 0.001);
                                    }

    @Test
                                    public void testCreateCopyFullRange() throws CloneNotSupportedException {
                                        TimeSeries series = new TimeSeries("Test Series");
                                        series.add(new Year(2000), 10.0);
                                        series.add(new Year(2001), 20.0);
                                        series.add(new Year(2002), 30.0);
                                        
                                        TimeSeries copy = series.createCopy(0, 2);
                                        
                                        assertEquals(3, copy.getItemCount());
                                        assertEquals(10.0, copy.getValue(0).doubleValue(), 0.001);
                                        assertEquals(20.0, copy.getValue(1).doubleValue(), 0.001);
                                        assertEquals(30.0, copy.getValue(2).doubleValue(), 0.001);
                                    }

    @Test(expected = IllegalArgumentException.class)
                                    public void testCreateCopyNegativeStart() throws CloneNotSupportedException {
                                        TimeSeries series = new TimeSeries("Test Series");
                                        series.createCopy(-1, 1);
                                    }

    @Test(expected = IllegalArgumentException.class)
                                    public void testCreateCopyEndLessThanStart() throws CloneNotSupportedException {
                                        TimeSeries series = new TimeSeries("Test Series");
                                        series.add(new TimeSeriesDataItem(new org.jfree.data.time.Day(), 1.0));
                                        series.createCopy(2, 1);
                                    }

    @Test
                                    public void testCreateCopyWithSeriesException() throws CloneNotSupportedException {
                                        // Create test items
                                        Day day1 = new Day(1, 1, 2000);
                                        TimeSeriesDataItem item1 = new TimeSeriesDataItem(day1, 100.0);
                                        
                                        // Create a series that will cause SeriesException when adding duplicate items
                                        TimeSeries problematicSeries = new TimeSeries("Problematic Series");
                                        problematicSeries.add(item1);
                                        problematicSeries.add(item1); // This will cause SeriesException in createCopy
                                        
                                        // The method should catch and print the exception but continue execution
                                        TimeSeries copy = problematicSeries.createCopy(0, 1);
                                        
                                        assertEquals(1, copy.getItemCount()); // Only one item should be added successfully
                                    }

    @Test
                                    public void testCreateCopyBoundaryConditions() throws CloneNotSupportedException {
                                        // Setup test data
                                        TimeSeries series = new TimeSeries("Test Series");
                                        series.add(new TimeSeriesDataItem(new org.jfree.data.time.Day(1, 1, 2000), 1.0));
                                        series.add(new TimeSeriesDataItem(new org.jfree.data.time.Day(2, 1, 2000), 2.0));
                                        series.add(new TimeSeriesDataItem(new org.jfree.data.time.Day(3, 1, 2000), 3.0));
                                
                                        // Test with start = 0 and end = last index
                                        TimeSeries copy1 = series.createCopy(0, series.getItemCount() - 1);
                                        assertEquals(series.getItemCount(), copy1.getItemCount());
                                        
                                        // Test with start = end = 0
                                        TimeSeries copy2 = series.createCopy(0, 0);
                                        assertEquals(1, copy2.getItemCount());
                                        
                                        // Test with start = end = last index
                                        TimeSeries copy3 = series.createCopy(series.getItemCount() - 1, series.getItemCount() - 1);
                                        assertEquals(1, copy3.getItemCount());
                                    }

    @Test(expected = IllegalArgumentException.class)
                                    public void testCreateCopyWithNullStart() throws CloneNotSupportedException {
                                        TimeSeries timeSeries = new TimeSeries("Test Series");
                                        Year endPeriod = new Year(2023);
                                        timeSeries.createCopy(null, endPeriod);
                                    }

    @Test(expected = IllegalArgumentException.class)
                                    public void testCreateCopyWithNullEnd() throws CloneNotSupportedException {
                                        TimeSeries timeSeries = new TimeSeries("Test Series");
                                        Year startPeriod = new Year(2000);
                                        timeSeries.createCopy(startPeriod, null);
                                    }

    @Test
                                    public void testCreateCopyWithStartBeforeFirstItem() throws CloneNotSupportedException {
                                        TimeSeries timeSeries = new TimeSeries("Test Series");
                                        timeSeries.add(new Year(2000), 100);
                                        timeSeries.add(new Year(2001), 200);
                                        timeSeries.add(new Year(2002), 300);
                                        
                                        Year beforeStartPeriod = new Year(1999);
                                        Year endPeriod = new Year(2002);
                                        
                                        TimeSeries copy = timeSeries.createCopy(beforeStartPeriod, endPeriod);
                                        assertEquals(3, copy.getItemCount());
                                    }

    @Test
                                    public void testCreateCopyWithEndAfterLastItem() throws CloneNotSupportedException {
                                        TimeSeries timeSeries = new TimeSeries("Test Series");
                                        timeSeries.add(new Year(2000), 100);
                                        timeSeries.add(new Year(2001), 200);
                                        timeSeries.add(new Year(2002), 300);
                                        
                                        Year startPeriod = new Year(2000);
                                        Year afterEndPeriod = new Year(2003); // After last item
                                        
                                        TimeSeries copy = timeSeries.createCopy(startPeriod, afterEndPeriod);
                                        assertEquals(3, copy.getItemCount());
                                    }

    @Test
                                    public void testCreateCopyWithValidRange() throws CloneNotSupportedException {
                                        TimeSeries timeSeries = new TimeSeries("Test Series");
                                        Year startPeriod = new Year(2000);
                                        Year endPeriod = new Year(2002);
                                        
                                        timeSeries.add(new Year(2000), 1.0);
                                        timeSeries.add(new Year(2001), 2.0);
                                        timeSeries.add(new Year(2002), 3.0);
                                        
                                        TimeSeries copy = timeSeries.createCopy(startPeriod, endPeriod);
                                        assertEquals(3, copy.getItemCount());
                                        assertEquals(1.0, copy.getValue(0).doubleValue(), 0.0001);
                                        assertEquals(3.0, copy.getValue(2).doubleValue(), 0.0001);
                                    }

    @Test
                                    public void testCreateCopyWithSingleItemRange() throws CloneNotSupportedException {
                                        TimeSeries timeSeries = new TimeSeries("Test Series");
                                        Day middlePeriod = new Day(15, 1, 2023);
                                        timeSeries.add(middlePeriod, 2.0);
                                        
                                        TimeSeries copy = timeSeries.createCopy(middlePeriod, middlePeriod);
                                        assertEquals(1, copy.getItemCount());
                                        assertEquals(2.0, copy.getValue(0).doubleValue(), 0.0001);
                                    }

    @Test
                                    public void testCreateCopyWithEmptyRangeBeforeSeries() throws CloneNotSupportedException {
                                        // Setup
                                        RegularTimePeriod startPeriod = mock(RegularTimePeriod.class);
                                        TimeSeries timeSeries = new TimeSeries("Test Series");
                                        
                                        RegularTimePeriod veryEarlyPeriod = mock(RegularTimePeriod.class);
                                        when(veryEarlyPeriod.compareTo(startPeriod)).thenReturn(-1);
                                        when(startPeriod.compareTo(veryEarlyPeriod)).thenReturn(1);
                                        
                                        // Test
                                        TimeSeries copy = timeSeries.createCopy(veryEarlyPeriod, veryEarlyPeriod);
                                        
                                        // Verify
                                        assertEquals(0, copy.getItemCount());
                                    }

    @Test
                                    public void testCreateCopyWithEmptyRangeAfterSeries() throws CloneNotSupportedException {
                                        TimeSeries timeSeries = new TimeSeries("Test Series");
                                        RegularTimePeriod endPeriod = mock(RegularTimePeriod.class);
                                        RegularTimePeriod veryLatePeriod = mock(RegularTimePeriod.class);
                                        
                                        when(veryLatePeriod.compareTo(endPeriod)).thenReturn(1);
                                        when(endPeriod.compareTo(veryLatePeriod)).thenReturn(-1);
                                        
                                        TimeSeries copy = timeSeries.createCopy(veryLatePeriod, veryLatePeriod);
                                        assertEquals(0, copy.getItemCount());
                                    }

    @Test
                                    public void testCreateCopyWithPartialRange() throws CloneNotSupportedException {
                                        TimeSeries timeSeries = new TimeSeries("Test Series");
                                        Year startPeriod = new Year(2000);
                                        Year middlePeriod = new Year(2001);
                                        Year endPeriod = new Year(2002);
                                        
                                        timeSeries.add(startPeriod, 1.0);
                                        timeSeries.add(middlePeriod, 2.0);
                                        timeSeries.add(endPeriod, 3.0);
                                        
                                        TimeSeries copy = timeSeries.createCopy(startPeriod, middlePeriod);
                                        assertEquals(2, copy.getItemCount());
                                        assertEquals(1.0, copy.getValue(0).doubleValue(), 0.0001);
                                        assertEquals(2.0, copy.getValue(1).doubleValue(), 0.0001);
                                    }

    @Test
                                    public void testCreateCopyMaintainsSeriesProperties() throws CloneNotSupportedException {
                                        TimeSeries timeSeries = new TimeSeries("Test Series");
                                        Day startPeriod = new Day(1, 1, 2000);
                                        Day endPeriod = new Day(2, 1, 2000);
                                        
                                        timeSeries.add(startPeriod, 1.0);
                                        timeSeries.add(endPeriod, 2.0);
                                        
                                        timeSeries.setDomainDescription("Test Domain");
                                        timeSeries.setRangeDescription("Test Range");
                                        timeSeries.setMaximumItemCount(100);
                                        timeSeries.setMaximumItemAge(200);
                                        
                                        TimeSeries copy = timeSeries.createCopy(startPeriod, endPeriod);
                                        
                                        assertEquals("Test Domain", copy.getDomainDescription());
                                        assertEquals("Test Range", copy.getRangeDescription());
                                        assertEquals(100, copy.getMaximumItemCount());
                                        assertEquals(200, copy.getMaximumItemAge());
                                    }

    @Test
                                    public void testCreateCopyWithEmptySeries() throws CloneNotSupportedException {
                                        TimeSeries emptySeries = new TimeSeries("Empty Series");
                                        RegularTimePeriod startPeriod = new Minute(); // Assuming Minute is available
                                        RegularTimePeriod endPeriod = new Minute();   // Assuming Minute is available
                                        TimeSeries copy = emptySeries.createCopy(startPeriod, endPeriod);
                                        assertEquals(0, copy.getItemCount());
                                    }

    @Test
                                    public void testCreateCopyWithExactRange() throws CloneNotSupportedException {
                                        TimeSeries timeSeries = new TimeSeries("Test Series");
                                        Day startPeriod = new Day(1, 1, 2000);
                                        Day endPeriod = new Day(3, 1, 2000);
                                        
                                        timeSeries.add(startPeriod, 1.0);
                                        timeSeries.add(new Day(2, 1, 2000), 2.0);
                                        timeSeries.add(endPeriod, 3.0);
                                        
                                        TimeSeries copy = timeSeries.createCopy(startPeriod, endPeriod);
                                        assertEquals(3, copy.getItemCount());
                                        assertEquals(1.0, copy.getValue(0).doubleValue(), 0.0001);
                                        assertEquals(2.0, copy.getValue(1).doubleValue(), 0.0001);
                                        assertEquals(3.0, copy.getValue(2).doubleValue(), 0.0001);
                                    }

    @Test
                                    public void testCreateCopyWithStartNotInSeries() throws CloneNotSupportedException {
                                        // Setup test data
                                        TimeSeries timeSeries = new TimeSeries("Test Series");
                                        RegularTimePeriod startPeriod = mock(RegularTimePeriod.class);
                                        RegularTimePeriod middlePeriod = mock(RegularTimePeriod.class);
                                        RegularTimePeriod endPeriod = mock(RegularTimePeriod.class);
                                        
                                        // Add data to time series
                                        timeSeries.add(startPeriod, 1.0);
                                        timeSeries.add(middlePeriod, 2.0);
                                        timeSeries.add(endPeriod, 3.0);
                                        
                                        // Mock behavior for new start period
                                        RegularTimePeriod newStart = mock(RegularTimePeriod.class);
                                        when(newStart.compareTo(startPeriod)).thenReturn(1);
                                        when(newStart.compareTo(middlePeriod)).thenReturn(-1);
                                        
                                        // Test the method
                                        TimeSeries copy = timeSeries.createCopy(newStart, endPeriod);
                                        
                                        // Verify results
                                        assertEquals(2, copy.getItemCount());
                                        assertEquals(2.0, copy.getValue(0).doubleValue(), 0.0001);
                                        assertEquals(3.0, copy.getValue(1).doubleValue(), 0.0001);
                                    }

    @Test
                                    public void testCreateCopyWithEndNotInSeries() throws CloneNotSupportedException {
                                        // Create test data
                                        TimeSeries timeSeries = new TimeSeries("Test Series");
                                        RegularTimePeriod startPeriod = mock(RegularTimePeriod.class);
                                        RegularTimePeriod middlePeriod = mock(RegularTimePeriod.class);
                                        RegularTimePeriod endPeriod = mock(RegularTimePeriod.class);
                                        
                                        // Add data to time series
                                        timeSeries.add(startPeriod, 1.0);
                                        timeSeries.add(middlePeriod, 2.0);
                                        timeSeries.add(endPeriod, 3.0);
                                        
                                        // Mock behavior for new end period
                                        RegularTimePeriod newEnd = mock(RegularTimePeriod.class);
                                        when(newEnd.compareTo(middlePeriod)).thenReturn(1);
                                        when(newEnd.compareTo(endPeriod)).thenReturn(-1);
                                        
                                        // Mock behavior for start period comparison
                                        when(startPeriod.compareTo(newEnd)).thenReturn(-1);
                                        
                                        TimeSeries copy = timeSeries.createCopy(startPeriod, newEnd);
                                        assertEquals(2, copy.getItemCount());
                                        assertEquals(1.0, copy.getValue(0).doubleValue(), 0.0001);
                                        assertEquals(2.0, copy.getValue(1).doubleValue(), 0.0001);
                                    }

    @Test(expected = IllegalArgumentException.class)
        public void testCreateCopyWithStartAfterEnd() throws CloneNotSupportedException {
            TimeSeries timeSeries = new TimeSeries("Test Series");
            RegularTimePeriod startPeriod = mock(RegularTimePeriod.class);
            RegularTimePeriod endPeriod = mock(RegularTimePeriod.class);
            
            when(startPeriod.compareTo(endPeriod)).thenReturn(1);
            timeSeries.createCopy(startPeriod, endPeriod);
        }


}
