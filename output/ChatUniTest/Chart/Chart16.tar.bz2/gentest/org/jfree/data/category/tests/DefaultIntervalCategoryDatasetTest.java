package gentest.org.jfree.data.category.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.category.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.ResourceBundle;
import org.jfree.data.DataUtilities;
import org.jfree.data.UnknownKeyException;
import org.jfree.data.general.AbstractSeriesDataset;
 
public class DefaultIntervalCategoryDatasetTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                    public void testSetCategoryKeysValidInput() {
                                                                                        // Create a dataset with some initial data
                                                                                        Number[][] starts = new Number[][]{{1, 2}, {3, 4}};
                                                                                        Number[][] ends = new Number[][]{{5, 6}, {7, 8}};
                                                                                        DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(
                                                                                            new String[]{"Series 1", "Series 2"}, 
                                                                                            new String[]{"Cat 1", "Cat 2"}, 
                                                                                            starts, 
                                                                                            ends
                                                                                        );
                                                                                        
                                                                                        Comparable[] newKeys = new Comparable[]{"New Cat 1", "New Cat 2"};
                                                                                        dataset.setCategoryKeys(newKeys);
                                                                                        assertArrayEquals(newKeys, dataset.getColumnKeys().toArray());
                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                    public void testSetCategoryKeysNullInput() {
                                                                                        DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(
                                                                                            new Number[][]{{1, 2}, {3, 4}},
                                                                                            new Number[][]{{0, 5}, {2, 6}}
                                                                                        );
                                                                                        dataset.setCategoryKeys(null);
                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                    public void testSetCategoryKeysWrongLength() {
                                                                                        DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(
                                                                                            new Number[][]{{1, 2}, {3, 4}}, 
                                                                                            new Number[][]{{5, 6}, {7, 8}}
                                                                                        );
                                                                                        Comparable[] wrongLengthKeys = new Comparable[]{"Only One"};
                                                                                        dataset.setCategoryKeys(wrongLengthKeys);
                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                    public void testSetCategoryKeysContainsNull() {
                                                                                        DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(
                                                                                            new Number[][]{{1, 2}, {3, 4}},
                                                                                            new Number[][]{{5, 6}, {7, 8}}
                                                                                        );
                                                                                        Comparable[] keysWithNull = new Comparable[]{"Valid", null};
                                                                                        dataset.setCategoryKeys(keysWithNull);
                                                                                    }

    @Test
                                                                                    public void testGenerateKeys() throws Exception {
                                                                                        DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(
                                                                                            new double[][]{{1.0, 2.0}, {3.0, 4.0}},
                                                                                            new double[][]{{5.0, 6.0}, {7.0, 8.0}}
                                                                                        );
                                                                                        
                                                                                        Method method = DefaultIntervalCategoryDataset.class.getDeclaredMethod(
                                                                                            "generateKeys", int.class, String.class);
                                                                                        method.setAccessible(true);
                                                                                        
                                                                                        Comparable<?>[] result = (Comparable<?>[]) method.invoke(dataset, 3, "Test ");
                                                                                        assertEquals("Test 1", result[0]);
                                                                                        assertEquals("Test 2", result[1]);
                                                                                        assertEquals("Test 3", result[2]);
                                                                                    }

    @Test
        public void testSetCategoryKeysFiresDatasetChanged() {
            DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(
                new Number[][]{{1, 2}, {3, 4}},
                new Number[][]{{0, 1}, {2, 3}}
            );
            
            Comparable[] newKeys = new Comparable[]{"New Cat 1", "New Cat 2"};
            dataset.setCategoryKeys(newKeys);
        }


}
