package gentest.org.jfree.chart.plot.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.plot.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Rectangle;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.jfree.chart.ChartRenderingInfo;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.LegendItem;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.event.PlotChangeEvent;
import org.jfree.chart.title.TextTitle;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.chart.util.PaintUtilities;
import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.RectangleInsets;
import org.jfree.chart.util.SerialUtilities;
import org.jfree.chart.util.TableOrder;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.CategoryToPieDataset;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.general.PieDataset;
 
public class MultiplePiePlotTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                    public void testConstructorWithNullDataset() {
                                                        MultiplePiePlot plotWithNull = new MultiplePiePlot(null);
                                                        assertNull(plotWithNull.getDataset());
                                                    }

    @Test
                                                    public void testConstructorWithNullDataset1() {
                                                        MultiplePiePlot plot = new MultiplePiePlot(null);
                                                        assertNull(plot.getDataset());
                                                        assertNotNull(plot.getPieChart());
                                                        assertEquals(TableOrder.BY_COLUMN, plot.getDataExtractOrder());
                                                        assertEquals("Other", plot.getAggregatedItemsKey());
                                                        assertEquals(Color.lightGray, plot.getAggregatedItemsPaint());
                                                        assertNotNull(plot.getPieChart().getTitle());
                                                    }

    @Test
                                                public void testConstructorInitializesFieldsCorrectly() {
                                                    MultiplePiePlot plot = new MultiplePiePlot();
                                                    CategoryDataset dataset = plot.getDataset();
                                                    assertNull(dataset);
                                                    
                                                    JFreeChart pieChart = plot.getPieChart();
                                                    assertNotNull(pieChart);
                                                    assertTrue(pieChart.getPlot() instanceof PiePlot);
                                                    assertEquals(1, pieChart.getSubtitles().size());
                                                    
                                                    TextTitle title = (TextTitle) pieChart.getSubtitles().get(0);
                                                    assertEquals("Series Title", title.getText());
                                                    assertEquals(new Font("SansSerif", Font.BOLD, 12), title.getFont());
                                                    
                                                    assertEquals(TableOrder.BY_COLUMN, plot.getDataExtractOrder());
                                                    assertEquals(0.0, plot.getLimit(), 0.0001);
                                                    assertEquals("Other", plot.getAggregatedItemsKey());
                                                    assertEquals(Color.lightGray, plot.getAggregatedItemsPaint());
                                                }

    @Test
                                                public void testConstructorWithDataset() {
                                                    CategoryDataset mockDataset = mock(CategoryDataset.class);
                                                    MultiplePiePlot plotWithDataset = new MultiplePiePlot(mockDataset);
                                                    assertEquals(mockDataset, plotWithDataset.getDataset());
                                                }

    @Test
                                                public void testSectionPaintsInitialized() throws Exception {
                                                    MultiplePiePlot plot = new MultiplePiePlot();
                                                    Field sectionPaintsField = MultiplePiePlot.class.getDeclaredField("sectionPaints");
                                                    sectionPaintsField.setAccessible(true);
                                                    Object sectionPaints = sectionPaintsField.get(plot);
                                                    assertNotNull(sectionPaints);
                                                    assertTrue(sectionPaints instanceof Map);
                                                    assertTrue(((Map) sectionPaints).isEmpty());
                                                }

    @Test
                                                public void testPieChartBackgroundPaintIsNull() {
                                                    MultiplePiePlot plot = new MultiplePiePlot(null);
                                                    assertNull(plot.getPieChart().getBackgroundPaint());
                                                }

    @Test
                                                public void testConstructorWithDataset1() {
                                                    CategoryDataset mockDataset = mock(CategoryDataset.class);
                                                    MultiplePiePlot multiplePiePlot = new MultiplePiePlot(mockDataset);
                                                    
                                                    assertSame(mockDataset, multiplePiePlot.getDataset());
                                                    assertNotNull(multiplePiePlot.getPieChart());
                                                    assertEquals(TableOrder.BY_COLUMN, multiplePiePlot.getDataExtractOrder());
                                                    assertEquals("Other", multiplePiePlot.getAggregatedItemsKey());
                                                    assertEquals(Color.lightGray, multiplePiePlot.getAggregatedItemsPaint());
                                                    assertNotNull(multiplePiePlot.getPieChart().getTitle());
                                                }

    @Test
                                                public void testPieChartInitialization() {
                                                    CategoryDataset dataset = mock(CategoryDataset.class);
                                                    MultiplePiePlot multiplePiePlot = new MultiplePiePlot(dataset);
                                                    
                                                    JFreeChart pieChart = multiplePiePlot.getPieChart();
                                                    assertNotNull(pieChart);
                                                    assertTrue(pieChart.getPlot() instanceof PiePlot);
                                                    assertNull(pieChart.getBackgroundPaint());
                                                    assertEquals(0, pieChart.getSubtitleCount()); // legend should be removed
                                                }

    @Test
                                                public void testTitleInitialization() {
                                                    MultiplePiePlot multiplePiePlot = new MultiplePiePlot(null);
                                                    TextTitle title = (TextTitle) multiplePiePlot.getPieChart().getTitle();
                                                    assertNotNull(title);
                                                    assertEquals("Series Title", title.getText());
                                                    assertEquals(RectangleEdge.BOTTOM, title.getPosition());
                                                    assertEquals(new Font("SansSerif", Font.BOLD, 12), title.getFont());
                                                }

    @Test
                                                public void testDefaultValues() {
                                                    MultiplePiePlot multiplePiePlot = new MultiplePiePlot(null);
                                                    assertEquals(0.0, multiplePiePlot.getLimit(), 0.0001);
                                                }

    @Test
                                        public void testPieChartLegendRemoved() {
                                            MultiplePiePlot plot = new MultiplePiePlot();
                                            JFreeChart pieChart = new JFreeChart("Test", new PiePlot());
                                            plot.setPieChart(pieChart);
                                            assertEquals(0, pieChart.getSubtitleCount());
                                        }

    @Test
        public void testSectionPaintsInitialization() throws Exception {
            CategoryDataset dataset = mock(CategoryDataset.class);
            MultiplePiePlot multiplePiePlot = new MultiplePiePlot(dataset);
            
            Field field = MultiplePiePlot.class.getDeclaredField("sectionPaints");
            field.setAccessible(true);
            Map sectionPaints = (Map) field.get(multiplePiePlot);
            
            assertNotNull(sectionPaints);
            assertTrue(sectionPaints.isEmpty());
        }


}
