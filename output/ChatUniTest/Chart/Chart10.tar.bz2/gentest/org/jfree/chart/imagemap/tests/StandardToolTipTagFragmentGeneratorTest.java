package gentest.org.jfree.chart.imagemap.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.imagemap.*;
 
public class StandardToolTipTagFragmentGeneratorTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testGenerateToolTipFragmentWithNormalText() {
            StandardToolTipTagFragmentGenerator generator = new StandardToolTipTagFragmentGenerator();
            String result = generator.generateToolTipFragment("Test Tooltip");
            assertEquals(" title=\"Test Tooltip\" alt=\"\"", result);
        }

    @Test
        public void testGenerateToolTipFragmentWithNullText() {
            StandardToolTipTagFragmentGenerator generator = new StandardToolTipTagFragmentGenerator();
            String result = generator.generateToolTipFragment(null);
            assertEquals(" title=\"null\" alt=\"\"", result);
        }

    @Test
        public void testGenerateToolTipFragmentWithEmptyText() {
            StandardToolTipTagFragmentGenerator generator = new StandardToolTipTagFragmentGenerator();
            String result = generator.generateToolTipFragment("");
            assertEquals(" title=\"\" alt=\"\"", result);
        }

    @Test
        public void testGenerateToolTipFragmentWithSpecialCharacters() {
            StandardToolTipTagFragmentGenerator generator = new StandardToolTipTagFragmentGenerator();
            String result = generator.generateToolTipFragment("<script>alert('xss')</script>");
            String expected = " title=\"" + ImageMapUtilities.htmlEscape("<script>alert('xss')</script>") + "\" alt=\"\"";
            assertEquals(expected, result);
        }

    @Test
        public void testGenerateToolTipFragmentWithQuotes() {
            StandardToolTipTagFragmentGenerator generator = new StandardToolTipTagFragmentGenerator();
            String result = generator.generateToolTipFragment("\"quoted\"");
            String expected = " title=\"" + ImageMapUtilities.htmlEscape("\"quoted\"") + "\" alt=\"\"";
            assertEquals(expected, result);
        }

}
