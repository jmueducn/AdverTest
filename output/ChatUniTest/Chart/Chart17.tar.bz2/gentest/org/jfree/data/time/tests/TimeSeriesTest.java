package gentest.org.jfree.data.time.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.time.*;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.data.general.Series;
import org.jfree.data.general.SeriesChangeEvent;
import org.jfree.data.general.SeriesException;
 
public class TimeSeriesTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                    public void testCloneReturnsDifferentObject() throws CloneNotSupportedException {
                        TimeSeries timeSeries = new TimeSeries("Test Series");
                        TimeSeries clone = (TimeSeries) timeSeries.clone();
                        assertNotSame("Clone should be a different object", timeSeries, clone);
                    }

    @Test
                    public void testCloneHasSameClass() throws CloneNotSupportedException {
                        TimeSeries timeSeries = new TimeSeries("Test Series");
                        TimeSeries clone = (TimeSeries) timeSeries.clone();
                        assertEquals("Clone should have same class", timeSeries.getClass(), clone.getClass());
                    }

    @Test
                    public void testCloneHasEqualContents() throws CloneNotSupportedException {
                        TimeSeries timeSeries = new TimeSeries("Test Series");
                        timeSeries.add(new org.jfree.data.time.Day(1, 1, 2000), 100.0);
                        timeSeries.add(new org.jfree.data.time.Day(2, 1, 2000), 200.0);
                        
                        TimeSeries clone = (TimeSeries) timeSeries.clone();
                        assertEquals("Clone should have equal contents", timeSeries, clone);
                    }

    @Test
                    public void testCloneMaintainsAllFields() throws CloneNotSupportedException {
                        TimeSeries timeSeries = new TimeSeries("Test Series");
                        timeSeries.add(new Day(), 1.0);
                        
                        // Set additional fields
                        timeSeries.setDomainDescription("Test Domain");
                        timeSeries.setRangeDescription("Test Range");
                        timeSeries.setMaximumItemCount(100);
                        timeSeries.setMaximumItemAge(200);
                        
                        TimeSeries clone = (TimeSeries) timeSeries.clone();
                        
                        assertEquals("Domain description should match", 
                            timeSeries.getDomainDescription(), clone.getDomainDescription());
                        assertEquals("Range description should match", 
                            timeSeries.getRangeDescription(), clone.getRangeDescription());
                        assertEquals("Maximum item count should match", 
                            timeSeries.getMaximumItemCount(), clone.getMaximumItemCount());
                        assertEquals("Maximum item age should match", 
                            timeSeries.getMaximumItemAge(), clone.getMaximumItemAge());
                        assertEquals("Time period class should match", 
                            timeSeries.getTimePeriodClass(), clone.getTimePeriodClass());
                    }

    @Test(expected = CloneNotSupportedException.class)
                    public void testCloneThrowsExceptionWhenSuperCloneFails() throws Exception {
                        // Create a new TimeSeries instance
                        TimeSeries timeSeries = new TimeSeries("Test Series");
                        
                        // Create a spy to make super.clone() throw exception
                        TimeSeries spySeries = spy(timeSeries);
                        doThrow(new CloneNotSupportedException()).when(spySeries).clone();
                        
                        spySeries.clone();
                    }

    @Test
        public void testCloneDataIsDeepCopy() throws CloneNotSupportedException {
            // Setup test data
            List<TimeSeriesDataItem> mockData = new ArrayList<>();
            mockData.add(new TimeSeriesDataItem(new org.jfree.data.time.Day(1, 1, 2000), 1.0));
            mockData.add(new TimeSeriesDataItem(new org.jfree.data.time.Day(2, 1, 2000), 2.0));
            
            // Create real TimeSeries instance
            TimeSeries timeSeries = new TimeSeries("Test Series");
            for (TimeSeriesDataItem item : mockData) {
                timeSeries.add(item);
            }
            
            // Create a mock for ObjectUtilities
            ObjectUtilities mockUtilities = mock(ObjectUtilities.class);
            when(mockUtilities.deepClone(mockData)).thenReturn(new ArrayList<>(mockData));
            
            // Use reflection to set the instance
            Object originalInstance = null;
            try {
                try {
                    java.lang.reflect.Field instanceField = ObjectUtilities.class.getDeclaredField("instance");
                    instanceField.setAccessible(true);
                    originalInstance = instanceField.get(null);
                    instanceField.set(null, mockUtilities);
                } catch (NoSuchFieldException | IllegalAccessException e) {
                    fail("Failed to set up mock ObjectUtilities instance");
                }
                
                TimeSeries clone = (TimeSeries) timeSeries.clone();
                
                // Verify deepClone was called with the data list
                verify(mockUtilities).deepClone(mockData);
                
                // The data lists should be equal but different objects
                assertNotSame("Data list should be a deep copy", 
                    timeSeries.getItems(), clone.getItems());
                assertEquals("Data list contents should be equal", 
                    timeSeries.getItems(), clone.getItems());
            } finally {
                // Restore original instance using reflection
                try {
                    if (originalInstance != null) {
                        java.lang.reflect.Field instanceField = ObjectUtilities.class.getDeclaredField("instance");
                        instanceField.setAccessible(true);
                        instanceField.set(null, originalInstance);
                    }
                } catch (Exception e) {
                    // Ignore any errors during cleanup
                }
            }
        }


}
