package gentest.org.jfree.data.general.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.general.*;
import org.jfree.data.pie.PieDataset;
import org.jfree.data.pie.DefaultPieDataset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.jfree.chart.util.ArrayUtilities;
import org.jfree.data.DomainInfo;
import org.jfree.data.KeyToGroupMap;
import org.jfree.data.KeyedValues;
import org.jfree.data.Range;
import org.jfree.data.RangeInfo;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.CategoryRangeInfo;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.category.IntervalCategoryDataset;
import org.jfree.data.function.Function2D;
import org.jfree.data.statistics.BoxAndWhiskerCategoryDataset;
import org.jfree.data.statistics.BoxAndWhiskerXYDataset;
import org.jfree.data.statistics.MultiValueCategoryDataset;
import org.jfree.data.statistics.StatisticalCategoryDataset;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.OHLCDataset;
import org.jfree.data.xy.TableXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYDomainInfo;
import org.jfree.data.xy.XYRangeInfo;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
 
public class DatasetUtilitiesTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                        public void testIterateDomainBoundsWithNaNValues() {
                                                                                            XYSeries seriesWithNaN = new XYSeries("Series with NaN");
                                                                                            seriesWithNaN.add(Double.NaN, 1.0);
                                                                                            seriesWithNaN.add(2.0, Double.NaN);
                                                                                            XYSeriesCollection datasetWithNaN = new XYSeriesCollection();
                                                                                            datasetWithNaN.addSeries(seriesWithNaN);
                                                                                            
                                                                                            Range result = DatasetUtilities.iterateDomainBounds(datasetWithNaN);
                                                                                            assertNotNull(result);
                                                                                            assertEquals(2.0, result.getLowerBound(), 0.0001);
                                                                                            assertEquals(2.0, result.getUpperBound(), 0.0001);
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testIterateDomainBoundsWithNullDataset() {
                                                                                            DatasetUtilities.iterateDomainBounds(null);
                                                                                        }

    @Test
                                                                                        public void testIterateDomainBoundsWithSinglePoint() {
                                                                                            XYSeries singlePointSeries = new XYSeries("Single Point");
                                                                                            singlePointSeries.add(5.0, 10.0);
                                                                                            XYSeriesCollection singlePointDataset = new XYSeriesCollection();
                                                                                            singlePointDataset.addSeries(singlePointSeries);
                                                                                            
                                                                                            Range result = DatasetUtilities.iterateDomainBounds(singlePointDataset);
                                                                                            assertNotNull(result);
                                                                                            assertEquals(5.0, result.getLowerBound(), 0.0001);
                                                                                            assertEquals(5.0, result.getUpperBound(), 0.0001);
                                                                                        }

    @Test
                                                                                        public void testIterateDomainBoundsWithNegativeValues() {
                                                                                            XYSeries negativeSeries = new XYSeries("Negative Values");
                                                                                            negativeSeries.add(-5.0, -10.0);
                                                                                            negativeSeries.add(-2.0, -4.0);
                                                                                            XYSeriesCollection negativeDataset = new XYSeriesCollection();
                                                                                            negativeDataset.addSeries(negativeSeries);
                                                                                            
                                                                                            Range result = DatasetUtilities.iterateDomainBounds(negativeDataset);
                                                                                            assertNotNull(result);
                                                                                            assertEquals(-5.0, result.getLowerBound(), 0.0001);
                                                                                            assertEquals(-2.0, result.getUpperBound(), 0.0001);
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testIterateDomainBoundsWithNullDataset1() {
                                                                                            DatasetUtilities.iterateDomainBounds(null, true);
                                                                                        }

    @Test
                                                                                        public void testIterateRangeBoundsWithNullDataset() {
                                                                                            try {
                                                                                                DatasetUtilities.iterateRangeBounds((CategoryDataset) null);
                                                                                                fail("Expected IllegalArgumentException");
                                                                                            } catch (IllegalArgumentException e) {
                                                                                                assertEquals("Null 'dataset' argument.", e.getMessage());
                                                                                            }
                                                                                        }

    @Test
                                                                                        public void testIterateRangeBoundsWithRegularCategoryDataset() {
                                                                                            DefaultCategoryDataset dataset = new DefaultCategoryDataset();
                                                                                            dataset.addValue(5.0, "R1", "C1");
                                                                                            dataset.addValue(10.0, "R1", "C2");
                                                                                            dataset.addValue(2.0, "R2", "C1");
                                                                                            
                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                                                                                            assertNotNull(result);
                                                                                            assertEquals(2.0, result.getLowerBound(), 0.0001);
                                                                                            assertEquals(10.0, result.getUpperBound(), 0.0001);
                                                                                        }

    @Test
                                                                                        public void testIterateRangeBoundsWithNaNValues() {
                                                                                            DefaultCategoryDataset dataset = new DefaultCategoryDataset();
                                                                                            dataset.addValue(Double.NaN, "R1", "C1");
                                                                                            dataset.addValue(10.0, "R1", "C2");
                                                                                            dataset.addValue(2.0, "R2", "C1");
                                                                                            
                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                                                                                            assertNotNull(result);
                                                                                            assertEquals(2.0, result.getLowerBound(), 0.0001);
                                                                                            assertEquals(10.0, result.getUpperBound(), 0.0001);
                                                                                        }

    @Test
                                                                                        public void testIterateRangeBoundsWithNullValues() {
                                                                                            DefaultCategoryDataset dataset = new DefaultCategoryDataset();
                                                                                            dataset.addValue(null, "R1", "C1");
                                                                                            dataset.addValue(10.0, "R1", "C2");
                                                                                            dataset.addValue(2.0, "R2", "C1");
                                                                                            
                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                                                                                            assertNotNull(result);
                                                                                            assertEquals(2.0, result.getLowerBound(), 0.0001);
                                                                                            assertEquals(10.0, result.getUpperBound(), 0.0001);
                                                                                        }

    @Test
                                                                                        public void testIterateRangeBoundsWithIntervalCategoryDataset() {
                                                                                            IntervalCategoryDataset dataset = mock(IntervalCategoryDataset.class);
                                                                                            when(dataset.getRowCount()).thenReturn(2);
                                                                                            when(dataset.getColumnCount()).thenReturn(2);
                                                                                            
                                                                                            // First row, first column
                                                                                            when(dataset.getValue(0, 0)).thenReturn(5.0);
                                                                                            when(dataset.getStartValue(0, 0)).thenReturn(4.0);
                                                                                            when(dataset.getEndValue(0, 0)).thenReturn(6.0);
                                                                                            
                                                                                            // First row, second column
                                                                                            when(dataset.getValue(0, 1)).thenReturn(10.0);
                                                                                            when(dataset.getStartValue(0, 1)).thenReturn(9.0);
                                                                                            when(dataset.getEndValue(0, 1)).thenReturn(11.0);
                                                                                            
                                                                                            // Second row, first column
                                                                                            when(dataset.getValue(1, 0)).thenReturn(2.0);
                                                                                            when(dataset.getStartValue(1, 0)).thenReturn(1.0);
                                                                                            when(dataset.getEndValue(1, 0)).thenReturn(3.0);
                                                                                            
                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                                                                                            assertNotNull(result);
                                                                                            assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                                            assertEquals(11.0, result.getUpperBound(), 0.0001);
                                                                                        }

    @Test
                                                                                        public void testIterateRangeBoundsWithIntervalCategoryDatasetAndNullValues() {
                                                                                            IntervalCategoryDataset dataset = mock(IntervalCategoryDataset.class);
                                                                                            when(dataset.getRowCount()).thenReturn(2);
                                                                                            when(dataset.getColumnCount()).thenReturn(2);
                                                                                            
                                                                                            // First row, first column
                                                                                            when(dataset.getValue(0, 0)).thenReturn(null);
                                                                                            when(dataset.getStartValue(0, 0)).thenReturn(null);
                                                                                            when(dataset.getEndValue(0, 0)).thenReturn(null);
                                                                                            
                                                                                            // First row, second column
                                                                                            when(dataset.getValue(0, 1)).thenReturn(10.0);
                                                                                            when(dataset.getStartValue(0, 1)).thenReturn(9.0);
                                                                                            when(dataset.getEndValue(0, 1)).thenReturn(11.0);
                                                                                            
                                                                                            // Second row, first column
                                                                                            when(dataset.getValue(1, 0)).thenReturn(2.0);
                                                                                            when(dataset.getStartValue(1, 0)).thenReturn(1.0);
                                                                                            when(dataset.getEndValue(1, 0)).thenReturn(3.0);
                                                                                            
                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                                                                                            assertNotNull(result);
                                                                                            assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                                            assertEquals(11.0, result.getUpperBound(), 0.0001);
                                                                                        }

    @Test
                                                                                        public void testIterateRangeBoundsWithIntervalCategoryDatasetAndNaNValues() {
                                                                                            IntervalCategoryDataset dataset = mock(IntervalCategoryDataset.class);
                                                                                            when(dataset.getRowCount()).thenReturn(2);
                                                                                            when(dataset.getColumnCount()).thenReturn(2);
                                                                                            
                                                                                            // First row, first column
                                                                                            when(dataset.getValue(0, 0)).thenReturn(Double.NaN);
                                                                                            when(dataset.getStartValue(0, 0)).thenReturn(Double.NaN);
                                                                                            when(dataset.getEndValue(0, 0)).thenReturn(Double.NaN);
                                                                                            
                                                                                            // First row, second column
                                                                                            when(dataset.getValue(0, 1)).thenReturn(10.0);
                                                                                            when(dataset.getStartValue(0, 1)).thenReturn(9.0);
                                                                                            when(dataset.getEndValue(0, 1)).thenReturn(11.0);
                                                                                            
                                                                                            // Second row, first column
                                                                                            when(dataset.getValue(1, 0)).thenReturn(2.0);
                                                                                            when(dataset.getStartValue(1, 0)).thenReturn(1.0);
                                                                                            when(dataset.getEndValue(1, 0)).thenReturn(3.0);
                                                                                            
                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                                                                                            assertNotNull(result);
                                                                                            assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                                            assertEquals(11.0, result.getUpperBound(), 0.0001);
                                                                                        }

    @Test
                                                                                        public void testIterateRangeBoundsWithIntervalCategoryDatasetButNotIncludingInterval() {
                                                                                            IntervalCategoryDataset dataset = mock(IntervalCategoryDataset.class);
                                                                                            when(dataset.getRowCount()).thenReturn(2);
                                                                                            when(dataset.getColumnCount()).thenReturn(2);
                                                                                            
                                                                                            // First row, first column
                                                                                            when(dataset.getValue(0, 0)).thenReturn(5.0);
                                                                                            when(dataset.getStartValue(0, 0)).thenReturn(4.0);
                                                                                            when(dataset.getEndValue(0, 0)).thenReturn(6.0);
                                                                                            
                                                                                            // First row, second column
                                                                                            when(dataset.getValue(0, 1)).thenReturn(10.0);
                                                                                            when(dataset.getStartValue(0, 1)).thenReturn(9.0);
                                                                                            when(dataset.getEndValue(0, 1)).thenReturn(11.0);
                                                                                            
                                                                                            // Second row, first column
                                                                                            when(dataset.getValue(1, 0)).thenReturn(2.0);
                                                                                            when(dataset.getStartValue(1, 0)).thenReturn(1.0);
                                                                                            when(dataset.getEndValue(1, 0)).thenReturn(3.0);
                                                                                            
                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset, false);
                                                                                            assertNotNull(result);
                                                                                            assertEquals(2.0, result.getLowerBound(), 0.0001);
                                                                                            assertEquals(10.0, result.getUpperBound(), 0.0001);
                                                                                        }

    @Test
                                                                                        public void testIterateRangeBoundsWithAllNullValues() {
                                                                                            DefaultCategoryDataset dataset = new DefaultCategoryDataset();
                                                                                            dataset.addValue(null, "R1", "C1");
                                                                                            dataset.addValue(null, "R1", "C2");
                                                                                            
                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                                                                                            assertNull(result);
                                                                                        }

    @Test
                                                                                        public void testIterateRangeBoundsWithAllNaNValues() {
                                                                                            DefaultCategoryDataset dataset = new DefaultCategoryDataset();
                                                                                            dataset.addValue(Double.NaN, "R1", "C1");
                                                                                            dataset.addValue(Double.NaN, "R1", "C2");
                                                                                            
                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                                                                                            assertNull(result);
                                                                                        }

    @Test
                                                                                        public void testIterateRangeBoundsWithNaNValues1() {
                                                                                            XYSeries series = new XYSeries("Series with NaN");
                                                                                            series.add(1.0, Double.NaN);
                                                                                            series.add(2.0, 3.0);
                                                                                            series.add(3.0, Double.NaN);
                                                                                            XYSeriesCollection dataset = new XYSeriesCollection(series);
                                                                                            
                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                                            assertNotNull("Range should not be null", result);
                                                                                            assertEquals(3.0, result.getLowerBound(), 0.0001);
                                                                                            assertEquals(3.0, result.getUpperBound(), 0.0001);
                                                                                        }

    @Test
                                                                                        public void testIterateRangeBoundsWithAllNaNValues1() {
                                                                                            XYSeries series = new XYSeries("Series with all NaN");
                                                                                            series.add(1.0, Double.NaN);
                                                                                            series.add(2.0, Double.NaN);
                                                                                            XYSeriesCollection dataset = new XYSeriesCollection(series);
                                                                                            
                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                                            assertNull("Range should be null for all NaN values", result);
                                                                                        }

    @Test
                                                                                    public void testIterateDomainBoundsWithRegularDataset() {
                                                                                        XYSeries series = new XYSeries("Test Series");
                                                                                        series.add(1.0, 100.0);
                                                                                        series.add(2.0, 200.0);
                                                                                        series.add(3.0, 300.0);
                                                                                        series.add(4.0, 400.0);
                                                                                        XYSeriesCollection regularDataset = new XYSeriesCollection(series);
                                                                                        
                                                                                        Range result = DatasetUtilities.iterateDomainBounds(regularDataset);
                                                                                        assertNotNull(result);
                                                                                        assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                                        assertEquals(4.0, result.getUpperBound(), 0.0001);
                                                                                    }

    @Test
                                                                                    public void testIterateDomainBoundsWithIntervalDataset() {
                                                                                        XYSeries series = new XYSeries("Test Series");
                                                                                        series.add(1.0, 1.0);
                                                                                        series.add(2.0, 2.0);
                                                                                        series.add(3.0, 3.0);
                                                                                        XYSeriesCollection intervalDataset = new XYSeriesCollection(series);
                                                                                        
                                                                                        Range result = DatasetUtilities.iterateDomainBounds(intervalDataset, true);
                                                                                        assertNotNull(result);
                                                                                        assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                                        assertEquals(3.0, result.getUpperBound(), 0.0001);
                                                                                    }

    @Test
                                                                                    public void testIterateDomainBoundsWithIntervalDatasetExcludingInterval() {
                                                                                        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
                                                                                        when(intervalDataset.getItemCount(0)).thenReturn(2);
                                                                                        when(intervalDataset.getStartXValue(0, 0)).thenReturn(1.0);
                                                                                        when(intervalDataset.getEndXValue(0, 0)).thenReturn(2.0);
                                                                                        when(intervalDataset.getStartXValue(0, 1)).thenReturn(2.0);
                                                                                        when(intervalDataset.getEndXValue(0, 1)).thenReturn(3.0);
                                                                                
                                                                                        Range result = DatasetUtilities.iterateDomainBounds(intervalDataset, false);
                                                                                        assertNotNull(result);
                                                                                        assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                                        assertEquals(3.0, result.getUpperBound(), 0.0001);
                                                                                    }

    @Test
                                                                                    public void testIterateDomainBoundsWithEmptyDataset() {
                                                                                        XYDataset emptyDataset = mock(XYDataset.class);
                                                                                        when(emptyDataset.getItemCount(0)).thenReturn(0);
                                                                                        Range result = DatasetUtilities.iterateDomainBounds(emptyDataset);
                                                                                        assertNull(result);
                                                                                    }

    @Test
                                                                                    public void testIterateDomainBoundsWithEmptyDataset1() {
                                                                                        XYDataset xyDataset = mock(XYDataset.class);
                                                                                        when(xyDataset.getSeriesCount()).thenReturn(0);
                                                                                        Range result = DatasetUtilities.iterateDomainBounds(xyDataset, true);
                                                                                        assertNull(result);
                                                                                    }

    @Test
                                                                                    public void testIterateDomainBoundsWithRegularXYDataset() {
                                                                                        XYDataset xyDataset = mock(XYDataset.class);
                                                                                        when(xyDataset.getSeriesCount()).thenReturn(1);
                                                                                        when(xyDataset.getItemCount(0)).thenReturn(2);
                                                                                        when(xyDataset.getXValue(0, 0)).thenReturn(1.0);
                                                                                        when(xyDataset.getXValue(0, 1)).thenReturn(2.0);
                                                                                
                                                                                        Range result = DatasetUtilities.iterateDomainBounds(xyDataset, true);
                                                                                        assertEquals(new Range(1.0, 2.0), result);
                                                                                    }

    @Test
                                                                                    public void testIterateDomainBoundsWithIntervalXYDataset() {
                                                                                        IntervalXYDataset intervalXYDataset = mock(IntervalXYDataset.class);
                                                                                        when(intervalXYDataset.getSeriesCount()).thenReturn(1);
                                                                                        when(intervalXYDataset.getItemCount(0)).thenReturn(2);
                                                                                        when(intervalXYDataset.getXValue(0, 0)).thenReturn(1.0);
                                                                                        when(intervalXYDataset.getStartXValue(0, 0)).thenReturn(0.5);
                                                                                        when(intervalXYDataset.getEndXValue(0, 0)).thenReturn(1.5);
                                                                                        when(intervalXYDataset.getXValue(0, 1)).thenReturn(2.0);
                                                                                        when(intervalXYDataset.getStartXValue(0, 1)).thenReturn(1.5);
                                                                                        when(intervalXYDataset.getEndXValue(0, 1)).thenReturn(2.5);
                                                                                    
                                                                                        Range result = DatasetUtilities.iterateDomainBounds(intervalXYDataset, true);
                                                                                        assertEquals(new Range(0.5, 2.5), result);
                                                                                    }

    @Test
                                                                                    public void testIterateDomainBoundsWithIntervalXYDatasetButNoInterval() {
                                                                                        IntervalXYDataset intervalXYDataset = mock(IntervalXYDataset.class);
                                                                                        when(intervalXYDataset.getSeriesCount()).thenReturn(1);
                                                                                        when(intervalXYDataset.getItemCount(0)).thenReturn(2);
                                                                                        when(intervalXYDataset.getXValue(0, 0)).thenReturn(1.0);
                                                                                        when(intervalXYDataset.getXValue(0, 1)).thenReturn(2.0);
                                                                                
                                                                                        Range result = DatasetUtilities.iterateDomainBounds(intervalXYDataset, false);
                                                                                        assertEquals(new Range(1.0, 2.0), result);
                                                                                    }

    @Test
                                                                                    public void testIterateDomainBoundsWithNaNValues1() {
                                                                                        XYDataset xyDataset = mock(XYDataset.class);
                                                                                        when(xyDataset.getSeriesCount()).thenReturn(1);
                                                                                        when(xyDataset.getItemCount(0)).thenReturn(3);
                                                                                        when(xyDataset.getXValue(0, 0)).thenReturn(Double.NaN);
                                                                                        when(xyDataset.getXValue(0, 1)).thenReturn(1.0);
                                                                                        when(xyDataset.getXValue(0, 2)).thenReturn(Double.NaN);
                                                                                    
                                                                                        Range result = DatasetUtilities.iterateDomainBounds(xyDataset, true);
                                                                                        assertEquals(new Range(1.0, 1.0), result);
                                                                                    }

    @Test
                                                                                    public void testIterateDomainBoundsWithAllNaNValues() {
                                                                                        XYDataset xyDataset = mock(XYDataset.class);
                                                                                        when(xyDataset.getSeriesCount()).thenReturn(1);
                                                                                        when(xyDataset.getItemCount(0)).thenReturn(2);
                                                                                        when(xyDataset.getXValue(0, 0)).thenReturn(Double.NaN);
                                                                                        when(xyDataset.getXValue(0, 1)).thenReturn(Double.NaN);
                                                                                
                                                                                        Range result = DatasetUtilities.iterateDomainBounds(xyDataset, true);
                                                                                        assertNull(result);
                                                                                    }

    @Test
                                                                                    public void testIterateDomainBoundsWithMultipleSeries() {
                                                                                        XYDataset xyDataset = mock(XYDataset.class);
                                                                                        when(xyDataset.getSeriesCount()).thenReturn(2);
                                                                                        when(xyDataset.getItemCount(0)).thenReturn(2);
                                                                                        when(xyDataset.getItemCount(1)).thenReturn(2);
                                                                                        when(xyDataset.getXValue(0, 0)).thenReturn(1.0);
                                                                                        when(xyDataset.getXValue(0, 1)).thenReturn(3.0);
                                                                                        when(xyDataset.getXValue(1, 0)).thenReturn(2.0);
                                                                                        when(xyDataset.getXValue(1, 1)).thenReturn(4.0);
                                                                                    
                                                                                        Range result = DatasetUtilities.iterateDomainBounds(xyDataset, true);
                                                                                        assertEquals(new Range(1.0, 4.0), result);
                                                                                    }

    @Test
                                                                                    public void testIterateDomainBoundsWithSingleValue() {
                                                                                        XYDataset xyDataset = mock(XYDataset.class);
                                                                                        when(xyDataset.getSeriesCount()).thenReturn(1);
                                                                                        when(xyDataset.getItemCount(0)).thenReturn(1);
                                                                                        when(xyDataset.getXValue(0, 0)).thenReturn(5.0);
                                                                                        
                                                                                        Range result = DatasetUtilities.iterateDomainBounds(xyDataset, true);
                                                                                        assertEquals(new Range(5.0, 5.0), result);
                                                                                    }

    @Test
                                                                                    public void testIterateRangeBoundsWithSingleValue() {
                                                                                        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
                                                                                        dataset.addValue(5.0, "Row1", "Column1");
                                                                                        Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                                        assertNotNull(result);
                                                                                        assertEquals(5.0, result.getLowerBound(), 0.0001);
                                                                                        assertEquals(5.0, result.getUpperBound(), 0.0001);
                                                                                    }

    @Test
                                                                                    public void testIterateRangeBoundsWithMultipleValues() {
                                                                                        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
                                                                                        dataset.addValue(5.0, "Row1", "Column1");
                                                                                        dataset.addValue(10.0, "Row1", "Column2");
                                                                                        dataset.addValue(2.0, "Row2", "Column1");
                                                                                        Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                                        assertNotNull(result);
                                                                                        assertEquals(2.0, result.getLowerBound(), 0.0001);
                                                                                        assertEquals(10.0, result.getUpperBound(), 0.0001);
                                                                                    }

    @Test
                                                                                    public void testIterateRangeBoundsWithNullValues1() {
                                                                                        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
                                                                                        dataset.addValue(5.0, "Row1", "Column1");
                                                                                        dataset.addValue(null, "Row1", "Column2");
                                                                                        dataset.addValue(2.0, "Row2", "Column1");
                                                                                        Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                                        assertNotNull(result);
                                                                                        assertEquals(2.0, result.getLowerBound(), 0.0001);
                                                                                        assertEquals(5.0, result.getUpperBound(), 0.0001);
                                                                                    }

    @Test
                                                                                    public void testIterateRangeBoundsWithNaNValues2() {
                                                                                        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
                                                                                        dataset.addValue(5.0, "Row1", "Column1");
                                                                                        dataset.addValue(Double.NaN, "Row1", "Column2");
                                                                                        dataset.addValue(2.0, "Row2", "Column1");
                                                                                        Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                                        assertNotNull(result);
                                                                                        assertEquals(2.0, result.getLowerBound(), 0.0001);
                                                                                        assertEquals(5.0, result.getUpperBound(), 0.0001);
                                                                                    }

    @Test
                                                                                    public void testIterateRangeBoundsWithNullDataset1() {
                                                                                        try {
                                                                                            DatasetUtilities.iterateRangeBounds((org.jfree.data.category.CategoryDataset) null, true);
                                                                                            fail("Expected IllegalArgumentException");
                                                                                        } catch (IllegalArgumentException e) {
                                                                                            assertEquals("Null 'dataset' argument.", e.getMessage());
                                                                                        }
                                                                                    }

    @Test
                                                                                    public void testIterateRangeBoundsWithSinglePointDataset() {
                                                                                        XYSeries series = new XYSeries("Test Series");
                                                                                        series.add(1.0, 2.0);
                                                                                        XYSeriesCollection singlePointDataset = new XYSeriesCollection(series);
                                                                                        
                                                                                        Range result = DatasetUtilities.iterateRangeBounds(singlePointDataset);
                                                                                        assertNotNull("Range should not be null", result);
                                                                                        assertEquals(2.0, result.getLowerBound(), 0.0001);
                                                                                        assertEquals(2.0, result.getUpperBound(), 0.0001);
                                                                                    }

    @Test
                                                                                    public void testIterateRangeBoundsWithMultiplePointsDataset() {
                                                                                        XYSeries series = new XYSeries("Test Series");
                                                                                        series.add(1.0, 2.0);
                                                                                        series.add(3.0, 4.0);
                                                                                        series.add(5.0, 6.0);
                                                                                        XYSeriesCollection multiplePointsDataset = new XYSeriesCollection(series);
                                                                                        
                                                                                        Range result = DatasetUtilities.iterateRangeBounds(multiplePointsDataset);
                                                                                        assertNotNull("Range should not be null", result);
                                                                                        assertEquals(2.0, result.getLowerBound(), 0.0001);
                                                                                        assertEquals(6.0, result.getUpperBound(), 0.0001);
                                                                                    }

    @Test
                                                                                    public void testIterateRangeBoundsWithEmptyXYDataset() {
                                                                                        XYDataset xyDataset = mock(XYDataset.class);
                                                                                        when(xyDataset.getSeriesCount()).thenReturn(0);
                                                                                        assertNull(DatasetUtilities.iterateRangeBounds(xyDataset, true));
                                                                                    }

    @Test
                                                                                    public void testIterateRangeBoundsWithXYDataset() {
                                                                                        XYDataset xyDataset = mock(XYDataset.class);
                                                                                        when(xyDataset.getSeriesCount()).thenReturn(1);
                                                                                        when(xyDataset.getItemCount(0)).thenReturn(2);
                                                                                        when(xyDataset.getYValue(0, 0)).thenReturn(5.0);
                                                                                        when(xyDataset.getYValue(0, 1)).thenReturn(10.0);
                                                                                
                                                                                        Range result = DatasetUtilities.iterateRangeBounds(xyDataset, false);
                                                                                        assertEquals(5.0, result.getLowerBound(), 0.0001);
                                                                                        assertEquals(10.0, result.getUpperBound(), 0.0001);
                                                                                    }

    @Test
                                                                                public void testIterateRangeBoundsWithXYDatasetContainingNaN() {
                                                                                    XYDataset xyDataset = mock(XYDataset.class);
                                                                                    when(xyDataset.getSeriesCount()).thenReturn(1);
                                                                                    when(xyDataset.getItemCount(0)).thenReturn(3);
                                                                                    when(xyDataset.getYValue(0, 0)).thenReturn(5.0);
                                                                                    when(xyDataset.getYValue(0, 1)).thenReturn(Double.NaN);
                                                                                    when(xyDataset.getYValue(0, 2)).thenReturn(10.0);
                                                                                    
                                                                                    Range result = DatasetUtilities.iterateRangeBounds(xyDataset, false);
                                                                                    assertEquals(5.0, result.getLowerBound(), 0.0001);
                                                                                    assertEquals(10.0, result.getUpperBound(), 0.0001);
                                                                                }

    @Test
                                                                                public void testIterateRangeBoundsWithIntervalXYDataset() {
                                                                                    IntervalXYDataset intervalXYDataset = mock(IntervalXYDataset.class);
                                                                                    when(intervalXYDataset.getSeriesCount()).thenReturn(1);
                                                                                    when(intervalXYDataset.getItemCount(0)).thenReturn(2);
                                                                                    when(intervalXYDataset.getYValue(0, 0)).thenReturn(5.0);
                                                                                    when(intervalXYDataset.getStartYValue(0, 0)).thenReturn(4.0);
                                                                                    when(intervalXYDataset.getEndYValue(0, 0)).thenReturn(6.0);
                                                                                    when(intervalXYDataset.getYValue(0, 1)).thenReturn(10.0);
                                                                                    when(intervalXYDataset.getStartYValue(0, 1)).thenReturn(9.0);
                                                                                    when(intervalXYDataset.getEndYValue(0, 1)).thenReturn(11.0);
                                                                                    
                                                                                    Range result = DatasetUtilities.iterateRangeBounds(intervalXYDataset, true);
                                                                                    assertEquals(4.0, result.getLowerBound(), 0.0001);
                                                                                    assertEquals(11.0, result.getUpperBound(), 0.0001);
                                                                                }

    @Test
                                                                                public void testIterateRangeBoundsWithIntervalXYDatasetAndNaNValues() {
                                                                                    IntervalXYDataset intervalXYDataset = mock(IntervalXYDataset.class);
                                                                                    when(intervalXYDataset.getSeriesCount()).thenReturn(1);
                                                                                    when(intervalXYDataset.getItemCount(0)).thenReturn(3);
                                                                                    when(intervalXYDataset.getYValue(0, 0)).thenReturn(5.0);
                                                                                    when(intervalXYDataset.getStartYValue(0, 0)).thenReturn(Double.NaN);
                                                                                    when(intervalXYDataset.getEndYValue(0, 0)).thenReturn(6.0);
                                                                                    when(intervalXYDataset.getYValue(0, 1)).thenReturn(Double.NaN);
                                                                                    when(intervalXYDataset.getStartYValue(0, 1)).thenReturn(9.0);
                                                                                    when(intervalXYDataset.getEndYValue(0, 1)).thenReturn(Double.NaN);
                                                                                    when(intervalXYDataset.getYValue(0, 2)).thenReturn(10.0);
                                                                                    when(intervalXYDataset.getStartYValue(0, 2)).thenReturn(9.5);
                                                                                    when(intervalXYDataset.getEndYValue(0, 2)).thenReturn(10.5);
                                                                                    
                                                                                    Range result = DatasetUtilities.iterateRangeBounds(intervalXYDataset, true);
                                                                                    assertEquals(5.0, result.getLowerBound(), 0.0001);
                                                                                    assertEquals(10.5, result.getUpperBound(), 0.0001);
                                                                                }

    @Test
                                                                                public void testIterateRangeBoundsWithOHLCDataset() {
                                                                                    OHLCDataset ohlcDataset = mock(OHLCDataset.class);
                                                                                    when(ohlcDataset.getSeriesCount()).thenReturn(1);
                                                                                    when(ohlcDataset.getItemCount(0)).thenReturn(2);
                                                                                    when(ohlcDataset.getLowValue(0, 0)).thenReturn(4.0);
                                                                                    when(ohlcDataset.getHighValue(0, 0)).thenReturn(6.0);
                                                                                    when(ohlcDataset.getLowValue(0, 1)).thenReturn(9.0);
                                                                                    when(ohlcDataset.getHighValue(0, 1)).thenReturn(11.0);
                                                                                    
                                                                                    Range result = DatasetUtilities.iterateRangeBounds(ohlcDataset, true);
                                                                                    assertEquals(4.0, result.getLowerBound(), 0.0001);
                                                                                    assertEquals(11.0, result.getUpperBound(), 0.0001);
                                                                                }

    @Test
                                                                                public void testIterateRangeBoundsWithOHLCDatasetAndNaNValues() {
                                                                                    OHLCDataset ohlcDataset = mock(OHLCDataset.class);
                                                                                    when(ohlcDataset.getSeriesCount()).thenReturn(1);
                                                                                    when(ohlcDataset.getItemCount(0)).thenReturn(3);
                                                                                    when(ohlcDataset.getLowValue(0, 0)).thenReturn(Double.NaN);
                                                                                    when(ohlcDataset.getHighValue(0, 0)).thenReturn(6.0);
                                                                                    when(ohlcDataset.getLowValue(0, 1)).thenReturn(9.0);
                                                                                    when(ohlcDataset.getHighValue(0, 1)).thenReturn(Double.NaN);
                                                                                    when(ohlcDataset.getLowValue(0, 2)).thenReturn(9.5);
                                                                                    when(ohlcDataset.getHighValue(0, 2)).thenReturn(10.5);
                                                                                    
                                                                                    Range result = DatasetUtilities.iterateRangeBounds(ohlcDataset, true);
                                                                                    assertEquals(9.0, result.getLowerBound(), 0.0001);
                                                                                    assertEquals(10.5, result.getUpperBound(), 0.0001);
                                                                                }

    @Test
                                                                                public void testIterateRangeBoundsWithAllNaNValues2() {
                                                                                    XYDataset xyDataset = mock(XYDataset.class);
                                                                                    when(xyDataset.getSeriesCount()).thenReturn(1);
                                                                                    when(xyDataset.getItemCount(0)).thenReturn(2);
                                                                                    when(xyDataset.getYValue(0, 0)).thenReturn(Double.NaN);
                                                                                    when(xyDataset.getYValue(0, 1)).thenReturn(Double.NaN);
                                                                                    
                                                                                    assertNull(DatasetUtilities.iterateRangeBounds(xyDataset, false));
                                                                                }

    @Test
                                                                                public void testIterateRangeBoundsWithMultipleSeries() {
                                                                                    XYDataset xyDataset = mock(XYDataset.class);
                                                                                    when(xyDataset.getSeriesCount()).thenReturn(2);
                                                                                    when(xyDataset.getItemCount(0)).thenReturn(2);
                                                                                    when(xyDataset.getItemCount(1)).thenReturn(2);
                                                                                    when(xyDataset.getYValue(0, 0)).thenReturn(5.0);
                                                                                    when(xyDataset.getYValue(0, 1)).thenReturn(10.0);
                                                                                    when(xyDataset.getYValue(1, 0)).thenReturn(3.0);
                                                                                    when(xyDataset.getYValue(1, 1)).thenReturn(12.0);
                                                                                    
                                                                                    Range result = DatasetUtilities.iterateRangeBounds(xyDataset, false);
                                                                                    assertEquals(3.0, result.getLowerBound(), 0.0001);
                                                                                    assertEquals(12.0, result.getUpperBound(), 0.0001);
                                                                                }

    @Test
                                                public void testIterateRangeBoundsWithIntervalDataset() {
                                                    IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
                                                    
                                                    when(intervalDataset.getXValue(0, 0)).thenReturn(5.0);
                                                    when(intervalDataset.getStartXValue(0, 0)).thenReturn(4.0);
                                                    when(intervalDataset.getEndXValue(0, 0)).thenReturn(6.0);
                                                
                                                    Range result = DatasetUtilities.iterateRangeBounds(intervalDataset, true);
                                                    assertNotNull(result);
                                                    assertEquals(4.0, result.getLowerBound(), 0.0001);
                                                    assertEquals(6.0, result.getUpperBound(), 0.0001);
                                                }

    @Test
                                                public void testIterateRangeBoundsWithNullDataset2() {
                                                    try {
                                                        Dataset dataset = null;
                                                        fail("Expected IllegalArgumentException");
                                                    } catch (IllegalArgumentException e) {
                                                        assertEquals("Null 'dataset' argument.", e.getMessage());
                                                    }
                                                }

    @Test
                                                public void testIterateRangeBoundsWithIntervalDataset1() {
                                                    IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
                                                    
                                                    when(intervalDataset.getXValue(0, 0)).thenReturn(5.0);
                                                    when(intervalDataset.getStartXValue(0, 0)).thenReturn(4.0);
                                                    when(intervalDataset.getEndXValue(0, 0)).thenReturn(6.0);
                                                
                                                    Range result = DatasetUtilities.iterateRangeBounds(intervalDataset, true);
                                                    assertNotNull(result);
                                                    assertEquals(4.0, result.getLowerBound(), 0.0001);
                                                    assertEquals(6.0, result.getUpperBound(), 0.0001);
                                                }

    @Test
                                                public void testIterateRangeBoundsWithIntervalDatasetDisabled() {
                                                    IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
                                                    
                                                    when(intervalDataset.getXValue(0, 0)).thenReturn(5.0);
                                                    when(intervalDataset.getStartXValue(0, 0)).thenReturn(4.0);
                                                    when(intervalDataset.getEndXValue(0, 0)).thenReturn(6.0);
                                                
                                                    Range result = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(intervalDataset, false);
                                                    assertNotNull(result);
                                                    assertEquals(5.0, result.getLowerBound(), 0.0001);
                                                    assertEquals(5.0, result.getUpperBound(), 0.0001);
                                                }

    @Test
                                                public void testIterateRangeBoundsWithNullDataset3() {
                                                    try {
                                                        Dataset dataset = null;
                                                        fail("Expected IllegalArgumentException");
                                                    } catch (IllegalArgumentException e) {
                                                        assertEquals("Null 'dataset' argument.", e.getMessage());
                                                    }
                                                }

    @Test
                        public void testIterateRangeBoundsWithIntervalDatasetAndNaNValues() {
                            IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
                            when(intervalDataset.getSeriesCount()).thenReturn(1);
                            when(intervalDataset.getItemCount(0)).thenReturn(1);
                            when(intervalDataset.getXValue(0, 0)).thenReturn(Double.NaN);
                            when(intervalDataset.getYValue(0, 0)).thenReturn(Double.NaN);
                            when(intervalDataset.getStartXValue(0, 0)).thenReturn(Double.NaN);
                            when(intervalDataset.getEndXValue(0, 0)).thenReturn(Double.NaN);
                            when(intervalDataset.getStartYValue(0, 0)).thenReturn(Double.NaN);
                            when(intervalDataset.getEndYValue(0, 0)).thenReturn(Double.NaN);
                        
                            Range result = DatasetUtilities.iterateRangeBounds(intervalDataset, true);
                            assertNull(result);
                        }

    @Test
        public void testIterateRangeBoundsWithEmptyDataset2() {
            Dataset dataset = mock(Dataset.class);
            
        }

    @Test
        public void testIterateRangeBoundsWithEmptyDataset1() {
            Dataset dataset = mock(Dataset.class);
            
        }

    @Test
        public void testIterateRangeBoundsWithEmptyDataset() {
            Dataset dataset = mock(Dataset.class);
            
        }

    @Test
        public void testIterateRangeBoundsWithIntervalDatasetAndNullValues() {
            
        }


}
