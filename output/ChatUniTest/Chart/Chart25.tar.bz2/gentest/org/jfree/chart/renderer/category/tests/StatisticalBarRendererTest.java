package gentest.org.jfree.chart.renderer.category.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.renderer.category.*;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.util.PaintUtilities;
import org.jfree.chart.util.PublicCloneable;
import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.SerialUtilities;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.statistics.StatisticalCategoryDataset;
 
public class StatisticalBarRendererTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                public void testDrawHorizontalItemWithNullMeanValue() throws Exception {
                                                    StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                    CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                    Rectangle2D dataArea = mock(Rectangle2D.class);
                                                    CategoryPlot plot = mock(CategoryPlot.class);
                                                    CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                    ValueAxis rangeAxis = mock(ValueAxis.class);
                                                    StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                            
                                                    when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(null);
                                                    when(state.getBarWidth()).thenReturn(10.0);
                                                    when(plot.getDomainAxisEdge()).thenReturn(null);
                                                    when(domainAxis.getCategoryStart(anyInt(), anyInt(), any(Rectangle2D.class), any())).thenReturn(0.0);
                                                    
                                                    Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                        "drawHorizontalItem", Graphics2D.class, CategoryItemRendererState.class,
                                                        Rectangle2D.class, CategoryPlot.class, CategoryAxis.class, ValueAxis.class,
                                                        StatisticalCategoryDataset.class, int.class, int.class);
                                                    method.setAccessible(true);
                                                    
                                                    method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                                    
                                                    verify(g2, never()).fill(any(Rectangle2D.class));
                                                }

    @Test
                                                public void testDrawHorizontalItemWithSingleSeries() throws Exception {
                                                    StatisticalBarRenderer renderer = mock(StatisticalBarRenderer.class);
                                                    StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                    CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                    Rectangle2D dataArea = mock(Rectangle2D.class);
                                                    CategoryPlot plot = mock(CategoryPlot.class);
                                                    CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                    ValueAxis rangeAxis = mock(ValueAxis.class);
                                                    CategoryItemLabelGenerator generator = mock(CategoryItemLabelGenerator.class);
                                            
                                                    when(dataset.getMeanValue(0, 0)).thenReturn(5.0);
                                                    when(dataset.getStdDevValue(0, 0)).thenReturn(1.0);
                                                    when(renderer.getRowCount()).thenReturn(1);
                                                    when(renderer.getColumnCount()).thenReturn(1);
                                                    when(renderer.getItemPaint(0, 0)).thenReturn(Color.RED);
                                                    when(renderer.isDrawBarOutline()).thenReturn(true);
                                                    when(renderer.getItemLabelGenerator(0, 0)).thenReturn(generator);
                                                    when(renderer.isItemLabelVisible(0, 0)).thenReturn(true);
                                                    when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                    when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                    when(state.getBarWidth()).thenReturn(10.0);
                                                    when(dataArea.getHeight()).thenReturn(100.0);
                                                    when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class)))
                                                        .thenReturn(50.0);
                                                    
                                                    Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                        "drawHorizontalItem", Graphics2D.class, CategoryItemRendererState.class,
                                                        Rectangle2D.class, CategoryPlot.class, CategoryAxis.class, ValueAxis.class,
                                                        StatisticalCategoryDataset.class, int.class, int.class);
                                                    method.setAccessible(true);
                                                    
                                                    method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                                    
                                                    verify(g2).fill(any(Rectangle2D.class));
                                                    verify(g2, atLeast(3)).draw(any(Line2D.class));
                                                    verify(g2).draw(any(Rectangle2D.class));
                                                }

    @Test
                                                public void testDrawHorizontalItemWithMultipleSeries() throws Exception {
                                                    // Create mocks
                                                    StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                    StatisticalBarRenderer renderer = mock(StatisticalBarRenderer.class);
                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                    CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                    Rectangle2D dataArea = mock(Rectangle2D.class);
                                                    CategoryPlot plot = mock(CategoryPlot.class);
                                                    CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                    ValueAxis rangeAxis = mock(ValueAxis.class);
                                            
                                                    // Stub methods
                                                    when(dataset.getMeanValue(1, 0)).thenReturn(5.0);
                                                    when(dataset.getStdDevValue(1, 0)).thenReturn(1.0);
                                                    when(renderer.getRowCount()).thenReturn(2);
                                                    when(renderer.getColumnCount()).thenReturn(1);
                                                    when(renderer.getItemPaint(1, 0)).thenReturn(Color.BLUE);
                                                    when(renderer.getItemMargin()).thenReturn(0.1);
                                                    when(state.getBarWidth()).thenReturn(10.0);
                                                    when(dataArea.getHeight()).thenReturn(100.0);
                                                    when(plot.getDomainAxisEdge()).thenReturn(null);
                                                    when(plot.getRangeAxisEdge()).thenReturn(null);
                                                    when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(50.0);
                                                    
                                                    Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                        "drawHorizontalItem", Graphics2D.class, CategoryItemRendererState.class,
                                                        Rectangle2D.class, CategoryPlot.class, CategoryAxis.class, ValueAxis.class,
                                                        StatisticalCategoryDataset.class, int.class, int.class);
                                                    method.setAccessible(true);
                                                    
                                                    method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 0);
                                                    
                                                    verify(g2).fill(any(Rectangle2D.class));
                                                    verify(g2, atLeast(3)).draw(any(Line2D.class));
                                                }

    @Test
                                                public void testDrawHorizontalItemWithNullStdDev() throws Exception {
                                                    StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                    CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                    Rectangle2D dataArea = mock(Rectangle2D.class);
                                                    CategoryPlot plot = mock(CategoryPlot.class);
                                                    CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                    ValueAxis rangeAxis = mock(ValueAxis.class);
                                                    StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                            
                                                    when(dataset.getMeanValue(0, 0)).thenReturn(5.0);
                                                    when(dataset.getStdDevValue(0, 0)).thenReturn(null);
                                                    when(state.getBarWidth()).thenReturn(10.0);
                                                    when(dataArea.getHeight()).thenReturn(100.0);
                                                    
                                                    Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                        "drawHorizontalItem", Graphics2D.class, CategoryItemRendererState.class,
                                                        Rectangle2D.class, CategoryPlot.class, CategoryAxis.class, ValueAxis.class,
                                                        StatisticalCategoryDataset.class, int.class, int.class);
                                                    method.setAccessible(true);
                                                    
                                                    method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                                    
                                                    verify(g2).fill(any(Rectangle2D.class));
                                                    verify(g2, never()).draw(any(Line2D.class));
                                                }

    @Test
                                                public void testDrawHorizontalItemWithCustomErrorIndicator() throws Exception {
                                                    // Create mocks
                                                    StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                    CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                    Rectangle2D dataArea = mock(Rectangle2D.class);
                                                    CategoryPlot plot = mock(CategoryPlot.class);
                                                    CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                    ValueAxis rangeAxis = mock(ValueAxis.class);
                                                    StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                            
                                                    // Setup mocks
                                                    when(state.getBarWidth()).thenReturn(10.0);
                                                    when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                    when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                    when(dataset.getMeanValue(0, 0)).thenReturn(5.0);
                                                    when(dataset.getStdDevValue(0, 0)).thenReturn(1.0);
                                                    renderer.setErrorIndicatorPaint(Color.GREEN);
                                                    renderer.setErrorIndicatorStroke(new BasicStroke(2.0f));
                                                    
                                                    Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                        "drawHorizontalItem", Graphics2D.class, CategoryItemRendererState.class,
                                                        Rectangle2D.class, CategoryPlot.class, CategoryAxis.class, ValueAxis.class,
                                                        StatisticalCategoryDataset.class, int.class, int.class);
                                                    method.setAccessible(true);
                                                    
                                                    method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                                    
                                                    verify(g2).setPaint(Color.GREEN);
                                                    verify(g2).setStroke(any(BasicStroke.class));
                                                }

    @Test
                                            public void testDrawHorizontalItemWithItemLabels() throws Exception {
                                                StatisticalBarRenderer renderer = mock(StatisticalBarRenderer.class);
                                                Graphics2D g2 = mock(Graphics2D.class);
                                                CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                Rectangle2D dataArea = mock(Rectangle2D.class);
                                                CategoryPlot plot = mock(CategoryPlot.class);
                                                CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                ValueAxis rangeAxis = mock(ValueAxis.class);
                                                StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                CategoryItemLabelGenerator generator = mock(CategoryItemLabelGenerator.class);
                                        
                                                when(dataset.getMeanValue(0, 0)).thenReturn(5.0);
                                                when(dataset.getStdDevValue(0, 0)).thenReturn(1.0);
                                                when(renderer.getItemLabelGenerator(0, 0)).thenReturn(generator);
                                                when(renderer.isItemLabelVisible(0, 0)).thenReturn(true);
                                                
                                                Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                    "drawHorizontalItem", Graphics2D.class, CategoryItemRendererState.class,
                                                    Rectangle2D.class, CategoryPlot.class, CategoryAxis.class, ValueAxis.class,
                                                    StatisticalCategoryDataset.class, int.class, int.class);
                                                method.setAccessible(true);
                                                
                                                method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                                
                                                verify(g2).fill(any(Rectangle2D.class));
                                            }

    @Test
                                            public void testDrawVerticalItemWithNullMeanValue() throws Exception {
                                                // Create mocks
                                                Graphics2D g2 = mock(Graphics2D.class);
                                                CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                Rectangle2D dataArea = mock(Rectangle2D.class);
                                                CategoryPlot plot = mock(CategoryPlot.class);
                                                CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                ValueAxis rangeAxis = mock(ValueAxis.class);
                                                StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                        
                                                // Stub methods
                                                when(dataset.getMeanValue(0, 0)).thenReturn(null);
                                                when(state.getBarWidth()).thenReturn(10.0);
                                                when(plot.getDomainAxisEdge()).thenReturn(null);
                                                when(dataArea.getWidth()).thenReturn(100.0);
                                                
                                                Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                    "drawVerticalItem", 
                                                    Graphics2D.class, 
                                                    CategoryItemRendererState.class, 
                                                    Rectangle2D.class, 
                                                    CategoryPlot.class, 
                                                    CategoryAxis.class, 
                                                    ValueAxis.class, 
                                                    StatisticalCategoryDataset.class, 
                                                    int.class, 
                                                    int.class
                                                );
                                                method.setAccessible(true);
                                                method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                                
                                                verify(g2, never()).fill(any(Rectangle2D.class));
                                            }

    @Test
                                            public void testDrawVerticalItemWithBarOutline() throws Exception {
                                                // Create mocks
                                                StatisticalBarRenderer renderer = mock(StatisticalBarRenderer.class);
                                                Graphics2D g2 = mock(Graphics2D.class);
                                                CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                Rectangle2D dataArea = mock(Rectangle2D.class);
                                                CategoryPlot plot = mock(CategoryPlot.class);
                                                CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                ValueAxis rangeAxis = mock(ValueAxis.class);
                                                StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                        
                                                // Stub methods
                                                when(dataset.getMeanValue(0, 0)).thenReturn(10.0);
                                                when(state.getBarWidth()).thenReturn(5.0);
                                                when(renderer.isDrawBarOutline()).thenReturn(true);
                                                when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class)))
                                                    .thenReturn(100.0);
                                                when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                when(domainAxis.getCategoryStart(anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class)))
                                                    .thenReturn(50.0);
                                                when(renderer.getRowCount()).thenReturn(1);
                                                when(renderer.getColumnCount()).thenReturn(1);
                                                when(renderer.getLowerClip()).thenReturn(0.0);
                                                when(renderer.getUpperClip()).thenReturn(20.0);
                                                
                                                Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                    "drawVerticalItem", 
                                                    Graphics2D.class, 
                                                    CategoryItemRendererState.class, 
                                                    Rectangle2D.class, 
                                                    CategoryPlot.class, 
                                                    CategoryAxis.class, 
                                                    ValueAxis.class, 
                                                    StatisticalCategoryDataset.class, 
                                                    int.class, 
                                                    int.class
                                                );
                                                method.setAccessible(true);
                                                method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                                
                                                verify(g2).draw(any(Rectangle2D.class));
                                            }

    @Test
                                            public void testDrawVerticalItemWithEntityCollection() throws Exception {
                                                // Create all mock objects needed for the test
                                                StatisticalBarRenderer renderer = mock(StatisticalBarRenderer.class);
                                                Graphics2D g2 = mock(Graphics2D.class);
                                                CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                Rectangle2D dataArea = mock(Rectangle2D.class);
                                                CategoryPlot plot = mock(CategoryPlot.class);
                                                CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                ValueAxis rangeAxis = mock(ValueAxis.class);
                                                StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                EntityCollection entityCollection = mock(EntityCollection.class);
                                        
                                                // Setup mock behavior
                                                when(dataset.getMeanValue(0, 0)).thenReturn(10.0);
                                                when(state.getEntityCollection()).thenReturn(entityCollection);
                                                when(state.getBarWidth()).thenReturn(10.0);
                                                when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class)))
                                                    .thenReturn(100.0);
                                                when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                
                                                // Use reflection to access private method
                                                Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                    "drawVerticalItem", 
                                                    Graphics2D.class, 
                                                    CategoryItemRendererState.class, 
                                                    Rectangle2D.class, 
                                                    CategoryPlot.class, 
                                                    CategoryAxis.class, 
                                                    ValueAxis.class, 
                                                    StatisticalCategoryDataset.class, 
                                                    int.class, 
                                                    int.class
                                                );
                                                method.setAccessible(true);
                                                method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                                
                                                // Verify interactions
                                                verify(entityCollection).add(any());
                                            }

    @Test
                                            public void testDrawVerticalItemWithMultipleSeries() throws Exception {
                                                // Create mocks
                                                StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                StatisticalBarRenderer renderer = mock(StatisticalBarRenderer.class);
                                                Graphics2D g2 = mock(Graphics2D.class);
                                                CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                Rectangle2D dataArea = mock(Rectangle2D.class);
                                                CategoryPlot plot = mock(CategoryPlot.class);
                                                CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                ValueAxis rangeAxis = mock(ValueAxis.class);
                                                
                                                // Stub methods
                                                when(dataset.getMeanValue(0, 0)).thenReturn(10.0);
                                                when(renderer.getRowCount()).thenReturn(2);
                                                when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class)))
                                                    .thenReturn(100.0);
                                                when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                when(state.getBarWidth()).thenReturn(10.0);
                                                when(dataArea.getWidth()).thenReturn(100.0);
                                                when(domainAxis.getCategoryStart(anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class)))
                                                    .thenReturn(50.0);
                                                
                                                Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                    "drawVerticalItem", 
                                                    Graphics2D.class, 
                                                    CategoryItemRendererState.class, 
                                                    Rectangle2D.class, 
                                                    CategoryPlot.class, 
                                                    CategoryAxis.class, 
                                                    ValueAxis.class, 
                                                    StatisticalCategoryDataset.class, 
                                                    int.class, 
                                                    int.class
                                                );
                                                method.setAccessible(true);
                                                method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                                
                                                verify(domainAxis).getCategoryStart(anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class));
                                            }

    @Test
                                        public void testDrawVerticalItemWithCustomErrorIndicator() throws Exception {
                                            StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                            Graphics2D g2 = mock(Graphics2D.class);
                                            CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                            Rectangle2D dataArea = mock(Rectangle2D.class);
                                            CategoryPlot plot = mock(CategoryPlot.class);
                                            CategoryAxis domainAxis = mock(CategoryAxis.class);
                                            ValueAxis rangeAxis = mock(ValueAxis.class);
                                            StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                            
                                            renderer.setErrorIndicatorPaint(Color.RED);
                                            renderer.setErrorIndicatorStroke(new BasicStroke(2.0f));
                                            
                                            when(dataset.getMeanValue(0, 0)).thenReturn(10.0);
                                            when(dataset.getStdDevValue(0, 0)).thenReturn(2.0);
                                            when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class)))
                                                .thenReturn(100.0);
                                            when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                            when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                            when(state.getBarWidth()).thenReturn(10.0);
                                            when(dataArea.getWidth()).thenReturn(100.0);
                                            
                                            Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                "drawVerticalItem", 
                                                Graphics2D.class, 
                                                CategoryItemRendererState.class, 
                                                Rectangle2D.class, 
                                                CategoryPlot.class, 
                                                CategoryAxis.class, 
                                                ValueAxis.class, 
                                                StatisticalCategoryDataset.class, 
                                                int.class, 
                                                int.class
                                            );
                                            method.setAccessible(true);
                                            method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                            
                                            verify(g2).setPaint(Color.RED);
                                            verify(g2).setStroke(any(BasicStroke.class));
                                        }

    @Test
                                    public void testDrawVerticalItemWithItemLabel() throws Exception {
                                        // Create mocks
                                        StatisticalBarRenderer renderer = mock(StatisticalBarRenderer.class);
                                        Graphics2D g2 = mock(Graphics2D.class);
                                        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                        Rectangle2D dataArea = mock(Rectangle2D.class);
                                        CategoryPlot plot = mock(CategoryPlot.class);
                                        CategoryAxis domainAxis = mock(CategoryAxis.class);
                                        ValueAxis rangeAxis = mock(ValueAxis.class);
                                        StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                        
                                        // Stub methods
                                        when(dataset.getMeanValue(0, 0)).thenReturn(10.0);
                                        when(renderer.getItemLabelGenerator(0, 0)).thenReturn(mock(CategoryItemLabelGenerator.class));
                                        when(renderer.isItemLabelVisible(0, 0)).thenReturn(true);
                                        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class)))
                                            .thenReturn(100.0);
                                        when(state.getBarWidth()).thenReturn(10.0);
                                        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                        when(domainAxis.getCategoryStart(anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class)))
                                            .thenReturn(50.0);
                                        
                                        Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                            "drawVerticalItem", 
                                            Graphics2D.class, 
                                            CategoryItemRendererState.class, 
                                            Rectangle2D.class, 
                                            CategoryPlot.class, 
                                            CategoryAxis.class, 
                                            ValueAxis.class, 
                                            StatisticalCategoryDataset.class, 
                                            int.class, 
                                            int.class
                                        );
                                        method.setAccessible(true);
                                        method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                        
                                        // Use reflection to verify protected method
                                        Method drawItemLabelMethod = BarRenderer.class.getDeclaredMethod(
                                            "drawItemLabel",
                                            Graphics2D.class,
                                            StatisticalCategoryDataset.class,
                                            int.class,
                                            int.class,
                                            CategoryPlot.class,
                                            CategoryItemLabelGenerator.class,
                                            Rectangle2D.class,
                                            boolean.class
                                        );
                                        drawItemLabelMethod.setAccessible(true);
                                        
                                        // Verify using reflection
                                        drawItemLabelMethod.invoke(
                                            verify(renderer, times(1)),
                                            any(Graphics2D.class),
                                            any(StatisticalCategoryDataset.class),
                                            anyInt(),
                                            anyInt(),
                                            any(CategoryPlot.class),
                                            any(CategoryItemLabelGenerator.class),
                                            any(Rectangle2D.class),
                                            anyBoolean()
                                        );
                                    }

    @Test
                            public void testDrawHorizontalItemWithNegativeValue() throws Exception {
                                StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                Graphics2D g2 = mock(Graphics2D.class);
                                CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                Rectangle2D dataArea = mock(Rectangle2D.class);
                                CategoryPlot plot = mock(CategoryPlot.class);
                                CategoryAxis domainAxis = mock(CategoryAxis.class);
                                ValueAxis rangeAxis = mock(ValueAxis.class);
                                StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                
                                when(state.getBarWidth()).thenReturn(10.0);
                                when(dataset.getMeanValue(0, 0)).thenReturn(-5.0);
                                when(dataset.getStdDevValue(0, 0)).thenReturn(1.0);
                                when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                when(domainAxis.getCategoryStart(anyInt(), anyInt(), any(Rectangle2D.class), any()))
                                    .thenReturn(50.0);
                                when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any()))
                                    .thenReturn(100.0);
                                
                                Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                    "drawHorizontalItem", Graphics2D.class, CategoryItemRendererState.class,
                                    Rectangle2D.class, CategoryPlot.class, CategoryAxis.class, ValueAxis.class,
                                    StatisticalCategoryDataset.class, int.class, int.class);
                                method.setAccessible(true);
                                
                                method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                
                                verify(g2).fill(any(Rectangle2D.class));
                            }

    @Test
            public void testDrawHorizontalItemWithUpperClip() throws Exception {
                StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                Graphics2D g2 = mock(Graphics2D.class);
                CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                Rectangle2D dataArea = mock(Rectangle2D.class);
                CategoryPlot plot = mock(CategoryPlot.class);
                CategoryAxis domainAxis = mock(CategoryAxis.class);
                ValueAxis rangeAxis = mock(ValueAxis.class);
        
                when(dataset.getMeanValue(0, 0)).thenReturn(5.0);
                when(dataset.getStdDevValue(0, 0)).thenReturn(1.0);
                when(state.getBarWidth()).thenReturn(10.0);
                when(dataArea.getHeight()).thenReturn(100.0);
                
                Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                    "drawHorizontalItem", Graphics2D.class, CategoryItemRendererState.class,
                    Rectangle2D.class, CategoryPlot.class, CategoryAxis.class, ValueAxis.class,
                    StatisticalCategoryDataset.class, int.class, int.class);
                method.setAccessible(true);
                
                method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                
                verify(g2).fill(any(Rectangle2D.class));
            }

    @Test
            public void testDrawHorizontalItemWithLowerClip() throws Exception {
                StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                Graphics2D g2 = mock(Graphics2D.class);
                CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
                CategoryPlot plot = mock(CategoryPlot.class);
                CategoryAxis domainAxis = mock(CategoryAxis.class);
                ValueAxis rangeAxis = mock(ValueAxis.class);
                RectangleEdge leftEdge = RectangleEdge.LEFT;
                RectangleEdge bottomEdge = RectangleEdge.BOTTOM;
        
                when(dataset.getMeanValue(0, 0)).thenReturn(-5.0);
                when(dataset.getStdDevValue(0, 0)).thenReturn(1.0);
                when(state.getBarWidth()).thenReturn(10.0);
                when(plot.getDomainAxisEdge()).thenReturn(leftEdge);
                when(plot.getRangeAxisEdge()).thenReturn(bottomEdge);
                
                
                Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                    "drawHorizontalItem", Graphics2D.class, CategoryItemRendererState.class,
                    Rectangle2D.class, CategoryPlot.class, CategoryAxis.class, ValueAxis.class,
                    StatisticalCategoryDataset.class, int.class, int.class);
                method.setAccessible(true);
                
                method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                
                verify(g2).fill(any(Rectangle2D.class));
            }

    @Test
            public void testDrawVerticalItemWithStandardDeviation() throws Exception {
                StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                Graphics2D g2 = mock(Graphics2D.class);
                CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
                CategoryPlot plot = mock(CategoryPlot.class);
                CategoryAxis domainAxis = mock(CategoryAxis.class);
                ValueAxis rangeAxis = mock(ValueAxis.class);
                StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                
                when(state.getBarWidth()).thenReturn(10.0);
                when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                when(dataset.getMeanValue(0, 0)).thenReturn(10.0);
                when(dataset.getStdDevValue(0, 0)).thenReturn(2.0);
                when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class)))
                    .thenReturn(100.0);
                
                Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                    "drawVerticalItem", 
                    Graphics2D.class, 
                    CategoryItemRendererState.class, 
                    Rectangle2D.class, 
                    CategoryPlot.class, 
                    CategoryAxis.class, 
                    ValueAxis.class, 
                    StatisticalCategoryDataset.class, 
                    int.class, 
                    int.class
                );
                method.setAccessible(true);
                method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                
                org.mockito.ArgumentCaptor<Line2D> lineCaptor = org.mockito.ArgumentCaptor.forClass(Line2D.class);
                verify(g2, atLeast(3)).draw(lineCaptor.capture());
                assertEquals(3, lineCaptor.getAllValues().size());
            }

    @Test
        public void testDrawVerticalItemWithVisibleBar() throws Exception {
            // Create mocks
            StatisticalBarRenderer renderer = new StatisticalBarRenderer();
            Graphics2D g2 = mock(Graphics2D.class);
            CategoryItemRendererState state = mock(CategoryItemRendererState.class);
            Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
            CategoryPlot plot = mock(CategoryPlot.class);
            CategoryAxis domainAxis = mock(CategoryAxis.class);
            ValueAxis rangeAxis = mock(ValueAxis.class);
            StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
        
            // Setup mock behavior
            when(dataset.getMeanValue(0, 0)).thenReturn(10.0);
            when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class)))
                .thenReturn(100.0);
            when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
            when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
            when(state.getBarWidth()).thenReturn(10.0);
            
            // Get and invoke private method
            Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                "drawVerticalItem", 
                Graphics2D.class, 
                CategoryItemRendererState.class, 
                Rectangle2D.class, 
                CategoryPlot.class, 
                CategoryAxis.class, 
                ValueAxis.class, 
                StatisticalCategoryDataset.class, 
                int.class, 
                int.class
            );
            method.setAccessible(true);
            Object result = method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
            
            // Verify
            assertNotNull(result);
        }


}
