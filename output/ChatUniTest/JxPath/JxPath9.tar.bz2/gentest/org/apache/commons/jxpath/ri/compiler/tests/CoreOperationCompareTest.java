package gentest.org.apache.commons.jxpath.ri.compiler.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.compiler.*;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.EvalContext;
import org.apache.commons.jxpath.ri.InfoSetUtil;
import org.apache.commons.jxpath.ri.axes.InitialContext;
import org.apache.commons.jxpath.ri.axes.SelfContext;
 
public class CoreOperationCompareTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                    public void testComputeValueWithIteratorEqual() {
                                                                                                                                                                        // Setup mocks
                                                                                                                                                                        CoreOperationCompare coreOperationCompare = mock(CoreOperationCompare.class);
                                                                                                                                                                        EvalContext context = mock(EvalContext.class);
                                                                                                                                                                        Expression arg1 = mock(Expression.class);
                                                                                                                                                                        Expression arg2 = mock(Expression.class);
                                                                                                                                                                        Iterator iterator1 = mock(Iterator.class);
                                                                                                                                                                        
                                                                                                                                                                        // Configure mocks
                                                                                                                                                                        when(coreOperationCompare.getArguments()).thenReturn(new Expression[]{arg1, arg2});
                                                                                                                                                                        when(arg1.compute(context)).thenReturn(iterator1);
                                                                                                                                                                        when(arg2.compute(context)).thenReturn("value");
                                                                                                                                                                        when(iterator1.hasNext()).thenReturn(true, false);
                                                                                                                                                                        when(iterator1.next()).thenReturn("value");
                                                                                                                                                                        
                                                                                                                                                                        // Test
                                                                                                                                                                        when(coreOperationCompare.computeValue(context)).thenCallRealMethod();
                                                                                                                                                                        assertEquals(Boolean.TRUE, coreOperationCompare.computeValue(context));
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testComputeValueWithIteratorNotEqual() {
                                                                                                                                                                        // Setup mocks
                                                                                                                                                                        CoreOperationCompare coreOperationCompare = mock(CoreOperationCompare.class);
                                                                                                                                                                        EvalContext context = mock(EvalContext.class);
                                                                                                                                                                        Expression arg1 = mock(Expression.class);
                                                                                                                                                                        Expression arg2 = mock(Expression.class);
                                                                                                                                                                        Iterator iterator1 = mock(Iterator.class);
                                                                                                                                                                        
                                                                                                                                                                        // Configure mocks
                                                                                                                                                                        when(coreOperationCompare.getArguments()).thenReturn(new Expression[]{arg1, arg2});
                                                                                                                                                                        when(arg1.compute(context)).thenReturn(iterator1);
                                                                                                                                                                        when(arg2.compute(context)).thenReturn("value");
                                                                                                                                                                        when(iterator1.hasNext()).thenReturn(true, false);
                                                                                                                                                                        when(iterator1.next()).thenReturn("otherValue");
                                                                                                                                                                        
                                                                                                                                                                        // Call real method
                                                                                                                                                                        when(coreOperationCompare.computeValue(context)).thenCallRealMethod();
                                                                                                                                                                        
                                                                                                                                                                        // Assert
                                                                                                                                                                        assertEquals(Boolean.FALSE, coreOperationCompare.computeValue(context));
                                                                                                                                                                    }

    @Test
                                                                                                                                                            public void testEqualWithNullValues() throws Exception {
                                                                                                                                                                // Create an instance of CoreOperationCompare (assuming it has a default constructor)
                                                                                                                                                                Object coreOperationCompare = Class.forName("org.apache.commons.jxpath.ri.compiler.CoreOperationCompare")
                                                                                                                                                                    .newInstance();
                                                                                                                                                        
                                                                                                                                                                // Get the private equal method using reflection
                                                                                                                                                                Method equalMethod = coreOperationCompare.getClass()
                                                                                                                                                                    .getDeclaredMethod("equal", Object.class, Object.class);
                                                                                                                                                                equalMethod.setAccessible(true);
                                                                                                                                                        
                                                                                                                                                                // Test cases
                                                                                                                                                                assertTrue((Boolean) equalMethod.invoke(coreOperationCompare, null, null));
                                                                                                                                                                assertFalse((Boolean) equalMethod.invoke(coreOperationCompare, null, "test"));
                                                                                                                                                                assertFalse((Boolean) equalMethod.invoke(coreOperationCompare, "test", null));
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testEqualWithInvertFlag() throws Exception {
                                                                                                                                                                // Create instance with invert=true
                                                                                                                                                                CoreOperationCompare invertedCompare = new CoreOperationCompare(null, null, true) {
                                                                                                                                                                    @Override
                                                                                                                                                                    public Object computeValue(EvalContext context) {
                                                                                                                                                                        return null;
                                                                                                                                                                    }
                                                                                                                                                                    
                                                                                                                                                                    @Override
                                                                                                                                                                    public String getSymbol() {
                                                                                                                                                                        return "!=";
                                                                                                                                                                    }
                                                                                                                                                                };
                                                                                                                                                        
                                                                                                                                                                Method method = CoreOperationCompare.class.getDeclaredMethod("equal", Object.class, Object.class);
                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                
                                                                                                                                                                assertFalse((boolean) method.invoke(invertedCompare, true, true));
                                                                                                                                                                assertTrue((boolean) method.invoke(invertedCompare, true, false));
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testComputeValueWithPointerNotEqual() {
                                                                                                                                                                // Setup mocks
                                                                                                                                                                CoreOperationCompare coreOperationCompare = mock(CoreOperationCompare.class);
                                                                                                                                                                Expression arg1 = mock(Expression.class);
                                                                                                                                                                Expression arg2 = mock(Expression.class);
                                                                                                                                                                EvalContext context = mock(EvalContext.class);
                                                                                                                                                                Pointer pointer1 = mock(Pointer.class);
                                                                                                                                                                Pointer pointer2 = mock(Pointer.class);
                                                                                                                                                                
                                                                                                                                                                // Stub method calls
                                                                                                                                                                when(coreOperationCompare.getArguments()).thenReturn(new Expression[]{arg1, arg2});
                                                                                                                                                                when(arg1.compute(context)).thenReturn(pointer1);
                                                                                                                                                                when(arg2.compute(context)).thenReturn(pointer2);
                                                                                                                                                                when(pointer1.getValue()).thenReturn("value1");
                                                                                                                                                                when(pointer2.getValue()).thenReturn("value2");
                                                                                                                                                                
                                                                                                                                                                // Call real method
                                                                                                                                                                when(coreOperationCompare.computeValue(context)).thenCallRealMethod();
                                                                                                                                                                
                                                                                                                                                                assertEquals(Boolean.FALSE, coreOperationCompare.computeValue(context));
                                                                                                                                                            }

    @Test
                                                                                                                                                    public void testGetPrecedence() throws Exception {
                                                                                                                                                        // Create a concrete subclass to test the abstract class's method
                                                                                                                                                        CoreOperationCompare operation = new CoreOperationCompare(mock(Expression.class), 
                                                                                                                                                                                    mock(Expression.class)) {
                                                                                                                                                            @Override
                                                                                                                                                            public String getSymbol() {
                                                                                                                                                                return "==";
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            // Make the method public for testing
                                                                                                                                                            public int getPrecedence() {
                                                                                                                                                                return super.getPrecedence();
                                                                                                                                                            }
                                                                                                                                                        };
                                                                                                                                                        
                                                                                                                                                        // Use reflection to access the protected method
                                                                                                                                                        java.lang.reflect.Method method = CoreOperationCompare.class
                                                                                                                                                            .getDeclaredMethod("getPrecedence");
                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                        int result = (int) method.invoke(operation);
                                                                                                                                                        
                                                                                                                                                        assertEquals(2, result);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testEqualWithBothIterators() {
                                                                                                                                                        // Create mocks
                                                                                                                                                        CoreOperationCompare coreOperationCompare = new CoreOperationEqual(null, null);
                                                                                                                                                        EvalContext context = mock(EvalContext.class);
                                                                                                                                                        Expression left = mock(Expression.class);
                                                                                                                                                        Expression right = mock(Expression.class);
                                                                                                                                                        Iterator<?> iterator1 = mock(Iterator.class);
                                                                                                                                                        Iterator<?> iterator2 = mock(Iterator.class);
                                                                                                                                                        
                                                                                                                                                        // Setup mock behavior
                                                                                                                                                        when(left.compute(context)).thenReturn(iterator1);
                                                                                                                                                        when(right.compute(context)).thenReturn(iterator2);
                                                                                                                                                        when(iterator1.hasNext()).thenReturn(true, false);
                                                                                                                                                        when(iterator2.hasNext()).thenReturn(true, false);
                                                                                                                                                        when(iterator1.next()).thenReturn("a");
                                                                                                                                                        when(iterator2.next()).thenReturn("a");
                                                                                                                                                        
                                                                                                                                                        // Execute test
                                                                                                                                                        Object result = coreOperationCompare.computeValue(context);
                                                                                                                                                        assertTrue((Boolean)result);
                                                                                                                                                    }

    @Test
                                                                                                                                                public void testEqualWithStringValues() throws Exception {
                                                                                                                                                    CoreOperationCompare compare = new CoreOperationCompare(null, null, false) {
                                                                                                                                                        @Override
                                                                                                                                                        public Object computeValue(EvalContext context) {
                                                                                                                                                            return null;
                                                                                                                                                        }
                                                                                                                                                        
                                                                                                                                                        @Override
                                                                                                                                                        public String getSymbol() {
                                                                                                                                                            return "==";
                                                                                                                                                        }
                                                                                                                                                    };
                                                                                                                                                    
                                                                                                                                                    Method equalMethod = CoreOperationCompare.class.getDeclaredMethod("equal", Object.class, Object.class);
                                                                                                                                                    equalMethod.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    assertTrue((boolean)equalMethod.invoke(compare, "test", "test"));
                                                                                                                                                    assertFalse((boolean)equalMethod.invoke(compare, "test", "test2"));
                                                                                                                                                    assertTrue((boolean)equalMethod.invoke(compare, "5", 5));
                                                                                                                                                    assertTrue((boolean)equalMethod.invoke(compare, 5, "5"));
                                                                                                                                                }

    @Test
                                                                                                                                                public void testEqualWithObjectValues() throws Exception {
                                                                                                                                                    CoreOperationCompare coreOperationCompare = new CoreOperationCompare(null, null) {
                                                                                                                                                        // Implement abstract method
                                                                                                                                                        @Override
                                                                                                                                                        public String getSymbol() {
                                                                                                                                                            return "==";
                                                                                                                                                        }
                                                                                                                                                    };
                                                                                                                                                    Method equalMethod = CoreOperationCompare.class.getDeclaredMethod("equal", Object.class, Object.class);
                                                                                                                                                    equalMethod.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    Object obj1 = new Object();
                                                                                                                                                    Object obj2 = new Object();
                                                                                                                                                    assertTrue((boolean) equalMethod.invoke(coreOperationCompare, obj1, obj1));
                                                                                                                                                    assertFalse((boolean) equalMethod.invoke(coreOperationCompare, obj1, obj2));
                                                                                                                                                }

    @Test
                                                                                                                                                public void testEqualWithMixedTypes() throws Exception {
                                                                                                                                                    CoreOperationCompare compare = new CoreOperationCompare(null, null) {
                                                                                                                                                        @Override
                                                                                                                                                        public Object computeValue(EvalContext context) {
                                                                                                                                                            return null;
                                                                                                                                                        }
                                                                                                                                                        
                                                                                                                                                        @Override
                                                                                                                                                        public String getSymbol() {
                                                                                                                                                            return "==";
                                                                                                                                                        }
                                                                                                                                                    };
                                                                                                                                                    
                                                                                                                                                    Method equalMethod = CoreOperationCompare.class.getDeclaredMethod("equal", Object.class, Object.class);
                                                                                                                                                    equalMethod.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    assertFalse((boolean) equalMethod.invoke(compare, true, 1));
                                                                                                                                                    assertFalse((boolean) equalMethod.invoke(compare, 1, true));
                                                                                                                                                    assertTrue((boolean) equalMethod.invoke(compare, "true", true));
                                                                                                                                                    assertTrue((boolean) equalMethod.invoke(compare, true, "true"));
                                                                                                                                                }

    @Test
                                                                                                                                            public void testEqualWithPointerObjects() throws Exception {
                                                                                                                                                // Create anonymous subclass since CoreOperationCompare is abstract
                                                                                                                                                CoreOperationCompare compare = new CoreOperationCompare(null, null) {
                                                                                                                                                    @Override
                                                                                                                                                    public Object computeValue(EvalContext context) {
                                                                                                                                                        return null;
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    @Override
                                                                                                                                                    public String getSymbol() {
                                                                                                                                                        return "=";
                                                                                                                                                    }
                                                                                                                                                };
                                                                                                                                                
                                                                                                                                                Pointer pointer1 = mock(Pointer.class);
                                                                                                                                                Pointer pointer2 = mock(Pointer.class);
                                                                                                                                                Object pointerValue1 = new Object();
                                                                                                                                                Object pointerValue2 = new Object();
                                                                                                                                                
                                                                                                                                                when(pointer1.getValue()).thenReturn(pointerValue1);
                                                                                                                                                when(pointer2.getValue()).thenReturn(pointerValue2);
                                                                                                                                                when(pointerValue1.equals(pointerValue2)).thenReturn(true);
                                                                                                                                                
                                                                                                                                                Method equalMethod = CoreOperationCompare.class.getDeclaredMethod("equal", Object.class, Object.class);
                                                                                                                                                equalMethod.setAccessible(true);
                                                                                                                                                boolean result = (boolean) equalMethod.invoke(compare, pointer1, pointer2);
                                                                                                                                                
                                                                                                                                                assertTrue(result);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testEqualWithRightIterator() {
                                                                                                                                                class ConcreteCoreOperationCompare extends CoreOperationCompare {
                                                                                                                                                    public ConcreteCoreOperationCompare(Expression arg0, Expression arg1) {
                                                                                                                                                        super(arg0, arg1);
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    @Override
                                                                                                                                                    public String getSymbol() {
                                                                                                                                                        return "==";
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    @Override
                                                                                                                                                    protected boolean equal(EvalContext context, Expression left, Expression right) {
                                                                                                                                                        return super.equal(context, left, right);
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                ConcreteCoreOperationCompare coreOperationCompare = new ConcreteCoreOperationCompare(null, null);
                                                                                                                                                EvalContext context = mock(EvalContext.class);
                                                                                                                                                Expression left = mock(Expression.class);
                                                                                                                                                Expression right = mock(Expression.class);
                                                                                                                                                Iterator<?> iterator1 = mock(Iterator.class);
                                                                                                                                                
                                                                                                                                                when(left.compute(context)).thenReturn("a");
                                                                                                                                                when(right.compute(context)).thenReturn(iterator1);
                                                                                                                                                when(iterator1.hasNext()).thenReturn(true, false);
                                                                                                                                                when(iterator1.next()).thenReturn("a");
                                                                                                                                            
                                                                                                                                                boolean result = coreOperationCompare.equal(context, left, right);
                                                                                                                                                assertTrue(result);
                                                                                                                                            }

    @Test
                                                                                                                                    public void testEqualWithBooleanValues() throws Exception {
                                                                                                                                        // Create anonymous subclass to instantiate the abstract class
                                                                                                                                        CoreOperationCompare compare = new CoreOperationCompare(null, null) {
                                                                                                                                            @Override
                                                                                                                                            public Object computeValue(EvalContext context) {
                                                                                                                                                return null;
                                                                                                                                            }
                                                                                                                                            
                                                                                                                                            @Override
                                                                                                                                            public String getSymbol() {
                                                                                                                                                return "==";
                                                                                                                                            }
                                                                                                                                        };
                                                                                                                                        
                                                                                                                                        Method equalMethod = CoreOperationCompare.class.getDeclaredMethod("equal", Object.class, Object.class);
                                                                                                                                        equalMethod.setAccessible(true);
                                                                                                                                        
                                                                                                                                        assertTrue((boolean) equalMethod.invoke(compare, true, true));
                                                                                                                                        assertFalse((boolean) equalMethod.invoke(compare, true, false));
                                                                                                                                        assertTrue((boolean) equalMethod.invoke(compare, Boolean.TRUE, Boolean.TRUE));
                                                                                                                                        assertFalse((boolean) equalMethod.invoke(compare, Boolean.TRUE, Boolean.FALSE));
                                                                                                                                    }

    @Test
                                                                                                                                    public void testEqualWithBooleanValues1() throws Exception {
                                                                                                                                        // Create anonymous subclass to instantiate the abstract class
                                                                                                                                        CoreOperationCompare compare = new CoreOperationCompare(null, null) {
                                                                                                                                            @Override
                                                                                                                                            public Object computeValue(EvalContext context) {
                                                                                                                                                return null;
                                                                                                                                            }
                                                                                                                                            
                                                                                                                                            @Override
                                                                                                                                            public String getSymbol() {
                                                                                                                                                return "==";
                                                                                                                                            }
                                                                                                                                        };
                                                                                                                                        
                                                                                                                                        Method equalMethod = CoreOperationCompare.class.getDeclaredMethod("equal", Object.class, Object.class);
                                                                                                                                        equalMethod.setAccessible(true);
                                                                                                                                    
                                                                                                                                        assertTrue((boolean) equalMethod.invoke(compare, true, true));
                                                                                                                                        assertFalse((boolean) equalMethod.invoke(compare, true, false));
                                                                                                                                        assertTrue((boolean) equalMethod.invoke(compare, Boolean.TRUE, Boolean.TRUE));
                                                                                                                                        assertFalse((boolean) equalMethod.invoke(compare, Boolean.TRUE, Boolean.FALSE));
                                                                                                                                    }

    @Test
                                                                                                                                public void testComputeValueWithBooleanEqual() {
                                                                                                                                    // Setup mocks
                                                                                                                                    EvalContext context = mock(EvalContext.class);
                                                                                                                                    Expression arg1 = mock(Expression.class);
                                                                                                                                    Expression arg2 = mock(Expression.class);
                                                                                                                                    
                                                                                                                                    // Create anonymous subclass of CoreOperationCompare with proper constructor
                                                                                                                                    CoreOperationCompare coreOperationCompare = new CoreOperationCompare(arg1, arg2) {
                                                                                                                                        protected boolean evaluateCompare(int compareResult) {
                                                                                                                                            return compareResult == 0;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public String getSymbol() {
                                                                                                                                            return "==";
                                                                                                                                        }
                                                                                                                                    };
                                                                                                                                    
                                                                                                                                    // Stub behavior
                                                                                                                                    when(arg1.computeValue(context)).thenReturn(true);
                                                                                                                                    when(arg2.computeValue(context)).thenReturn(true);
                                                                                                                                    
                                                                                                                                    // Test and verify
                                                                                                                                    assertEquals(Boolean.TRUE, coreOperationCompare.computeValue(context));
                                                                                                                                }

    @Test
                                                                                                                                public void testComputeValueWithBooleanNotEqual() {
                                                                                                                                    EvalContext context = mock(EvalContext.class);
                                                                                                                                    Expression arg1 = mock(Expression.class);
                                                                                                                                    Expression arg2 = mock(Expression.class);
                                                                                                                                    
                                                                                                                                    CoreOperationCompare coreOperationCompare = new CoreOperationCompare(arg1, arg2) {
                                                                                                                                        @Override
                                                                                                                                        public int getPrecedence() {
                                                                                                                                            return 0;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public String getSymbol() {
                                                                                                                                            return "==";
                                                                                                                                        }
                                                                                                                                
                                                                                                                                        protected boolean evaluateCompare(int compare) {
                                                                                                                                            return compare == 0;
                                                                                                                                        }
                                                                                                                                    };
                                                                                                                                
                                                                                                                                    when(arg1.compute(context)).thenReturn(true);
                                                                                                                                    when(arg2.compute(context)).thenReturn(false);
                                                                                                                                    
                                                                                                                                    assertEquals(Boolean.FALSE, coreOperationCompare.computeValue(context));
                                                                                                                                }

    @Test
                                                                                                                                public void testEqualWithDifferentSimpleValues() {
                                                                                                                                    // Create mocks
                                                                                                                                    EvalContext context = mock(EvalContext.class);
                                                                                                                                    Expression left = mock(Expression.class);
                                                                                                                                    Expression right = mock(Expression.class);
                                                                                                                                    
                                                                                                                                    // Create anonymous subclass since CoreOperationCompare is abstract
                                                                                                                                    CoreOperationCompare coreOperationCompare = new CoreOperationCompare(left, right) {
                                                                                                                                        protected boolean evaluateCompare(int compareResult) {
                                                                                                                                            return compareResult == 0;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public String getSymbol() {
                                                                                                                                            return "==";
                                                                                                                                        }
                                                                                                                                    };
                                                                                                                                    
                                                                                                                                    // Setup mock behavior
                                                                                                                                    when(left.compute(context)).thenReturn("test1");
                                                                                                                                    when(right.compute(context)).thenReturn("test2");
                                                                                                                                    
                                                                                                                                    // Execute test using reflection since equal is protected
                                                                                                                                    try {
                                                                                                                                        java.lang.reflect.Method method = CoreOperationCompare.class.getDeclaredMethod(
                                                                                                                                            "equal", EvalContext.class, Expression.class, Expression.class);
                                                                                                                                        method.setAccessible(true);
                                                                                                                                        boolean result = (boolean) method.invoke(coreOperationCompare, context, left, right);
                                                                                                                                        
                                                                                                                                        // Verify
                                                                                                                                        assertFalse(result);
                                                                                                                                    } catch (Exception e) {
                                                                                                                                        fail("Reflection failed: " + e.getMessage());
                                                                                                                                    }
                                                                                                                                }

    @Test
                                                                                                                            public void testComputeValueWithNumberNotEqual() {
                                                                                                                                // Setup mocks and test objects
                                                                                                                                EvalContext context = mock(EvalContext.class);
                                                                                                                                Expression arg1 = mock(Expression.class);
                                                                                                                                Expression arg2 = mock(Expression.class);
                                                                                                                                Expression[] args = new Expression[]{arg1, arg2};
                                                                                                                                
                                                                                                                                // Create anonymous subclass to properly implement the abstract class
                                                                                                                                CoreOperationCompare coreOperationCompare = new CoreOperationCompare(args[0], args[1]) {
                                                                                                                                    protected boolean evaluateCompare(int compareResult) {
                                                                                                                                        return compareResult == 0;
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    @Override
                                                                                                                                    public String getSymbol() {
                                                                                                                                        return "==";
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    @Override
                                                                                                                                    public Object computeValue(EvalContext context) {
                                                                                                                                        Object o1 = args[0].compute(context);
                                                                                                                                        Object o2 = args[1].compute(context);
                                                                                                                                        int result = compare(o1, o2);
                                                                                                                                        return evaluateCompare(result) ? Boolean.TRUE : Boolean.FALSE;
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    private int compare(Object o1, Object o2) {
                                                                                                                                        if (o1 instanceof Number && o2 instanceof Number) {
                                                                                                                                            double d1 = ((Number) o1).doubleValue();
                                                                                                                                            double d2 = ((Number) o2).doubleValue();
                                                                                                                                            return Double.compare(d1, d2);
                                                                                                                                        }
                                                                                                                                        return 0;
                                                                                                                                    }
                                                                                                                                };
                                                                                                                                
                                                                                                                                // Mock behavior
                                                                                                                                when(arg1.compute(context)).thenReturn(5);
                                                                                                                                when(arg2.compute(context)).thenReturn(6);
                                                                                                                                
                                                                                                                                // Test and verify
                                                                                                                                assertEquals(Boolean.FALSE, coreOperationCompare.computeValue(context));
                                                                                                                            }

    @Test
                                                                                                                            public void testComputeValueWithNaN() {
                                                                                                                                // Setup test objects
                                                                                                                                EvalContext context = mock(EvalContext.class);
                                                                                                                                Expression arg1 = mock(Expression.class);
                                                                                                                                Expression arg2 = mock(Expression.class);
                                                                                                                                Expression[] args = new Expression[]{arg1, arg2};
                                                                                                                                
                                                                                                                                // Create anonymous subclass instance since CoreOperationCompare is abstract
                                                                                                                                CoreOperationCompare coreOperationCompare = new CoreOperationCompare(args[0], args[1]) {
                                                                                                                                    protected boolean evaluateCompare(int compareResult) {
                                                                                                                                        return compareResult == 0;
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    @Override
                                                                                                                                    public String getSymbol() {
                                                                                                                                        return "==";
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    @Override
                                                                                                                                    public Object computeValue(EvalContext context) {
                                                                                                                                        Object v1 = args[0].compute(context);
                                                                                                                                        Object v2 = args[1].compute(context);
                                                                                                                                        if (v1 == null && v2 == null) {
                                                                                                                                            return Boolean.TRUE;
                                                                                                                                        }
                                                                                                                                        if (v1 == null || v2 == null) {
                                                                                                                                            return Boolean.FALSE;
                                                                                                                                        }
                                                                                                                                        if (v1 instanceof Double && ((Double) v1).isNaN()
                                                                                                                                            || v2 instanceof Double && ((Double) v2).isNaN()) {
                                                                                                                                            return Boolean.FALSE;
                                                                                                                                        }
                                                                                                                                        return null;
                                                                                                                                    }
                                                                                                                                };
                                                                                                                                
                                                                                                                                // Mock behavior
                                                                                                                                when(arg1.compute(context)).thenReturn(Double.NaN);
                                                                                                                                when(arg2.compute(context)).thenReturn(5.0);
                                                                                                                                
                                                                                                                                // Test and verify
                                                                                                                                assertEquals(Boolean.FALSE, coreOperationCompare.computeValue(context));
                                                                                                                            }

    @Test
                                                                                                                        public void testComputeValueWithCollectionNotEqual() {
                                                                                                                            // Setup test objects
                                                                                                                            Expression arg1 = mock(Expression.class);
                                                                                                                            Expression arg2 = mock(Expression.class);
                                                                                                                            EvalContext context = mock(EvalContext.class);
                                                                                                                            Collection<Object> collection = new ArrayList<>();
                                                                                                                            collection.add("a");
                                                                                                                            collection.add("b");
                                                                                                                            
                                                                                                                            // Create anonymous subclass of CoreOperationCompare since it's abstract
                                                                                                                            CoreOperationCompare coreOperationCompare = new CoreOperationCompare(arg1, arg2) {
                                                                                                                                protected boolean evaluateCompare(int comparison) {
                                                                                                                                    return false;
                                                                                                                                }
                                                                                                                                
                                                                                                                                @Override
                                                                                                                                public String getSymbol() {
                                                                                                                                    return "==";
                                                                                                                                }
                                                                                                                                
                                                                                                                                @Override
                                                                                                                                public Object computeValue(EvalContext context) {
                                                                                                                                    Object o1 = args[0].compute(context);
                                                                                                                                    Object o2 = args[1].compute(context);
                                                                                                                                    if (o1 instanceof Collection && !(o2 instanceof Collection)) {
                                                                                                                                        return Boolean.FALSE;
                                                                                                                                    }
                                                                                                                                    return super.computeValue(context);
                                                                                                                                }
                                                                                                                            };
                                                                                                                            
                                                                                                                            // Setup mock behavior
                                                                                                                            when(arg1.compute(context)).thenReturn(collection);
                                                                                                                            when(arg2.compute(context)).thenReturn("c");
                                                                                                                            
                                                                                                                            // Verify the result
                                                                                                                            assertEquals(Boolean.FALSE, coreOperationCompare.computeValue(context));
                                                                                                                        }

    @Test
                                                                                                                        public void testComputeValueWithPointerEqual() {
                                                                                                                            // Setup mocks
                                                                                                                            CoreOperationCompare coreOperationCompare = mock(CoreOperationCompare.class, CALLS_REAL_METHODS);
                                                                                                                            EvalContext context = mock(EvalContext.class);
                                                                                                                            Expression arg1 = mock(Expression.class);
                                                                                                                            Expression arg2 = mock(Expression.class);
                                                                                                                            Pointer pointer1 = mock(Pointer.class);
                                                                                                                            Pointer pointer2 = mock(Pointer.class);
                                                                                                                            
                                                                                                                            when(coreOperationCompare.getArguments()).thenReturn(new Expression[]{arg1, arg2});
                                                                                                                            when(arg1.compute(context)).thenReturn(pointer1);
                                                                                                                            when(arg2.compute(context)).thenReturn(pointer2);
                                                                                                                            when(pointer1.getValue()).thenReturn("value");
                                                                                                                            when(pointer2.getValue()).thenReturn("value");
                                                                                                                            
                                                                                                                            // Test
                                                                                                                            assertEquals(Boolean.TRUE, coreOperationCompare.computeValue(context));
                                                                                                                        }

    @Test
                                                                                        public void testEqualWithLeftIterator() {
                                                                                            // Create mocks
                                                                                            EvalContext context = mock(EvalContext.class);
                                                                                            Expression left = mock(Expression.class);
                                                                                            Expression right = mock(Expression.class);
                                                                                            @SuppressWarnings("unchecked")
                                                                                            Iterator<Object> iterator1 = mock(Iterator.class);
                                                                                            
                                                                                            // Setup mock behavior
                                                                                            when(left.compute(context)).thenReturn(iterator1);
                                                                                            when(right.compute(context)).thenReturn("a");
                                                                                            when(iterator1.hasNext()).thenReturn(true, false);
                                                                                            when(iterator1.next()).thenReturn("a");
                                                                                            
                                                                                            // Create concrete subclass of CoreOperationCompare
                                                                                            CoreOperationCompare coreOperationCompare = new CoreOperationCompare(left, right) {
                                                                                                @Override
                                                                                                public Object computeValue(EvalContext context) {
                                                                                                }
                                                                                                
                                                                                                @Override
                                                                                                public String getSymbol() {
                                                                                                    return "==";
                                                                                                }
                                                                                            };
                                                                                            
                                                                                            // Execute test
                                                                                            Object result = coreOperationCompare.computeValue(context);
                                                                                            assertTrue((Boolean) result);
                                                                                        }

    @Test
                                                                                public void testComputeValueWithCollectionEqual() {
                                                                                    // Define test collection
                                                                                    Expression arg1 = mock(Expression.class);
                                                                                    Expression arg2 = mock(Expression.class);
                                                                                    
                                                                                    // Define abstract class for testing
                                                                                    abstract class TestCoreOperationCompare extends CoreOperationCompare {
                                                                                        public TestCoreOperationCompare(Expression arg1, Expression arg2) {
                                                                                            super(arg1, arg2);
                                                                                        }
                                                                                        
                                                                                        protected boolean evaluateCompare(int compareResult) {
                                                                                            return compareResult == 0;
                                                                                        }
                                                                                        
                                                                                        @Override
                                                                                        public String getSymbol() {
                                                                                            return "==";
                                                                                        }
                                                                                    }
                                                                                    
                                                                                    EvalContext context = mock(EvalContext.class);
                                                                                    
                                                                                    TestCoreOperationCompare coreOperationCompare = new TestCoreOperationCompare(arg1, arg2) {};
                                                                                    
                                                                                    // Add test assertions here
                                                                                }

    @Test
                                                                                public void testEqualWithSimpleValues() throws Exception {
                                                                                    // Create mocks and test instance
                                                                                    Expression leftExpr = mock(Expression.class);
                                                                                    Expression rightExpr = mock(Expression.class);
                                                                                    
                                                                                    CoreOperationCompare coreOperationCompare = new CoreOperationCompare(leftExpr, rightExpr) {
                                                                                        @Override
                                                                                        public Object computeValue(EvalContext context) {
                                                                                            return null;
                                                                                        }
                                                                                        
                                                                                        @Override
                                                                                        public String getSymbol() {
                                                                                            return "==";
                                                                                        }
                                                                                    };
                                                                                    
                                                                                    EvalContext context = mock(EvalContext.class);
                                                                                    
                                                                                    // Setup mock behavior
                                                                                    when(leftExpr.computeValue(context)).thenReturn("test");
                                                                                    when(rightExpr.computeValue(context)).thenReturn("test");
                                                                                    
                                                                                    // Get protected method via reflection
                                                                                    Method equalMethod = CoreOperationCompare.class.getDeclaredMethod(
                                                                                        "equal", Object.class, Object.class);
                                                                                    equalMethod.setAccessible(true);
                                                                                    
                                                                                    // Test
                                                                                    boolean result = (boolean) equalMethod.invoke(
                                                                                        coreOperationCompare, 
                                                                                        leftExpr.computeValue(context),
                                                                                        rightExpr.computeValue(context));
                                                                                    assertTrue(result);
                                                                                }

    @Test
                                                                                public void testEqualWithCollectionValues() throws Exception {
                                                                                    // Create test collections
                                                                                    Collection<Object> left = new ArrayList<>();
                                                                                    Collection<Object> right = new ArrayList<>();
                                                                                    
                                                                                    // Create anonymous subclass to instantiate abstract class
                                                                                    CoreOperationCompare operation = new CoreOperationCompare(null, null) {
                                                                                        @Override
                                                                                        protected boolean equal(Object left, Object right) {
                                                                                            return left.equals(right);
                                                                                        }
                                                                                        
                                                                                        @Override
                                                                                        public String getSymbol() {
                                                                                            return "==";
                                                                                        }
                                                                                    };
                                                                                    
                                                                                    // Using reflection to test private equal method
                                                                                    Method equalMethod = CoreOperationCompare.class.getDeclaredMethod("equal", Object.class, Object.class);
                                                                                    equalMethod.setAccessible(true);
                                                                                    boolean result = (boolean) equalMethod.invoke(operation, left, right);
                                                                                }

    @Test
                                                                        public void testEqualWithNaNValues() throws Exception {
                                                                            // Create anonymous subclass since CoreOperationCompare is abstract
                                                                            CoreOperationCompare coreOperationCompare = new CoreOperationCompare(null, null) {
                                                                                @Override
                                                                                public Object computeValue(EvalContext context) {
                                                                                    return null;
                                                                                }
                                                                                
                                                                                @Override
                                                                                protected int getPrecedence() {
                                                                                    return 0;
                                                                                }
                                                                                
                                                                                @Override
                                                                                public String getSymbol() {
                                                                                    return "==";
                                                                                }
                                                                            };
                                                                            
                                                                            // Get the protected equal method using reflection
                                                                            Method equalMethod = CoreOperationCompare.class.getDeclaredMethod("equal", Object.class, Object.class);
                                                                            equalMethod.setAccessible(true);
                                                                            
                                                                            // Test cases
                                                                            assertTrue((Boolean) equalMethod.invoke(coreOperationCompare, Double.NaN, Double.NaN));
                                                                            assertFalse((Boolean) equalMethod.invoke(coreOperationCompare, Double.NaN, 1.0));
                                                                            assertTrue((Boolean) equalMethod.invoke(coreOperationCompare, 1.0, 1.0));
                                                                            assertFalse((Boolean) equalMethod.invoke(coreOperationCompare, 1.0, 2.0));
                                                                        }

    @Test
                                                                        public void testEqualWithInitialContext() {
                                                                            Expression left = mock(Expression.class);
                                                                            Expression right = mock(Expression.class);
                                                                            EvalContext context = mock(EvalContext.class);
                                                                            
                                                                            CoreOperationCompare coreOperationCompare = new CoreOperationCompare(left, right) {
                                                                                @Override
                                                                                public String getSymbol() {
                                                                                    return "==";
                                                                                }
                                                                    
                                                                                @Override
                                                                                public Object computeValue(EvalContext context) {
                                                                                    return false;
                                                                                }
                                                                    
                                                                                @Override
                                                                                protected int getPrecedence() {
                                                                                    return 0;
                                                                                }
                                                                    
                                                                                @Override
                                                                                protected boolean equal(Object l, Object r) {
                                                                                    Object leftVal = left.compute(context);
                                                                                    if (leftVal instanceof EvalContext) {
                                                                                        ((EvalContext) leftVal).reset();
                                                                                    }
                                                                                    Object rightVal = right.compute(context);
                                                                                    return false;
                                                                                }
                                                                            };
                                                                            
                                                                            EvalContext initialContext = mock(EvalContext.class);
                                                                        }

    @Test
                                                                    public void testComputeValueReturnsTrueWhenEqual() {
                                                                        // Setup context and mocks
                                                                        Expression arg1 = new Expression() {
                                                                            @Override
                                                                            public Object computeValue(EvalContext context) {
                                                                                return 5;
                                                                            }
                                                                            
                                                                            @Override
                                                                            public Object compute(EvalContext context) {
                                                                                return computeValue(context);
                                                                            }
                                                                            
                                                                            @Override
                                                                            public boolean computeContextDependent() {
                                                                                return false;
                                                                            }
                                                                        };
                                                                        
                                                                        Expression arg2 = new Expression() {
                                                                            @Override
                                                                            public Object computeValue(EvalContext context) {
                                                                                return 5;
                                                                            }
                                                                            
                                                                            @Override
                                                                            public Object compute(EvalContext context) {
                                                                                return computeValue(context);
                                                                            }
                                                                            
                                                                            @Override
                                                                            public boolean computeContextDependent() {
                                                                                return false;
                                                                            }
                                                                        };
                                                                    
                                                                        // Create test instance with mock arguments
                                                                        CoreOperationCompare coreOperationCompare = new CoreOperationCompare(arg1, arg2) {
                                                                            protected boolean evaluateCompare(int compare) {
                                                                                return compare == 0;
                                                                            }
                                                                            
                                                                            @Override
                                                                            public String getSymbol() {
                                                                                return "==";
                                                                            }
                                                                        };
                                                                        
                                                                        // Test the computeValue method
                                                                        Object result = coreOperationCompare.computeValue(null);
                                                                        assertTrue((Boolean)result);
                                                                    }

    @Test
                                        public void testEqualWithSelfContext() throws Exception {
                                            EvalContext context = mock(EvalContext.class);
                                            Expression left = mock(Expression.class);
                                            
                                            CoreOperationCompare coreOperationCompare = new CoreOperationCompare(left, left) {
                                                protected boolean evaluateCompare(int comparison) {
                                                    return false;
                                                }
                                                
                                                @Override
                                                public String getSymbol() {
                                                    return "=";
                                                }
                                            };
                                            
                                            Expression right = mock(Expression.class);
                                            when(left.compute(context)).thenReturn("test");
                                            when(right.compute(context)).thenReturn("different");
                                            
                                            // Use reflection to access protected method
                                            java.lang.reflect.Method equalMethod = CoreOperationCompare.class
                                                .getDeclaredMethod("equal", EvalContext.class, Expression.class, Expression.class);
                                            equalMethod.setAccessible(true);
                                            boolean result = (boolean) equalMethod.invoke(coreOperationCompare, context, left, right);
                                            
                                            assertFalse(result);
                                        }

    @Test
                                    public void testComputeValueWithNumberEqual() {
                                        // Setup mocks
                                        Expression arg1 = mock(Expression.class);
                                        Expression arg2 = mock(Expression.class);
                                        EvalContext context = mock(EvalContext.class);
                                        
                                        // Create test instance using anonymous subclass since CoreOperationCompare is abstract
                                        CoreOperationCompare testInstance = new CoreOperationCompare(arg1, arg2) {
                                            @Override
                                            public String getSymbol() {
                                                return "==";
                                            }
                                            
                                            @Override
                                            public Object computeValue(EvalContext context) {
                                                return super.computeValue(context);
                                            }
                                            
                                            protected boolean evaluateCompare(int compareResult) {
                                                return compareResult == 0;
                                            }
                                            
                                            protected int compare(Object l, Object r) {
                                                return ((Comparable) l).compareTo(r);
                                            }
                                        };
                                        
                                        // Configure mocks
                                        when(arg1.computeValue(context)).thenReturn(5);
                                        when(arg2.computeValue(context)).thenReturn(5);
                                        
                                        // Test
                                        Object result = testInstance.computeValue(context);
                                        
                                        // Verify
                                        assertTrue(result.equals(Boolean.TRUE));
                                    }

    @Test
                public void testComputeValueReturnsFalseWhenNotEqual() {
                    // Setup context and mocks
                    Expression arg1 = new Expression() {
                        @Override
                        public Object computeValue(EvalContext context) {
                            return 1;
                        }
                        
                        @Override
                        public Object compute(EvalContext context) {
                            return computeValue(context);
                        }
                        
                        @Override
                        public boolean computeContextDependent() {
                            return false;
                        }
                        
                        @Override
                        public boolean isContextDependent() {
                            return false;
                        }
                        
                        @Override
                        public String toString() {
                            return "1";
                        }
                    };
                    
                    Expression arg2 = new Expression() {
                        @Override
                        public Object computeValue(EvalContext context) {
                            return 2;
                        }
                        
                        @Override
                        public Object compute(EvalContext context) {
                            return computeValue(context);
                        }
                        
                        @Override
                        public boolean computeContextDependent() {
                            return false;
                        }
                        
                        @Override
                        public boolean isContextDependent() {
                            return false;
                        }
                        
                        @Override
                        public String toString() {
                            return "2";
                        }
                    };
                    
                    // Create test instance with mock arguments
                    CoreOperationCompare coreOperationCompare = new CoreOperationCompare(arg1, arg2) {
                        protected boolean evaluateCompare(int compare) {
                            return compare == 0;
                        }
                        
                        @Override
                        public String getSymbol() {
                            return "==";
                        }
                    };
                    
                    // Test the method
                    Object result = coreOperationCompare.computeValue(null);
                    assertFalse((Boolean)result);
                }

    @Test
        public void testEqualWithCollection() {
            // Create test data
            
            // Create mocks
            CoreOperationCompare coreOperationCompare = new CoreOperationCompare(null, null) {
                @Override
                public Object computeValue(EvalContext context) {
                    return null;
                }
                
                @Override
                public String getSymbol() {
                    return "==";
                }
                
                // Add the equal method since it's not in the original class
                public boolean equal(Expression left, Expression right, EvalContext context) {
                    Object l = left.compute(context);
                    Object r = right.compute(context);
                    if (l instanceof Collection && !(r instanceof Collection)) {
                        return ((Collection<?>) l).contains(r);
                    }
                    if (r instanceof Collection && !(l instanceof Collection)) {
                        return ((Collection<?>) r).contains(l);
                    }
                    return l == r || (l != null && l.equals(r));
                }
            };
            
            EvalContext context = mock(EvalContext.class);
            Expression left = mock(Expression.class);
            Expression right = mock(Expression.class);
            
            // Setup test data
            when(left.compute(context)).thenReturn(collection);
            when(right.compute(context)).thenReturn("a");
            
            // Execute test
            
            // Verify
            assertTrue(result);
        }

    @Test
        public void testEqualWithNullValues1() {
            // Setup mocks
            EvalContext context = mock(EvalContext.class);
            Expression left = mock(Expression.class);
            Expression right = mock(Expression.class);
            
            // Create anonymous subclass since CoreOperationCompare is abstract
            CoreOperationCompare coreOperationCompare = new CoreOperationCompare(left, right) {
                @Override
                public String getSymbol() {
                    return "==";
                }
                
                @Override
                public Object computeValue(EvalContext context) {
                    return false;
                }
                
                public boolean isEqual(EvalContext context, Expression left, Expression right) {
                    Object l = left.compute(context);
                    Object r = right.compute(context);
                    if (l == r) {
                        return true;
                    }
                    if (l == null || r == null) {
                        return false;
                    }
                    return l.equals(r);
                }
            };
            
            // Stub behavior
            when(left.compute(context)).thenReturn(null);
            when(right.compute(context)).thenReturn(null);
            
            // Test
            assertFalse(result);
        }

    @Test
        public void testEqualWithPointerValues() {
{}{
                @Override
{
                }
                
                @Override
{
                }
                
                @Override
{
                    Object r = right.compute(context);
{
                    }
{
                        r = ((Pointer) r).getValue();
                    }
                    return l == r || (l != null && l.equals(r));
                }
            };
            
            Expression right = mock(Expression.class);
            Pointer pointer1 = mock(Pointer.class);
            Pointer pointer2 = mock(Pointer.class);
            
        }

    @Test
        public void testEqualWithNumberValues1() throws Exception {
            // Create test instance
            Expression[] args = new Expression[0];
{
                @Override
{
                    return false;
                }
                
                @Override
{
                    return false;
                }
                
                @Override
{
                    return "test";
                }
            };
            
            // Get private equal method via reflection
        }

    @Test
        public void testEqualWithNumberValues() throws Exception {
            // Create test instance
            Expression[] emptyExpressions = new Expression[0];
{
                @Override
{
                    return false;
                }
                
                @Override
{
                    return "==";
                }
                
                @Override
{
                    return null;
                }
            };
            
            // Get private equal method via reflection
        }


}
