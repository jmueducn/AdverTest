package gentest.org.apache.commons.jxpath.ri.compiler.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.compiler.*;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import org.apache.commons.jxpath.ri.EvalContext;
import org.apache.commons.jxpath.ri.InfoSetUtil;
import org.apache.commons.jxpath.ri.axes.InitialContext;
import org.apache.commons.jxpath.ri.axes.SelfContext;
 
public class CoreOperationRelationalExpressionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                    public void testComputeWithNumbers() throws Exception {
                                                                                                                                                                        CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(null) {
                                                                                                                                                                            @Override
                                                                                                                                                                            protected boolean evaluateCompare(int compare) {
                                                                                                                                                                                return compare == 0;
                                                                                                                                                                            }
                                                                                                                                                                            
                                                                                                                                                                            @Override
                                                                                                                                                                            public String getSymbol() {
                                                                                                                                                                                return "==";
                                                                                                                                                                            }
                                                                                                                                                                        };
                                                                                                                                                                        
                                                                                                                                                                        Method method = CoreOperationRelationalExpression.class.getDeclaredMethod(
                                                                                                                                                                            "compute", Object.class, Object.class);
                                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                                        assertTrue((boolean) method.invoke(expr, 5, 5));
                                                                                                                                                                    }

    @Test
                                                                                                                                                                public void testComputeWithBothIterators() throws Exception {
                                                                                                                                                                    // Create mock iterators
                                                                                                                                                                    Iterator<Integer> iterator1 = mock(Iterator.class);
                                                                                                                                                                    Iterator<Integer> iterator2 = mock(Iterator.class);
                                                                                                                                                                    
                                                                                                                                                                    // Set up mock behavior
                                                                                                                                                                    when(iterator1.hasNext()).thenReturn(true, false);
                                                                                                                                                                    when(iterator1.next()).thenReturn(1);
                                                                                                                                                                    when(iterator2.hasNext()).thenReturn(true, false);
                                                                                                                                                                    when(iterator2.next()).thenReturn(1);
                                                                                                                                                                    
                                                                                                                                                                    // Create test instance
                                                                                                                                                                    CoreOperationRelationalExpression expression = new CoreOperationRelationalExpression(
                                                                                                                                                                        new CoreOperation[]{mock(CoreOperation.class), mock(CoreOperation.class)}) {
                                                                                                                                                                        @Override
                                                                                                                                                                        protected boolean evaluateCompare(int compare) {
                                                                                                                                                                            return true;
                                                                                                                                                                        }
                                                                                                                                                                        @Override
                                                                                                                                                                        public String getSymbol() {
                                                                                                                                                                            return "test";
                                                                                                                                                                        }
                                                                                                                                                                    };
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to access private compute method
                                                                                                                                                                    Method computeMethod = CoreOperationRelationalExpression.class.getDeclaredMethod(
                                                                                                                                                                        "compute", Object.class, Object.class);
                                                                                                                                                                    computeMethod.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Invoke and assert
                                                                                                                                                                    boolean result = (boolean) computeMethod.invoke(expression, iterator1, iterator2);
                                                                                                                                                                    assertTrue(result);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testComputeWithLeftIterator() throws Exception {
                                                                                                                                                                    Iterator<Integer> iterator1 = mock(Iterator.class);
                                                                                                                                                                    when(iterator1.hasNext()).thenReturn(true, false);
                                                                                                                                                                    when(iterator1.next()).thenReturn(1);
                                                                                                                                                                    
                                                                                                                                                                    CoreOperationRelationalExpression expression = new CoreOperationRelationalExpression(
                                                                                                                                                                        new CoreOperation[]{mock(CoreOperation.class), mock(CoreOperation.class)}) {
                                                                                                                                                                        @Override
                                                                                                                                                                        protected boolean evaluateCompare(int compare) {
                                                                                                                                                                            return true;
                                                                                                                                                                        }
                                                                                                                                                                        @Override
                                                                                                                                                                        public String getSymbol() {
                                                                                                                                                                            return "test";
                                                                                                                                                                        }
                                                                                                                                                                    };
                                                                                                                                                                    
                                                                                                                                                                    Method computeMethod = CoreOperationRelationalExpression.class.getDeclaredMethod(
                                                                                                                                                                        "compute", Object.class, Object.class);
                                                                                                                                                                    computeMethod.setAccessible(true);
                                                                                                                                                                    boolean result = (boolean) computeMethod.invoke(expression, iterator1, 1);
                                                                                                                                                                    assertTrue(result);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testComputeWithRightIterator() throws Exception {
                                                                                                                                                                    // Create mock iterator
                                                                                                                                                                    Iterator<Integer> iterator1 = mock(Iterator.class);
                                                                                                                                                                    
                                                                                                                                                                    // Set up mock behavior
                                                                                                                                                                    when(iterator1.hasNext()).thenReturn(true, false);
                                                                                                                                                                    when(iterator1.next()).thenReturn(1);
                                                                                                                                                                    
                                                                                                                                                                    // Create test instance (simplified for test)
                                                                                                                                                                    CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(new CoreOperation[]{}) {
                                                                                                                                                                        @Override
                                                                                                                                                                        protected boolean evaluateCompare(int compare) {
                                                                                                                                                                            return true;
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        @Override
                                                                                                                                                                        public String getSymbol() {
                                                                                                                                                                            return "test";
                                                                                                                                                                        }
                                                                                                                                                                    };
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to access private compute method
                                                                                                                                                                    Method computeMethod = CoreOperationRelationalExpression.class.getDeclaredMethod(
                                                                                                                                                                        "compute", Object.class, Object.class);
                                                                                                                                                                    computeMethod.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Invoke the method
                                                                                                                                                                    boolean result = (boolean) computeMethod.invoke(expr, 1, iterator1);
                                                                                                                                                                    assertTrue(result);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testComputeWithNaN() throws Exception {
                                                                                                                                                                    CoreOperationRelationalExpression expression = new CoreOperationRelationalExpression(new CoreOperation[]{null, null}) {
                                                                                                                                                                        @Override
                                                                                                                                                                        protected boolean evaluateCompare(int compare) {
                                                                                                                                                                            return false;
                                                                                                                                                                        }
                                                                                                                                                            
                                                                                                                                                                        @Override
                                                                                                                                                                        public String getSymbol() {
                                                                                                                                                                            return null;
                                                                                                                                                                        }
                                                                                                                                                                    };
                                                                                                                                                            
                                                                                                                                                                    Method computeMethod = CoreOperationRelationalExpression.class.getDeclaredMethod(
                                                                                                                                                                            "compute", Object.class, Object.class);
                                                                                                                                                                    computeMethod.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                                    assertFalse((Boolean) computeMethod.invoke(expression, Double.NaN, 5));
                                                                                                                                                                    assertFalse((Boolean) computeMethod.invoke(expression, 5, Double.NaN));
                                                                                                                                                                }

    @Test
                                                                                                                                                            public void testComputeWithCollection() throws Exception {
                                                                                                                                                                Collection<Integer> collection = mock(Collection.class);
                                                                                                                                                                Iterator<Integer> iterator1 = mock(Iterator.class);
                                                                                                                                                                
                                                                                                                                                                when(collection.iterator()).thenReturn(iterator1);
                                                                                                                                                                when(iterator1.hasNext()).thenReturn(true, false);
                                                                                                                                                                when(iterator1.next()).thenReturn(1);
                                                                                                                                                                
                                                                                                                                                                CoreOperationRelationalExpression expression = new CoreOperationRelationalExpression(
                                                                                                                                                                    new Expression[0] // Provide empty array of expressions
                                                                                                                                                                ) {
                                                                                                                                                                    @Override
                                                                                                                                                                    protected boolean evaluateCompare(int compare) {
                                                                                                                                                                        return compare == 0;
                                                                                                                                                                    }
                                                                                                                                                                    
                                                                                                                                                                    @Override
                                                                                                                                                                    public String getSymbol() {
                                                                                                                                                                        return "=";
                                                                                                                                                                    }
                                                                                                                                                                };
                                                                                                                                                                
                                                                                                                                                                Method computeMethod = CoreOperationRelationalExpression.class.getDeclaredMethod("compute", Object.class, Object.class);
                                                                                                                                                                computeMethod.setAccessible(true);
                                                                                                                                                                boolean result = (boolean) computeMethod.invoke(expression, collection, 1);
                                                                                                                                                                
                                                                                                                                                                assertTrue(result);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testContainsMatch_WithNaNValue() throws Exception {
                                                                                                                                                                Iterator<Double> mockIterator = mock(Iterator.class);
                                                                                                                                                                when(mockIterator.hasNext()).thenReturn(true, false);
                                                                                                                                                                when(mockIterator.next()).thenReturn(Double.NaN);
                                                                                                                                                                
                                                                                                                                                                CoreOperationRelationalExpression expression = new CoreOperationRelationalExpression(new CoreOperation[]{}) {
                                                                                                                                                                    protected boolean compute(Object left, Object right) {
                                                                                                                                                                        return left.equals(right);
                                                                                                                                                                    }
                                                                                                                                                                    
                                                                                                                                                                    protected boolean evaluateCompare(int compareResult) {
                                                                                                                                                                        return false;
                                                                                                                                                                    }
                                                                                                                                                                    
                                                                                                                                                                    public String getSymbol() {
                                                                                                                                                                        return "test";
                                                                                                                                                                    }
                                                                                                                                                                };
                                                                                                                                                                
                                                                                                                                                                Method method = CoreOperationRelationalExpression.class.getDeclaredMethod(
                                                                                                                                                                    "containsMatch", Object.class, Iterator.class);
                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                boolean result = (boolean) method.invoke(expression, Double.NaN, mockIterator);
                                                                                                                                                                
                                                                                                                                                                assertFalse(result);
                                                                                                                                                            }

    @Test
                                                                                                                                                public void testContainsMatch_MultipleElementsLastMatches() throws Exception {
                                                                                                                                                    // Create a concrete subclass for testing
                                                                                                                                                    class TestCoreOperationRelationalExpression extends CoreOperationRelationalExpression {
                                                                                                                                                        public TestCoreOperationRelationalExpression() {
                                                                                                                                                            super(new Expression[0]);
                                                                                                                                                        }
                                                                                                                                                        
                                                                                                                                                        @Override
                                                                                                                                                        protected boolean evaluateCompare(int compareResult) {
                                                                                                                                                            // Minimal implementation for testing
                                                                                                                                                            return false;
                                                                                                                                                        }
                                                                                                                                                        
                                                                                                                                                        @Override
                                                                                                                                                        public String getSymbol() {
                                                                                                                                                            return "test-symbol";
                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    Iterator<Integer> mockIterator = mock(Iterator.class);
                                                                                                                                                    when(mockIterator.hasNext()).thenReturn(true, true, false);
                                                                                                                                                    when(mockIterator.next()).thenReturn(1, 2);
                                                                                                                                                    
                                                                                                                                                    TestCoreOperationRelationalExpression expression = new TestCoreOperationRelationalExpression();
                                                                                                                                                    Method method = CoreOperationRelationalExpression.class.getDeclaredMethod(
                                                                                                                                                        "containsMatch", Object.class, Iterator.class);
                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                    boolean result = (boolean) method.invoke(expression, 2, mockIterator);
                                                                                                                                                    
                                                                                                                                                    assertTrue(result);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testContainsMatch_WithNullInIterator() throws Exception {
                                                                                                                                                    // Create a concrete subclass for testing
                                                                                                                                                    class ConcreteCoreOperationRelationalExpression extends CoreOperationRelationalExpression {
                                                                                                                                                        public ConcreteCoreOperationRelationalExpression() {
                                                                                                                                                            super(new Expression[0]);
                                                                                                                                                        }
                                                                                                                                                        
                                                                                                                                                        @Override
                                                                                                                                                        protected boolean evaluateCompare(int compareResult) {
                                                                                                                                                            return false;
                                                                                                                                                        }
                                                                                                                                                        
                                                                                                                                                        @Override
                                                                                                                                                        public String getSymbol() {
                                                                                                                                                            return "test-symbol";
                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    Iterator<Object> mockIterator = mock(Iterator.class);
                                                                                                                                                    when(mockIterator.hasNext()).thenReturn(true, true, false);
                                                                                                                                                    when(mockIterator.next()).thenReturn(null, 2);
                                                                                                                                                    
                                                                                                                                                    // Define the private method invocation helper
                                                                                                                                                    Method containsMatchMethod = CoreOperationRelationalExpression.class
                                                                                                                                                        .getDeclaredMethod("containsMatch", Object.class, Iterator.class);
                                                                                                                                                    containsMatchMethod.setAccessible(true);
                                                                                                                                                    boolean result = (boolean) containsMatchMethod.invoke(
                                                                                                                                                        new ConcreteCoreOperationRelationalExpression(), 2, mockIterator);
                                                                                                                                                        
                                                                                                                                                    assertTrue(result);
                                                                                                                                                }

    @Test
                                                                                                                                            public void testComputeWithSelfContext() throws Exception {
                                                                                                                                                // Create mock objects
                                                                                                                                                Expression left = mock(Expression.class);
                                                                                                                                                Expression right = mock(Expression.class);
                                                                                                                                                
                                                                                                                                                // Create test instance using concrete subclass
                                                                                                                                                CoreOperationEqual expr = new CoreOperationEqual(left, right);
                                                                                                                                                
                                                                                                                                                // Mock context
                                                                                                                                                Object selfContext = mock(Object.class);
                                                                                                                                                when(selfContext.toString()).thenReturn("test");
                                                                                                                                                
                                                                                                                                                // Use reflection to access private method
                                                                                                                                                Method computeMethod = CoreOperationRelationalExpression.class
                                                                                                                                                    .getDeclaredMethod("compute", Object.class, Object.class);
                                                                                                                                                computeMethod.setAccessible(true);
                                                                                                                                                
                                                                                                                                                // Test
                                                                                                                                                boolean result = (boolean) computeMethod.invoke(expr, selfContext, "other");
                                                                                                                                                assertFalse(result);
                                                                                                                                            }

    @Test
                                                                                                                                public void testComputeWithInitialContext() throws Exception {
                                                                                                                                    // Create mock objects
                                                                                                                                    CoreOperationRelationalExpression expression = mock(CoreOperationRelationalExpression.class);
                                                                                                                                    EvalContext initialContext = mock(EvalContext.class);
                                                                                                                                    
                                                                                                                                    // Setup mock behavior
                                                                                                                                    
                                                                                                                                    // Create test utility method
                                                                                                                                    Method computeMethod = CoreOperationRelationalExpression.class
                                                                                                                                        .getDeclaredMethod("compute", Object.class, Object.class);
                                                                                                                                    computeMethod.setAccessible(true);
                                                                                                                                    
                                                                                                                                    // Test with initial context
                                                                                                                                    assertFalse((boolean) computeMethod.invoke(expression, initialContext, "test"));
                                                                                                                                    assertFalse((boolean) computeMethod.invoke(expression, "test", initialContext));
                                                                                                                                }

    @Test
                                                                                                                                public void testReduce() throws Exception {
                                                                                                                                    CoreOperationRelationalExpression expression = mock(CoreOperationRelationalExpression.class);
                                                                                                                                    EvalContext selfContext = mock(EvalContext.class);
                                                                                                                                    Collection<Object> collection = mock(Collection.class);
                                                                                                                                    Iterator<Object> iterator1 = mock(Iterator.class);
                                                                                                                                    Object pointer = new Object();
                                                                                                                                    Object testString = "test";
                                                                                                                                    
                                                                                                                                    Method method = CoreOperationRelationalExpression.class.getDeclaredMethod(
                                                                                                                                        "reduce", Object.class);
                                                                                                                                    method.setAccessible(true);
                                                                                                                                
                                                                                                                                    assertEquals(pointer, method.invoke(expression, selfContext));
                                                                                                                                
                                                                                                                                    when(collection.iterator()).thenReturn(iterator1);
                                                                                                                                    assertEquals(iterator1, method.invoke(expression, collection));
                                                                                                                                
                                                                                                                                    assertEquals(testString, method.invoke(expression, testString));
                                                                                                                                }

    @Test
                                                                                                                                public void testContainsMatchWithNullValue() throws Exception {
                                                                                                                                    
                                                                                                                                    @SuppressWarnings("unchecked")
                                                                                                                                    Iterator<Object> mockIterator = mock(Iterator.class);
                                                                                                                                    Expression arg1 = mock(Expression.class);
                                                                                                                                    Expression arg2 = mock(Expression.class);
                                                                                                                                    
                                                                                                                                    CoreOperationRelationalExpression testImpl = new CoreOperationRelationalExpression(new Expression[]{arg1, arg2}) {
                                                                                                                                        @Override
                                                                                                                                        protected boolean evaluateCompare(int compareResult) {
                                                                                                                                            return false;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public String getSymbol() {
                                                                                                                                            return null;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        public boolean computeValue(Object left, Object right) {
                                                                                                                                            return true;
                                                                                                                                        }
                                                                                                                                    };
                                                                                                                                    
                                                                                                                                    when(mockIterator.hasNext()).thenReturn(true, false);
                                                                                                                                    when(mockIterator.next()).thenReturn(null);
                                                                                                                                    
                                                                                                                                    CoreOperationRelationalExpression spy = spy(testImpl);
                                                                                                                                    
                                                                                                                                    boolean result = (boolean) spy.getClass()
                                                                                                                                        .getDeclaredMethod("containsMatch", Iterator.class, Object.class)
                                                                                                                                        .invoke(spy, mockIterator, null);
                                                                                                                                    assertTrue(result);
                                                                                                                                }

    @Test
                                                                                                                                public void testContainsMatch_WithNullValue() throws Exception {
                                                                                                                                    Iterator<?> mockIterator = mock(Iterator.class);
                                                                                                                                    
                                                                                                                                    when(mockIterator.hasNext()).thenReturn(true, false);
                                                                                                                                    when(mockIterator.next()).thenReturn(null);
                                                                                                                                    
                                                                                                                                    CoreOperationRelationalExpression expression = new CoreOperationRelationalExpression(
                                                                                                                                        new Expression[]{mock(Expression.class), mock(Expression.class)}) {
                                                                                                                                        @Override
                                                                                                                                        protected boolean evaluateCompare(int comparisonResult) {
                                                                                                                                            return false;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        protected boolean compute(Object left, Object right) {
                                                                                                                                            return left == right;
                                                                                                                                        }
                                                                                                                            
                                                                                                                                        @Override
                                                                                                                                        public String getSymbol() {
                                                                                                                                            return "test";
                                                                                                                                        }
                                                                                                                                    };
                                                                                                                                    
                                                                                                                                    Method method = CoreOperationRelationalExpression.class.getDeclaredMethod(
                                                                                                                                        "containsMatch", Object.class, Iterator.class);
                                                                                                                                    method.setAccessible(true);
                                                                                                                                    boolean result = (boolean) method.invoke(expression, null, mockIterator);
                                                                                                                                    
                                                                                                                                    assertTrue(result);
                                                                                                                                }

    @Test
                                                                                                                            public void testContainsMatchWithFirstElementMatch() throws Exception {
                                                                                                                                Iterator<String> mockIterator = mock(Iterator.class);
                                                                                                                                Object testImpl = new Object() {
                                                                                                                                    private boolean compute(Object left, Object right) {
                                                                                                                                        return false;
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    private boolean containsMatch(Iterator<String> iterator, Object value) {
                                                                                                                                        while (iterator.hasNext()) {
                                                                                                                                            if (compute(iterator.next(), value)) {
                                                                                                                                                return true;
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                        return false;
                                                                                                                                    }
                                                                                                                                };
                                                                                                                                
                                                                                                                                when(mockIterator.hasNext()).thenReturn(true, false);
                                                                                                                                when(mockIterator.next()).thenReturn("value1");
                                                                                                                                
                                                                                                                                Object spy = spy(testImpl);
                                                                                                                                Method computeMethod = spy.getClass().getDeclaredMethod("compute", Object.class, Object.class);
                                                                                                                                computeMethod.setAccessible(true);
                                                                                                                                when(computeMethod.invoke(spy, eq("value1"), any())).thenReturn(true);
                                                                                                                                
                                                                                                                                Method containsMatchMethod = spy.getClass().getDeclaredMethod("containsMatch", Iterator.class, Object.class);
                                                                                                                                containsMatchMethod.setAccessible(true);
                                                                                                                                boolean result = (boolean) containsMatchMethod.invoke(spy, mockIterator, "test");
                                                                                                                                assertTrue(result);
                                                                                                                            }

    @Test
                                                                                                                        public void testContainsMatch_NoMatch() throws Exception {
                                                                                                                            Iterator<Integer> mockIterator = mock(Iterator.class);
                                                                                                                            when(mockIterator.hasNext()).thenReturn(true, true, false);
                                                                                                                            when(mockIterator.next()).thenReturn(1, 2);
                                                                                                                            
                                                                                                                            CoreOperation leftOp = mock(CoreOperation.class);
                                                                                                                            CoreOperation rightOp = mock(CoreOperation.class);
                                                                                                                            CoreOperation[] args = new CoreOperation[]{leftOp, rightOp};
                                                                                                                            
                                                                                                                            CoreOperationRelationalExpression expression = new CoreOperationRelationalExpression(args) {
                                                                                                                                protected boolean compute(Object left, Object right) {
                                                                                                                                    return left.equals(right);
                                                                                                                                }
                                                                                                                                
                                                                                                                                @Override
                                                                                                                                protected boolean evaluateCompare(int compareResult) {
                                                                                                                                    return false;
                                                                                                                                }
                                                                                                                                
                                                                                                                                @Override
                                                                                                                                public String getSymbol() {
                                                                                                                                    return "test";
                                                                                                                                }
                                                                                                                            };
                                                                                                                            
                                                                                                                            Method method = CoreOperationRelationalExpression.class.getDeclaredMethod(
                                                                                                                                "containsMatch", Object.class, Iterator.class);
                                                                                                                            method.setAccessible(true);
                                                                                                                            boolean result = (boolean) method.invoke(expression, 3, mockIterator);
                                                                                                                            
                                                                                                                            assertFalse(result);
                                                                                                                        }

    @Test
                                                                                                                        public void testContainsMatch_MultipleElementsFirstMatches() throws Exception {
                                                                                                                            Iterator<Integer> mockIterator = mock(Iterator.class);
                                                                                                                            when(mockIterator.hasNext()).thenReturn(true, true, false);
                                                                                                                            when(mockIterator.next()).thenReturn(2, 3);
                                                                                                                            
                                                                                                                            CoreOperation[] operations = new CoreOperation[]{
                                                                                                                                mock(CoreOperation.class),
                                                                                                                                mock(CoreOperation.class)
                                                                                                                            };
                                                                                                                            
                                                                                                                            CoreOperationRelationalExpression expression = new CoreOperationRelationalExpression(operations) {
                                                                                                                                protected boolean compute(Object value, Object element) {
                                                                                                                                    if (value == null) {
                                                                                                                                        return element == null;
                                                                                                                                    }
                                                                                                                                    return value.equals(element);
                                                                                                                                }
                                                                                                                                
                                                                                                                                @Override
                                                                                                                                protected boolean evaluateCompare(int compareResult) {
                                                                                                                                    return compareResult == 0;
                                                                                                                                }
                                                                                                                                
                                                                                                                                @Override
                                                                                                                                public String getSymbol() {
                                                                                                                                    return null;
                                                                                                                                }
                                                                                                                            };
                                                                                                                            
                                                                                                                            // Use reflection to access private method
                                                                                                                            java.lang.reflect.Method method = CoreOperationRelationalExpression.class
                                                                                                                                .getDeclaredMethod("containsMatch", Object.class, Iterator.class);
                                                                                                                            method.setAccessible(true);
                                                                                                                            boolean result = (Boolean) method.invoke(expression, 2, mockIterator);
                                                                                                                                
                                                                                                                            assertTrue(result);
                                                                                                                        }

    @Test
                                                                                                                    public void testContainsMatch_SingleMatch() throws Exception {
                                                                                                                        Iterator<Integer> mockIterator = mock(Iterator.class);
                                                                                                                        when(mockIterator.hasNext()).thenReturn(true, true, false);
                                                                                                                        when(mockIterator.next()).thenReturn(1, 2);
                                                                                                                        
                                                                                                                        CoreOperationRelationalExpression expression = new CoreOperationRelationalExpression(
                                                                                                                            new CoreOperation[]{mock(CoreOperation.class), mock(CoreOperation.class)}) {
                                                                                                                            
                                                                                                                            protected boolean compute(Object left, Object right) {
                                                                                                                                return left.equals(right);
                                                                                                                            }
                                                                                                                            
                                                                                                                            protected boolean evaluateCompare(int compareResult) {
                                                                                                                                return compareResult == 0;
                                                                                                                            }
                                                                                                                            
                                                                                                                            public String getSymbol() {
                                                                                                                                return "==";
                                                                                                                            }
                                                                                                                        };
                                                                                                                        
                                                                                                                        Method method = CoreOperationRelationalExpression.class.getDeclaredMethod(
                                                                                                                            "containsMatch", Object.class, Iterator.class);
                                                                                                                        method.setAccessible(true);
                                                                                                                        boolean result = (boolean) method.invoke(expression, 2, mockIterator);
                                                                                                                        
                                                                                                                        assertTrue(result);
                                                                                                                    }

    @Test
                                                                                                                public void testContainsMatch_EmptyIterator() throws Exception {
                                                                                                                    Iterator<?> mockIterator = mock(Iterator.class);
                                                                                                                    when(mockIterator.hasNext()).thenReturn(false);
                                                                                                                    
                                                                                                                    CoreOperationRelationalExpression expression = new CoreOperationRelationalExpression(new CoreOperation[0]) {
                                                                                                                        @Override
                                                                                                                        protected boolean evaluateCompare(int compareResult) {
                                                                                                                            return false;
                                                                                                                        }
                                                                                                                        
                                                                                                                        @Override
                                                                                                                        public String getSymbol() {
                                                                                                                            return null;
                                                                                                                        }
                                                                                                                
                                                                                                                        @Override
                                                                                                                        public Object compute(EvalContext context) {
                                                                                                                            return Boolean.FALSE;
                                                                                                                        }
                                                                                                                
                                                                                                                        public Object computeValue(EvalContext context, Object left, Object right) {
                                                                                                                            return Boolean.FALSE;
                                                                                                                        }
                                                                                                                    };
                                                                                                                    
                                                                                                                    Method method = CoreOperationRelationalExpression.class.getDeclaredMethod(
                                                                                                                        "containsMatch", Object.class, Iterator.class);
                                                                                                                    method.setAccessible(true);
                                                                                                                    boolean result = (boolean) method.invoke(expression, "test", mockIterator);
                                                                                                                    
                                                                                                                    assertFalse(result);
                                                                                                                }

    @Test
                                                                                    public void testContainsMatchWithIteratorFirst() throws Exception {
                                                                                        List<Integer> list = new ArrayList<>();
                                                                                        list.add(1);
                                                                                        list.add(2);
                                                                                        Iterator<Integer> it = list.iterator();
                                                                                
                                                                                        CoreOperation left = new CoreOperation(new CoreOperation[]{}) {
                                                                                            @Override
                                                                                            public Object computeValue(EvalContext context) {
                                                                                                return null;
                                                                                            }
                                                                                            @Override
                                                                                            public int getPrecedence() {
                                                                                                return 0;
                                                                                            }
                                                                                            @Override
                                                                                            public boolean isSymmetric() {
                                                                                                return false;
                                                                                            }
                                                                                            @Override
                                                                                            public String getSymbol() {
                                                                                                return "op1";
                                                                                            }
                                                                                        };
                                                                                
                                                                                        CoreOperation right = new CoreOperation(new CoreOperation[]{}) {
                                                                                            @Override
                                                                                            public Object computeValue(EvalContext context) {
                                                                                                return null;
                                                                                            }
                                                                                            @Override
                                                                                            public int getPrecedence() {
                                                                                                return 0;
                                                                                            }
                                                                                            @Override
                                                                                            public boolean isSymmetric() {
                                                                                                return false;
                                                                                            }
                                                                                            @Override
                                                                                            public String getSymbol() {
                                                                                                return "op2";
                                                                                            }
                                                                                        };
                                                                                    }

    @Test
                                                                                    public void testContainsMatchWithEmptyIterator() throws Exception {
                                                                                        CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(null) {
                                                                                            @Override
                                                                                            protected boolean evaluateCompare(int compareResult) {
                                                                                                return false;
                                                                                            }
                                                                                            
                                                                                            @Override
                                                                                            public String getSymbol() {
                                                                                                return "!=";
                                                                                            }
                                                                                        };
                                                                                
                                                                                        // Use reflection to access private method
                                                                                        Method method = CoreOperationRelationalExpression.class.getDeclaredMethod(
                                                                                            "containsMatch", Iterator.class, Object.class);
                                                                                        method.setAccessible(true);
                                                                                        
                                                                                        Iterator<?> emptyIterator = new Iterator<Object>() {
                                                                                            @Override
                                                                                            public boolean hasNext() {
                                                                                                return false;
                                                                                            }
                                                                                
                                                                                            @Override
                                                                                            public Object next() {
                                                                                                return null;
                                                                                            }
                                                                                        };
                                                                                        
                                                                                        boolean result = (boolean) method.invoke(expr, emptyIterator, new Object());
                                                                                    }

    @Test
                                                                                public void testContainsMatchWithObjectFirst() throws Exception {
                                                                                    Iterator<Object> it = mock(Iterator.class);
                                                                                    when(it.hasNext()).thenReturn(true, false);
                                                                                    when(it.next()).thenReturn(2);
                                                                                    
                                                                                    CoreOperationRelationalExpression expression = new CoreOperationRelationalExpression(new CoreOperation[]{}) {
                                                                                        @Override
                                                                                        protected boolean evaluateCompare(int compareResult) {
                                                                                            return false;
                                                                                        }
                                                                                        
                                                                                        @Override
                                                                                        public String getSymbol() {
                                                                                            return null;
                                                                                        }
                                                                                    };
                                                                                    
                                                                                    Method method = CoreOperationRelationalExpression.class.getDeclaredMethod(
                                                                                        "containsMatch", Object.class, Iterator.class);
                                                                                    method.setAccessible(true);
                                                                                
                                                                                    assertTrue((boolean) method.invoke(expression, 2, it));
                                                                                }

    @Test
                                                                            public void testContainsMatchWithNoMatch() throws Exception {
                                                                                // Create mock iterator
                                                                                @SuppressWarnings("unchecked")
                                                                                Iterator<Object> mockIterator = mock(Iterator.class);
                                                                                when(mockIterator.hasNext()).thenReturn(true, false);
                                                                                when(mockIterator.next()).thenReturn("testValue");
                                                                        
                                                                                // Create concrete subclass instance
                                                                                CoreOperationRelationalExpression expression = new CoreOperationRelationalExpression(new CoreOperation[]{}) {
                                                                                    @Override
                                                                                    protected boolean evaluateCompare(int compareResult) {
                                                                                        return false;
                                                                                    }
                                                                                    
                                                                                    @Override
                                                                                    public String getSymbol() {
                                                                                        return "test";
                                                                                    }
                                                                                };
                                                                        
                                                                                // Use reflection to invoke private method
                                                                                java.lang.reflect.Method method = CoreOperationRelationalExpression.class
                                                                                        .getDeclaredMethod("containsMatch", Iterator.class, Object.class);
                                                                                method.setAccessible(true);
                                                                                boolean result = (boolean) method.invoke(expression, mockIterator, "nonMatchingValue");
                                                                        
                                                                                assertFalse(result);
                                                                            }

    @Test
                                                public void testContainsMatchWithMatch() throws Exception {
                                                    // Create mock expressions
                                                    Expression arg1 = mock(Expression.class);
                                                    Expression arg2 = mock(Expression.class);
                                                    
                                                    // Create concrete subclass instance since CoreOperationRelationalExpression is abstract
                                                    CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(new Expression[]{arg1, arg2}) {
                                                        @Override
                                                        protected boolean evaluateCompare(int compareResult) {
                                                            return false;
                                                        }
                                                        
                                                        @Override
                                                        public String getSymbol() {
                                                            return "";
                                                        }
                                                    };
                                                    
                                                    // Setup mock behavior
                                                    
                                                    // Create mock compiler
                                                    Compiler compiler = mock(Compiler.class);
                                                    
                                                    // Test the containsMatch method
                                                    boolean result = false;
                                                    try {
                                                        java.lang.reflect.Method method = CoreOperationRelationalExpression.class.getDeclaredMethod("containsMatch", Compiler.class);
                                                        method.setAccessible(true);
                                                        result = (boolean) method.invoke(expr, compiler);
                                                    } catch (Exception e) {
                                                        fail("Reflection failed: " + e.getMessage());
                                                    }
                                                    
                                                    // Add assertions
                                                    assertFalse(result);
                                                }

    @Test
        public void testContainsMatchWithRealIterator() throws Exception {
            // Create test implementation
            CoreOperation[] args = new CoreOperation[]{mock(CoreOperation.class)};
            CoreOperationRelationalExpression testImpl = new CoreOperationRelationalExpression(args) {
                @Override
                public String getSymbol() {
                    return "test";
                }
                
                @Override
                public boolean evaluateCompare(int comparisonResult) {
                    return false;
                }
                
                protected boolean computeValue(Object left, Object right) {
                    return false;
                }
            };
            
            // Create real iterator for testing
            
            CoreOperationRelationalExpression spy = spy(testImpl);
            
            // Use reflection to mock private method
            Method computeValueMethod = CoreOperationRelationalExpression.class.getDeclaredMethod(
                "computeValue", Object.class, Object.class);
            computeValueMethod.setAccessible(true);
            when(computeValueMethod.invoke(spy, eq("a"), any())).thenReturn(false);
            when(computeValueMethod.invoke(spy, eq("b"), any())).thenReturn(true);
            when(computeValueMethod.invoke(spy, eq("c"), any())).thenReturn(false);
            
            // Use reflection to invoke private containsMatch method
            Method containsMatchMethod = CoreOperationRelationalExpression.class.getDeclaredMethod(
                "containsMatch", Iterator.class, Object.class);
            containsMatchMethod.setAccessible(true);
            
        }

    @Test
        public void testFindMatch() throws Exception {
            // Create mock iterators
            Object testObject = new Object();
                
            // Create a concrete subclass instance since CoreOperationRelationalExpression is abstract
            CoreOperationRelationalExpression expression = new CoreOperationRelationalExpression(new Expression[0]) {
                @Override
                protected boolean evaluateCompare(int compareResult) {
                    return false;
                }
                
                @Override
                public String getSymbol() {
                    return "";
                }
                
                @Override
                public Object compute(EvalContext context) {
                    return null;
                }
            };
            
            Method method = CoreOperationRelationalExpression.class.getDeclaredMethod(
                "findMatch", Iterator.class, Iterator.class);
            method.setAccessible(true);
            
        }


}
