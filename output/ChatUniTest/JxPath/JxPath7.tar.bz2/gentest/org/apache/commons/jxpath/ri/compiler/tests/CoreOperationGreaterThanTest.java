package gentest.org.apache.commons.jxpath.ri.compiler.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.compiler.*;
 
public class CoreOperationGreaterThanTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testEvaluateComparePositive() throws Exception {
            CoreOperationGreaterThan operation = new CoreOperationGreaterThan(null, null);
            Method method = CoreOperationGreaterThan.class.getDeclaredMethod("evaluateCompare", int.class);
            method.setAccessible(true);
            
            boolean result = (boolean) method.invoke(operation, 1);
            assertTrue(result);
        }

    @Test
        public void testEvaluateCompareZero() throws Exception {
            CoreOperationGreaterThan operation = new CoreOperationGreaterThan(null, null);
            Method method = CoreOperationGreaterThan.class.getDeclaredMethod("evaluateCompare", int.class);
            method.setAccessible(true);
            
            boolean result = (boolean) method.invoke(operation, 0);
            assertFalse(result);
        }

    @Test
        public void testEvaluateCompareNegative() throws Exception {
            CoreOperationGreaterThan operation = new CoreOperationGreaterThan(null, null);
            Method method = CoreOperationGreaterThan.class.getDeclaredMethod("evaluateCompare", int.class);
            method.setAccessible(true);
            
            boolean result = (boolean) method.invoke(operation, -1);
            assertFalse(result);
        }

    @Test
        public void testEvaluateCompareMaxValue() throws Exception {
            CoreOperationGreaterThan operation = new CoreOperationGreaterThan(null, null);
            Method method = CoreOperationGreaterThan.class.getDeclaredMethod("evaluateCompare", int.class);
            method.setAccessible(true);
            
            boolean result = (boolean) method.invoke(operation, Integer.MAX_VALUE);
            assertTrue(result);
        }

    @Test
        public void testEvaluateCompareMinValue() throws Exception {
            CoreOperationGreaterThan operation = new CoreOperationGreaterThan(null, null);
            Method method = CoreOperationGreaterThan.class.getDeclaredMethod("evaluateCompare", int.class);
            method.setAccessible(true);
            
            boolean result = (boolean) method.invoke(operation, Integer.MIN_VALUE);
            assertFalse(result);
        }

    @Test
        public void testGetSymbol() {
            CoreOperationGreaterThan operation = new CoreOperationGreaterThan(null, null);
            assertEquals(">", operation.getSymbol());
        }

}
