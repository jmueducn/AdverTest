package gentest.org.apache.commons.jxpath.ri.axes.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.axes.*;
import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.EvalContext;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;
 
public class AttributeContextTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                            public void testNextNodeWithNodeTypeTestAndNodeTypeNode() {
                                                                // Mock objects
                                                                NodeTest nodeTest = mock(NodeTest.class);
                                                                NodeTypeTest nodeTypeTest = mock(NodeTypeTest.class);
                                                                ParentContext parentContext = mock(ParentContext.class);
                                                                NodePointer currentNodePointer = mock(NodePointer.class);
                                                                NodeIterator nodeIterator = mock(NodeIterator.class);
                                                                
                                                                // Setup mocks
                                                                when(nodeTest instanceof NodeTypeTest).thenReturn(true);
                                                                when(((NodeTypeTest) nodeTest).getNodeType()).thenReturn(Compiler.NODE_TYPE_NODE);
                                                                when(parentContext.getCurrentNodePointer()).thenReturn(currentNodePointer);
                                                                when(currentNodePointer.attributeIterator(any(QName.class))).thenReturn(nodeIterator);
                                                                when(nodeIterator.setPosition(1)).thenReturn(true);
                                                                when(nodeIterator.getNodePointer()).thenReturn(currentNodePointer);
                                                                
                                                                // Create test instance
                                                                AttributeContext attributeContext = new AttributeContext(parentContext, nodeTest);
                                                                
                                                                // Test method
                                                                boolean result = attributeContext.nextNode();
                                                                
                                                                // Assertions
                                                                assertTrue(result);
                                                                assertTrue(attributeContext.getCurrentNodePointer() != null);
                                                            }

    @Test
                                                            public void testNextNodeWithNodeNameTest() {
                                                                // Create mocks
                                                                ParentContext parentContext = mock(ParentContext.class);
                                                                NodeTest nodeTest = mock(NodeTest.class);
                                                                NodePointer currentNodePointer = mock(NodePointer.class);
                                                                NodeIterator nodeIterator = mock(NodeIterator.class);
                                                                
                                                                // Setup mock behavior
                                                                when(nodeTest instanceof NodeNameTest).thenReturn(true);
                                                                when(((NodeNameTest) nodeTest).getNodeName()).thenReturn(new QName(null, "test"));
                                                                when(parentContext.getCurrentNodePointer()).thenReturn(currentNodePointer);
                                                                when(currentNodePointer.attributeIterator(any(QName.class))).thenReturn(nodeIterator);
                                                                when(nodeIterator.setPosition(1)).thenReturn(true);
                                                                when(nodeIterator.getNodePointer()).thenReturn(currentNodePointer);
                                                                
                                                                // Create and test attribute context
                                                                AttributeContext attributeContext = new AttributeContext(parentContext, nodeTest);
                                                                boolean result = attributeContext.nextNode();
                                                                
                                                                // Verify results
                                                                assertTrue(result);
                                                                assertTrue(attributeContext.getCurrentNodePointer() != null);
                                                            }

    @Test
                                                            public void testNextNodeWithUnsupportedNodeTest() {
                                                                ParentContext parentContext = mock(ParentContext.class);
                                                                NodeTest nodeTest = mock(NodeTest.class);
                                                                
                                                                when(nodeTest instanceof NodeTypeTest).thenReturn(false);
                                                                when(nodeTest instanceof NodeNameTest).thenReturn(false);
                                                                
                                                                AttributeContext attributeContext = new AttributeContext(parentContext, nodeTest);
                                                                boolean result = attributeContext.nextNode();
                                                                
                                                                assertFalse(result);
                                                            }

    @Test
                                                            public void testNextNodeWithNullIterator() {
                                                                NodeTest nodeTest = mock(NodeTest.class);
                                                                NodePointer currentNodePointer = mock(NodePointer.class);
                                                                AttributeContext parentContext = mock(AttributeContext.class);
                                                                
                                                                when(nodeTest instanceof NodeNameTest).thenReturn(true);
                                                                when(((NodeNameTest) nodeTest).getNodeName()).thenReturn(new QName(null, "test"));
                                                                when(parentContext.getCurrentNodePointer()).thenReturn(currentNodePointer);
                                                                when(currentNodePointer.attributeIterator(any(QName.class))).thenReturn(null);
                                                        
                                                                AttributeContext attributeContext = new AttributeContext(parentContext, nodeTest);
                                                                boolean result = attributeContext.nextNode();
                                                        
                                                                assertFalse(result);
                                                            }

    @Test
                        public void testNextNodeAfterReset() {
                            // Create mocks
                            NodeTest nodeTest = mock(NodeNameTest.class);
                            NodeNameTest nodeNameTest = mock(NodeNameTest.class);
                            NodePointer parentContext = mock(NodePointer.class);
                            NodePointer currentNodePointer = mock(NodePointer.class);
                            NodeIterator nodeIterator = mock(NodeIterator.class);
                            
                            // Setup mock behavior
                            when(nodeTest instanceof NodeNameTest).thenReturn(true);
                            when(nodeNameTest.getNodeName()).thenReturn(new QName(null, "test"));
                            when(currentNodePointer.attributeIterator(any(QName.class))).thenReturn(nodeIterator);
                            when(nodeIterator.setPosition(1)).thenReturn(true);
                            when(nodeIterator.getNodePointer()).thenReturn(currentNodePointer);
                        
                            // Create test EvalContext
                            EvalContext evalContext = mock(EvalContext.class);
                            when(evalContext.getCurrentNodePointer()).thenReturn(parentContext);
                            
                            // Create and test AttributeContext
                            AttributeContext attributeContext = new AttributeContext(evalContext, nodeTest);
                            attributeContext.nextNode();
                            attributeContext.reset();
                            boolean result = attributeContext.nextNode();
                        
                            assertTrue(result);
                        }

    @Test
                public void testNextNodeMultipleCalls() {
                    NodeTest nodeTest = mock(NodeTest.class);
                    NodeNameTest nodeNameTest = mock(NodeNameTest.class);
                    NodePointer parentContext = mock(NodePointer.class);
                    NodePointer currentNodePointer = mock(NodePointer.class);
                    NodeIterator nodeIterator = mock(NodeIterator.class);
                    
                    EvalContext evalContext = mock(EvalContext.class);
                    when(evalContext.getCurrentNodePointer()).thenReturn(parentContext);
                    
                    AttributeContext attributeContext = new AttributeContext(evalContext, nodeTest);
                    
                    when(nodeTest instanceof NodeNameTest).thenReturn(true);
                    when(((NodeNameTest) nodeTest).getNodeName()).thenReturn(new QName(null, "test"));
                    when(currentNodePointer.attributeIterator(any(QName.class))).thenReturn(nodeIterator);
                    when(nodeIterator.setPosition(1)).thenReturn(true);
                    when(nodeIterator.setPosition(2)).thenReturn(true);
                    when(nodeIterator.getNodePointer()).thenReturn(currentNodePointer);
                    when(nodeIterator.getPosition()).thenReturn(0).thenReturn(1).thenReturn(2);
                    
                    boolean firstCall = attributeContext.nextNode();
                    boolean secondCall = attributeContext.nextNode();
                    
                    assertTrue(firstCall);
                    assertTrue(secondCall);
                    assertEquals(2, attributeContext.getCurrentPosition());
                }

    @Test
        public void testNextNodeWhenIteratorFailsToSetPosition() {
            NodeNameTest nodeTest = mock(NodeNameTest.class);
            NodePointer parentContext = mock(NodePointer.class);
            NodePointer currentNodePointer = mock(NodePointer.class);
            NodeIterator nodeIterator = mock(NodeIterator.class);
            
            // Create a mock EvalContext that wraps the parentContext
            EvalContext evalContext = mock(EvalContext.class);
            when(evalContext.getCurrentNodePointer()).thenReturn(parentContext);
            
            AttributeContext attributeContext = new AttributeContext(evalContext, nodeTest);
            when(nodeTest.getNodeName()).thenReturn(new QName(null, "test"));
            when(evalContext.getCurrentNodePointer()).thenReturn(currentNodePointer);
            when(currentNodePointer.attributeIterator(any(QName.class))).thenReturn(nodeIterator);
            when(nodeIterator.setPosition(1)).thenReturn(false);
            
            boolean result = attributeContext.nextNode();
            
            assertFalse(result);
        }


}
