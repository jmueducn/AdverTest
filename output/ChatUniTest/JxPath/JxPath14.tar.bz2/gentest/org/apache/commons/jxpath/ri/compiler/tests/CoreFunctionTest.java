package gentest.org.apache.commons.jxpath.ri.compiler.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.compiler.*;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.util.Collection;
import java.util.Locale;
import org.apache.commons.jxpath.BasicNodeSet;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.JXPathException;
import org.apache.commons.jxpath.JXPathInvalidSyntaxException;
import org.apache.commons.jxpath.NodeSet;
import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.EvalContext;
import org.apache.commons.jxpath.ri.InfoSetUtil;
import org.apache.commons.jxpath.ri.axes.NodeSetContext;
import org.apache.commons.jxpath.ri.model.NodePointer;
 
public class CoreFunctionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                    public void testFunctionCeilingWithNegativeInfinity() {
                                                                                        CoreFunction coreFunction = mock(CoreFunction.class);
                                                                                        Expression arg1 = mock(Expression.class);
                                                                                        EvalContext context = mock(EvalContext.class);
                                                                                        
                                                                                        when(coreFunction.getArg1()).thenReturn(arg1);
                                                                                        when(arg1.computeValue(context)).thenReturn(Double.NEGATIVE_INFINITY);
                                                                                        when(coreFunction.computeValue(context)).thenCallRealMethod();
                                                                                        
                                                                                        Object result = coreFunction.computeValue(context);
                                                                                        assertTrue(Double.isInfinite(((Double) result).doubleValue()));
                                                                                        assertEquals(Double.NEGATIVE_INFINITY, ((Double) result).doubleValue(), 0.001);
                                                                                    }

    @Test
                                                                                public void testFunctionCeilingWithRegularNumber() {
                                                                                    // Setup mock objects
                                                                                    CoreFunction coreFunction = mock(CoreFunction.class);
                                                                                    Expression arg1 = mock(Expression.class);
                                                                                    EvalContext context = mock(EvalContext.class);
                                                                                    
                                                                                    // Configure mocks
                                                                                    when(coreFunction.getArg1()).thenReturn(arg1);
                                                                                    when(arg1.computeValue(context)).thenReturn(3.4);
                                                                                    
                                                                                    // Call the actual method (using reflection if needed)
                                                                                    try {
                                                                                        java.lang.reflect.Method method = CoreFunction.class.getDeclaredMethod("functionCeiling", EvalContext.class);
                                                                                        method.setAccessible(true);
                                                                                        Object result = method.invoke(coreFunction, context);
                                                                                        
                                                                                        // Verify result
                                                                                        assertEquals(4.0, ((Double) result).doubleValue(), 0.001);
                                                                                    } catch (Exception e) {
                                                                                        fail("Exception occurred: " + e.getMessage());
                                                                                    }
                                                                                }

    @Test
                                                                                public void testFunctionCeilingWithNaN() {
                                                                                    // Setup mock objects
                                                                                    CoreFunction coreFunction = mock(CoreFunction.class);
                                                                                    Expression arg1 = mock(Expression.class);
                                                                                    EvalContext context = mock(EvalContext.class);
                                                                                    
                                                                                    // Configure mocks
                                                                                    when(coreFunction.getArg1()).thenReturn(arg1);
                                                                                    when(arg1.computeValue(context)).thenReturn(Double.NaN);
                                                                                    
                                                                                    // Call the actual method (using reflection since computeValue is private)
                                                                                    try {
                                                                                        java.lang.reflect.Method method = CoreFunction.class.getDeclaredMethod(
                                                                                            "functionCeiling", EvalContext.class);
                                                                                        method.setAccessible(true);
                                                                                        Object result = method.invoke(coreFunction, context);
                                                                                        
                                                                                        // Assert
                                                                                        assertTrue(Double.isNaN(((Double) result).doubleValue()));
                                                                                    } catch (Exception e) {
                                                                                        fail("Exception occurred: " + e.getMessage());
                                                                                    }
                                                                                }

    @Test
                                                                                public void testFunctionRoundWithNormalNumber() {
                                                                                    // Setup mocks
                                                                                    CoreFunction coreFunction = mock(CoreFunction.class);
                                                                                    Expression arg1 = mock(Expression.class);
                                                                                    EvalContext context = mock(EvalContext.class);
                                                                                    
                                                                                    // Mock behavior
                                                                                    when(coreFunction.getArg1()).thenReturn(arg1);
                                                                                    when(arg1.computeValue(context)).thenReturn(5.6);
                                                                                    
                                                                                    // Call real method
                                                                                    when(coreFunction.computeValue(context)).thenCallRealMethod();
                                                                                    
                                                                                    // Test
                                                                                    Object result = coreFunction.computeValue(context);
                                                                                    assertEquals(6.0, ((Double) result).doubleValue(), 0.0001);
                                                                                }

    @Test
                                                                                public void testFunctionRoundWithNegativeNumber() {
                                                                                    // Setup mocks
                                                                                    CoreFunction coreFunction = mock(CoreFunction.class);
                                                                                    Expression arg1 = mock(Expression.class);
                                                                                    EvalContext context = mock(EvalContext.class);
                                                                                    
                                                                                    // Mock behavior
                                                                                    when(coreFunction.getArg1()).thenReturn(arg1);
                                                                                    when(arg1.computeValue(context)).thenReturn(-3.4);
                                                                                    
                                                                                    // Use reflection to set private field
                                                                                    try {
                                                                                        java.lang.reflect.Field field = CoreFunction.class.getDeclaredField("args");
                                                                                        field.setAccessible(true);
                                                                                        field.set(coreFunction, new Expression[]{arg1});
                                                                                    } catch (Exception e) {
                                                                                        fail("Failed to set private field via reflection");
                                                                                    }
                                                                                    
                                                                                    // Mock static method
                                                                                    try (org.mockito.MockedStatic<InfoSetUtil> mocked = mockStatic(InfoSetUtil.class)) {
                                                                                        mocked.when(() -> InfoSetUtil.doubleValue(-3.4)).thenReturn(-3.4);
                                                                                        
                                                                                        // Stub the method under test
                                                                                        when(coreFunction.computeValue(context)).thenCallRealMethod();
                                                                                        
                                                                                        // Execute and verify
                                                                                        Object result = coreFunction.computeValue(context);
                                                                                        assertEquals(-3.0, ((Double) result).doubleValue(), 0.0001);
                                                                                    }
                                                                                }

    @Test
                                                                                public void testFunctionRoundWithNaN() {
                                                                                    // Setup mocks
                                                                                    CoreFunction coreFunction = mock(CoreFunction.class);
                                                                                    Expression arg1 = mock(Expression.class);
                                                                                    EvalContext context = mock(EvalContext.class);
                                                                                    
                                                                                    // Mock behavior
                                                                                    when(coreFunction.getArg1()).thenReturn(arg1);
                                                                                    when(arg1.computeValue(context)).thenReturn(Double.NaN);
                                                                                    
                                                                                    // Call method under test
                                                                                    when(coreFunction.computeValue(context)).thenCallRealMethod();
                                                                                    
                                                                                    Object result = coreFunction.computeValue(context);
                                                                                    
                                                                                    // Assert
                                                                                    assertTrue(Double.isNaN(((Double) result).doubleValue()));
                                                                                }

    @Test
                                                                                public void testFunctionRoundWithNegativeInfinity() {
                                                                                    // Setup mocks
                                                                                    CoreFunction coreFunction = mock(CoreFunction.class);
                                                                                    Expression arg1 = mock(Expression.class);
                                                                                    EvalContext context = mock(EvalContext.class);
                                                                                    JXPathContext jxPathContext = mock(JXPathContext.class);
                                                                                    
                                                                                    // Configure mocks
                                                                                    when(coreFunction.getArg1()).thenReturn(arg1);
                                                                                    when(arg1.computeValue(context)).thenReturn(Double.NEGATIVE_INFINITY);
                                                                                    when(context.getJXPathContext()).thenReturn(jxPathContext);
                                                                                    when(coreFunction.computeValue(context)).thenCallRealMethod();
                                                                                    
                                                                                    // Test
                                                                                    Object result = coreFunction.computeValue(context);
                                                                                    assertEquals(Double.NEGATIVE_INFINITY, ((Double) result).doubleValue(), 0.0001);
                                                                                }

    @Test
                                                                                public void testFunctionRoundWithZero() {
                                                                                    // Setup mocks
                                                                                    CoreFunction coreFunction = mock(CoreFunction.class);
                                                                                    Expression arg1 = mock(Expression.class);
                                                                                    EvalContext context = mock(EvalContext.class);
                                                                                    
                                                                                    // Mock behavior
                                                                                    when(coreFunction.getArg1()).thenReturn(arg1);
                                                                                    when(arg1.computeValue(context)).thenReturn(0.0);
                                                                                    
                                                                                    // Use reflection to test private method
                                                                                    try {
                                                                                        java.lang.reflect.Method method = CoreFunction.class.getDeclaredMethod(
                                                                                            "functionRound", EvalContext.class);
                                                                                        method.setAccessible(true);
                                                                                        
                                                                                        Double result = (Double) method.invoke(coreFunction, context);
                                                                                        assertEquals(0.0, result.doubleValue(), 0.0001);
                                                                                    } catch (Exception e) {
                                                                                        fail("Exception occurred: " + e.getMessage());
                                                                                    }
                                                                                }

    @Test
                                                                                public void testFunctionRoundWithHalfUpRounding() {
                                                                                    // Setup mocks
                                                                                    CoreFunction coreFunction = mock(CoreFunction.class);
                                                                                    Expression arg1 = mock(Expression.class);
                                                                                    EvalContext context = mock(EvalContext.class);
                                                                                    
                                                                                    // Mock behavior
                                                                                    when(coreFunction.getArg1()).thenReturn(arg1);
                                                                                    when(arg1.computeValue(context)).thenReturn(2.5);
                                                                                    
                                                                                    // Use reflection to test private method
                                                                                    try {
                                                                                        java.lang.reflect.Method method = CoreFunction.class.getDeclaredMethod("functionRound", EvalContext.class);
                                                                                        method.setAccessible(true);
                                                                                        Object result = method.invoke(coreFunction, context);
                                                                                        assertEquals(3.0, ((Double) result).doubleValue(), 0.0001);
                                                                                    } catch (Exception e) {
                                                                                        fail("Exception occurred: " + e.getMessage());
                                                                                    }
                                                                                }

    @Test
                                                                                public void testFunctionRoundWithHalfDownRounding() {
                                                                                    // Setup mocks
                                                                                    CoreFunction coreFunction = mock(CoreFunction.class);
                                                                                    Expression arg1 = mock(Expression.class);
                                                                                    EvalContext context = mock(EvalContext.class);
                                                                                    
                                                                                    // Mock behavior
                                                                                    when(coreFunction.getArg1()).thenReturn(arg1);
                                                                                    when(arg1.computeValue(context)).thenReturn(-2.5);
                                                                                    when(coreFunction.computeValue(context)).thenCallRealMethod();
                                                                                    
                                                                                    // Call the actual method
                                                                                    Object result = coreFunction.computeValue(context);
                                                                                    
                                                                                    // Assert
                                                                                    assertEquals(-2.0, ((Double) result).doubleValue(), 0.0001);
                                                                                }

    @Test
                                                                            public void testFunctionFloorWithRegularNumber() throws Exception {
                                                                                // Setup mocks
                                                                                CoreFunction coreFunction = mock(CoreFunction.class);
                                                                                Expression arg1 = mock(Expression.class);
                                                                                EvalContext context = mock(EvalContext.class);
                                                                                
                                                                                // Mock behavior
                                                                                when(coreFunction.getArg1()).thenReturn(arg1);
                                                                                when(arg1.computeValue(context)).thenReturn(5.7);
                                                                                
                                                                                // Use reflection to access protected method
                                                                                Method method = CoreFunction.class.getDeclaredMethod("functionFloor", EvalContext.class);
                                                                                method.setAccessible(true);
                                                                                
                                                                                // Test
                                                                                Object result = method.invoke(coreFunction, context);
                                                                                assertEquals(5.0, ((Double) result).doubleValue(), 0.001);
                                                                            }

    @Test
                                                                            public void testFunctionFloorWithNegativeNumber() throws Exception {
                                                                                // Setup mocks
                                                                                CoreFunction coreFunction = mock(CoreFunction.class);
                                                                                Expression arg1 = mock(Expression.class);
                                                                                EvalContext context = mock(EvalContext.class);
                                                                                
                                                                                // Stub methods
                                                                                when(coreFunction.getArg1()).thenReturn(arg1);
                                                                                when(arg1.computeValue(context)).thenReturn(-3.2);
                                                                                
                                                                                // Use reflection to access protected method
                                                                                Method method = CoreFunction.class.getDeclaredMethod("functionFloor", EvalContext.class);
                                                                                method.setAccessible(true);
                                                                                
                                                                                // Call real method through reflection
                                                                                when(coreFunction.getArg1()).thenCallRealMethod();
                                                                                Object result = method.invoke(coreFunction, context);
                                                                                
                                                                                assertEquals(-4.0, ((Double) result).doubleValue(), 0.001);
                                                                            }

    @Test
                                                                            public void testFunctionFloorWithNaN() throws Exception {
                                                                                // Setup mocks
                                                                                CoreFunction coreFunction = mock(CoreFunction.class);
                                                                                EvalContext context = mock(EvalContext.class);
                                                                                Expression arg1 = mock(Expression.class);
                                                                                
                                                                                // Mock behavior
                                                                                when(coreFunction.getArg1()).thenReturn(arg1);
                                                                                when(arg1.computeValue(context)).thenReturn(Double.NaN);
                                                                                
                                                                                // Use reflection to access protected method
                                                                                Method method = CoreFunction.class.getDeclaredMethod("functionFloor", EvalContext.class);
                                                                                method.setAccessible(true);
                                                                                
                                                                                // Test
                                                                                Object result = method.invoke(coreFunction, context);
                                                                                assertTrue(Double.isNaN(((Double) result).doubleValue()));
                                                                            }

    @Test
                                                                            public void testFunctionFloorWithNegativeInfinity() throws Exception {
                                                                                // Create mocks
                                                                                CoreFunction coreFunction = mock(CoreFunction.class);
                                                                                Expression arg1 = mock(Expression.class);
                                                                                EvalContext context = mock(EvalContext.class);
                                                                                
                                                                                // Setup behavior
                                                                                when(coreFunction.getArg1()).thenReturn(arg1);
                                                                                when(arg1.computeValue(context)).thenReturn(Double.NEGATIVE_INFINITY);
                                                                                when(InfoSetUtil.doubleValue(Double.NEGATIVE_INFINITY)).thenReturn(Double.NEGATIVE_INFINITY);
                                                                                
                                                                                // Use reflection to access protected method
                                                                                Method method = CoreFunction.class.getDeclaredMethod("functionFloor", EvalContext.class);
                                                                                method.setAccessible(true);
                                                                                
                                                                                // Call the method under test
                                                                                Object result = method.invoke(coreFunction, context);
                                                                                
                                                                                // Verify
                                                                                assertEquals(Double.NEGATIVE_INFINITY, ((Double) result).doubleValue(), 0.001);
                                                                            }

    @Test
                                                                            public void testFunctionFloorWithInteger() throws Exception {
                                                                                // Setup mocks
                                                                                CoreFunction coreFunction = mock(CoreFunction.class);
                                                                                Expression arg1 = mock(Expression.class);
                                                                                EvalContext context = mock(EvalContext.class);
                                                                                JXPathContext jxPathContext = mock(JXPathContext.class);
                                                                                
                                                                                // Configure mocks
                                                                                when(coreFunction.getArg1()).thenReturn(arg1);
                                                                                when(arg1.computeValue(context)).thenReturn(10.0);
                                                                                when(context.getJXPathContext()).thenReturn(jxPathContext);
                                                                                
                                                                                // Mock static call
                                                                                when(InfoSetUtil.doubleValue(10.0)).thenReturn(10.0);
                                                                                
                                                                                // Use reflection to access protected method
                                                                                Method method = CoreFunction.class.getDeclaredMethod("functionFloor", EvalContext.class);
                                                                                method.setAccessible(true);
                                                                                
                                                                                // Call the method
                                                                                when(coreFunction.getArg1()).thenCallRealMethod();
                                                                                Object result = method.invoke(coreFunction, context);
                                                                                
                                                                                // Verify
                                                                                assertEquals(10.0, ((Double) result).doubleValue(), 0.001);
                                                                            }

    @Test
                                                                            public void testFunctionRoundWithPositiveInfinity() {
                                                                                CoreFunction coreFunction = mock(CoreFunction.class);
                                                                                Expression arg1 = mock(Expression.class);
                                                                                EvalContext context = mock(EvalContext.class);
                                                                                
                                                                                when(coreFunction.getArg1()).thenReturn(arg1);
                                                                                when(arg1.computeValue(context)).thenReturn(Double.POSITIVE_INFINITY);
                                                                                when(InfoSetUtil.doubleValue(Double.POSITIVE_INFINITY)).thenReturn(Double.POSITIVE_INFINITY);
                                                                                when(coreFunction.computeValue(context)).thenReturn(Double.POSITIVE_INFINITY);
                                                                            
                                                                                Object result = coreFunction.computeValue(context);
                                                                                assertEquals(Double.POSITIVE_INFINITY, ((Double) result).doubleValue(), 0.0001);
                                                                            }

    @Test(expected = RuntimeException.class)
                                                public void testFunctionCeilingWithWrongArgumentCount() {
                                                    Expression[] emptyArgs = new Expression[]{};
                                                    CoreFunction invalidFunction = new CoreFunction(Compiler.FUNCTION_CEILING, emptyArgs);
                                                    Object context = mock(Object.class);
                                                }

    @Test(expected = IllegalArgumentException.class)
                                                public void testFunctionRoundWithWrongArgumentCount() {
                                                    Expression[] emptyArgs = new Expression[]{};
                                                    CoreFunction invalidFunction = new CoreFunction(Compiler.FUNCTION_ROUND, emptyArgs);
                                                    Object context = mock(Object.class);
                                                }

    @Test
                                public void testFunctionFloorWithPositiveInfinity() throws Exception {
                                    // Setup mocks
                                    Expression arg1 = mock(Expression.class);
                                    EvalContext context = mock(EvalContext.class);
                                    
                                    // Mock behavior
                                    when(arg1.computeValue(context)).thenReturn(Double.POSITIVE_INFINITY);
                                    
                                    // Create anonymous subclass to test protected method
                                    CoreFunction testInstance = new CoreFunction(0, new Expression[]{arg1}) {
                                        @Override
                                        protected Object functionFloor(EvalContext context) {
                                            return super.functionFloor(context);
                                        }
                                    };
                                    
                                    // Use reflection to access protected method
                                    Method method = CoreFunction.class.getDeclaredMethod("functionFloor", EvalContext.class);
                                    method.setAccessible(true);
                                    
                                    // Call the method under test
                                    Object result = method.invoke(testInstance, context);
                                    
                                    // Verify
                                    assertEquals(Double.POSITIVE_INFINITY, ((Double) result).doubleValue(), 0.001);
                                }

    @Test
                        public void testFunctionCeilingWithNegativeNumber() {
                            // Define constant locally since it's not available from the test class
                            final int FUNCTION_CEILING = 1;
                            
                            // Setup mock objects
                            Expression arg1 = mock(Expression.class);
                            EvalContext context = mock(EvalContext.class);
                            
                            // Create CoreFunction instance with function name "ceiling"
                            Expression[] args = new Expression[]{arg1};
                            CoreFunction coreFunction = new CoreFunction(FUNCTION_CEILING, args);
                            
                            // Mock behavior
                            when(arg1.computeValue(context)).thenReturn(Double.valueOf(-2.7));
                            
                            // Test
                            Object result = coreFunction.computeValue(context);
                            assertEquals(-2.0, ((Double) result).doubleValue(), 0.001);
                        }

    @Test
                    public void testFunctionCeilingWithInteger() {
                        // Define function constant inside the method
                        final int FUNCTION_CEILING = 9;
                        
                        // Setup mocks
                        Expression arg1 = mock(Expression.class);
                        JXPathContext context = mock(JXPathContext.class);
                        EvalContext evalContext = mock(EvalContext.class);
                        
                        when(evalContext.getJXPathContext()).thenReturn(context);
                        
                        // Create CoreFunction instance with CEILING function
                        CoreFunction coreFunction = new CoreFunction(
                            FUNCTION_CEILING,
                            new Expression[] {arg1}
                        );
                    
                        // Mock behavior
                        when(arg1.compute(evalContext)).thenReturn(5.0);
                        
                        // Test
                        Object result = coreFunction.compute(evalContext);
                        assertEquals(5.0, ((Double) result).doubleValue(), 0.001);
                    }

    @Test
                public void testFunctionCeilingWithPositiveInfinity() {
                    // Define function name constant locally
                    final int FUNCTION_CEILING = 4; // Assuming FUNCTION_CEILING has value 4
                    
                    // Setup mock objects
                    EvalContext context = mock(EvalContext.class);
                    Expression arg1 = mock(Expression.class);
                    
                    // Create CoreFunction instance with mock argument
                    Expression[] args = new Expression[]{arg1};
                    CoreFunction coreFunction = new CoreFunction(FUNCTION_CEILING, args);
                    
                    // Configure mock behavior
                    when(arg1.computeValue(context)).thenReturn(Double.POSITIVE_INFINITY);
                    
                    // Execute test
                    Object result = coreFunction.computeValue(context);
                    
                    // Verify results
                    assertTrue(Double.isInfinite(((Double) result).doubleValue()));
                    assertEquals(Double.POSITIVE_INFINITY, ((Double) result).doubleValue(), 0.001);
                }

    @Test
        public void testFunctionFloorWithWrongArgumentCount() {
            String functionName = "floor";
            Expression[] emptyExpressions = new Expression[0];
            Expression mockExpression = mock(Expression.class);
{}
            Object context = mock(Object.class);
            
            try {
                java.lang.reflect.Method method = CoreFunction.class.getDeclaredMethod(
                    "functionFloor", Object.class, Expression[].class);
                method.setAccessible(true);
                fail("Expected RuntimeException");
            } catch (Exception e) {
                assertTrue(e.getCause() instanceof RuntimeException);
            }
        }


}
