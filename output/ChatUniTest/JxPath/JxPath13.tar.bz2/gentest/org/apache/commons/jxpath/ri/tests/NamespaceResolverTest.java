package gentest.org.apache.commons.jxpath.ri.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.*;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;
 
public class NamespaceResolverTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                    public void testGetNamespaceURI_WhenPrefixNotRegisteredAndPointerNull() {
                                                                                                                        NamespaceResolver namespaceResolver = new NamespaceResolver();
                                                                                                                        Pointer pointer = null;
                                                                                                                        // Use reflection to set the pointer field since it's likely private
                                                                                                                        try {
                                                                                                                            java.lang.reflect.Field field = NamespaceResolver.class.getDeclaredField("pointer");
                                                                                                                            field.setAccessible(true);
                                                                                                                            field.set(namespaceResolver, pointer);
                                                                                                                        } catch (Exception e) {
                                                                                                                            fail("Failed to set pointer field via reflection");
                                                                                                                        }
                                                                                                                        
                                                                                                                        String result = namespaceResolver.getNamespaceURI("test");
                                                                                                                        assertNull(result);
                                                                                                                    }

    @Test
                                                                                                                    public void testGetExternallyRegisteredNamespaceURI_WhenPrefixExists() throws Exception {
                                                                                                                        Map<String, String> namespaceMap = new HashMap<>();
                                                                                                                        namespaceMap.put("test", "http://test.com");
                                                                                                                        
                                                                                                                        NamespaceResolver namespaceResolver = new NamespaceResolver();
                                                                                                                        Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                            "getExternallyRegisteredNamespaceURI", String.class);
                                                                                                                        method.setAccessible(true);
                                                                                                                        String result = (String) method.invoke(namespaceResolver, "test");
                                                                                                                        
                                                                                                                        assertEquals("http://test.com", result);
                                                                                                                    }

    @Test
                                                                                                                public void testGetPrefixWithExternallyRegisteredPrefix() {
                                                                                                                    // Create test instance and mock data
                                                                                                                    NamespaceResolver namespaceResolver = new NamespaceResolver();
                                                                                                                    Map<String, String> namespaceMap = new HashMap<>();
                                                                                                                    Map<String, String> reverseMap = new HashMap<>();
                                                                                                                    
                                                                                                                    // Set up test data
                                                                                                                    namespaceMap.put("testPrefix", "testURI");
                                                                                                                    reverseMap.put("testURI", "testPrefix");
                                                                                                                    
                                                                                                                    // Use reflection to set private fields if needed
                                                                                                                    try {
                                                                                                                        java.lang.reflect.Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                                        namespaceMapField.setAccessible(true);
                                                                                                                        namespaceMapField.set(namespaceResolver, namespaceMap);
                                                                                                                        
                                                                                                                        java.lang.reflect.Field reverseMapField = NamespaceResolver.class.getDeclaredField("reverseMap");
                                                                                                                        reverseMapField.setAccessible(true);
                                                                                                                        reverseMapField.set(namespaceResolver, reverseMap);
                                                                                                                    } catch (Exception e) {
                                                                                                                        fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                    }
                                                                                                                    
                                                                                                                    // Execute test
                                                                                                                    String result = namespaceResolver.getPrefix("testURI");
                                                                                                                    assertEquals("testPrefix", result);
                                                                                                                }

    @Test
                                                                                                                public void testGetPrefixWithNullPointer() {
                                                                                                                    NamespaceResolver namespaceResolver = new NamespaceResolver();
                                                                                                                    try {
                                                                                                                        java.lang.reflect.Field pointerField = NamespaceResolver.class.getDeclaredField("pointer");
                                                                                                                        pointerField.setAccessible(true);
                                                                                                                        pointerField.set(namespaceResolver, null);
                                                                                                                    } catch (Exception e) {
                                                                                                                        fail("Failed to set pointer field via reflection");
                                                                                                                    }
                                                                                                                    
                                                                                                                    String result = namespaceResolver.getPrefix("testURI");
                                                                                                                    assertNull(result);
                                                                                                                }

    @Test
                                                                                                                public void testGetPrefixWithEmptyPrefix() {
                                                                                                                    NamespaceResolver namespaceResolver = new NamespaceResolver();
                                                                                                                    Map<String, String> namespaceMap = new HashMap<>();
                                                                                                                    Map<String, String> reverseMap = new HashMap<>();
                                                                                                                    
                                                                                                                    // Use reflection to set private fields
                                                                                                                    try {
                                                                                                                        java.lang.reflect.Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                                        namespaceMapField.setAccessible(true);
                                                                                                                        namespaceMapField.set(namespaceResolver, namespaceMap);
                                                                                                                        
                                                                                                                        java.lang.reflect.Field reverseMapField = NamespaceResolver.class.getDeclaredField("reverseMap");
                                                                                                                        reverseMapField.setAccessible(true);
                                                                                                                        reverseMapField.set(namespaceResolver, reverseMap);
                                                                                                                    } catch (Exception e) {
                                                                                                                        fail("Failed to set private fields via reflection");
                                                                                                                    }
                                                                                                            
                                                                                                                    namespaceMap.put("", "emptyURI");
                                                                                                                    reverseMap.put("emptyURI", "");
                                                                                                            
                                                                                                                    String result = namespaceResolver.getPrefix("emptyURI");
                                                                                                                    assertNull(result);
                                                                                                                }

    @Test
                                                                                                                public void testGetPrefixWithParentPointer() {
                                                                                                                    NodePointer pointer = mock(NodePointer.class);
                                                                                                                    NamespaceResolver parentResolver = mock(NamespaceResolver.class);
                                                                                                                    NamespaceResolver namespaceResolver = new NamespaceResolver(parentResolver);
                                                                                                                    
                                                                                                                    // Use reflection to set private field
                                                                                                                    try {
                                                                                                                        java.lang.reflect.Field field = NamespaceResolver.class.getDeclaredField("pointer");
                                                                                                                        field.setAccessible(true);
                                                                                                                        field.set(namespaceResolver, null);
                                                                                                                    } catch (Exception e) {
                                                                                                                        throw new RuntimeException(e);
                                                                                                                    }
                                                                                                                    
                                                                                                                    when(parentResolver.getNamespaceContextPointer()).thenReturn(pointer);
                                                                                                                    
                                                                                                                    String result = namespaceResolver.getPrefix("testURI");
                                                                                                                    assertNull(result);
                                                                                                                }

    @Test
                                                                                                                public void testSealWithoutParent() {
                                                                                                                    NamespaceResolver namespaceResolver = new NamespaceResolver(null);
                                                                                                                    assertFalse(namespaceResolver.isSealed());
                                                                                                                    namespaceResolver.seal();
                                                                                                                    assertTrue(namespaceResolver.isSealed());
                                                                                                                }

    @Test
                                                                                                                public void testSealWithParent() {
                                                                                                                    NamespaceResolver parentResolver = mock(NamespaceResolver.class);
                                                                                                                    NamespaceResolver namespaceResolver = new NamespaceResolver(parentResolver);
                                                                                                                    assertFalse(namespaceResolver.isSealed());
                                                                                                                    when(parentResolver.isSealed()).thenReturn(false);
                                                                                                                    
                                                                                                                    namespaceResolver.seal();
                                                                                                                    
                                                                                                                    assertTrue(namespaceResolver.isSealed());
                                                                                                                    verify(parentResolver).seal();
                                                                                                                }

    @Test
                                                                                                                public void testSealWithAlreadySealedParent() {
                                                                                                                    NamespaceResolver parentResolver = mock(NamespaceResolver.class);
                                                                                                                    NamespaceResolver namespaceResolver = new NamespaceResolver(parentResolver);
                                                                                                                    
                                                                                                                    assertFalse(namespaceResolver.isSealed());
                                                                                                                    when(parentResolver.isSealed()).thenReturn(true);
                                                                                                                    
                                                                                                                    namespaceResolver.seal();
                                                                                                                    
                                                                                                                    assertTrue(namespaceResolver.isSealed());
                                                                                                                    verify(parentResolver, never()).seal();
                                                                                                                }

    @Test
                                                                                                                public void testSealWithNullParent() {
                                                                                                                    NamespaceResolver namespaceResolver = new NamespaceResolver(null);
                                                                                                                    assertFalse(namespaceResolver.isSealed());
                                                                                                                    
                                                                                                                    namespaceResolver.seal();
                                                                                                                    
                                                                                                                    assertTrue(namespaceResolver.isSealed());
                                                                                                                }

    @Test
                                                                                                                public void testSealMultipleTimes() {
                                                                                                                    NamespaceResolver namespaceResolver = new NamespaceResolver();
                                                                                                                    namespaceResolver.seal();
                                                                                                                    assertTrue(namespaceResolver.isSealed());
                                                                                                                    
                                                                                                                    namespaceResolver.seal();
                                                                                                                    assertTrue(namespaceResolver.isSealed());
                                                                                                                }

    @Test
                                                                                                            public void testGetPrefixWithNullPointer1() {
                                                                                                                NamespaceResolver namespaceResolver = new NamespaceResolver();
                                                                                                                NodePointer pointer = null;
                                                                                                                try {
                                                                                                                    java.lang.reflect.Field field = namespaceResolver.getClass().getDeclaredField("pointer");
                                                                                                                    field.setAccessible(true);
                                                                                                                    field.set(namespaceResolver, pointer);
                                                                                                                } catch (Exception e) {
                                                                                                                    fail("Failed to set pointer field via reflection");
                                                                                                                }
                                                                                                                
                                                                                                                String result = namespaceResolver.getPrefix("testURI");
                                                                                                                assertNull(result);
                                                                                                            }

    @Test
                                                                                                            public void testGetPrefixWithEmptyPrefix1() {
                                                                                                                NamespaceResolver namespaceResolver = new NamespaceResolver();
                                                                                                                Map<String, String> namespaceMap = new HashMap<>();
                                                                                                                Map<String, String> reverseMap = new HashMap<>();
                                                                                                                
                                                                                                                try {
                                                                                                                    java.lang.reflect.Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                                    namespaceMapField.setAccessible(true);
                                                                                                                    namespaceMapField.set(namespaceResolver, namespaceMap);
                                                                                                                    
                                                                                                                    java.lang.reflect.Field reverseMapField = NamespaceResolver.class.getDeclaredField("reverseMap");
                                                                                                                    reverseMapField.setAccessible(true);
                                                                                                                    reverseMapField.set(namespaceResolver, reverseMap);
                                                                                                                } catch (Exception e) {
                                                                                                                    fail("Failed to set private fields using reflection");
                                                                                                                }
                                                                                                                
                                                                                                                namespaceMap.put("", "emptyURI");
                                                                                                                reverseMap.put("emptyURI", "");
                                                                                                                
                                                                                                                String result = namespaceResolver.getPrefix("emptyURI");
                                                                                                                assertNull(result);
                                                                                                            }

    @Test
                                                                                                            public void testCloneSuccessfully() throws Exception {
                                                                                                                NodePointer mockPointer = mock(NodePointer.class);
                                                                                                                NamespaceResolver original = new NamespaceResolver();
                                                                                                                original.registerNamespace("test", "http://test.com");
                                                                                                                original.setNamespaceContextPointer(mockPointer);
                                                                                                                original.seal();
                                                                                                        
                                                                                                                NamespaceResolver cloned = (NamespaceResolver) original.clone();
                                                                                                        
                                                                                                                assertNotNull(cloned);
                                                                                                                assertNotSame(original, cloned);
                                                                                                                
                                                                                                                // Use reflection to access protected fields
                                                                                                                java.lang.reflect.Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                                namespaceMapField.setAccessible(true);
                                                                                                                Object originalNamespaceMap = namespaceMapField.get(original);
                                                                                                                Object clonedNamespaceMap = namespaceMapField.get(cloned);
                                                                                                                assertEquals(originalNamespaceMap, clonedNamespaceMap);
                                                                                                        
                                                                                                                java.lang.reflect.Field pointerField = NamespaceResolver.class.getDeclaredField("pointer");
                                                                                                                pointerField.setAccessible(true);
                                                                                                                Object originalPointer = pointerField.get(original);
                                                                                                                Object clonedPointer = pointerField.get(cloned);
                                                                                                                assertEquals(originalPointer, clonedPointer);
                                                                                                        
                                                                                                                assertFalse(cloned.isSealed());
                                                                                                            }

    @Test
                                                                                                            public void testCloneWithNullPointer() throws Exception {
                                                                                                                NamespaceResolver original = new NamespaceResolver();
                                                                                                                original.registerNamespace("test", "http://test.com");
                                                                                                                original.setNamespaceContextPointer(null);
                                                                                                                
                                                                                                                NamespaceResolver cloned = (NamespaceResolver) original.clone();
                                                                                                                
                                                                                                                assertNotNull(cloned);
                                                                                                                assertNull(original.getNamespaceContextPointer());
                                                                                                            }

    @Test
                                                                                                            public void testGetNamespaceURI_WhenPrefixNotRegisteredButPointerNotNull() {
                                                                                                                org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver = 
                                                                                                                    new org.apache.commons.jxpath.ri.NamespaceResolver();
                                                                                                                NodePointer mockPointer = mock(NodePointer.class);
                                                                                                                
                                                                                                                namespaceResolver.setNamespaceContextPointer(mockPointer);
                                                                                                                when(mockPointer.getNamespaceURI("test")).thenReturn("http://pointer.com");
                                                                                                                
                                                                                                                String result = namespaceResolver.getNamespaceURI("test");
                                                                                                                assertEquals("http://pointer.com", result);
                                                                                                            }

    @Test
                                                                                                            public void testGetNamespaceURI_WhenPrefixRegisteredAndPointerNotNull() {
                                                                                                                NamespaceResolver namespaceResolver = new NamespaceResolver();
                                                                                                                NodePointer mockPointer = mock(NodePointer.class);
                                                                                                                when(mockPointer.getNamespaceURI("test")).thenReturn("http://test.com");
                                                                                                                
                                                                                                                namespaceResolver.registerNamespace("test", "http://test.com");
                                                                                                                namespaceResolver.setNamespaceContextPointer(mockPointer);
                                                                                                                
                                                                                                                String result = namespaceResolver.getNamespaceURI("test");
                                                                                                                assertEquals("http://test.com", result);
                                                                                                            }

    @Test
                                                                                                            public void testGetNamespaceURI_WhenPrefixNotRegisteredInCurrentButInParent() {
                                                                                                                NamespaceResolver mockParent = mock(NamespaceResolver.class);
                                                                                                                NamespaceResolver namespaceResolver = new NamespaceResolver(mockParent);
                                                                                                                
                                                                                                                // Use reflection to access protected method
                                                                                                                try {
                                                                                                                    java.lang.reflect.Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                        "getExternallyRegisteredNamespaceURI", String.class);
                                                                                                                    method.setAccessible(true);
                                                                                                                    when(method.invoke(mockParent, "test")).thenReturn("http://parent.com");
                                                                                                                    
                                                                                                                    String result = namespaceResolver.getNamespaceURI("test");
                                                                                                                    assertEquals("http://parent.com", result);
                                                                                                                } catch (Exception e) {
                                                                                                                    fail("Reflection failed: " + e.getMessage());
                                                                                                                }
                                                                                                            }

    @Test
                                                                                                            public void testGetNamespaceURI_WhenPrefixNotRegisteredInCurrentButPointerNotNull() {
                                                                                                                NamespaceResolver namespaceResolver;
                                                                                                                NamespaceResolver mockParent = mock(NamespaceResolver.class);
                                                                                                                NodePointer mockPointer = mock(NodePointer.class);
                                                                                                                
                                                                                                                namespaceResolver = new NamespaceResolver(mockParent);
                                                                                                                namespaceResolver.setNamespaceContextPointer(mockPointer);
                                                                                                                
                                                                                                                // Use reflection to access protected method
                                                                                                                try {
                                                                                                                    java.lang.reflect.Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                        "getExternallyRegisteredNamespaceURI", String.class);
                                                                                                                    method.setAccessible(true);
                                                                                                                    when(method.invoke(mockParent, "test")).thenReturn(null);
                                                                                                                } catch (Exception e) {
                                                                                                                    fail("Reflection failed: " + e.getMessage());
                                                                                                                }
                                                                                                                
                                                                                                                when(mockPointer.getNamespaceURI("test")).thenReturn("http://pointer.com");
                                                                                                                
                                                                                                                String result = namespaceResolver.getNamespaceURI("test");
                                                                                                                assertEquals("http://pointer.com", result);
                                                                                                            }

    @Test
                                                                                                            public void testGetExternallyRegisteredNamespaceURI_WhenPrefixDoesNotExistButParentHasIt() throws Exception {
                                                                                                                NamespaceResolver parentResolver = mock(NamespaceResolver.class);
                                                                                                                NamespaceResolver namespaceResolver = new NamespaceResolver(parentResolver);
                                                                                                                Map<String, String> namespaceMap = new HashMap<String, String>();
                                                                                                                
                                                                                                                // Use reflection to set private field
                                                                                                                Field field = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                                field.setAccessible(true);
                                                                                                                field.set(namespaceResolver, namespaceMap);
                                                                                                                
                                                                                                                when(parentResolver.getNamespaceURI("parentPrefix"))
                                                                                                                    .thenReturn("http://parent.com");
                                                                                                                
                                                                                                                // No need to use reflection since the method is protected and we're in the same package
                                                                                                                String result = namespaceResolver.getNamespaceURI("parentPrefix");
                                                                                                                
                                                                                                                assertEquals("http://parent.com", result);
                                                                                                            }

    @Test
                                                                                                            public void testGetExternallyRegisteredNamespaceURI_WhenPrefixExistsInBothCurrentAndParent() throws Exception {
                                                                                                                Map<String, String> namespaceMap = new HashMap<>();
                                                                                                                namespaceMap.put("test", "http://current.com");
                                                                                                                
                                                                                                                NamespaceResolver parentResolver = mock(NamespaceResolver.class);
                                                                                                                NamespaceResolver namespaceResolver = new NamespaceResolver(parentResolver);
                                                                                                                
                                                                                                                // Use reflection to set the private namespaceMap field
                                                                                                                java.lang.reflect.Field field = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                                field.setAccessible(true);
                                                                                                                field.set(namespaceResolver, namespaceMap);
                                                                                                                
                                                                                                                // Use reflection to invoke protected method
                                                                                                                java.lang.reflect.Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                    "getExternallyRegisteredNamespaceURI", String.class);
                                                                                                                method.setAccessible(true);
                                                                                                                
                                                                                                                when(method.invoke(parentResolver, "test"))
                                                                                                                    .thenReturn("http://parent.com");
                                                                                                                
                                                                                                                String result = (String) method.invoke(namespaceResolver, "test");
                                                                                                                
                                                                                                                assertEquals("http://current.com", result);
                                                                                                            }

    @Test
                                                                                                            public void testGetPrefixWithPointer() throws Exception {
                                                                                                                NamespaceResolver namespaceResolver = new NamespaceResolver();
                                                                                                                NodePointer pointer = mock(NodePointer.class);
                                                                                                                
                                                                                                                // Use reflection to set the protected field
                                                                                                                Field pointerField = NamespaceResolver.class.getDeclaredField("pointer");
                                                                                                                pointerField.setAccessible(true);
                                                                                                                pointerField.set(namespaceResolver, pointer);
                                                                                                                
                                                                                                                when(pointer.getNamespaceURI("testPrefix")).thenReturn("testURI");
                                                                                                                when(pointer.getName()).thenReturn(new QName("testPrefix"));
                                                                                                        
                                                                                                                Method getPrefixMethod = NamespaceResolver.class.getDeclaredMethod("getPrefix", 
                                                                                                                    NodePointer.class, String.class);
                                                                                                                getPrefixMethod.setAccessible(true);
                                                                                                                
                                                                                                                // Mock the static method call using reflection
                                                                                                                when(getPrefixMethod.invoke(null, pointer, "testURI")).thenReturn("testPrefix");
                                                                                                        
                                                                                                                String result = namespaceResolver.getPrefix("testURI");
                                                                                                                assertEquals("testPrefix", result);
                                                                                                            }

    @Test
                                                                                                            public void testGetExternallyRegisteredPrefix_WithExistingReverseMap() throws Exception {
                                                                                                                NamespaceResolver namespaceResolver = new NamespaceResolver(null);
                                                                                                                Map<String, String> reverseMap = new HashMap<>();
                                                                                                                Map<String, String> namespaceMap = new HashMap<>();
                                                                                                                
                                                                                                                reverseMap.put("uri1", "prefix1");
                                                                                                                reverseMap.put("uri2", "prefix2");
                                                                                                        
                                                                                                                // Use reflection to set private fields
                                                                                                                Field reverseMapField = NamespaceResolver.class.getDeclaredField("reverseMap");
                                                                                                                reverseMapField.setAccessible(true);
                                                                                                                reverseMapField.set(namespaceResolver, reverseMap);
                                                                                                        
                                                                                                                Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                                namespaceMapField.setAccessible(true);
                                                                                                                namespaceMapField.set(namespaceResolver, namespaceMap);
                                                                                                        
                                                                                                                // Use reflection to invoke protected method
                                                                                                                java.lang.reflect.Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                    "getExternallyRegisteredPrefix", String.class);
                                                                                                                method.setAccessible(true);
                                                                                                                String result = (String) method.invoke(namespaceResolver, "uri1");
                                                                                                                
                                                                                                                assertEquals("prefix1", result);
                                                                                                            }

    @Test
                                                                                                            public void testGetExternallyRegisteredPrefix_WithNonExistentURI() throws Exception {
                                                                                                                NamespaceResolver namespaceResolver = new NamespaceResolver(null);
                                                                                                                Map<String, String> reverseMap = new HashMap<>();
                                                                                                                Map<String, String> namespaceMap = new HashMap<>();
                                                                                                                reverseMap.put("uri1", "prefix1");
                                                                                                        
                                                                                                                // Set private fields using reflection
                                                                                                                java.lang.reflect.Field reverseMapField = NamespaceResolver.class.getDeclaredField("reverseMap");
                                                                                                                reverseMapField.setAccessible(true);
                                                                                                                reverseMapField.set(namespaceResolver, reverseMap);
                                                                                                        
                                                                                                                java.lang.reflect.Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                                namespaceMapField.setAccessible(true);
                                                                                                                namespaceMapField.set(namespaceResolver, namespaceMap);
                                                                                                        
                                                                                                                // Access protected method using reflection
                                                                                                                java.lang.reflect.Method method = NamespaceResolver.class.getDeclaredMethod("getExternallyRegisteredPrefix", String.class);
                                                                                                                method.setAccessible(true);
                                                                                                                String result = (String) method.invoke(namespaceResolver, "nonexistent");
                                                                                                                
                                                                                                                assertNull(result);
                                                                                                            }

    @Test
                                                                                                            public void testGetExternallyRegisteredPrefix_WithNullParent() throws Exception {
                                                                                                                class TestNamespaceResolver extends NamespaceResolver {
                                                                                                                    public TestNamespaceResolver(NamespaceResolver parent) {
                                                                                                                        super(parent);
                                                                                                                    }
                                                                                                                    
                                                                                                                    @Override
                                                                                                                    protected String getExternallyRegisteredPrefix(String prefix) {
                                                                                                                        return super.getExternallyRegisteredPrefix(prefix);
                                                                                                                    }
                                                                                                                }
                                                                                                                
                                                                                                                TestNamespaceResolver namespaceResolver = new TestNamespaceResolver(null);
                                                                                                                Map<String, String> namespaceMap = new HashMap<>();
                                                                                                                namespaceMap.put("prefix", "uri");
                                                                                                                
                                                                                                                // Use reflection to set private field
                                                                                                                java.lang.reflect.Field field = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                                field.setAccessible(true);
                                                                                                                field.set(namespaceResolver, namespaceMap);
                                                                                                            
                                                                                                                String result = namespaceResolver.getExternallyRegisteredPrefix("nonexistent");
                                                                                                                assertNull(result);
                                                                                                            }

    @Test
                                                                                                            public void testGetExternallyRegisteredPrefix_WithEmptyNamespaceMap() throws Exception {
                                                                                                                NamespaceResolver namespaceResolver = new NamespaceResolver(null);
                                                                                                                
                                                                                                                // Use reflection to set private field
                                                                                                                Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                                namespaceMapField.setAccessible(true);
                                                                                                                namespaceMapField.set(namespaceResolver, new HashMap<>());
                                                                                                                
                                                                                                                Field reverseMapField = NamespaceResolver.class.getDeclaredField("reverseMap");
                                                                                                                reverseMapField.setAccessible(true);
                                                                                                                reverseMapField.set(namespaceResolver, null);
                                                                                                        
                                                                                                                // Use reflection to invoke protected method
                                                                                                                java.lang.reflect.Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                    "getExternallyRegisteredPrefix", String.class);
                                                                                                                method.setAccessible(true);
                                                                                                                String result = (String) method.invoke(namespaceResolver, "anyURI");
                                                                                                                
                                                                                                                assertNull(result);
                                                                                                            }

    @Test
                                                                                                        public void testCloneWithParent() throws Exception {
                                                                                                            NamespaceResolver parent = new NamespaceResolver();
                                                                                                            NamespaceResolver original = new NamespaceResolver(parent);
                                                                                                            original.registerNamespace("test", "http://test.com");
                                                                                                            NodePointer mockPointer = mock(NodePointer.class);
                                                                                                            original.setNamespaceContextPointer(mockPointer);
                                                                                                            original.seal();
                                                                                                        
                                                                                                            NamespaceResolver cloned = (NamespaceResolver) original.clone();
                                                                                                        
                                                                                                            assertNotNull(cloned);
                                                                                                            // Access parent through reflection since it's protected
                                                                                                            NamespaceResolver clonedParent = (NamespaceResolver) cloned.getClass()
                                                                                                                .getDeclaredField("parent")
                                                                                                                .get(cloned);
                                                                                                            assertEquals(parent, clonedParent);
                                                                                                            assertFalse(cloned.isSealed());
                                                                                                        }

    @Test
                                                                                                        public void testCloneEmptyResolver() throws Exception {
                                                                                                            NamespaceResolver original = new NamespaceResolver();
                                                                                                            NamespaceResolver cloned = (NamespaceResolver) original.clone();
                                                                                                    
                                                                                                            assertNotNull(cloned);
                                                                                                            
                                                                                                            // Use reflection to access protected fields
                                                                                                            Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                            namespaceMapField.setAccessible(true);
                                                                                                            assertTrue(((Map<?, ?>) namespaceMapField.get(cloned)).isEmpty());
                                                                                                        
                                                                                                            Field pointerField = NamespaceResolver.class.getDeclaredField("pointer");
                                                                                                            pointerField.setAccessible(true);
                                                                                                            assertNull(pointerField.get(cloned));
                                                                                                        
                                                                                                            Field sealedField = NamespaceResolver.class.getDeclaredField("sealed");
                                                                                                            sealedField.setAccessible(true);
                                                                                                            assertFalse(sealedField.getBoolean(cloned));
                                                                                                        }

    @Test
                                                                                                        public void testGetPrefixWithParentExternallyRegisteredPrefix() throws Exception {
                                                                                                            NamespaceResolver parentResolver = mock(NamespaceResolver.class);
                                                                                                            Map<String, String> namespaceMap = new HashMap<String, String>();
                                                                                                            Map<String, String> reverseMap = new HashMap<String, String>();
                                                                                                            
                                                                                                            // Use reflection to invoke protected method
                                                                                                            when(parentResolver.getPrefix("testURI")).thenReturn("parentPrefix");
                                                                                                            NamespaceResolver namespaceResolver = new NamespaceResolver(parentResolver);
                                                                                                            
                                                                                                            // Use reflection to set protected fields
                                                                                                            Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                            namespaceMapField.setAccessible(true);
                                                                                                            namespaceMapField.set(namespaceResolver, namespaceMap);
                                                                                                            
                                                                                                            Field reverseMapField = NamespaceResolver.class.getDeclaredField("reverseMap");
                                                                                                            reverseMapField.setAccessible(true);
                                                                                                            reverseMapField.set(namespaceResolver, reverseMap);
                                                                                                            
                                                                                                            String result = namespaceResolver.getPrefix("testURI");
                                                                                                            assertEquals("parentPrefix", result);
                                                                                                        }

    @Test
                                                                                                        public void testGetExternallyRegisteredPrefix_WithParentResolver() throws Exception {
                                                                                                            // Helper method to set private fields
                                                                                                            class TestHelper {
                                                                                                                void setPrivateField(Object target, String fieldName, Object value) throws Exception {
                                                                                                                    Field field = target.getClass().getDeclaredField(fieldName);
                                                                                                                    field.setAccessible(true);
                                                                                                                    field.set(target, value);
                                                                                                                }
                                                                                                            }
                                                                                                            TestHelper helper = new TestHelper();
                                                                                                    
                                                                                                            NamespaceResolver parentResolver = new NamespaceResolver(null);
                                                                                                            Map<String, String> parentNamespaceMap = new HashMap<>();
                                                                                                            parentNamespaceMap.put("parentPrefix", "parentURI");
                                                                                                            helper.setPrivateField(parentResolver, "namespaceMap", parentNamespaceMap);
                                                                                                            
                                                                                                            NamespaceResolver namespaceResolver = new NamespaceResolver(parentResolver);
                                                                                                            Map<String, String> namespaceMap = new HashMap<>();
                                                                                                            namespaceMap.put("childPrefix", "childURI");
                                                                                                            helper.setPrivateField(namespaceResolver, "namespaceMap", namespaceMap);
                                                                                                            
                                                                                                            // Test child URI
                                                                                                            Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                "getExternallyRegisteredPrefix", String.class);
                                                                                                            method.setAccessible(true);
                                                                                                            String result = (String) method.invoke(namespaceResolver, "childURI");
                                                                                                            assertEquals("childPrefix", result);
                                                                                                            
                                                                                                            // Test parent URI
                                                                                                            result = (String) method.invoke(namespaceResolver, "parentURI");
                                                                                                            assertEquals("parentPrefix", result);
                                                                                                        }

    @Test
                                                                                                    public void testGetExternallyRegisteredNamespaceURI_WhenPrefixDoesNotExistAndParentDoesNotHaveIt() throws Exception {
                                                                                                        NamespaceResolver parentResolver = mock(NamespaceResolver.class);
                                                                                                        Map<String, String> namespaceMap = new HashMap<>();
                                                                                                        NamespaceResolver namespaceResolver = new NamespaceResolver(parentResolver);
                                                                                                        
                                                                                                        // Use reflection to set the private field
                                                                                                        Field field = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                        field.setAccessible(true);
                                                                                                        field.set(namespaceResolver, namespaceMap);
                                                                                                        
                                                                                                        // Use reflection to access protected method
                                                                                                        Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                                            "getExternallyRegisteredNamespaceURI", String.class);
                                                                                                        method.setAccessible(true);
                                                                                                        
                                                                                                        // Mock parent resolver behavior using reflection
                                                                                                        Method parentMethod = NamespaceResolver.class.getDeclaredMethod(
                                                                                                            "getExternallyRegisteredNamespaceURI", String.class);
                                                                                                        parentMethod.setAccessible(true);
                                                                                                        when(parentMethod.invoke(parentResolver, "nonexistent")).thenReturn(null);
                                                                                                        
                                                                                                        String result = (String) method.invoke(namespaceResolver, "nonexistent");
                                                                                                        
                                                                                                        assertNull(result);
                                                                                                    }

    @Test
                                                                                                    public void testGetExternallyRegisteredPrefix_WithReverseMapNull() throws Exception {
                                                                                                        // Initialize test variables
                                                                                                        NamespaceResolver namespaceResolver = new NamespaceResolver(null) {
                                                                                                            @Override
                                                                                                            protected String getExternallyRegisteredPrefix(String uri) {
                                                                                                                return super.getExternallyRegisteredPrefix(uri);
                                                                                                            }
                                                                                                        };
                                                                                                        Map<String, String> namespaceMap = new HashMap<>();
                                                                                                        namespaceMap.put("prefix1", "uri1");
                                                                                                        namespaceMap.put("prefix2", "uri2");
                                                                                                    
                                                                                                        // Use reflection to set private field
                                                                                                        Field field = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                        field.setAccessible(true);
                                                                                                        field.set(namespaceResolver, namespaceMap);
                                                                                                    
                                                                                                        // Use reflection to call protected method
                                                                                                        java.lang.reflect.Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                                            "getExternallyRegisteredPrefix", String.class);
                                                                                                        method.setAccessible(true);
                                                                                                        String result = (String) method.invoke(namespaceResolver, "uri1");
                                                                                                    
                                                                                                        assertEquals("prefix1", result);
                                                                                                    
                                                                                                        // Verify reverseMap was initialized
                                                                                                        Field reverseMapField = NamespaceResolver.class.getDeclaredField("reverseMap");
                                                                                                        reverseMapField.setAccessible(true);
                                                                                                        assertNotNull(reverseMapField.get(namespaceResolver));
                                                                                                    }

    @Test
                                                                                            public void testGetNamespaceURI_WhenPrefixNotRegisteredAnywhere() throws Exception {
                                                                                                NamespaceResolver mockParent = mock(NamespaceResolver.class);
                                                                                                NamespaceResolver namespaceResolver = new NamespaceResolver(mockParent);
                                                                                                
                                                                                                // Mock the parent behavior
                                                                                                when(mockParent.getNamespaceURI("test")).thenReturn(null);
                                                                                                
                                                                                                // Use reflection to access protected method
                                                                                                Method getExternallyRegisteredNamespaceURI = NamespaceResolver.class
                                                                                                    .getDeclaredMethod("getExternallyRegisteredNamespaceURI", String.class);
                                                                                                getExternallyRegisteredNamespaceURI.setAccessible(true);
                                                                                                
                                                                                                // Invoke the method
                                                                                                String result = (String) getExternallyRegisteredNamespaceURI.invoke(namespaceResolver, "test");
                                                                                                
                                                                                                assertNull(namespaceResolver.getNamespaceURI("test"));
                                                                                            }

    @Test
                                                                                public void testGetNamespaceURI_WhenPrefixRegistered() {
                                                                                    NamespaceResolver namespaceResolver = new NamespaceResolver();
                                                                                    Pointer pointer = mock(Pointer.class);
                                                                                    
                                                                                    // Use reflection to set the private pointer field
                                                                                    try {
                                                                                        java.lang.reflect.Field field = NamespaceResolver.class.getDeclaredField("pointer");
                                                                                        field.setAccessible(true);
                                                                                        field.set(namespaceResolver, pointer);
                                                                                    } catch (Exception e) {
                                                                                        fail("Failed to set pointer field via reflection");
                                                                                    }
                                                                                    
                                                                                    namespaceResolver.registerNamespace("test", "http://test.com");
                                                                                    String result = namespaceResolver.getNamespaceURI("test");
                                                                                    assertEquals("http://test.com", result);
                                                                                }

    @Test
                                                                                public void testGetPrefixWithNoMatch() {
                                                                                    NodePointer parent = mock(NodePointer.class);
                                                                                    NamespaceResolver namespaceResolver = new NamespaceResolver();
                                                                                    when(parent.getNamespaceResolver()).thenReturn(namespaceResolver);
                                                                                    String result = namespaceResolver.getPrefix("nonExistentURI");
                                                                                    assertNull(result);
                                                                                }

    @Test
                                                                                public void testGetPrefixWithPointerAndNoExternallyRegisteredPrefix() throws Exception {
                                                                                    class TestNamespaceResolver {
                                                                                        public NodePointer testPointer;
                                                                                        
                                                                                        public String getPrefix(String namespaceURI) {
                                                                                            return null;
                                                                                        }
                                                                                        
                                                                                        public NodePointer getPointer() {
                                                                                            return this.testPointer;
                                                                                        }
                                                                                    }
                                                                                    
                                                                                    TestNamespaceResolver namespaceResolver = new TestNamespaceResolver();
                                                                                    NodePointer pointer = mock(NodePointer.class);
                                                                                    
                                                                                    namespaceResolver.testPointer = pointer;
                                                                                    when(pointer.getNamespaceURI(anyString())).thenReturn("testURI");
                                                                                    when(pointer.getName()).thenReturn(new QName("testPrefix", "testURI"));
                                                                                
                                                                                    Method getPrefixMethod = TestNamespaceResolver.class.getDeclaredMethod("getPrefix", 
                                                                                        String.class);
                                                                                    getPrefixMethod.setAccessible(true);
                                                                                    
                                                                                    TestNamespaceResolver spyResolver = spy(namespaceResolver);
                                                                                    doReturn("testPrefix").when(spyResolver).getPrefix("testURI");
                                                                                
                                                                                    String result = spyResolver.getPrefix("testURI");
                                                                                    assertEquals("testPrefix", result);
                                                                                }

    @Test
                                                                        public void testCloneUnsealedResolver() throws Exception {
                                                                            NamespaceResolver original = new NamespaceResolver();
                                                                            original.registerNamespace("test", "http://test.com");
                                                                            
                                                                            NamespaceResolver cloned = (NamespaceResolver) original.clone();
                                                                            
                                                                            assertNotNull(cloned);
                                                                            assertEquals("http://test.com", cloned.getNamespaceURI("test"));
                                                                        }

    @Test
                                                                        public void testGetExternallyRegisteredNamespaceURI_WhenPrefixDoesNotExist() throws Exception {
                                                                            // Create mock objects
                                                                            Object namespaceResolver = mock(NamespaceResolver.class);
                                                                            Map<String, String> namespaceMap = new HashMap<>();
                                                                            
                                                                            // Create anonymous subclass to access protected method
                                                                            NamespaceResolver child = new NamespaceResolver() {
                                                                                @Override
                                                                                protected String getExternallyRegisteredNamespaceURI(String prefix) {
                                                                                    try {
                                                                                        Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                            "getExternallyRegisteredNamespaceURI", String.class);
                                                                                        method.setAccessible(true);
                                                                                        return (String) method.invoke(this, prefix);
                                                                                    } catch (Exception e) {
                                                                                        throw new RuntimeException(e);
                                                                                    }
                                                                                }
                                                                            };
                                                                            
                                                                            // Set up child's state using reflection
                                                                            Method setParentMethod = NamespaceResolver.class.getDeclaredMethod("setParent", NamespaceResolver.class);
                                                                            setParentMethod.setAccessible(true);
                                                                            setParentMethod.invoke(child, namespaceResolver);
                                                                            
                                                                            Method setNamespaceMapMethod = NamespaceResolver.class.getDeclaredMethod("setNamespaceMap", Map.class);
                                                                            setNamespaceMapMethod.setAccessible(true);
                                                                            setNamespaceMapMethod.invoke(child, namespaceMap);
                                                                            
                                                                            // Set up mock behavior using reflection
                                                                            Method mockMethod = namespaceResolver.getClass().getMethod("getExternallyRegisteredNamespaceURI", String.class);
                                                                            when(mockMethod.invoke(namespaceResolver, "nonexistent")).thenReturn(null);
                                                                            
                                                                            // Invoke method under test
                                                                            Method testMethod = NamespaceResolver.class.getDeclaredMethod("getExternallyRegisteredNamespaceURI", String.class);
                                                                            testMethod.setAccessible(true);
                                                                            String result = (String) testMethod.invoke(child, "nonexistent");
                                                                            
                                                                            // Verify result
                                                                            assertNull(result);
                                                                        }

    @Test
                                                                    public void testGetPrefixWithNullNamespaceIterator() {
                                                                        NodePointer pointer = mock(NodePointer.class);
                                                                        when(pointer.namespaceIterator()).thenReturn(null);
                                                                        when(pointer.getParent()).thenReturn(null);
                                                                        
                                                                        NamespaceResolver resolver = new NamespaceResolver();
                                                                        resolver.setNamespaceContextPointer(pointer);
                                                                        String result = resolver.getPrefix("someNamespace");
                                                                        
                                                                        assertNull(result);
                                                                    }

    @Test
                                            public void testGetPrefixWithNoMatchingNamespace() {
                                                class NamespaceResolver {
                                                    public String getPrefix(NodePointer pointer, String namespaceURI) {
                                                        return null; // Mock implementation
                                                    }
                                                }
                                                
                                                NamespaceResolver resolver = new NamespaceResolver();
                                                NodePointer pointer = mock(NodePointer.class);
                                                NodePointer parentPointer = mock(NodePointer.class);
                                                NodeIterator namespaceIterator = mock(NodeIterator.class);
                                                
                                                when(pointer.namespaceIterator()).thenReturn(namespaceIterator);
                                                when(namespaceIterator.setPosition(anyInt())).thenReturn(false);
                                                when(pointer.getParent()).thenReturn(parentPointer);
                                                when(parentPointer.namespaceIterator()).thenReturn(namespaceIterator);
                                                
                                                String result = resolver.getPrefix(pointer, "http://example.com");
                                                assertNull(result);
                                            }

    @Test
                                    public void testGetPrefixWithMultipleNamespaceIterations() {
                                        NodePointer pointer = mock(NodePointer.class);
                                        NodeIterator namespaceIterator = mock(NodeIterator.class);
                                        NodePointer nsPointer = mock(NodePointer.class);
                                        
                                        when(pointer.namespaceIterator()).thenReturn(namespaceIterator);
                                        when(namespaceIterator.setPosition(1)).thenReturn(true);
                                        when(namespaceIterator.getNodePointer()).thenReturn(nsPointer);
                                        when(nsPointer.getNamespaceURI()).thenReturn("http://other.com");
                                        when(nsPointer.getName()).thenReturn(new QName("http://other.com", "otherPrefix"));
                                        when(namespaceIterator.setPosition(2)).thenReturn(true);
                                        when(namespaceIterator.getNodePointer()).thenReturn(nsPointer);
                                        when(nsPointer.getNamespaceURI()).thenReturn("http://example.com");
                                        when(nsPointer.getName()).thenReturn(new QName("http://example.com", "prefix"));
                                        when(namespaceIterator.setPosition(3)).thenReturn(false);
                                        when(pointer.getParent()).thenReturn(null);
                                        
                                        NamespaceResolver resolver = new NamespaceResolver();
                                        resolver.setNamespaceContextPointer(pointer);
                                        String result = resolver.getPrefix("http://example.com");
                                        
                                        assertEquals("prefix", result);
                                    }

    @Test
                            public void testGetPrefixWithParentPointerMatch() {
                                NodePointer pointer = mock(NodePointer.class);
                                NodeIterator namespaceIterator = mock(NodeIterator.class);
                                NodePointer parentPointer = mock(NodePointer.class);
                                NodeIterator parentNamespaceIterator = mock(NodeIterator.class);
                                NodePointer nsPointer = mock(NodePointer.class);
                                
                                when(pointer.namespaceIterator()).thenReturn(namespaceIterator);
                                when(namespaceIterator.setPosition(1)).thenReturn(false);
                                when(pointer.getParent()).thenReturn(parentPointer);
                                
                                when(parentPointer.namespaceIterator()).thenReturn(parentNamespaceIterator);
                                when(parentNamespaceIterator.setPosition(1)).thenReturn(true);
                                when(parentNamespaceIterator.getNodePointer()).thenReturn(nsPointer);
                                when(nsPointer.getNamespaceURI()).thenReturn("http://example.com");
                                when(nsPointer.getName()).thenReturn(new QName("parentPrefix"));
                                when(parentPointer.getParent()).thenReturn(null);
                                
                                NamespaceResolver resolver = new NamespaceResolver();
                                resolver.setNamespaceContextPointer(pointer);
                                String result = resolver.getPrefix("http://example.com");
                                // Add assertions here if needed
                            }

    @Test
            public void testGetPrefixWithMatchingNamespace() {
                NodePointer pointer = mock(NodePointer.class);
                NodeIterator namespaceIterator = mock(NodeIterator.class);
                NodePointer nsPointer = mock(NodePointer.class);
                
                when(pointer.namespaceIterator()).thenReturn(namespaceIterator);
                when(namespaceIterator.setPosition(1)).thenReturn(true);
                when(namespaceIterator.getNodePointer()).thenReturn(nsPointer);
                when(nsPointer.getNamespaceURI()).thenReturn("http://example.com");
                when(nsPointer.getName()).thenReturn(new QName("http://example.com", "prefix:local"));
                when(pointer.getParent()).thenReturn(null);
            
                NamespaceResolver resolver = new NamespaceResolver();
                resolver.setNamespaceContextPointer(pointer);
                String prefix = resolver.getPrefix("http://example.com");
                
                assertEquals("prefix", prefix);
            }

    @Test
        public void testGetPrefixWithNullNamespaceURI() {
            NodePointer pointer = mock(NodePointer.class);
            when(pointer.namespaceIterator()).thenReturn(null);
            when(pointer.getParent()).thenReturn(null);
            
            NamespaceResolver resolver = new NamespaceResolver();
            resolver.setNamespaceContextPointer(pointer);
            String namespaceURI = null;
            String result = resolver.getPrefix(namespaceURI);
            assertNull(result);
        }


}
