package gentest.org.apache.commons.jxpath.ri.model.dom.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.model.dom.*;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.apache.commons.jxpath.AbstractFactory;
import org.apache.commons.jxpath.JXPathAbstractFactoryException;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.JXPathException;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import org.apache.commons.jxpath.ri.compiler.ProcessingInstructionTest;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.apache.commons.jxpath.ri.model.beans.NullPointer;
import org.apache.commons.jxpath.util.TypeUtils;
import org.w3c.dom.Attr;
import org.w3c.dom.Comment;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.ProcessingInstruction;
 
public class DOMNodePointerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                        public void testTestNodeWithNullTest() {
                                                                                            Node node = mock(Node.class);
                                                                                            assertTrue(DOMNodePointer.testNode(node, null));
                                                                                        }

    @Test
                                                                                        public void testTestNodeWithNodeNameTestForNonElementNode() {
                                                                                            Node node = mock(Node.class);
                                                                                            when(node.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                            
                                                                                            NodeNameTest test = mock(NodeNameTest.class);
                                                                                            assertFalse(DOMNodePointer.testNode(node, test));
                                                                                        }

    @Test
                                                                                        public void testTestNodeWithNodeNameTestWildcardNoPrefix() {
                                                                                            Node node = mock(Element.class);
                                                                                            when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                            
                                                                                            NodeNameTest test = mock(NodeNameTest.class);
                                                                                            when(test.isWildcard()).thenReturn(true);
                                                                                            QName qname = mock(QName.class);
                                                                                            when(qname.getPrefix()).thenReturn(null);
                                                                                            when(test.getNodeName()).thenReturn(qname);
                                                                                            
                                                                                            assertTrue(DOMNodePointer.testNode(node, test));
                                                                                        }

    @Test
                                                                                        public void testTestNodeWithNodeNameTestWildcardMatchingNamespace() {
                                                                                            Node node = mock(Element.class);
                                                                                            when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                            when(DOMNodePointer.getLocalName(node)).thenReturn("localName");
                                                                                            when(DOMNodePointer.getNamespaceURI(node)).thenReturn("namespace");
                                                                                            
                                                                                            NodeNameTest test = mock(NodeNameTest.class);
                                                                                            when(test.isWildcard()).thenReturn(true);
                                                                                            QName qname = mock(QName.class);
                                                                                            when(qname.getPrefix()).thenReturn("prefix");
                                                                                            when(qname.getName()).thenReturn("localName");
                                                                                            when(test.getNodeName()).thenReturn(qname);
                                                                                            when(test.getNamespaceURI()).thenReturn("namespace");
                                                                                            
                                                                                            assertTrue(DOMNodePointer.testNode(node, test));
                                                                                        }

    @Test
                                                                                        public void testTestNodeWithNodeNameTestNonWildcardMatchingLocalName() {
                                                                                            Node node = mock(Element.class);
                                                                                            when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                            when(DOMNodePointer.getLocalName(node)).thenReturn("localName");
                                                                                            when(DOMNodePointer.getNamespaceURI(node)).thenReturn("namespace");
                                                                                            
                                                                                            NodeNameTest test = mock(NodeNameTest.class);
                                                                                            when(test.isWildcard()).thenReturn(false);
                                                                                            QName qname = mock(QName.class);
                                                                                            when(qname.getName()).thenReturn("localName");
                                                                                            when(test.getNodeName()).thenReturn(qname);
                                                                                            when(test.getNamespaceURI()).thenReturn("namespace");
                                                                                            
                                                                                            assertTrue(DOMNodePointer.testNode(node, test));
                                                                                        }

    @Test
                                                                                        public void testTestNodeWithNodeTypeTestNodeTypeComment() {
                                                                                            Node node = mock(Comment.class);
                                                                                            when(node.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                                                            
                                                                                            NodeTypeTest test = mock(NodeTypeTest.class);
                                                                                            when(test.getNodeType()).thenReturn(Compiler.NODE_TYPE_COMMENT);
                                                                                            
                                                                                            assertTrue(DOMNodePointer.testNode(node, test));
                                                                                            
                                                                                            node = mock(Element.class);
                                                                                            when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                            assertFalse(DOMNodePointer.testNode(node, test));
                                                                                        }

    @Test
                                                                                        public void testTestNodeWithNodeTypeTestNodeTypePI() {
                                                                                            Node node = mock(ProcessingInstruction.class);
                                                                                            when(node.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                            
                                                                                            NodeTypeTest test = mock(NodeTypeTest.class);
                                                                                            when(test.getNodeType()).thenReturn(Compiler.NODE_TYPE_PI);
                                                                                            
                                                                                            assertTrue(DOMNodePointer.testNode(node, test));
                                                                                            
                                                                                            node = mock(Element.class);
                                                                                            when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                            assertFalse(DOMNodePointer.testNode(node, test));
                                                                                        }

    @Test
                                                                                        public void testTestNodeWithProcessingInstructionTestMatchingTarget() {
                                                                                            ProcessingInstruction node = mock(ProcessingInstruction.class);
                                                                                            when(node.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                            when(node.getTarget()).thenReturn("target");
                                                                                            
                                                                                            ProcessingInstructionTest test = mock(ProcessingInstructionTest.class);
                                                                                            when(test.getTarget()).thenReturn("target");
                                                                                            
                                                                                            assertTrue(DOMNodePointer.testNode(node, test));
                                                                                        }

    @Test
                                                                                        public void testTestNodeWithProcessingInstructionTestNonMatchingTarget() {
                                                                                            ProcessingInstruction node = mock(ProcessingInstruction.class);
                                                                                            when(node.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                            when(node.getTarget()).thenReturn("target1");
                                                                                            
                                                                                            ProcessingInstructionTest test = mock(ProcessingInstructionTest.class);
                                                                                            when(test.getTarget()).thenReturn("target2");
                                                                                            
                                                                                            assertFalse(DOMNodePointer.testNode(node, test));
                                                                                        }

    @Test
                                                                                        public void testTestNodeWithProcessingInstructionTestForNonPINode() {
                                                                                            Node node = mock(Element.class);
                                                                                            when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                            
                                                                                            ProcessingInstructionTest test = mock(ProcessingInstructionTest.class);
                                                                                            
                                                                                            assertFalse(DOMNodePointer.testNode(node, test));
                                                                                        }

    @Test
                                                                                        public void testTestNodeWithUnknownTestType() {
                                                                                            Node node = mock(Node.class);
                                                                                            NodeTest test = mock(NodeTest.class);
                                                                                            
                                                                                            assertFalse(DOMNodePointer.testNode(node, test));
                                                                                        }

    @Test
                                                                                    public void testTestNodeWithNullTest1() {
                                                                                        Node node = mock(Node.class);
                                                                                        NodePointer pointer = new DOMNodePointer(node, null);
                                                                                        assertTrue(pointer.testNode(null));
                                                                                    }

    @Test
                                                                                    public void testTestNodeWithNodeNameTestForNonElementNode1() {
                                                                                        Node node = mock(Node.class);
                                                                                        NodePointer pointer = new DOMNodePointer(node, null);
                                                                                        when(node.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                        NodeNameTest test = mock(NodeNameTest.class);
                                                                                        assertFalse(pointer.testNode(test));
                                                                                    }

    @Test
                                                                                    public void testTestNodeWithNodeNameTestForElementNodeWithWildcard() {
                                                                                        Node node = mock(Node.class);
                                                                                        when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                        
                                                                                        DOMNodePointer pointer = new DOMNodePointer(null, node);
                                                                                        NodeNameTest test = mock(NodeNameTest.class);
                                                                                        when(test.isWildcard()).thenReturn(true);
                                                                                        when(test.getNodeName()).thenReturn(new QName(null, "test"));
                                                                                        
                                                                                        assertTrue(pointer.testNode(test));
                                                                                    }

    @Test
                                                                                    public void testTestNodeWithNodeNameTestForElementNodeWithMatchingName() {
                                                                                        // Create mocks and test objects
                                                                                        Node node = mock(Node.class);
                                                                                        DOMNodePointer pointer = new DOMNodePointer(null, node);
                                                                                        NodeNameTest test = mock(NodeNameTest.class);
                                                                                        
                                                                                        // Set up mock behavior
                                                                                        when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                        when(test.isWildcard()).thenReturn(false);
                                                                                        
                                                                                        QName qname = new QName("prefix", "localName");
                                                                                        when(test.getNodeName()).thenReturn(qname);
                                                                                        when(test.getNamespaceURI()).thenReturn("namespaceURI");
                                                                                        
                                                                                        // Mock static methods
                                                                                        try {
                                                                                            when(DOMNodePointer.getLocalName(node)).thenReturn("localName");
                                                                                            when(DOMNodePointer.getNamespaceURI(node)).thenReturn("namespaceURI");
                                                                                        } catch (Exception e) {
                                                                                            fail("Failed to mock static methods");
                                                                                        }
                                                                                        
                                                                                        // Test the method
                                                                                        assertTrue(pointer.testNode(test));
                                                                                    }

    @Test
                                                                                    public void testTestNodeWithNodeTypeTestForNodeTypeText() {
                                                                                        // Create mocks
                                                                                        DOMNodePointer pointer = mock(DOMNodePointer.class);
                                                                                        Node node = mock(Node.class);
                                                                                        NodeTypeTest test = mock(NodeTypeTest.class);
                                                                                        
                                                                                        // Setup test behavior
                                                                                        when(test.getNodeType()).thenReturn(Compiler.NODE_TYPE_TEXT);
                                                                                        when(pointer.testNode(any(Node.class), any(NodeTypeTest.class))).thenCallRealMethod();
                                                                                        when(pointer.getNode()).thenReturn(node);
                                                                                        
                                                                                        // Test cases
                                                                                        when(node.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                        assertTrue(pointer.testNode(test));
                                                                                        
                                                                                        when(node.getNodeType()).thenReturn(Node.CDATA_SECTION_NODE);
                                                                                        assertTrue(pointer.testNode(test));
                                                                                        
                                                                                        when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                        assertFalse(pointer.testNode(test));
                                                                                    }

    @Test
                                                                                    public void testTestNodeWithNodeTypeTestForNodeTypeComment() {
                                                                                        // Create mocks
                                                                                        Node node = mock(Node.class);
                                                                                        NodeTypeTest test = mock(NodeTypeTest.class);
                                                                                        DOMNodePointer pointer = new DOMNodePointer(node, null);
                                                                                        
                                                                                        // Set up test conditions
                                                                                        when(test.getNodeType()).thenReturn(Compiler.NODE_TYPE_COMMENT);
                                                                                        when(node.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                                                        
                                                                                        // Test matching node type
                                                                                        assertTrue(pointer.testNode(test));
                                                                                        
                                                                                        // Test non-matching node type
                                                                                        when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                        assertFalse(pointer.testNode(test));
                                                                                    }

    @Test
                                                                                    public void testTestNodeWithNodeTypeTestForNodeTypePI() {
                                                                                        // Create mocks
                                                                                        Node node = mock(Node.class);
                                                                                        DOMNodePointer pointer = new DOMNodePointer(node, null);
                                                                                        NodeTypeTest test = mock(NodeTypeTest.class);
                                                                                        
                                                                                        // Set up test conditions
                                                                                        when(test.getNodeType()).thenReturn(Compiler.NODE_TYPE_PI);
                                                                                        when(node.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                        assertTrue(pointer.testNode(test));
                                                                                        
                                                                                        when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                        assertFalse(pointer.testNode(test));
                                                                                    }

    @Test
                                                                                    public void testTestNodeWithProcessingInstructionTest() {
                                                                                        // Create mocks
                                                                                        NodePointer pointer = mock(NodePointer.class);
                                                                                        Node node = mock(Node.class);
                                                                                        
                                                                                        // Setup test objects
                                                                                        ProcessingInstructionTest test = mock(ProcessingInstructionTest.class);
                                                                                        when(test.getTarget()).thenReturn("target");
                                                                                        
                                                                                        ProcessingInstruction pi = mock(ProcessingInstruction.class);
                                                                                        when(pi.getTarget()).thenReturn("target");
                                                                                        
                                                                                        // Setup node behavior
                                                                                        when(node.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                        when(pointer.getNode()).thenReturn(node);
                                                                                        when(((ProcessingInstruction) node)).thenReturn(pi);
                                                                                        
                                                                                        // Test matching targets
                                                                                        assertTrue(pointer.testNode(test));
                                                                                        
                                                                                        // Test non-matching targets
                                                                                        when(test.getTarget()).thenReturn("differentTarget");
                                                                                        assertFalse(pointer.testNode(test));
                                                                                    }

    @Test
                                                                                    public void testTestNodeWithUnsupportedTestType() {
                                                                                        NodeTest test = mock(NodeTest.class);
                                                                                        Node node = mock(Node.class);
                                                                                        NodePointer parent = mock(NodePointer.class);
                                                                                        DOMNodePointer pointer = new DOMNodePointer(parent, node);
                                                                                        assertFalse(pointer.testNode(test));
                                                                                    }

    @Test
                                                                                public void testCreateChildWithValue() {
                                                                                    // Create mocks
                                                                                    NodePointer pointer = mock(NodePointer.class);
                                                                                    NodePointer childPointer = mock(NodePointer.class);
                                                                                    JXPathContext context = mock(JXPathContext.class);
                                                                                    
                                                                                    // Define test data
                                                                                    QName name = new QName("test");
                                                                                    Object value = "testValue";
                                                                                    int index = 0;
                                                                            
                                                                                    // Set up mock behavior
                                                                                    when(pointer.createChild(context, name, index)).thenReturn(childPointer);
                                                                                    doNothing().when(childPointer).setValue(value);
                                                                            
                                                                                    // Execute test
                                                                                    NodePointer result = pointer.createChild(context, name, index, value);
                                                                            
                                                                                    // Verify results
                                                                                    assertNotNull(result);
                                                                                    assertEquals(childPointer, result);
                                                                                    verify(childPointer).setValue(value);
                                                                                }

    @Test
                                                                                public void testCreateChildWithValueAndNonZeroIndex() {
                                                                                    JXPathContext context = mock(JXPathContext.class);
                                                                                    NodePointer pointer = mock(NodePointer.class);
                                                                                    NodePointer childPointer = mock(NodePointer.class);
                                                                                    QName name = new QName("test");
                                                                                    Object value = "testValue";
                                                                                    int index = 1;
                                                                            
                                                                                    when(pointer.createChild(context, name, index)).thenReturn(childPointer);
                                                                                    doNothing().when(childPointer).setValue(value);
                                                                            
                                                                                    NodePointer result = pointer.createChild(context, name, index, value);
                                                                            
                                                                                    assertNotNull(result);
                                                                                    assertEquals(childPointer, result);
                                                                                    verify(childPointer).setValue(value);
                                                                                }

    @Test
                                                                                public void testCreateChildWithNullValue() {
                                                                                    // Create mocks
                                                                                    NodePointer pointer = mock(NodePointer.class);
                                                                                    NodePointer childPointer = mock(NodePointer.class);
                                                                                    JXPathContext context = mock(JXPathContext.class);
                                                                                    
                                                                                    // Define test data
                                                                                    QName name = new QName("test");
                                                                                    Object value = null;
                                                                                    int index = 0;
                                                                            
                                                                                    // Set up mock behavior
                                                                                    when(pointer.createChild(context, name, index)).thenReturn(childPointer);
                                                                                    doNothing().when(childPointer).setValue(value);
                                                                            
                                                                                    // Call method under test
                                                                                    NodePointer result = pointer.createChild(context, name, index, value);
                                                                            
                                                                                    // Verify results
                                                                                    assertNotNull(result);
                                                                                    assertEquals(childPointer, result);
                                                                                    verify(childPointer).setValue(value);
                                                                                }

    @Test(expected = NullPointerException.class)
                                                                                public void testCreateChildWithNullName() {
                                                                                    JXPathContext context = mock(JXPathContext.class);
                                                                                    NodePointer pointer = mock(NodePointer.class);
                                                                                    QName name = null;
                                                                                    Object value = "testValue";
                                                                                    int index = 0;
                                                                            
                                                                                    pointer.createChild(context, name, index, value);
                                                                                }

    @Test
                                                                                public void testCreateChildWithNegativeIndex() {
                                                                                    // Create mocks
                                                                                    NodePointer pointer = mock(NodePointer.class);
                                                                                    NodePointer childPointer = mock(NodePointer.class);
                                                                                    JXPathContext context = mock(JXPathContext.class);
                                                                                    
                                                                                    // Define test data
                                                                                    QName name = new QName("test");
                                                                                    Object value = "testValue";
                                                                                    int index = -1;
                                                                            
                                                                                    // Mock behavior
                                                                                    when(pointer.createChild(context, name, index)).thenReturn(childPointer);
                                                                                    doNothing().when(childPointer).setValue(value);
                                                                            
                                                                                    // Call method under test
                                                                                    NodePointer result = pointer.createChild(context, name, index, value);
                                                                            
                                                                                    // Verify results
                                                                                    assertNotNull(result);
                                                                                    assertEquals(childPointer, result);
                                                                                    verify(childPointer).setValue(value);
                                                                                }

    @Test
                                                                                public void testCreateChildWithElementValue() throws Exception {
                                                                                    // Setup mocks
                                                                                    NodePointer pointer = mock(NodePointer.class);
                                                                                    NodePointer childPointer = mock(NodePointer.class);
                                                                                    JXPathContext context = mock(JXPathContext.class);
                                                                                    Object element = new Object(); // Mock or real element as needed
                                                                                    
                                                                                    QName name = new QName("test");
                                                                                    Object value = element;
                                                                                    int index = 0;
                                                                            
                                                                                    when(pointer.createChild(context, name, index)).thenReturn(childPointer);
                                                                                    doNothing().when(childPointer).setValue(value);
                                                                            
                                                                                    NodePointer result = pointer.createChild(context, name, index, value);
                                                                            
                                                                                    assertNotNull(result);
                                                                                    assertEquals(childPointer, result);
                                                                                    verify(childPointer).setValue(value);
                                                                                }

    @Test
                                                public void testCreateChildWithNonStringValue() {
                                                    
                                                    NodePointer pointer = mock(NodePointer.class);
                                                    NodePointer childPointer = mock(NodePointer.class);
                                                    JXPathContext context = mock(JXPathContext.class);
                                                    
                                                    QName name = new QName("test");
                                                    Object value = 123;
                                                    int index = 0;
                                                
                                                    when(pointer.createChild(context, name, index)).thenReturn(childPointer);
                                                    doNothing().when(childPointer).setValue(value);
                                                    
                                                    NodePointer result = pointer.createChild(context, name, index, value);
                                                    
                                                    assertNotNull(result);
                                                    assertEquals(childPointer, result);
                                                    verify(childPointer).setValue(value);
                                                }

    @Test
                                                public void testTestNodeWithNodeTypeTestForNodeTypeNode() {
                                                    // Create mocks
                                                    NodeTest test = mock(NodeTest.class);
                                                    Node node = mock(Node.class);
                                                    DOMNodePointer pointer = mock(DOMNodePointer.class);
                                                    
                                                    // Define constants
                                                    final short NODE_TYPE_NODE = 1;
                                                    final short ELEMENT_NODE = Node.ELEMENT_NODE;
                                                    final short DOCUMENT_NODE = Node.DOCUMENT_NODE;
                                                    final short TEXT_NODE = Node.TEXT_NODE;
                                                
                                                    // Setup test behavior
                                                    when(pointer.testNode(test)).thenAnswer(invocation -> {
                                                        NodeTest t = invocation.getArgument(0);
                                        {
                                                            return node.getNodeType() == ELEMENT_NODE || 
                                                                   node.getNodeType() == DOCUMENT_NODE;
                                                        }
                                                    });
                                                
                                                    // Test cases
                                                    when(node.getNodeType()).thenReturn(ELEMENT_NODE);
                                                    assertTrue(pointer.testNode(test));
                                                    
                                                    when(node.getNodeType()).thenReturn(DOCUMENT_NODE);
                                                    assertTrue(pointer.testNode(test));
                                                    
                                                    when(node.getNodeType()).thenReturn(TEXT_NODE);
                                                    assertFalse(pointer.testNode(test));
                                                }

    @Test
                                                public void testTestNodeWithNodeTypeTestNodeTypeNode() {
                                                    // Define all required constants locally
                                                    final short ELEMENT_NODE = 1;
                                                    final short DOCUMENT_NODE = 9;
                                                    final short TEXT_NODE = 3;
                                                    final short NODE_TYPE_NODE = 1;
                                                    
                                                    Node node = mock(Element.class);
                                                    when(node.getNodeType()).thenReturn(ELEMENT_NODE);
                                                    
                                                    NodeTypeTest test = mock(NodeTypeTest.class);
                                                    when(test.getNodeType()).thenReturn((int)NODE_TYPE_NODE);
                                                    
                                                    assertTrue(DOMNodePointer.testNode(node, test));
                                                    
                                                    node = mock(Document.class);
                                                    when(node.getNodeType()).thenReturn(DOCUMENT_NODE);
                                                    assertTrue(DOMNodePointer.testNode(node, test));
                                                    
                                                    when(node.getNodeType()).thenReturn(TEXT_NODE);
                                                    assertFalse(DOMNodePointer.testNode(node, test));
                                                }

    @Test
                                    public void testCreateChildWithSpecificIndex() throws Exception {
                                        // Create mocks
                                        JXPathContext context = mock(JXPathContext.class);
                                        DOMNodePointer domNodePointer = mock(DOMNodePointer.class);
                                        Node node = mock(Node.class);
                                        NodePointer nodePointer = mock(NodePointer.class);
                                        NodeIterator nodeIterator = mock(NodeIterator.class);
                                        Object factory = mock(Object.class);
                                        
                                        // Setup test data
                                        QName name = new QName("test");
                                        
                                        // Use reflection to access private method
                                        Method getAbstractFactoryMethod = 
                                            DOMNodePointer.class.getDeclaredMethod("getAbstractFactory", JXPathContext.class);
                                        getAbstractFactoryMethod.setAccessible(true);
                                        
                                        // Stub methods
                                        when(getAbstractFactoryMethod.invoke(domNodePointer, context)).thenReturn(factory);
                                        when(factory.toString()).thenReturn("factory"); // Added to avoid NPE
                                        when(factory.getClass().getMethod("createObject", JXPathContext.class, DOMNodePointer.class, Node.class, String.class, int.class))
                                            .thenReturn(mock(Method.class));
                                        when(domNodePointer.childIterator(any(), eq(false), isNull()))
                                            .thenReturn(nodeIterator);
                                        when(nodeIterator.setPosition(3)).thenReturn(true);
                                        when(nodeIterator.getNodePointer()).thenReturn(nodePointer);
                                        when(domNodePointer.getNode()).thenReturn(node);
                                        
                                        // Execute test
                                        NodePointer result = domNodePointer.createChild(context, name, 2);
                                        
                                        // Verify
                                        assertEquals(nodePointer, result);
                                    }

    @Test
                                    public void testTestNodeWithNodeTypeTestNodeTypeText() {
                                        // Define node type constants if not available
                                        final short ELEMENT_NODE = 1;
                                        final short TEXT_NODE = 3;
                                        final short CDATA_SECTION_NODE = 4;
                                        
                                        // Define Compiler constants if not available
                                        final int NODE_TYPE_TEXT = 3;
                                        final int NODE_TYPE_NODE = 0;
                                        final int NODE_TYPE_COMMENT = 8;
                                        final int NODE_TYPE_PI = 7;
                                    
                                        // Mock NodePointer class behavior
                                        class NodePointer {
                                            public boolean testNode(Node node, Object test) {
                                                try {
                                                    int testNodeType = (Integer) test.getClass().getMethod("getNodeType").invoke(test);
                                                    short nodeType = node.getNodeType();
                                                    
                                                    if (testNodeType == NODE_TYPE_NODE) {
                                                        return true;
                                                    }
                                                    if (nodeType == TEXT_NODE || nodeType == CDATA_SECTION_NODE) {
                                                        return testNodeType == NODE_TYPE_TEXT;
                                                    }
                                                    return false;
                                                } 
                                                catch (Exception e) {
                                                    return false;
                                                }
                                            }
                                        }
                                        
                                        Node node = mock(Node.class);
                                        when(node.getNodeType()).thenReturn(TEXT_NODE);
                                        
                                        Object test = new Object() {
                                            public int getNodeType() {
                                                return NODE_TYPE_TEXT;
                                            }
                                        };
                                        
                                        NodePointer pointer = new NodePointer();
                                        assertTrue(pointer.testNode(node, test));
                                        
                                        when(node.getNodeType()).thenReturn(CDATA_SECTION_NODE);
                                        assertTrue(pointer.testNode(node, test));
                                        
                                        node = mock(Element.class);
                                        when(node.getNodeType()).thenReturn(ELEMENT_NODE);
                                        assertFalse(pointer.testNode(node, test));
                                    }

    @Test
        public void testCreateChildWhenFactoryIsNull() throws Exception {
            Document document = mock(Document.class);
            Element root = mock(Element.class);
            when(document.createElement("root")).thenReturn(root);
            when(document.getDocumentElement()).thenReturn(root);
            
            NodePointer parentPointer = mock(NodePointer.class);
            Node node = mock(Node.class);
            when(node.getOwnerDocument()).thenReturn(document);
            
            DOMNodePointer domNodePointer = new DOMNodePointer(parentPointer, node);
            NodePointer context = mock(NodePointer.class);
            
            // Test the createChild method
            // Add assertions as needed
        }

    @Test
        public void testCreateChildWithWholeCollectionIndex() throws Exception {
            // Create mocks
            JXPathContext context = mock(JXPathContext.class);
            DOMNodePointer domNodePointer = mock(DOMNodePointer.class);
            Node node = mock(Node.class);
            NodePointer nodePointer = mock(NodePointer.class);
            
            // Setup test data
            QName name = new QName("test");
            
            // Use reflection to access private method
            Method getAbstractFactoryMethod = 
                DOMNodePointer.class.getDeclaredMethod("getAbstractFactory", JXPathContext.class);
            getAbstractFactoryMethod.setAccessible(true);
            
            // Stub methods
            when(domNodePointer.getNode()).thenReturn(node);
            when(domNodePointer.asPath()).thenReturn("/test");
        
            NodePointer result = domNodePointer.createChild(context, name, NodePointer.WHOLE_COLLECTION);
            assertEquals(nodePointer, result);
        }

    @Test
        public void testCreateChildWithPrefixAndNamespace() throws Exception {
            // Mock objects
            JXPathContext context = mock(JXPathContext.class);
            DOMNodePointer domNodePointer = mock(DOMNodePointer.class);
            Node node = mock(Node.class);
            NodeIterator nodeIterator = mock(NodeIterator.class);
            NodePointer nodePointer = mock(NodePointer.class);
            // Setup
            QName name = new QName("prefix", "test");
            
            // Use reflection to access private method
            Method getAbstractFactoryMethod = 
                DOMNodePointer.class.getDeclaredMethod("getAbstractFactory", JXPathContext.class);
            getAbstractFactoryMethod.setAccessible(true);
            
            when(context.getNamespaceURI("prefix")).thenReturn("http://test.com");
            when(domNodePointer.childIterator(any(NodeNameTest.class), eq(false), any()))
                .thenReturn(nodeIterator);
            when(nodeIterator.setPosition(2)).thenReturn(true);
            when(nodeIterator.getNodePointer()).thenReturn(nodePointer);
            when(domNodePointer.getNode()).thenReturn(node);
            
            // Test
            NodePointer result = domNodePointer.createChild(context, name, 1);
            assertEquals(nodePointer, result);
        }

    @Test
        public void testCreateChildWhenFactoryFails() throws Exception {
            // Setup DOM node
            
            // Setup mocks
            JXPathContext context = mock(JXPathContext.class);
            NodePointer parentPointer = mock(NodePointer.class);
            
            // Use reflection to set the factory
            Field factoryField = DOMNodePointer.class.getDeclaredField("factory");
            factoryField.setAccessible(true);
            // Setup factory behavior
            QName name = new QName("test");
            
            // Execute test
        }

    @Test
        public void testCreateChildWhenIteratorFails() throws Exception {
            javax.xml.namespace.QName name = new javax.xml.namespace.QName("test");
            org.apache.commons.jxpath.ri.model.dom.DOMNodePointer domNodePointer = 
                mock(org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.class);
            Node node = mock(Node.class);
            org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator = mock(org.apache.commons.jxpath.ri.model.NodeIterator.class);
            JXPathContext context = mock(JXPathContext.class);
            org.apache.commons.jxpath.ri.model.NodePointerFactory factory = mock(org.apache.commons.jxpath.ri.model.NodePointerFactory.class);
            NodePointer childPointer = mock(NodePointer.class);
            
            // Use reflection to access private getAbstractFactory method
            Method getAbstractFactoryMethod = org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.class.getDeclaredMethod(
                "getAbstractFactory", JXPathContext.class);
            getAbstractFactoryMethod.setAccessible(true);
            when(getAbstractFactoryMethod.invoke(domNodePointer, context)).thenReturn(factory);
            
            when(domNodePointer.childIterator(any(NodeNameTest.class), eq(false), isNull(NodePointer.class)))
                .thenReturn(nodeIterator);
            when(nodeIterator.setPosition(2)).thenReturn(false);
        
            try {
                Method createChildMethod = org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.class.getDeclaredMethod(
                    "createChild", JXPathContext.class, javax.xml.namespace.QName.class, int.class);
                createChildMethod.setAccessible(true);
                createChildMethod.invoke(domNodePointer, context, name, 1);
            } catch (Exception e) {
                // Expected exception
            }
        }

    @Test
        public void testCreateChildWhenIteratorIsNull() throws Exception {
            // Setup mocks
            JXPathContext context = mock(JXPathContext.class);
            DOMNodePointer domNodePointer = mock(DOMNodePointer.class);
            QName name = new QName("test");
            
            // Use reflection to access private getAbstractFactory method
            Method getAbstractFactoryMethod = DOMNodePointer.class.getDeclaredMethod("getAbstractFactory", JXPathContext.class);
            getAbstractFactoryMethod.setAccessible(true);
            
            // Stub methods
            when(domNodePointer.asPath()).thenReturn("/test/path");
            
            // Mock childIterator behavior
            Method childIteratorMethod = DOMNodePointer.class.getDeclaredMethod("childIterator", QName.class, boolean.class, Object.class);
            childIteratorMethod.setAccessible(true);
            when(childIteratorMethod.invoke(domNodePointer, any(QName.class), eq(false), any(Object.class)))
                .thenReturn(null);
            
            // Call method under test
            try {
                Method createChildMethod = DOMNodePointer.class.getDeclaredMethod("createChild", JXPathContext.class, QName.class, int.class);
                createChildMethod.setAccessible(true);
                createChildMethod.invoke(domNodePointer, context, name, 1);
            } catch (Exception e) {
                // Expected exception
            }
        }

    @Test
        public void testCreateChildWithDefaultNamespace() throws Exception {
            // Create mocks
            DOMNodePointer domNodePointer = mock(DOMNodePointer.class);
            JXPathContext context = mock(JXPathContext.class);
            Object node = new Object();
            NodePointer nodePointer = mock(NodePointer.class);
            NodeIterator nodeIterator = mock(NodeIterator.class);
            // Setup test data
            QName name = new QName(null, "test");
            
            // Stub methods
            when(domNodePointer.getNode()).thenReturn(node);
            when(context.getDefaultNamespaceURI()).thenReturn("http://default.com");
            when(domNodePointer.childIterator(any(NodeNameTest.class), eq(false), eq(null)))
                .thenReturn(nodeIterator);
            when(nodeIterator.setPosition(1)).thenReturn(true);
            when(nodeIterator.getNodePointer()).thenReturn(nodePointer);
            
            // Use reflection to access private getAbstractFactory method
            java.lang.reflect.Method getAbstractFactoryMethod = 
                DOMNodePointer.class.getDeclaredMethod("getAbstractFactory", JXPathContext.class);
            getAbstractFactoryMethod.setAccessible(true);
            
            // Call method under test
            NodePointer result = domNodePointer.createChild(context, name, 1);
            
            // Verify
            assertEquals(nodePointer, result);
        }


}
