package gentest.org.apache.commons.jxpath.ri.compiler.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.compiler.*;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.EvalContext;
import org.apache.commons.jxpath.ri.InfoSetUtil;
import org.apache.commons.jxpath.ri.axes.InitialContext;
import org.apache.commons.jxpath.ri.axes.SelfContext;
 
public class CoreOperationCompareTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                        public void testEqualWithOneNullValue() throws Exception {
                                                                                                                                                            CoreOperationCompare coreOperationCompare = new CoreOperationEqual(null, null);
                                                                                                                                                            Method equalMethod = CoreOperationCompare.class.getDeclaredMethod(
                                                                                                                                                                "equal", Object.class, Object.class);
                                                                                                                                                            equalMethod.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            boolean result = (boolean) equalMethod.invoke(coreOperationCompare, "value", null);
                                                                                                                                                            assertFalse(result);
                                                                                                                                                        }

    @Test
                                                                                                                                                public void testEqualWithCollection() {
                                                                                                                                                    // Define all mocks inside the method
                                                                                                                                                    EvalContext context = mock(EvalContext.class);
                                                                                                                                                    Expression left = mock(Expression.class);
                                                                                                                                                    Expression right = mock(Expression.class);
                                                                                                                                                    Collection collection = mock(Collection.class);
                                                                                                                                                    Iterator iterator = mock(Iterator.class);
                                                                                                                                                    
                                                                                                                                                    // Create concrete subclass since CoreOperationCompare is abstract
                                                                                                                                                    CoreOperationCompare coreOperationCompare = new CoreOperationCompare(left, right) {
                                                                                                                                                        @Override
                                                                                                                                                        public Object computeValue(EvalContext context) {
                                                                                                                                                            return null;
                                                                                                                                                        }
                                                                                                                                                        
                                                                                                                                                        @Override
                                                                                                                                                        public int getPrecedence() {
                                                                                                                                                            return 0;
                                                                                                                                                        }
                                                                                                                                                        
                                                                                                                                                        @Override
                                                                                                                                                        public boolean isSymmetric() {
                                                                                                                                                            return false;
                                                                                                                                                        }
                                                                                                                                                        
                                                                                                                                                        @Override
                                                                                                                                                        public String getSymbol() {
                                                                                                                                                            return "=";
                                                                                                                                                        }
                                                                                                                                                    };
                                                                                                                                                
                                                                                                                                                    when(left.compute(context)).thenReturn(collection);
                                                                                                                                                    when(right.compute(context)).thenReturn("test");
                                                                                                                                                    when(collection.iterator()).thenReturn(iterator);
                                                                                                                                                    when(iterator.hasNext()).thenReturn(false);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to access the private equal method
                                                                                                                                                    try {
                                                                                                                                                        Method method = CoreOperationCompare.class.getDeclaredMethod(
                                                                                                                                                            "equal", EvalContext.class, Expression.class, Expression.class);
                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                        boolean result = (boolean) method.invoke(coreOperationCompare, context, left, right);
                                                                                                                                                        assertFalse(result);
                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                        fail("Reflection failed: " + e.getMessage());
                                                                                                                                                    }
                                                                                                                                                }

    @Test
                                                                                                                                                public void testEqualWithSameObjectReferences() throws Exception {
                                                                                                                                                    CoreOperationCompare coreOperationCompare = new CoreOperationCompare(null, null) {
                                                                                                                                                        @Override
                                                                                                                                                        public Object computeValue(org.apache.commons.jxpath.ri.EvalContext context) {
                                                                                                                                                            return null;
                                                                                                                                                        }
                                                                                                                                                        
                                                                                                                                                        @Override
                                                                                                                                                        public int getPrecedence() {
                                                                                                                                                            return 0;
                                                                                                                                                        }
                                                                                                                                                        
                                                                                                                                                        @Override
                                                                                                                                                        public boolean isSymmetric() {
                                                                                                                                                            return false;
                                                                                                                                                        }
                                                                                                                                                        
                                                                                                                                                        @Override
                                                                                                                                                        public String getSymbol() {
                                                                                                                                                            return "==";
                                                                                                                                                        }
                                                                                                                                                    };
                                                                                                                                                    
                                                                                                                                                    Method equalMethod = CoreOperationCompare.class.getDeclaredMethod(
                                                                                                                                                        "equal", Object.class, Object.class);
                                                                                                                                                    equalMethod.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    Object obj = new Object();
                                                                                                                                                    boolean result = (boolean) equalMethod.invoke(coreOperationCompare, obj, obj);
                                                                                                                                                    assertTrue(result);
                                                                                                                                                }

    @Test
                                                                                                                                            public void testEqualWithNullValues() throws Exception {
                                                                                                                                                CoreOperationCompare coreOperationCompare = new CoreOperationCompare(null, null) {
                                                                                                                                                    @Override
                                                                                                                                                    public Object computeValue(EvalContext context) {
                                                                                                                                                        return null;
                                                                                                                                                    }
                                                                                                                                        
                                                                                                                                                    @Override
                                                                                                                                                    public String getSymbol() {
                                                                                                                                                        return "==";
                                                                                                                                                    }
                                                                                                                                        
                                                                                                                                                    @Override
                                                                                                                                                    public int getPrecedence() {
                                                                                                                                                        return 0;
                                                                                                                                                    }
                                                                                                                                        
                                                                                                                                                    @Override
                                                                                                                                                    public boolean isSymmetric() {
                                                                                                                                                        return true;
                                                                                                                                                    }
                                                                                                                                                };
                                                                                                                                                Method equalMethod = CoreOperationCompare.class.getDeclaredMethod("equal", Object.class, Object.class);
                                                                                                                                                equalMethod.setAccessible(true);
                                                                                                                                                boolean result = (boolean) equalMethod.invoke(coreOperationCompare, null, null);
                                                                                                                                                assertTrue(result);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testEqualWithBooleanValues() throws Exception {
                                                                                                                                                // Create concrete subclass since CoreOperationCompare is abstract
                                                                                                                                                CoreOperationCompare coreOperationCompare = new CoreOperationCompare(null, null) {
                                                                                                                                                    @Override
                                                                                                                                                    public Object computeValue(EvalContext context) {
                                                                                                                                                        return null;
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    @Override
                                                                                                                                                    public int getPrecedence() {
                                                                                                                                                        return 0;
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    @Override
                                                                                                                                                    public boolean isSymmetric() {
                                                                                                                                                        return false;
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    @Override
                                                                                                                                                    public String getSymbol() {
                                                                                                                                                        return "=";
                                                                                                                                                    }
                                                                                                                                                };
                                                                                                                                                
                                                                                                                                                Method equalMethod = CoreOperationCompare.class.getDeclaredMethod("equal", Object.class, Object.class);
                                                                                                                                                equalMethod.setAccessible(true);
                                                                                                                                            
                                                                                                                                                boolean result1 = (boolean) equalMethod.invoke(coreOperationCompare, true, true);
                                                                                                                                                assertTrue(result1);
                                                                                                                                            
                                                                                                                                                boolean result2 = (boolean) equalMethod.invoke(coreOperationCompare, true, false);
                                                                                                                                                assertFalse(result2);
                                                                                                                                            
                                                                                                                                                boolean result3 = (boolean) equalMethod.invoke(coreOperationCompare, Boolean.TRUE, true);
                                                                                                                                                assertTrue(result3);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testEqualWithRegularObjects() throws Exception {
                                                                                                                                                // Create concrete subclass since CoreOperationCompare is abstract
                                                                                                                                                CoreOperationCompare coreOperationCompare = new CoreOperationCompare(null, null) {
                                                                                                                                                    @Override
                                                                                                                                                    public Object computeValue(EvalContext context) {
                                                                                                                                                        return null;
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    @Override
                                                                                                                                                    public int getPrecedence() {
                                                                                                                                                        return 0;
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    @Override
                                                                                                                                                    public boolean isSymmetric() {
                                                                                                                                                        return false;
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    @Override
                                                                                                                                                    public String getSymbol() {
                                                                                                                                                        return "==";
                                                                                                                                                    }
                                                                                                                                                };
                                                                                                                                                
                                                                                                                                                Method equalMethod = CoreOperationCompare.class.getDeclaredMethod("equal", Object.class, Object.class);
                                                                                                                                                equalMethod.setAccessible(true);
                                                                                                                                            
                                                                                                                                                Object obj1 = new Object() {
                                                                                                                                                    @Override
                                                                                                                                                    public boolean equals(Object obj) {
                                                                                                                                                        return true;
                                                                                                                                                    }
                                                                                                                                                };
                                                                                                                                                Object obj2 = new Object();
                                                                                                                                                
                                                                                                                                                boolean result1 = (boolean) equalMethod.invoke(coreOperationCompare, obj1, obj2);
                                                                                                                                                assertTrue(result1);
                                                                                                                                            
                                                                                                                                                boolean result2 = (boolean) equalMethod.invoke(coreOperationCompare, new Object(), new Object());
                                                                                                                                                assertFalse(result2);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testEqualWithBooleanValues1() throws Exception {
                                                                                                                                                // Create concrete subclass since CoreOperationCompare is abstract
                                                                                                                                                CoreOperationCompare coreOperationCompare = new CoreOperationCompare(null, null) {
                                                                                                                                                    @Override
                                                                                                                                                    public Object computeValue(EvalContext context) {
                                                                                                                                                        return null;
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    @Override
                                                                                                                                                    public int getPrecedence() {
                                                                                                                                                        return 0;
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    @Override
                                                                                                                                                    public boolean isSymmetric() {
                                                                                                                                                        return false;
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    @Override
                                                                                                                                                    public String getSymbol() {
                                                                                                                                                        return "==";
                                                                                                                                                    }
                                                                                                                                                };
                                                                                                                                                
                                                                                                                                                Method equalMethod = CoreOperationCompare.class.getDeclaredMethod("equal", Object.class, Object.class);
                                                                                                                                                equalMethod.setAccessible(true);
                                                                                                                                            
                                                                                                                                                boolean result1 = (boolean) equalMethod.invoke(coreOperationCompare, true, true);
                                                                                                                                                assertTrue(result1);
                                                                                                                                            
                                                                                                                                                boolean result2 = (boolean) equalMethod.invoke(coreOperationCompare, true, false);
                                                                                                                                                assertFalse(result2);
                                                                                                                                            
                                                                                                                                                boolean result3 = (boolean) equalMethod.invoke(coreOperationCompare, Boolean.TRUE, true);
                                                                                                                                                assertTrue(result3);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testEqualWithSamePointerObjects() throws Exception {
                                                                                                                                                // Setup
                                                                                                                                                Pointer pointer1 = mock(Pointer.class);
                                                                                                                                                Pointer pointer2 = mock(Pointer.class);
                                                                                                                                                
                                                                                                                                                // Create anonymous subclass of CoreOperationCompare since it's abstract
                                                                                                                                                CoreOperationCompare coreOperationCompare = new CoreOperationCompare(null, null) {
                                                                                                                                                    @Override
                                                                                                                                                    public Object computeValue(org.apache.commons.jxpath.ri.EvalContext context) {
                                                                                                                                                        return null;
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    @Override
                                                                                                                                                    protected int getPrecedence() {
                                                                                                                                                        return 0;
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    @Override
                                                                                                                                                    protected boolean isSymmetric() {
                                                                                                                                                        return true;
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    @Override
                                                                                                                                                    public String getSymbol() {
                                                                                                                                                        return "=";
                                                                                                                                                    }
                                                                                                                                                };
                                                                                                                                                
                                                                                                                                                // Get private equal method via reflection
                                                                                                                                                Method equalMethod = CoreOperationCompare.class.getDeclaredMethod(
                                                                                                                                                    "equal", Object.class, Object.class);
                                                                                                                                                equalMethod.setAccessible(true);
                                                                                                                                            
                                                                                                                                                // Test
                                                                                                                                                when(pointer1.equals(pointer2)).thenReturn(true);
                                                                                                                                                boolean result = (boolean) equalMethod.invoke(coreOperationCompare, pointer1, pointer2);
                                                                                                                                                
                                                                                                                                                // Verify
                                                                                                                                                assertTrue(result);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testEqualWithDifferentPointerObjects() throws Exception {
                                                                                                                                                // Create mock objects
                                                                                                                                                Pointer pointer1 = mock(Pointer.class);
                                                                                                                                                Pointer pointer2 = mock(Pointer.class);
                                                                                                                                                
                                                                                                                                                // Create anonymous subclass instance of CoreOperationCompare
                                                                                                                                                CoreOperationCompare coreOperationCompare = new CoreOperationCompare(null, null) {
                                                                                                                                                    @Override
                                                                                                                                                    public int getPrecedence() {
                                                                                                                                                        return 0;
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    @Override
                                                                                                                                                    public boolean isSymmetric() {
                                                                                                                                                        return false;
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    @Override
                                                                                                                                                    public String getSymbol() {
                                                                                                                                                        return "==";
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    @Override
                                                                                                                                                    public Object computeValue(EvalContext context) {
                                                                                                                                                        return null;
                                                                                                                                                    }
                                                                                                                                                };
                                                                                                                                                
                                                                                                                                                // Get private equal method via reflection
                                                                                                                                                Method equalMethod = CoreOperationCompare.class.getDeclaredMethod("equal", Object.class, Object.class);
                                                                                                                                                equalMethod.setAccessible(true);
                                                                                                                                                
                                                                                                                                                // Set up mock behavior
                                                                                                                                                when(pointer1.equals(pointer2)).thenReturn(false);
                                                                                                                                                when(pointer1.getValue()).thenReturn("value1");
                                                                                                                                                when(pointer2.getValue()).thenReturn("value2");
                                                                                                                                                
                                                                                                                                                // Invoke and verify
                                                                                                                                                boolean result = (boolean) equalMethod.invoke(coreOperationCompare, pointer1, pointer2);
                                                                                                                                                assertFalse(result);
                                                                                                                                            }

    @Test
                                                                                                                                        public void testEqualWithNumberValues() throws Exception {
                                                                                                                                            CoreOperationCompare coreOperationCompare = new CoreOperationCompare(null, null) {
                                                                                                                                                @Override
                                                                                                                                                public int getPrecedence() {
                                                                                                                                                    return 0;
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                @Override
                                                                                                                                                public boolean isSymmetric() {
                                                                                                                                                    return false;
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                @Override
                                                                                                                                                public String getSymbol() {
                                                                                                                                                    return "==";
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                @Override
                                                                                                                                                public Object computeValue(EvalContext context) {
                                                                                                                                                    return null;
                                                                                                                                                }
                                                                                                                                            };
                                                                                                                                            Method equalMethod = CoreOperationCompare.class.getDeclaredMethod("equal", Object.class, Object.class);
                                                                                                                                            equalMethod.setAccessible(true);
                                                                                                                                        
                                                                                                                                            boolean result1 = (boolean) equalMethod.invoke(coreOperationCompare, 5, 5.0);
                                                                                                                                            assertTrue(result1);
                                                                                                                                        
                                                                                                                                            boolean result2 = (boolean) equalMethod.invoke(coreOperationCompare, 5, 6);
                                                                                                                                            assertFalse(result2);
                                                                                                                                        
                                                                                                                                            boolean result3 = (boolean) equalMethod.invoke(coreOperationCompare, 5.0, 5);
                                                                                                                                            assertTrue(result3);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testEqualWithPointerAndValue() throws Exception {
                                                                                                                                            // Setup
                                                                                                                                            CoreOperationCompare coreOperationCompare = new CoreOperationCompare(null, null) {
                                                                                                                                                @Override
                                                                                                                                                public int getPrecedence() {
                                                                                                                                                    return 0;
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                @Override
                                                                                                                                                public boolean isSymmetric() {
                                                                                                                                                    return true;
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                @Override
                                                                                                                                                public String getSymbol() {
                                                                                                                                                    return "=";
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                @Override
                                                                                                                                                public Object computeValue(org.apache.commons.jxpath.ri.EvalContext context) {
                                                                                                                                                    return null; // Dummy implementation
                                                                                                                                                }
                                                                                                                                            };
                                                                                                                                            
                                                                                                                                            Method equalMethod = CoreOperationCompare.class.getDeclaredMethod(
                                                                                                                                                "equal", Object.class, Object.class);
                                                                                                                                            equalMethod.setAccessible(true);
                                                                                                                                            
                                                                                                                                            Pointer pointer1 = mock(Pointer.class);
                                                                                                                                            
                                                                                                                                            // Test cases
                                                                                                                                            when(pointer1.getValue()).thenReturn("value");
                                                                                                                                            boolean result1 = (boolean) equalMethod.invoke(coreOperationCompare, pointer1, "value");
                                                                                                                                            assertTrue(result1);
                                                                                                                                            
                                                                                                                                            boolean result2 = (boolean) equalMethod.invoke(coreOperationCompare, "value", pointer1);
                                                                                                                                            assertTrue(result2);
                                                                                                                                            
                                                                                                                                            when(pointer1.getValue()).thenReturn("different");
                                                                                                                                            boolean result3 = (boolean) equalMethod.invoke(coreOperationCompare, pointer1, "value");
                                                                                                                                            assertFalse(result3);
                                                                                                                                        }

    @Test
                                                                                                                                    public void testEqualWithNumberValues1() throws Exception {
                                                                                                                                        CoreOperationCompare coreOperationCompare = new CoreOperationCompare(null, null) {
                                                                                                                                            @Override
                                                                                                                                            public int getPrecedence() {
                                                                                                                                                return 0;
                                                                                                                                            }
                                                                                                                                            
                                                                                                                                            @Override
                                                                                                                                            public boolean isSymmetric() {
                                                                                                                                                return false;
                                                                                                                                            }
                                                                                                                                            
                                                                                                                                            @Override
                                                                                                                                            public String getSymbol() {
                                                                                                                                                return "==";
                                                                                                                                            }
                                                                                                                                            
                                                                                                                                            @Override
                                                                                                                                            public Object computeValue(EvalContext context) {
                                                                                                                                                return null;
                                                                                                                                            }
                                                                                                                                        };
                                                                                                                                        Method equalMethod = CoreOperationCompare.class.getDeclaredMethod("equal", Object.class, Object.class);
                                                                                                                                        equalMethod.setAccessible(true);
                                                                                                                                    
                                                                                                                                        boolean result1 = (boolean) equalMethod.invoke(coreOperationCompare, 5, 5.0);
                                                                                                                                        assertTrue(result1);
                                                                                                                                    
                                                                                                                                        boolean result2 = (boolean) equalMethod.invoke(coreOperationCompare, 5, 6);
                                                                                                                                        assertFalse(result2);
                                                                                                                                    
                                                                                                                                        boolean result3 = (boolean) equalMethod.invoke(coreOperationCompare, 5.0, 5);
                                                                                                                                        assertTrue(result3);
                                                                                                                                    }

    @Test
                                                                                                                                public void testEqualWithStringValues() {
                                                                                                                                    // Create mocks
                                                                                                                                    EvalContext context = mock(EvalContext.class);
                                                                                                                                    Expression left = mock(Expression.class);
                                                                                                                                    Expression right = mock(Expression.class);
                                                                                                                                    
                                                                                                                                    // Create anonymous subclass since CoreOperationCompare is abstract
                                                                                                                                    CoreOperationCompare coreOperationCompare = new CoreOperationCompare(left, right) {
                                                                                                                                        @Override
                                                                                                                                        public Object computeValue(EvalContext context) {
                                                                                                                                            return null;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public int getPrecedence() {
                                                                                                                                            return 0;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public boolean isSymmetric() {
                                                                                                                                            return true;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public String getSymbol() {
                                                                                                                                            return "==";
                                                                                                                                        }
                                                                                                                                    };
                                                                                                                                    
                                                                                                                                    // Setup mock behavior
                                                                                                                                    when(left.compute(context)).thenReturn("test");
                                                                                                                                    when(right.compute(context)).thenReturn("test");
                                                                                                                                    
                                                                                                                                    // Test
                                                                                                                                }

    @Test
                                                                                                                                public void testEqualWithEmptyCollections() {
                                                                                                                                    // Create mock objects
                                                                                                                                    EvalContext context = mock(EvalContext.class);
                                                                                                                                    Expression left = mock(Expression.class);
                                                                                                                                    Expression right = mock(Expression.class);
                                                                                                                                    
                                                                                                                                    // Create anonymous subclass since CoreOperationCompare is abstract
                                                                                                                                    CoreOperationCompare coreOperationCompare = new CoreOperationCompare(left, right) {
                                                                                                                                        @Override
                                                                                                                                        public Object computeValue(EvalContext context) {
                                                                                                                                            return null;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public int getPrecedence() {
                                                                                                                                            return 0;
                                                                                                                                        }
                                                                                                                                
                                                                                                                                        @Override
                                                                                                                                        public boolean isSymmetric() {
                                                                                                                                            return false;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public String getSymbol() {
                                                                                                                                            return "=";
                                                                                                                                        }
                                                                                                                                    };
                                                                                                                                    
                                                                                                                                    // Setup mock behavior
                                                                                                                                    
                                                                                                                                    // Test the equal method using reflection since it's protected
                                                                                                                                    try {
                                                                                                                                        Method equalMethod = CoreOperationCompare.class.getDeclaredMethod(
                                                                                                                                            "equal", EvalContext.class, Expression.class, Expression.class);
                                                                                                                                        equalMethod.setAccessible(true);
                                                                                                                                        boolean result = (boolean) equalMethod.invoke(coreOperationCompare, context, left, right);
                                                                                                                                        assertTrue(result);
                                                                                                                                    } catch (Exception e) {
                                                                                                                                        fail("Reflection failed: " + e.getMessage());
                                                                                                                                    }
                                                                                                                                }

    @Test
                                                                                                                                public void testEqualWithDifferentTypes() {
                                                                                                                                    // Create anonymous subclass since CoreOperationCompare is abstract
                                                                                                                                    CoreOperationCompare coreOperationCompare = new CoreOperationCompare(null, null) {
                                                                                                                                        @Override
                                                                                                                                        public Object computeValue(EvalContext context) {
                                                                                                                                            return null;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public int getPrecedence() {
                                                                                                                                            return 0;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public boolean isSymmetric() {
                                                                                                                                            return false;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public String getSymbol() {
                                                                                                                                            return null;
                                                                                                                                        }
                                                                                                                                    };
                                                                                                                                    
                                                                                                                                    EvalContext context = mock(EvalContext.class);
                                                                                                                                    Expression left = mock(Expression.class);
                                                                                                                                    Expression right = mock(Expression.class);
                                                                                                                                    
                                                                                                                                    // Stub behavior
                                                                                                                                    when(left.compute(context)).thenReturn("5");
                                                                                                                                    when(right.compute(context)).thenReturn(5);
                                                                                                                                    
                                                                                                                                    // Test
                                                                                                                                }

    @Test
                                                                                                                                public void testEqualWithLeftIteratorRightObject() {
                                                                                                                                    // Create mocks
                                                                                                                                    EvalContext context = mock(EvalContext.class);
                                                                                                                                    Expression left = mock(Expression.class);
                                                                                                                                    Expression right = mock(Expression.class);
                                                                                                                                    Iterator<?> iterator = mock(Iterator.class);
                                                                                                                                    
                                                                                                                                    // Create anonymous subclass since CoreOperationCompare is abstract
                                                                                                                                    CoreOperationCompare coreOperationCompare = new CoreOperationCompare(left, right) {
                                                                                                                                        @Override
                                                                                                                                        public Object computeValue(EvalContext context) {
                                                                                                                                            return null;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public int getPrecedence() {
                                                                                                                                            return 0;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public boolean isSymmetric() {
                                                                                                                                            return false;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public String getSymbol() {
                                                                                                                                            return "==";
                                                                                                                                        }
                                                                                                                                    };
                                                                                                                                    
                                                                                                                                    // Setup mock behavior
                                                                                                                                    when(left.compute(context)).thenReturn(iterator);
                                                                                                                                    when(right.compute(context)).thenReturn("test");
                                                                                                                                    when(iterator.hasNext()).thenReturn(false);
                                                                                                                                    
                                                                                                                                    // Test
                                                                                                                                    Object leftResult = left.compute(context);
                                                                                                                                    Object rightResult = right.compute(context);
                                                                                                                                }

    @Test
                                                                                                                                public void testEqualWithRightIteratorLeftObject() {
                                                                                                                                    // Create mocks
                                                                                                                                    CoreOperationCompare coreOperationCompare = new CoreOperationCompare(null, null) {
                                                                                                                                        @Override
                                                                                                                                        public Object computeValue(EvalContext context) {
                                                                                                                                            return null;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public int getPrecedence() {
                                                                                                                                            return 0;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public boolean isSymmetric() {
                                                                                                                                            return false;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public String getSymbol() {
                                                                                                                                            return "==";
                                                                                                                                        }
                                                                                                                                    };
                                                                                                                                    
                                                                                                                                    EvalContext context = mock(EvalContext.class);
                                                                                                                                    Expression left = mock(Expression.class);
                                                                                                                                    Expression right = mock(Expression.class);
                                                                                                                                    Iterator<?> iterator = mock(Iterator.class);
                                                                                                                                    
                                                                                                                                    // Setup mock behavior
                                                                                                                                    when(left.compute(context)).thenReturn("test");
                                                                                                                                    when(right.compute(context)).thenReturn(iterator);
                                                                                                                                    when(iterator.hasNext()).thenReturn(false);
                                                                                                                                    
                                                                                                                                    // Test
                                                                                                                                }

    @Test
                                                                                                                                public void testEqualWithBothIterators() {
                                                                                                                                    // Create anonymous subclass since CoreOperationCompare is abstract
                                                                                                                                    CoreOperationCompare coreOperationCompare = new CoreOperationCompare(null, null) {
                                                                                                                                        @Override
                                                                                                                                        public Object computeValue(EvalContext context) {
                                                                                                                                            return null;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public int getPrecedence() {
                                                                                                                                            return 0;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public boolean isSymmetric() {
                                                                                                                                            return false;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public String getSymbol() {
                                                                                                                                            return "==";
                                                                                                                                        }
                                                                                                                            
                                                                                                                                        // Add protected method to make it accessible in test
                                                                                                                                        public boolean testEqual(Object left, Object right) {
                                                                                                                                            return equal(left, right);
                                                                                                                                        }
                                                                                                                                    };
                                                                                                                                    
                                                                                                                                    EvalContext context = mock(EvalContext.class);
                                                                                                                                    EvalContext left = mock(EvalContext.class);
                                                                                                                                    EvalContext right = mock(EvalContext.class);
                                                                                                                                    Iterator<?> iterator = mock(Iterator.class);
                                                                                                                                    
                                                                                                                                    // Setup mock behavior
                                                                                                                                    when(iterator.hasNext()).thenReturn(false);
                                                                                                                                    
                                                                                                                                    // Test using the exposed method
                                                                                                                                }

    @Test
                                                                                                                                public void testEqualWithPointers() {
                                                                                                                                    // Create mocks
                                                                                                                                    EvalContext context = mock(EvalContext.class);
                                                                                                                                    Expression left = mock(Expression.class);
                                                                                                                                    Expression right = mock(Expression.class);
                                                                                                                                    Pointer pointer1 = mock(Pointer.class);
                                                                                                                                    Pointer pointer2 = mock(Pointer.class);
                                                                                                                                    
                                                                                                                                    // Create anonymous subclass since CoreOperationCompare is abstract
                                                                                                                                    CoreOperationCompare coreOperationCompare = new CoreOperationCompare(left, right) {
                                                                                                                                        @Override
                                                                                                                                        protected boolean equal(EvalContext context, Expression left, Expression right) {
                                                                                                                                            Object l = left.compute(context);
                                                                                                                                            Object r = right.compute(context);
                                                                                                                                            if (l == r) {
                                                                                                                                                return true;
                                                                                                                                            }
                                                                                                                                            if (l instanceof Pointer && r instanceof Pointer) {
                                                                                                                                                return ((Pointer) l).equals((Pointer) r);
                                                                                                                                            }
                                                                                                                                            return l != null && l.equals(r);
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public int getPrecedence() {
                                                                                                                                            return 0;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public boolean isSymmetric() {
                                                                                                                                            return false;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public String getSymbol() {
                                                                                                                                            return "=";
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public Object computeValue(EvalContext context) {
                                                                                                                                            return null;
                                                                                                                                        }
                                                                                                                                    };
                                                                                                                                
                                                                                                                                    // Setup mock behavior
                                                                                                                                    when(left.compute(context)).thenReturn(pointer1);
                                                                                                                                    when(right.compute(context)).thenReturn(pointer2);
                                                                                                                                    when(pointer1.equals(pointer2)).thenReturn(true);
                                                                                                                                
                                                                                                                                    // Test
                                                                                                                                }

    @Test
                                                                                                                                public void testEqualWithStringValues1() {
                                                                                                                                    // Create mocks
                                                                                                                                    EvalContext context = mock(EvalContext.class);
                                                                                                                                    Expression left = mock(Expression.class);
                                                                                                                                    Expression right = mock(Expression.class);
                                                                                                                                    
                                                                                                                                    // Create anonymous subclass since CoreOperationCompare is abstract
                                                                                                                                    CoreOperationCompare coreOperationCompare = new CoreOperationCompare(left, right) {
                                                                                                                                        @Override
                                                                                                                                        public Object computeValue(EvalContext context) {
                                                                                                                                            return null;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public int getPrecedence() {
                                                                                                                                            return 0;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public boolean isSymmetric() {
                                                                                                                                            return true;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public String getSymbol() {
                                                                                                                                            return "==";
                                                                                                                                        }
                                                                                                                                    };
                                                                                                                                    
                                                                                                                                    // Setup mock behavior
                                                                                                                                    when(left.compute(context)).thenReturn("test");
                                                                                                                                    when(right.compute(context)).thenReturn("test");
                                                                                                                                    
                                                                                                                                    // Test
                                                                                                                                }

    @Test
                                                                                                                            public void testEqualWithInitialContext() {
                                                                                                                                Expression left = mock(Expression.class);
                                                                                                                                Expression right = mock(Expression.class);
                                                                                                                                EvalContext context = mock(EvalContext.class);
                                                                                                                                
                                                                                                                                Object initialContext = new Object() {
                                                                                                                                    public void reset() {}
                                                                                                                                };
                                                                                                                                
                                                                                                                                when(left.compute(context)).thenReturn(initialContext);
                                                                                                                                when(right.compute(context)).thenReturn("test");
                                                                                                                                
                                                                                                                                try {
                                                                                                                                    verify(left).compute(context);
                                                                                                                                    verify(right).compute(context);
                                                                                                                                    initialContext.getClass().getMethod("reset").invoke(initialContext);
                                                                                                                                } catch (Exception e) {
                                                                                                                                    throw new RuntimeException(e);
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                            public void testEqualWithSameValues() {
                                                                                                // Create abstract class definition since it's not provided
                                                                                                abstract class CoreOperationCompare {
                                                                                                    protected Expression left;
                                                                                                    protected Expression right;
                                                                                                    
                                                                                                    public CoreOperationCompare(Expression left, Expression right) {
                                                                                                        this.left = left;
                                                                                                        this.right = right;
                                                                                                    }
                                                                                                    
                                                                                                    public abstract String getSymbol();
                                                                                                    public abstract int getPrecedence();
                                                                                                    protected abstract boolean evaluateCompare(int comparisonResult);
                                                                                                    public abstract Object computeValue(EvalContext context);
                                                                                                    public abstract boolean isSymmetric();
                                                                                                }
                                                                                        
                                                                                                // Create concrete subclass
                                                                                                class ConcreteCoreOperationCompare extends CoreOperationCompare {
                                                                                                    private Expression left;
                                                                                                    private Expression right;
                                                                                                    
                                                                                                    public ConcreteCoreOperationCompare(Expression left, Expression right) {
                                                                                                        super(left, right);
                                                                                                        this.left = left;
                                                                                                        this.right = right;
                                                                                                    }
                                                                                        
                                                                                                    @Override
                                                                                                    public String getSymbol() {
                                                                                                        return "==";
                                                                                                    }
                                                                                        
                                                                                                    @Override
                                                                                                    public int getPrecedence() {
                                                                                                        return 0;
                                                                                                    }
                                                                                                    
                                                                                                    @Override
                                                                                                    protected boolean evaluateCompare(int comparisonResult) {
                                                                                                        return comparisonResult == 0;
                                                                                                    }
                                                                                                    
                                                                                                    @Override
                                                                                                    public Object computeValue(EvalContext context) {
                                                                                                        return computeValue(context, left, right);
                                                                                                    }
                                                                                        
                                                                                                    @Override
                                                                                                    public boolean isSymmetric() {
                                                                                                        return false;
                                                                                                    }
                                                                                                    
                                                                                                    public boolean computeValue(EvalContext context, Expression left, Expression right) {
                                                                                                        Object l = left.computeValue(context);
                                                                                                        Object r = right.computeValue(context);
                                                                                                        return l.equals(r);
                                                                                                    }
                                                                                                }
                                                                                            
                                                                                                // Create mock objects
                                                                                                EvalContext context = mock(EvalContext.class);
                                                                                                Expression left = mock(Expression.class);
                                                                                                Expression right = mock(Expression.class);
                                                                                                ConcreteCoreOperationCompare coreOperationCompare = new ConcreteCoreOperationCompare(left, right);
                                                                                            
                                                                                                // Set up mock behavior
                                                                                                when(left.computeValue(eq(context))).thenReturn("test");
                                                                                                when(right.computeValue(eq(context))).thenReturn("test");
                                                                                            
                                                                                                // Test the equal method
                                                                                                assertTrue(coreOperationCompare.computeValue(context, left, right));
                                                                                            }

    @Test
                                                                                    public void testEqualWithMatchingIterator() {
                                                                                        // Create mock objects
                                                                                        CoreOperationCompare coreOperationCompare = new CoreOperationCompare(null, null) {
                                                                                            @Override
                                                                                            public Object computeValue(EvalContext context) {
                                                                                                return null;
                                                                                            }
                                                                                            
                                                                                            @Override
                                                                                            public int getPrecedence() {
                                                                                                return 0;
                                                                                            }
                                                                                            
                                                                                            @Override
                                                                                            public boolean isSymmetric() {
                                                                                                return true;
                                                                                            }
                                                                                            
                                                                                            @Override
                                                                                            public String getSymbol() {
                                                                                                return "=";
                                                                                            }
                                                                                        };
                                                                                        
                                                                                        // Define test data
                                                                                        // Set up mock behavior
                                                                                        // Add assertions here
                                                                                    }

    @Test
                                                                                    public void testEqualWithSelfContext() {
                                                                                        // Create concrete instance of abstract class
                                                                                        CoreOperationCompare instance = new CoreOperationCompare(null, null) {
                                                                                            @Override
                                                                                            public Object computeValue(org.apache.commons.jxpath.ri.EvalContext context) {
                                                                                                return null;
                                                                                            }
                                                                                            
                                                                                            @Override
                                                                                            public int getPrecedence() {
                                                                                                return 0;
                                                                                            }
                                                                                            
                                                                                            @Override
                                                                                            public boolean isSymmetric() {
                                                                                                return false;
                                                                                            }
                                                                                            
                                                                                            @Override
                                                                                            public String getSymbol() {
                                                                                                return "==";
                                                                                            }
                                                                                        };
                                                                                
                                                                                        // Create mock context
                                                                                        Object mockContext = new Object() {
                                                                                            public void setValue(Object value) {}
                                                                                            public void setIndex(int index) {}
                                                                                        };
                                                                                    }

    @Test
                                                            public void testEqualWithDifferentTypes1() throws Exception {
                                                                CoreOperationCompare compare = new CoreOperationCompare(null, null) {
                                                                    @Override
                                                                    public Object computeValue(EvalContext context) {
                                                                        return false;
                                                                    }
                                                                    
                                                                    @Override
                                                                    public int getPrecedence() {
                                                                        return 0;
                                                                    }
                                                                    
                                                                    @Override
                                                                    public boolean isSymmetric() {
                                                                        return false;
                                                                    }
                                                                    
                                                                    @Override
                                                                    public String getSymbol() {
                                                                        return "=";
                                                                    }
                                                                };
                                                                
                                                                // Use reflection to access protected method
                                                                Method equalMethod = CoreOperationCompare.class.getDeclaredMethod("equal", Object.class, Object.class);
                                                                equalMethod.setAccessible(true);
                                                                
                                                                assertFalse((boolean)equalMethod.invoke(compare, "test", 123));
                                                                assertTrue((boolean)equalMethod.invoke(compare, null, null));
                                                                assertTrue((boolean)equalMethod.invoke(compare, "same", "same"));
                                                            }

    @Test
                                                        public void testEqualWithMixedTypes() throws Exception {
                                                            // Create test objects
                                                            Expression[] args = new Expression[2];
                                                            args[0] = new Expression() {
                                                                @Override
                                                                public Object computeValue(EvalContext context) {
                                                                    return null;
                                                                }
                                                                
                                                                @Override
                                                                public Object compute(EvalContext context) {
                                                                    return null;
                                                                }
                                                                
                                                                @Override
                                                                public boolean isContextDependent() {
                                                                    return false;
                                                                }
                                                                
                                                                @Override
                                                                public boolean computeContextDependent() {
                                                                    return false;
                                                                }
                                                            };
                                                            
                                                            args[1] = new Expression() {
                                                                @Override
                                                                public Object computeValue(EvalContext context) {
                                                                    return null;
                                                                }
                                                                
                                                                @Override
                                                                public Object compute(EvalContext context) {
                                                                    return null;
                                                                }
                                                                
                                                                @Override
                                                                public boolean isContextDependent() {
                                                                    return false;
                                                                }
                                                                
                                                                @Override
                                                                public boolean computeContextDependent() {
                                                                    return false;
                                                                }
                                                            };
                                                            
                                                            CoreOperationCompare operation = new CoreOperationCompare(args[0], args[1]) {
                                                                @Override
                                                                public Object computeValue(EvalContext context) {
                                                                    return null;
                                                                }
                                                                
                                                                @Override
                                                                public Object compute(EvalContext context) {
                                                                    return null;
                                                                }
                                                                
                                                                @Override
                                                                public boolean isContextDependent() {
                                                                    return false;
                                                                }
                                                                
                                                                @Override
                                                                public int getPrecedence() {
                                                                    return 0;
                                                                }
                                                                
                                                                @Override
                                                                public boolean computeContextDependent() {
                                                                    return false;
                                                                }
                                                                
                                                                @Override
                                                                public String getSymbol() {
                                                                    return "==";
                                                                }
                                                                
                                                                @Override
                                                                protected boolean isSymmetric() {
                                                                    return true;
                                                                }
                                                            };
                                                            
                                                            // Get private equal method via reflection
                                                            Method equalMethod = CoreOperationCompare.class.getDeclaredMethod("equal", Object.class, Object.class);
                                                            equalMethod.setAccessible(true);
                                                            
                                                            // Test with null values
                                                            boolean result = (boolean) equalMethod.invoke(operation, null, null);
                                                            assertTrue(result);
                                                        }

    @Test
        public void testEqualWithNonMatchingIterator() {
            // Create mock expressions
            Expression leftExpr = mock(Expression.class);
            Expression rightExpr = mock(Expression.class);
            
            // Create test class instance using anonymous subclass since CoreOperationCompare is abstract
            CoreOperationCompare coreOperationCompare = new CoreOperationCompare(leftExpr, rightExpr) {
                @Override
                public Object computeValue(EvalContext context) {
                    return null;
                }
                
                @Override
                public int getPrecedence() {
                    return 0;
                }
                
                @Override
                public boolean isSymmetric() {
                    return false;
                }
                
                @Override
                public String getSymbol() {
                    return "=";
                }
                
                @Override
                public boolean equals(Object obj) {
                    return super.equals(obj);
                }
            };
            
            // Create mock objects
            EvalContext context = mock(EvalContext.class);
            Object pointer1 = new Object();
            Object pointer2 = new Object();
            
            // Test the equal method
        }

    @Test
        public void testEqualWithIteratorAndValue() {
            CoreOperationCompare operation = new CoreOperationCompare(null, null) {
                @Override
                public boolean computeContextDependent() {
                    return false;
                }
                
                @Override
                public int getPrecedence() {
                    return 0;
                }
                
                @Override
                public boolean isSymmetric() {
                    return false;
                }
    
                @Override
                public String getSymbol() {
                    return "==";
                }
    
                @Override
                public Object computeValue(EvalContext context) {
                    return null;
                }
    
                @Override
                protected boolean equal(EvalContext context, Expression left, Expression right) {
                    return false;
                }
            };
            
            Expression left = new Expression() {
                @Override
                public Object compute(EvalContext context) {
                    return null;
                }
                
                @Override
                public Object computeValue(EvalContext context) {
                    return null;
                }
                
                @Override
                public boolean computeContextDependent() {
                    return false;
                }
                
                public int getPrecedence() {
                    return 0;
                }
    
                @Override
                public String toString() {
                    return "expr";
                }
            };
            
            Expression right = mock(Expression.class);
            EvalContext context = mock(EvalContext.class);
            
        }


}
