package gentest.org.apache.commons.jxpath.ri.model.dom.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.model.dom.*;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.w3c.dom.Attr;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
 
public class DOMAttributeIteratorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                    public void testTestAttrWithXmlnsPrefix() throws Exception {
                                                                                                                                                                        // Setup test objects
                                                                                                                                                                        Attr attr = mock(Attr.class);
                                                                                                                                                                        NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                        QName name = new QName("test");
                                                                                                                                                                        
                                                                                                                                                                        // Create iterator instance and get private method via reflection
                                                                                                                                                                        DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                        Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class);
                                                                                                                                                                        testAttrMethod.setAccessible(true);
                                                                                                                                                                        
                                                                                                                                                                        // Mock behavior
                                                                                                                                                                        when(DOMNodePointer.getPrefix(attr)).thenReturn("xmlns");
                                                                                                                                                                        when(DOMNodePointer.getLocalName(attr)).thenReturn("test");
                                                                                                                                                                        
                                                                                                                                                                        // Test
                                                                                                                                                                        boolean result = (boolean) testAttrMethod.invoke(iterator, attr);
                                                                                                                                                                        assertFalse(result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testTestAttrWithMatchingPrefix() throws Exception {
                                                                                                                                                                        // Create mocks
                                                                                                                                                                        Attr attr = mock(Attr.class);
                                                                                                                                                                        QName name = mock(QName.class);
                                                                                                                                                                        NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                        
                                                                                                                                                                        // Create test instance (assuming DOMAttributeIterator constructor takes parent and name)
                                                                                                                                                                        DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                        
                                                                                                                                                                        // Get private method via reflection
                                                                                                                                                                        Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class);
                                                                                                                                                                        testAttrMethod.setAccessible(true);
                                                                                                                                                                        
                                                                                                                                                                        // Setup mock behavior
                                                                                                                                                                        when(DOMNodePointer.getPrefix(attr)).thenReturn("prefix");
                                                                                                                                                                        when(DOMNodePointer.getLocalName(attr)).thenReturn("local");
                                                                                                                                                                        when(name.getName()).thenReturn("local");
                                                                                                                                                                        when(name.getPrefix()).thenReturn("prefix");
                                                                                                                                                                        when(parent.getNamespaceURI(anyString())).thenReturn("http://example.com");
                                                                                                                                                                        
                                                                                                                                                                        // Invoke and verify
                                                                                                                                                                        boolean result = (boolean) testAttrMethod.invoke(iterator, attr);
                                                                                                                                                                        assertTrue(result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testTestAttrWithDifferentPrefixesButSameNamespace() throws Exception {
                                                                                                                                                                        // Create mocks
                                                                                                                                                                        Attr attr = mock(Attr.class);
                                                                                                                                                                        QName name = mock(QName.class);
                                                                                                                                                                        NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                        
                                                                                                                                                                        // Create test instance (assuming DOMAttributeIterator is the class under test)
                                                                                                                                                                        Object iterator = new Object() {
                                                                                                                                                                            private boolean testAttr(Attr attr, QName name, NodePointer parent) {
                                                                                                                                                                                String nodePrefix = DOMNodePointer.getPrefix(attr);
                                                                                                                                                                                String nodeLocalName = DOMNodePointer.getLocalName(attr);
                                                                                                                                                                
                                                                                                                                                                                if (nodePrefix != null && nodePrefix.equals("xmlns")) {
                                                                                                                                                                                    return false;
                                                                                                                                                                                }
                                                                                                                                                                
                                                                                                                                                                                if (nodePrefix == null && nodeLocalName.equals("xmlns")) {
                                                                                                                                                                                    return false;
                                                                                                                                                                                }
                                                                                                                                                                
                                                                                                                                                                                String testLocalName = name.getName();
                                                                                                                                                                                if (testLocalName.equals("*") || testLocalName.equals(nodeLocalName)) {
                                                                                                                                                                                    String testPrefix = name.getPrefix();
                                                                                                                                                                
                                                                                                                                                                                    if (testPrefix == null || equalStrings(testPrefix, nodePrefix)) {
                                                                                                                                                                                        return true;
                                                                                                                                                                                    }
                                                                                                                                                                                    if (nodePrefix == null) {
                                                                                                                                                                                        return false;
                                                                                                                                                                                    }
                                                                                                                                                                                    return equalStrings(parent.getNamespaceURI(testPrefix), parent
                                                                                                                                                                                            .getNamespaceURI(nodePrefix));
                                                                                                                                                                                }
                                                                                                                                                                                return false;
                                                                                                                                                                            }
                                                                                                                                                                            
                                                                                                                                                                            private boolean equalStrings(String s1, String s2) {
                                                                                                                                                                                return s1 == null ? s2 == null : s1.equals(s2);
                                                                                                                                                                            }
                                                                                                                                                                        };
                                                                                                                                                                
                                                                                                                                                                        // Get the testAttr method via reflection
                                                                                                                                                                        Method testAttrMethod = iterator.getClass().getDeclaredMethod("testAttr", Attr.class, QName.class, NodePointer.class);
                                                                                                                                                                        testAttrMethod.setAccessible(true);
                                                                                                                                                                
                                                                                                                                                                        // Set up mock behavior
                                                                                                                                                                        when(DOMNodePointer.getPrefix(attr)).thenReturn("prefix1");
                                                                                                                                                                        when(DOMNodePointer.getLocalName(attr)).thenReturn("local");
                                                                                                                                                                        when(name.getName()).thenReturn("local");
                                                                                                                                                                        when(name.getPrefix()).thenReturn("prefix2");
                                                                                                                                                                        when(parent.getNamespaceURI("prefix1")).thenReturn("http://test");
                                                                                                                                                                        when(parent.getNamespaceURI("prefix2")).thenReturn("http://test");
                                                                                                                                                                
                                                                                                                                                                        // Invoke and assert
                                                                                                                                                                        boolean result = (boolean) testAttrMethod.invoke(iterator, attr, name, parent);
                                                                                                                                                                        assertTrue(result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                public void testTestAttrWithMatchingLocalNameAndNullPrefix() throws Exception {
                                                                                                                                                                    // Create mocks
                                                                                                                                                                    NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                    QName name = mock(QName.class);
                                                                                                                                                                    Attr attr = mock(Attr.class);
                                                                                                                                                                    
                                                                                                                                                                    // Get private method via reflection
                                                                                                                                                                    Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class);
                                                                                                                                                                    testAttrMethod.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Create iterator instance
                                                                                                                                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                    
                                                                                                                                                                    // Setup mock behavior
                                                                                                                                                                    when(DOMNodePointer.getPrefix(attr)).thenReturn(null);
                                                                                                                                                                    when(DOMNodePointer.getLocalName(attr)).thenReturn("local");
                                                                                                                                                                    when(name.getName()).thenReturn("local");
                                                                                                                                                                    when(name.getPrefix()).thenReturn(null);
                                                                                                                                                                    when(parent.getNamespaceURI(anyString())).thenReturn("uri");
                                                                                                                                                            
                                                                                                                                                                    // Invoke and assert
                                                                                                                                                                    boolean result = (boolean) testAttrMethod.invoke(iterator, attr);
                                                                                                                                                                    assertTrue(result);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testTestAttrWithWildcardLocalName() throws Exception {
                                                                                                                                                                    // Create mocks
                                                                                                                                                                    Attr attr = mock(Attr.class);
                                                                                                                                                                    QName name = mock(QName.class);
                                                                                                                                                                    NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                    
                                                                                                                                                                    // Create test instance and get private method via reflection
                                                                                                                                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                    Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class);
                                                                                                                                                                    testAttrMethod.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Setup mock behavior
                                                                                                                                                                    when(DOMNodePointer.getPrefix(attr)).thenReturn("prefix");
                                                                                                                                                                    when(DOMNodePointer.getLocalName(attr)).thenReturn("local");
                                                                                                                                                                    when(name.getName()).thenReturn("*");
                                                                                                                                                                    when(name.getPrefix()).thenReturn("prefix");
                                                                                                                                                                    
                                                                                                                                                                    // Invoke and verify
                                                                                                                                                                    boolean result = (boolean) testAttrMethod.invoke(iterator, attr);
                                                                                                                                                                    assertTrue(result);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testTestAttrWithNonMatchingLocalName() throws Exception {
                                                                                                                                                                    // Create mocks
                                                                                                                                                                    Attr attr = mock(Attr.class);
                                                                                                                                                                    QName name = mock(QName.class);
                                                                                                                                                                    Object iterator = mock(Object.class);
                                                                                                                                                                    
                                                                                                                                                                    // Get the testAttr method via reflection
                                                                                                                                                                    Method testAttrMethod = iterator.getClass().getDeclaredMethod("testAttr", Attr.class);
                                                                                                                                                                    testAttrMethod.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Set up mock behavior
                                                                                                                                                                    when(DOMNodePointer.getPrefix(attr)).thenReturn("prefix");
                                                                                                                                                                    when(DOMNodePointer.getLocalName(attr)).thenReturn("local1");
                                                                                                                                                                    when(name.getName()).thenReturn("local2");
                                                                                                                                                                    
                                                                                                                                                                    // Invoke and verify
                                                                                                                                                                    boolean result = (boolean) testAttrMethod.invoke(iterator, attr);
                                                                                                                                                                    assertFalse(result);
                                                                                                                                                                }

    @Test
                                                                                                                                public void testTestAttrWithXmlnsLocalName() throws Exception {
                                                                                                                                    
                                                                                                                                    // Create mocks
                                                                                                                                    Attr attr = mock(Attr.class);
                                                                                                                                    NodePointer parent = mock(NodePointer.class);
                                                                                                                                    QName name = mock(QName.class);
                                                                                                                                    
                                                                                                                                    // Create iterator instance
                                                                                                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                    
                                                                                                                                    // Get private method via reflection
                                                                                                                                    Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class);
                                                                                                                                    testAttrMethod.setAccessible(true);
                                                                                                                                    
                                                                                                                                    // Setup mocks
                                                                                                                                    when(DOMNodePointer.getPrefix(attr)).thenReturn(null);
                                                                                                                                    when(DOMNodePointer.getLocalName(attr)).thenReturn("xmlns");
                                                                                                                                    
                                                                                                                                    // Test
                                                                                                                                    boolean result = (boolean) testAttrMethod.invoke(iterator, attr);
                                                                                                                                    assertFalse(result);
                                                                                                                                }

    @Test
                                                                                                                                public void testTestAttrWithNullNodePrefix() throws Exception {
                                                                                                                                    
                                                                                                                                    NodePointer parent = mock(NodePointer.class);
                                                                                                                                    QName name = new QName("prefix", "local");
                                                                                                                                    Attr attr = mock(Attr.class);
                                                                                                                                    DOMNodePointer domNodePointer = mock(DOMNodePointer.class);
                                                                                                                                    
                                                                                                                                    when(parent.getNode()).thenReturn(domNodePointer);
                                                                                                                                    
                                                                                                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                    
                                                                                                                                    Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class);
                                                                                                                                    testAttrMethod.setAccessible(true);
                                                                                                                                    
                                                                                                                                    when(domNodePointer.getPrefix(attr)).thenReturn(null);
                                                                                                                                    when(domNodePointer.getLocalName(attr)).thenReturn("local");
                                                                                                                                    
                                                                                                                                    boolean result = (boolean) testAttrMethod.invoke(iterator, attr);
                                                                                                                                    assertFalse(result);
                                                                                                                                }

    @Test
                                                                                                                                public void testGetAttributeWithNamespaceButNoNSAttribute() throws Exception {
                                                                                                                                    // Create mocks
                                                                                                                                    QName qname = mock(QName.class);
                                                                                                                                    NodePointer parent = mock(NodePointer.class);
                                                                                                                                    Object namespaceResolver = mock(Object.class); // Changed to mock
                                                                                                                                    Element element = mock(Element.class);
                                                                                                                                    NamedNodeMap attributesMap = mock(NamedNodeMap.class);
                                                                                                                                    Attr attr = mock(Attr.class);
                                                                                                                                    
                                                                                                                                    // Setup mock behavior
                                                                                                                                    when(qname.getPrefix()).thenReturn("testPrefix");
                                                                                                                                    when(qname.getName()).thenReturn("testName");
                                                                                                                                    when(parent.getNamespaceURI("testPrefix")).thenReturn("testNS");
                                                                                                                                    
                                                                                                                                    // Mock the reflection call
                                                                                                                                    when(element.getAttributeNodeNS("testNS", "testName")).thenReturn(null);
                                                                                                                                    when(element.getAttributes()).thenReturn(attributesMap);
                                                                                                                                    when(attributesMap.getLength()).thenReturn(1);
                                                                                                                                    when(attributesMap.item(0)).thenReturn(attr);
                                                                                                                                    
                                                                                                                                    // Create real iterator instance
                                                                                                                                    DOMAttributeIterator realIterator = new DOMAttributeIterator(parent, qname);
                                                                                                                                    
                                                                                                                                    // Use reflection to test private method
                                                                                                                                    Method method = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                                                                                                                    method.setAccessible(true);
                                                                                                                                    Attr result = (Attr) method.invoke(realIterator, element, qname);
                                                                                                                                    
                                                                                                                                    assertEquals(attr, result);
                                                                                                                                }

    @Test
                                                                                                                            public void testSetPosition_InvalidHighPosition() {
                                                                                                                                List<Attr> attributes = new ArrayList<>();
                                                                                                                                Attr mockAttr = mock(Attr.class);
                                                                                                                                when(mockAttr.getNodeType()).thenReturn(Node.ATTRIBUTE_NODE);
                                                                                                                                attributes.add(mockAttr);
                                                                                                                                
                                                                                                                                NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                QName name = new QName("test");
                                                                                                                                
                                                                                                                                DOMAttributeIterator iterator = new DOMAttributeIterator(parentPointer, name);
                                                                                                                                assertFalse(iterator.setPosition(2));
                                                                                                                                assertEquals(2, iterator.getPosition());
                                                                                                                            }

    @Test
                                                                                                                        public void testSetPosition_EmptyAttributes() {
                                                                                                                            // Setup mocks
                                                                                                                            NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                            Element element = mock(Element.class);
                                                                                                                            NamedNodeMap attributes = mock(NamedNodeMap.class);
                                                                                                                            
                                                                                                                            when(parentPointer.getNode()).thenReturn(element);
                                                                                                                            when(element.getAttributes()).thenReturn(attributes);
                                                                                                                            when(attributes.getLength()).thenReturn(0);
                                                                                                                        
                                                                                                                            // Create iterator with QName parameter
                                                                                                                            QName testQName = new QName("test");
                                                                                                                            DOMAttributeIterator iterator = new DOMAttributeIterator(parentPointer, testQName);
                                                                                                                            
                                                                                                                            // Test
                                                                                                                            assertFalse(iterator.setPosition(1));
                                                                                                                            assertEquals(1, iterator.getPosition());
                                                                                                                        }

    @Test
                                                                                                            public void testGetAttributeNoPrefix() throws Exception {
                                                                                                                // Create mocks
                                                                                                                Element element = mock(Element.class);
                                                                                                                QName qname = new QName("", "testName");
                                                                                                                Attr attr = mock(Attr.class);
                                                                                                                NodePointer parent = mock(DOMNodePointer.class);
                                                                                                                
                                                                                                                // Create test instance
                                                                                                                DOMAttributeIterator iterator = new DOMAttributeIterator(parent, qname);
                                                                                                                
                                                                                                                // Set up mock behavior
                                                                                                                when(element.getAttributeNode("testName")).thenReturn(attr);
                                                                                                                
                                                                                                                // Use reflection to test private method
                                                                                                                Method method = DOMAttributeIterator.class.getDeclaredMethod(
                                                                                                                    "getAttribute", Element.class, QName.class);
                                                                                                                method.setAccessible(true);
                                                                                                                Attr result = (Attr) method.invoke(iterator, element, qname);
                                                                                                                
                                                                                                                // Verify
                                                                                                                assertEquals(attr, result);
                                                                                                            }

    @Test
                                                                                public void testGetAttributeNoPrefixNoMatch() throws Exception {
                                                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(null, null);
                                                                                    Element element = mock(Element.class);
                                                                                    QName qname = new QName("", "testName");
                                                                                    NodePointer parent = mock(NodePointer.class);
                                                                                    
                                                                                    when(element.getAttributeNode("testName")).thenReturn(null);
                                                                                
                                                                                    Method method = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                                                                    method.setAccessible(true);
                                                                                    Attr result = (Attr) method.invoke(iterator, element, qname);
                                                                                    
                                                                                    assertNull(result);
                                                                                }

    @Test
                                                                public void testSetPosition_InvalidLowPosition() {
                                                                    List<Object> attributes = new ArrayList<>();
                                                                    Node mockNode = mock(Node.class);
                                                                    attributes.add(mockNode);
                                                                    
                                                                    QName qname = mock(QName.class);
                                                                    NodePointer parent = mock(NodePointer.class);
                                                                    when(parent.getNode()).thenReturn(mock(Node.class));
                                                                    
                                                                    org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator iterator = 
                                                                        new org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator(parent, qname);
                                                                    
                                                                    // Use reflection to set the private attributes field
                                                                    try {
                                                                        java.lang.reflect.Field field = iterator.getClass().getDeclaredField("attributes");
                                                                        field.setAccessible(true);
                                                                        field.set(iterator, attributes);
                                                                    } catch (Exception e) {
                                                                        fail("Failed to set attributes field via reflection");
                                                                    }
                                                                    
                                                                    assertFalse(iterator.setPosition(0));
                                                                    assertEquals(0, iterator.getPosition());
                                                                }

    @Test
                                        public void testSetPosition_BoundaryConditions() {
                                            // Setup
                                            List<Object> attributes = new ArrayList<>();
                                            attributes.add(mock(Object.class));
                                            attributes.add(mock(Object.class));
                                            
                                            QName name = new QName("http://example.com", "test");
                                            NodePointer parent = mock(NodePointer.class);
                                            Node node = mock(Node.class);
                                            when(parent.getNode()).thenReturn(node);
                                            
                                            // Create iterator instance
                                            DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                            
                                            // Lower boundary
                                            assertTrue(iterator.setPosition(1));
                                            assertEquals(1, iterator.getPosition());
                                            
                                            // Upper boundary
                                            assertTrue(iterator.setPosition(2));
                                            assertEquals(2, iterator.getPosition());
                                            
                                            // Just above upper boundary
                                            assertFalse(iterator.setPosition(3));
                                            assertEquals(2, iterator.getPosition()); // Position should not change when setPosition fails
                                        }

    @Test
            public void testGetAttributeWithPrefixAndNamespace() throws Exception {
                // Create mocks and test objects
                Element element = mock(Element.class);
                NodePointer parent = mock(NodePointer.class);
                Attr attr = mock(Attr.class);
                QName qname = new QName("testPrefix", "testName");
                
                DOMAttributeIterator iterator = new DOMAttributeIterator(parent, qname);
                
                // Setup mock behavior
                when(parent.getNamespaceResolver()).thenReturn(mock(org.apache.commons.jxpath.ri.NamespaceResolver.class));
                when(parent.getNamespaceResolver().getNamespaceURI("testPrefix")).thenReturn("testNS");
                when(element.getAttributeNodeNS("testNS", "testName")).thenReturn(attr);
                
                // Use reflection to access private method
                Method method = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                method.setAccessible(true);
                Attr result = (Attr) method.invoke(iterator, element, qname);
                
                // Verify
                assertEquals(attr, result);
            }

    @Test
        public void testGetAttributeWithNamespaceButNoMatchingAttr() throws Exception {
            // Create mocks
            DOMAttributeIterator iterator = mock(DOMAttributeIterator.class);
            Element element = mock(Element.class);
            QName qname = new QName("testPrefix", "testName");
            NodePointer parent = mock(NodePointer.class);
            Attr attr = mock(Attr.class);
            
            // Setup mock behavior
            when(element.getAttributeNodeNS("testNS", "testName")).thenReturn(null);
        
            // Mock private testAttr method
            Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class);
            testAttrMethod.setAccessible(true);
            when(testAttrMethod.invoke(iterator, attr)).thenReturn(false);
        
            // Set parent field using reflection
            Field parentField = DOMAttributeIterator.class.getDeclaredField("parent");
            parentField.setAccessible(true);
            parentField.set(iterator, parent);
        
            // Invoke private method
            Method method = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
            method.setAccessible(true);
            Attr result = (Attr) method.invoke(iterator, element, qname);
        
            assertNull(result);
        }

    @Test
        public void testSetPosition_ValidPosition() {
            // Setup
            NodePointer parentPointer = mock(NodePointer.class);
            Element element = mock(Element.class);
            when(parentPointer.getNode()).thenReturn(element);
            
            List<QName> attributes = new ArrayList<>();
            attributes.add(new QName("http://example.com", "attr1"));
            attributes.add(new QName("http://example.com", "attr2"));
            
            Attr attr1 = mock(Attr.class);
            Attr attr2 = mock(Attr.class);
            when(element.getAttributeNodeNS("http://example.com", "attr1")).thenReturn(attr1);
            when(element.getAttributeNodeNS("http://example.com", "attr2")).thenReturn(attr2);
            
            
            // Test
            
        }

    @Test
        public void testTestAttrWithDifferentPrefixesAndDifferentNamespaces() throws Exception {
            // Create mocks and test instance
            Attr attr = mock(Attr.class);
            NodePointer parent = mock(NodePointer.class);
            
            // Get private method via reflection
            Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod(
                "testAttr", Attr.class, org.apache.commons.jxpath.ri.QName.class);
            testAttrMethod.setAccessible(true);
            
            // Create QName parameter
            QName qname = new QName("prefix2", "local");
            
            // Set up mock behavior
            when(attr.getPrefix()).thenReturn("prefix1");
            when(attr.getLocalName()).thenReturn("local");
            when(parent.getNamespaceURI("prefix1")).thenReturn("http://test1");
            when(parent.getNamespaceURI("prefix2")).thenReturn("http://test2");
            
            // Invoke and verify
        }

    @Test
        public void testGetAttributeWithPrefixNoNamespace() throws Exception {
            // Create mocks
            Element element = mock(Element.class);
            NodePointer parent = mock(NodePointer.class);
            Attr attr = mock(Attr.class);
            
            // Create namespace resolver implementation
            Object resolver = new Object() {
                public String getNamespaceURI(String prefix) {
                    return null;
                }
                public String getPrefix(String namespaceURI) {
                    return null;
                }
            };
            
            // Create test instance with proper constructor
            when(parent.getNode()).thenReturn(element);
            
            // Setup mock behavior
            when(element.getAttributeNode("testName")).thenReturn(attr);
            
            // Use reflection to access private method
            Method method = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
            method.setAccessible(true);
            
            // Verify
        }


}
