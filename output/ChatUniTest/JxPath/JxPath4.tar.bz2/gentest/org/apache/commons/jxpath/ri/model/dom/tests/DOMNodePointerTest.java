package gentest.org.apache.commons.jxpath.ri.model.dom.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.model.dom.*;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.apache.commons.jxpath.AbstractFactory;
import org.apache.commons.jxpath.JXPathAbstractFactoryException;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.JXPathException;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import org.apache.commons.jxpath.ri.compiler.ProcessingInstructionTest;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.apache.commons.jxpath.ri.model.beans.NullPointer;
import org.apache.commons.jxpath.util.TypeUtils;
import org.w3c.dom.Attr;
import org.w3c.dom.Comment;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.ProcessingInstruction;
 
public class DOMNodePointerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                        public void testGetBaseValueWithDifferentNodeTypes() {
                                                                                            // Test with element node
                                                                                            Node elementNode = mock(Node.class);
                                                                                            when(elementNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                            DOMNodePointer elementPointer = new DOMNodePointer(elementNode, null);
                                                                                            assertSame(elementNode, elementPointer.getBaseValue());
                                                                                    
                                                                                            // Test with text node
                                                                                            Node textNode = mock(Node.class);
                                                                                            when(textNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                            DOMNodePointer textPointer = new DOMNodePointer(textNode, null);
                                                                                            assertSame(textNode, textPointer.getBaseValue());
                                                                                    
                                                                                            // Test with document node
                                                                                            Node documentNode = mock(Node.class);
                                                                                            when(documentNode.getNodeType()).thenReturn(Node.DOCUMENT_NODE);
                                                                                            DOMNodePointer documentPointer = new DOMNodePointer(documentNode, null);
                                                                                            assertSame(documentNode, documentPointer.getBaseValue());
                                                                                        }

    @Test
                                                                                        public void testGetImmediateNodeReturnsNode() {
                                                                                            // Create a mock Node
                                                                                            Node mockNode = mock(Node.class);
                                                                                            
                                                                                            // Create DOMNodePointer instance with the mock node
                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                            
                                                                                            // Verify getImmediateNode returns the same node instance
                                                                                            assertSame(mockNode, pointer.getImmediateNode());
                                                                                        }

    @Test
                                                                                        public void testGetImmediateNodeAfterConstructionWithLocale() {
                                                                                            Node mockNode = mock(Node.class);
                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, java.util.Locale.US);
                                                                                            
                                                                                            assertSame(mockNode, pointer.getImmediateNode());
                                                                                        }

    @Test
                                                                                        public void testGetImmediateNodeAfterConstructionWithId() {
                                                                                            Node mockNode = mock(Node.class);
                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, java.util.Locale.US, "testId");
                                                                                            
                                                                                            assertSame(mockNode, pointer.getImmediateNode());
                                                                                        }

    @Test
                                                                                        public void testGetImmediateNodeAfterParentConstructor() {
                                                                                            Node parentNode = mock(Node.class);
                                                                                            Node childNode = mock(Node.class);
                                                                                            
                                                                                            DOMNodePointer parentPointer = new DOMNodePointer(parentNode, null);
                                                                                            DOMNodePointer childPointer = new DOMNodePointer(parentPointer, childNode);
                                                                                            
                                                                                            assertSame(childNode, childPointer.getImmediateNode());
                                                                                        }

    @Test
                                                                                        public void testGetImmediateNodeWithDifferentNodeTypes() {
                                                                                            // Test with Element node
                                                                                            Node elementNode = mock(Element.class);
                                                                                            DOMNodePointer elementPointer = new DOMNodePointer(elementNode, null);
                                                                                            assertSame(elementNode, elementPointer.getImmediateNode());
                                                                                    
                                                                                            // Test with Text node
                                                                                            Node textNode = mock(Node.class);
                                                                                            when(textNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                            DOMNodePointer textPointer = new DOMNodePointer(textNode, null);
                                                                                            assertSame(textNode, textPointer.getImmediateNode());
                                                                                    
                                                                                            // Test with Document node
                                                                                            Node documentNode = mock(Document.class);
                                                                                            DOMNodePointer documentPointer = new DOMNodePointer(documentNode, null);
                                                                                            assertSame(documentNode, documentPointer.getImmediateNode());
                                                                                        }

    @Test
                                                                                        public void testAsPathDocumentNode() {
                                                                                            Document doc = mock(Document.class);
                                                                                            when(doc.getNodeType()).thenReturn(Node.DOCUMENT_NODE);
                                                                                            
                                                                                            DOMNodePointer pointer = new DOMNodePointer(null, doc);
                                                                                            assertEquals("", pointer.asPath());
                                                                                        }

    @Test
                                                                                        public void testGetValueWithCommentNodeAndNullData() {
                                                                                            Comment comment = mock(Comment.class);
                                                                                            when(comment.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                                                            when(comment.getData()).thenReturn(null);
                                                                                            
                                                                                            DOMNodePointer commentPointer = new DOMNodePointer(comment, null);
                                                                                            assertEquals("", commentPointer.getValue());
                                                                                        }

    @Test
                                                                                        public void testGetValueWithCommentNodeAndEmptyData() {
                                                                                            Comment comment = mock(Comment.class);
                                                                                            when(comment.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                                                            when(comment.getData()).thenReturn("");
                                                                                            
                                                                                            DOMNodePointer commentPointer = new DOMNodePointer(comment, null);
                                                                                            assertEquals("", commentPointer.getValue());
                                                                                        }

    @Test
                                                                                        public void testGetValueWithCommentNodeAndData() {
                                                                                            Comment comment = mock(Comment.class);
                                                                                            when(comment.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                                                            when(comment.getData()).thenReturn("  test comment  ");
                                                                                            
                                                                                            DOMNodePointer commentPointer = new DOMNodePointer(comment, null);
                                                                                            assertEquals("test comment", commentPointer.getValue());
                                                                                        }

    @Test
                                                                                        public void testGetValueWithProcessingInstructionNode() {
                                                                                            ProcessingInstruction piNode = mock(ProcessingInstruction.class);
                                                                                            when(piNode.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                            when(piNode.getData()).thenReturn("  pi data  ");
                                                                                            
                                                                                            DOMNodePointer piPointer = new DOMNodePointer(piNode, null);
                                                                                            assertEquals("pi data", piPointer.getValue());
                                                                                        }

    @Test
                                                                                        public void testGetValueWithEmptyElementNode() {
                                                                                            Node elementNode = mock(Node.class);
                                                                                            when(elementNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                            
                                                                                            NodeList emptyNodeList = mock(NodeList.class);
                                                                                            when(emptyNodeList.getLength()).thenReturn(0);
                                                                                            
                                                                                            when(elementNode.getChildNodes()).thenReturn(emptyNodeList);
                                                                                            
                                                                                            DOMNodePointer elementPointer = new DOMNodePointer(elementNode, null);
                                                                                            assertEquals("", elementPointer.getValue());
                                                                                        }

    @Test
                                                                                    public void testGetDefaultNamespaceURI_WhenDefaultNamespaceIsNullAndNodeIsDocument() {
                                                                                        // Create mocks
                                                                                        Node node = mock(Node.class);
                                                                                        Document document = mock(Document.class);
                                                                                        Element element = mock(Element.class);
                                                                                        Attr attr = mock(Attr.class);
                                                                                
                                                                                        // Set up mock behavior
                                                                                        when(node.getNodeType()).thenReturn(Node.DOCUMENT_NODE);
                                                                                        when(document.getDocumentElement()).thenReturn(element);
                                                                                        
                                                                                        DOMNodePointer pointer = new DOMNodePointer(document, null);
                                                                                
                                                                                        when(element.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                        when(element.getAttributeNode("xmlns")).thenReturn(attr);
                                                                                        when(attr.getValue()).thenReturn("http://example.com");
                                                                                
                                                                                        String result = pointer.getDefaultNamespaceURI();
                                                                                        assertEquals("http://example.com", result);
                                                                                    }

    @Test
                                                                                    public void testGetDefaultNamespaceURI_WhenDefaultNamespaceIsNullAndNodeIsElementWithNamespace() {
                                                                                        // Setup mocks
                                                                                        Node node = mock(Node.class);
                                                                                        Element element = mock(Element.class);
                                                                                        Attr attr = mock(Attr.class);
                                                                                        
                                                                                        DOMNodePointer pointer = new DOMNodePointer(node, null);
                                                                                        
                                                                                        // Mock behavior
                                                                                        when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                        when(node.getParentNode()).thenReturn(null);
                                                                                        when(((Element) node).getAttributeNode("xmlns")).thenReturn(attr);
                                                                                        when(attr.getValue()).thenReturn("http://example.com");
                                                                                
                                                                                        // Test
                                                                                        String result = pointer.getDefaultNamespaceURI();
                                                                                        
                                                                                        // Verify
                                                                                        assertEquals("http://example.com", result);
                                                                                    }

    @Test
                                                                                    public void testGetDefaultNamespaceURI_WhenDefaultNamespaceIsNullAndNoNamespaceFound() {
                                                                                        // Create mocks
                                                                                        Node node = mock(Node.class);
                                                                                        Element element = mock(Element.class);
                                                                                        DOMNodePointer pointer = new DOMNodePointer(node, null);
                                                                                        
                                                                                        // Setup behavior
                                                                                        when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                        when(node.getParentNode()).thenReturn(null);
                                                                                        when(((Element) node).getAttributeNode("xmlns")).thenReturn(null);
                                                                                
                                                                                        // Test
                                                                                        String result = pointer.getDefaultNamespaceURI();
                                                                                        assertNull(result);
                                                                                    }

    @Test
                                                                                    public void testGetDefaultNamespaceURI_WhenDefaultNamespaceIsEmptyString() {
                                                                                        Node node = mock(Node.class);
                                                                                        Document document = mock(Document.class);
                                                                                        Element element = mock(Element.class);
                                                                                        
                                                                                        when(node.getOwnerDocument()).thenReturn(document);
                                                                                        when(document.getDocumentElement()).thenReturn(element);
                                                                                        when(element.getAttributeNode("xmlns")).thenReturn(null);
                                                                                        
                                                                                        DOMNodePointer pointer = new DOMNodePointer(node, null) {
                                                                                            @Override
                                                                                            public String getDefaultNamespaceURI() {
                                                                                                try {
                                                                                                    java.lang.reflect.Field field = DOMNodePointer.class
                                                                                                        .getDeclaredField("defaultNamespace");
                                                                                                    field.setAccessible(true);
                                                                                                    field.set(this, "");
                                                                                                } catch (Exception e) {
                                                                                                    throw new RuntimeException(e);
                                                                                                }
                                                                                                return super.getDefaultNamespaceURI();
                                                                                            }
                                                                                        };
                                                                                
                                                                                        String result = pointer.getDefaultNamespaceURI();
                                                                                        assertNull(result);
                                                                                    }

    @Test
                                                                                    public void testGetDefaultNamespaceURI_WhenDefaultNamespaceIsAlreadySet() throws Exception {
                                                                                        Node node = mock(Node.class);
                                                                                        Document document = mock(Document.class);
                                                                                        Element element = mock(Element.class);
                                                                                        when(node.getOwnerDocument()).thenReturn(document);
                                                                                        when(document.getDocumentElement()).thenReturn(element);
                                                                                
                                                                                        DOMNodePointer pointer = new DOMNodePointer(node, null) {
                                                                                            @Override
                                                                                            public String getDefaultNamespaceURI() {
                                                                                                try {
                                                                                                    java.lang.reflect.Field field = DOMNodePointer.class.getDeclaredField("defaultNamespace");
                                                                                                    field.setAccessible(true);
                                                                                                    field.set(this, "http://predefined.com");
                                                                                                } catch (Exception e) {
                                                                                                    throw new RuntimeException(e);
                                                                                                }
                                                                                                return super.getDefaultNamespaceURI();
                                                                                            }
                                                                                        };
                                                                                
                                                                                        String result = pointer.getDefaultNamespaceURI();
                                                                                        assertEquals("http://predefined.com", result);
                                                                                    }

    @Test
                                                                                    public void testGetDefaultNamespaceURI_WhenDocumentElementHasNoNamespace() {
                                                                                        // Create mocks
                                                                                        Document document = mock(Document.class);
                                                                                        Element element = mock(Element.class);
                                                                                        Node node = mock(Node.class);
                                                                                        
                                                                                        // Set up mock behavior
                                                                                        when(node.getNodeType()).thenReturn(Node.DOCUMENT_NODE);
                                                                                        when(document.getDocumentElement()).thenReturn(element);
                                                                                        DOMNodePointer pointer = new DOMNodePointer(document, null);
                                                                                
                                                                                        when(element.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                        when(element.getAttributeNode("xmlns")).thenReturn(null);
                                                                                        when(element.getParentNode()).thenReturn(null);
                                                                                
                                                                                        // Test
                                                                                        String result = pointer.getDefaultNamespaceURI();
                                                                                        assertNull(result);
                                                                                    }

    @Test
                                                                                    public void testGetDefaultNamespaceURI_WhenMultipleLevelsOfParents() {
                                                                                        Node node = mock(Node.class);
                                                                                        Node grandParent = mock(Node.class);
                                                                                        Node parent = mock(Node.class);
                                                                                        Attr attr = mock(Attr.class);
                                                                                        DOMNodePointer pointer = new DOMNodePointer(node, null);
                                                                                        
                                                                                        when(node.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                        when(node.getParentNode()).thenReturn(parent);
                                                                                        
                                                                                        when(parent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                        when(((Element) parent).getAttributeNode("xmlns")).thenReturn(null);
                                                                                        when(parent.getParentNode()).thenReturn(grandParent);
                                                                                        
                                                                                        when(grandParent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                        when(((Element) grandParent).getAttributeNode("xmlns")).thenReturn(attr);
                                                                                        when(attr.getValue()).thenReturn("http://deep.example.com");
                                                                                    
                                                                                        String result = pointer.getDefaultNamespaceURI();
                                                                                        assertEquals("http://deep.example.com", result);
                                                                                    }

    @Test
                                                                                    public void testGetBaseValueReturnsNode() {
                                                                                        // Create mock objects
                                                                                        Node mockNode = mock(Node.class);
                                                                                        
                                                                                        // Create test instance (using reflection since constructor details aren't provided)
                                                                                        DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                        
                                                                                        // Invoke method and verify
                                                                                        Object result = pointer.getBaseValue();
                                                                                        assertSame(mockNode, result);
                                                                                    }

    @Test
                                                                                    public void testGetBaseValueAfterNodeChange() {
                                                                                        // Create test objects
                                                                                        Node originalNode = mock(Node.class);
                                                                                        DOMNodePointer pointer = new DOMNodePointer(originalNode, null);
                                                                                        
                                                                                        Node newMockNode = mock(Node.class);
                                                                                        // Use reflection to change the node field
                                                                                        try {
                                                                                            java.lang.reflect.Field nodeField = DOMNodePointer.class.getDeclaredField("node");
                                                                                            nodeField.setAccessible(true);
                                                                                            nodeField.set(pointer, newMockNode);
                                                                                            
                                                                                            Object result = pointer.getBaseValue();
                                                                                            assertSame(newMockNode, result);
                                                                                        } catch (Exception e) {
                                                                                            fail("Failed to set node field via reflection: " + e.getMessage());
                                                                                        }
                                                                                    }

    @Test
                                                                                    public void testGetBaseValueConsistency() {
                                                                                        Node mockNode = mock(Node.class);
                                                                                        DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                        Object firstCall = pointer.getBaseValue();
                                                                                        Object secondCall = pointer.getBaseValue();
                                                                                        assertSame(firstCall, secondCall);
                                                                                    }

    @Test
                                                                                    public void testIsLanguageWhenCurrentLanguageMatches() {
                                                                                        Element mockElement = mock(Element.class);
                                                                                        DOMNodePointer pointer = new DOMNodePointer(mockElement, Locale.ENGLISH);
                                                                                        when(mockElement.getAttribute("xml:lang")).thenReturn("en-US");
                                                                                        when(mockElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                        
                                                                                        assertTrue(pointer.isLanguage("en"));
                                                                                        assertTrue(pointer.isLanguage("en-US"));
                                                                                        assertTrue(pointer.isLanguage("EN"));
                                                                                        assertTrue(pointer.isLanguage("EN-us"));
                                                                                    }

    @Test
                                                                                    public void testIsLanguageWhenCurrentLanguageDoesNotMatch() {
                                                                                        Element mockElement = mock(Element.class);
                                                                                        DOMNodePointer pointer = new DOMNodePointer(mockElement, Locale.ENGLISH);
                                                                                        when(mockElement.getAttribute("xml:lang")).thenReturn("fr-FR");
                                                                                        when(mockElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                        
                                                                                        assertFalse(pointer.isLanguage("en"));
                                                                                        assertFalse(pointer.isLanguage("fr-CA"));
                                                                                    }

    @Test
                                                                                    public void testIsLanguageWithEmptyLanguage() {
                                                                                        Element mockElement = mock(Element.class);
                                                                                        DOMNodePointer pointer = new DOMNodePointer(mockElement, Locale.ENGLISH);
                                                                                        when(mockElement.getAttribute("xml:lang")).thenReturn("");
                                                                                        when(mockElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                        
                                                                                        assertFalse(pointer.isLanguage("en"));
                                                                                    }

    @Test
                                                                                    public void testIsLanguageWithNullInput() {
                                                                                        Element mockElement = mock(Element.class);
                                                                                        DOMNodePointer pointer = new DOMNodePointer(mockElement, Locale.ENGLISH);
                                                                                        when(mockElement.getAttribute("xml:lang")).thenReturn("en-US");
                                                                                        when(mockElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                        
                                                                                        assertFalse(pointer.isLanguage(null));
                                                                                    }

    @Test
                                                                                    public void testIsLanguageWithEmptyInput() {
                                                                                        Element mockElement = mock(Element.class);
                                                                                        DOMNodePointer pointer = new DOMNodePointer(mockElement, java.util.Locale.ENGLISH);
                                                                                        when(mockElement.getAttribute("xml:lang")).thenReturn("en-US");
                                                                                        when(mockElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                        
                                                                                        assertTrue(pointer.isLanguage(""));
                                                                                    }

    @Test
                                                                                    public void testIsLanguageCaseInsensitive() {
                                                                                        Element mockElement = mock(Element.class);
                                                                                        DOMNodePointer pointer = new DOMNodePointer(mockElement, Locale.ENGLISH);
                                                                                        when(mockElement.getAttribute("xml:lang")).thenReturn("EN-us");
                                                                                        when(mockElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                        
                                                                                        assertTrue(pointer.isLanguage("en"));
                                                                                        assertTrue(pointer.isLanguage("en-US"));
                                                                                    }

    @Test
                                                                                    public void testIsLanguageWithParentHavingLanguage() {
                                                                                        Node mockNode = mock(Node.class);
                                                                                        Node parentNode = mock(Node.class);
                                                                                        when(mockNode.getParentNode()).thenReturn(parentNode);
                                                                                        when(parentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                        when(((Element)parentNode).getAttribute("xml:lang")).thenReturn("de-DE");
                                                                                        
                                                                                        DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
                                                                                        
                                                                                        assertTrue(pointer.isLanguage("de"));
                                                                                        assertFalse(pointer.isLanguage("en"));
                                                                                    }

    @Test
                                                                                public void testFindEnclosingAttributeWhenNodeIsNull() throws Exception {
                                                                                    Method method = DOMNodePointer.class.getDeclaredMethod(
                                                                                        "findEnclosingAttribute", Node.class, String.class);
                                                                                    method.setAccessible(true);
                                                                                    String result = (String) method.invoke(null, null, "attrName");
                                                                                    assertNull(result);
                                                                                }

    @Test
                                                                            public void testAsPathTextNode() throws Exception {
                                                                                Node node = mock(Node.class);
                                                                                NodePointer parentPointer = mock(NodePointer.class);
                                                                                
                                                                                when(node.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                when(parentPointer.asPath()).thenReturn("/parent");
                                                                                
                                                                                DOMNodePointer pointer = new DOMNodePointer(parentPointer, node);
                                                                                
                                                                                Method getRelativePositionOfTextNode = DOMNodePointer.class.getDeclaredMethod("getRelativePositionOfTextNode");
                                                                                getRelativePositionOfTextNode.setAccessible(true);
                                                                                when(getRelativePositionOfTextNode.invoke(pointer)).thenReturn(1);
                                                                                
                                                                                assertEquals("/parent/text()[1]", pointer.asPath());
                                                                            }

    @Test
                                                                            public void testAsPathCDATASectionNode() throws Exception {
                                                                                Node node = mock(Node.class);
                                                                                NodePointer parentPointer = mock(NodePointer.class);
                                                                                
                                                                                when(node.getNodeType()).thenReturn(Node.CDATA_SECTION_NODE);
                                                                                when(parentPointer.asPath()).thenReturn("/parent");
                                                                                
                                                                                DOMNodePointer pointer = new DOMNodePointer(parentPointer, node);
                                                                                
                                                                                Method getRelativePositionOfTextNode = DOMNodePointer.class.getDeclaredMethod("getRelativePositionOfTextNode");
                                                                                getRelativePositionOfTextNode.setAccessible(true);
                                                                                when(getRelativePositionOfTextNode.invoke(pointer)).thenReturn(2);
                                                                                
                                                                                assertEquals("/parent/text()[2]", pointer.asPath());
                                                                            }

    @Test
                                                                            public void testAsPathProcessingInstructionNode() throws Exception {
                                                                                NodePointer parentPointer = mock(NodePointer.class);
                                                                                ProcessingInstruction pi = mock(ProcessingInstruction.class);
                                                                                when(pi.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                when(pi.getTarget()).thenReturn("target");
                                                                                when(parentPointer.asPath()).thenReturn("/parent");
                                                                                
                                                                                DOMNodePointer pointer = new DOMNodePointer(parentPointer, pi);
                                                                                
                                                                                Method getRelativePositionOfPI = DOMNodePointer.class.getDeclaredMethod("getRelativePositionOfPI", String.class);
                                                                                getRelativePositionOfPI.setAccessible(true);
                                                                                when(getRelativePositionOfPI.invoke(pointer, "target")).thenReturn(1);
                                                                                
                                                                                assertEquals("/parent/processing-instruction('target')[1]", pointer.asPath());
                                                                            }

    @Test
                                                                            public void testEscape() throws Exception {
                                                                                Node node = new org.apache.xerces.dom.DocumentImpl().createElement("test");
                                                                                DOMNodePointer pointer = new DOMNodePointer(node, null);
                                                                                Method escape = DOMNodePointer.class.getDeclaredMethod("escape", String.class);
                                                                                escape.setAccessible(true);
                                                                                
                                                                                assertEquals("test&apos;string", escape.invoke(pointer, "test'string"));
                                                                                assertEquals("test&quot;string", escape.invoke(pointer, "test\"string"));
                                                                                assertEquals("test&apos;&quot;string", escape.invoke(pointer, "test'\"string"));
                                                                            }

    @Test
                                                                        public void testGetDefaultNamespaceURI_WhenDefaultNamespaceIsNullAndParentHasNamespace() {
                                                                            // Create mocks
                                                                            Node node = mock(Node.class);
                                                                            Node parent = mock(Node.class);
                                                                            Attr attr = mock(Attr.class);
                                                                            
                                                                            // Setup behavior
                                                                            when(node.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                            when(node.getParentNode()).thenReturn(parent);
                                                                            when(parent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                            when(((Element) parent).getAttributeNode("xmlns")).thenReturn(attr);
                                                                            when(attr.getValue()).thenReturn("http://example.com");
                                                                        
                                                                            // Create test object
                                                                            DOMNodePointer pointer = new DOMNodePointer(null, node);
                                                                            
                                                                            // Test
                                                                            String result = pointer.getDefaultNamespaceURI();
                                                                            assertEquals("http://example.com", result);
                                                                        }

    @Test
                                                                        public void testGetBaseValueWithNullNode() {
                                                                            NodePointer parent = null;
                                                                            Node node = null;
                                                                            DOMNodePointer nullPointer = new DOMNodePointer(parent, node);
                                                                            assertNull(nullPointer.getBaseValue());
                                                                        }

    @Test
                                                                        public void testFindEnclosingAttributeWhenNodeIsNotElement() throws Exception {
                                                                            Node node = mock(Node.class);
                                                                            when(node.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                            when(node.getParentNode()).thenReturn(null);
                                                                            
                                                                            Method method = DOMNodePointer.class.getDeclaredMethod(
                                                                                "findEnclosingAttribute", Node.class, String.class);
                                                                            method.setAccessible(true);
                                                                            
                                                                            String result = (String) method.invoke(null, node, "attrName");
                                                                            assertNull(result);
                                                                        }

    @Test
                                                                        public void testFindEnclosingAttributeWhenElementHasAttribute() throws Exception {
                                                                            Node node = mock(Node.class);
                                                                            Element element = mock(Element.class);
                                                                            
                                                                            when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                            when(node.getParentNode()).thenReturn(null);
                                                                            when(element.getAttribute("attrName")).thenReturn("value");
                                                                            when(((Element) node)).thenReturn(element);
                                                                            
                                                                            Method method = DOMNodePointer.class.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                                                                            method.setAccessible(true);
                                                                            String result = (String) method.invoke(null, node, "attrName");
                                                                            
                                                                            assertEquals("value", result);
                                                                        }

    @Test
                                                                        public void testFindEnclosingAttributeWhenElementHasEmptyAttribute() throws Exception {
                                                                            Node node = mock(Node.class);
                                                                            Element element = mock(Element.class);
                                                                            
                                                                            when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                            when(node.getParentNode()).thenReturn(null);
                                                                            when(((Element) node).getAttribute("attrName")).thenReturn("");
                                                                            
                                                                            Method method = DOMNodePointer.class.getDeclaredMethod(
                                                                                "findEnclosingAttribute", Node.class, String.class);
                                                                            method.setAccessible(true);
                                                                            String result = (String) method.invoke(null, node, "attrName");
                                                                            
                                                                            assertNull(result);
                                                                        }

    @Test
                                                                        public void testFindEnclosingAttributeWhenParentHasAttribute() throws Exception {
                                                                            Node node = mock(Node.class);
                                                                            Node parentElement = mock(Node.class);
                                                                            
                                                                            when(node.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                            when(node.getParentNode()).thenReturn(parentElement);
                                                                            when(parentElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                            when(((Element)parentElement).getAttribute("attrName")).thenReturn("parentValue");
                                                                            
                                                                            Class<?> clazz = Class.forName("org.apache.commons.jxpath.ri.model.dom.DOMNodePointer");
                                                                            Method method = clazz.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                                                                            method.setAccessible(true);
                                                                            
                                                                            String result = (String) method.invoke(null, node, "attrName");
                                                                            assertEquals("parentValue", result);
                                                                        }

    @Test
                                                                        public void testFindEnclosingAttributeWhenGrandparentHasAttribute() throws Exception {
                                                                            Node node = mock(Node.class);
                                                                            Node parentNode = mock(Node.class);
                                                                            Node grandparent = mock(Node.class);
                                                                            
                                                                            when(node.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                            when(node.getParentNode()).thenReturn(parentNode);
                                                                            when(parentNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                            when(parentNode.getParentNode()).thenReturn(grandparent);
                                                                            when(grandparent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                            when(((Element) grandparent).getAttribute("attrName")).thenReturn("grandparentValue");
                                                                    
                                                                            Method method = DOMNodePointer.class.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                                                                            method.setAccessible(true);
                                                                            String result = (String) method.invoke(null, node, "attrName");
                                                                            
                                                                            assertEquals("grandparentValue", result);
                                                                        }

    @Test
                                                                        public void testFindEnclosingAttributeWhenNoNodeHasAttribute() throws Exception {
                                                                            Node node = mock(Node.class);
                                                                            Node parentNode = mock(Node.class);
                                                                            
                                                                            when(node.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                            when(node.getParentNode()).thenReturn(parentNode);
                                                                            when(parentNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                            when(parentNode.getParentNode()).thenReturn(null);
                                                                            
                                                                            Method method = DOMNodePointer.class.getDeclaredMethod(
                                                                                "findEnclosingAttribute", Node.class, String.class);
                                                                            method.setAccessible(true);
                                                                            String result = (String) method.invoke(null, node, "attrName");
                                                                            assertNull(result);
                                                                        }

    @Test
                                                                        public void testFindEnclosingAttributeWithMultipleLevels() throws Exception {
                                                                            Node node = mock(Node.class);
                                                                            Node parentNode = mock(Node.class);
                                                                            Node grandparent = mock(Node.class);
                                                                            
                                                                            when(node.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                            when(node.getParentNode()).thenReturn(parentNode);
                                                                            when(parentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                            when(((Element) parentNode).getAttribute("attrName")).thenReturn("");
                                                                            when(parentNode.getParentNode()).thenReturn(grandparent);
                                                                            when(grandparent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                            when(((Element) grandparent).getAttribute("attrName")).thenReturn("grandparentValue");
                                                                    
                                                                            Method method = DOMNodePointer.class.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                                                                            method.setAccessible(true);
                                                                            String result = (String) method.invoke(null, node, "attrName");
                                                                            
                                                                            assertEquals("grandparentValue", result);
                                                                        }

    @Test
                                                                        public void testGetLanguageWhenNoLanguageAttribute() throws Exception {
                                                                            Node node = mock(Node.class);
                                                                            Element element = mock(Element.class);
                                                                            DOMNodePointer pointer = new DOMNodePointer(node, null);
                                                                            
                                                                            when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                            when(node.getParentNode()).thenReturn(null);
                                                                            when(element.getAttribute("xml:lang")).thenReturn("");
                                                                            when(node.getParentNode()).thenReturn(null);
                                                                            
                                                                            Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                            getLanguageMethod.setAccessible(true);
                                                                            String result = (String) getLanguageMethod.invoke(pointer);
                                                                            
                                                                            assertNull(result);
                                                                        }

    @Test
                                                                        public void testGetLanguageWhenCurrentNodeHasLanguage() throws Exception {
                                                                            Element element = mock(Element.class);
                                                                            when(element.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                            when(element.getAttribute("xml:lang")).thenReturn("en-US");
                                                                            DOMNodePointer pointer = new DOMNodePointer(element, null);
                                                                            
                                                                            Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                            getLanguageMethod.setAccessible(true);
                                                                            String result = (String) getLanguageMethod.invoke(pointer);
                                                                            
                                                                            assertEquals("en-US", result);
                                                                        }

    @Test
                                                                        public void testGetLanguageWhenParentNodeHasLanguage() throws Exception {
                                                                            Element element = mock(Element.class);
                                                                            when(element.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                            when(element.getAttribute("xml:lang")).thenReturn("");
                                                                            
                                                                            Element parentElement = mock(Element.class);
                                                                            when(parentElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                            when(parentElement.getAttribute("xml:lang")).thenReturn("fr-FR");
                                                                            when(element.getParentNode()).thenReturn(parentElement);
                                                                            when(parentElement.getParentNode()).thenReturn(null);
                                                                            
                                                                            DOMNodePointer pointer = new DOMNodePointer(element, null);
                                                                            
                                                                            Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                            getLanguageMethod.setAccessible(true);
                                                                            String result = (String) getLanguageMethod.invoke(pointer);
                                                                            
                                                                            assertEquals("fr-FR", result);
                                                                        }

    @Test
                                                                        public void testGetLanguageWhenGrandparentNodeHasLanguage() throws Exception {
                                                                            Element element = mock(Element.class);
                                                                            when(element.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                            when(element.getAttribute("xml:lang")).thenReturn("");
                                                                    
                                                                            Element parent = mock(Element.class);
                                                                            when(parent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                            when(parent.getAttribute("xml:lang")).thenReturn("");
                                                                    
                                                                            Element grandparent = mock(Element.class);
                                                                            when(grandparent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                            when(grandparent.getAttribute("xml:lang")).thenReturn("de-DE");
                                                                    
                                                                            when(element.getParentNode()).thenReturn(parent);
                                                                            when(parent.getParentNode()).thenReturn(grandparent);
                                                                            when(grandparent.getParentNode()).thenReturn(null);
                                                                    
                                                                            DOMNodePointer pointer = new DOMNodePointer(element, null);
                                                                            
                                                                            // Use reflection to access protected method
                                                                            Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                            getLanguageMethod.setAccessible(true);
                                                                            String result = (String) getLanguageMethod.invoke(pointer);
                                                                            
                                                                            assertEquals("de-DE", result);
                                                                        }

    @Test
                                                                        public void testGetLanguageWhenNonElementNode() throws Exception {
                                                                            Node textNode = mock(Node.class);
                                                                            when(textNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                            when(textNode.getParentNode()).thenReturn(null);
                                                                            
                                                                            DOMNodePointer pointer = new DOMNodePointer(textNode, null);
                                                                            
                                                                            // Use reflection to access protected method
                                                                            Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                            getLanguageMethod.setAccessible(true);
                                                                            String result = (String) getLanguageMethod.invoke(pointer);
                                                                            
                                                                            assertNull(result);
                                                                        }

    @Test
                                                                        public void testGetLanguageWhenParentChainHasMixedNodeTypes() throws Exception {
                                                                            Element element = mock(Element.class);
                                                                            when(element.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                            when(element.getAttribute("xml:lang")).thenReturn("");
                                                                            
                                                                            Node nonElementNode = mock(Node.class);
                                                                            when(nonElementNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                            
                                                                            Element parentElement = mock(Element.class);
                                                                            when(parentElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                            when(parentElement.getAttribute("xml:lang")).thenReturn("es-ES");
                                                                            
                                                                            when(element.getParentNode()).thenReturn(nonElementNode);
                                                                            when(nonElementNode.getParentNode()).thenReturn(parentElement);
                                                                            when(parentElement.getParentNode()).thenReturn(null);
                                                                            
                                                                            DOMNodePointer pointer = new DOMNodePointer(element, null);
                                                                            
                                                                            Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                            getLanguageMethod.setAccessible(true);
                                                                            String result = (String) getLanguageMethod.invoke(pointer);
                                                                            
                                                                            assertEquals("es-ES", result);
                                                                        }

    @Test
                                                                        public void testStringValueTextNodeWithValueAndNoTrim() throws Exception {
                                                                            // Create mock objects
                                                                            Node node = mock(Node.class);
                                                                            DOMNodePointer pointer = mock(DOMNodePointer.class, withSettings().defaultAnswer(CALLS_REAL_METHODS));
                                                                            
                                                                            // Setup reflection to access private method
                                                                            Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod("stringValue", Node.class);
                                                                            stringValueMethod.setAccessible(true);
                                                                            
                                                                            // Setup reflection to access protected method
                                                                            Method findEnclosingAttributeMethod = DOMNodePointer.class.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                                                                            findEnclosingAttributeMethod.setAccessible(true);
                                                                            
                                                                            // Stub method calls
                                                                            when(node.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                            when(node.getNodeValue()).thenReturn("  text  ");
                                                                            when(findEnclosingAttributeMethod.invoke(pointer, node, "xml:space")).thenReturn("preserve");
                                                                            
                                                                            // Call the method and verify result
                                                                            String result = (String) stringValueMethod.invoke(pointer, node);
                                                                            assertEquals("  text  ", result);
                                                                        }

    @Test
                                                                        public void testStringValueCDataNode() throws Exception {
                                                                            // Create mock objects
                                                                            Node node = mock(Node.class);
                                                                            DOMNodePointer pointer = mock(DOMNodePointer.class);
                                                                            
                                                                            // Get the private method via reflection
                                                                            Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod(
                                                                                "stringValue", Node.class);
                                                                            stringValueMethod.setAccessible(true);
                                                                            
                                                                            // Get the protected method via reflection
                                                                            Method findEnclosingAttributeMethod = DOMNodePointer.class.getDeclaredMethod(
                                                                                "findEnclosingAttribute", Node.class, String.class);
                                                                            findEnclosingAttributeMethod.setAccessible(true);
                                                                            
                                                                            // Setup mock behavior
                                                                            when(node.getNodeType()).thenReturn(Node.CDATA_SECTION_NODE);
                                                                            when(node.getNodeValue()).thenReturn("  cdata  ");
                                                                            when(findEnclosingAttributeMethod.invoke(pointer, node, "xml:space")).thenReturn(null);
                                                                            
                                                                            // Invoke and verify
                                                                            String result = (String) stringValueMethod.invoke(pointer, node);
                                                                            assertEquals("cdata", result);
                                                                        }

    @Test
                                                                        public void testStringValueWithEmptyChildNodes() throws Exception {
                                                                            // Create mock objects
                                                                            Node node = mock(Node.class);
                                                                            NodeList nodeList = mock(NodeList.class);
                                                                            NodePointer parent = mock(NodePointer.class);
                                                                            
                                                                            // Set up mock behavior
                                                                            when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                            when(node.getChildNodes()).thenReturn(nodeList);
                                                                            when(nodeList.getLength()).thenReturn(0);
                                                                            
                                                                            // Get the stringValue method via reflection
                                                                            Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod("stringValue", Node.class);
                                                                            stringValueMethod.setAccessible(true);
                                                                            
                                                                            // Create test instance with proper constructor
                                                                            DOMNodePointer pointer = new DOMNodePointer(parent, node);
                                                                            
                                                                            // Invoke and verify
                                                                            String result = (String) stringValueMethod.invoke(pointer, node);
                                                                            assertEquals("", result);
                                                                        }

    @Test
                                                                    public void testStringValueWithChildNodes() throws Exception {
                                                                        // Create mocks
                                                                        Node node = mock(Node.class);
                                                                        NodeList nodeList = mock(NodeList.class);
                                                                        Node textNode = mock(Node.class);
                                                                        Node commentNode = mock(Node.class);
                                                                        DOMNodePointer pointer = new DOMNodePointer((org.w3c.dom.Node) null, null);
                                                                        
                                                                        // Get private method via reflection
                                                                        Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod("stringValue", Node.class);
                                                                        stringValueMethod.setAccessible(true);
                                                                        
                                                                        // Setup mock behavior
                                                                        when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                        when(node.getChildNodes()).thenReturn(nodeList);
                                                                        when(nodeList.getLength()).thenReturn(2);
                                                                        when(nodeList.item(0)).thenReturn(textNode);
                                                                        when(nodeList.item(1)).thenReturn(commentNode);
                                                                        
                                                                        when(textNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                        when(textNode.getNodeValue()).thenReturn("text");
                                                                        
                                                                        when(commentNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                                        
                                                                        String result = (String) stringValueMethod.invoke(pointer, node);
                                                                        assertEquals("text", result);
                                                                    }

    @Test
                                                public void testIsLanguageWhenCurrentLanguageIsNull() {
                                                    Node mockNode = mock(Node.class);
                                                    NodePointer parentPointer = mock(NodePointer.class);
                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
                                                    
                                                    when(mockNode.getParentNode()).thenReturn(null);
                                                    
                                                    // Test when current language is null and super returns true
                                                    when(parentPointer.isLanguage("en")).thenReturn(true);
                                                    assertTrue(pointer.isLanguage("en"));
                                                    
                                                    // Test when current language is null and super returns false
                                                    when(parentPointer.isLanguage("fr")).thenReturn(false);
                                                    assertFalse(pointer.isLanguage("fr"));
                                                }

    @Test
                                                public void testStringValueTextNodeWithNullValue() throws Exception {
                                                    // Create mock objects
                                                    Node node = mock(Node.class);
                                                    DOMNodePointer pointer = new DOMNodePointer(null, null, null) {
                                                        public Node findEnclosingAttribute(Node n) {
                                                            return null;
                                                        }
                                                        
                                                        @Override
                                                        public boolean isAttribute() {
                                                            return false;
                                                        }
                                                        
                                                        @Override
                                                        public String getNamespaceURI() {
                                                            return null;
                                                        }
                                                    };
                                                    
                                                    // Get the private method using reflection
                                                    Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod("stringValue", Node.class);
                                                    stringValueMethod.setAccessible(true);
                                                    
                                                    // Set up mock behavior
                                                    when(node.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                    when(node.getNodeValue()).thenReturn(null);
                                                    
                                                    // Invoke the method and verify result
                                                    String result = (String) stringValueMethod.invoke(pointer, node);
                                                    assertEquals("", result);
                                                }

    @Test
                                                public void testStringValueProcessingInstructionWithNullData() throws Exception {
                                                    // Setup
                                                    Node node = mock(Node.class);
                                                    DOMNodePointer pointer = new DOMNodePointer(null, null, null) {
                                                        public Node findEnclosingAttribute(Node n) {
                                                            return null;
                                                        }
                                                        
                                                        @Override
                                                        public boolean isAttribute() {
                                                            return false;
                                                        }
                                                        
                                                        @Override
                                                        public String getNamespaceURI() {
                                                            return null;
                                                        }
                                                    };
                                                    
                                                    Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod(
                                                        "stringValue", Node.class);
                                                    stringValueMethod.setAccessible(true);
                                                    
                                                    when(node.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                    when(node.getNodeValue()).thenReturn(null);
                                                    
                                                    // Test
                                                    String result = (String) stringValueMethod.invoke(pointer, node);
                                                    
                                                    // Verify
                                                    assertEquals("", result);
                                                }

    @Test
                                            public void testGetValueWithTextNode() {
                                                // Define Node.TEXT_NODE constant since it's not available
                                                short TEXT_NODE = 3;
                                                
                                                // Create mock Node
                                                Node textNode = mock(Node.class);
                                                when(textNode.getNodeType()).thenReturn(TEXT_NODE);
                                                when(textNode.getNodeValue()).thenReturn("  text value  ");
                                                
                                                DOMNodePointer textPointer = new DOMNodePointer(textNode, null);
                                                assertEquals("text value", textPointer.getValue());
                                            }

    @Test
                                            public void testGetValueWithCDATASectionNode() {
                                                final short CDATA_SECTION_NODE = 4; // Defined according to org.w3c.dom.Node
                                                Node cdataNode = mock(Node.class);
                                                
                                                when(cdataNode.getNodeType()).thenReturn(CDATA_SECTION_NODE);
                                                when(cdataNode.getNodeValue()).thenReturn("  cdata value  ");
                                                
                                                DOMNodePointer cdataPointer = new DOMNodePointer(cdataNode, null);
                                                assertEquals("cdata value", cdataPointer.getValue());
                                            }

    @Test
                                            public void testGetValueWithElementNode() {
                                                short ELEMENT_NODE = 1;
                                                short TEXT_NODE = 3;
                                                
                                                Node elementNode = mock(Node.class);
                                                Node childText = mock(Node.class);  // Added missing mock
                                                
                                                when(elementNode.getNodeType()).thenReturn(ELEMENT_NODE);
                                                when(childText.getNodeType()).thenReturn(TEXT_NODE);  // Added node type
                                                when(childText.getNodeValue()).thenReturn("child text");
                                                
                                                NodeList nodeList = mock(NodeList.class);
                                                when(nodeList.getLength()).thenReturn(1);
                                                when(nodeList.item(0)).thenReturn(childText);
                                                
                                                when(elementNode.getChildNodes()).thenReturn(nodeList);
                                                
                                                DOMNodePointer elementPointer = new DOMNodePointer(elementNode, null);
                                                assertEquals("child text", elementPointer.getValue());
                                            }

    @Test
                                            public void testGetValueWithPreserveSpace() throws Exception {
                                                Node elementNode = mock(Node.class);
                                                Node childText = mock(Node.class);  // Added missing mock
                                                when(elementNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                
                                                when(childText.getNodeValue()).thenReturn("  preserved space  ");
                                                
                                                NodeList nodeList = mock(NodeList.class);
                                                when(nodeList.getLength()).thenReturn(1);
                                                when(nodeList.item(0)).thenReturn(childText);
                                                
                                                when(elementNode.getChildNodes()).thenReturn(nodeList);
                                                
                                                DOMNodePointer pointer = new DOMNodePointer(elementNode, null);
                                                DOMNodePointer spyPointer = spy(pointer);
                                                
                                                // Use reflection to access the protected method
                                                Method findEnclosingAttributeMethod = DOMNodePointer.class
                                                    .getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                                                findEnclosingAttributeMethod.setAccessible(true);
                                                when(findEnclosingAttributeMethod.invoke(spyPointer, any(Node.class), eq("xml:space")))
                                                    .thenReturn("preserve");
                                                
                                                assertEquals("  preserved space  ", spyPointer.getValue());
                                            }

    @Test
                                            public void testStringValueProcessingInstructionWithDataAndTrim() throws Exception {
                                                // Create mock objects
                                                Node node = mock(Node.class);
                                                ProcessingInstruction piNode = mock(ProcessingInstruction.class);
                                                DOMNodePointer pointer = new DOMNodePointer(null, null, null) {
                                                    @Override
                                                    public Node getNode() {
                                                        return null;
                                                    }
                                                };
                                                
                                                // Setup reflection to access private method
                                                Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod("stringValue", Node.class);
                                                stringValueMethod.setAccessible(true);
                                                
                                                // Mock behavior
                                                when(node.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                when(node.getNodeValue()).thenReturn("  pi data  ");
                                                
                                                // Call method and verify
                                                String result = (String) stringValueMethod.invoke(pointer, node);
                                                assertEquals("pi data", result);
                                            }

    @Test
                                            public void testStringValueProcessingInstructionWithDataAndNoTrim() throws Exception {
                                                // Create mock objects
                                                Node node = mock(Node.class);
                                                
                                                // Create anonymous subclass of DOMNodePointer with proper constructor
                                                DOMNodePointer pointer = new DOMNodePointer(null, null, null) {
                                                    @Override
                                                    public String getNamespaceURI() {
                                                        return "preserve";
                                                    }
                                                };
                                                
                                                // Setup method to test via reflection
                                                Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod(
                                                    "stringValue", Node.class);
                                                stringValueMethod.setAccessible(true);
                                                
                                                // Setup mock behavior
                                                when(node.getNodeType()).thenReturn((short) Node.PROCESSING_INSTRUCTION_NODE);
                                                when(node.getNodeValue()).thenReturn("  pi data  ");
                                                
                                                String result = (String) stringValueMethod.invoke(pointer, node);
                                                assertEquals("  pi data  ", result);
                                            }

    @Test
        public void testGetImmediateNodeWithNullNode() {
            // Create DOMNodePointer with null node
            Node node = null;
            String name = null;
            DOMNodePointer parentPointer = null;
            
            // Verify getImmediateNode returns null
        }

    @Test
        public void testAsPathWithId() throws Exception {
            
        }

    @Test
        public void testAsPathElementNodeWithDefaultNamespace() throws Exception {
            Node node = mock(Node.class);
            NodePointer parentPointer = mock(NodePointer.class);
            // Get the setNamespaceResolver field via reflection
            Field setNamespaceResolverField = DOMNodePointer.class.getDeclaredField("namespaceResolver");
            setNamespaceResolverField.setAccessible(true);
            
            when(node.getNodeType()).thenReturn((short) 1); // Node.ELEMENT_NODE
            when(parentPointer.asPath()).thenReturn("/parent");
            
            DOMNodePointer pointer = new DOMNodePointer(parentPointer, node);
            
            // Use reflection to set private field
            
            Method getLocalName = DOMNodePointer.class.getDeclaredMethod("getLocalName", Node.class);
            getLocalName.setAccessible(true);
            getLocalName.invoke(pointer, node);
            
            when(node.getNodeName()).thenReturn("testElement");
            
            Method getRelativePositionByName = DOMNodePointer.class.getDeclaredMethod("getRelativePositionByName");
            getRelativePositionByName.setAccessible(true);
            when(getRelativePositionByName.invoke(pointer)).thenReturn(1);
            
            assertEquals("/parent/testElement[1]", pointer.asPath());
        }

    @Test
        public void testAsPathElementNodeWithPrefix() throws Exception {
            // Mock objects
            Node node = mock(Node.class);
            NodePointer parentPointer = mock(NodePointer.class);
            // Stubbing
            when(node.getNodeType()).thenReturn((short) 1); // Node.ELEMENT_NODE = 1
            when(parentPointer.asPath()).thenReturn("/parent");
            
            // Create test object
            DOMNodePointer pointer = new DOMNodePointer(parentPointer, node);
            
            // Set private field using reflection
            Field field = DOMNodePointer.class.getDeclaredField("namespaceResolver");
            field.setAccessible(true);
            
            // Mock private methods
            Method getNamespaceURI = DOMNodePointer.class.getDeclaredMethod("getNamespaceURI");
            getNamespaceURI.setAccessible(true);
            when(getNamespaceURI.invoke(pointer)).thenReturn("testURI");
            
            Method getLocalName = DOMNodePointer.class.getDeclaredMethod("getLocalName", Node.class);
            getLocalName.setAccessible(true);
            when(getLocalName.invoke(pointer, node)).thenReturn("testElement");
            
            when(node.getNodeName()).thenReturn("testElement");
            
            Method getRelativePositionByName = DOMNodePointer.class.getDeclaredMethod("getRelativePositionByName");
            getRelativePositionByName.setAccessible(true);
            when(getRelativePositionByName.invoke(pointer)).thenReturn(2);
            
            // Assert
            assertEquals("/parent/testPrefix:testElement[2]", pointer.asPath());
        }

    @Test
        public void testAsPathElementNodeWithoutPrefix() throws Exception {
            // Define constants that might be missing
            final short ELEMENT_NODE = 1;
            
            // Create mocks
            Node node = mock(Node.class);
            NodePointer parentPointer = mock(NodePointer.class);
            // Set up mock behavior
            when(node.getNodeType()).thenReturn(ELEMENT_NODE);
            when(parentPointer.asPath()).thenReturn("/parent");
            
            // Create test instance
            Object pointer = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(parentPointer, node);
            
            // Use reflection to set private field
            Field namespaceResolverField = pointer.getClass().getDeclaredField("namespaceResolver");
            namespaceResolverField.setAccessible(true);
            
            // Mock private methods
            Method getNamespaceURI = pointer.getClass().getDeclaredMethod("getNamespaceURI");
            getNamespaceURI.setAccessible(true);
            when(getNamespaceURI.invoke(pointer)).thenReturn("testURI");
            
            Method getRelativePositionOfElement = pointer.getClass().getDeclaredMethod("getRelativePositionOfElement");
            getRelativePositionOfElement.setAccessible(true);
            when(getRelativePositionOfElement.invoke(pointer)).thenReturn(3);
            
            // Test
            Method asPath = pointer.getClass().getMethod("asPath");
            String result = (String) asPath.invoke(pointer);
            assertEquals("/parent/node()[3]", result);
        }

    @Test
        public void testStringValueCommentNode() throws Exception {
            // Setup
            Node node = mock(Node.class);
            
            // Get private method via reflection
            Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod(
                "stringValue", Node.class);
            stringValueMethod.setAccessible(true);
            
            // Test
            when(node.getNodeType()).thenReturn((short) 8); // Node.COMMENT_NODE
            when(node.getNodeValue()).thenReturn("");
            
            // Verify
        }

    @Test
        public void testStringValueTextNodeWithValueAndTrim() throws Exception {
            // Create mocks
            Node node = mock(Node.class);
            DOMNodePointer pointer = new DOMNodePointer(null, null, null) {
                @Override
                public Node getNode() {
                    return null;
                }
                
                @Override
                public boolean isLeaf() {
                    return true;
                }
                
                @Override
                public NodePointer getParent() {
                    return null;
                }
                
                public NodePointer createAttributePointer(QName name) {
                    return new DOMNodePointer(this, null) {
                        @Override
                        public Node getNode() {
                            return null;
                        }
                    };
                }
                
                public NodePointer createChild(NodePointer parent, QName name, int index) {
                    return new DOMNodePointer(parent, null) {
                        @Override
                        public Node getNode() {
                            return null;
                        }
                    };
                }
                
                public NodePointer createAttribute(NodePointer parent, QName name) {
                    return new DOMNodePointer(parent, null) {
                        @Override
                        public Node getNode() {
                            return null;
                        }
                    };
                }
            };
            
            // Get the private method via reflection
            Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod("stringValue", Node.class);
            stringValueMethod.setAccessible(true);
            
            // Setup mock behavior
            when(node.getNodeType()).thenReturn((short) 3); // Node.TEXT_NODE
            when(node.getNodeValue()).thenReturn("  text  ");
            
            // Invoke and verify
            String result = (String) stringValueMethod.invoke(pointer, node);
            assertEquals("text", result);
        }


}
