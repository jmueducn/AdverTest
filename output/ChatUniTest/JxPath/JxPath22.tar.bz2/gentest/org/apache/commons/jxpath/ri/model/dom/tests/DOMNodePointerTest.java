package gentest.org.apache.commons.jxpath.ri.model.dom.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.model.dom.*;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.apache.commons.jxpath.JXPathAbstractFactoryException;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.JXPathException;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.NamespaceResolver;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import org.apache.commons.jxpath.ri.compiler.ProcessingInstructionTest;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.apache.commons.jxpath.ri.model.beans.NullPointer;
import org.apache.commons.jxpath.util.TypeUtils;
import org.w3c.dom.Attr;
import org.w3c.dom.Comment;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.ProcessingInstruction;
 
public class DOMNodePointerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                public void testGetNamespaceURI_ElementWithEmptyNamespaceURI() {
                                                    Node mockNode = mock(Node.class);
                                                    Element mockElement = mock(Element.class);
                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                    
                                                    when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                    when(mockElement.getNamespaceURI()).thenReturn("");
                                                    when(mockNode.getParentNode()).thenReturn(mockElement);
                                                    
                                                    String result = pointer.getNamespaceURI();
                                                    assertNull(result);
                                                }

    @Test
                                                public void testGetNamespaceURI_DocumentNode() {
                                                    Node mockNode = mock(Node.class);
                                                    Document mockDocument = mock(Document.class);
                                                    Element mockElement = mock(Element.class);
                                                    
                                                    when(mockNode.getNodeType()).thenReturn(Node.DOCUMENT_NODE);
                                                    when(mockDocument.getDocumentElement()).thenReturn(mockElement);
                                                    when(mockElement.getNamespaceURI()).thenReturn("http://example.com/ns");
                                                    
                                                    DOMNodePointer docPointer = new DOMNodePointer(mockDocument, null);
                                                    String result = docPointer.getNamespaceURI();
                                                    assertEquals("http://example.com/ns", result);
                                                }

    @Test
                                                public void testGetNamespaceURI_ElementWithNoNamespace() {
                                                    Node mockNode = mock(Node.class);
                                                    Element mockElement = mock(Element.class);
                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                    
                                                    when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                    when(mockElement.getNamespaceURI()).thenReturn(null);
                                                    when(mockNode.getParentNode()).thenReturn(mockElement);
                                                    when(mockNode.getPrefix()).thenReturn(null);
                                                    
                                                    String result = pointer.getNamespaceURI();
                                                    assertNull(result);
                                                }

    @Test
                                                public void testGetNamespaceURI_ElementWithPrefixButNoNamespace() {
                                                    // Create mocks
                                                    Node mockNode = mock(Node.class);
                                                    Element mockElement = mock(Element.class);
                                                    Attr mockAttr = mock(Attr.class);
                                                    
                                                    // Create pointer with mock node
                                                    NodePointer parentPointer = mock(NodePointer.class);
                                                    DOMNodePointer pointer = new DOMNodePointer(parentPointer, mockNode);
                                                    
                                                    // Setup mock behavior
                                                    when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                    when(mockElement.getNamespaceURI()).thenReturn(null);
                                                    when(mockNode.getParentNode()).thenReturn(mockElement);
                                                    when(mockNode.getPrefix()).thenReturn("test");
                                                    when(mockElement.getAttributeNode("xmlns:test")).thenReturn(null);
                                                    
                                                    String result = pointer.getNamespaceURI();
                                                    assertNull(result);
                                                }

    @Test
                                                public void testGetNamespaceURI_NonElementNode() {
                                                    Node mockNode = mock(Node.class);
                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                    
                                                    when(mockNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                    
                                                    String result = pointer.getNamespaceURI();
                                                    assertNull(result);
                                                }

    @Test
                                                public void testGetNamespaceURI_FromDocumentElement() {
                                                    Document mockDocument = mock(Document.class);
                                                    Element mockElement = mock(Element.class);
                                                    Attr mockAttr = mock(Attr.class);
                                                    
                                                    when(mockDocument.getDocumentElement()).thenReturn(mockElement);
                                                    DOMNodePointer pointer = new DOMNodePointer(mockDocument, null);
                                                    
                                                    when(mockElement.getAttributeNode("xmlns:test")).thenReturn(mockAttr);
                                                    when(mockAttr.getValue()).thenReturn("http://test.com");
                                                    
                                                    assertEquals("http://test.com", pointer.getNamespaceURI("test"));
                                                }

    @Test
                                                public void testGetNamespaceURI_UnknownNamespace() {
                                                    Node mockNode = mock(Node.class);
                                                    when(mockNode.getParentNode()).thenReturn(null);
                                                    
                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                    assertNull(pointer.getNamespaceURI("unknown"));
                                                }

    @Test
                                                public void testGetNamespaceURIWithDocumentNode() {
                                                    Document document = mock(Document.class);
                                                    Element element = mock(Element.class);
                                                    
                                                    when(document.getDocumentElement()).thenReturn(element);
                                                    when(element.getNamespaceURI()).thenReturn("http://example.com/ns");
                                            
                                                    String result = DOMNodePointer.getNamespaceURI(document);
                                                    assertEquals("http://example.com/ns", result);
                                                }

    @Test
                                                public void testGetNamespaceURIWithElementHavingNamespaceURI() {
                                                    Node node = mock(Node.class);
                                                    Element element = mock(Element.class);
                                                    
                                                    when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                    when(node.getParentNode()).thenReturn(null);
                                                    when(element.getNamespaceURI()).thenReturn("http://example.com/ns");
                                                    
                                                    // Mock the cast from Node to Element
                                                    when(((Element) node)).thenReturn(element);
                                                    
                                                    String result = DOMNodePointer.getNamespaceURI(node);
                                                    assertEquals("http://example.com/ns", result);
                                                }

    @Test
                                                public void testGetNamespaceURIWithElementNoNamespaceURIButPrefix() {
                                                    // Create mocks
                                                    Node node = mock(Node.class);
                                                    Node parentNode = mock(Node.class);
                                                    Attr attr = mock(Attr.class);
                                            
                                                    // Setup mock behavior
                                                    when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                    when(((Element) node).getNamespaceURI()).thenReturn(null);
                                                    when(node.getPrefix()).thenReturn("test");
                                                    when(node.getNodeName()).thenReturn("test:element");
                                            
                                                    // Mock parent node traversal
                                                    when(node.getParentNode()).thenReturn(parentNode);
                                                    when(parentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                    when(((Element) parentNode).getAttributeNode("xmlns:test")).thenReturn(attr);
                                                    when(attr.getValue()).thenReturn("http://example.com/test");
                                            
                                                    String result = DOMNodePointer.getNamespaceURI(node);
                                                    assertEquals("http://example.com/test", result);
                                                }

    @Test
                                                public void testGetNamespaceURIWithElementNoNamespaceURINoPrefix() {
                                                    Node node = mock(Node.class);
                                                    Node parentNode = mock(Node.class);
                                                    Attr attr = mock(Attr.class);
                                            
                                                    when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                    when(((Element) node).getNamespaceURI()).thenReturn(null);
                                                    when(node.getPrefix()).thenReturn(null);
                                                    when(node.getNodeName()).thenReturn("element");
                                                    
                                                    // Mock parent node traversal
                                                    when(node.getParentNode()).thenReturn(parentNode);
                                                    when(parentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                    when(((Element) parentNode).getAttributeNode("xmlns")).thenReturn(attr);
                                                    when(attr.getValue()).thenReturn("http://example.com/default");
                                            
                                                    String result = DOMNodePointer.getNamespaceURI(node);
                                                    assertEquals("http://example.com/default", result);
                                                }

    @Test
                                            public void testGetNamespaceURIWithEmptyStringURI() {
                                                Node node = mock(Node.class);
                                                Element element = mock(Element.class);
                                                
                                                when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                when(node instanceof Element).thenReturn(true);
                                                when(element.getNamespaceURI()).thenReturn("");
                                                
                                                String result = DOMNodePointer.getNamespaceURI(node);
                                                assertNull(result);
                                            }

    @Test
                                            public void testGetNamespaceURIWithNoNamespaceFound() {
                                                Node node = mock(Node.class);
                                                Element element = mock(Element.class);
                                                when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                when(element.getNamespaceURI()).thenReturn(null);
                                                when(node.getPrefix()).thenReturn(null);
                                                when(node.getNodeName()).thenReturn("element");
                                                when(node.getParentNode()).thenReturn(null);
                                                
                                                String result = DOMNodePointer.getNamespaceURI(node);
                                                assertNull(result);
                                            }

    @Test
                                            public void testGetNamespaceURIWithPrefixButNoNamespaceDeclaration() {
                                                Node node = mock(Node.class);
                                                Element element = mock(Element.class);
                                                when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                when(((Element) node).getNamespaceURI()).thenReturn(null);
                                                when(node.getPrefix()).thenReturn("test");
                                                when(node.getNodeName()).thenReturn("test:element");
                                                when(node.getParentNode()).thenReturn(null);
                                        
                                                String result = DOMNodePointer.getNamespaceURI(node);
                                                assertNull(result);
                                            }

    @Test
                                            public void testGetNamespaceURIWithEmptyNamespaceDeclaration() {
                                                // Create mocks
                                                Node node = mock(Node.class);
                                                Node parentNode = mock(Node.class);
                                                Attr attr = mock(Attr.class);
                                                
                                                // Setup mock behavior
                                                when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                when(((Element) node).getNamespaceURI()).thenReturn(null);
                                                when(node.getPrefix()).thenReturn("test");
                                                when(node.getNodeName()).thenReturn("test:element");
                                        
                                                // Mock parent node traversal
                                                when(node.getParentNode()).thenReturn(parentNode);
                                                when(parentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                when(((Element) parentNode).getAttributeNode("xmlns:test")).thenReturn(attr);
                                                when(attr.getValue()).thenReturn("");
                                        
                                                // Call the method under test
                                                String result = DOMNodePointer.getNamespaceURI(node);
                                                
                                                // Verify
                                                assertNull(result);
                                            }

    @Test
                                            public void testGetValueWithCommentNodeAndNullData() {
                                                Comment commentNode = mock(Comment.class);
                                                when(commentNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                when(commentNode.getData()).thenReturn(null);
                                                
                                                DOMNodePointer pointer = new DOMNodePointer(commentNode, Locale.ENGLISH);
                                                assertEquals("", pointer.getValue());
                                            }

    @Test
                                            public void testGetValueWithCommentNodeAndEmptyData() {
                                                Comment commentNode = mock(Comment.class);
                                                when(commentNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                when(commentNode.getData()).thenReturn("");
                                                
                                                DOMNodePointer pointer = new DOMNodePointer(commentNode, Locale.ENGLISH);
                                                assertEquals("", pointer.getValue());
                                            }

    @Test
                                            public void testGetValueWithCommentNodeAndData() {
                                                Comment commentNode = mock(Comment.class);
                                                when(commentNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                when(commentNode.getData()).thenReturn("  some comment  ");
                                                
                                                DOMNodePointer pointer = new DOMNodePointer(commentNode, Locale.ENGLISH);
                                                assertEquals("some comment", pointer.getValue());
                                            }

    @Test
                                            public void testGetValueWithTextNode() {
                                                Node textNode = mock(Node.class);
                                                Element elementNode = mock(Element.class);
                                                
                                                when(textNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                when(textNode.getNodeValue()).thenReturn("  some text  ");
                                                when(textNode.getParentNode()).thenReturn(elementNode);
                                                when(elementNode.getAttribute("xml:space")).thenReturn(null);
                                                
                                                DOMNodePointer pointer = new DOMNodePointer(textNode, Locale.ENGLISH);
                                                assertEquals("some text", pointer.getValue());
                                            }

    @Test
                                            public void testGetValueWithTextNodeAndPreserveSpace() {
                                                Node textNode = mock(Node.class);
                                                Element elementNode = mock(Element.class);
                                                
                                                when(textNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                when(textNode.getNodeValue()).thenReturn("  some text  ");
                                                when(textNode.getParentNode()).thenReturn(elementNode);
                                                when(elementNode.getAttribute("xml:space")).thenReturn("preserve");
                                                
                                                DOMNodePointer pointer = new DOMNodePointer(textNode, java.util.Locale.ENGLISH);
                                                assertEquals("  some text  ", pointer.getValue());
                                            }

    @Test
                                            public void testGetValueWithCDATANode() {
                                                Node cdataNode = mock(Node.class);
                                                Element elementNode = mock(Element.class);
                                                
                                                when(cdataNode.getNodeType()).thenReturn(Node.CDATA_SECTION_NODE);
                                                when(cdataNode.getNodeValue()).thenReturn("  some cdata  ");
                                                when(cdataNode.getParentNode()).thenReturn(elementNode);
                                                when(elementNode.getAttribute("xml:space")).thenReturn(null);
                                                
                                                DOMNodePointer pointer = new DOMNodePointer(cdataNode, java.util.Locale.ENGLISH);
                                                assertEquals("some cdata", pointer.getValue());
                                            }

    @Test
                                            public void testGetValueWithProcessingInstructionNode() {
                                                Node piNode = mock(Node.class);
                                                Element elementNode = mock(Element.class);
                                                
                                                when(piNode.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                when(piNode.getNodeValue()).thenReturn("  some data  ");
                                                when(piNode.getParentNode()).thenReturn(elementNode);
                                                when(elementNode.getAttribute("xml:space")).thenReturn(null);
                                                
                                                DOMNodePointer pointer = new DOMNodePointer(piNode, java.util.Locale.ENGLISH);
                                                assertEquals("some data", pointer.getValue());
                                            }

    @Test
                                            public void testGetValueWithEmptyElementNode() {
                                                Node elementNode = mock(Node.class);
                                                NodeList nodeList = mock(NodeList.class);
                                                
                                                when(elementNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                when(elementNode.getChildNodes()).thenReturn(nodeList);
                                                when(nodeList.getLength()).thenReturn(0);
                                                
                                                DOMNodePointer pointer = new DOMNodePointer(elementNode, Locale.ENGLISH);
                                                assertEquals("", pointer.getValue());
                                            }

    @Test
                                            public void testGetNamespaceURI_ElementWithNamespaceURI() {
                                                // Create mocks
                                                Node mockNode = mock(Node.class);
                                                Element mockElement = mock(Element.class);
                                                
                                                // Create DOMNodePointer instance with proper constructor
                                                DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                
                                                // Setup mock behavior
                                                when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                when(mockElement.getNamespaceURI()).thenReturn("http://example.com/ns");
                                                when(mockNode.getParentNode()).thenReturn(mockElement);
                                                
                                                // Test
                                                String result = pointer.getNamespaceURI();
                                                assertEquals("http://example.com/ns", result);
                                            }

    @Test
                                            public void testGetNamespaceURI_NullOrEmptyPrefix() throws Exception {
                                                // Setup
                                                Node mockNode = mock(Node.class);
                                                HashMap<String, String> namespaces = new HashMap<>();
                                                DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                
                                                // Use reflection to set private field
                                                java.lang.reflect.Field namespacesField = DOMNodePointer.class.getDeclaredField("namespaces");
                                                namespacesField.setAccessible(true);
                                                namespacesField.set(pointer, namespaces);
                                            
                                                // Test
                                                assertNull(pointer.getNamespaceURI((String)null));
                                                assertNull(pointer.getNamespaceURI(""));
                                            }

    @Test
                                        public void testGetNamespaceURI_XmlnsPrefix() {
                                            DOMNodePointer pointer = new DOMNodePointer(null, null, null) {
                                                @Override
                                                public String getDefaultNamespaceURI() {
                                                    return null;
                                                }
                                            };
                                            assertEquals("http://www.w3.org/2000/xmlns/", pointer.getNamespaceURI("xmlns"));
                                        }

    @Test
                                        public void testGetNamespaceURI_FromNamespacesMap() throws Exception {
                                            // Create mock document and element
                                            Document document = mock(Document.class);
                                            Element element = mock(Element.class);
                                            when(document.getDocumentElement()).thenReturn(element);
                                            
                                            // Create pointer instance
                                            DOMNodePointer pointer = new DOMNodePointer(null, document);
                                            
                                            // Set up namespaces map
                                            Map<String, String> namespaces = new HashMap<>();
                                            namespaces.put("test", "http://test.com");
                                            
                                            // Set namespaces field using reflection
                                            Field namespacesField = DOMNodePointer.class.getDeclaredField("namespaces");
                                            namespacesField.setAccessible(true);
                                            namespacesField.set(pointer, namespaces);
                                            
                                            // Test the method
                                            assertEquals("http://test.com", pointer.getNamespaceURI("test"));
                                        }

    @Test
                                        public void testGetNamespaceURI_CachesResult() {
                                            // Create mocks
                                            Node mockNode = mock(Node.class);
                                            Element mockElement = mock(Element.class);
                                            Attr mockAttr = mock(Attr.class);
                                            
                                            // Create pointer instance
                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                            
                                            // Setup mock behavior
                                            when(mockNode.getParentNode()).thenReturn(mockElement);
                                            when(mockElement.getAttributeNode("xmlns:test")).thenReturn(mockAttr);
                                            when(mockAttr.getValue()).thenReturn("http://test.com");
                                            
                                            // First call - should get from attribute
                                            assertEquals("http://test.com", pointer.getNamespaceURI("test"));
                                            
                                            // Second call - should get from cache
                                            when(mockElement.getAttributeNode("xmlns:test")).thenReturn(null);
                                            assertEquals("http://test.com", pointer.getNamespaceURI("test"));
                                        }

    @Test
                public void testGetNamespaceURI_XmlPrefix() {
                    // Create mock objects
                    Node mockNode = mock(Node.class);
                    HashMap<String, String> namespaces = new HashMap<>();
                    
                    // Create test instance
                    DOMNodePointer pointer = new DOMNodePointer(mockNode, null, (String)null) {
                        @Override
                        public String getDefaultNamespaceURI() {
                            return null;
                        }
                        
                        @Override
                        public String getNamespaceURI(String prefix) {
                            if ("xml".equals(prefix)) {
                                return "http://www.w3.org/XML/1998/namespace";
                            }
                            return null;
                        }
                    };
                    
                    // Set XML_NAMESPACE_URI through reflection if needed
                    try {
                        java.lang.reflect.Field field = DOMNodePointer.class.getDeclaredField("XML_NAMESPACE_URI");
                        field.setAccessible(true);
                        field.set(null, "http://www.w3.org/XML/1998/namespace");
                    } catch (Exception e) {
                        fail("Failed to set XML_NAMESPACE_URI");
                    }
                    
                    assertEquals("http://www.w3.org/XML/1998/namespace", pointer.getNamespaceURI("xml"));
                }

    @Test
            public void testGetValueWithElementNode() {
                // Define Node constants since they're not imported
                final short ELEMENT_NODE = 1;
                final short TEXT_NODE = 3;
                
                Node elementNode = mock(Node.class);
                NodeList nodeList = mock(NodeList.class);
                
                when(elementNode.getNodeType()).thenReturn(ELEMENT_NODE);
                when(elementNode.getChildNodes()).thenReturn(nodeList);
                when(nodeList.getLength()).thenReturn(2);
                
                Node child1 = mock(Node.class);
                Node child2 = mock(Node.class);
                
                when(nodeList.item(0)).thenReturn(child1);
                when(nodeList.item(1)).thenReturn(child2);
                
                when(child1.getNodeType()).thenReturn(TEXT_NODE);
                when(child1.getNodeValue()).thenReturn("text1");
                when(child1.getParentNode()).thenReturn(elementNode);
                
                when(child2.getNodeType()).thenReturn(TEXT_NODE);
                when(child2.getNodeValue()).thenReturn("text2");
                when(child2.getParentNode()).thenReturn(elementNode);
                
                
                DOMNodePointer pointer = new DOMNodePointer(elementNode, Locale.ENGLISH);
                assertEquals("text1text2", pointer.getValue());
            }

    @Test
        public void testGetNamespaceURI_FromAttribute() {
            // Create mocks
            Node mockNode = mock(Node.class);
            Element mockElement = mock(Element.class);
            Attr mockAttr = mock(Attr.class);
            
            // Create DOMNodePointer instance
            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
            
            // Set up mock behavior
            when(mockNode.getParentNode()).thenReturn(mockElement);
            when(mockElement.getAttributeNode("xmlns:test")).thenReturn(mockAttr);
            when(mockAttr.getValue()).thenReturn("http://test.com");
            
            // Test the method
            assertEquals("http://test.com", pointer.getNamespaceURI("test"));
        }

    @Test
        public void testGetNamespaceURI_EmptyNamespace() {
            // Create mocks
            Node mockNode = mock(Node.class);
            Element mockElement = mock(Element.class);
            Attr mockAttr = mock(Attr.class);
            
            // Create DOMNodePointer instance
            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
            
            // Set up mock behavior
            when(mockNode.getParentNode()).thenReturn(mockElement);
            when(mockElement.getAttributeNode("xmlns:test")).thenReturn(mockAttr);
            when(mockAttr.getValue()).thenReturn("");
            
            // Test
            assertNull(pointer.getNamespaceURI("test"));
        }

    @Test
        public void testGetNamespaceURI_ElementWithNullNamespaceURI() {
            // Create mocks
            Node mockNode = mock(Node.class);
            Element mockElement = mock(Element.class);
            Attr mockAttr = mock(Attr.class);
            Node mockParent = mock(Node.class);
            
            // Create DOMNodePointer instance with proper constructor
            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
            
            // Setup mock behavior
            when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
            when(mockElement.getNamespaceURI()).thenReturn(null);
            when(mockNode.getParentNode()).thenReturn(mockElement);
            when(mockNode.getPrefix()).thenReturn("test");
            when(mockElement.getAttributeNode("xmlns:test")).thenReturn(mockAttr);
            when(mockAttr.getValue()).thenReturn("http://example.com/ns");
            
            // Test
            String result = pointer.getNamespaceURI();
            assertEquals("http://example.com/ns", result);
        }


}
