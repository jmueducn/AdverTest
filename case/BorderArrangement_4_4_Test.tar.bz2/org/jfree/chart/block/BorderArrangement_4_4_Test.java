package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_4_4_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    

    

    

    

    @Test
    public void testArrangeFF_NoBlocks() {
        RectangleConstraint constraint = new RectangleConstraint(300.0, 250.0);
        
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertEquals(300.0, result.getWidth(), 0.001);
        assertEquals(250.0, result.getHeight(), 0.001);
    }

    

    

    
}