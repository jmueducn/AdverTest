package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_7_4_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_OnlyRightBlock() {
        Block rightBlock = mock(Block.class);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);

        // Mock the arrangement of the right block
        RectangleConstraint expectedConstraint = new RectangleConstraint(0.0,
                new Range(0.0, 180.0 - 0.0), // constraint.getWidth() - w[2] = 180.0 - 0.0
                LengthConstraintType.RANGE, 180.0, null, LengthConstraintType.FIXED);
        
        when(rightBlock.arrange(g2, expectedConstraint))
                .thenReturn(new Size2D(35.0, 180.0));

        RectangleConstraint constraint = new RectangleConstraint(180.0, 180.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);

        // Verify the result
        assertEquals(180.0, result.getWidth(), 0.001);
        assertEquals(180.0, result.getHeight(), 0.001);

        // Verify that setBounds was called on the right block with correct parameters
        // w[2] + w[4] = 0.0 + (180.0 - 35.0 - 0.0) = 145.0, h[0] = 0.0
        verify(rightBlock).setBounds(new Rectangle2D.Double(145.0, 0.0, 35.0, 180.0));
    }
}