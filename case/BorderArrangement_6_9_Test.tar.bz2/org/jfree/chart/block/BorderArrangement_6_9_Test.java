package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_6_9_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_LeftBlockExceedsWidth() {
        Block leftBlock = mock(Block.class);
        when(leftBlock.arrange(g2, new RectangleConstraint(0.0,
                new org.jfree.data.Range(0.0, 100.0), LengthConstraintType.RANGE, 50.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(120.0, 50.0));
        
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        
        // Create a constraint that will trigger arrangeFF method
        // FIXED width and FIXED height constraints will call arrangeFF
        RectangleConstraint constraint = new RectangleConstraint(100.0, 50.0);
        
        // Use the public arrange method which internally calls arrangeFF
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(50.0, result.getHeight(), 0.001);
    }
}