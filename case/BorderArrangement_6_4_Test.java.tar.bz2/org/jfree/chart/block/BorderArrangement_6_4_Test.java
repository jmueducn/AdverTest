package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_6_4_Test {

    private TestBorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    // Test subclass to access protected arrangeFF method
    private static class TestBorderArrangement extends BorderArrangement {
        public Size2D arrangeFF(BlockContainer container, Graphics2D g2, RectangleConstraint constraint) {
            return super.arrangeFF(container, g2, constraint);
        }
    }

    @Before
    public void setUp() {
        arrangement = new TestBorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_OnlyRightBlock() {
        Block rightBlock = mock(Block.class);
        
        // Mock the arrange method to return a specific size
        when(rightBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(25.0, 50.0));
        
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        
        RectangleConstraint constraint = new RectangleConstraint(100.0, 50.0);
        
        // Call arrangeFF directly
        Size2D result = arrangement.arrangeFF(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(50.0, result.getHeight(), 0.001);
        
        // Verify that the right block's bounds were set correctly
        // The right block should be positioned at x = 75.0 (100 - 25), y = 0.0, width = 25.0, height = 50.0
        verify(rightBlock).setBounds(new Rectangle2D.Double(75.0, 0.0, 25.0, 50.0));
    }

    @Test
    public void testArrangeFF_WithMultipleBlocks() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        // Mock arrange methods for all blocks
        when(topBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(100.0, 20.0));
        when(bottomBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(100.0, 15.0));
        when(leftBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(30.0, 65.0));
        when(rightBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(25.0, 65.0));
        when(centerBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(45.0, 65.0));
        
        // Add all blocks to the arrangement
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null); // center block
        
        RectangleConstraint constraint = new RectangleConstraint(100.0, 100.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(100.0, result.getHeight(), 0.001);
        
        // Verify all blocks had their bounds set with correct values
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 20.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 85.0, 100.0, 15.0));
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 20.0, 30.0, 65.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(75.0, 20.0, 25.0, 65.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(30.0, 20.0, 45.0, 65.0));
    }

    @Test
    public void testArrangeFF_OnlyCenterBlock() {
        Block centerBlock = mock(Block.class);
        
        when(centerBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(80.0, 60.0));
        
        arrangement.add(centerBlock, null); // center block
        
        RectangleConstraint constraint = new RectangleConstraint(100.0, 80.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(80.0, result.getHeight(), 0.001);
        
        // Center block should occupy the entire space when no other blocks are present
        verify(centerBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 80.0));
    }

    @Test
    public void testArrangeFF_OnlyTopAndBottomBlocks() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        
        when(topBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(100.0, 25.0));
        when(bottomBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(100.0, 20.0));
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        
        RectangleConstraint constraint = new RectangleConstraint(100.0, 80.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(80.0, result.getHeight(), 0.001);
        
        // Verify bounds - middle section (h[2]) should be 35.0 (80 - 25 - 20)
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 25.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 60.0, 100.0, 20.0));
    }
}