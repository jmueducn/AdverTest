package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_5_2_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_TopAndBottomBlocksOnly() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);

        when(topBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(100.0, 40.0));
        when(bottomBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(100.0, 50.0));

        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);

        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);

        // Verify bounds are set correctly
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 40.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 190.0, 100.0, 50.0));
    }

    @Test
    public void testArrangeFF_AllBlocks() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);

        when(topBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(100.0, 30.0));
        when(bottomBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(100.0, 20.0));
        when(leftBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(25.0, 150.0));
        when(rightBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(15.0, 150.0));
        when(centerBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(60.0, 150.0));

        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);

        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);

        // Verify bounds are set correctly for all blocks
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 30.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 180.0, 100.0, 20.0));
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 30.0, 25.0, 150.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(85.0, 30.0, 15.0, 150.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(25.0, 30.0, 60.0, 150.0));
    }

    @Test
    public void testArrangeFF_NoBlocks() {
        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);

        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
    }
}