package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_4_3_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_LeftAndRightBlocksOnly() {
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        RectangleConstraint constraint = new RectangleConstraint(200.0, 180.0);
        
        // Mock the arrange calls for left and right blocks
        // Left block: width range [0, 200], fixed height 180 (full height since no top/bottom)
        when(leftBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 200.0), LengthConstraintType.RANGE, 180.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(40.0, 180.0));
        
        // Right block: width range [0, 160] (200 - 40), fixed height 180
        when(rightBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 160.0), LengthConstraintType.RANGE, 180.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(35.0, 180.0));
        
        // Add blocks to arrangement
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        
        // Call arrange with FIXED width and FIXED height to trigger arrangeFF
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        // Verify the result
        assertEquals(200.0, result.getWidth(), 0.001);
        assertEquals(180.0, result.getHeight(), 0.001);
        
        // Verify bounds are set correctly
        // Left block: x=0, y=0, width=40, height=180
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 40.0, 180.0));
        
        // Right block: x=165 (40 + 125), y=0, width=35, height=180
        verify(rightBlock).setBounds(new Rectangle2D.Double(165.0, 0.0, 35.0, 180.0));
    }
}