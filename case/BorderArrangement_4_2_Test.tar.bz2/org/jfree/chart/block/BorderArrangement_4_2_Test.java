package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Method;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_4_2_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        // Create a real Graphics2D instance from BufferedImage
        BufferedImage image = new BufferedImage(100, 100, BufferedImage.TYPE_INT_RGB);
        g2 = image.createGraphics();
    }

    @Test
    public void testArrangeFF_TopAndBottomBlocksOnly() throws Exception {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        RectangleConstraint constraint = new RectangleConstraint(80.0, 150.0);
        
        when(topBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(80.0, 25.0));
        when(bottomBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(80.0, 35.0));
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        
        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
            "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
        arrangeFFMethod.setAccessible(true);
        
        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);
        
        assertEquals(80.0, result.getWidth(), 0.001);
        assertEquals(150.0, result.getHeight(), 0.001);
        
        // Top block at top (y=0), bottom block at bottom (y=115 = 150-35)
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 80.0, 25.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 115.0, 80.0, 35.0));
    }

    @Test
    public void testArrangeFF_WithLeftAndRightBlocks() throws Exception {
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
        
        when(leftBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(20.0, 200.0));
        when(rightBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(30.0, 200.0));
        when(centerBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(50.0, 200.0));
        
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);
        
        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
            "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
        arrangeFFMethod.setAccessible(true);
        
        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);
        
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        
        // Left, center, right blocks all start at y=0 with full height (no top/bottom blocks)
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 20.0, 200.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(70.0, 0.0, 30.0, 200.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(20.0, 0.0, 50.0, 200.0));
    }

    @Test
    public void testArrangeFF_AllBlocks() throws Exception {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        RectangleConstraint constraint = new RectangleConstraint(120.0, 180.0);
        
        when(topBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(120.0, 20.0));
        when(bottomBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(120.0, 25.0));
        when(leftBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(25.0, 135.0));
        when(rightBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(30.0, 135.0));
        when(centerBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(65.0, 135.0));
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);
        
        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
            "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
        arrangeFFMethod.setAccessible(true);
        
        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);
        
        assertEquals(120.0, result.getWidth(), 0.001);
        assertEquals(180.0, result.getHeight(), 0.001);
        
        // Verify all block positions with correct calculations:
        // Top: y=0, height=20
        // Bottom: y=155 (20+135), height=25  
        // Left/Center/Right: y=20, height=135 (180-20-25)
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 120.0, 20.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 155.0, 120.0, 25.0));
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 20.0, 25.0, 135.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(90.0, 20.0, 30.0, 135.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(25.0, 20.0, 65.0, 135.0));
    }

    @Test
    public void testArrangeFF_OnlyCenterBlock() throws Exception {
        Block centerBlock = mock(Block.class);
        RectangleConstraint constraint = new RectangleConstraint(100.0, 150.0);
        
        when(centerBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(100.0, 150.0));
        
        arrangement.add(centerBlock, null);
        
        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
            "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
        arrangeFFMethod.setAccessible(true);
        
        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);
        
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(150.0, result.getHeight(), 0.001);
        
        verify(centerBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 150.0));
    }
}