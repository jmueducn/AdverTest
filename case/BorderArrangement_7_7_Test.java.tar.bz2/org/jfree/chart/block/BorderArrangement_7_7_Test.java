package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_7_7_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_LeftAndRightBlocks() {
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);

        // Mock the arrange calls for left and right blocks
        when(leftBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 160.0), LengthConstraintType.RANGE, 160.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(40.0, 160.0));
        
        when(rightBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 120.0), LengthConstraintType.RANGE, 160.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(30.0, 160.0));

        // Mock the container's toContentConstraint method
        RectangleConstraint constraint = new RectangleConstraint(160.0, 160.0);
        when(container.toContentConstraint(constraint)).thenReturn(constraint);
        
        // Mock the container's calculateTotalWidth and calculateTotalHeight methods
        when(container.calculateTotalWidth(160.0)).thenReturn(160.0);
        when(container.calculateTotalHeight(160.0)).thenReturn(160.0);

        // Call the public arrange method which will internally call arrangeFF
        Size2D result = arrangement.arrange(container, g2, constraint);

        assertEquals(160.0, result.getWidth(), 0.001);
        assertEquals(160.0, result.getHeight(), 0.001);
    }
}