package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;

import java.awt.Graphics2D;

import org.jfree.chart.util.Size2D;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_7_8_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_NoBlocks() {
        RectangleConstraint constraint = new RectangleConstraint(100.0, 100.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);

        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(100.0, result.getHeight(), 0.001);
    }

    @Test
    public void testArrangeFF_WithCenterBlock() {
        Block centerBlock = mock(Block.class);
        arrangement.add(centerBlock, null);
        
        RectangleConstraint constraint = new RectangleConstraint(200.0, 150.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);

        assertEquals(200.0, result.getWidth(), 0.001);
        assertEquals(150.0, result.getHeight(), 0.001);
    }

    @Test
    public void testArrangeFF_WithTopBlock() {
        Block topBlock = mock(Block.class);
        arrangement.add(topBlock, org.jfree.chart.util.RectangleEdge.TOP);
        
        RectangleConstraint constraint = new RectangleConstraint(300.0, 200.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);

        assertEquals(300.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
    }

    @Test
    public void testArrangeFF_WithAllBlocks() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        arrangement.add(topBlock, org.jfree.chart.util.RectangleEdge.TOP);
        arrangement.add(bottomBlock, org.jfree.chart.util.RectangleEdge.BOTTOM);
        arrangement.add(leftBlock, org.jfree.chart.util.RectangleEdge.LEFT);
        arrangement.add(rightBlock, org.jfree.chart.util.RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);
        
        RectangleConstraint constraint = new RectangleConstraint(400.0, 300.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);

        assertEquals(400.0, result.getWidth(), 0.001);
        assertEquals(300.0, result.getHeight(), 0.001);
    }
}