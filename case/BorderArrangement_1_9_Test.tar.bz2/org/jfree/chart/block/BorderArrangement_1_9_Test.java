package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_1_9_Test extends BorderArrangement {

    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_LeftBlockExceedsAvailableWidth() {
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        add(leftBlock, RectangleEdge.LEFT);
        add(rightBlock, RectangleEdge.RIGHT);
        
        RectangleConstraint constraint = new RectangleConstraint(50.0, 200.0);
        
        // Mock the arrange calls with correct constraints
        when(leftBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 50.0), LengthConstraintType.RANGE, 200.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(40.0, 200.0));
        
        when(rightBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, Math.max(50.0 - 40.0, 0.0)), LengthConstraintType.RANGE, 200.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(8.0, 200.0));
        
        Size2D result = arrangeFF(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(50.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
    }
}