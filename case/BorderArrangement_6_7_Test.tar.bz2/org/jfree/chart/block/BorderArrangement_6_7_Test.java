package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;

import org.jfree.chart.util.Size2D;
import org.jfree.chart.util.RectangleEdge;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_6_7_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_LeftAndRightBlocks() {
        Block leftBlock = mock(Block.class);
        when(leftBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 100.0), LengthConstraintType.RANGE, 50.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(20.0, 50.0));
        
        Block rightBlock = mock(Block.class);
        when(rightBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 80.0), LengthConstraintType.RANGE, 50.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(25.0, 50.0));
        
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        
        // Mock the container behavior
        RectangleConstraint constraint = new RectangleConstraint(100.0, 50.0);
        RectangleConstraint contentConstraint = new RectangleConstraint(100.0, 50.0);
        when(container.toContentConstraint(constraint)).thenReturn(contentConstraint);
        when(container.calculateTotalWidth(100.0)).thenReturn(100.0);
        when(container.calculateTotalHeight(50.0)).thenReturn(50.0);
        
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(50.0, result.getHeight(), 0.001);
    }
}