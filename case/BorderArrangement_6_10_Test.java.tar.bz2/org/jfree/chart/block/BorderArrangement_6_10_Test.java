package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_6_10_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_RightBlockWithZeroAvailableWidth() {
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        // Mock left block arrangement
        when(leftBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(100.0, 50.0));
        
        // Mock right block arrangement - zero width available
        when(rightBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(0.0, 50.0));
        
        // Mock center block arrangement
        when(centerBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(0.0, 50.0));
        
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null); // center block
        
        // Use arrange method with FIXED width and FIXED height constraint to trigger arrangeFF
        RectangleConstraint constraint = new RectangleConstraint(100.0, 100.0);
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(100.0, result.getHeight(), 0.001);
        
        // Verify that blocks received setBounds calls
        verify(leftBlock).setBounds(any(Rectangle2D.Double.class));
        verify(rightBlock).setBounds(any(Rectangle2D.Double.class));
        verify(centerBlock).setBounds(any(Rectangle2D.Double.class));
    }

    @Test
    public void testArrangeFF_AllBlocksPresent() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        // Mock block arrangements with appropriate sizes
        when(topBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(100.0, 20.0));
        when(bottomBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(100.0, 20.0));
        when(leftBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(30.0, 60.0));
        when(rightBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(30.0, 60.0));
        when(centerBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(40.0, 60.0));
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);
        
        RectangleConstraint constraint = new RectangleConstraint(100.0, 100.0);
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(100.0, result.getHeight(), 0.001);
        
        // Verify all blocks received setBounds calls
        verify(topBlock).setBounds(any(Rectangle2D.Double.class));
        verify(bottomBlock).setBounds(any(Rectangle2D.Double.class));
        verify(leftBlock).setBounds(any(Rectangle2D.Double.class));
        verify(rightBlock).setBounds(any(Rectangle2D.Double.class));
        verify(centerBlock).setBounds(any(Rectangle2D.Double.class));
    }

    @Test
    public void testArrangeFF_OnlyCenterBlock() {
        Block centerBlock = mock(Block.class);
        
        // Mock center block arrangement
        when(centerBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(100.0, 100.0));
        
        arrangement.add(centerBlock, null);
        
        RectangleConstraint constraint = new RectangleConstraint(100.0, 100.0);
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(100.0, result.getHeight(), 0.001);
        
        verify(centerBlock).setBounds(any(Rectangle2D.Double.class));
    }

    @Test
    public void testArrangeFF_TopAndBottomBlocksOnly() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        
        // Mock block arrangements
        when(topBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(100.0, 30.0));
        when(bottomBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(100.0, 30.0));
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        
        RectangleConstraint constraint = new RectangleConstraint(100.0, 100.0);
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(100.0, result.getHeight(), 0.001);
        
        verify(topBlock).setBounds(any(Rectangle2D.Double.class));
        verify(bottomBlock).setBounds(any(Rectangle2D.Double.class));
    }
}