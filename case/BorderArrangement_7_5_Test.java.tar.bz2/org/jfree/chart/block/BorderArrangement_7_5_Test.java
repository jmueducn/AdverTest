package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Method;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_7_5_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_OnlyCenterBlock() throws Exception {
        Block centerBlock = mock(Block.class);
        arrangement.add(centerBlock, null);

        RectangleConstraint constraint = new RectangleConstraint(200.0, 150.0);

        // Mock the center block arrangement with the correct constraint
        when(centerBlock.arrange(g2, new RectangleConstraint(200.0, 150.0)))
                .thenReturn(new Size2D(200.0, 150.0));

        // Use reflection to access the protected arrangeFF method
        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
                "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
        arrangeFFMethod.setAccessible(true);
        
        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);

        assertEquals(200.0, result.getWidth(), 0.001);
        assertEquals(150.0, result.getHeight(), 0.001);
        
        // Verify the center block was positioned correctly
        verify(centerBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 200.0, 150.0));
    }

    @Test
    public void testArrangeFF_WithAllBlocks() throws Exception {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);

        RectangleConstraint constraint = new RectangleConstraint(300.0, 200.0);

        // Mock block arrangements
        when(topBlock.arrange(g2, new RectangleConstraint(300.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 200.0), LengthConstraintType.RANGE)))
                .thenReturn(new Size2D(300.0, 30.0));
                
        when(bottomBlock.arrange(g2, new RectangleConstraint(300.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 170.0), LengthConstraintType.RANGE)))
                .thenReturn(new Size2D(300.0, 25.0));
                
        when(leftBlock.arrange(g2, new RectangleConstraint(0.0, new Range(0.0, 300.0),
                LengthConstraintType.RANGE, 145.0, null, LengthConstraintType.FIXED)))
                .thenReturn(new Size2D(50.0, 145.0));
                
        when(rightBlock.arrange(g2, new RectangleConstraint(0.0, new Range(0.0, 250.0),
                LengthConstraintType.RANGE, 145.0, null, LengthConstraintType.FIXED)))
                .thenReturn(new Size2D(60.0, 145.0));

        when(centerBlock.arrange(g2, new RectangleConstraint(190.0, 145.0)))
                .thenReturn(new Size2D(190.0, 145.0));

        // Use reflection to access the protected arrangeFF method
        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
                "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
        arrangeFFMethod.setAccessible(true);
        
        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);

        assertEquals(300.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        
        // Verify all blocks were positioned correctly
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 300.0, 30.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 175.0, 300.0, 25.0));
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 30.0, 50.0, 145.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(240.0, 30.0, 60.0, 145.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(50.0, 30.0, 190.0, 145.0));
    }
}