package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_8_6_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
        
        // Mock the container to return appropriate content constraints
        when(container.toContentConstraint(any(RectangleConstraint.class)))
            .thenAnswer(invocation -> invocation.getArgument(0));
        when(container.calculateTotalWidth(any(Double.class)))
            .thenAnswer(invocation -> invocation.getArgument(0));
        when(container.calculateTotalHeight(any(Double.class)))
            .thenAnswer(invocation -> invocation.getArgument(0));
    }

    @Test
    public void testArrangeFF_AllBlocksPresent() {
        // Create mock blocks for all positions
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        // Set up mock responses for each block
        when(topBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(100.0, 20.0));
        when(bottomBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(100.0, 15.0));
        when(leftBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(25.0, 65.0));
        when(rightBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(20.0, 65.0));
        when(centerBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(55.0, 65.0));

        // Add all blocks to the arrangement
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);

        // Create a fixed-fixed constraint
        RectangleConstraint constraint = new RectangleConstraint(100.0, 100.0);
        
        // Test through public arrange method
        Size2D result = arrangement.arrange(container, g2, constraint);

        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.0);
        assertEquals(100.0, result.getHeight(), 0.0);
        
        // Verify blocks received correct bounds
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 20.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 85.0, 100.0, 15.0));
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 20.0, 25.0, 65.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(80.0, 20.0, 20.0, 65.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(25.0, 20.0, 55.0, 65.0));
    }

    @Test
    public void testArrangeFF_OnlyCenterBlock() {
        Block centerBlock = mock(Block.class);
        
        when(centerBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(80.0, 60.0));

        arrangement.add(centerBlock, null);

        RectangleConstraint constraint = new RectangleConstraint(100.0, 100.0);
        
        Size2D result = arrangement.arrange(container, g2, constraint);

        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.0);
        assertEquals(100.0, result.getHeight(), 0.0);
        
        // Verify center block received correct bounds
        verify(centerBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 100.0));
    }

    @Test
    public void testArrangeFF_LeftAndRightBlocksWithLimitedSpace() {
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        // Left and right blocks request more width than available
        when(leftBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(40.0, 80.0));
        when(rightBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(40.0, 80.0));
        when(centerBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(20.0, 80.0));

        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);

        RectangleConstraint constraint = new RectangleConstraint(100.0, 100.0);
        
        Size2D result = arrangement.arrange(container, g2, constraint);

        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.0);
        assertEquals(100.0, result.getHeight(), 0.0);
        
        // Verify blocks received correct bounds despite limited space
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 40.0, 80.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(80.0, 0.0, 20.0, 80.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(40.0, 0.0, 40.0, 80.0));
    }

    @Test
    public void testArrangeFF_NoBlocks() {
        RectangleConstraint constraint = new RectangleConstraint(100.0, 100.0);
        
        Size2D result = arrangement.arrange(container, g2, constraint);

        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.0);
        assertEquals(100.0, result.getHeight(), 0.0);
    }

    @Test
    public void testArrangeFF_TopAndBottomBlocksOnly() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        
        when(topBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(100.0, 30.0));
        when(bottomBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(100.0, 20.0));

        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);

        RectangleConstraint constraint = new RectangleConstraint(100.0, 100.0);
        
        Size2D result = arrangement.arrange(container, g2, constraint);

        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.0);
        assertEquals(100.0, result.getHeight(), 0.0);
        
        // Verify blocks received correct bounds
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 30.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 80.0, 100.0, 20.0));
    }
}