package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_7_6_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_TopAndBottomBlocks() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);

        when(topBlock.arrange(g2, new RectangleConstraint(90.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 150.0),
                LengthConstraintType.RANGE))).thenReturn(new Size2D(90.0, 25.0));
        
        when(bottomBlock.arrange(g2, new RectangleConstraint(90.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 125.0),
                LengthConstraintType.RANGE))).thenReturn(new Size2D(90.0, 35.0));

        RectangleConstraint constraint = new RectangleConstraint(90.0, 150.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);

        assertEquals(90.0, result.getWidth(), 0.001);
        assertEquals(150.0, result.getHeight(), 0.001);
    }
}