package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Method;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_5_1_Test {

    private BorderArrangement arrangement;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_OnlyCenterBlock() throws Exception {
        Block centerBlock = mock(Block.class);
        arrangement.add(centerBlock, null);

        BlockContainer container = mock(BlockContainer.class);
        
        // Mock center block arrangement - the method will create a constraint with width 100 and height 150
        RectangleConstraint centerConstraint = new RectangleConstraint(100.0, 150.0);
        when(centerBlock.arrange(g2, centerConstraint))
                .thenReturn(new Size2D(100.0, 150.0));

        // Create constraint with FIXED width and FIXED height
        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);

        // Use reflection to access protected arrangeFF method
        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
            "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
        arrangeFFMethod.setAccessible(true);
        
        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);

        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        
        // Verify center block bounds were set correctly
        verify(centerBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 150.0));
    }

    @Test
    public void testArrangeFF_WithRightBlock() throws Exception {
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);

        BlockContainer container = mock(BlockContainer.class);

        // Mock right block arrangement - the actual constraint will have height 200 (full constraint height)
        RectangleConstraint rightConstraint = new RectangleConstraint(0.0,
                new Range(0.0, 100.0), 
                LengthConstraintType.RANGE, 
                200.0, null, 
                LengthConstraintType.FIXED);
        when(rightBlock.arrange(g2, rightConstraint))
                .thenReturn(new Size2D(30.0, 200.0));

        // Mock center block arrangement - width will be 70 (100 - 30), height will be 200
        RectangleConstraint centerConstraint = new RectangleConstraint(70.0, 200.0);
        when(centerBlock.arrange(g2, centerConstraint))
                .thenReturn(new Size2D(70.0, 200.0));

        // Create constraint with FIXED width and FIXED height
        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);

        // Use reflection to access protected arrangeFF method
        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
            "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
        arrangeFFMethod.setAccessible(true);
        
        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);

        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        
        // Verify block bounds were set correctly
        verify(rightBlock).setBounds(new Rectangle2D.Double(70.0, 0.0, 30.0, 200.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 70.0, 200.0));
    }

    @Test
    public void testArrangeFF_WithTopAndBottomBlocks() throws Exception {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        arrangement.add(centerBlock, null);

        BlockContainer container = mock(BlockContainer.class);

        // Mock top block arrangement
        RectangleConstraint topConstraint = new RectangleConstraint(100.0, null,
                LengthConstraintType.FIXED, 
                0.0, new Range(0.0, 200.0),
                LengthConstraintType.RANGE);
        when(topBlock.arrange(g2, topConstraint))
                .thenReturn(new Size2D(100.0, 20.0));

        // Mock bottom block arrangement - available height will be 180 (200 - 20)
        RectangleConstraint bottomConstraint = new RectangleConstraint(100.0, null,
                LengthConstraintType.FIXED, 
                0.0, new Range(0.0, 180.0),
                LengthConstraintType.RANGE);
        when(bottomBlock.arrange(g2, bottomConstraint))
                .thenReturn(new Size2D(100.0, 30.0));

        // Mock center block arrangement - height will be 150 (200 - 20 - 30)
        RectangleConstraint centerConstraint = new RectangleConstraint(100.0, 150.0);
        when(centerBlock.arrange(g2, centerConstraint))
                .thenReturn(new Size2D(100.0, 150.0));

        // Create constraint with FIXED width and FIXED height
        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);

        // Use reflection to access protected arrangeFF method
        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
            "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
        arrangeFFMethod.setAccessible(true);
        
        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);

        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        
        // Verify block bounds were set correctly
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 20.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 170.0, 100.0, 30.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(0.0, 20.0, 100.0, 150.0));
    }

    @Test
    public void testArrangeFF_WithLeftAndRightBlocks() throws Exception {
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);

        BlockContainer container = mock(BlockContainer.class);

        // Mock left block arrangement
        RectangleConstraint leftConstraint = new RectangleConstraint(0.0,
                new Range(0.0, 100.0), 
                LengthConstraintType.RANGE, 
                200.0, null, 
                LengthConstraintType.FIXED);
        when(leftBlock.arrange(g2, leftConstraint))
                .thenReturn(new Size2D(25.0, 200.0));

        // Mock right block arrangement - available width will be 75 (100 - 25)
        RectangleConstraint rightConstraint = new RectangleConstraint(0.0,
                new Range(0.0, 75.0), 
                LengthConstraintType.RANGE, 
                200.0, null, 
                LengthConstraintType.FIXED);
        when(rightBlock.arrange(g2, rightConstraint))
                .thenReturn(new Size2D(35.0, 200.0));

        // Mock center block arrangement - width will be 40 (100 - 25 - 35), height 200
        RectangleConstraint centerConstraint = new RectangleConstraint(40.0, 200.0);
        when(centerBlock.arrange(g2, centerConstraint))
                .thenReturn(new Size2D(40.0, 200.0));

        // Create constraint with FIXED width and FIXED height
        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);

        // Use reflection to access protected arrangeFF method
        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
            "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
        arrangeFFMethod.setAccessible(true);
        
        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);

        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        
        // Verify block bounds were set correctly
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 25.0, 200.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(65.0, 0.0, 35.0, 200.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(25.0, 0.0, 40.0, 200.0));
    }
}