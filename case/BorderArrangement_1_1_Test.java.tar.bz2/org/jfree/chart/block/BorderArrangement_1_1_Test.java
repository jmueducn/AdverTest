package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_1_1_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
        
        // Mock the container's constraint conversion methods
        when(container.toContentConstraint(any(RectangleConstraint.class)))
            .thenAnswer(invocation -> invocation.getArgument(0));
        when(container.calculateTotalWidth(any(Double.class)))
            .thenAnswer(invocation -> invocation.getArgument(0));
        when(container.calculateTotalHeight(any(Double.class)))
            .thenAnswer(invocation -> invocation.getArgument(0));
    }

    @Test
    public void testArrangeFF_OnlyTopBlock() {
        Block topBlock = mock(Block.class);
        arrangement.add(topBlock, RectangleEdge.TOP);
        
        // Create constraint with fixed width and height (triggers arrangeFF)
        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
        
        // Mock the arrange method for top block
        when(topBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                .thenReturn(new Size2D(100.0, 50.0));
        
        // Invoke the arrange method which will call arrangeFF internally
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        
        // Verify the top block was positioned correctly
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 50.0));
    }

    @Test
    public void testArrangeFF_WithAllBlocks() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);
        
        RectangleConstraint constraint = new RectangleConstraint(300.0, 400.0);
        
        // Mock arrange methods for all blocks with appropriate constraints
        when(topBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                .thenReturn(new Size2D(300.0, 50.0));
        when(bottomBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                .thenReturn(new Size2D(300.0, 40.0));
        when(leftBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                .thenReturn(new Size2D(60.0, 310.0));
        when(rightBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                .thenReturn(new Size2D(70.0, 310.0));
        when(centerBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                .thenReturn(new Size2D(170.0, 310.0));
        
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(300.0, result.getWidth(), 0.001);
        assertEquals(400.0, result.getHeight(), 0.001);
        
        // Verify all blocks were positioned correctly
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 300.0, 50.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 360.0, 300.0, 40.0));
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 50.0, 60.0, 310.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(230.0, 50.0, 70.0, 310.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(60.0, 50.0, 170.0, 310.0));
    }

    @Test
    public void testArrangeFF_NoBlocks() {
        RectangleConstraint constraint = new RectangleConstraint(200.0, 300.0);
        
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(200.0, result.getWidth(), 0.001);
        assertEquals(300.0, result.getHeight(), 0.001);
    }

    @Test
    public void testArrangeFF_OnlyCenterBlock() {
        Block centerBlock = mock(Block.class);
        arrangement.add(centerBlock, null);
        
        RectangleConstraint constraint = new RectangleConstraint(200.0, 300.0);
        
        when(centerBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                .thenReturn(new Size2D(200.0, 300.0));
        
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(200.0, result.getWidth(), 0.001);
        assertEquals(300.0, result.getHeight(), 0.001);
        
        verify(centerBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 200.0, 300.0));
    }

    @Test
    public void testArrangeFF_LeftAndRightBlocksOnly() {
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        
        RectangleConstraint constraint = new RectangleConstraint(300.0, 400.0);
        
        when(leftBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                .thenReturn(new Size2D(80.0, 400.0));
        when(rightBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                .thenReturn(new Size2D(90.0, 400.0));
        
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(300.0, result.getWidth(), 0.001);
        assertEquals(400.0, result.getHeight(), 0.001);
        
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 80.0, 400.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(210.0, 0.0, 90.0, 400.0));
    }
}