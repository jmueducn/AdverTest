package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;

import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_6_2_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_OnlyBottomBlock() {
        Block bottomBlock = mock(Block.class);
        when(bottomBlock.arrange(g2, new RectangleConstraint(100.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 50.0),
                LengthConstraintType.RANGE))).thenReturn(new Size2D(100.0, 15.0));
        
        arrangement.add(bottomBlock, org.jfree.chart.util.RectangleEdge.BOTTOM);
        RectangleConstraint constraint = new RectangleConstraint(100.0, 50.0);
        
        // Test through the public arrange method which internally calls arrangeFF
        // when both width and height constraints are FIXED
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(50.0, result.getHeight(), 0.001);
    }
}