package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_7_2_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_OnlyBottomBlock() {
        Block bottomBlock = mock(Block.class);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);

        // Mock the container's toContentConstraint method to return the same constraint
        RectangleConstraint constraint = new RectangleConstraint(80.0, 250.0);
        when(container.toContentConstraint(constraint)).thenReturn(constraint);
        
        // Mock the container's calculateTotalWidth and calculateTotalHeight methods
        when(container.calculateTotalWidth(80.0)).thenReturn(80.0);
        when(container.calculateTotalHeight(250.0)).thenReturn(250.0);

        // Mock the bottom block arrangement
        RectangleConstraint bottomConstraint = new RectangleConstraint(80.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 250.0),
                LengthConstraintType.RANGE);
        when(bottomBlock.arrange(g2, bottomConstraint)).thenReturn(new Size2D(80.0, 40.0));

        // Call the public arrange method which will internally call arrangeFF
        Size2D result = arrangement.arrange(container, g2, constraint);

        assertEquals(80.0, result.getWidth(), 0.001);
        assertEquals(250.0, result.getHeight(), 0.001);
    }
}