package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_4_6_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = null; // Use null instead of mock since Graphics2D is not actually used
    }

    @Test
    public void testArrangeFF_TopAndBottomExceedAvailableHeight() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        RectangleConstraint constraint = new RectangleConstraint(100.0, 50.0);
        
        when(topBlock.arrange(g2, new RectangleConstraint(100.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 50.0),
                LengthConstraintType.RANGE))).thenReturn(new Size2D(100.0, 40.0));
        when(bottomBlock.arrange(g2, new RectangleConstraint(100.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 10.0),
                LengthConstraintType.RANGE))).thenReturn(new Size2D(100.0, 5.0));
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(50.0, result.getHeight(), 0.001);
    }
}