package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;

import org.jfree.chart.util.Size2D;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_8_3_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_OnlyCenterBlock() {
        Block centerBlock = mock(Block.class);

        when(centerBlock.arrange(g2, new RectangleConstraint(120.0, 180.0)))
                .thenReturn(new Size2D(120.0, 180.0));

        arrangement.add(centerBlock, null);

        RectangleConstraint constraint = new RectangleConstraint(120.0, 180.0);
        Size2D result = arrangement.arrange(container, g2, constraint);

        assertNotNull(result);
        assertEquals(120.0, result.getWidth(), 0.0);
        assertEquals(180.0, result.getHeight(), 0.0);
    }
}