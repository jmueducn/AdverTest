package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_1_0_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_AllBlocksNull() {
        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
    }

    @Test
    public void testArrangeFF_WithTopBlock() {
        Block topBlock = mock(Block.class);
        when(topBlock.arrange(g2, any(RectangleConstraint.class)))
                .thenReturn(new Size2D(100.0, 20.0));
        
        arrangement.add(topBlock, org.jfree.chart.util.RectangleEdge.TOP);
        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 20.0));
    }

    @Test
    public void testArrangeFF_WithBottomBlock() {
        Block bottomBlock = mock(Block.class);
        when(bottomBlock.arrange(g2, any(RectangleConstraint.class)))
                .thenReturn(new Size2D(100.0, 30.0));
        
        arrangement.add(bottomBlock, org.jfree.chart.util.RectangleEdge.BOTTOM);
        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 170.0, 100.0, 30.0));
    }

    @Test
    public void testArrangeFF_WithLeftBlock() {
        Block leftBlock = mock(Block.class);
        when(leftBlock.arrange(g2, any(RectangleConstraint.class)))
                .thenReturn(new Size2D(40.0, 150.0));
        
        arrangement.add(leftBlock, org.jfree.chart.util.RectangleEdge.LEFT);
        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 40.0, 150.0));
    }

    @Test
    public void testArrangeFF_WithRightBlock() {
        Block rightBlock = mock(Block.class);
        when(rightBlock.arrange(g2, any(RectangleConstraint.class)))
                .thenReturn(new Size2D(35.0, 150.0));
        
        arrangement.add(rightBlock, org.jfree.chart.util.RectangleEdge.RIGHT);
        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        verify(rightBlock).setBounds(new Rectangle2D.Double(65.0, 0.0, 35.0, 150.0));
    }

    @Test
    public void testArrangeFF_WithCenterBlock() {
        Block centerBlock = mock(Block.class);
        when(centerBlock.arrange(g2, any(RectangleConstraint.class)))
                .thenReturn(new Size2D(60.0, 150.0));
        
        arrangement.add(centerBlock, null);
        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        verify(centerBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 150.0));
    }

    @Test
    public void testArrangeFF_WithAllBlocks() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        when(topBlock.arrange(g2, any(RectangleConstraint.class)))
                .thenReturn(new Size2D(100.0, 20.0));
        when(bottomBlock.arrange(g2, any(RectangleConstraint.class)))
                .thenReturn(new Size2D(100.0, 30.0));
        when(leftBlock.arrange(g2, any(RectangleConstraint.class)))
                .thenReturn(new Size2D(25.0, 150.0));
        when(rightBlock.arrange(g2, any(RectangleConstraint.class)))
                .thenReturn(new Size2D(30.0, 150.0));
        when(centerBlock.arrange(g2, any(RectangleConstraint.class)))
                .thenReturn(new Size2D(45.0, 150.0));
        
        arrangement.add(topBlock, org.jfree.chart.util.RectangleEdge.TOP);
        arrangement.add(bottomBlock, org.jfree.chart.util.RectangleEdge.BOTTOM);
        arrangement.add(leftBlock, org.jfree.chart.util.RectangleEdge.LEFT);
        arrangement.add(rightBlock, org.jfree.chart.util.RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);
        
        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 20.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 170.0, 100.0, 30.0));
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 20.0, 25.0, 150.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(70.0, 20.0, 30.0, 150.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(25.0, 20.0, 45.0, 150.0));
    }
}