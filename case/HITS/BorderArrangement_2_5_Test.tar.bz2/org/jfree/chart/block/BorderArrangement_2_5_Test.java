package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_2_5_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_OnlyCenterBlock() {
        Block centerBlock = mock(Block.class);
        
        // Set up the center block to return the expected size when arranged
        RectangleConstraint centerConstraint = new RectangleConstraint(100.0, 50.0);
        when(centerBlock.arrange(g2, centerConstraint))
                .thenReturn(new Size2D(100.0, 50.0));
        
        arrangement.add(centerBlock, null);
        
        // Create a constraint that will trigger arrangeFF method
        RectangleConstraint constraint = new RectangleConstraint(100.0, 50.0);
        
        // Call the public arrange method which internally calls arrangeFF
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(50.0, result.getHeight(), 0.001);
        
        // Verify the center block was positioned correctly
        verify(centerBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 50.0));
    }

    @Test
    public void testArrangeFF_WithTopAndCenterBlocks() {
        Block topBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        // Set up top block arrangement
        RectangleConstraint topConstraint = new RectangleConstraint(100.0, null,
                LengthConstraintType.FIXED, 0.0,
                new Range(0.0, 50.0), LengthConstraintType.RANGE);
        when(topBlock.arrange(g2, topConstraint))
                .thenReturn(new Size2D(100.0, 20.0));
        
        // Set up center block arrangement  
        RectangleConstraint centerConstraint = new RectangleConstraint(100.0, 30.0);
        when(centerBlock.arrange(g2, centerConstraint))
                .thenReturn(new Size2D(100.0, 30.0));
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(centerBlock, null);
        
        RectangleConstraint constraint = new RectangleConstraint(100.0, 50.0);
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(50.0, result.getHeight(), 0.001);
        
        // Verify block positioning
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 20.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(0.0, 20.0, 100.0, 30.0));
    }

    @Test
    public void testArrangeFF_WithAllBlocks() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        // Set up mock arrangements
        RectangleConstraint topConstraint = new RectangleConstraint(200.0, null,
                LengthConstraintType.FIXED, 0.0,
                new Range(0.0, 100.0), LengthConstraintType.RANGE);
        when(topBlock.arrange(g2, topConstraint))
                .thenReturn(new Size2D(200.0, 20.0));
                
        RectangleConstraint bottomConstraint = new RectangleConstraint(200.0, null,
                LengthConstraintType.FIXED, 0.0, 
                new Range(0.0, 80.0), LengthConstraintType.RANGE);
        when(bottomBlock.arrange(g2, bottomConstraint))
                .thenReturn(new Size2D(200.0, 15.0));
                
        RectangleConstraint leftConstraint = new RectangleConstraint(0.0,
                new Range(0.0, 200.0), LengthConstraintType.RANGE, 65.0, null,
                LengthConstraintType.FIXED);
        when(leftBlock.arrange(g2, leftConstraint))
                .thenReturn(new Size2D(30.0, 65.0));
                
        RectangleConstraint rightConstraint = new RectangleConstraint(0.0,
                new Range(0.0, 170.0), LengthConstraintType.RANGE, 65.0, null,
                LengthConstraintType.FIXED);
        when(rightBlock.arrange(g2, rightConstraint))
                .thenReturn(new Size2D(25.0, 65.0));
                
        RectangleConstraint centerConstraint = new RectangleConstraint(145.0, 65.0);
        when(centerBlock.arrange(g2, centerConstraint))
                .thenReturn(new Size2D(145.0, 65.0));
        
        // Add all blocks
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);
        
        RectangleConstraint constraint = new RectangleConstraint(200.0, 100.0);
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(200.0, result.getWidth(), 0.001);
        assertEquals(100.0, result.getHeight(), 0.001);
        
        // Verify all blocks are positioned correctly
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 200.0, 20.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 85.0, 200.0, 15.0));
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 20.0, 30.0, 65.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(175.0, 20.0, 25.0, 65.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(30.0, 20.0, 145.0, 65.0));
    }
}