package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_3_8_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        // Create a real Graphics2D instance from BufferedImage
        BufferedImage image = new BufferedImage(100, 100, BufferedImage.TYPE_INT_RGB);
        g2 = image.createGraphics();
    }

    @Test
    public void testArrangeFF_LeftBlockTakesFullWidth() {
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        
        // Use FIXED constraint for both width and height to trigger arrangeFF
        RectangleConstraint constraint = new RectangleConstraint(200.0, 300.0);
        
        // Mock left block arrangement - it should take available width
        when(leftBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 200.0), LengthConstraintType.RANGE, 300.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(200.0, 300.0));
        
        // Mock right block arrangement - gets 0 width since left took all
        when(rightBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 0.0), LengthConstraintType.RANGE, 300.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(0.0, 300.0));
        
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        
        // Use public arrange method with FIXED constraints
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertEquals(200.0, result.getWidth(), 0.001);
        assertEquals(300.0, result.getHeight(), 0.001);
        
        // Verify bounds are set correctly
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 200.0, 300.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(200.0, 0.0, 0.0, 300.0));
    }

    @Test
    public void testArrangeFF_WithAllBlocks() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        RectangleConstraint constraint = new RectangleConstraint(400.0, 500.0);
        
        // Mock top block arrangement
        when(topBlock.arrange(g2, new RectangleConstraint(400.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 500.0),
                LengthConstraintType.RANGE))).thenReturn(new Size2D(400.0, 50.0));
        
        // Mock bottom block arrangement
        when(bottomBlock.arrange(g2, new RectangleConstraint(400.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 450.0),
                LengthConstraintType.RANGE))).thenReturn(new Size2D(400.0, 50.0));
        
        // Mock left block arrangement
        when(leftBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 400.0), LengthConstraintType.RANGE, 400.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(100.0, 400.0));
        
        // Mock right block arrangement
        when(rightBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 300.0), LengthConstraintType.RANGE, 400.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(100.0, 400.0));
        
        // Mock center block arrangement
        when(centerBlock.arrange(g2, new RectangleConstraint(200.0, 400.0)))
                .thenReturn(new Size2D(200.0, 400.0));
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);
        
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertEquals(400.0, result.getWidth(), 0.001);
        assertEquals(500.0, result.getHeight(), 0.001);
        
        // Verify bounds are set correctly
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 400.0, 50.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 450.0, 400.0, 50.0));
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 50.0, 100.0, 400.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(300.0, 50.0, 100.0, 400.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(100.0, 50.0, 200.0, 400.0));
    }

    @Test
    public void testArrangeFF_OnlyCenterBlock() {
        Block centerBlock = mock(Block.class);
        RectangleConstraint constraint = new RectangleConstraint(300.0, 200.0);
        
        // Mock center block arrangement
        when(centerBlock.arrange(g2, new RectangleConstraint(300.0, 200.0)))
                .thenReturn(new Size2D(300.0, 200.0));
        
        arrangement.add(centerBlock, null);
        
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertEquals(300.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        
        // Verify center block bounds
        verify(centerBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 300.0, 200.0));
    }

    @Test
    public void testArrangeFF_OnlyTopAndBottomBlocks() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        RectangleConstraint constraint = new RectangleConstraint(300.0, 400.0);
        
        // Mock top block arrangement
        when(topBlock.arrange(g2, new RectangleConstraint(300.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 400.0),
                LengthConstraintType.RANGE))).thenReturn(new Size2D(300.0, 100.0));
        
        // Mock bottom block arrangement
        when(bottomBlock.arrange(g2, new RectangleConstraint(300.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 300.0),
                LengthConstraintType.RANGE))).thenReturn(new Size2D(300.0, 100.0));
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertEquals(300.0, result.getWidth(), 0.001);
        assertEquals(400.0, result.getHeight(), 0.001);
        
        // Verify bounds
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 300.0, 100.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 300.0, 300.0, 100.0));
    }
}