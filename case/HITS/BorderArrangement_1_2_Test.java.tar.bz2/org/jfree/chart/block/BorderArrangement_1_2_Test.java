package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_1_2_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
        
        // Mock the container's behavior to return the same constraint
        when(container.toContentConstraint(any(RectangleConstraint.class)))
            .thenAnswer(invocation -> invocation.getArgument(0));
        when(container.calculateTotalWidth(any(Double.class)))
            .thenAnswer(invocation -> invocation.getArgument(0));
        when(container.calculateTotalHeight(any(Double.class)))
            .thenAnswer(invocation -> invocation.getArgument(0));
    }

    @Test
    public void testArrangeFF_OnlyBottomBlock() {
        Block bottomBlock = mock(Block.class);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        
        // Create proper FIXED-FIXED constraint
        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
        
        // Mock the bottom block arrangement
        when(bottomBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(100.0, 40.0));
        
        // Test through the public arrange method which will call arrangeFF internally
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        
        // Verify the bottom block bounds were set correctly
        verify(bottomBlock).setBounds(any(Rectangle2D.class));
    }

    @Test
    public void testArrangeFF_WithCenterBlock() {
        Block centerBlock = mock(Block.class);
        arrangement.add(centerBlock, null); // null key for center block
        
        RectangleConstraint constraint = new RectangleConstraint(150.0, 180.0);
        
        // Mock the center block arrangement
        when(centerBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(150.0, 180.0));
        
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(150.0, result.getWidth(), 0.001);
        assertEquals(180.0, result.getHeight(), 0.001);
        
        // Verify the center block bounds were set correctly
        verify(centerBlock).setBounds(any(Rectangle2D.class));
    }

    @Test
    public void testArrangeFF_WithTopAndBottomBlocks() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        
        RectangleConstraint constraint = new RectangleConstraint(200.0, 300.0);
        
        // Mock the arrangements
        when(topBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(200.0, 50.0));
        when(bottomBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(200.0, 60.0));
        
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(200.0, result.getWidth(), 0.001);
        assertEquals(300.0, result.getHeight(), 0.001);
        
        // Verify both blocks' bounds were set correctly
        verify(topBlock).setBounds(any(Rectangle2D.class));
        verify(bottomBlock).setBounds(any(Rectangle2D.class));
    }

    @Test
    public void testArrangeFF_WithLeftAndRightBlocks() {
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        
        RectangleConstraint constraint = new RectangleConstraint(250.0, 200.0);
        
        // Mock the arrangements
        when(leftBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(60.0, 200.0));
        when(rightBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(70.0, 200.0));
        
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(250.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        
        // Verify both blocks' bounds were set correctly
        verify(leftBlock).setBounds(any(Rectangle2D.class));
        verify(rightBlock).setBounds(any(Rectangle2D.class));
    }

    @Test
    public void testArrangeFF_WithAllBlocks() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);
        
        RectangleConstraint constraint = new RectangleConstraint(300.0, 400.0);
        
        // Mock the arrangements
        when(topBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(300.0, 50.0));
        when(bottomBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(300.0, 60.0));
        when(leftBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(80.0, 290.0));
        when(rightBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(70.0, 290.0));
        when(centerBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(150.0, 290.0));
        
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(300.0, result.getWidth(), 0.001);
        assertEquals(400.0, result.getHeight(), 0.001);
        
        // Verify all blocks' bounds were set correctly
        verify(topBlock).setBounds(any(Rectangle2D.class));
        verify(bottomBlock).setBounds(any(Rectangle2D.class));
        verify(leftBlock).setBounds(any(Rectangle2D.class));
        verify(rightBlock).setBounds(any(Rectangle2D.class));
        verify(centerBlock).setBounds(any(Rectangle2D.class));
    }
}