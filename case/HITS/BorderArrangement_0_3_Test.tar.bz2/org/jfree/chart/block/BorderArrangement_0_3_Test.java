package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_0_3_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_LeftAndRightBlocksOnly() {
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);

        when(leftBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 200.0), LengthConstraintType.RANGE, 200.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(40.0, 200.0));
        when(rightBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 160.0), LengthConstraintType.RANGE, 200.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(30.0, 200.0));

        RectangleConstraint constraint = new RectangleConstraint(200.0, 200.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);

        assertNotNull(result);
        assertEquals(200.0, result.getWidth(), 0.0);
        assertEquals(200.0, result.getHeight(), 0.0);
    }
}