package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_0_6_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_WithZeroHeightConstraint() {
        Block topBlock = mock(Block.class);
        arrangement.add(topBlock, RectangleEdge.TOP);

        RectangleConstraint constraint = new RectangleConstraint(100.0, 0.0);
        RectangleConstraint contentConstraint = new RectangleConstraint(100.0, 0.0);
        
        when(container.toContentConstraint(constraint)).thenReturn(contentConstraint);
        when(container.calculateTotalWidth(100.0)).thenReturn(100.0);
        when(container.calculateTotalHeight(0.0)).thenReturn(0.0);

        when(topBlock.arrange(g2, 
            new RectangleConstraint(100.0, null,
                LengthConstraintType.FIXED, 0.0,
                new Range(0.0, 0.0),
                LengthConstraintType.RANGE)))
            .thenReturn(new Size2D(100.0, 0.0));

        Size2D result = arrangement.arrange(container, g2, constraint);

        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.0);
        assertEquals(0.0, result.getHeight(), 0.0);
        
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 0.0));
    }

    @Test
    public void testArrangeFF_WithAllBlocks() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);

        RectangleConstraint constraint = new RectangleConstraint(200.0, 150.0);
        RectangleConstraint contentConstraint = new RectangleConstraint(200.0, 150.0);
        
        when(container.toContentConstraint(constraint)).thenReturn(contentConstraint);
        when(container.calculateTotalWidth(200.0)).thenReturn(200.0);
        when(container.calculateTotalHeight(150.0)).thenReturn(150.0);

        when(topBlock.arrange(g2, 
            new RectangleConstraint(200.0, null, 
                LengthConstraintType.FIXED, 0.0,
                new Range(0.0, 150.0), 
                LengthConstraintType.RANGE)))
            .thenReturn(new Size2D(200.0, 20.0));
        
        when(bottomBlock.arrange(g2, 
            new RectangleConstraint(200.0, null, 
                LengthConstraintType.FIXED, 0.0,
                new Range(0.0, 130.0), 
                LengthConstraintType.RANGE)))
            .thenReturn(new Size2D(200.0, 15.0));
        
        when(leftBlock.arrange(g2, 
            new RectangleConstraint(0.0, 
                new Range(0.0, 200.0), 
                LengthConstraintType.RANGE, 115.0, null,
                LengthConstraintType.FIXED)))
            .thenReturn(new Size2D(30.0, 115.0));
        
        when(rightBlock.arrange(g2, 
            new RectangleConstraint(0.0, 
                new Range(0.0, 170.0), 
                LengthConstraintType.RANGE, 115.0, null,
                LengthConstraintType.FIXED)))
            .thenReturn(new Size2D(25.0, 115.0));

        when(centerBlock.arrange(g2, 
            new RectangleConstraint(145.0, 115.0)))
            .thenReturn(new Size2D(145.0, 115.0));

        Size2D result = arrangement.arrange(container, g2, constraint);

        assertNotNull(result);
        assertEquals(200.0, result.getWidth(), 0.0);
        assertEquals(150.0, result.getHeight(), 0.0);
        
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 200.0, 20.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 135.0, 200.0, 15.0));
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 20.0, 30.0, 115.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(175.0, 20.0, 25.0, 115.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(30.0, 20.0, 145.0, 115.0));
    }

    @Test
    public void testArrangeFF_WithOnlyCenterBlock() {
        Block centerBlock = mock(Block.class);
        arrangement.add(centerBlock, null);

        RectangleConstraint constraint = new RectangleConstraint(300.0, 200.0);
        RectangleConstraint contentConstraint = new RectangleConstraint(300.0, 200.0);
        
        when(container.toContentConstraint(constraint)).thenReturn(contentConstraint);
        when(container.calculateTotalWidth(300.0)).thenReturn(300.0);
        when(container.calculateTotalHeight(200.0)).thenReturn(200.0);

        when(centerBlock.arrange(g2, 
            new RectangleConstraint(300.0, 200.0)))
            .thenReturn(new Size2D(300.0, 200.0));

        Size2D result = arrangement.arrange(container, g2, constraint);

        assertNotNull(result);
        assertEquals(300.0, result.getWidth(), 0.0);
        assertEquals(200.0, result.getHeight(), 0.0);
        
        verify(centerBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 300.0, 200.0));
    }

    @Test
    public void testArrangeFF_WithTopAndBottomBlocksOnly() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);

        RectangleConstraint constraint = new RectangleConstraint(250.0, 180.0);
        RectangleConstraint contentConstraint = new RectangleConstraint(250.0, 180.0);
        
        when(container.toContentConstraint(constraint)).thenReturn(contentConstraint);
        when(container.calculateTotalWidth(250.0)).thenReturn(250.0);
        when(container.calculateTotalHeight(180.0)).thenReturn(180.0);

        when(topBlock.arrange(g2, 
            new RectangleConstraint(250.0, null, 
                LengthConstraintType.FIXED, 0.0,
                new Range(0.0, 180.0), 
                LengthConstraintType.RANGE)))
            .thenReturn(new Size2D(250.0, 40.0));
        
        when(bottomBlock.arrange(g2, 
            new RectangleConstraint(250.0, null, 
                LengthConstraintType.FIXED, 0.0,
                new Range(0.0, 140.0), 
                LengthConstraintType.RANGE)))
            .thenReturn(new Size2D(250.0, 35.0));

        Size2D result = arrangement.arrange(container, g2, constraint);

        assertNotNull(result);
        assertEquals(250.0, result.getWidth(), 0.0);
        assertEquals(180.0, result.getHeight(), 0.0);
        
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 250.0, 40.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 145.0, 250.0, 35.0));
    }

    @Test
    public void testArrangeFF_WithLeftAndRightBlocksOnly() {
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);

        RectangleConstraint constraint = new RectangleConstraint(400.0, 300.0);
        RectangleConstraint contentConstraint = new RectangleConstraint(400.0, 300.0);
        
        when(container.toContentConstraint(constraint)).thenReturn(contentConstraint);
        when(container.calculateTotalWidth(400.0)).thenReturn(400.0);
        when(container.calculateTotalHeight(300.0)).thenReturn(300.0);

        when(leftBlock.arrange(g2, 
            new RectangleConstraint(0.0, 
                new Range(0.0, 400.0), 
                LengthConstraintType.RANGE, 300.0, null,
                LengthConstraintType.FIXED)))
            .thenReturn(new Size2D(50.0, 300.0));
        
        when(rightBlock.arrange(g2, 
            new RectangleConstraint(0.0, 
                new Range(0.0, 350.0), 
                LengthConstraintType.RANGE, 300.0, null,
                LengthConstraintType.FIXED)))
            .thenReturn(new Size2D(60.0, 300.0));

        when(centerBlock.arrange(g2, 
            new RectangleConstraint(290.0, 300.0)))
            .thenReturn(new Size2D(290.0, 300.0));

        Size2D result = arrangement.arrange(container, g2, constraint);

        assertNotNull(result);
        assertEquals(400.0, result.getWidth(), 0.0);
        assertEquals(300.0, result.getHeight(), 0.0);
        
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 50.0, 300.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(340.0, 0.0, 60.0, 300.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(50.0, 0.0, 290.0, 300.0));
    }
}