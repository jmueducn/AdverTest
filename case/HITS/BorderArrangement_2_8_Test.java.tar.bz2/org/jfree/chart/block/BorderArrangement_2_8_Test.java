package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_2_8_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_AllBlocksPresent() {
        Block topBlock = mock(Block.class);
        when(topBlock.arrange(g2, new RectangleConstraint(100.0, null,
                LengthConstraintType.FIXED, 0.0,
                new Range(0.0, 50.0), LengthConstraintType.RANGE)))
                .thenReturn(new Size2D(100.0, 10.0));
        
        Block bottomBlock = mock(Block.class);
        when(bottomBlock.arrange(g2, new RectangleConstraint(100.0, null,
                LengthConstraintType.FIXED, 0.0,
                new Range(0.0, 40.0), LengthConstraintType.RANGE)))
                .thenReturn(new Size2D(100.0, 15.0));
        
        Block leftBlock = mock(Block.class);
        when(leftBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 100.0), LengthConstraintType.RANGE,
                25.0, null, LengthConstraintType.FIXED)))
                .thenReturn(new Size2D(20.0, 25.0));
        
        Block rightBlock = mock(Block.class);
        when(rightBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 80.0), LengthConstraintType.RANGE,
                25.0, null, LengthConstraintType.FIXED)))
                .thenReturn(new Size2D(25.0, 25.0));
        
        Block centerBlock = mock(Block.class);
        when(centerBlock.arrange(g2, new RectangleConstraint(55.0, 25.0)))
                .thenReturn(new Size2D(55.0, 25.0));
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);
        
        RectangleConstraint constraint = new RectangleConstraint(100.0, 50.0);
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(50.0, result.getHeight(), 0.001);
    }
}