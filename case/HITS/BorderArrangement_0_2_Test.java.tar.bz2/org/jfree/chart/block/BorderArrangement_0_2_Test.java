package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.jfree.chart.util.RectangleEdge.TOP;
import static org.jfree.chart.util.RectangleEdge.BOTTOM;
import static org.jfree.chart.util.RectangleEdge.LEFT;
import static org.jfree.chart.util.RectangleEdge.RIGHT;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_0_2_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_TopAndBottomBlocksOnly() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        
        arrangement.add(topBlock, TOP);
        arrangement.add(bottomBlock, BOTTOM);

        when(topBlock.arrange(g2, new RectangleConstraint(80.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 120.0),
                LengthConstraintType.RANGE))).thenReturn(new Size2D(80.0, 25.0));
        when(bottomBlock.arrange(g2, new RectangleConstraint(80.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 95.0),
                LengthConstraintType.RANGE))).thenReturn(new Size2D(80.0, 35.0));

        RectangleConstraint constraint = new RectangleConstraint(80.0, 120.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);

        assertNotNull(result);
        assertEquals(80.0, result.getWidth(), 0.0);
        assertEquals(120.0, result.getHeight(), 0.0);
        
        // Verify that the blocks have their bounds set correctly
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 80.0, 25.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 85.0, 80.0, 35.0));
    }

    @Test
    public void testArrangeFF_AllBlocks() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        arrangement.add(topBlock, TOP);
        arrangement.add(bottomBlock, BOTTOM);
        arrangement.add(leftBlock, LEFT);
        arrangement.add(rightBlock, RIGHT);
        arrangement.add(centerBlock, null);

        when(topBlock.arrange(g2, new RectangleConstraint(100.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 150.0),
                LengthConstraintType.RANGE))).thenReturn(new Size2D(100.0, 20.0));
        when(bottomBlock.arrange(g2, new RectangleConstraint(100.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 130.0),
                LengthConstraintType.RANGE))).thenReturn(new Size2D(100.0, 30.0));
        when(leftBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 100.0), LengthConstraintType.RANGE, 100.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(15.0, 100.0));
        when(rightBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 85.0), LengthConstraintType.RANGE, 100.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(20.0, 100.0));
        when(centerBlock.arrange(g2, new RectangleConstraint(65.0, 100.0)))
                .thenReturn(new Size2D(65.0, 100.0));

        RectangleConstraint constraint = new RectangleConstraint(100.0, 150.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);

        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.0);
        assertEquals(150.0, result.getHeight(), 0.0);
        
        // Verify bounds for all blocks
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 20.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 120.0, 100.0, 30.0));
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 20.0, 15.0, 100.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(80.0, 20.0, 20.0, 100.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(15.0, 20.0, 65.0, 100.0));
    }

    @Test
    public void testArrangeFF_NoBlocks() {
        RectangleConstraint constraint = new RectangleConstraint(100.0, 150.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);

        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.0);
        assertEquals(150.0, result.getHeight(), 0.0);
    }

    @Test
    public void testArrangeFF_OnlyCenterBlock() {
        Block centerBlock = mock(Block.class);
        
        arrangement.add(centerBlock, null);

        when(centerBlock.arrange(g2, new RectangleConstraint(100.0, 150.0)))
                .thenReturn(new Size2D(100.0, 150.0));

        RectangleConstraint constraint = new RectangleConstraint(100.0, 150.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);

        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.0);
        assertEquals(150.0, result.getHeight(), 0.0);
        
        verify(centerBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 150.0));
    }
}