package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_3_6_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_ZeroWidthConstraint() {
        Block topBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        RectangleConstraint constraint = new RectangleConstraint(0.0, 300.0);
        
        // Mock arrangements for blocks
        when(topBlock.arrange(g2, new RectangleConstraint(0.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 300.0),
                LengthConstraintType.RANGE))).thenReturn(new Size2D(0.0, 50.0));
        
        when(leftBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 0.0), LengthConstraintType.RANGE, 250.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(0.0, 250.0));
        
        when(centerBlock.arrange(g2, new RectangleConstraint(0.0, 250.0)))
                .thenReturn(new Size2D(0.0, 250.0));
        
        // Add blocks to arrangement
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(centerBlock, null);
        
        Size2D result = arrangement.arrangeFF(container, g2, constraint);
        
        // Verify the result size
        assertEquals(0.0, result.getWidth(), 0.001);
        assertEquals(300.0, result.getHeight(), 0.001);
        
        // Verify that setBounds was called with correct parameters
        topBlock.setBounds(new Rectangle2D.Double(0.0, 0.0, 0.0, 50.0));
        leftBlock.setBounds(new Rectangle2D.Double(0.0, 50.0, 0.0, 250.0));
        centerBlock.setBounds(new Rectangle2D.Double(0.0, 50.0, 0.0, 250.0));
    }

    @Test
    public void testArrangeFF_WithAllBlocks() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        RectangleConstraint constraint = new RectangleConstraint(400.0, 500.0);
        
        // Mock arrangements for all blocks
        when(topBlock.arrange(g2, new RectangleConstraint(400.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 500.0),
                LengthConstraintType.RANGE))).thenReturn(new Size2D(400.0, 50.0));
        
        when(bottomBlock.arrange(g2, new RectangleConstraint(400.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 450.0),
                LengthConstraintType.RANGE))).thenReturn(new Size2D(400.0, 50.0));
        
        when(leftBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 400.0), LengthConstraintType.RANGE, 400.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(100.0, 400.0));
        
        when(rightBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 300.0), LengthConstraintType.RANGE, 400.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(100.0, 400.0));
        
        when(centerBlock.arrange(g2, new RectangleConstraint(200.0, 400.0)))
                .thenReturn(new Size2D(200.0, 400.0));
        
        // Add all blocks to arrangement
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);
        
        Size2D result = arrangement.arrangeFF(container, g2, constraint);
        
        // Verify the result size
        assertEquals(400.0, result.getWidth(), 0.001);
        assertEquals(500.0, result.getHeight(), 0.001);
        
        // Verify that setBounds was called with correct parameters
        topBlock.setBounds(new Rectangle2D.Double(0.0, 0.0, 400.0, 50.0));
        bottomBlock.setBounds(new Rectangle2D.Double(0.0, 450.0, 400.0, 50.0));
        leftBlock.setBounds(new Rectangle2D.Double(0.0, 50.0, 100.0, 400.0));
        rightBlock.setBounds(new Rectangle2D.Double(300.0, 50.0, 100.0, 400.0));
        centerBlock.setBounds(new Rectangle2D.Double(100.0, 50.0, 200.0, 400.0));
    }
}