package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_2_2_Test {

    private BorderArrangement arrangement;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_OnlyBottomBlock() {
        Block bottomBlock = mock(Block.class);
        
        // Mock the arrange method for bottom block
        RectangleConstraint expectedConstraint = new RectangleConstraint(100.0, null,
                LengthConstraintType.FIXED, 0.0, 
                new Range(0.0, 50.0), LengthConstraintType.RANGE);
        when(bottomBlock.arrange(g2, expectedConstraint))
                .thenReturn(new Size2D(100.0, 15.0));
        
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        
        // Create constraint with FIXED width and FIXED height
        RectangleConstraint constraint = new RectangleConstraint(100.0, 50.0);
        
        // Call arrangeFF directly
        Size2D result = arrangement.arrangeFF(null, g2, constraint);
        
        // Verify results
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(50.0, result.getHeight(), 0.001);
        
        // Verify bottom block was positioned correctly
        // y = h[0] + h[2] = 0 + (50 - 0 - 15) = 35
        // height = h[1] = 15
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 35.0, 100.0, 15.0));
    }
}