package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_3_4_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_TopBottomLeftRightBlocks() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        RectangleConstraint constraint = new RectangleConstraint(500.0, 400.0);
        
        when(topBlock.arrange(g2, new RectangleConstraint(500.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 400.0),
                LengthConstraintType.RANGE))).thenReturn(new Size2D(500.0, 70.0));
        
        when(bottomBlock.arrange(g2, new RectangleConstraint(500.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 330.0),
                LengthConstraintType.RANGE))).thenReturn(new Size2D(500.0, 60.0));
        
        when(leftBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 500.0), LengthConstraintType.RANGE, 270.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(100.0, 270.0));
        
        when(rightBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 400.0), LengthConstraintType.RANGE, 270.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(95.0, 270.0));
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        
        Size2D result = arrangement.arrangeFF(container, g2, constraint);
        
        assertEquals(500.0, result.getWidth(), 0.001);
        assertEquals(400.0, result.getHeight(), 0.001);
    }
}