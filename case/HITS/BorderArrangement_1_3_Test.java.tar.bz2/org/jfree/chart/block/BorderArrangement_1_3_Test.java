package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.lang.reflect.Method;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_1_3_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_OnlyLeftBlock() throws Exception {
        Block leftBlock = mock(Block.class);
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        
        // Create a proper RectangleConstraint with fixed width and height
        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
        
        // Mock the left block arrangement
        // In arrangeFF, for left block: height is constraint.getHeight() - h[1] - h[0]
        // Since no top or bottom blocks, h[0] = 0, h[1] = 0, so height = 200.0
        RectangleConstraint expectedConstraint = new RectangleConstraint(0.0,
                new Range(0.0, 100.0), 
                LengthConstraintType.RANGE, 
                200.0, 
                null,
                LengthConstraintType.FIXED);
        when(leftBlock.arrange(g2, expectedConstraint)).thenReturn(new Size2D(30.0, 200.0));
        
        // Use reflection to access protected arrangeFF method
        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
            "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
        arrangeFFMethod.setAccessible(true);
        
        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
    }

    @Test
    public void testArrangeFF_WithTopAndLeftBlocks() throws Exception {
        Block topBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        
        RectangleConstraint constraint = new RectangleConstraint(150.0, 300.0);
        
        // Mock top block arrangement - it should take some height
        RectangleConstraint topConstraint = new RectangleConstraint(150.0, null,
                LengthConstraintType.FIXED, 0.0,
                new Range(0.0, 300.0), LengthConstraintType.RANGE);
        when(topBlock.arrange(g2, topConstraint)).thenReturn(new Size2D(150.0, 50.0));
        
        // Mock left block arrangement - height should be total height minus top height
        // h[2] = constraint.getHeight() - h[1] - h[0] = 300 - 0 - 50 = 250
        RectangleConstraint leftConstraint = new RectangleConstraint(0.0,
                new Range(0.0, 150.0), 
                LengthConstraintType.RANGE, 
                250.0, 
                null,
                LengthConstraintType.FIXED);
        when(leftBlock.arrange(g2, leftConstraint)).thenReturn(new Size2D(40.0, 250.0));
        
        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
            "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
        arrangeFFMethod.setAccessible(true);
        
        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(150.0, result.getWidth(), 0.001);
        assertEquals(300.0, result.getHeight(), 0.001);
    }

    @Test
    public void testArrangeFF_WithAllBlocks() throws Exception {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);
        
        RectangleConstraint constraint = new RectangleConstraint(200.0, 400.0);
        
        // Mock top block
        RectangleConstraint topConstraint = new RectangleConstraint(200.0, null,
                LengthConstraintType.FIXED, 0.0,
                new Range(0.0, 400.0), LengthConstraintType.RANGE);
        when(topBlock.arrange(g2, topConstraint)).thenReturn(new Size2D(200.0, 60.0));
        
        // Mock bottom block - available height is 400 - 60 = 340
        RectangleConstraint bottomConstraint = new RectangleConstraint(200.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 340.0), 
                LengthConstraintType.RANGE);
        when(bottomBlock.arrange(g2, bottomConstraint)).thenReturn(new Size2D(200.0, 40.0));
        
        // Center height = 400 - 60 - 40 = 300
        // Mock left block
        RectangleConstraint leftConstraint = new RectangleConstraint(0.0,
                new Range(0.0, 200.0), 
                LengthConstraintType.RANGE, 
                300.0, 
                null,
                LengthConstraintType.FIXED);
        when(leftBlock.arrange(g2, leftConstraint)).thenReturn(new Size2D(50.0, 300.0));
        
        // Mock right block - available width is max(200 - 50, 0) = 150
        RectangleConstraint rightConstraint = new RectangleConstraint(0.0,
                new Range(0.0, 150.0), 
                LengthConstraintType.RANGE, 
                300.0, 
                null,
                LengthConstraintType.FIXED);
        when(rightBlock.arrange(g2, rightConstraint)).thenReturn(new Size2D(40.0, 300.0));
        
        // Center block gets remaining space: width = 200 - 50 - 40 = 110, height = 300
        RectangleConstraint centerConstraint = new RectangleConstraint(110.0, 300.0);
        when(centerBlock.arrange(g2, centerConstraint)).thenReturn(new Size2D(110.0, 300.0));
        
        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
            "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
        arrangeFFMethod.setAccessible(true);
        
        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(200.0, result.getWidth(), 0.001);
        assertEquals(400.0, result.getHeight(), 0.001);
    }
}