package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_3_2_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_TopAndBottomBlocksOnly() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        RectangleConstraint constraint = new RectangleConstraint(400.0, 300.0);
        
        // Mock the arrange calls for top and bottom blocks
        when(topBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(400.0, 60.0));
        when(bottomBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(400.0, 50.0));
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        
        // Call the public arrange method instead of the protected arrangeFF
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        // Verify the result
        assertEquals(400.0, result.getWidth(), 0.001);
        assertEquals(300.0, result.getHeight(), 0.001);
        
        // Verify that the blocks were properly positioned
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 400.0, 60.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 240.0, 400.0, 50.0));
    }
}