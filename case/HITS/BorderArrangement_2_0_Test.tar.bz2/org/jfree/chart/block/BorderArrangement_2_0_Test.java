package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_2_0_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_AllBlocksNull() {
        RectangleConstraint constraint = new RectangleConstraint(100.0, 50.0);
        when(container.toContentConstraint(constraint)).thenReturn(constraint);
        
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(50.0, result.getHeight(), 0.001);
    }

    @Test
    public void testArrangeFF_WithTopBlock() {
        Block topBlock = mock(Block.class);
        when(topBlock.arrange(g2, org.mockito.ArgumentMatchers.any(RectangleConstraint.class)))
            .thenReturn(new Size2D(100.0, 20.0));
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        
        RectangleConstraint constraint = new RectangleConstraint(100.0, 50.0);
        when(container.toContentConstraint(constraint)).thenReturn(constraint);
        
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(50.0, result.getHeight(), 0.001);
        
        // Verify top block bounds
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 20.0));
    }

    @Test
    public void testArrangeFF_WithBottomBlock() {
        Block bottomBlock = mock(Block.class);
        when(bottomBlock.arrange(g2, org.mockito.ArgumentMatchers.any(RectangleConstraint.class)))
            .thenReturn(new Size2D(100.0, 15.0));
        
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        
        RectangleConstraint constraint = new RectangleConstraint(100.0, 50.0);
        when(container.toContentConstraint(constraint)).thenReturn(constraint);
        
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(50.0, result.getHeight(), 0.001);
        
        // Verify bottom block bounds
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 35.0, 100.0, 15.0));
    }

    @Test
    public void testArrangeFF_WithLeftBlock() {
        Block leftBlock = mock(Block.class);
        when(leftBlock.arrange(g2, org.mockito.ArgumentMatchers.any(RectangleConstraint.class)))
            .thenReturn(new Size2D(30.0, 25.0));
        
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        
        RectangleConstraint constraint = new RectangleConstraint(100.0, 50.0);
        when(container.toContentConstraint(constraint)).thenReturn(constraint);
        
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(50.0, result.getHeight(), 0.001);
        
        // Verify left block bounds
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 30.0, 25.0));
    }

    @Test
    public void testArrangeFF_WithRightBlock() {
        Block rightBlock = mock(Block.class);
        when(rightBlock.arrange(g2, org.mockito.ArgumentMatchers.any(RectangleConstraint.class)))
            .thenReturn(new Size2D(25.0, 25.0));
        
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        
        RectangleConstraint constraint = new RectangleConstraint(100.0, 50.0);
        when(container.toContentConstraint(constraint)).thenReturn(constraint);
        
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(50.0, result.getHeight(), 0.001);
        
        // Verify right block bounds
        verify(rightBlock).setBounds(new Rectangle2D.Double(75.0, 0.0, 25.0, 25.0));
    }

    @Test
    public void testArrangeFF_WithCenterBlock() {
        Block centerBlock = mock(Block.class);
        when(centerBlock.arrange(g2, org.mockito.ArgumentMatchers.any(RectangleConstraint.class)))
            .thenReturn(new Size2D(50.0, 25.0));
        
        arrangement.add(centerBlock, null);
        
        RectangleConstraint constraint = new RectangleConstraint(100.0, 50.0);
        when(container.toContentConstraint(constraint)).thenReturn(constraint);
        
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(50.0, result.getHeight(), 0.001);
        
        // Verify center block bounds
        verify(centerBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 50.0, 25.0));
    }

    @Test
    public void testArrangeFF_WithAllBlocks() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        when(topBlock.arrange(g2, org.mockito.ArgumentMatchers.any(RectangleConstraint.class)))
            .thenReturn(new Size2D(100.0, 10.0));
        when(bottomBlock.arrange(g2, org.mockito.ArgumentMatchers.any(RectangleConstraint.class)))
            .thenReturn(new Size2D(100.0, 10.0));
        when(leftBlock.arrange(g2, org.mockito.ArgumentMatchers.any(RectangleConstraint.class)))
            .thenReturn(new Size2D(20.0, 30.0));
        when(rightBlock.arrange(g2, org.mockito.ArgumentMatchers.any(RectangleConstraint.class)))
            .thenReturn(new Size2D(20.0, 30.0));
        when(centerBlock.arrange(g2, org.mockito.ArgumentMatchers.any(RectangleConstraint.class)))
            .thenReturn(new Size2D(60.0, 30.0));
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);
        
        RectangleConstraint constraint = new RectangleConstraint(100.0, 50.0);
        when(container.toContentConstraint(constraint)).thenReturn(constraint);
        
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(50.0, result.getHeight(), 0.001);
        
        // Verify all block bounds
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 10.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 40.0, 100.0, 10.0));
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 10.0, 20.0, 30.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(80.0, 10.0, 20.0, 30.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(20.0, 10.0, 60.0, 30.0));
    }
}