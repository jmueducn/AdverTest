package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_1_10_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_TopAndBottomExceedAvailableHeight() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        
        RectangleConstraint constraint = new RectangleConstraint(100.0, 50.0);
        when(topBlock.arrange(g2, new RectangleConstraint(100.0, null,
                LengthConstraintType.FIXED, 0.0,
                new Range(0.0, 50.0), LengthConstraintType.RANGE)))
                .thenReturn(new Size2D(100.0, 30.0));
        when(bottomBlock.arrange(g2, new RectangleConstraint(100.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 20.0),
                LengthConstraintType.RANGE))).thenReturn(new Size2D(100.0, 20.0));
        
        Size2D result = arrangement.arrangeFF(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(50.0, result.getHeight(), 0.001);
        
        // Verify block bounds
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 30.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 50.0, 100.0, 20.0));
    }

    @Test
    public void testArrangeFF_WithAllBlocks() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);
        
        RectangleConstraint constraint = new RectangleConstraint(200.0, 150.0);
        
        // Mock arrangements
        when(topBlock.arrange(g2, new RectangleConstraint(200.0, null,
                LengthConstraintType.FIXED, 0.0,
                new Range(0.0, 150.0), LengthConstraintType.RANGE)))
                .thenReturn(new Size2D(200.0, 30.0));
        when(bottomBlock.arrange(g2, new RectangleConstraint(200.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 120.0),
                LengthConstraintType.RANGE))).thenReturn(new Size2D(200.0, 25.0));
        when(leftBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 200.0), LengthConstraintType.RANGE, 95.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(40.0, 95.0));
        when(rightBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 160.0), LengthConstraintType.RANGE, 95.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(50.0, 95.0));
        when(centerBlock.arrange(g2, new RectangleConstraint(110.0, 95.0)))
                .thenReturn(new Size2D(110.0, 95.0));
        
        Size2D result = arrangement.arrangeFF(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(200.0, result.getWidth(), 0.001);
        assertEquals(150.0, result.getHeight(), 0.001);
        
        // Verify block bounds
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 200.0, 30.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 125.0, 200.0, 25.0));
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 30.0, 40.0, 95.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(150.0, 30.0, 50.0, 95.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(40.0, 30.0, 110.0, 95.0));
    }

    @Test
    public void testArrangeFF_OnlyCenterBlock() {
        Block centerBlock = mock(Block.class);
        arrangement.add(centerBlock, null);
        
        RectangleConstraint constraint = new RectangleConstraint(300.0, 200.0);
        
        when(centerBlock.arrange(g2, new RectangleConstraint(300.0, 200.0)))
                .thenReturn(new Size2D(300.0, 200.0));
        
        Size2D result = arrangement.arrangeFF(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(300.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        
        verify(centerBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 300.0, 200.0));
    }
}