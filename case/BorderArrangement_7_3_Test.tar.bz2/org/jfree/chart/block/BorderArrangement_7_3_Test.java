package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Method;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_7_3_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_OnlyLeftBlock() throws Exception {
        Block leftBlock = mock(Block.class);
        arrangement.add(leftBlock, RectangleEdge.LEFT);

        // Use reflection to access the protected arrangeFF method
        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
            "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
        arrangeFFMethod.setAccessible(true);

        // Mock the arrange method with any constraint
        when(leftBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(30.0, 200.0));

        RectangleConstraint constraint = new RectangleConstraint(200.0, 200.0);
        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);

        assertEquals(200.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        
        // Verify that the left block bounds are set correctly
        // With only left block: x=0.0, y=0.0 (no top block), width=30.0, height=200.0
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 30.0, 200.0));
    }

    @Test
    public void testArrangeFF_WithTopAndLeftBlocks() throws Exception {
        Block topBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(leftBlock, RectangleEdge.LEFT);

        // Use reflection to access the protected arrangeFF method
        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
            "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
        arrangeFFMethod.setAccessible(true);

        // Mock arrange methods
        when(topBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(200.0, 50.0));
        when(leftBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(40.0, 150.0));

        RectangleConstraint constraint = new RectangleConstraint(200.0, 200.0);
        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);

        assertEquals(200.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        
        // Verify bounds
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 200.0, 50.0));
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 50.0, 40.0, 150.0));
    }

    @Test
    public void testArrangeFF_WithCenterBlock() throws Exception {
        Block centerBlock = mock(Block.class);
        arrangement.add(centerBlock, null);

        // Use reflection to access the protected arrangeFF method
        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
            "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
        arrangeFFMethod.setAccessible(true);

        // Mock arrange method for center block
        when(centerBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(200.0, 200.0));

        RectangleConstraint constraint = new RectangleConstraint(200.0, 200.0);
        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);

        assertEquals(200.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        
        // Verify center block bounds - should fill entire area when no other blocks
        verify(centerBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 200.0, 200.0));
    }

    @Test
    public void testArrangeFF_WithAllBlocks() throws Exception {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);

        // Use reflection to access the protected arrangeFF method
        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
            "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
        arrangeFFMethod.setAccessible(true);

        // Mock arrange methods
        when(topBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(200.0, 30.0));
        when(bottomBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(200.0, 20.0));
        when(leftBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(40.0, 150.0));
        when(rightBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(35.0, 150.0));
        when(centerBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
            .thenReturn(new Size2D(125.0, 150.0));

        RectangleConstraint constraint = new RectangleConstraint(200.0, 200.0);
        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);

        assertEquals(200.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        
        // Verify bounds for all blocks
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 200.0, 30.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 180.0, 200.0, 20.0));
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 30.0, 40.0, 150.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(165.0, 30.0, 35.0, 150.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(40.0, 30.0, 125.0, 150.0));
    }
}