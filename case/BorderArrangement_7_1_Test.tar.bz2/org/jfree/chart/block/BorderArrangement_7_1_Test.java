package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_7_1_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
    }

    @Test
    public void testArrangeFF_OnlyTopBlock() {
        Block topBlock = mock(Block.class);
        arrangement.add(topBlock, org.jfree.chart.util.RectangleEdge.TOP);

        // Mock the arrange method for top block with correct RectangleConstraint
        RectangleConstraint topConstraint = new RectangleConstraint(150.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 300.0),
                LengthConstraintType.RANGE);
        when(topBlock.arrange(null, topConstraint)).thenReturn(new Size2D(150.0, 50.0));

        // Mock container's toContentConstraint method
        RectangleConstraint constraint = new RectangleConstraint(150.0, 300.0);
        RectangleConstraint contentConstraint = new RectangleConstraint(150.0, 300.0);
        when(container.toContentConstraint(constraint)).thenReturn(contentConstraint);
        
        // Mock container's calculateTotalWidth and calculateTotalHeight methods
        when(container.calculateTotalWidth(150.0)).thenReturn(150.0);
        when(container.calculateTotalHeight(300.0)).thenReturn(300.0);

        // Call the public arrange method which will internally call arrangeFF
        // when both width and height constraints are FIXED
        Size2D result = arrangement.arrange(container, null, constraint);

        assertEquals(150.0, result.getWidth(), 0.001);
        assertEquals(300.0, result.getHeight(), 0.001);
    }

    @Test
    public void testArrangeFF_WithCenterBlock() {
        Block centerBlock = mock(Block.class);
        arrangement.add(centerBlock, null); // null key for center block

        RectangleConstraint constraint = new RectangleConstraint(200.0, 400.0);
        RectangleConstraint contentConstraint = new RectangleConstraint(200.0, 400.0);
        when(container.toContentConstraint(constraint)).thenReturn(contentConstraint);
        
        when(container.calculateTotalWidth(200.0)).thenReturn(200.0);
        when(container.calculateTotalHeight(400.0)).thenReturn(400.0);

        // Center block constraint in arrangeFF is RectangleConstraint(w[4], h[4])
        RectangleConstraint centerConstraint = new RectangleConstraint(200.0, 400.0);
        when(centerBlock.arrange(null, centerConstraint)).thenReturn(new Size2D(200.0, 400.0));

        Size2D result = arrangement.arrange(container, null, constraint);

        assertEquals(200.0, result.getWidth(), 0.001);
        assertEquals(400.0, result.getHeight(), 0.001);
    }

    @Test
    public void testArrangeFF_WithLeftAndRightBlocks() {
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        
        arrangement.add(leftBlock, org.jfree.chart.util.RectangleEdge.LEFT);
        arrangement.add(rightBlock, org.jfree.chart.util.RectangleEdge.RIGHT);

        RectangleConstraint constraint = new RectangleConstraint(300.0, 500.0);
        RectangleConstraint contentConstraint = new RectangleConstraint(300.0, 500.0);
        when(container.toContentConstraint(constraint)).thenReturn(contentConstraint);
        
        when(container.calculateTotalWidth(300.0)).thenReturn(300.0);
        when(container.calculateTotalHeight(500.0)).thenReturn(500.0);

        // Mock left block arrangement
        RectangleConstraint leftConstraint = new RectangleConstraint(0.0,
                new Range(0.0, 300.0), LengthConstraintType.RANGE, 500.0, null,
                LengthConstraintType.FIXED);
        when(leftBlock.arrange(null, leftConstraint)).thenReturn(new Size2D(80.0, 500.0));

        // Mock right block arrangement  
        RectangleConstraint rightConstraint = new RectangleConstraint(0.0,
                new Range(0.0, Math.max(300.0 - 80.0, 0.0)),
                LengthConstraintType.RANGE, 500.0, null,
                LengthConstraintType.FIXED);
        when(rightBlock.arrange(null, rightConstraint)).thenReturn(new Size2D(70.0, 500.0));

        Size2D result = arrangement.arrange(container, null, constraint);

        assertEquals(300.0, result.getWidth(), 0.001);
        assertEquals(500.0, result.getHeight(), 0.001);
    }
}