package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_8_5_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_TopAndLeftBlocks() {
        Block topBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);

        // Mock the arrange calls with correct RectangleConstraint constructors
        RectangleConstraint topConstraint = new RectangleConstraint(80.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 150.0), 
                LengthConstraintType.RANGE);
        when(topBlock.arrange(g2, topConstraint)).thenReturn(new Size2D(80.0, 25.0));
        
        RectangleConstraint leftConstraint = new RectangleConstraint(0.0,
                new Range(0.0, 80.0), LengthConstraintType.RANGE, 
                125.0, null, LengthConstraintType.FIXED);
        when(leftBlock.arrange(g2, leftConstraint)).thenReturn(new Size2D(20.0, 125.0));

        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(leftBlock, RectangleEdge.LEFT);

        // Create constraint with FIXED width and FIXED height to trigger arrangeFF
        RectangleConstraint constraint = new RectangleConstraint(80.0, 150.0);

        Size2D result = arrangement.arrange(container, g2, constraint);

        assertNotNull(result);
        assertEquals(80.0, result.getWidth(), 0.0);
        assertEquals(150.0, result.getHeight(), 0.0);

        // Verify that setBounds was called with correct parameters
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 80.0, 25.0));
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 25.0, 20.0, 125.0));
    }
}