package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.any;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_5_6_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        BufferedImage image = new BufferedImage(500, 500, BufferedImage.TYPE_INT_RGB);
        g2 = image.createGraphics();
    }

    @Test
    public void testArrangeFF_WithTopAndBottomBlocks() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);

        when(topBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                .thenReturn(new Size2D(100.0, 50.0));
        when(bottomBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                .thenReturn(new Size2D(100.0, 40.0));

        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
        
        Size2D result = arrangement.arrange(container, g2, constraint);

        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 50.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 50.0 + 110.0, 100.0, 40.0));
    }

    @Test
    public void testArrangeFF_WithAllBlocks() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);

        when(topBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                .thenReturn(new Size2D(200.0, 50.0));
        when(bottomBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                .thenReturn(new Size2D(200.0, 40.0));
        when(leftBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                .thenReturn(new Size2D(30.0, 210.0));
        when(rightBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                .thenReturn(new Size2D(40.0, 210.0));
        when(centerBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                .thenReturn(new Size2D(130.0, 210.0));

        RectangleConstraint constraint = new RectangleConstraint(200.0, 300.0);
        
        Size2D result = arrangement.arrange(container, g2, constraint);

        assertNotNull(result);
        assertEquals(200.0, result.getWidth(), 0.001);
        assertEquals(300.0, result.getHeight(), 0.001);
        
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 200.0, 50.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 50.0 + 210.0, 200.0, 40.0));
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 50.0, 30.0, 210.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(30.0 + 130.0, 50.0, 40.0, 210.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(30.0, 50.0, 130.0, 210.0));
    }

    @Test
    public void testArrangeFF_WithCenterBlockOnly() {
        Block centerBlock = mock(Block.class);
        
        arrangement.add(centerBlock, null);

        when(centerBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                .thenReturn(new Size2D(150.0, 200.0));

        RectangleConstraint constraint = new RectangleConstraint(150.0, 200.0);
        
        Size2D result = arrangement.arrange(container, g2, constraint);

        assertNotNull(result);
        assertEquals(150.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        
        verify(centerBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 150.0, 200.0));
    }

    @Test
    public void testArrangeFF_WithLeftAndRightBlocks() {
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);

        when(leftBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                .thenReturn(new Size2D(40.0, 200.0));
        when(rightBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                .thenReturn(new Size2D(50.0, 200.0));
        when(centerBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                .thenReturn(new Size2D(110.0, 200.0));

        RectangleConstraint constraint = new RectangleConstraint(200.0, 200.0);
        
        Size2D result = arrangement.arrange(container, g2, constraint);

        assertNotNull(result);
        assertEquals(200.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 40.0, 200.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(40.0 + 110.0, 0.0, 50.0, 200.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(40.0, 0.0, 110.0, 200.0));
    }
}