package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.lang.reflect.Method;

import org.jfree.chart.util.Size2D;
import org.jfree.chart.util.RectangleEdge;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_8_7_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_RightBlockWidthExceedsAvailableSpace() throws Exception {
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);

        when(leftBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 100.0), LengthConstraintType.RANGE, 100.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(60.0, 100.0));
        when(rightBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 40.0), LengthConstraintType.RANGE, 100.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(50.0, 100.0));

        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);

        RectangleConstraint constraint = new RectangleConstraint(100.0, 100.0);
        
        // Use reflection to access the protected arrangeFF method
        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
            "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
        arrangeFFMethod.setAccessible(true);
        
        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);

        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.0);
        assertEquals(100.0, result.getHeight(), 0.0);
    }
}