package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.awt.Graphics2D;
import java.lang.reflect.Method;

import org.jfree.chart.util.Size2D;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_8_4_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = new BlockContainer(new BorderArrangement());
    }

    @Test
    public void testArrangeFF_NoBlocks() throws Exception {
        RectangleConstraint constraint = new RectangleConstraint(100.0, 100.0);
        
        // Use reflection to access the protected arrangeFF method
        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
            "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
        arrangeFFMethod.setAccessible(true);
        
        // Pass null for Graphics2D since we're testing with no blocks and don't need actual graphics
        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, null, constraint);

        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.0);
        assertEquals(100.0, result.getHeight(), 0.0);
    }
}