package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_6_0_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_AllBlocksNull() {
        RectangleConstraint constraint = new RectangleConstraint(100.0, 50.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(50.0, result.getHeight(), 0.001);
    }

    @Test
    public void testArrangeFF_WithCenterBlock() {
        Block centerBlock = mock(Block.class);
        arrangement.add(centerBlock, null);
        
        RectangleConstraint constraint = new RectangleConstraint(200.0, 150.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(200.0, result.getWidth(), 0.001);
        assertEquals(150.0, result.getHeight(), 0.001);
        
        // Verify center block bounds - should be positioned at (0,0) with full dimensions
        verify(centerBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 200.0, 150.0));
    }

    @Test
    public void testArrangeFF_WithTopBlock() {
        Block topBlock = mock(Block.class);
        when(topBlock.arrange(g2, new RectangleConstraint(300.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 200.0), 
                LengthConstraintType.RANGE)))
                .thenReturn(new Size2D(300.0, 40.0));
        
        arrangement.add(topBlock, org.jfree.chart.util.RectangleEdge.TOP);
        
        RectangleConstraint constraint = new RectangleConstraint(300.0, 200.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(300.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        
        // Verify top block bounds
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 300.0, 40.0));
    }

    @Test
    public void testArrangeFF_WithBottomBlock() {
        Block bottomBlock = mock(Block.class);
        when(bottomBlock.arrange(g2, new RectangleConstraint(400.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 250.0), 
                LengthConstraintType.RANGE)))
                .thenReturn(new Size2D(400.0, 30.0));
        
        arrangement.add(bottomBlock, org.jfree.chart.util.RectangleEdge.BOTTOM);
        
        RectangleConstraint constraint = new RectangleConstraint(400.0, 250.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(400.0, result.getWidth(), 0.001);
        assertEquals(250.0, result.getHeight(), 0.001);
        
        // Verify bottom block bounds - should be at bottom with remaining height
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 220.0, 400.0, 30.0));
    }

    @Test
    public void testArrangeFF_WithLeftAndRightBlocks() {
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        
        when(leftBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 500.0), LengthConstraintType.RANGE, 300.0, null,
                LengthConstraintType.FIXED)))
                .thenReturn(new Size2D(80.0, 300.0));
        
        when(rightBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, Math.max(500.0 - 80.0, 0.0)), 
                LengthConstraintType.RANGE, 300.0, null,
                LengthConstraintType.FIXED)))
                .thenReturn(new Size2D(70.0, 300.0));
        
        arrangement.add(leftBlock, org.jfree.chart.util.RectangleEdge.LEFT);
        arrangement.add(rightBlock, org.jfree.chart.util.RectangleEdge.RIGHT);
        
        RectangleConstraint constraint = new RectangleConstraint(500.0, 300.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(500.0, result.getWidth(), 0.001);
        assertEquals(300.0, result.getHeight(), 0.001);
        
        // Verify left and right block bounds
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 80.0, 300.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(430.0, 0.0, 70.0, 300.0));
    }

    @Test
    public void testArrangeFF_WithAllBlocks() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        // Setup top block
        when(topBlock.arrange(g2, new RectangleConstraint(600.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 400.0), 
                LengthConstraintType.RANGE)))
                .thenReturn(new Size2D(600.0, 50.0));
        
        // Setup bottom block
        when(bottomBlock.arrange(g2, new RectangleConstraint(600.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 350.0), 
                LengthConstraintType.RANGE)))
                .thenReturn(new Size2D(600.0, 40.0));
        
        // Setup left block
        when(leftBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 600.0), LengthConstraintType.RANGE, 310.0, null,
                LengthConstraintType.FIXED)))
                .thenReturn(new Size2D(100.0, 310.0));
        
        // Setup right block
        when(rightBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, Math.max(600.0 - 100.0, 0.0)), 
                LengthConstraintType.RANGE, 310.0, null,
                LengthConstraintType.FIXED)))
                .thenReturn(new Size2D(90.0, 310.0));
        
        arrangement.add(topBlock, org.jfree.chart.util.RectangleEdge.TOP);
        arrangement.add(bottomBlock, org.jfree.chart.util.RectangleEdge.BOTTOM);
        arrangement.add(leftBlock, org.jfree.chart.util.RectangleEdge.LEFT);
        arrangement.add(rightBlock, org.jfree.chart.util.RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);
        
        RectangleConstraint constraint = new RectangleConstraint(600.0, 400.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(600.0, result.getWidth(), 0.001);
        assertEquals(400.0, result.getHeight(), 0.001);
        
        // Verify all block bounds
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 600.0, 50.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 360.0, 600.0, 40.0));
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 50.0, 100.0, 310.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(410.0, 50.0, 90.0, 310.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(100.0, 50.0, 310.0, 310.0));
    }

    @Test
    public void testArrangeFF_WithTopAndBottomBlocks() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        
        when(topBlock.arrange(g2, new RectangleConstraint(400.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 300.0), 
                LengthConstraintType.RANGE)))
                .thenReturn(new Size2D(400.0, 60.0));
        
        when(bottomBlock.arrange(g2, new RectangleConstraint(400.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 240.0), 
                LengthConstraintType.RANGE)))
                .thenReturn(new Size2D(400.0, 50.0));
        
        arrangement.add(topBlock, org.jfree.chart.util.RectangleEdge.TOP);
        arrangement.add(bottomBlock, org.jfree.chart.util.RectangleEdge.BOTTOM);
        
        RectangleConstraint constraint = new RectangleConstraint(400.0, 300.0);
        Size2D result = arrangement.arrangeFF(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(400.0, result.getWidth(), 0.001);
        assertEquals(300.0, result.getHeight(), 0.001);
        
        // Verify top and bottom block bounds
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 400.0, 60.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 250.0, 400.0, 50.0));
    }
}