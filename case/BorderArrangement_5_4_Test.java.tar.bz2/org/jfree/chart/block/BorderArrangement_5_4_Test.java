package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_5_4_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;
    private Block rightBlock;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
        rightBlock = mock(Block.class);
    }

    @Test
    public void testArrangeFF_WithRightBlock() {
        // Add the right block to the arrangement
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        
        // Create constraints that will trigger arrangeFF path
        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
        
        // Mock the behavior of the right block with specific constraint
        RectangleConstraint rightConstraint = new RectangleConstraint(0.0,
                new Range(0.0, 100.0), // width range: 0.0 to 100.0
                LengthConstraintType.RANGE, 150.0, null, // fixed height: 150.0
                LengthConstraintType.FIXED);
        
        when(rightBlock.arrange(g2, rightConstraint))
            .thenReturn(new Size2D(30.0, 150.0));
        
        // Mock the container behavior
        RectangleConstraint contentConstraint = new RectangleConstraint(100.0, 200.0);
        when(container.toContentConstraint(constraint)).thenReturn(contentConstraint);
        when(container.calculateTotalWidth(100.0)).thenReturn(100.0);
        when(container.calculateTotalHeight(200.0)).thenReturn(200.0);
        
        // Call the public arrange method which will internally call arrangeFF
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        
        // Verify the right block bounds are set correctly
        verify(rightBlock).setBounds(new Rectangle2D.Double(70.0, 50.0, 30.0, 150.0));
    }

    @Test
    public void testArrangeFF_NoBlocks() {
        // Create a fresh arrangement without any blocks
        BorderArrangement emptyArrangement = new BorderArrangement();
        
        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
        
        // Create a new mock container for this test to avoid interference
        BlockContainer testContainer = mock(BlockContainer.class);
        
        // Mock the container behavior
        RectangleConstraint contentConstraint = new RectangleConstraint(100.0, 200.0);
        when(testContainer.toContentConstraint(constraint)).thenReturn(contentConstraint);
        when(testContainer.calculateTotalWidth(100.0)).thenReturn(100.0);
        when(testContainer.calculateTotalHeight(200.0)).thenReturn(200.0);
        
        // Call the public arrange method which will internally call arrangeFF
        Size2D result = emptyArrangement.arrange(testContainer, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
    }
}