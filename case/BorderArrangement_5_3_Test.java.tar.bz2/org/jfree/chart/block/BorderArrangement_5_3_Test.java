package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_5_3_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFFWithLeftAndRightBlocks() {
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);

        // Mock the arrange calls for left and right blocks
        when(leftBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 100.0), LengthConstraintType.RANGE, 
                200.0, null, LengthConstraintType.FIXED)))
                .thenReturn(new Size2D(30.0, 200.0));
        
        when(rightBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 70.0), LengthConstraintType.RANGE, 
                200.0, null, LengthConstraintType.FIXED)))
                .thenReturn(new Size2D(25.0, 200.0));

        // Create a constraint that will trigger arrangeFF path
        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
        
        // Test through the public arrange method
        Size2D result = arrangement.arrange(container, g2, constraint);

        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        
        // Verify that blocks were set with correct bounds
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 30.0, 200.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(75.0, 0.0, 25.0, 200.0));
    }

    @Test
    public void testArrangeFFWithAllBlocks() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);

        // Mock arrange calls for all blocks
        when(topBlock.arrange(g2, new RectangleConstraint(150.0, null,
                LengthConstraintType.FIXED, 0.0,
                new Range(0.0, 200.0), LengthConstraintType.RANGE)))
                .thenReturn(new Size2D(150.0, 30.0));
        
        when(bottomBlock.arrange(g2, new RectangleConstraint(150.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 170.0), 
                LengthConstraintType.RANGE)))
                .thenReturn(new Size2D(150.0, 25.0));
        
        when(leftBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 150.0), LengthConstraintType.RANGE, 
                145.0, null, LengthConstraintType.FIXED)))
                .thenReturn(new Size2D(40.0, 145.0));
        
        when(rightBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 110.0), LengthConstraintType.RANGE, 
                145.0, null, LengthConstraintType.FIXED)))
                .thenReturn(new Size2D(35.0, 145.0));
        
        when(centerBlock.arrange(g2, new RectangleConstraint(75.0, 145.0)))
                .thenReturn(new Size2D(75.0, 145.0));

        RectangleConstraint constraint = new RectangleConstraint(150.0, 200.0);
        Size2D result = arrangement.arrange(container, g2, constraint);

        assertNotNull(result);
        assertEquals(150.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        
        // Verify bounds for all blocks
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 150.0, 30.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 175.0, 150.0, 25.0));
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 30.0, 40.0, 145.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(115.0, 30.0, 35.0, 145.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(40.0, 30.0, 75.0, 145.0));
    }
}