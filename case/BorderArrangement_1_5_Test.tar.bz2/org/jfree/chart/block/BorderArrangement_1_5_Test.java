package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_1_5_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_OnlyCenterBlock() {
        Block centerBlock = mock(Block.class);
        arrangement.add(centerBlock, null);
        
        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
        
        // Mock container behavior
        when(container.toContentConstraint(constraint))
                .thenReturn(constraint);
        when(container.calculateTotalWidth(100.0)).thenReturn(100.0);
        when(container.calculateTotalHeight(200.0)).thenReturn(200.0);
        
        // Call the public arrange method which will internally call arrangeFF
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
        
        // When only center block exists in arrangeFF, it should be positioned at (0,0) with full width and height
        verify(centerBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 200.0));
    }

    @Test
    public void testArrangeFF_WithAllBlocks() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        arrangement.add(topBlock, org.jfree.chart.util.RectangleEdge.TOP);
        arrangement.add(bottomBlock, org.jfree.chart.util.RectangleEdge.BOTTOM);
        arrangement.add(leftBlock, org.jfree.chart.util.RectangleEdge.LEFT);
        arrangement.add(rightBlock, org.jfree.chart.util.RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);
        
        RectangleConstraint constraint = new RectangleConstraint(300.0, 400.0);
        
        // Mock block arrangements - these should match the constraints used in arrangeFF
        when(topBlock.arrange(g2, new RectangleConstraint(300.0, null,
                LengthConstraintType.FIXED, 0.0,
                new Range(0.0, 400.0),
                LengthConstraintType.RANGE)))
                .thenReturn(new Size2D(300.0, 50.0));
        
        when(bottomBlock.arrange(g2, new RectangleConstraint(300.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 350.0),
                LengthConstraintType.RANGE)))
                .thenReturn(new Size2D(300.0, 60.0));
        
        when(leftBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 300.0),
                LengthConstraintType.RANGE, 290.0, null,
                LengthConstraintType.FIXED)))
                .thenReturn(new Size2D(80.0, 290.0));
        
        when(rightBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 220.0),
                LengthConstraintType.RANGE, 290.0, null,
                LengthConstraintType.FIXED)))
                .thenReturn(new Size2D(70.0, 290.0));
        
        // Center block arrangement with fixed constraints
        RectangleConstraint centerConstraint = new RectangleConstraint(150.0, 290.0);
        when(centerBlock.arrange(g2, centerConstraint))
                .thenReturn(new Size2D(150.0, 290.0));
        
        // Mock container behavior
        when(container.toContentConstraint(constraint))
                .thenReturn(constraint);
        when(container.calculateTotalWidth(300.0)).thenReturn(300.0);
        when(container.calculateTotalHeight(400.0)).thenReturn(400.0);
        
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(300.0, result.getWidth(), 0.001);
        assertEquals(400.0, result.getHeight(), 0.001);
        
        // Verify bounds for all blocks according to arrangeFF logic
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 300.0, 50.0));
        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 350.0, 300.0, 60.0));
        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 50.0, 80.0, 290.0));
        verify(rightBlock).setBounds(new Rectangle2D.Double(230.0, 50.0, 70.0, 290.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(80.0, 50.0, 150.0, 290.0));
    }

    @Test
    public void testArrangeFF_WithTopAndCenterBlocks() {
        Block topBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        arrangement.add(topBlock, org.jfree.chart.util.RectangleEdge.TOP);
        arrangement.add(centerBlock, null);
        
        RectangleConstraint constraint = new RectangleConstraint(200.0, 300.0);
        
        // Mock block arrangements
        when(topBlock.arrange(g2, new RectangleConstraint(200.0, null,
                LengthConstraintType.FIXED, 0.0,
                new Range(0.0, 300.0),
                LengthConstraintType.RANGE)))
                .thenReturn(new Size2D(200.0, 40.0));
        
        RectangleConstraint centerConstraint = new RectangleConstraint(200.0, 260.0);
        when(centerBlock.arrange(g2, centerConstraint))
                .thenReturn(new Size2D(200.0, 260.0));
        
        // Mock container behavior
        when(container.toContentConstraint(constraint))
                .thenReturn(constraint);
        when(container.calculateTotalWidth(200.0)).thenReturn(200.0);
        when(container.calculateTotalHeight(300.0)).thenReturn(300.0);
        
        Size2D result = arrangement.arrange(container, g2, constraint);
        
        assertNotNull(result);
        assertEquals(200.0, result.getWidth(), 0.001);
        assertEquals(300.0, result.getHeight(), 0.001);
        
        // Verify bounds
        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 200.0, 40.0));
        verify(centerBlock).setBounds(new Rectangle2D.Double(0.0, 40.0, 200.0, 260.0));
    }
}