package org.jfree.chart.block;
import static org.mockito.Mockito.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.lang.reflect.Method;

import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
import org.junit.Before;
import org.junit.Test;

public class BorderArrangement_0_0_Test {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;

    @Before
    public void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    public void testArrangeFF_AllBlocksPresent() throws Exception {
        // Setup blocks
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);

        // Mock block arrangements with correct RectangleConstraint parameters
        // These constraints match exactly what arrangeFF creates internally
        when(topBlock.arrange(g2, new RectangleConstraint(100.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 200.0),
                LengthConstraintType.RANGE))).thenReturn(new Size2D(100.0, 20.0));
        
        when(bottomBlock.arrange(g2, new RectangleConstraint(100.0, null,
                LengthConstraintType.FIXED, 0.0, new Range(0.0, 180.0),
                LengthConstraintType.RANGE))).thenReturn(new Size2D(100.0, 30.0));
        
        when(leftBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 100.0), LengthConstraintType.RANGE, 150.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(25.0, 150.0));
        
        when(rightBlock.arrange(g2, new RectangleConstraint(0.0,
                new Range(0.0, 75.0), LengthConstraintType.RANGE, 150.0, null,
                LengthConstraintType.FIXED))).thenReturn(new Size2D(20.0, 150.0));
        
        // Center block uses simple constraint in arrangeFF
        when(centerBlock.arrange(g2, new RectangleConstraint(55.0, 150.0)))
                .thenReturn(new Size2D(55.0, 150.0));

        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
        
        // Use reflection to test the protected arrangeFF method directly
        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
            "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
        arrangeFFMethod.setAccessible(true);
        
        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);

        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.0);
        assertEquals(200.0, result.getHeight(), 0.0);
    }

    @Test
    public void testArrangeFF_OnlyCenterBlock() throws Exception {
        // Setup only center block
        Block centerBlock = mock(Block.class);
        arrangement.add(centerBlock, null);

        // Mock center block arrangement
        when(centerBlock.arrange(g2, new RectangleConstraint(100.0, 200.0)))
                .thenReturn(new Size2D(100.0, 200.0));

        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
        
        // Use reflection to test the protected arrangeFF method directly
        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
            "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
        arrangeFFMethod.setAccessible(true);
        
        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);

        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.0);
        assertEquals(200.0, result.getHeight(), 0.0);
    }

    @Test
    public void testArrangeFF_NoBlocks() throws Exception {
        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
        
        // Use reflection to test the protected arrangeFF method directly
        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
            "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
        arrangeFFMethod.setAccessible(true);
        
        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);

        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.0);
        assertEquals(200.0, result.getHeight(), 0.0);
    }
}